# Longitudinal Memory — [Speaker Name]
# meeting-insights-analyzer · tracking comunicazione nel tempo

---

## YYYY-MM-DD — [Meeting Name] ([Meeting Type])

- **CEI**: XX/100 — *[Label]*
- **Speaking**: X%  **Fillers/min**: X.X  **Questions**: X
- **Top strength**: [one line description]
- **Top growth area**: [one line description]
- **Category scores**: AL=X CA=X SB=X FW=X FA=X

---

<!-- Add new entries above this line, most recent first -->
<!-- Format: one ## block per meeting session -->
<!-- The skill reads this file at session start to compute CEI delta -->
