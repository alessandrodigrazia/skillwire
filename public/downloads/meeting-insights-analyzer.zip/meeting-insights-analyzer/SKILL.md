---
name: meeting-insights-analyzer
description: Analyzes meeting transcripts (.vtt, .srt, .txt, .md, .docx) to identify communication patterns, calculate a Communication Effectiveness Index (CEI) score 0-100, and generate an interactive HTML dashboard with radar chart, filler word breakdown, and pattern timeline. This skill should be used when users want to analyze their communication style from meeting recordings, get behavioral feedback with timestamped examples, track communication improvement over time, or prepare coaching insights from transcripts.
---

# Meeting Insights Analyzer

Transforms meeting transcripts into actionable communication insights: pattern detection, CEI scoring, HTML dashboard, coaching card, and longitudinal progress tracking.

## When to Use

- Analyzing communication patterns (conflict avoidance, filler words, active listening, facilitation)
- Getting timestamped behavioral feedback from meeting recordings
- Tracking communication improvement over time across multiple meetings
- Generating a visual dashboard to share or use in coaching sessions

## Workflow

### Step 1 — Discover & Memory Check

- Scan the target folder or file for transcripts (.vtt, .srt, .txt, .md, .docx)
- Confirm speaker labels and timestamp format (WebVTT `<v Name>`, SRT numbers, plain text, etc.)
- Identify the subject speaker and the date range of the meeting(s)
- **Check longitudinal memory**: look for `memory/[speaker-name].md` inside this skill folder
  - If found: load silently and prepare a delta line for the CEI section (`vs. [date]: CEI [prev] → [new] ([+/-delta] pts)`)
  - If not found: this session will become the baseline

### Step 2 — Clarify Meeting Type

Identify the meeting type from transcript context. If ambiguous, ask. Store it — it calibrates all scoring.

See `references/patterns-guide.md` → *Meeting Type Benchmarks* for optimal speaking % and priority metrics per type.

### Step 3 — Analyze Patterns

Read the full transcript. For each category, apply the detection rules in `references/patterns-guide.md`:

- **Conflict Avoidance** — hedging language, indirect phrasing, vague commitments, self-deprecating disclaimers
- **Speaking Ratios** — % of total speaking time, turn count, average turn length, question/statement ratio
- **Filler Words** — auto-detect language; count per minute and per speaking turn; track dominant filler and contexts where frequency spikes (see language lists in patterns-guide.md)
- **Active Listening** — paraphrases, clarifying questions, build-on references, cross-connections
- **Facilitation** — next steps with who/what/when, agenda control, inclusive questions, decision clarity

### Step 4 — Collect Examples

For each pattern identified, collect 2–3 timestamped examples in this format:

```markdown
**[Timestamp]** — [What happened] / [Why it matters] / [Better approach]
> "[Verbatim quote from transcript]"
```

### Step 5 — Generate Summary Report

Produce the full report. Use the CEI scoring formula from `references/scoring-guide.md` to calculate scores.

```markdown
# Meeting Insights Summary

**Meeting**: [Name] · **Date**: [Date] · **Duration**: [X min] · **Type**: [Meeting Type]
**Speaker analyzed**: [Name]

## Communication Effectiveness Index (CEI)

**Score**: [XX]/100 — [Excellent ≥85 / Good 70–84 / Developing 55–69 / Needs Work <55]

| Category           | Score    | Weight | Contribution |
|--------------------|----------|--------|--------------|
| Active Listening   | [XX]/100 | 25%    | [XX.XX] pts  |
| Conflict Avoidance | [XX]/100 | 20%    | [XX.XX] pts  |
| Speaking Balance   | [XX]/100 | 20%    | [XX.XX] pts  |
| Filler Words       | [XX]/100 | 20%    | [XX.XX] pts  |
| Facilitation       | [XX]/100 | 15%    | [XX.XX] pts  |

[If longitudinal memory found: *vs. [prev date]: CEI [prev] → [new] ([+/-delta] pts)*]

## Key Patterns

### 1. [Primary Pattern]
**Finding** · **Frequency** · **Examples** (2–3 with timestamps) · **Better Approach**

### 2. [Second Pattern]
[Same structure]

## Communication Strengths
1. [Strength with example]
2. [Strength with example]
3. [Strength with example]

## Growth Opportunities
1. **[Area]**: [Specific, actionable advice]
2. **[Area]**: [Specific, actionable advice]
3. **[Area]**: [Specific, actionable advice]

## Speaking Statistics
- Speaking time: [X%] · Questions asked: [X] · Fillers/min: [X.X] · Interruptions: [X] · Turns: [X]
- Dominant filler: "[word]" ([N] instances)

## Next Steps
[3–5 concrete actions]
```

### Step 6 — Generate Outputs

**Always generate automatically — no need to ask for dashboard or coaching card:**

#### a) HTML Dashboard

Read `assets/dashboard-template.html`. Fill all `{{PLACEHOLDER}}` values using the scoring reference in `references/scoring-guide.md`. Generate immediately after the Summary Report — do not ask.

**Environment detection:**
- **Claude Code** (file system available): save as `meeting-dashboard-[speaker]-[YYYYMMDD].html` in the same folder as the transcript. Confirm path after saving.
- **Claude Desktop / claude.ai** (no file system): produce the complete filled HTML as an artifact — the user can copy and save it locally.

#### b) Coaching Card

Always produce inline in chat immediately after the dashboard — no need to ask:

```
┌─────────────────────────────────────────────────────┐
│  COACHING CARD — [Speaker] · [Date]                 │
├─────────────────────────────────────────────────────┤
│  ✓ KEEP    [Strength 1 — 5 words max]               │
│            [Strength 2 — 5 words max]               │
│            [Strength 3 — 5 words max]               │
├─────────────────────────────────────────────────────┤
│  ✗ AVOID   [Behavior or filler — specific trigger]  │
│            [Behavior or filler — specific trigger]  │
│            [Behavior or filler — specific trigger]  │
├─────────────────────────────────────────────────────┤
│  → FOCUS   [One concrete priority + when]           │
└─────────────────────────────────────────────────────┘
```

#### c) Memory Save (ask once)

After dashboard and coaching card, ask once: *"Salvo i risultati per il tracking del progresso nel tempo?"*

If yes:
- **Claude Code**: create or append to `memory/[speaker-name].md` (see `memory/_example.md` for format)
- **Claude Desktop / claude.ai**: produce the memory entry as a Markdown artifact for the user to download and provide in future sessions

**Memory entry format:**
```markdown
## [YYYY-MM-DD] — [Meeting Name] ([Meeting Type])
- **CEI**: [XX]/100
- **Speaking**: [X]%  **Fillers/min**: [X.X]  **Questions**: [X]
- **Top strength**: [one line]
- **Top growth area**: [one line]
- **Category scores**: AL=[X] CA=[X] SB=[X] FW=[X] FA=[X]
```
