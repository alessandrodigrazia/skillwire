# Patterns Guide — Meeting Insights Analyzer

## Contents
- [Meeting Type Benchmarks](#meeting-type-benchmarks)
- [Conflict Avoidance](#conflict-avoidance)
- [Speaking Ratios](#speaking-ratios)
- [Filler Words](#filler-words)
- [Active Listening](#active-listening)
- [Facilitation](#facilitation)

---

## Meeting Type Benchmarks

| Meeting Type | Optimal Speaking % | Priority Metrics |
|--------------|-------------------|-----------------|
| **1:1 / Coaching / Check-in** | 40–55% | 6+ clarifying questions, listening-dominant |
| **Team Meeting** | <30% | Facilitation, inclusive questions, agenda control |
| **Client Presentation / Sales** | 40–60% | Structured delivery, minimal fillers, explicit next steps |
| **Negotiation / Difficult Conversation** | <40% | Active listening, open questions, low hedging |
| **Peer Sync / Collaborative Session** | 40–60% | Balanced exchange, collaborative tone |

Use the meeting type to calibrate Speaking Balance scoring — distance from the optimal range determines the SB score (see scoring-guide.md).

---

## Conflict Avoidance

### What to Look For

**Hedging language** (softens a position unnecessarily):
- "maybe", "kind of", "I think", "sort of", "I guess", "perhaps"
- Italian: "forse", "tipo", "mi sembra", "non so", "magari"

**Indirect phrasing** (avoids naming the issue directly):
- Hinting at problems instead of stating them
- Asking rhetorical questions instead of making direct requests
- Changing subject when tension arises

**Self-deprecating disclaimers** (undermines credibility before a valid point):
- "I might be wrong but...", "I don't know if this makes sense..."
- Italian: "io dico bestialità perché non sono tecnico", "non ne capisco una mazza"
- Pattern: disclaimer immediately precedes a correct and useful insight

**Vague commitments** (intent without accountability):
- "We'll figure it out", "Let's see", "Sometime soon"
- Italian: "ci troviamo un modo", "non so quando", "vedremo"
- A vague commitment is when the speaker offers help/action but refuses to attach a time or clear ownership

**Agreement without conviction**:
- "Yeah, sure, whatever you think is best" — acquiesces without genuine agreement
- Deflecting ownership: "Whatever you decide is fine"

### Scoring Guidance

Count meaningful instances (not casual speech). A single "maybe" in small talk does not count. Count instances where hedging/indirectness significantly weakens the communication impact.

---

## Speaking Ratios

### What to Calculate

- **Speaking time %**: total speaker time ÷ total meeting time × 100
  - For VTT files: sum of duration of all `<v Speaker>` segments
  - For text: estimate by word count proportion
- **Turn count**: number of distinct speaking turns
- **Average turn length**: total speaking time ÷ turn count
- **Question/statement ratio**: questions asked ÷ total turns (questions are phrases ending in "?" or with interrogative structure)
- **Interruptions**: turns where the speaker starts before the previous speaker's timestamp has ended

### Calibration Notes

- In a 2-person meeting where one person is demoing/presenting, 60–65% speaking is expected — context matters
- Apply meeting type benchmark before scoring (see above)
- Excessive speaking (>70%) in a 1:1 or team meeting signals poor listening; moderate excess (60–65%) in a demo/peer sync is contextually appropriate

---

## Filler Words

### Auto-Detect Language from Transcript

Apply the list for the transcript's language. Count ALL instances across the full transcript for the subject speaker only.

**English**
`um`, `uh`, `like`, `you know`, `actually`, `basically`, `literally`, `I mean`, `sort of`, `kind of`, `right?`, `so...`

**Italian**
`cioè`, `diciamo`, `come dire`, `no?`, `appunto`, `tra l'altro`, `boh`, `ecco`, `vabbè`, `praticamente`, `nel senso`, `tipo`, `insomma`

**Spanish**
`o sea`, `bueno`, `este`, `pues`, `entonces`, `a ver`, `vamos`, `¿no?`, `osea`

**French**
`euh`, `bah`, `voilà`, `donc`, `genre`, `en fait`, `du coup`, `quoi`, `hein`

### How to Count

- Count per minute of **total meeting duration** (not just speaking time) — this is the standard metric for the CEI
- Also note **per speaking turn** — identifies whether fillers cluster in specific moments
- Track **per-word breakdown**: list the top 5 fillers with individual counts
- Note **context spikes**: when does filler frequency increase? (topic transitions, uncertainty, pushback from others, technical explanations)

### Interpretation

High filler frequency in topic transitions = habit/connector. High frequency under pushback = uncertainty/anxiety. Both patterns have different coaching implications.

---

## Active Listening

### What to Look For

**Paraphrasing**: restates the other person's point in different words before responding
- "So what you're saying is...", "If I understand correctly..."
- Italian: "Quindi stai dicendo che...", "Se ho capito bene..."

**Clarifying questions**: asks for more information about something the other person said
- References the other person's specific words or ideas
- Distinguishes from rhetorical questions (which don't seek real information)

**Build-on references**: explicitly connects own contribution to the other person's earlier point
- "Building on what you said about X...", "That's exactly why I was thinking Y..."
- Italian: "Partendo da quello che hai detto su...", "Proprio per questo..."

**Cross-connections**: links information from different parts of the meeting
- "You mentioned earlier that X — that's relevant here because..."
- Shows the speaker has been listening across the full conversation, not just the last exchange

### Scoring Guidance

Count each distinct instance of the above (paraphrase, clarifying question, build-on, cross-connection) as +1 AL signal. Use the total to determine the AL score via scoring-guide.md.

---

## Facilitation

### What to Look For

**Explicit next steps**: states a clear action with owner and timeframe
- Full: "I'll send you the document by Friday" → who (I) + what (document) + when (Friday)
- Partial: "Let me send you the document" → who + what, no when → counts as 0.5
- Vague: "We'll follow up on this" → no owner, no timeframe → does not count

**Agenda control**: actively steers the conversation toward the intended topics
- Redirecting off-topic tangents back to the agenda
- Proposing a structure: "Let me show you X first, then we can discuss Y"

**Inclusive questions**: draws in quieter participants or seeks explicit confirmation from others
- "What do you think about this, [name]?", "Does this make sense from your side?"

**Decision clarity**: explicitly names when a decision has been made
- "So we've agreed that...", "The plan is..."

### Scoring Guidance

Count each distinct facilitation action. "Who/what/when" next steps score full; partial next steps (missing one element) score 0.5.
