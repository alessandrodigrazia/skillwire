# Scoring Guide — Meeting Insights Analyzer

## Contents
- [CEI Formula](#cei-formula)
- [Category Scoring Rules](#category-scoring-rules)
- [Dashboard Placeholder Reference](#dashboard-placeholder-reference)

---

## CEI Formula

```
CEI = (AL × 0.25) + (CA × 0.20) + (SB × 0.20) + (FW × 0.20) + (FA × 0.15)
```

| Category | Code | Weight |
|----------|------|--------|
| Active Listening | AL | 25% |
| Conflict Avoidance | CA | 20% |
| Speaking Balance | SB | 20% |
| Filler Words | FW | 20% |
| Facilitation | FA | 15% |

**CEI Labels**: ≥85 Excellent · 70–84 Good · 55–69 Developing · <55 Needs Work

---

## Category Scoring Rules

### Active Listening (AL) — 0 to 100

Count total AL signals: paraphrases + clarifying questions + build-on references + cross-connections.

| Total AL signals | Score |
|-----------------|-------|
| 0–2 | 20 |
| 3–5 | 50 |
| 6–9 | 75 |
| 10+ | 100 |

### Conflict Avoidance (CA) — 0 to 100

Count meaningful conflict-avoidance instances (hedging, indirect phrasing, vague commitments, self-deprecating disclaimers). Fewer = better score.

| Instances | Score |
|-----------|-------|
| 0 | 100 |
| 1–2 | 80 |
| 3–4 | 60 |
| 5–6 | 35 |
| 7+ | 0 |

### Speaking Balance (SB) — 0 to 100

Calculate actual speaking % and compare to the optimal range for the detected meeting type (see patterns-guide.md).

| Distance from optimal range | Score |
|----------------------------|-------|
| Within range | 100 |
| 1–10% outside | 70 |
| 11–20% outside | 40 |
| >20% outside | 10 |

*Example: Peer Sync optimal = 40–60%. Speaker at 63% → 3% outside → Score 70.*

### Filler Words (FW) — 0 to 100

Calculate fillers per minute of **total meeting duration**.

| Fillers/min | Score |
|-------------|-------|
| 0.0 | 100 |
| 0.5 | 85 |
| 1.0 | 70 |
| 1.5 | 50 |
| 2.0 | 25 |
| ≥2.5 | 0 |

*Interpolate linearly between thresholds. Example: 1.7/min → 50 − ((1.7−1.5)/(2.0−1.5)) × (50−25) = 50 − 10 = 40.*

### Facilitation (FA) — 0 to 100

Count explicit facilitation actions: next steps with who/what/when (full = 1, partial = 0.5), agenda control moves, inclusive questions, decision clarity statements.

| Total actions | Score |
|--------------|-------|
| 0 | 20 |
| 1–2 | 50 |
| 3–4 | 75 |
| 5+ | 100 |

---

## Dashboard Placeholder Reference

When filling `assets/dashboard-template.html`, replace all `{{PLACEHOLDER}}` values:

| Placeholder | Value |
|-------------|-------|
| `{{LANG}}` | `it` for Italian transcripts, `en` for English |
| `{{SPEAKER_NAME}}` | Full name of the analyzed speaker |
| `{{MEETING_NAME}}` | Meeting title from filename or transcript header |
| `{{DATE}}` | Meeting date (YYYY-MM-DD) |
| `{{DURATION}}` | e.g. `45 min` |
| `{{MEETING_TYPE}}` | e.g. `PEER SYNC` (uppercase) |
| `{{CEI_SCORE}}` | Integer 0–100 |
| `{{CEI_LABEL}}` | Excellent / Good / Developing / Needs Work |
| `{{AL_SCORE}}` `{{CA_SCORE}}` `{{SB_SCORE}}` `{{FW_SCORE}}` `{{FA_SCORE}}` | Category scores 0–100 (integers) |
| `{{SPEAKING_PCT}}` | Speaker's % of total talking time (integer) |
| `{{OTHER_PCT}}` | 100 − SPEAKING_PCT |
| `{{QUESTIONS_N}}` | Total questions asked |
| `{{FILLER_PM}}` | Fillers per minute (1 decimal, e.g. `1.4`) |
| `{{INTERRUPTIONS_N}}` | Total interruptions given |
| `{{TURNS_N}}` | Number of speaking turns |
| `{{FILLER_LABELS}}` | JS-ready quoted strings: `'"cioè"', '"diciamo"', '"no?"'` |
| `{{FILLER_COUNTS}}` | JS-ready integers: `35, 9, 6, 4, 3` |
| `{{STRENGTH_1}}` `{{STRENGTH_2}}` `{{STRENGTH_3}}` | 1–2 sentence strength descriptions |
| `{{GROWTH_1}}` `{{GROWTH_2}}` `{{GROWTH_3}}` | 1–2 sentence growth area descriptions |
| `{{TS_N}}` | Timestamp string e.g. `14:32` |
| `{{TAG_CLASS_N}}` | One of: `tag-conflict` `tag-filler` `tag-listen` `tag-speak` `tag-facil` |
| `{{TAG_LABEL_N}}` | One of: `CONFLICT` `FILLER` `LISTENING` `SPEAKING` `FACILITATION` |
| `{{PATTERN_DESC_N}}` | One-line description of the pattern |
| `{{QUOTE_N}}` | Short verbatim quote from transcript |
| `{{ANALYSIS_DATE}}` | Today's date (YYYY-MM-DD) |

**Timeline items**: Add one `<div class="tl-item">` block per pattern found. Aim for 8–15 items for a 45-min meeting.
