# Linkedin Toolkit — Skillwire Bundle

This bundle contains 3 skills. Install each one individually:

- content-pipeline-pro.zip
- human-writer.zip
- janus.zip

## Installation

For each skill ZIP:
- **Claude Code**: extract into ~/.claude/skills/ and you're done
- **Claude Desktop**: Settings → Features → Skills → Add, then upload the ZIP

Questions? hello@skillwire.ai
