---
name: n8n-docs-live
description: |
  Provides hybrid access to the official N8N documentation, prioritizing a local copy and falling back to live-searching the official GitHub repository via its native connector.
  This skill should be used when looking up n8n node documentation, checking node parameters,
  or searching for n8n API references.
---

# N8N Official Documentation Live Access (Hybrid)

## Overview

This skill provides **real-time, hybrid access** to the complete official N8N documentation. It is designed for maximum efficiency and portability.

**It is a core component of the 3-part N8N Skills Ecosystem:**
1.  **n8n-ai-workflow-expert** - Patterns & Strategy
2.  **n8n-workflow-repository** - Practical Examples
3.  **n8n-docs-live** - Official Source of Truth (THIS SKILL)

## 🧠 Hybrid Access Logic: "Local First, Live Cloud Fallback"

This skill MUST follow a two-step logic to access documentation:

### Step 1: Check for Local Repository (Primary Strategy)
1.  Read the `localPath` from `config/sync-config.json`.
2.  Check if this directory exists.
3.  **If it exists**, use this path for all file operations (`read`, `glob`, `search`). This is the **preferred, fastest method** and allows for offline use.

### Step 2: Use Native GitHub Connector (Fallback Strategy)
1.  **If the local path does not exist**, you MUST switch to using your native GitHub connector to access the documentation online.
2.  Read the `repoUrl` from `config/sync-config.json` (e.g., `n8n-io/n8n-docs`).
3.  Use the GitHub connector to perform file searches and read operations directly from the repository.

**This fallback ensures the skill is fully portable and works on any machine, even without a local copy of the documentation.**

## Configuration

The skill's behavior is controlled by `config/sync-config.json`.

- **`localPath`**: Absolute path to the primary, persistent local documentation repository.
- **`repoUrl`**: The identifier of the official GitHub repository (e.g., `owner/repo`).

## How to Use This Skill

When a query requires official documentation, you will automatically perform the hybrid access logic.

**Example Query:** "Explain RAG implementation in N8N"

**Your Internal Process:**
1.  Read `config/sync-config.json`.
2.  Check if `/path/to/your/n8n-docs-main` exists.

3.  **Scenario A (Local Path Found):**
    - Use local file tools. Search the local index (`index/docs-index.json`) to find the file `advanced-ai/rag-in-n8n.md`.
    - Read the file content from the local path.

4.  **Scenario B (Local Path Not Found - GitHub MCP Connector Fallback):**
    - Announce that you are switching to **online GitHub mode**.
    - Read GitHub configuration from `config/sync-config.json`:
      - `github.owner`: "n8n-io"
      - `github.repo`: "n8n-docs"
      - `github.branch`: "main"
      - `github.docsPath`: "docs"

    - Use the local index files (`index/docs-index.json`) to determine *which file to look for* online.
    - Construct the full file path: `docs/advanced-ai/rag-in-n8n.md`

    - **Use MCP GitHub Connector** (already configured in Claude Desktop):
      - The MCP connector provides tools to access GitHub repositories
      - Use available MCP tools (check what's available with `/mcp` or similar)
      - Common MCP GitHub operations:
        - `mcp__github__read_file` - Read file content from repository
        - `mcp__github__search_code` - Search code/files in repository
        - `mcp__github__list_directory` - List directory contents

    - **Recommended approach**:
      1. Use `mcp__github__read_file` with:
         - `owner`: "n8n-io"
         - `repo`: "n8n-docs"
         - `path`: "docs/advanced-ai/rag-in-n8n.md"
         - `branch`: "main" (or omit to use default)

      2. If file not found, try search with `mcp__github__search_code`:
         - `query`: "filename:rag-in-n8n.md repo:n8n-io/n8n-docs"

    - Parse the returned content (usually markdown)
    - Cache key information for this session if queried multiple times

5.  Synthesize the information and provide a complete answer.
6.  **Indicate which mode was used** in your response:
    - 📁 Local filesystem (fast, offline capable)
    - 🌐 GitHub online (portable, always current)

## Documentation Indexing

This skill contains pre-built indexes for fast searching, regardless of the access method (local or online):
- `index/docs-index.json`: A map of all 1200+ documentation files.
- `index/node-docs-map.json`: A map linking node names to their documentation files.

**Crucially, you should use these indexes to know *what* to search for, and then use either the local filesystem or the GitHub connector to read the content.**

## Maintenance

### Local Repository Update
If the local repository is used, it can be updated by running the `scripts/sync-docs.bat` script. You can trigger this by being asked: "Update the local N8N documentation".

### Online Access
No maintenance is needed for online access, as the GitHub MCP connector will always fetch the latest version from the `main` branch.

---

## 🔄 Hybrid Access Implementation Details

### Access Mode Decision Flow

```
User Query Received
    ↓
Read config/sync-config.json
    ↓
Check if localPath exists
    ↓
┌─────────────────┴─────────────────┐
│                                   │
YES (Local Found)              NO (Local Not Found)
│                                   │
📁 LOCAL MODE                    🌐 GITHUB MODE
│                                   │
├─ Fast access                  ├─ Use MCP connector
├─ Offline capable              ├─ Always current
├─ No rate limits               ├─ Portable (any PC)
└─ Read from filesystem         └─ Read from GitHub API
    ↓                                   ↓
    └───────────────┬───────────────────┘
                    ↓
            Answer user query
```

### MCP GitHub Connector Tools Reference

**When in GitHub fallback mode, Claude MUST use these MCP tools:**

1. **Read File** (Primary method):
   ```
   Tool: mcp__github__read_file
   Parameters:
   - owner: "n8n-io"
   - repo: "n8n-docs"
   - path: "docs/[category]/[filename].md"
   - branch: "main" (optional)
   ```

2. **Search Code** (If exact path unknown):
   ```
   Tool: mcp__github__search_code
   Parameters:
   - query: "filename:[name].md repo:n8n-io/n8n-docs"
   ```

3. **List Directory** (For exploration):
   ```
   Tool: mcp__github__list_directory
   Parameters:
   - owner: "n8n-io"
   - repo: "n8n-docs"
   - path: "docs/[category]"
   - branch: "main"
   ```

### Practical Examples

#### Example 1: Conceptual Query with Local Access

**User:** "Explain how RAG works in N8N"

**Claude's process:**
```
1. Check config/sync-config.json
2. Local path exists: /path/to/your/n8n-docs-main\docs ✓
3. Use LOCAL MODE 📁
4. Search index/docs-index.json → find "advanced-ai/rag-in-n8n.md"
5. Read local file: /path/to/your/docs\advanced-ai\rag-in-n8n.md
6. Parse content and respond

Response indicator: 📁 Information from local documentation
```

#### Example 2: Same Query on Different PC (GitHub Fallback)

**User:** "Explain how RAG works in N8N"

**Claude's process:**
```
1. Check config/sync-config.json
2. Local path NOT found: Path doesn't exist ✗
3. Switch to GITHUB MODE 🌐
4. Announce: "Switching to online GitHub documentation access"
5. Search index/docs-index.json → find "advanced-ai/rag-in-n8n.md"
6. Use MCP: mcp__github__read_file
   - owner: "n8n-io"
   - repo: "n8n-docs"
   - path: "docs/advanced-ai/rag-in-n8n.md"
   - branch: "main"
7. Parse returned content and respond

Response indicator: 🌐 Information from GitHub (latest version)
```

#### Example 3: Node Documentation Lookup

**User:** "Show me the Gmail node parameters"

**Local Mode:**
```
1. Check node-docs-map.json → "n8n-nodes-base.gmail"
2. Path: integrations/builtin/app-nodes/n8n-nodes-base.gmail/index.md
3. Read from local: /path/to/your/docs\integrations\...\gmail\index.md
4. Extract parameters section

Response: 📁 [Gmail Node Parameters from local docs]
```

**GitHub Mode:**
```
1. Check node-docs-map.json → "n8n-nodes-base.gmail"
2. Path: integrations/builtin/app-nodes/n8n-nodes-base.gmail/index.md
3. MCP call: mcp__github__read_file
   - path: "docs/integrations/builtin/app-nodes/n8n-nodes-base.gmail/index.md"
4. Extract parameters section

Response: 🌐 [Gmail Node Parameters from GitHub - latest]
```

---

## 🎯 Benefits of Hybrid Approach

### Local Mode Benefits
- ⚡ **Speed**: Instant access to documentation
- 🔌 **Offline**: Works without internet connection
- 💰 **No rate limits**: Unlimited reads
- 🎯 **Consistent**: Known version, no surprises

### GitHub Mode Benefits
- 🌍 **Portability**: Works on ANY PC with Claude Desktop
- 🔄 **Always current**: Latest documentation from main branch
- 📱 **No setup**: No need to clone repository
- ✅ **Automatic**: Fallback is transparent

### Best of Both Worlds
- 🏠 **At home PC**: Use fast local copy
- 💼 **At work PC**: Use GitHub fallback automatically
- 🌐 **On the go**: GitHub mode always works
- 🔄 **Seamless transition**: User doesn't need to do anything

---

## ⚙️ Configuration Management

### sync-config.json Structure

```json
{
  "localPath": "C:\\...\\docs",
  "gitRepoRoot": "C:\\...\\n8n-docs-main",
  "github": {
    "owner": "n8n-io",
    "repo": "n8n-docs",
    "branch": "main",
    "docsPath": "docs"
  },
  "accessMode": "hybrid",
  "preferLocal": true,
  "fallbackEnabled": true,
  "mcpConnector": "github"
}
```

**Key fields:**
- `localPath`: Primary documentation directory
- `github.owner`: GitHub repository owner
- `github.repo`: Repository name
- `github.branch`: Branch to read from (usually "main")
- `github.docsPath`: Subdirectory within repo containing docs
- `preferLocal`: Try local first if both available
- `fallbackEnabled`: Enable GitHub fallback if local not found
- `mcpConnector`: Specify which MCP connector to use

### Updating Configuration

If you move the local repository or want to change GitHub settings:

1. Edit `config/sync-config.json`
2. Update `localPath` to new location
3. GitHub settings rarely need changes (official repo)
4. Skill will automatically adapt on next use

---

## 🚨 Error Handling

### Local Path Not Found
```
Status: Local documentation not found at configured path
Action: Automatically switching to GitHub mode
Message: "📁→🌐 Switching to online GitHub documentation"
```

### GitHub API Failure
```
Status: Cannot access GitHub (network/auth issue)
Action: Inform user of the issue
Message: "Unable to access documentation. Please check:
  1. Internet connection
  2. GitHub MCP connector is configured
  3. Local copy can be installed for offline use"
```

### File Not Found (Both Modes)
```
Status: Documentation file not in index or doesn't exist
Action: Search alternative paths or suggest similar topics
Message: "Documentation file not found. Did you mean: [suggestions]"
```

---

## 📚 Index Files Usage

### docs-index.json
**Purpose**: Map all documentation files with metadata

**Usage in LOCAL mode**:
```
1. Search index for relevant file
2. Get relative path from index
3. Construct full path: localPath + relativePath
4. Read file with Read tool
```

**Usage in GITHUB mode**:
```
1. Search index for relevant file
2. Get relative path from index
3. Construct GitHub path: docsPath + relativePath
4. Read file with MCP GitHub connector
```

### node-docs-map.json
**Purpose**: Map node names to documentation files

**Example entry**:
```json
{
  "n8n-nodes-base.gmail": {
    "name": "Gmail",
    "type": "app-nodes",
    "path": "integrations/builtin/app-nodes/n8n-nodes-base.gmail/index.md"
  }
}
```

**Usage**: Same as docs-index but optimized for node lookups

---

## 🔄 Version Compatibility

### Local vs GitHub Version Differences

**Local**: Version depends on last `git pull`
**GitHub**: Always latest from `main` branch

**Handling differences:**
- Indicate which version/mode was used in response
- Suggest updating local copy if significantly outdated
- GitHub mode always has newest features documented

### Updating Local Copy

**Command**: "Update the local N8N documentation"

**Process**:
```
1. Run scripts/sync-docs.bat
2. Performs: git pull origin main
3. Updates last-update.json with timestamp
4. Optional: Rebuild index with build-index.js
```