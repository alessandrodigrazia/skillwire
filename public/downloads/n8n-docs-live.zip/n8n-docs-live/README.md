# N8N Official Documentation - Live Access Skill

This skill provides Claude with **hybrid access** to the complete N8N official documentation, ensuring accuracy, portability, and speed.

## 🎯 Purpose

This skill acts as the "source of truth" for the N8N ecosystem. It gives Claude the ability to answer questions based on the official documentation by:

1.  **Prioritizing a local copy** for maximum speed.
2.  **Falling back to a live online search** using Claude's native GitHub connector for maximum flexibility.

## 🔗 Part of the N8N Skills Ecosystem

This is one of three complementary skills that work together:

1.  **`n8n-ai-workflow-expert`**: The "Strategist" for patterns, best practices, and AI model selection.
2.  **`n8n-workflow-repository`**: The "Library" with 1495 real-world workflow JSON examples.
3.  **`n8n-docs-live` (THIS SKILL)**: The "Oracle" that provides the official documentation and technical specifications.

## 🚀 How It Works: Hybrid Access

This skill uses a "Local First, Live Cloud Fallback" strategy to ensure the best performance and portability.

### 1. Local First (Speed)
- The skill first checks for a local copy of the documentation at the path defined in `config/sync-config.json`.
- If found, it uses this local copy for lightning-fast searches and responses. This also enables offline usage.

### 2. Live Cloud Fallback (Flexibility)
- If the local copy is **not found** (e.g., you are on a different computer), the skill automatically switches to using Claude's native GitHub connector.
- It searches and reads files directly from the official `n8n-io/n8n-docs` repository online.
- This ensures the skill works on **any machine** without needing a local setup, always accessing the most up-to-date information.

This hybrid model means you get the best of both worlds without any manual intervention.

## 📊 What's Included

- **Configuration**: A simple `sync-config.json` to define the local path and GitHub repo.
- **Intelligent Indexes**: Pre-built JSON files (`docs-index.json`, `node-docs-map.json`) that allow Claude to quickly find relevant documents, whether they are local or online.
- **Quick Reference Library**: Summaries of the most important topics in the `/quick-ref/` directory for instant answers to common questions.
- **Maintenance Scripts**: A script (`sync-docs.bat`) to update your local copy of the documentation easily.

## 📖 How to Use

Simply ask Claude your n8n-related questions. The skill's hybrid logic is completely automatic.

**Example Questions:**
- "How do I use vector databases in N8N?"
- "Show me the documentation for the Code node."
- "Explain RAG implementation in N8N."
- "What are the latest features in the release notes?"

Claude will decide the best way to access the documentation (local or online) and use the indexes to find the precise information needed before giving you a comprehensive answer.

## 🔄 Maintenance

- **Online Mode**: Requires no maintenance. It's always live.
- **Local Mode**: To keep your local copy fresh, you can ask Claude:
  `"Update the local N8N documentation"`
  Claude will then run the `scripts/sync-docs.bat` script for you.

## ✅ Summary of Advantages

- **Portable**: Works on any PC, thanks to the GitHub connector fallback.
- **Efficient**: Uses a super-fast local copy when available.
- **Always Up-to-Date**: Can access the very latest documentation online.
- **Comprehensive**: Uses indexes to search over 1,200 documentation pages instantly.
- **Seamless**: You don't need to know or decide which method to use; the skill handles it automatically.