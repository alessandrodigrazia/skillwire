#!/usr/bin/env node
/**
 * Update last-update.json with current timestamp and git commit info
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const CONFIG_PATH = path.join(__dirname, '../config/last-update.json');
const REPO_PATH = '/path/to/your/n8n-docs-main';

try {
  // Get current git commit
  const currentCommit = execSync('git rev-parse HEAD', {
    cwd: REPO_PATH,
    encoding: 'utf-8'
  }).trim();

  // Get commit message
  const commitMessage = execSync('git log -1 --pretty=%B', {
    cwd: REPO_PATH,
    encoding: 'utf-8'
  }).trim();

  // Update config
  const config = {
    lastGitPull: new Date().toISOString(),
    lastIndexBuild: null,
    currentCommit: currentCommit,
    commitMessage: commitMessage,
    docsVersion: 'latest',
    notes: 'Documentation successfully updated from GitHub'
  };

  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));

  console.log('✓ Timestamp updated successfully');
  console.log(`✓ Current commit: ${currentCommit.substring(0, 8)}`);
  console.log(`✓ Last update: ${config.lastGitPull}`);

} catch (error) {
  console.error('Error updating timestamp:', error.message);
  process.exit(1);
}
