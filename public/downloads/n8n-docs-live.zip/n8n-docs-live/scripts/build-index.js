#!/usr/bin/env node
/**
 * Build searchable index from N8N documentation
 * Scans all markdown files and creates:
 * - docs-index.json: Full documentation index with metadata
 * - topics-map.json: Topic to file path mapping
 * - node-docs-map.json: Node name to documentation mapping
 * - search-index.json: Optimized search index
 */

const fs = require('fs');
const path = require('path');

const DOCS_PATH = '/path/to/your/n8n-docs-main/docs';
const INDEX_PATH = path.join(__dirname, '../index');

// Ensure index directory exists
if (!fs.existsSync(INDEX_PATH)) {
  fs.mkdirSync(INDEX_PATH, { recursive: true });
}

/**
 * Recursively find all markdown files
 */
function findMarkdownFiles(dir, fileList = []) {
  const files = fs.readdirSync(dir);

  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);

    if (stat.isDirectory()) {
      // Skip node_modules, .git, etc.
      if (!file.startsWith('.') && !file.startsWith('_')) {
        findMarkdownFiles(filePath, fileList);
      }
    } else if (file.endsWith('.md')) {
      fileList.push(filePath);
    }
  });

  return fileList;
}

/**
 * Extract frontmatter and content from markdown file
 */
function parseMarkdownFile(filePath) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const relativePath = path.relative(DOCS_PATH, filePath).replace(/\\/g, '/');

  // Extract frontmatter
  let frontmatter = {};
  let mainContent = content;

  if (content.startsWith('---')) {
    const endOfFrontmatter = content.indexOf('---', 3);
    if (endOfFrontmatter !== -1) {
      const frontmatterText = content.substring(3, endOfFrontmatter);
      mainContent = content.substring(endOfFrontmatter + 3).trim();

      // Parse YAML-like frontmatter
      frontmatterText.split('\n').forEach(line => {
        const match = line.match(/^([^:]+):\s*(.+)$/);
        if (match) {
          frontmatter[match[1].trim()] = match[2].trim().replace(/^["']|["']$/g, '');
        }
      });
    }
  }

  // Extract title (from frontmatter or first h1)
  let title = frontmatter.title || '';
  if (!title) {
    const h1Match = mainContent.match(/^#\s+(.+)$/m);
    if (h1Match) {
      title = h1Match[1];
    }
  }

  // Extract description
  const description = frontmatter.description || '';

  // Extract headings for navigation
  const headings = [];
  const headingMatches = mainContent.matchAll(/^(#{1,6})\s+(.+)$/gm);
  for (const match of headingMatches) {
    headings.push({
      level: match[1].length,
      text: match[2]
    });
  }

  // Get first 500 characters for preview
  const preview = mainContent
    .replace(/^#{1,6}\s+.+$/gm, '') // Remove headings
    .replace(/```[\s\S]*?```/g, '') // Remove code blocks
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // Remove links
    .replace(/[*_`]/g, '') // Remove formatting
    .trim()
    .substring(0, 500);

  return {
    path: relativePath,
    fullPath: filePath,
    title,
    description,
    headings,
    preview,
    wordCount: mainContent.split(/\s+/).length,
    category: getCategoryFromPath(relativePath),
    tags: extractTags(frontmatter, relativePath, title, mainContent)
  };
}

/**
 * Determine category from file path
 */
function getCategoryFromPath(relativePath) {
  const parts = relativePath.split('/');
  if (parts.length > 1) {
    return parts[0];
  }
  return 'root';
}

/**
 * Extract relevant tags for search
 */
function extractTags(frontmatter, relativePath, title, content) {
  const tags = new Set();

  // Add category
  const category = getCategoryFromPath(relativePath);
  tags.add(category);

  // Add path segments
  relativePath.split('/').forEach(segment => {
    if (segment !== 'index.md') {
      tags.add(segment.replace(/\.md$/, '').replace(/-/g, ' '));
    }
  });

  // Add title words
  if (title) {
    title.toLowerCase().split(/\s+/).forEach(word => {
      if (word.length > 3) tags.add(word);
    });
  }

  // Add common keywords from content
  const keywords = [
    'node', 'workflow', 'ai', 'langchain', 'agent', 'chain',
    'integration', 'code', 'expression', 'function', 'api',
    'credential', 'authentication', 'trigger', 'webhook'
  ];

  keywords.forEach(keyword => {
    if (content.toLowerCase().includes(keyword)) {
      tags.add(keyword);
    }
  });

  return Array.from(tags);
}

/**
 * Build node documentation mapping
 */
function buildNodeDocsMap(docsIndex) {
  const nodeMap = {};

  docsIndex.forEach(doc => {
    // Check if this is a node documentation file
    const nodeMatch = doc.path.match(/integrations\/builtin\/(app-nodes|core-nodes|cluster-nodes)\/([^/]+)/);

    if (nodeMatch) {
      const nodeType = nodeMatch[1];
      const nodeName = nodeMatch[2];

      if (!nodeMap[nodeName]) {
        nodeMap[nodeName] = {
          name: nodeName,
          type: nodeType,
          title: doc.title,
          path: doc.path,
          description: doc.description
        };
      }
    }

    // Also map by node display name
    if (doc.title && doc.category === 'integrations') {
      nodeMap[doc.title.toLowerCase().replace(/\s+/g, '-')] = {
        name: doc.title,
        path: doc.path,
        description: doc.description
      };
    }
  });

  return nodeMap;
}

/**
 * Build topic mapping
 */
function buildTopicsMap(docsIndex) {
  const topicsMap = {};

  // Define topic categories
  const topics = {
    'ai-agents': [],
    'langchain': [],
    'vector-databases': [],
    'rag': [],
    'code-expressions': [],
    'builtin-functions': [],
    'data-transformation': [],
    'workflows': [],
    'integrations': [],
    'credentials': [],
    'api': [],
    'error-handling': [],
    'subworkflows': [],
    'webhooks': [],
    'triggers': []
  };

  docsIndex.forEach(doc => {
    doc.tags.forEach(tag => {
      const normalizedTag = tag.toLowerCase().replace(/\s+/g, '-');
      if (topics.hasOwnProperty(normalizedTag)) {
        topics[normalizedTag].push({
          title: doc.title,
          path: doc.path,
          description: doc.description
        });
      }
    });
  });

  return topics;
}

/**
 * Build search index
 */
function buildSearchIndex(docsIndex) {
  return docsIndex.map(doc => ({
    path: doc.path,
    title: doc.title,
    description: doc.description,
    category: doc.category,
    tags: doc.tags,
    preview: doc.preview.substring(0, 200)
  }));
}

/**
 * Main execution
 */
function main() {
  console.log('🔨 Building N8N Documentation Index...\n');

  // Find all markdown files
  console.log('📁 Scanning for markdown files...');
  const markdownFiles = findMarkdownFiles(DOCS_PATH);
  console.log(`   Found ${markdownFiles.length} files\n`);

  // Parse all files
  console.log('📖 Parsing markdown files...');
  const docsIndex = markdownFiles.map((file, index) => {
    if (index % 50 === 0) {
      process.stdout.write(`   Progress: ${index}/${markdownFiles.length}\r`);
    }
    return parseMarkdownFile(file);
  });
  console.log(`   Parsed ${docsIndex.length} files\n`);

  // Build node documentation map
  console.log('🔌 Building node documentation map...');
  const nodeDocsMap = buildNodeDocsMap(docsIndex);
  console.log(`   Mapped ${Object.keys(nodeDocsMap).length} nodes\n`);

  // Build topics map
  console.log('🏷️  Building topics map...');
  const topicsMap = buildTopicsMap(docsIndex);
  const topicCount = Object.values(topicsMap).reduce((sum, docs) => sum + docs.length, 0);
  console.log(`   Created ${Object.keys(topicsMap).length} topic categories with ${topicCount} entries\n`);

  // Build search index
  console.log('🔍 Building search index...');
  const searchIndex = buildSearchIndex(docsIndex);
  console.log(`   Indexed ${searchIndex.length} documents\n`);

  // Write index files
  console.log('💾 Writing index files...');

  fs.writeFileSync(
    path.join(INDEX_PATH, 'docs-index.json'),
    JSON.stringify({
      generated: new Date().toISOString(),
      totalDocs: docsIndex.length,
      docs: docsIndex
    }, null, 2)
  );
  console.log('   ✓ docs-index.json');

  fs.writeFileSync(
    path.join(INDEX_PATH, 'node-docs-map.json'),
    JSON.stringify(nodeDocsMap, null, 2)
  );
  console.log('   ✓ node-docs-map.json');

  fs.writeFileSync(
    path.join(INDEX_PATH, 'topics-map.json'),
    JSON.stringify(topicsMap, null, 2)
  );
  console.log('   ✓ topics-map.json');

  fs.writeFileSync(
    path.join(INDEX_PATH, 'search-index.json'),
    JSON.stringify({
      generated: new Date().toISOString(),
      totalDocs: searchIndex.length,
      index: searchIndex
    }, null, 2)
  );
  console.log('   ✓ search-index.json\n');

  // Update last-update.json
  const configPath = path.join(__dirname, '../config/last-update.json');
  const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  config.lastIndexBuild = new Date().toISOString();
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

  // Print statistics
  console.log('📊 Index Statistics:');
  console.log(`   Total documents: ${docsIndex.length}`);
  console.log(`   Categories: ${new Set(docsIndex.map(d => d.category)).size}`);
  console.log(`   Node documentation: ${Object.keys(nodeDocsMap).length}`);
  console.log(`   Topic categories: ${Object.keys(topicsMap).length}`);
  console.log(`   Total words: ${docsIndex.reduce((sum, d) => sum + d.wordCount, 0).toLocaleString()}`);
  console.log('\n✅ Index build complete!');
}

// Run if called directly
if (require.main === module) {
  main();
}

module.exports = { main };
