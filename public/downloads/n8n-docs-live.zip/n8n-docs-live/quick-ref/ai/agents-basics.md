# AI Agents in N8N - Quick Reference

**Source:** Official N8N Documentation - `advanced-ai/examples/understand-agents.md`

## What is an AI Agent?

An **agent** is like a chain that knows how to make decisions. While a chain follows a predetermined sequence of calls, an agent uses a language model to determine which actions to take dynamically.

## Key Characteristics

- **Decision-makers**: Agents act as autonomous decision-makers
- **Tool interaction**: Can interact with other agents and tools
- **Adaptive**: Adapt to specific queries and prompts
- **Multi-execution**: Run multiple times during workflow execution

## How Agents Work

When you send a query to an agent:
1. Agent analyzes the query
2. Chooses the best tools to use
3. Executes the tools
4. Evaluates responses
5. Provides final answer

## Agent Execution Flow

Example workflow execution:
1. Initial setup
2. Tool call run
3. Evaluation run
4. Response to user

An agent may run multiple times in a single workflow execution.

## Agent Node in N8N

N8N provides **one Agent node** that can act as different agent types depending on settings.

**Node:** `@n8n/n8n-nodes-langchain.agent`

**Available Agent Types:**
- Conversational Agent
- Tools Agent
- OpenAI Functions Agent
- ReAct Agent
- And more (see official docs)

## When to Use Agents

✅ **Use agents when:**
- Need dynamic decision-making
- Complex multi-step reasoning required
- Tool selection based on context
- Adaptive behavior needed

❌ **Don't use agents when:**
- Simple, predetermined flow is sufficient
- Single AI call is enough
- Cost optimization is critical (agents are more expensive)

## Integration with N8N Workflows

Agents work with:
- **Tools**: HTTP Request Tool, Workflow Tool, Calculator, etc.
- **Memory**: Store conversation context
- **Chains**: Can be combined with chains
- **Vector Stores**: For RAG implementations

## Best Practices

1. **Clear prompts**: Define agent behavior clearly
2. **Tool selection**: Provide only necessary tools
3. **Max iterations**: Set limits to prevent infinite loops
4. **Error handling**: Implement fallbacks
5. **Testing**: Test with various query types

## Common Use Cases

- Customer support chatbots
- Research assistants
- Data analysis workflows
- Multi-step automation with decision points
- Dynamic API interactions

## Related Concepts

- **Chains**: Predetermined sequence of AI calls
- **Tools**: Functions agents can use
- **Memory**: Conversation history storage
- **Prompts**: Instructions for agent behavior

## Official Documentation

For complete details, see:
- `/advanced-ai/examples/understand-agents.md`
- `/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.agent/`

**Full path:** `/path/to/your/n8n-docs-main/docs\advanced-ai\examples\understand-agents.md`
