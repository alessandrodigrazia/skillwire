@echo off
REM N8N Documentation Sync Script
REM Updates the local N8N documentation repository from GitHub

echo ========================================
echo N8N Documentation Sync
echo ========================================
echo.

set REPO_PATH=/path/to/your/n8n-docs-main

echo Checking repository path...
if not exist "%REPO_PATH%" (
    echo ERROR: Repository not found at %REPO_PATH%
    echo Please clone the repository first:
    echo git clone https://github.com/n8n-io/n8n-docs.git
    pause
    exit /b 1
)

echo Repository found: %REPO_PATH%
echo.

cd /d "%REPO_PATH%"

echo Current branch:
git branch --show-current
echo.

echo Fetching updates from GitHub...
git fetch origin
echo.

echo Current local commit:
git rev-parse HEAD
echo.

echo Latest remote commit:
git rev-parse origin/main
echo.

echo Pulling latest changes...
git pull origin main

if errorlevel 1 (
    echo.
    echo ERROR: Git pull failed!
    echo Please check your internet connection and Git configuration.
    pause
    exit /b 1
)

echo.
echo ========================================
echo Documentation updated successfully!
echo ========================================
echo.

echo Updated commit:
git log -1 --oneline
echo.

echo Updating last-update.json...
cd /d "/path/to/your/n8n-docs-live"
node scripts\update-timestamp.js

echo.
echo Done! Documentation is now up to date.
echo.
pause
