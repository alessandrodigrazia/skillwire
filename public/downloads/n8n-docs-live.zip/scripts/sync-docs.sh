#!/bin/bash
# N8N Documentation Sync Script
# Updates the local N8N documentation repository from GitHub
# Usage: ./sync-docs.sh [path-to-n8n-docs-repo]

set -e

echo "========================================"
echo "N8N Documentation Sync"
echo "========================================"
echo

REPO_PATH="${1:-/path/to/your/n8n-docs-main}"
SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "Checking repository path..."
if [ ! -d "$REPO_PATH" ]; then
    echo "ERROR: Repository not found at $REPO_PATH"
    echo "Please clone the repository first:"
    echo "  git clone https://github.com/n8n-io/n8n-docs.git"
    echo ""
    echo "Then run:"
    echo "  ./sync-docs.sh /path/to/n8n-docs"
    exit 1
fi

echo "Repository found: $REPO_PATH"
echo

cd "$REPO_PATH"

echo "Current branch:"
git branch --show-current
echo

echo "Fetching updates from GitHub..."
git fetch origin
echo

echo "Current local commit:"
git rev-parse HEAD
echo

echo "Latest remote commit:"
git rev-parse origin/main
echo

echo "Pulling latest changes..."
git pull origin main

echo
echo "========================================"
echo "Documentation updated successfully!"
echo "========================================"
echo

echo "Updated commit:"
git log -1 --oneline
echo

echo "Updating last-update.json..."
cd "$SKILL_DIR"
node scripts/update-timestamp.js

echo
echo "Done! Documentation is now up to date."
