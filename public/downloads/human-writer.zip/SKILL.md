---
name: human-writer
description: This skill should be used when the user provides AI-generated text (in Italian or English) for humanization, optimization, or AI-detection analysis. The skill detects common AI writing patterns, assigns severity levels, explains why they are AI tells, and suggests human-like alternatives with before/after examples.
---

# Human-Writer Skill

## Purpose

Transform AI-generated text into natural, human-like writing by detecting and correcting the most common patterns and errors that Large Language Models make. This skill uses a research-based database of AI writing tells to provide intelligent, context-aware suggestions.

**Core Capabilities:**
- Detect AI writing patterns in Italian (primary) and English
- Assign severity levels (CRITICAL, HIGH, MEDIUM, STYLE)
- Explain WHY each pattern is an AI tell
- Suggest specific human-like alternatives
- Provide before/after comparisons
- Consider cultural context (IT vs USA tone)

---

## When to Use This Skill

Activate this skill when the user:
- Provides text for "humanization" or AI-detection removal
- Asks to "optimize" or "improve" AI-generated content
- Wants to check if text sounds "too AI"
- Requests analysis of writing patterns
- Needs alternatives to overused AI phrases
- Wants culturally-appropriate tone (Italian vs English contexts)

---

## Analysis Process

### Step 1: Language Detection
Identify the primary language (Italian, English, or mixed) to apply the correct pattern database.

### Step 2: CRITICAL Tier Scan (🔴 Severity: High)
Detect absolute ban patterns that immediately signal AI authorship:

**Italian:**
- Opening formulas: "In un mondo in cui...", "Nell'era di/della...", "Nel vasto e complesso scenario..."
- Signature phrases: "È interessante notare che", "Vale la pena menzionare"
- Typography errors: Capitals after colons, Title Case in Italian headings
- Concluding formulas: "In conclusione", "Per concludere", "In sintesi"

**English:**
- Citation artifacts: `[oai_citation:0]`, `utm_source=openai`, `[web:1]`
- Opening patterns: "Have you ever wondered...", "In today's rapidly evolving..."
- Metadata tells: ChatGPT URL references, attached_file markers

### Step 3: HIGH Tier Scan (🟠 Severity: Context-Aware)
Detect overused transitions, buzzwords, and structural patterns:

**Italian:**
- Overused connectors: "Inoltre" (5-8x more frequent), "Tuttavia", "Infatti", "Nonostante"
- Buzzwords: "Innovativo" (10x in business), "Rivoluzionario", "Cruciale", "Fondamentale"
- Structural patterns: "Non X ma Y" antithesis, triple lists (always 3 elements), gerund chains

**English:**
- Transitions: "Moreover", "Furthermore", "It's worth noting", "That being said"
- Buzzwords: "Revolutionary", "Seamless", "Cutting-edge", "Game-changing", "Robust"
- Structural patterns: "IT'S NOT X, IT'S Y", three-item lists at sentence end

### Step 4: MEDIUM/STYLE Tier (🟡 Context-Dependent)
Check register-appropriate issues:
- Formal academic terms overused in casual contexts
- Sentence length uniformity (AI tends to 15-25 words consistently)
- Lack of VARIATIO principle (Italian: repeating words instead of using synonyms)
- Cultural tone mismatch (USA motivational style in Italian professional text)
- Excessive formatting (bold, emoji, bullet overuse)

---

## Output Format

For each text analyzed, provide:

### 1. **Summary Assessment**
```
Language: [Italian/English/Mixed]
AI Probability: [Low/Medium/High/Very High]
Critical Issues: [number]
High-Priority Issues: [number]
Style Suggestions: [number]
```

### 2. **Detailed Findings by Severity**

**🔴 CRITICAL Issues** (must fix):
- Pattern detected: [exact phrase/structure]
- Why it's an AI tell: [explanation with frequency data]
- Alternative: [specific human-like replacement]
- Example: `Before → After`

**🟠 HIGH Priority** (strongly recommended):
- [Same structure as above]

**🟡 MEDIUM/STYLE** (context-dependent):
- [Same structure as above]

### 3. **Annotated Original Text**
Show the original text with inline markers:
- 🔴 for CRITICAL issues
- 🟠 for HIGH issues
- 🟡 for MEDIUM issues

### 4. **Optimized Version**
Provide a complete rewrite that:
- Eliminates all CRITICAL and HIGH issues
- Applies MEDIUM suggestions where contextually appropriate
- Maintains the original meaning and key information
- Sounds natural and human-written
- Respects cultural tone (Italian vs English expectations)

### 5. **Educational Notes**
Brief explanation of:
- Most impactful changes made
- Why certain patterns are AI signatures
- Cultural/linguistic principles applied (e.g., Italian VARIATIO)

---

## Quick Reference: Top AI Tells

### 🇮🇹 Italian - TIER BAN (Never Use)

| Category | Terms/Patterns | AI Frequency |
|----------|----------------|--------------|
| **Connectors** | Inoltre, Tuttavia, Nonostante, Infatti | 5-8x more |
| **Buzzwords** | Innovativo, Rivoluzionario, Cruciale, Fondamentale | 10x in business |
| **Openings** | "In un mondo in cui...", "Nell'era di/della..." | 80%+ AI articles |
| **Signatures** | "È interessante notare che", "Vale la pena menzionare" | ChatGPT signature |
| **Conclusions** | "In conclusione", "Per concludere", "In sintesi" | 80%+ AI articles |
| **Typography** | Capitals after colons, Title Case headings | 85% detection |
| **Patterns** | "Non X ma Y" antithesis, Always 3-item lists | 60%+ persuasive |

**Top 20 Overused Terms (Context-Dependent):**
Ottimizzazione, Integrazione, Massimizzare, Agevolare, Implementazione, Contestualizzare, Problematica, Optare, Sostanzialmente, Significativo, Rilevante, Considerevole, Notevole, Scenario, Contesto, Approccio, Strategia, Soluzione, Potenziale, Tendenza

### 🇬🇧 English - TIER BAN (Never Use)

| Category | Terms/Patterns | Severity |
|----------|----------------|----------|
| **Transitions** | Moreover, Furthermore, Certainly, "It's worth noting" | CRITICAL |
| **Buzzwords** | Revolutionary, Cutting-edge, Seamless, Game-changing | HIGH |
| **Action Verbs** | Navigate, Delve into, Underscore, Illuminate, Bolster | HIGH |
| **Openings** | "Have you ever wondered...", "In today's rapidly..." | CRITICAL |
| **Patterns** | "IT'S NOT X, IT'S Y", Three-item lists, "fast, efficient, secure" | CRITICAL |
| **Metadata** | [oai_citation], utm_source=openai, [web:1] | CRITICAL |
| **Formatting** | Excessive em dashes (—), emoji overuse, unhinged bold | HIGH |

---

## Context-Aware Intelligence

### Register Adjustment
- **Academic/Technical**: Allow moderate use of formal terms (but still reduce AI transitions)
- **Business/Professional**: Ban motivational tone in Italian, reduce buzzwords everywhere
- **Casual/Creative**: Eliminate all formal academic overload, prioritize conversational flow

### Cultural Sensitivity
- **Italian Professional**: Formal but warm, relationship-first, avoid USA motivational imperatives
- **Italian Web**: Apply VARIATIO principle (never repeat, use synonyms/periphrases)
- **English Business**: Brief = professional, but avoid clinical ChatGPT tone
- **English Creative**: Vary sentence length dramatically, embrace imperfection

### Model Recognition
- **ChatGPT signatures**: Clinical tone, em dash without spaces, immediate lists, "It's worth noting"
- **Claude patterns**: (Generally more human, but check for excessive politeness in Italian)
- **Gemini patterns**: Overly casual in technical contexts, prefers simple terms excessively

---

## Reference Files

For comprehensive databases and detailed guidance, consult:

- **`references/italian-errors-database.md`**: Complete Italian AI patterns (51+ ban terms, typography, VARIATIO principle)
- **`references/english-errors-database.md`**: Complete English AI patterns (metadata tells, formatting, model differences)
- **`references/alternatives-guide.md`**: Specific human-like alternatives for every banned term with examples
- **`references/cultural-context.md`**: IT vs USA tone, professional etiquette, false friends
- **`references/detection-framework.md`**: Severity logic, context-aware rules, false positive handling

---

## Important Principles

### 1. Context Over Rules
Not all "AI patterns" are wrong in every context. Academic papers can use "tuttavia"; technical docs can say "implementation". Apply severity levels intelligently.

### 2. Explain, Don't Just Flag
Always explain WHY a pattern is an AI tell (frequency data, model signature, cultural mismatch) so the user learns.

### 3. Cultural Awareness
Italian professional writing differs from USA expectations. A phrase that sounds normal in English business can sound cold or inappropriate in Italian.

### 4. VARIATIO for Italian
Italian style principle: never repeat the same word. AI repeats due to SEO English bias. Use synonyms, periphrases, pronouns.

### 5. Preserve Meaning
Humanization should never change the factual content or core message. Only improve naturalness.

---

## Example Workflow

**User provides text:**
> "Nell'era digitale, è interessante notare che le aziende devono ottimizzare le loro strategie. Inoltre, l'innovazione è cruciale. In conclusione, il futuro è promettente."

**Analysis output:**

🔴 **CRITICAL Issues (3):**
1. "Nell'era digitale" - Opening formula (80%+ AI articles)
   - Alternative: Start directly with topic: "Le aziende digitali devono..."
2. "È interessante notare che" - ChatGPT signature phrase
   - Alternative: Remove entirely or use "In particolare" if transition needed
3. "In conclusione" - Generic AI closing (80%+ AI articles)
   - Alternative: Rephrase as natural conclusion without formula: "Il futuro offre..."

🟠 **HIGH Issues (4):**
4. "ottimizzare" - Overused formal term (context: could use "migliorare", "affinare")
5. "Inoltre" - 5-8x more frequent in AI
   - Alternative: "Allo stesso tempo", "Parallelamente", or restructure sentence
6. "innovazione è cruciale" - Double buzzword (innovazione 10x, cruciale top-3)
   - Alternative: "serve innovazione costante" or "rinnovamento continuo"
7. Word repetition - "è" used 3 times (violates VARIATIO)

🟡 **STYLE:**
8. Sentence uniformity - All sentences 8-12 words (AI pattern)
9. Generic optimism - "futuro promettente" lacks specificity

**Optimized version:**
> "Le aziende hanno urgente bisogno di affinare le proprie strategie digitali. Parallelamente, la capacità di rinnovarsi continua a fare la differenza. Il futuro offre opportunità a chi saprà adattarsi rapidamente."

**Changes explained:**
- Removed AI opening formula, started with substance
- Eliminated ChatGPT signature phrase
- Replaced buzzwords with more specific, varied terms
- Applied VARIATIO: varied verbs and nouns
- Removed generic conclusion formula
- Varied sentence length (9, 11, 12 words → more natural rhythm)

---

## Usage Tips

1. **Always process the full text** - AI patterns compound across paragraphs
2. **Consider the target audience** - B2B Italian professionals need different tone than tech blogs
3. **Check typography carefully** - Capitals after colons are 85% detection rate in Italian
4. **Look for triple structures** - If you see 3 items in a list repeatedly, flag it
5. **Cultural red flag**: USA motivational tone ("Supera i tuoi limiti!") in Italian professional contexts
6. **Model detection**: Multiple "moreover" = ChatGPT; excessive casualness = Gemini

---

**When in doubt, consult the reference files for comprehensive pattern databases and alternatives.**
