# Alternatives Guide - Human-Like Replacements

Practical guide providing specific human-like alternatives for AI-banned terms and patterns. Organized by language and category with before/after examples.

---

## 🇮🇹 ITALIAN ALTERNATIVES

### Connectors & Transitions (Connettivi)

#### "Inoltre" (Moreover/Furthermore) - 5-8x AI frequency

**Human Alternatives:**
- **Allo stesso tempo** (At the same time)
- **Parallelamente** (In parallel)
- **In aggiunta** (In addition - but use sparingly)
- **Anche** (Also - simple and natural)
- **Per di più** (What's more - informal)
- **A questo si aggiunge** (To this is added)

**Better Strategy**: Restructure sentence to avoid explicit connector.

**Examples:**

❌ **AI**:
"Le aziende devono innovare. Inoltre, devono formare i dipendenti."

✅ **Human - Alternative 1 (connector replacement)**:
"Le aziende devono innovare. Allo stesso tempo, serve formare i dipendenti."

✅ **Human - Alternative 2 (restructure, best)**:
"Le aziende devono innovare e formare i dipendenti. Senza formazione, ogni investimento tecnologico resta inefficace."

---

#### "Tuttavia" (However) - 4-6x AI frequency

**Human Alternatives:**
- **Ma** (But - simple, natural)
- **Però** (But/However - conversational)
- **Eppure** (Yet - adds nuance)
- **Ciò nonostante** (Nevertheless - formal, use rarely)
- **D'altra parte** (On the other hand - use sparingly)

**Best Strategy**: Use "ma" or restructure with contrast implied, not explicit.

**Examples:**

❌ **AI**:
"La tecnologia è utile. Tuttavia, richiede investimenti."

✅ **Human - Simple**:
"La tecnologia è utile, ma richiede investimenti."

✅ **Human - Restructured**:
"La tecnologia porta vantaggi evidenti. Il problema? Gli investimenti necessari sono spesso sottovalutati."

---

#### "Infatti" (In fact) - 4-6x AI frequency

**Human Alternatives:**
- Remove entirely (often unnecessary)
- **In effetti** (Actually - less formal)
- **Di fatto** (In fact - more natural)
- Restructure to make point without emphasis marker

**Examples:**

❌ **AI**:
"I dati confermano il trend. Infatti, il 70% delle aziende ha investito in AI."

✅ **Human - Remove**:
"I dati confermano il trend: il 70% delle aziende ha investito in AI."

✅ **Human - Replace**:
"I dati lo dimostrano: il 70% delle aziende ha già investito in AI."

---

#### "In conclusione / Per concludere" - 80%+ AI articles

**Human Alternatives:**
- **Remove explicit conclusion marker** (best)
- **Quindi** (So - natural conclusion)
- **In sintesi** (In summary - use rarely)
- **Il punto è** (The point is - conversational)
- Creative closing: "Guardando al futuro...", "A conti fatti...", "Insomma..."

**Examples:**

❌ **AI**:
"In conclusione, le aziende devono adattarsi. Il futuro è digitale."

✅ **Human - Remove marker**:
"Le aziende devono adattarsi. Chi non investe in digitale rischia di restare indietro."

✅ **Human - Creative close**:
"A conti fatti, la scelta è chiara: adattarsi o perdere terreno."

---

#### "È interessante notare che" - ChatGPT signature (CRITICAL)

**Human Alternatives:**
- **Remove entirely** (best - just state the fact)
- **In particolare** (In particular)
- **Da notare** (To note - less common)
- **Un dato significativo** (A significant fact)

**Examples:**

❌ **AI (CRITICAL ERROR)**:
"È interessante notare che il 60% delle startup fallisce nei primi 3 anni."

✅ **Human - Direct statement**:
"Il 60% delle startup fallisce nei primi 3 anni."

✅ **Human - With emphasis**:
"Un dato che sorprende: il 60% delle startup non supera i 3 anni."

---

#### "Vale la pena menzionare" - ChatGPT signature (CRITICAL)

**Human Alternative:**
- **Remove entirely**
- **Importante** (Important)
- **Da segnalare** (Worth reporting)

**Examples:**

❌ **AI (CRITICAL ERROR)**:
"Vale la pena menzionare che la soluzione è scalabile."

✅ **Human**:
"La soluzione è scalabile."

✅ **Human - With emphasis**:
"Aspetto chiave: la soluzione scala senza problemi."

---

### Buzzwords (Aggettivi Inflazionati)

#### "Innovativo" - 10x AI frequency in business

**Human Alternatives:**
- **Remove and be specific** (what makes it innovative?)
- **Nuovo** (New - simple)
- **Originale** (Original)
- **Diverso dal solito** (Different from usual)
- **Inedito** (Unprecedented)

**Examples:**

❌ **AI**:
"La nostra soluzione innovativa rivoluziona il mercato."

✅ **Human - Specific**:
"La nostra soluzione riduce i tempi di produzione del 40% grazie a un algoritmo predittivo."

✅ **Human - Remove buzzword**:
"La nostra soluzione si distingue per una caratteristica inedita: anticipa i guasti prima che si verifichino."

---

#### "Cruciale" - Top 3 AI overused

**Human Alternatives:**
- **Importante** (Important)
- **Essenziale** (Essential - but don't overuse)
- **Fondamentale** (Fundamental - but also overused, use rarely)
- **Determinante** (Decisive)
- **Chiave** (Key)
- **Remove and show why it matters**

**Examples:**

❌ **AI**:
"La formazione è cruciale per il successo."

✅ **Human - Replace**:
"La formazione è determinante per il successo."

✅ **Human - Show, don't tell**:
"Senza formazione, l'investimento tecnologico fallisce. I nostri dati lo confermano: il 70% dei progetti senza training non raggiunge gli obiettivi."

---

#### "Rivoluzionario" - 8-9x AI frequency

**Human Alternatives:**
- **Remove and be specific**
- **Cambia le regole** (Changes the rules)
- **Radicalmente diverso** (Radically different)
- **Senza precedenti** (Unprecedented)

**Examples:**

❌ **AI**:
"Questo approccio rivoluzionario trasforma il settore."

✅ **Human**:
"Questo approccio cambia le regole: per la prima volta, le PMI possono accedere a tecnologie finora riservate alle grandi aziende."

---

### Formal Academic Terms (Termini Formali)

#### "Ottimizzazione / Ottimizzare"

**Human Alternatives (Context-Dependent):**
- **Miglioramento / Migliorare** (Improvement / Improve)
- **Affinare** (Refine)
- **Perfezionare** (Perfect)
- **Rendere più efficiente** (Make more efficient)

**Examples:**

❌ **AI (casual context)**:
"Ottimizziamo il tuo workflow aziendale."

✅ **Human**:
"Miglioriamo il tuo flusso di lavoro."

✅ **Technical context (OK to use)**:
"Ottimizzazione degli algoritmi di machine learning per ridurre il tempo di training del 30%."

---

#### "Implementazione / Implementare"

**Human Alternatives:**
- **Realizzazione / Realizzare** (Realization / Realize)
- **Attuazione / Attuare** (Implementation / Implement - slightly less technical)
- **Applicazione / Applicare** (Application / Apply)
- **Mettere in pratica** (Put into practice)

**Examples:**

❌ **AI (business article)**:
"L'implementazione della strategia richiede tempo."

✅ **Human**:
"Mettere in pratica la strategia richiede tempo."

---

#### "Strategia" - Overused

**Human Alternatives:**
- **Piano** (Plan)
- **Approccio** (Approach - but also overused)
- **Metodo** (Method)
- **Via** (Way/Path)
- Be specific: "piano marketing", "metodo operativo"

---

#### "Soluzione" - Everything is a "solution"

**Human Alternatives:**
- **Risposta** (Answer)
- **Strumento** (Tool)
- **Metodo** (Method)
- **Sistema** (System)
- **Prodotto** (Product - if it's a product)

**Examples:**

❌ **AI**:
"La nostra soluzione innovativa risolve il problema."

✅ **Human**:
"Il nostro strumento risolve il problema."

✅ **Human - Specific**:
"Il nostro software automatizza l'inventario, eliminando errori manuali."

---

### Opening Formulas - How to Start Instead

#### Replace "In un mondo in cui..." / "Nell'era di..."

**Human Alternatives:**

**1. Start with Data/Fact:**
✅ "Il 73% delle aziende italiane ha investito in digitale nel 2024."

**2. Start with Problem:**
✅ "Le PMI italiane perdono 12 ore a settimana per processi manuali."

**3. Start with Question (but not generic hook):**
✅ "Quanto costa davvero un errore di inventario? Per una media azienda manifatturiera, circa 45.000 euro l'anno."

**4. Start with Story/Example:**
✅ "Marco, CEO di una PMI bolognese, ha scoperto che il 30% del tempo del suo team andava perso in attività ripetitive."

**5. Start with Direct Topic:**
✅ "L'automazione dei processi aziendali non è più un lusso per grandi aziende."

**Examples - Before/After:**

❌ **AI**:
"In un mondo sempre più digitale, le aziende devono innovare per restare competitive. Nell'era della trasformazione digitale, l'innovazione è cruciale."

✅ **Human**:
"Le aziende italiane hanno investito 4,2 miliardi in digitale nel 2024. Eppure, il 60% non ha ancora un piano chiaro per l'AI. Perché questo gap?"

---

### Antithesis Pattern - How to Restructure

#### Replace "Non si tratta di X, ma di Y"

**Human Alternatives:**

**1. Remove antithesis, state positively:**

❌ AI: "Non si tratta di tecnologia, ma di persone."

✅ Human: "La tecnologia funziona quando chi la usa è formato adeguatamente."

**2. Use contrast without formula:**

❌ AI: "Non basta investire. Serve una strategia."

✅ Human: "Investire senza strategia è come comprare un'auto senza patente. Lo strumento c'è, ma nessuno sa guidarlo."

**3. Replace with data/example:**

❌ AI: "Non è solo efficienza. È trasformazione."

✅ Human: "L'efficienza è il risultato visibile. Dietro c'è un cambio culturale: da 'abbiamo sempre fatto così' a 'come possiamo fare meglio?'"

---

## Variatio Techniques (Italian Principle)

**Principle**: Never repeat the same word in close proximity (within 100-150 words). Use synonyms, periphrases, pronouns.

### Common Words - Variation Examples

#### "Azienda" (Company)

**Variations:**
1. Azienda
2. Impresa
3. Società
4. Realtà aziendale
5. Organizzazione
6. Gruppo (if applicable)
7. L'azienda → la società → l'impresa → use pronoun ("essa", "questa")

**Example:**

❌ **AI (repetition)**:
"L'azienda deve innovare. L'azienda che non innova rischia di perdere competitività. Ogni azienda deve quindi investire in formazione."

✅ **Human (variatio)**:
"L'azienda deve innovare. Chi non lo fa rischia di perdere competitività. Ogni impresa deve quindi investire in formazione."

---

#### "Cliente" (Customer)

**Variations:**
1. Cliente
2. Consumatore
3. Utente
4. Acquirente
5. Destinatario del servizio
6. Pubblico (if collective)

---

#### "Tecnologia" (Technology)

**Variations:**
1. Tecnologia
2. Strumenti digitali
3. Soluzioni tech
4. Sistemi tecnologici
5. Innovazione tecnologica
6. Risorse digitali

---

#### "Problema" (Problem)

**Variations:**
1. Problema
2. Criticità
3. Questione
4. Sfida
5. Ostacolo
6. Difficoltà
7. Nodo (knot/issue - literary)

**Example:**

❌ **AI**:
"Il problema principale è la mancanza di formazione. Questo problema affligge il 60% delle PMI. Per risolvere il problema serve investire."

✅ **Human**:
"Il problema principale è la mancanza di formazione. Questa criticità affligge il 60% delle PMI. Per risolverla serve investire."

---

#### Place Names (Geography)

**Special Italian Practice**: Vary using historical/cultural references.

**Milano:**
1. Milano
2. Il capoluogo lombardo
3. La metropoli milanese
4. La città meneghina
5. Use pronoun

**Roma:**
1. Roma
2. La capitale
3. La città eterna
4. Il capoluogo laziale

**Example:**

❌ **AI**:
"Milano è il centro economico italiano. Milano attrae investimenti. Milano offre opportunità."

✅ **Human**:
"Milano è il centro economico italiano. Il capoluogo lombardo attrae investimenti da tutta Europa. La metropoli offre opportunità uniche nel panorama nazionale."

---

## 🇬🇧 ENGLISH ALTERNATIVES

### Transitions & Connectors

#### "Moreover" / "Furthermore" - 8-10x AI frequency (CRITICAL)

**Human Alternatives:**
- **Also** (simple, natural)
- **In addition** (formal but less AI-marked)
- **Beyond that** (conversational)
- **What's more** (informal)
- **On top of that** (casual)
- **Restructure to avoid explicit connector** (best)

**Examples:**

❌ **AI**:
"The platform is efficient. Moreover, it's scalable. Furthermore, it's cost-effective."

✅ **Human - Replace**:
"The platform is efficient. It's also scalable and cost-effective."

✅ **Human - Restructure (best)**:
"The platform combines efficiency with scalability—and it doesn't break the budget."

---

#### "It's worth noting" / "It's important to note" - ChatGPT signature (CRITICAL)

**Human Alternatives:**
- **Remove entirely** (best)
- **Notably** (but still overused)
- **Importantly** (use sparingly)
- **One key point** (conversational)

**Examples:**

❌ **AI (CRITICAL ERROR)**:
"It's worth noting that 60% of startups fail within three years."

✅ **Human**:
"60% of startups fail within three years."

✅ **Human - With emphasis**:
"Here's the reality: 60% of startups don't make it past year three."

---

#### "That being said" - 5-6x AI frequency

**Human Alternatives:**
- **That said** (more concise)
- **Still** (simple)
- **Even so** (natural)
- **But** (simplest)
- Restructure with implied contrast

**Examples:**

❌ **AI**:
"The technology is promising. That being said, it requires significant investment."

✅ **Human**:
"The technology is promising. But it requires significant investment."

✅ **Human - Restructure**:
"The technology shows promise—if you can afford the upfront investment."

---

### Buzzwords & Corporate Speak

#### "Revolutionary" / "Game-changing" - CRITICAL

**Human Alternatives:**
- **Remove and be specific** (best)
- **Significant** (if you must use emphasis)
- **Substantial** (measurable impact)
- **Show, don't tell** (describe the actual change)

**Examples:**

❌ **AI**:
"Our revolutionary platform is a game-changing solution."

✅ **Human**:
"Our platform reduces processing time by 60%—the fastest in the industry."

✅ **Human - Specific impact**:
"Our platform cuts what used to take 3 days down to 4 hours."

---

#### "Seamless integration" - Tech cliché

**Human Alternatives:**
- **Integrates smoothly** (less buzzwordy)
- **Connects with [specific tools]**
- **Works with existing [systems]**
- **Describe how it actually works**

**Examples:**

❌ **AI**:
"Our solution offers seamless integration with all major platforms."

✅ **Human**:
"Our solution connects with Salesforce, HubSpot, and Slack—no custom coding needed."

---

#### "Cutting-edge" / "Innovative"

**Human Alternatives:**
- **New** (simple)
- **Advanced** (if technically true)
- **Latest** (temporal, factual)
- **Describe what makes it new** (best)

**Examples:**

❌ **AI**:
"We use cutting-edge AI technology."

✅ **Human**:
"We use GPT-4 with custom fine-tuning on industry data."

---

#### "Leverage" (verb) - Corporate speak

**Human Alternatives:**
- **Use** (simple, direct)
- **Apply** (appropriate)
- **Take advantage of** (natural)

**Examples:**

❌ **AI**:
"Leverage our expertise to optimize your workflow."

✅ **Human**:
"Use our expertise to streamline your workflow."

---

#### "Robust" - Vague quality descriptor

**Human Alternatives:**
- **Reliable** (specific quality)
- **Powerful** (if about capability)
- **Comprehensive** (if about coverage)
- **Describe actual attributes**

**Examples:**

❌ **AI**:
"Our robust platform handles enterprise needs."

✅ **Human**:
"Our platform handles 10M+ transactions daily without downtime."

---

### Action Verbs

#### "Navigate" / "Navigating the landscape"

**Human Alternatives:**
- **Explore** (discovery)
- **Work through** (process)
- **Manage** (control)
- **Deal with** (challenge)
- **Remove the metaphor entirely** (best)

**Examples:**

❌ **AI**:
"Navigating the complex landscape of digital transformation requires expertise."

✅ **Human**:
"Digital transformation is complex. You need expertise to do it right."

✅ **Human - Direct**:
"Digital transformation fails 70% of the time. Here's why—and how to avoid it."

---

#### "Delve into" / "Dive into"

**Human Alternatives:**
- **Examine** (analytical)
- **Explore** (discovery)
- **Look at** (simple)
- **Analyze** (technical)
- **Let's talk about** (conversational)

**Examples:**

❌ **AI**:
"Let's delve into the key features of our platform."

✅ **Human**:
"Let's look at the key features of our platform."

✅ **Human - Direct**:
"Here are the features that matter most:"

---

#### "Harness the power of"

**Human Alternatives:**
- **Use** (simple)
- **Apply** (appropriate)
- **Take advantage of** (natural)
- Remove metaphor entirely

**Examples:**

❌ **AI**:
"Harness the power of AI to transform your business."

✅ **Human**:
"Use AI to automate repetitive tasks and free up your team."

---

### Structural Patterns - How to Restructure

#### Replace "IT'S NOT X, IT'S Y" (CRITICAL - Dead Giveaway)

**Human Alternatives:**

**1. Remove binary opposition:**

❌ AI: "It's not just about technology. It's about people."

✅ Human: "Technology works when people know how to use it."

**2. Show complexity instead of opposition:**

❌ AI: "This isn't a product. It's a solution."

✅ Human: "This product solves a specific problem: manual data entry errors that cost companies an average of $45K annually."

**3. Use nuanced connection:**

❌ AI: "We don't just deliver. We transform."

✅ Human: "We deliver results that change how teams work. One client reduced meeting time by 40% in the first month."

---

#### Replace Three-Item Lists (Always 3 Items)

**Human Alternative:**
- **Vary the number**: Use 2, 4, or 5 items
- **Break up adjective lists**: Use sentences instead

**Examples:**

❌ **AI**:
"Our platform is fast, efficient, and user-friendly."

✅ **Human - Two items**:
"Our platform is fast and built for teams that don't have time for training."

✅ **Human - Four items**:
"Our platform is fast, requires zero training, integrates with your existing tools, and costs less than hiring a new employee."

✅ **Human - Restructure entirely**:
"Our platform loads in under 2 seconds. Your team can start using it today without training. And it costs less than a full-time hire."

---

#### Replace Hook Questions

**Human Alternatives:**

**1. Start with data:**

❌ AI: "Have you ever wondered why digital transformation fails?"

✅ Human: "70% of digital transformation projects fail within the first year."

**2. Start with specific problem:**

❌ AI: "Are you ready to revolutionize your workflow?"

✅ Human: "Your team spends 12 hours a week on manual data entry. Here's how to eliminate that entirely."

**3. Start with story:**

❌ AI: "Imagine a world where your processes are fully automated."

✅ Human: "Sarah's team used to spend Fridays doing manual reporting. Now they don't. Here's what changed."

---

### Opening Patterns - How to Start Instead

#### Replace "In today's rapidly evolving..."

**Human Alternatives:**

**1. Start with current data:**
✅ "The software market grew 23% in 2024."

**2. Start with specific change:**
✅ "Five years ago, AI was experimental. Today, 60% of Fortune 500 companies use it in production."

**3. Start with problem:**
✅ "Most companies waste 30% of their software budget on tools nobody uses."

**4. Start with provocative statement:**
✅ "Digital transformation doesn't work. At least not the way most companies do it."

**5. Start with question (specific, not generic hook):**
✅ "What do successful digital projects have in common? They start small."

---

## Combined Example - Full Paragraph Transformation

### ITALIAN

❌ **AI VERSION** (Multiple tells):
```
Nell'era digitale, è interessante notare che le aziende devono ottimizzare le loro strategie. Inoltre, l'innovazione è cruciale per restare competitivi. Tuttavia, l'implementazione richiede investimenti significativi. In conclusione, la trasformazione digitale è fondamentale per il futuro.
```

**AI Tells Present:**
- Opening formula: "Nell'era digitale"
- ChatGPT signature: "È interessante notare"
- Overused connectors: "Inoltre", "Tuttavia"
- Buzzwords: "Innovazione", "cruciale", "fondamentale"
- Formal excess: "ottimizzare", "implementazione"
- Generic closing: "In conclusione"
- Word repetition: No variatio applied

✅ **HUMAN VERSION** (All tells removed):
```
Le aziende italiane hanno investito 4,2 miliardi in digitale nel 2024. Eppure, il 60% non ha ancora un piano chiaro per utilizzare questi strumenti. Il problema? Serve formazione. Senza, ogni euro speso in tecnologia rischia di essere sprecato. I dati lo confermano: le imprese che formano il personale vedono un ROI del 230% superiore rispetto a chi compra software e spera che funzioni.
```

**Human Improvements:**
- Starts with data, not generic setup
- Direct language, no buzzwords
- Natural connector ("Eppure" instead of "Tuttavia")
- Variatio: aziende → imprese
- Shows problem concretely
- Ends with data, not formula
- Conversational tone ("Il problema?")

---

### ENGLISH

❌ **AI VERSION** (Multiple tells):
```
In today's rapidly evolving digital landscape, it's worth noting that companies must leverage cutting-edge technology. Moreover, innovation is crucial for success. Furthermore, seamless integration is a game-changer. That being said, implementation requires significant investment. It's not just about technology. It's about transformation.
```

**AI Tells Present:**
- Generic opening: "In today's rapidly evolving"
- ChatGPT signature: "It's worth noting"
- Overused connectors: "Moreover", "Furthermore", "That being said"
- Buzzwords: "cutting-edge", "crucial", "seamless integration", "game-changer"
- Corporate speak: "leverage"
- Antithesis: "It's not just X. It's Y."

✅ **HUMAN VERSION** (All tells removed):
```
Companies spent $4.2B on digital tools in 2024. But 60% still don't have a clear plan for using them. The problem isn't technology—it's training. Without it, every dollar spent is a gamble. The data backs this up: companies that train their teams see 230% higher ROI than those who buy software and hope for the best.
```

**Human Improvements:**
- Starts with concrete data
- Simple connectors ("But")
- Specific problem, no buzzwords
- Natural contrast without formula
- Ends with data-driven insight
- Conversational asides ("—it's training")
- Varied sentence length (short + long)

---

## Summary Principles

### For ALL Alternatives:

1. **Specificity over vagueness**: Replace buzzwords with concrete data, examples, outcomes
2. **Simple over complex**: Use everyday language unless technical precision required
3. **Show over tell**: Describe actual impact instead of using adjectives like "innovative"
4. **Vary over repeat**: Apply variatio principle (especially Italian), avoid uniform structures
5. **Natural over formulaic**: Remove explicit connectors and section markers where possible
6. **Data over claims**: "Reduces cost by 40%" beats "cost-effective solution"
7. **Story over setup**: Start with specific example instead of grand contextual opening

---

**For context-specific severity rules, see `detection-framework.md`.**
**For cultural appropriateness (IT vs USA), see `cultural-context.md`.**
