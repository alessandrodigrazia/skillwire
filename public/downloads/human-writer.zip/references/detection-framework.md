# Detection Framework - Context-Aware Analysis System

Systematic framework for detecting AI writing patterns with context-aware severity assessment. This guide explains how to apply detection rules intelligently based on content type, audience, and cultural context.

---

## Four-Tier Severity System

### 🔴 CRITICAL Tier (Must Fix - Very High AI Probability)

**Definition**: Patterns that are **absolute indicators** of AI authorship or are so overused by AI that they immediately signal non-human writing.

**Characteristics:**
- Appear in 70%+ of AI-generated content
- Rarely (or never) used by human writers in same frequency
- Often direct artifacts of AI generation process
- Immediate red flags regardless of context

**Italian CRITICAL Patterns:**
1. Opening formulas: "In un mondo in cui...", "Nell'era di..."
2. ChatGPT signatures: "È interessante notare che", "Vale la pena menzionare"
3. Typography: Capitals after colons (3+ instances), Title Case headings
4. Citation artifacts: [oai_citation], metadata tells
5. Closing formulas: "In conclusione", "Per concludere" (when combined with other tells)

**English CRITICAL Patterns:**
1. Response artifacts: "Certainly! Here is...", "Based on the information provided"
2. Citation markers: [oai_citation:0], utm_source=openai, [web:1]
3. ChatGPT signatures: "It's worth noting", "Moreover" + "Furthermore" combo
4. "IT'S NOT X, IT'S Y" antithesis (2+ instances)
5. Hook openings: "In today's rapidly evolving...", "Have you ever wondered..."

**Action Required:**
- **Always flag and fix** (no exceptions)
- Explain why it's a critical tell
- Provide specific alternative
- Show before/after example

**AI Probability**: 85-100% when CRITICAL patterns present

---

### 🟠 HIGH Tier (Strongly Recommended to Fix - Context-Aware)

**Definition**: Patterns **significantly overused by AI** (4-10x frequency) that are legitimate in some contexts but become tells when:
- Used multiple times in one piece
- Combined with other HIGH or CRITICAL patterns
- Used in inappropriate contexts

**Characteristics:**
- Acceptable in formal/academic contexts (moderate use)
- Red flags in casual/web content
- Frequency matters: 1 instance = caution, 3+ = very high AI probability

**Italian HIGH Patterns:**
1. Connectors: "Inoltre" (3+ uses), "Tuttavia", "Nonostante", "Infatti"
2. Buzzwords: "Innovativo", "Rivoluzionario", "Cruciale", "Fondamentale" (2+ different)
3. Antithesis: "Non X ma Y" pattern (2+ instances)
4. Triple lists: Exactly 3 items (3+ instances across text)
5. Generic conclusions with formulaic recap

**English HIGH Patterns:**
1. Transitions: "Moreover", "Furthermore", "That being said" (2+ instances)
2. Buzzwords: "Revolutionary", "Cutting-edge", "Seamless", "Game-changing" (2+ different)
3. Action verbs: "Navigate", "Delve into", "Harness", "Bolster"
4. Triple lists: Exactly 3 items (3+ instances)
5. Em dashes without spaces (3+ in 500 words - ChatGPT specific)

**Context-Aware Rules:**

| Context | HIGH Pattern Threshold | Severity |
|---------|------------------------|----------|
| **Academic/Research** | 4-5 instances OK | MEDIUM (contextual) |
| **Business Article** | 2-3 instances | HIGH (flag) |
| **Web/Blog Casual** | 1-2 instances | HIGH (flag) |
| **Social Media** | 1 instance | CRITICAL (sounds robotic) |

**Action Required:**
- Flag when threshold exceeded for context
- Explain context-appropriateness
- Suggest reduction or alternatives
- If 3+ HIGH patterns + any CRITICAL = treat as CRITICAL

**AI Probability**: 70-90% when multiple HIGH patterns in inappropriate context

---

### 🟡 MEDIUM Tier (Context-Dependent - Improvement Suggestions)

**Definition**: Patterns that are **moderately overused** by AI (2-4x frequency) or are legitimate in their intended context but signal AI when:
- Used outside appropriate register
- Combined with CRITICAL/HIGH patterns
- Part of systematic pattern (e.g., all sentences same length)

**Characteristics:**
- Appropriate in formal/technical writing
- Questionable in casual contexts
- Become tells through concentration or combination

**Italian MEDIUM Patterns:**
1. Formal academic terms in casual context (5+ different terms: "ottimizzazione", "implementazione", "strategia", etc.)
2. Word repetition violating VARIATIO (3+ repetitions of non-technical term)
3. Uniform sentence length (StdDev <5 words, average 15-25)
4. Passive voice avoidance (Italian uses passive naturally; AI underuses it)
5. USA motivational tone in Italian professional contexts
6. Gerund chains (3+ gerunds in one sentence)

**English MEDIUM Patterns:**
1. Formal corporate terms in casual context: "Facilitate", "Leverage", "Robust" (3+ instances)
2. Uniform paragraph length (all 4-5 sentences)
3. Excessive hedging: "It could be argued that...", "One might suggest..." (3+ instances)
4. False casualness: "Let's face it", "At the end of the day" (2+ instances)
5. Immediate list structures (no preamble before bullets)
6. Perfect grammar, zero typos in 1000+ words

**Context-Aware Rules:**

| Pattern | Academic | Business | Web/Blog | Social |
|---------|----------|----------|----------|--------|
| Formal terms (IT) | ✅ Appropriate | 🟡 Max 3-4 | 🟠 Flag if >2 | 🔴 Flag any |
| Sentence uniformity | 🟡 OK if varied | 🟠 Flag | 🟠 Flag | 🔴 Critical |
| Perfect grammar | ✅ Expected | ✅ OK | 🟡 Suspicious if combined with other tells | 🟠 Flag |

**Action Required:**
- Note pattern, assess context
- If context is appropriate, lower severity or skip
- If context inappropriate, flag and suggest alternatives
- If 5+ MEDIUM patterns = escalate to HIGH

**AI Probability**: 50-70% when MEDIUM patterns concentrated in inappropriate context

---

### ⚪ STYLE Tier (Optional Improvements - Preference)

**Definition**: Patterns that are **stylistic preferences** or minor tells that don't significantly impact AI detection but improve naturalness.

**Characteristics:**
- Not AI-specific, but AI tends toward certain styles
- Improve readability and human feel
- Optional fixes based on user preference

**Examples:**
1. Could vary sentence structure more (but current structure not wrong)
2. Could use more contractions in casual English (but lack of contractions not a tell)
3. Could add personal anecdote (but absence not AI-specific)
4. Could use more specific examples (generic content not always AI)
5. Emoji use appropriate but could be adjusted for audience

**Action Required:**
- Note as optional improvement
- Suggest only if user wants maximum humanization
- Don't count toward AI probability calculation

**AI Probability**: Neutral (doesn't increase or decrease probability)

---

## Context-Aware Detection Logic

### Step 1: Identify Content Type

**Question**: What type of content is this?

| Content Type | Baseline Formality | Expected Patterns |
|--------------|-------------------|-------------------|
| **Academic Paper** | Very High | Formal terms OK, citations expected, longer sentences |
| **Technical Documentation** | High | Technical jargon appropriate, structured organization |
| **Business Article** | Medium-High | Some formal terms OK, but reduce buzzwords |
| **Web Blog** | Medium | Conversational, varied structure, personal voice |
| **Social Media** | Low | Brief, casual, emoji acceptable, imperfect OK |
| **Marketing Copy** | Variable | Some buzzwords expected, but genuine specificity needed |
| **Email (Professional)** | Medium (IT: High, USA: Medium) | Cultural rules apply strongly |

**Action**: Adjust severity thresholds based on content type.

---

### Step 2: Assess Target Audience

**Question**: Who is the intended reader?

| Audience | Tone Expectation | Pattern Tolerance |
|----------|------------------|-------------------|
| **Academic/Researchers** | Formal, precise | High tolerance for formal terms |
| **Business Executives (IT)** | Formal, relationship-oriented | Low tolerance for USA casual tone |
| **Business Executives (USA)** | Professional but brief | Low tolerance for excessive formality |
| **General Public** | Accessible, clear | Low tolerance for jargon/buzzwords |
| **Technical Specialists** | Precise, technical | High tolerance for technical terms |
| **Social Media** | Casual, authentic | Zero tolerance for robotic patterns |

**Action**: Flag patterns inappropriate for audience.

---

### Step 3: Language & Cultural Context

**Question**: What language and cultural norms apply?

**Italian Content:**
- Higher formality baseline
- Longer sentences expected
- VARIATIO principle mandatory
- USA motivational tone = red flag
- Titles and "Lei" expected in professional contexts

**English (USA) Content:**
- Lower formality baseline
- Brevity valued
- First names, direct communication
- Excessive formality = potential AI (or non-native)

**English (UK) Content:**
- Slightly more formal than USA
- More reserved tone
- Understatement valued

**Action**: Apply cultural rules from `cultural-context.md`.

---

### Step 4: Calculate Pattern Concentration

**Formula for AI Probability**:

```
AI Probability Score =
  (CRITICAL patterns × 30) +
  (HIGH patterns × 10) +
  (MEDIUM patterns × 3)
```

**Interpretation**:

| Score | AI Probability | Confidence |
|-------|----------------|------------|
| 0-10 | Low (0-30%) | Likely human or very sophisticated AI |
| 11-30 | Medium (30-60%) | Some AI tells, inconclusive |
| 31-60 | High (60-85%) | Multiple patterns, likely AI |
| 61-90 | Very High (85-95%) | Strong AI indicators |
| 91+ | Near Certain (95-99%) | Overwhelming AI evidence |
| Metadata artifact | Certain (100%) | Proof of AI generation |

**Context Adjustment**:
- Subtract 10-20 points if patterns are appropriate for context (e.g., formal terms in academic paper)
- Add 10-20 points if patterns are inappropriate for context (e.g., USA motivational in Italian business)

**Examples**:

**Example 1**: Italian blog post
- CRITICAL: "È interessante notare" (1) = 30 points
- HIGH: "Inoltre" (4 times), "Innovativo" (2 times) = 20 points
- MEDIUM: 6 formal terms in casual blog = 18 points
- **Total**: 68 points = **Very High AI Probability (85-95%)**

**Example 2**: English technical documentation
- HIGH: "Moreover" (2 times) = 20 points
- MEDIUM: "Facilitate", "Robust", "Implementation" (technical context, appropriate) = 9 points, but subtract 15 for context appropriateness
- **Total**: 14 points = **Medium AI Probability (30-60%)** - Could be human technical writer or AI

**Example 3**: Italian academic paper
- HIGH: "Inoltre" (3 times), "Tuttavia" (2 times) = 50 points, but subtract 30 for academic context
- MEDIUM: 8 formal terms (appropriate in academic) = 24 points, subtract 20 for context
- **Total**: 24 points = **Medium-Low AI Probability (40-50%)** - Likely human academic or very context-appropriate AI

---

## Industry-Specific Adjustments

### Legal Writing

**Characteristics:**
- Highly formal (both IT & EN)
- Technical terminology essential
- Long, complex sentences expected
- Conservative tone mandatory

**Adjustments:**
- MEDIUM formal terms → OK, don't flag
- Sentence length uniformity → OK in legal
- HIGH formal connectors → Reduce severity to MEDIUM
- CRITICAL patterns still flag (no "È interessante notare" in legal docs)

---

### Tech Startups

**Characteristics:**
- More casual (even in Italian)
- English terms mixed in (especially Italian tech)
- First names faster (Italy)
- Innovation buzzwords somewhat expected

**Adjustments:**
- Some buzzwords tolerable ("innovativo" in tech = less severe)
- Casual tone acceptable
- But: Emoji excess, triple lists, antithesis still flag
- CRITICAL patterns still critical

---

### Marketing Copy

**Characteristics:**
- Persuasive language expected
- Some hype acceptable
- Emotional engagement valued

**Adjustments:**
- 1-2 buzzwords tolerable (but not "rivoluzionario" + "innovativo" + "trasformativo")
- Antithesis pattern more acceptable (1 instance OK, 3+ still flag)
- Triple lists somewhat expected (but not exclusively)
- Opening hooks more acceptable
- But: ChatGPT signatures, metadata tells still CRITICAL

---

### Journalism / News

**Characteristics:**
- Objective tone
- Data-driven
- Clear, accessible language
- Inverted pyramid structure

**Adjustments:**
- Formal terms should be minimal
- Buzzwords inappropriate (flag as HIGH)
- VARIATIO essential (Italian)
- Perfect grammar expected (don't flag)
- Generic openings highly inappropriate (elevate to CRITICAL)

---

## False Positives - When to Ignore or Downgrade

### Legitimate False Positives

**1. Non-Native Writers**
- May use formal language excessively (learned from textbooks)
- May apply wrong cultural norms (Italian writing English, vice versa)
- **Action**: If other signals suggest human (imperfections, specific examples, personal voice), note non-native patterns but don't over-flag as AI

**2. Templated Corporate Communication**
- Some companies require specific phrasing
- Brand voice guidelines may mandate certain terms
- **Action**: If consistently using company-specific terms/structure, may be human following template

**3. Multilingual Texts**
- Code-switching between languages
- Technical terms in English within Italian text (or vice versa)
- **Action**: Common in tech, academic contexts; don't flag as AI unless other tells present

**4. Edited Content**
- Professional editing can create uniform sentence length
- Copy editing can remove all typos
- **Action**: Perfect grammar + uniform length alone ≠ AI; needs additional tells

**5. Style Guide Compliance**
- Some publications require specific connectors
- House style may mandate certain structures
- **Action**: Check if patterns align with known publication style

---

### Edge Cases - Ambiguous Signals

**Scenario 1**: Academic paper with multiple "inoltre", "tuttavia", formal terms
- **Analysis**: Appropriate for context
- **Action**: Note patterns, but rate as Medium-Low AI probability
- **Key**: If NO CRITICAL tells + context-appropriate = likely human

**Scenario 2**: Italian LinkedIn post with emoji and personal story but some AI buzzwords
- **Analysis**: Mixed signals - human structure with AI language
- **Action**: Likely human who consumed AI content or used AI for editing
- **Key**: Personal anecdote + specific details + minor AI buzzwords = human with AI influence

**Scenario 3**: Perfect grammar, uniform structure, but highly specific technical content
- **Analysis**: Could be expert human or well-prompted AI
- **Action**: Look for specificity, novel insights, data sources
- **Key**: If content shows deep expertise and specific examples = likely expert human (or expert + AI assistant)

---

## Decision Tree for Analysis

```
START: Analyze Text

1. Scan for CRITICAL Patterns
   ├─ Found citation artifacts / response artifacts?
   │  └─ YES → AI Probability = 100% (CERTAIN)
   │
   ├─ Found ChatGPT signatures ("È interessante notare", "It's worth noting")?
   │  └─ YES → AI Probability = 95%+ (NEAR CERTAIN)
   │
   ├─ Found opening formulas ("In un mondo in cui", "In today's rapidly")?
   │  └─ YES → Continue to count other patterns (Very High AI Probability)
   │
   └─ None found → Continue to HIGH tier

2. Scan for HIGH Patterns
   ├─ Count frequency of high-tier patterns
   ├─ Assess context appropriateness
   │  ├─ Academic/Technical context?
   │  │  └─ Reduce severity by 1-2 levels
   │  └─ Casual/Web context?
   │     └─ Maintain severity
   │
   ├─ 3+ HIGH patterns in inappropriate context?
   │  └─ YES → AI Probability = 85%+ (VERY HIGH)
   │
   └─ 1-2 HIGH patterns → Continue to MEDIUM tier

3. Scan for MEDIUM Patterns
   ├─ Count medium-tier patterns
   ├─ Assess context
   ├─ 5+ MEDIUM patterns in inappropriate context?
   │  └─ YES → AI Probability = 70%+ (HIGH)
   │
   └─ <5 MEDIUM patterns → Calculate score

4. Calculate AI Probability Score
   Score = (CRITICAL × 30) + (HIGH × 10) + (MEDIUM × 3)
   Apply context adjustments (+/- 10-20 points)

5. Assign Final Probability
   ├─ 0-10: Low (0-30%)
   ├─ 11-30: Medium (30-60%)
   ├─ 31-60: High (60-85%)
   ├─ 61-90: Very High (85-95%)
   └─ 91+: Near Certain (95-99%)

6. Check for False Positive Indicators
   ├─ Non-native writer signals?
   ├─ Template/Brand voice compliance?
   ├─ Specific expertise + novel insights?
   ├─ Personal anecdotes + imperfections?
   │
   └─ If YES to multiple → Reduce AI probability by 10-20%

7. Generate Report
   ├─ List patterns by severity
   ├─ Explain context appropriateness
   ├─ Provide alternatives
   ├─ Show before/after examples
   └─ Assign final AI probability with confidence level
```

---

## Reporting Framework

### For Each Detected Pattern, Report:

1. **Pattern Identified**:
   - Exact text/structure
   - Location in text (paragraph, line if possible)

2. **Severity Level**:
   - 🔴 CRITICAL / 🟠 HIGH / 🟡 MEDIUM / ⚪ STYLE

3. **Why It's an AI Tell**:
   - Frequency data (e.g., "8x more common in AI")
   - Model signature (e.g., "ChatGPT hallmark phrase")
   - Context inappropriateness (e.g., "USA tone in Italian professional")

4. **Context Assessment**:
   - Is pattern appropriate for this content type?
   - Adjust severity based on context

5. **Alternative Suggestion**:
   - Specific human-like replacement
   - Before/After example

6. **Educational Note**:
   - Why this matters
   - What principle it violates (e.g., VARIATIO, cultural appropriateness)

---

## Confidence Levels in Detection

### Very High Confidence (95-99%)
- Multiple CRITICAL patterns present
- Patterns inappropriate for any context
- Combination of tells across multiple categories
- **Action**: State with confidence, explain thoroughly

### High Confidence (85-94%)
- 1 CRITICAL + multiple HIGH patterns
- Clear context inappropriateness
- **Action**: State with high confidence, note any ambiguities

### Medium Confidence (60-84%)
- Multiple HIGH patterns in inappropriate context
- OR concentrated MEDIUM patterns
- Some ambiguity about context
- **Action**: State as "likely AI", acknowledge uncertainty

### Low Confidence (30-59%)
- Few HIGH/MEDIUM patterns
- Context could explain patterns
- Mixed human/AI signals
- **Action**: Note patterns, but acknowledge low confidence; may be human with AI influence or highly context-appropriate AI

---

## Summary Principles

1. **Context is King**: Same pattern can be CRITICAL in one context, OK in another
2. **Concentration Matters**: 1 instance = caution; 3+ = very high probability
3. **Combination Amplifies**: Multiple tells across tiers = exponential confidence increase
4. **Cultural Sensitivity**: Apply appropriate norms (IT vs USA)
5. **Industry Awareness**: Legal ≠ Social Media ≠ Academic
6. **False Positive Vigilance**: Don't over-flag humans with atypical styles
7. **Explain, Always**: User should understand WHY pattern is flagged for given context

---

**For specific patterns and frequencies, see `italian-errors-database.md` and `english-errors-database.md`.**
**For alternatives, see `alternatives-guide.md`.**
**For cultural rules, see `cultural-context.md`.**
