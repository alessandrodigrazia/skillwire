# English AI Writing Patterns - Complete Database

Comprehensive database of AI writing tells in English, based on quantitative research and detection patterns. Organized by severity and category for systematic analysis.

---

## TIER BAN - Never Use (Critical Severity 🔴)

These terms and patterns are immediate red flags for AI-generated English content, particularly ChatGPT outputs.

### Transitions & Connectors

| Term/Phrase | Severity | AI Frequency | Notes |
|-------------|----------|--------------|-------|
| **Moreover** | CRITICAL | 8-10x higher | #1 ChatGPT tell |
| **Furthermore** | CRITICAL | 7-9x higher | Paired with "Moreover" |
| **Certainly** | CRITICAL | ChatGPT signature | "Certainly! Here is..." opening |
| **That being said** | HIGH | 5-6x higher | Overused hedge |
| **At its core** | HIGH | 4-5x higher | Analytical crutch |
| **It's worth noting** | **CRITICAL** | ChatGPT hallmark | Appears in 50%+ ChatGPT articles |
| **It's important to note** | **CRITICAL** | ChatGPT hallmark | Paired with above |
| **Notably** | HIGH | 4-5x higher | Academic overuse |
| **Indeed** | MEDIUM-HIGH | 3-4x higher | Formal confirmation |
| **Additionally** | MEDIUM | 3-4x higher | Less obvious but overused |

**Detection Rule**: "Moreover" + "Furthermore" in same article = 95%+ ChatGPT probability.

**"Certainly!" Opening**: If text starts with "Certainly! Here is..." = 100% AI (ChatGPT response pattern).

---

### Descriptive & Academic Terms

| Term | Severity | Why It's an AI Tell |
|------|----------|---------------------|
| **Crucial** | CRITICAL | Top 3 most overused AI adjective |
| **Notable/Notably** | HIGH | Academic pretension |
| **Underscore** | HIGH | "This underscores the importance..." - cliché |
| **Illuminate** | HIGH | "Shed light on" / "Illuminate" - overused metaphor |
| **Facilitate** | HIGH | Corporate jargon overload |
| **Bolster** | HIGH | "To bolster the argument..." - formal excess |
| **Myriad** | MEDIUM | "A myriad of options" - pretentious |
| **Plethora** | MEDIUM | Similar to myriad - overused variety word |
| **Vital** | MEDIUM-HIGH | Emphasis overuse (everything is "vital") |
| **Paramount** | MEDIUM-HIGH | Exaggeration crutch |

---

### Buzzwords & Corporate Speak

| Term/Phrase | Severity | Industry | Detection Impact |
|-------------|----------|----------|------------------|
| **Revolutionize** | CRITICAL | Tech/Business | Empty hype |
| **Game-changing** | CRITICAL | Marketing | Overused innovation claim |
| **Cutting-edge** | HIGH | Tech | Every product is "cutting-edge" |
| **Innovative** | HIGH | All | Generic innovation buzzword |
| **Seamless integration** | HIGH | Tech | Product description cliché |
| **Scalable solution** | HIGH | SaaS/Tech | Every software is "scalable" |
| **Transformative** | HIGH | Business | Exaggeration |
| **Leverage** | MEDIUM-HIGH | Business | "Leverage our expertise" - corporate |
| **Ecosystem** | MEDIUM | Tech | Everything is an "ecosystem" |
| **Robust** | MEDIUM-HIGH | Tech | Vague quality descriptor |
| **Synergy** | MEDIUM | Business | Corporate buzzword classic |
| **Holistic** | MEDIUM | Business/Wellness | Overused comprehensive descriptor |

**Detection Rule**: 3+ of these buzzwords in a single article = Very High AI probability.

---

### Action Verbs (Overused)

| Verb/Phrase | Severity | AI Pattern | Human Alternative |
|-------------|----------|------------|-------------------|
| **Navigate** | HIGH | "Navigating the landscape of..." | Explore, work through, manage |
| **Delve into** | HIGH | "Let's delve into..." | Examine, explore, look at |
| **Dive into** | MEDIUM-HIGH | "Dive deep into..." | Explore, examine |
| **Harness** | MEDIUM | "Harness the power of..." | Use, utilize, apply |
| **Embark on** | MEDIUM | "Embark on a journey..." | Start, begin |
| **Unpack** | MEDIUM-HIGH | "Let's unpack this..." | Analyze, examine, break down |

**ChatGPT Specific**: "Navigate" appears in 40%+ of ChatGPT business/tech articles.

---

### Formulaic Phrases

| Phrase | Severity | Context |
|--------|----------|---------|
| **"Based on the information provided"** | CRITICAL | ChatGPT response artifact |
| **"As of my knowledge cutoff"** | CRITICAL | LLM temporal disclaimer |
| **"I don't have access to real-time data"** | CRITICAL | LLM limitation statement |
| **"Let me know if you have any questions"** | HIGH | ChatGPT conversational closer |
| **"Feel free to reach out"** | MEDIUM | Generic corporate closer |

---

## Structural Patterns (CRITICAL Detection)

### 1. "IT'S NOT X, IT'S Y" Parallelism

**Pattern**: Binary antithesis structure appears multiple times per AI article.

**Examples:**
- "It's not just about technology. It's about people."
- "This isn't a product. It's a solution."
- "We don't just deliver. We transform."
- "It's not simply X. It's fundamentally Y."

**Why It's an AI Tell**:
- Appears in 70%+ of persuasive AI content
- Used multiple times per article (human: rarely, if ever)
- Rhythmic, dramatic structure AI finds compelling

**Variation Patterns**:
- "It's not X, it's Y"
- "This isn't X, it's Y"
- "Not just X, but Y"
- "More than X, it's Y"

**Detection Rule**: 2+ instances in one article = **"Dead giveaway"** (per research).

---

### 2. Three-Item Lists (Triple Structure)

**Pattern**: AI systematically ends sentences with exactly 3 adjectives/items.

**Examples:**
- "Our platform is fast, efficient, and user-friendly."
- "We provide solutions that are scalable, robust, and innovative."
- "The future is digital, connected, and transformative."

**Why It's an AI Tell**:
- AI almost never uses 2 or 4 items - always 3
- Comes from "rule of three" in marketing copy training data
- Human writers vary: 2, 3, 4, 5 items

**Detection Rule**: 3+ instances of exactly-3-item lists = Very High AI probability.

**"Dead Giveaway" Quote from Research**: This pattern is one of the most reliable AI detectors.

---

### 3. Hook + Question Opening

**Pattern**: Start with rhetorical question to create engagement.

**Examples:**
- "Have you ever wondered why...?"
- "What if I told you that...?"
- "Are you ready to transform...?"
- "Imagine a world where..."

**Why It's AI**:
- Mimics clickbait/marketing training data
- Used systematically even in inappropriate contexts (e.g., technical docs)
- Human professional writing starts more directly

**Detection**: Hook question in first paragraph = Medium-High AI probability.

---

### 4. Sequential Organization (Rigid Structure)

**Pattern**: Overuse of "Firstly, Secondly, Finally" or "First, Second, Third".

**AI Example**:
```
Firstly, we need to consider X.
Secondly, it's important to address Y.
Finally, we must implement Z.
```

**Why It's AI**:
- Mechanically rigid structure
- Human writers use more varied transitions
- Often combined with other tells

**Human Alternative**: Use varied transitions like "To start", "Beyond that", "Most importantly", or integrate points without explicit numbering.

---

## Formatting Tells (HIGH SEVERITY)

### 1. Excessive Em Dashes (—)

**AI Pattern**: Frequent em dashes (—), often correctly formatted but unnatural in frequency.

**Example:**
"Our solution—which is cutting-edge—provides seamless integration—ensuring scalability."

**ChatGPT Specific**: Em dash WITHOUT spaces is a ChatGPT hallmark.
- AI: "solution—which is"
- Human: "solution — which is" or "solution—which is" (but rarely used)

**Detection**: 3+ em dashes in 500 words = AI flag.

---

### 2. Immediate List Structures

**AI Pattern**: Jumps to bullet points or numbered lists immediately after heading without preamble.

**Example:**
```
## Benefits

- Benefit 1
- Benefit 2
- Benefit 3
```

**Human Pattern**: Brief introductory sentence before list.

**Example:**
```
## Benefits

Our approach offers several key advantages:
- Benefit 1
- Benefit 2
- Benefit 3
```

---

### 3. Emoji Overuse (Context-Inappropriate)

**AI Pattern**: Uses emojis in professional/technical contexts where they don't belong.

**Examples:**
- ✅ Checkmarks in bullet lists (every single item)
- 🚀 Rocket for "innovation" or "growth"
- 💡 Lightbulb for "ideas"
- 📊 Chart for any data mention

**Why It's AI**: Mimics LinkedIn viral post structure, applied indiscriminately.

**Human Pattern**: Emojis used sparingly in professional content, contextually in social media.

---

### 4. "Unhinged Bold Highlights"

**AI Pattern**: Random bold text that doesn't follow logical hierarchy or emphasis rules.

**Example**:
"Our platform provides **seamless integration** with **cutting-edge technology** to **transform** your business."

**Why It's AI**: Attempts to emphasize "important" words without understanding natural emphasis patterns.

**Human Pattern**: Bold used for headings, key terms (first mention), or sparingly for true emphasis.

---

### 5. Uniform Paragraph/Sentence Length

**AI Pattern**: All paragraphs 4-5 sentences, all sentences 20-30 words.

**Quantitative Detection**:
- Calculate sentence length standard deviation
- If StdDev < 6 words AND average 20-30 words = AI flag

**Human Pattern**: High variation (8-word sentences mixed with 40-word sentences).

---

## Metadata Tells (CRITICAL - 100% Detection)

These are artifacts from AI generation that are absolute proof of AI authorship.

### 1. UTM Parameters

**Pattern**: URLs with AI-specific tracking parameters.

**Examples:**
- `utm_source=openai`
- `utm_source=chatgpt.com`
- `ref=chatgpt`

**Detection**: CRITICAL - 100% AI.

---

### 2. Citation Artifacts

**Pattern**: Incomplete or malformed citation attempts.

**Examples:**
- `[oai_citation:0‡source.com]`
- `citeturn0search0`
- `[web:1]`
- `[attached_file:1]`
- `【source†】`

**Detection**: CRITICAL - 100% AI (ChatGPT with web search or file uploads).

---

### 3. Markdown/HTML Mixing

**AI Pattern**: Inconsistent formatting with mixed markdown and HTML.

**Example**:
```
## Heading

<b>Bold text</b> mixed with **markdown bold**.

<ul>
<li>HTML list item</li>
</ul>

- Markdown list item
```

**Why It's AI**: Human editors use one consistent format. AI mixes formats from different training examples.

---

### 4. Response Artifacts

**Pattern**: Conversational AI response patterns left in text.

**Examples:**
- "Certainly! Here is..."
- "I hope this helps!"
- "Let me know if you need further clarification."
- "Based on the context provided..."

**Detection**: CRITICAL - These are direct chatbot responses.

---

## Opening Patterns (HIGH SEVERITY)

### TIER BAN Openings

1. **"In today's rapidly evolving [industry/world]..."**
   - Appears in 60%+ AI business articles
   - Detection: CRITICAL

2. **"Have you ever wondered...?"**
   - Hook question pattern
   - Detection: HIGH

3. **"Imagine a world where..."**
   - Futuristic scenario opener
   - Detection: HIGH

4. **"In an era of [buzzword]..."**
   - Similar to Italian "Nell'era di..."
   - Detection: HIGH

5. **"The landscape of [industry] is changing..."**
   - Generic transformation opener
   - Detection: MEDIUM-HIGH

6. **"As [industry] continues to evolve..."**
   - Passive evolution statement
   - Detection: MEDIUM-HIGH

---

## Tone Issues

### 1. False Casualness

**AI Pattern**: Attempts casual tone but comes across as forced or corporate.

**Examples:**
- "Let's face it..."
- "At the end of the day..."
- "The bottom line is..."
- "Here's the thing..."

**Why It's AI**: Trained on casual marketing copy, but applies it mechanically.

**Human Casual**: More natural, varied, may include contractions, personal anecdotes.

---

### 2. Excessive Hedging

**AI Pattern**: Overuse of qualifiers and hedge words.

**Examples:**
- "It could be argued that..."
- "One might suggest..."
- "It's possible that..."
- "Perhaps it's worth considering..."

**Why It's AI**: Trained to be cautious and non-committal.

**Human Pattern**: More direct statements or specific attribution ("According to [source]...").

---

### 3. Corporate Enthusiasm (Inappropriate)

**AI Pattern**: Overly enthusiastic tone in formal/technical contexts.

**Example**:
"We're thrilled to revolutionize your workflow with our game-changing platform! 🚀"

**Context**: Appropriate for marketing, inappropriate for technical documentation or professional articles.

---

## Model-Specific Signatures

### ChatGPT Hallmarks

**CRITICAL Tells:**
1. **"Moreover" / "Furthermore"** - appears in 70%+ of outputs
2. **"It's worth noting"** - signature phrase
3. **"Certainly!"** - response opener
4. **Em dash without spaces** - formatting signature
5. **Citation artifacts** - [oai_citation:0]
6. **Triple lists** - exactly 3 items, repeatedly
7. **Immediate structured lists** - jumps to bullets without preamble

**Tone**: Clinical, formal, academic even in casual contexts.

**Structure**: Rigid, sequential, highly organized.

**Vocabulary**: Technical, precise, buzzword-heavy.

---

### Claude Signatures

**Patterns:**
- More conversational and naturally flowing
- Less prone to buzzwords
- Better at humor and nuance
- May use longer, more complex sentences
- Generally more human-like (harder to detect)

**Possible Tells:**
- Excessive politeness or apologetic tone
- Overuse of parenthetical asides
- Tendency toward balanced, measured statements

**Note**: Claude (this model) tends to avoid classic AI tells naturally but can still fall into patterns when prompted for specific styles.

---

### Gemini Signatures

**Patterns:**
- More casual, sometimes too informal
- Prefers simple terms over complex ones (sometimes excessively)
- Example: Uses "sugar" instead of "glucose" even in technical contexts
- Conversational, explanatory style
- Shorter paragraphs

**Possible Tells:**
- Oversimplification in technical contexts
- Casual tone where formality expected
- Shorter, choppier sentences

---

## Quantitative Detection Data

### Frequency Multipliers (AI vs Human)

| Term/Pattern | AI Frequency | Confidence Level |
|--------------|--------------|------------------|
| "Moreover" | 8-10x | Very High |
| "Furthermore" | 7-9x | Very High |
| "It's worth noting" | 50%+ ChatGPT | Critical |
| "Crucial" | 6-8x | High |
| Triple lists (3+ instances) | 70%+ AI | Very High |
| "IT'S NOT X, IT'S Y" (2+ instances) | 70%+ AI | **Dead Giveaway** |
| "Navigate/Navigating" | 40%+ ChatGPT | High |
| Em dashes (3+ in 500 words) | High | Medium-High |

### Academic Studies Data

- **Detection accuracy**: 95-99% at document level (with multiple signals)
- **Vocabulary reduction**: 30-31% fewer unique words in AI text
- **Sentence length**: StdDev <6 in AI vs >10 in human writing
- **LinkedIn**: 54% of long-form posts AI-generated (Oct 2024)

---

## Cross-Language Universal Patterns

Patterns that appear in both English and Italian AI writing:

1. **Generic openings** - Contextual setup instead of direct topic
2. **Triple structure** - Always 3 items in lists
3. **Antithesis overuse** - "Not X but Y" pattern
4. **Buzzword concentration** - Multiple buzzwords per paragraph
5. **Uniform structure** - Predictable sentence/paragraph length
6. **Perfect grammar** - Zero typos in long texts
7. **Lack of personality** - Generic voice, no personal anecdotes
8. **Emoji misuse** - Contextually inappropriate or excessive
9. **Conclusive sections** - Explicit "Conclusion" with formulaic recap
10. **Emotional detachment** - Lacks genuine passion or frustration

---

## Grep Patterns for Quick Detection

### Critical Patterns
```regex
# Response artifacts
^(Certainly!|Based on the information provided|As of my knowledge cutoff)

# Citation artifacts
\[oai_citation|\[web:\d+\]|\[attached_file|【.*?†.*?】|citeturn

# Signature phrases
(It's worth noting|It's important to note|At its core)

# UTM parameters
utm_source=(openai|chatgpt)
```

### High-Frequency Terms
```regex
\b(Moreover|Furthermore|Notably|Crucial)\b
\b(Revolutionary|Cutting-edge|Seamless|Game-changing)\b
\b(Navigate|Navigating|Delve|Delving)\b
```

### Structural Patterns
```regex
# IT'S NOT X, IT'S Y
(It's not|This isn't) .{5,50}[,.]? (It's|This is)

# Opening patterns
^(In today's rapidly|Have you ever wondered|Imagine a world)

# Sequential organization
(Firstly|First),.*?(Secondly|Second),.*?(Finally|Third)
```

---

## False Positives - When to Ignore Flags

### Legitimate Contexts

1. **Academic Writing**: "Moreover", "Furthermore", "Notably" are standard academic transitions
2. **Technical Documentation**: "Implementation", "Facilitate", "Robust" are appropriate technical terms
3. **Marketing Copy**: Some buzzwords expected (but still reduce excessive use)
4. **Formal Reports**: Sequential organization (First, Second, Third) is standard practice

### Editorial Differences

- Some publications may have house style requiring em dashes
- Bullet-heavy style may be intentional design choice
- Technical jargon appropriate in specialized contexts

**Key Distinction**: Context + concentration matter. 1-2 flags in appropriate context ≠ AI. 8+ flags across categories = Very High AI probability.

---

## Summary Detection Checklist

**CRITICAL (Any one = Very High/Certain AI):**
- [ ] Citation artifacts ([oai_citation:0], utm_source=openai)
- [ ] Response artifacts ("Certainly! Here is...", "Based on the information provided")
- [ ] "It's worth noting" + "Moreover/Furthermore" combination
- [ ] Metadata tells (chatgpt.com URLs, attached_file markers)

**HIGH (3+ = Very High AI Probability):**
- [ ] "Moreover" or "Furthermore" used 2+ times
- [ ] "IT'S NOT X, IT'S Y" pattern (2+ instances)
- [ ] Triple lists (3+ instances of exactly 3 items)
- [ ] Buzzwords: "Revolutionary", "Cutting-edge", "Seamless", "Game-changing" (2+ different)
- [ ] "Navigate/Navigating the landscape of..."
- [ ] Em dashes without spaces (3+ instances)
- [ ] Generic opening pattern ("In today's rapidly evolving...")

**MEDIUM (5+ = Medium-High AI Probability):**
- [ ] "Crucial", "Vital", "Paramount" (emphasis overload)
- [ ] "Delve into", "Harness", "Bolster" (formal action verbs)
- [ ] Uniform sentence length (StdDev <6 words)
- [ ] Immediate list structures without preamble
- [ ] Excessive bold highlighting
- [ ] False casual tone ("Let's face it", "Here's the thing")
- [ ] Perfect grammar, zero typos in 800+ words
- [ ] Hook question opening ("Have you ever wondered?")

---

## Detection Confidence Levels

| Signals Present | AI Probability | Confidence |
|-----------------|----------------|------------|
| 1-2 MEDIUM | 30-50% | Low |
| 3-4 MEDIUM | 50-70% | Medium |
| 1 HIGH + 2 MEDIUM | 70-85% | High |
| 2+ HIGH | 85-95% | Very High |
| 3+ HIGH OR 1 CRITICAL | 95-99% | Near Certain |
| Citation/Metadata artifact | 100% | Certain |

---

**For alternatives and rewrites, see `alternatives-guide.md`.**
**For cultural differences USA vs other contexts, see `cultural-context.md`.**
**For severity logic and context-aware rules, see `detection-framework.md`.**
