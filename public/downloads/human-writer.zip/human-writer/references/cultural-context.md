# Cultural Context Guide - Italian vs USA Professional Writing

Understanding cultural differences in professional communication to avoid AI tells that come from applying English (USA) norms to Italian contexts, and vice versa.

---

## Core Cultural Differences

### Italy: Relationship-First Culture
- **Trust building precedes business**
- Formal titles essential (Dott., Ing., Prof.)
- Long, eloquent sentences valued (shows education)
- Passion and emotion appropriate in professional contexts
- Progression from "Lei" (formal you) to "tu" (informal you) is meaningful
- Face-to-face or phone preferred over email for important matters

### USA: Efficiency-First Culture
- **Get to the point quickly**
- First names immediately, even with executives
- Brief = professional; long = wasting time
- Emotional detachment in business contexts
- Everyone is equal (egalitarian surface, at least)
- Email preferred for documentation

### AI Error Pattern
**LLMs default to USA norms** because English training data dominates. When generating Italian business content, AI often applies American tone, which sounds:
- Cold and transactional
- Inappropriately informal
- Lacking proper respect markers
- Too brief (Italian professional writing is more elaborate)

---

## Italian Professional Communication Style

### 1. Formal Titles Are Non-Negotiable

**Italian Expectation:**
- **Dott.** (Dottore) - Anyone with a university degree
- **Ing.** (Ingegnere) - Engineering degree
- **Avv.** (Avvocato) - Lawyer
- **Prof.** (Professore) - University professor or high school teacher
- **Arch.** (Architetto) - Architect

**AI Error**: Omitting titles or using first names too quickly.

**Examples:**

❌ **AI (USA style in Italian)**:
"Ciao Marco, ti scrivo per discutere il progetto."

✅ **Human Italian Professional (first contact)**:
"Gentile Dott. Rossi, La contatto per discutere il progetto di cui abbiamo parlato."

**Timeline for Lei → tu transition:**
- First contact: Always "Lei"
- After several meetings/emails: May shift if other person initiates
- Senior to junior: Senior may offer "tu", junior cannot initiate
- Peer-to-peer: Usually stays "Lei" unless informal industry (startups, creative)

---

### 2. Opening and Closing Formulas

**Italian Professional Standard:**

**Openings (email/letter):**
- Formal: "Gentile Dott. [Last Name]" or "Egregio Dott. [Last Name]"
- Less formal but still professional: "Buongiorno Dott. [Last Name]"
- After relationship established: "Buongiorno [First Name]" (still with "Lei" in body)

**Closings:**
- Very formal: "Distinti saluti", "Cordiali saluti"
- Professional standard: "Cordiali saluti"
- Warm professional: "Un cordiale saluto"
- After relationship: "Un caro saluto"

**AI Error**: Using USA-style casual closings in Italian.

❌ AI (too casual): "A presto!", "Ciao!", "Buona giornata!"
✅ Human: "Cordiali saluti"

---

### 3. Sentence Length and Elaboration

**Italian Professional Norm:**
- **Longer, more elaborate sentences** show education and sophistication
- Multiple subordinate clauses are normal
- Average sentence: 25-35 words (vs English 15-20)

**AI Error**: Too-short sentences that sound abrupt or uneducated in Italian.

**Examples:**

❌ **AI (too brief for Italian professional)**:
"Il progetto è pronto. Lo invio domani. Fammi sapere cosa ne pensi."

✅ **Human Italian Professional**:
"Il progetto, dopo un'attenta revisione con il team, è ora pronto per essere inviato. Glielo farò pervenire entro domani mattina, e sarò lieto di ricevere i Suoi feedback e le Sue eventuali osservazioni."

**Note**: This is NOT wrong to be brief in Italian, but professional contexts expect more elaboration. Brevity can signal:
- Lack of education
- Dismissiveness
- Urgency/emergency
- Inappropriate casualness

---

### 4. Emotional Expression

**Italian Professional Context:**
- Passion is POSITIVE (shows investment, care)
- Appropriate to express enthusiasm genuinely
- Frustration can be voiced (but diplomatically)
- Humor is valued in professional relationships

**USA Professional Context:**
- Emotional detachment is professional
- Enthusiasm must be measured
- Never show frustration
- Humor risky in formal contexts

**AI Error**: USA-style emotional detachment in Italian sounds cold.

**Examples:**

❌ **AI (USA tone in Italian - too detached)**:
"Il progetto procede secondo i piani. I risultati sono soddisfacenti."

✅ **Human Italian (appropriate passion)**:
"Il progetto sta andando davvero bene! Siamo molto soddisfatti dei risultati ottenuti finora, e il team è particolarmente motivato."

---

### 5. Disagreement and Criticism

**Italian Style:**
- Indirect, wrapped in politeness
- Use of subjunctive mood for softening ("sarebbe meglio se...")
- Preserve face (avoid direct "you are wrong")
- Build up before criticism

**USA Style:**
- Direct feedback valued (allegedly)
- "I disagree because..." is acceptable
- Brevity in criticism

**Examples:**

❌ **AI (too direct for Italian)**:
"Non sono d'accordo. Questo approccio non funziona."

✅ **Human Italian Professional**:
"Capisco il ragionamento, e sicuramente ci sono aspetti validi. Tuttavia, mi chiedo se non potrebbe essere utile valutare anche un approccio alternativo, considerando che [reasons]."

---

## USA Professional Communication Style

### 1. Brevity = Professionalism

**USA Norm**: Respect others' time by being concise.

**Email structure:**
- Subject line: Clear, actionable
- First sentence: Purpose of email
- Body: 2-4 short paragraphs max
- Close: Next step/action item

**AI Error**: Overly elaborate language in USA business contexts.

❌ **AI (too elaborate for USA)**:
"I hope this message finds you well and that you and your team are enjoying continued success. I am writing to you today to inquire about the possibility of scheduling a meeting at your earliest convenience to discuss the various aspects of our ongoing collaboration."

✅ **Human USA Professional**:
"Hi John, Can we schedule 30 minutes this week to discuss the Q3 roadmap? Let me know what works for you. Thanks, Sarah"

---

### 2. Egalitarian Surface (First Names)

**USA Norm**: Use first names immediately, even with CEO.

**Exception**: Academic contexts (Dr., Professor), legal (Judge), medical (Dr.)

**AI sometimes gets this wrong by**:
- Being too formal in casual USA contexts
- Or too casual in the few formal USA contexts that exist

---

### 3. Action Orientation

**USA Professional Writing:**
- Lead with ask/action item
- Data supports action
- Next steps explicit
- Timeline clear

**Italian Professional Writing:**
- Context and relationship come first
- Data embedded in narrative
- Next steps implied or softly suggested
- Timeline more flexible

**Examples:**

**USA Style:**
```
Subject: Approval needed - Q3 Budget

Hi Maria,

Please review the attached Q3 budget by Friday.

Key changes:
- Marketing +15%
- R&D -5%

Let me know if you have questions.

Thanks,
John
```

**Italian Style:**
```
Subject: Budget Q3 - Richiesta di Revisione

Gentile Dott.ssa Bianchi,

Le scrivo in merito al budget del terzo trimestre, che abbiamo elaborato considerando le priorità discusse nell'ultimo incontro.

Come potrà vedere dal documento allegato, abbiamo incrementato la voce Marketing del 15%, in linea con gli obiettivi di crescita, mentre abbiamo ottimizzato alcune voci R&D (-5%), senza compromettere i progetti strategici.

Sarei lieto di ricevere i Suoi feedback entro venerdì prossimo, se possibile, così da poter finalizzare il piano.

Resto a disposizione per eventuali chiarimenti.

Cordiali saluti,
Giovanni Rossi
```

---

## False Friends - Stilistic (Falsi Amici Stilistici)

Words that exist in both languages but have different connotations, frequency, or usage patterns in professional contexts.

### Italian → English Traps

| Italian Word | Literal English | Why It's a Trap | Better Alternative |
|--------------|-----------------|-----------------|-------------------|
| **Attualmente** | Actually | Means "currently", not "actually" | Currently, at present |
| **Eventualmente** | Eventually | Means "possibly", not "eventually" | Possibly, if needed |
| **Conveniente** | Convenient | Often means "affordable", not "convenient" | Affordable (cost) / Handy (convenience) |
| **Sensibile** | Sensible | Means "sensitive", not "sensible" | Sensitive |
| **Libreria** | Library | Means "bookstore", not "library" | Bookstore |
| **Agenda** | Agenda | Means "calendar/planner", not "agenda" | Calendar (IT) / Agenda (EN meeting topics) |
| **Fattoria** | Factory | Means "farm", not "factory" | Farm |
| **Magazzino** | Magazine | Means "warehouse", not "magazine" | Warehouse |

**AI Error Pattern**: Literal translation creates awkward phrasing.

**Example:**

❌ AI (literal translation):
IT: "Attualmente stiamo lavorando al progetto."
EN (AI translation): "Actually we are working on the project."

✅ Human:
EN: "We're currently working on the project."

---

### English → Italian Traps

| English Word | Literal Italian | Why It's a Trap | Better Alternative |
|--------------|-----------------|-----------------|-------------------|
| **To realize** | Realizzare | In Italian means "to create/build", not "to understand" | Rendersi conto (to realize/understand) |
| **To pretend** | Pretendere | Means "to demand/claim", not "to pretend" | Fingere (to pretend) |
| **Preservative** | Preservativo | Means "condom", not "preservative" | Conservante (food preservative) |
| **Educated** | Educato | Means "polite", not "educated" | Istruito (educated) |
| **To assist** | Assistere | Often means "to witness/attend", not "to help" | Aiutare (to help/assist) |

**AI Error Pattern**: Direct translation creates embarrassing or confusing statements.

---

## Motivational/Inspirational Tone

### USA Professional (Common)

**Characteristics:**
- Individual achievement celebrated
- "You can do it!" messaging
- Goal-oriented, competitive framing
- Personal responsibility emphasized

**Examples:**
- "Unlock your potential"
- "Become the leader you were meant to be"
- "Transform your life today"
- "Don't wait—start now!"

**Context**: Acceptable in coaching, self-help, some business contexts (especially startups, sales)

---

### Italian Professional (Rare/Inappropriate)

**Why it doesn't work:**
- Sounds like American self-help (foreign, not authentic)
- Italian culture values collective success, relationships
- Can seem arrogant or naive
- Professionalism = measured, not hyperbolic

**AI Error**: Applying USA motivational tone to Italian business content.

**Examples:**

❌ **AI (USA motivational style in Italian)**:
"Supera i tuoi limiti! Diventa il leader che hai sempre sognato di essere! Trasforma la tua vita oggi! 🚀"

✅ **Human Italian Professional**:
"Il percorso di leadership richiede impegno e la capacità di costruire relazioni solide con il proprio team. Lavoreremo insieme per sviluppare queste competenze."

**Key Differences:**
- AI: Individual heroism, hyperbolic
- Human IT: Collective process ("insieme"), measured, relationship-focused

---

## Industry-Specific Variations

### Startups & Tech (Both IT & USA)

**More casual** than traditional business:
- First names quicker (even in Italy)
- "Tu" arrives faster (Italy)
- Emoji acceptable in some contexts
- English terms mixed in (especially Italy tech)

**But still**: Italian startups maintain more formality than USA equivalents.

---

### Legal, Banking, Government (Both IT & USA)

**Highly formal**:
- Titles mandatory
- Elaborate language (even in USA, relatively)
- Conservative tone

**Italy**: Even MORE formal; USA legal still more concise than Italian legal.

---

### Creative Industries (Both)

**More personality**:
- Casual tone acceptable
- Humor valued
- Less rigid structure

**But**: Italian creative still uses "Lei" initially; USA creative uses first names immediately.

---

## LinkedIn Cultural Differences

### USA LinkedIn Norms

**Post Style:**
- Personal story (vulnerability trending)
- Brief paragraphs (mobile-friendly)
- Clear takeaway/lesson
- Call-to-action (engage with question)
- Emoji moderate use
- Hashtags: 3-5 targeted

**Tone**: Authentic, vulnerable, motivational

---

### Italian LinkedIn Norms (Evolving)

**Traditional Italian Professional:**
- More formal, less personal
- Focus on company/industry news
- Longer paragraphs
- Less call-to-action

**Emerging (Mimicking USA, often via AI):**
- Personal stories (but often feels forced)
- Emoji (overused by AI)
- Motivational tone (sounds foreign)

**AI Detection Signal**: Italian LinkedIn post with USA viral structure + emoji + motivational tone = Very High AI probability.

**Example - AI-Generated Italian LinkedIn Post:**

❌ **AI (USA structure in Italian)**:
```
🚀 La Lezione Più Importante Della Mia Carriera 🚀

3 anni fa ho fatto un errore che mi ha cambiato.

❌ Non ascoltare il team
✅ Collaborare sempre
✅ Essere umile

Oggi sono un leader migliore. 💪

Qual è stata la tua lezione più importante?

#leadership #crescita #motivazione #business #innovazione
```

**AI Tells:**
- Emoji structure (systematic)
- Title Case in Italian heading
- USA-style vulnerability/lesson format
- Checklist structure with emoji
- Motivational muscle emoji
- Generic hashtags

✅ **Human Italian Professional LinkedIn**:
```
Tre anni fa ho commesso un errore che mi ha insegnato molto.

Avevamo un progetto cruciale e, convinto di avere la soluzione migliore, ho ignorato i dubbi del team. Risultato? Abbiamo perso il cliente più importante.

Da allora ho imparato che ascoltare non è debolezza, è intelligenza. Le migliori decisioni le abbiamo prese insieme, non da soli.

#leadership #teamwork #impresaitaliana
```

**Human Markers:**
- Natural narrative without emoji
- Specific story with consequences
- Measured reflection
- Targeted, relevant hashtags
- No checklist/formulaic structure

---

## Formality Spectrum by Context

### Italian Contexts (Most → Least Formal)

1. **Legal, Government, Banking** - Highest formality
   - "Lei" always, titles mandatory
   - Elaborate syntax
   - Conservative tone

2. **Traditional Corporate (large Italian firms)** - High formality
   - "Lei" standard, titles used
   - Professional distance maintained

3. **Modern Corporate / Consulting** - Medium-High formality
   - "Lei" initially, may shift to "tu" after relationship
   - Titles used at first

4. **Tech / Startups** - Medium formality
   - "Lei" initially, shifts to "tu" relatively quickly
   - Titles sometimes omitted in internal comms

5. **Creative / Agency** - Lower formality
   - "Tu" arrives quickly
   - More casual language, but still more formal than USA equivalent

**Key**: Even the most casual Italian professional context is more formal than typical USA business context.

---

### USA Contexts (Most → Least Formal)

1. **Legal / Academic / Medical** - Highest formality (but still less than Italian equivalent)
   - Use titles (Dr., Professor, Judge)
   - More elaborate language
   - Conservative tone

2. **Traditional Corporate / Finance** - Medium formality
   - First names, but measured tone
   - Professional detachment

3. **Modern Corporate / Tech** - Low-Medium formality
   - First names immediately
   - Casual but professional

4. **Startups / Creative** - Very casual
   - First names, sometimes nicknames
   - Humor, personality encouraged
   - Very brief communication

**Key**: USA baseline is more casual; formality is exception, not norm.

---

## AI Detection Signals Related to Culture

### Critical Cultural AI Tells (Italian)

1. **USA motivational tone in Italian professional context**
   - "Supera i tuoi limiti!", "Trasforma la tua vita!"
   - Signal: Very High AI probability

2. **Missing titles in first contact**
   - "Ciao Marco" instead of "Gentile Dott. Rossi"
   - Signal: High AI probability (or foreign writer)

3. **Too-brief sentences in professional context**
   - Reads abrupt/uneducated in Italian
   - Signal: Medium-High AI probability

4. **Inappropriate emoji use in formal contexts**
   - Business proposal with 🚀 and ✅
   - Signal: High AI probability

5. **Title Case in Italian headings**
   - "Come Ottimizzare La Tua Strategia"
   - Signal: Very High AI probability (English rule applied)

---

### Critical Cultural AI Tells (English)

1. **Overly formal in casual context**
   - "Dear Sir/Madam" in startup email
   - Signal: Medium AI probability (or non-native)

2. **Excessive elaboration in USA business**
   - 300-word email for simple request
   - Signal: Medium AI probability

3. **Formulaic USA business buzzwords**
   - "Leverage synergy for transformative outcomes"
   - Signal: High AI probability (mimicking corporate speak training data)

---

## Summary Checklist - Cultural Appropriateness

### When Writing in Italian Professional Context:

- [ ] Use titles (Dott., Ing.) at first contact
- [ ] Start with "Gentile [Title] [Last Name]"
- [ ] Use "Lei" (formal you) unless relationship established
- [ ] Sentences 25-35 words average (elaborate, not brief)
- [ ] Close with "Cordiali saluti" or similar formal closing
- [ ] Show appropriate passion/enthusiasm (not detached)
- [ ] Avoid USA-style motivational imperatives
- [ ] No Title Case in Italian headings
- [ ] Emoji rare or absent in formal contexts
- [ ] Apply VARIATIO principle (no word repetition)

### When Writing in USA Professional Context:

- [ ] Use first names (unless legal/academic/medical)
- [ ] Brief = respectful (2-4 paragraph emails)
- [ ] Lead with action item/ask
- [ ] Measured emotional tone (professional detachment)
- [ ] Clear next steps and timeline
- [ ] Subject line actionable
- [ ] Avoid excessive formality (unless context demands)
- [ ] Emoji rare in most professional contexts (more common in tech/startups)

---

**For language-specific AI patterns, see `italian-errors-database.md` and `english-errors-database.md`.**
**For detection severity logic, see `detection-framework.md`.**
