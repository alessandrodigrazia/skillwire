# Italian AI Writing Patterns - Complete Database

Comprehensive database of AI writing tells in Italian, based on quantitative research and detection patterns. Organized by severity and category for systematic analysis.

---

## TIER BAN - Never Use (Critical Severity 🔴)

These terms and patterns are immediate red flags for AI-generated content. Use frequency is 5-10x higher in AI compared to human writing.

### Connectors & Transitions (Congiunzioni e Connettivi)

| Term | AI Frequency | Detection Impact | Context Notes |
|------|--------------|------------------|---------------|
| **Inoltre** | 5-8x higher | Very High | #1 AI connector overused |
| **Tuttavia** | 4-6x higher | Very High | Formal alternative to "ma" overused |
| **Nonostante** | 3-5x higher | High | Despite - formal overuse |
| **Infatti** | 4-6x higher | High | In fact - overused for emphasis |
| **In conclusione** | 80%+ AI articles | Critical | Generic closing formula |
| **Per concludere** | 75%+ AI articles | Critical | Automatic conclusion marker |
| **In sintesi** | 70%+ AI articles | Critical | Summary formula |
| **In definitiva** | 4-5x higher | High | Ultimately - corporate speak |
| **D'altro canto** | 3-4x higher | Medium-High | On the other hand - formal |
| **È interessante notare che** | ChatGPT signature | **CRITICAL** | Hallmark ChatGPT phrase |
| **Vale la pena menzionare** | ChatGPT signature | **CRITICAL** | "Worth mentioning" literal translation |
| **È importante sottolineare** | 6-8x higher | Very High | Emphasis crutch |
| **Occorre evidenziare** | 5-7x higher | High | Academic overuse |

**Quick Rule**: If you see 3+ of these connectors in a single article, AI probability >85%.

---

### Aspirational & Marketing Adjectives (Aggettivi Inflazionati)

| Term | AI Frequency | Industry | Why It's an AI Tell |
|------|--------------|----------|---------------------|
| **Innovativo** | **10x higher** | Business/Tech | Most overused buzzword |
| **Rivoluzionario** | 8-9x higher | Marketing | Revolutionary - empty hype |
| **Trasformativo** | 7-8x higher | Business | Transformative - corporate |
| **Dinamico** | 5-6x higher | General | Dynamic - vague filler |
| **Cruciale** | **Top 3** overused | All contexts | Crucial - AI emphasis addiction |
| **Fondamentale** | 6-7x higher | Academic/Business | Fundamental - overstatement |
| **Strategico** | 5-6x higher | Business | Strategic - everything is strategic |
| **Essenziale** | 4-5x higher | All contexts | Essential - exaggeration |
| **Significativo** | 5-6x higher | Academic | Significant - statistical term overused |
| **Rilevante** | 4-5x higher | Academic | Relevant - academic overuse |

**Detection Pattern**: AI uses 2-3 of these per paragraph. Human writers: 0-1 per article.

---

### Formal Academic Terms (TIER CONTEXTUAL)

These are acceptable in academic/technical contexts but are red flags in casual, web, or conversational content when overused (>2 per article in non-academic text).

**Category 1: Process & Action Terms**
- Ottimizzazione (Optimization)
- Integrazione (Integration)
- Massimizzare (Maximize)
- Minimizzare (Minimize)
- Agevolare (Facilitate)
- Implementazione (Implementation)
- Contestualizzare (Contextualize)

**Category 2: Problem Framing**
- Problematica (Issue/problem - formal noun)
- Criticità (Critical issue)
- Sfida (Challenge - overused)

**Category 3: Choice & Degree**
- Optare (Opt for)
- Probabilmente (Probably - hedge word)
- Sostanzialmente (Substantially)
- Primariamente (Primarily)
- Essenzialmente (Essentially)
- Prevalentemente (Predominantly)

**Category 4: Analysis Terms**
- Scenario (Scenario)
- Contesto (Context - overused)
- Approccio (Approach)
- Strategia (Strategy)
- Soluzione (Solution - everything is a "solution")
- Metodologia (Methodology)
- Framework (Framework - often untranslated)

**Category 5: Descriptive Qualifiers**
- Notevole / Notevolmente (Notable/Notably)
- Considerevole (Considerable)
- Complessivo (Overall/Comprehensive)
- Potenziale (Potential - noun or adjective overuse)
- Tendenza (Trend)
- Fenomeno (Phenomenon)

**Category 6: Components**
- Aspetto (Aspect)
- Elemento (Element)
- Fattore (Factor)
- Parametro (Parameter)
- Componente (Component)

**Severity Rule**:
- Academic paper: OK to use freely
- Business article: Max 3-4 different terms total
- Blog/Casual: 0-1, otherwise sounds robotic
- >5 in a single article (non-academic) = Very High AI probability

---

### Unnatural Anglicisms (Calchi Stilistici)

Italian AI models often translate English expressions literally, creating unnatural Italian:

| Anglicism | Why Unnatural | Human Alternative |
|-----------|---------------|-------------------|
| **Elevare** (elevate) | Too literal from "elevate the discussion" | Migliorare, arricchire, portare a un livello superiore |
| **Ottimale** | Overused for "migliore" | Migliore, ideale, più adatto |
| **Implementare** | IT jargon overused | Realizzare, attuare, applicare, mettere in pratica |
| **Focalizzare** | Literal "to focus" | Concentrarsi su, porre l'attenzione su |
| **Deliverable** (untranslated) | English in Italian text | Risultato, prodotto consegnabile |
| **Topic** (untranslated) | English word | Argomento, tema, questione |
| **Step-by-step** | English phrase | Passo dopo passo, gradualmente |

---

## Opening Formulas (ABSOLUTE BAN 🔴)

These opening patterns appear in **80%+ of AI-generated Italian articles**. They are the #1 detection method.

### Top 10 Critical Openings

1. **"In un mondo in cui..."** (In a world where...)
   - Appears in 80%+ AI marketing/business articles
   - Detection: CRITICAL

2. **"Nell'era di/della..."** (In the era of...)
   - Variations: "Nell'era digitale", "Nell'era dell'AI", "Nell'era moderna"
   - Detection: CRITICAL

3. **"In un mondo sempre più [aggettivo]..."**
   - [connesso, digitale, complesso, globalizzato, competitivo, tecnologico]
   - Detection: CRITICAL

4. **"Nel vasto e complesso scenario..."** ⚠️ TRIPLE BUZZWORD ALERT
   - Combines: vasto (vague) + complesso (buzzword) + scenario (overused)
   - Detection: CRITICAL - 95%+ AI probability

5. **"In un contesto sempre più..."**
   - Variations: "dinamico", "competitivo", "sfidante"
   - Detection: Very High

6. **"Nel cuore della rivoluzione..."**
   - "digitale", "tecnologica", "AI"
   - Detection: High

7. **"Nel panorama [settore]..."**
   - "aziendale", "digitale", "economico"
   - Detection: High

8. **"Oggigiorno / Al giorno d'oggi..."**
   - Dated formal expression, rarely used by modern Italian speakers
   - Detection: Medium-High

9. **"È innegabile che..."** (It's undeniable that...)
   - Persuasive formula overused by AI
   - Detection: High

10. **"Non è un segreto che..."** (It's no secret that...)
    - Another persuasive opener
    - Detection: Medium-High

### 100+ Opening Formula Variations (Grep Pattern)

Any opening matching these patterns = HIGH AI probability:

```regex
^(In un mondo|Nell'era|Nel panorama|Nel contesto|Nello scenario|Nel cuore|In un contesto sempre più|Oggigiorno|Al giorno d'oggi|È innegabile|Non è un segreto|In questa era|Ai giorni nostri)
```

**Human Alternative**: Start directly with the topic. No grand contextual setup needed.

**Example:**
- ❌ AI: "In un mondo sempre più digitale, le aziende devono innovare."
- ✅ Human: "Le aziende italiane stanno investendo il 23% in più in tecnologia rispetto al 2023."

---

## Antithesis Patterns (Pattern di Antitesi)

AI loves binary opposition structures. Appears in **60%+ of persuasive AI texts**.

### Primary Patterns

1. **"Non si tratta di X, ma di Y"**
   - Frequency: Very High (60%+ persuasive articles)
   - Example: "Non si tratta di tecnologia, ma di persone"
   - Detection: HIGH

2. **"Non è solo X. È Y."**
   - Dramatic separation for emphasis
   - Example: "Non è solo un tool. È una rivoluzione."
   - Detection: HIGH

3. **"Non basta X. Serve Y."**
   - Imperative variation
   - Example: "Non basta ottimizzare. Serve trasformare."
   - Detection: Medium-High

4. **"X non significa Y, significa Z"**
   - Definition antithesis
   - Detection: Medium

**Why It's an AI Tell**: While antithesis is a valid rhetorical device, AI overuses it systematically. Human writers use it sparingly for true contrast. AI uses it as a crutch in every article.

**Rule**: More than 1 antithesis per article (non-rhetorical context) = AI flag.

---

## Structural Patterns (Pattern Strutturali)

### 1. Triple Structure (Struttura Ternaria)

**AI Pattern**: Always organizes in groups of 3 (never 2, never 4).

**Examples:**
- "veloce, affidabile, sicuro"
- "innovazione, efficienza, sostenibilità"
- "analizzare, ottimizzare, implementare"

**Why It's AI**:
- Comes from training on marketing copy (rule of three)
- AI applies it mechanically to every list
- Human writers vary: sometimes 2, sometimes 4-5 items

**Detection Rule**: 3+ instances of exactly-3-item lists in one article = Very High AI probability.

---

### 2. Gerund Chains (Catene di Gerundi)

**AI Pattern**: 3-4 gerunds per sentence.

**Example:**
❌ "Ottimizzando le risorse, implementando nuove strategie, monitorando i risultati e adattando l'approccio, le aziende possono crescere."

**Human Pattern**: Max 1-2 gerunds per sentence, varied with other subordinate structures.

**Example:**
✅ "Le aziende crescono quando ottimizzano le risorse e adattano la strategia in base ai risultati."

**Detection**: 3+ gerunds in one sentence = Very High AI probability.

---

### 3. Bullet Points with Emoji (Liste con Emoji)

**AI Pattern**: 70%+ of AI articles use emoji in structured lists.

**Structure:**
- 📊 **Tema 1**: Descrizione
- 🚀 **Tema 2**: Descrizione
- ✅ **Tema 3**: Descrizione

**Why It's AI**:
- Mimics LinkedIn viral posts
- Systematically applied even when inappropriate
- Emoji choice often random or mismatched

**Human Pattern**: Emoji used sparingly, contextually, or not at all in professional articles.

---

### 4. Automatic "Conclusioni" Section

**AI Pattern**: 80%+ of AI articles have a section explicitly titled "Conclusione" or "Conclusioni".

**Structure:**
```
## Conclusione

In conclusione, [ripetizione punti principali]. Il futuro è [aggettivo positivo] per chi saprà [verbo di azione].
```

**Human Pattern**:
- Conclusions integrated naturally without explicit section
- Or titled creatively ("Il futuro", "Prossimi passi", etc.)
- Not formulaic

---

## Typography Errors (Errori Tipografici) - 85% Detection Rate

These errors are **CRITICAL** for Italian AI detection. English typographic rules applied incorrectly to Italian.

### 1. Capitals After Colons (Maiuscole dopo i Due Punti)

**AI Error**: Capitalizing after colons (English rule).

**Examples:**
- ❌ AI: "Il problema è chiaro: La soluzione richiede innovazione."
- ✅ Human: "Il problema è chiaro: la soluzione richiede innovazione."

**Rule**: In Italian, lowercase after colon unless it's a proper noun or title.

**Exception**: After colon introducing a complete independent sentence, capitals are acceptable in some editorial styles, but lowercase is more common in web content.

**Detection**: 3+ instances = Very High AI probability (85%+).

---

### 2. Title Case in Headings (Title Case nei Titoli)

**AI Error**: Applying English Title Case to Italian headings.

**Examples:**
- ❌ AI: "Come Ottimizzare La Tua Strategia SEO"
- ✅ Human: "Come ottimizzare la tua strategia SEO"

**Rule**: Italian uses "sentence case" - only capitalize first word and proper nouns.

**Detection**: Title Case in Italian = 90%+ AI probability.

---

### 3. Capitals in Bullet Points After Introductory Colons

**AI Error**:
```
Le strategie includono:
- Ottimizzazione dei processi
- Implementazione di nuove tecnologie
- Monitoraggio costante
```

**Should be** (in most web content):
```
Le strategie includono:
- ottimizzazione dei processi
- implementazione di nuove tecnologie
- monitoraggio costante
```

**Note**: This is more style-dependent. Some editorial guidelines allow capitals. However, AI systematically uses capitals, while human web content often uses lowercase.

---

### 4. Em Dash Usage (Uso del Trattino Lungo —)

**AI Pattern**: Excessive em dashes (—) without surrounding spaces.

**Example:**
❌ AI: "Le aziende—soprattutto quelle innovative—devono adattarsi."

**Human Pattern**:
- Uses em dash less frequently
- Or uses en dash with spaces: "Le aziende – soprattutto quelle innovative – devono adattarsi."
- Or uses parentheses: "Le aziende (soprattutto quelle innovative) devono adattarsi."

**ChatGPT Specific**: Em dash WITHOUT spaces is a ChatGPT hallmark.

---

### 5. Quote Style (Virgolette)

**AI Pattern**: Curved quotes ("...") vs straight quotes ("...").

**Context**: Editorial standard prefers curved, but web content often uses straight. AI systematically uses curved.

**Detection Impact**: Low in isolation, but combined with other signals, reinforces AI authorship.

---

## Syntax Issues (Questioni Sintattiche)

### 1. Uniform Sentence Length

**AI Pattern**: Sentences consistently 15-25 words with little variation.

**Detection Method**:
- Calculate average sentence length
- Calculate standard deviation
- If StdDev < 5 words AND average 15-25 = AI flag

**Human Pattern**: High variation (5-word sentences mixed with 35-word sentences).

---

### 2. Perfect Grammar, Zero Typos

**AI Tell**: In texts >1000 words, zero errors is suspicious.

**Human Reality**:
- Occasional typos (especially in web content)
- Minor grammatical inconsistencies
- Colloquialisms

**Detection**: Perfect grammar + other AI signals = reinforcing evidence.

---

### 3. Passive Voice Avoidance

**AI Pattern**: Uses passive voice **20% less** than human Italian writers.

**Why**: English training bias (English advice: avoid passive). Italian uses passive more naturally.

**Example:**
- ❌ AI (active overload): "Le aziende implementano nuove strategie che migliorano i risultati."
- ✅ Human (natural passive): "Nuove strategie vengono implementate per migliorare i risultati."

---

## VARIATIO Principle Violation (Principio di Variatio)

**Italian Writing Principle**: Never repeat the same word in close proximity. Use synonyms, periphrases, pronouns.

**AI Error**: Repeats the same word due to SEO English bias (keyword optimization).

### Example - Word Repetition

❌ **AI Text**:
"Milano è una città importante. Milano offre molte opportunità. Milano attrae talenti da tutta Italia."

✅ **Human Text**:
"Milano è una città importante. Il capoluogo lombardo offre molte opportunità. La metropoli attrae talenti da tutta Italia."

**Variations Used**: Milano → capoluogo lombardo → metropoli → città meneghina

---

### Common Repetition Errors

| Repeated Word | Human Variations |
|---------------|------------------|
| Azienda | Impresa, società, organizzazione, realtà aziendale, gruppo |
| Tecnologia | Innovazione tecnica, strumenti digitali, soluzioni tech, sistemi |
| Cliente | Consumatore, utente, acquirente, destinatario del servizio |
| Problema | Criticità, questione, sfida, ostacolo, difficoltà |
| Soluzione | Risposta, approccio, strategia, via d'uscita, risoluzione |

**Detection Rule**: Same non-functional word repeated 3+ times in 200 words = AI flag.

**Exception**: Technical terms that must be repeated for precision (e.g., "intelligenza artificiale" in an AI article).

---

## Tone Issues - USA Style in Italian (Tono Americano in Italiano)

### 1. Motivational Imperatives (Imperativi Motivazionali)

**AI Pattern**: USA-style motivational language inappropriate for Italian professional contexts.

**Examples:**
- ❌ "Supera i tuoi limiti!"
- ❌ "Diventa il leader che hai sempre sognato di essere!"
- ❌ "Trasforma la tua vita oggi!"

**Why Inappropriate**:
- Italian professional culture is more formal and relationship-based
- This tone sounds like American self-help, not Italian business
- Comes from English training data

**Human Italian Alternative**:
- More measured, less hyperbolic
- Focus on collaboration, not individual heroism
- "Miglioriamo insieme i risultati" vs "Supera i tuoi limiti!"

---

### 2. Disproportionate Enthusiasm with Structural Emoji

**AI Pattern**:
```
🚀 Sei pronto per la rivoluzione digitale?

✅ Innovazione
✅ Trasformazione
✅ Crescita esponenziale

Non aspettare! 💪
```

**Why It's AI**:
- Mimics LinkedIn viral post structure
- Emoji + enthusiasm + buzzwords = triple AI tell
- Inappropriate tone for most professional Italian contexts

---

### 3. Excessive Superlatives

**AI Pattern**: Every product is "il migliore", every solution is "rivoluzionaria", every approach is "innovativo".

**Human Pattern**: Measured claims, specific benefits, data-driven statements.

**Example:**
- ❌ AI: "La nostra soluzione rivoluzionaria è la migliore sul mercato."
- ✅ Human: "La nostra soluzione ha ridotto i costi del 23% per clienti del settore manifatturiero."

---

## LinkedIn Italy Specific Patterns

### Viral Post Structure (70%+ AI-generated)

**Pattern:**
```
[Emoji] + [Enthusiastic Title] + [Emoji]

Breve introduzione provocatoria.

📊 Punto 1
🚀 Punto 2
✅ Punto 3

[Hashtag generici] #innovazione #crescita #business
```

**AI Tells**:
1. Emoji structure systematically applied
2. Generic content without personal experience
3. No call-to-action or personal question
4. Hashtags inappropriate or over-generic
5. Triple structure (always 3 points)

**Human Pattern**:
- Starts with personal story/experience
- Specific data or case study
- Authentic voice, potential imperfections
- Asks genuine question to audience
- Targeted hashtags

---

## Quantitative Detection Data

### Frequency Multipliers (AI vs Human)

| Term/Pattern | AI Frequency | Detection Confidence |
|--------------|--------------|----------------------|
| "Inoltre" | 5-8x | Very High |
| "Innovativo" | 10x (business) | Very High |
| "Cruciale" | 6-8x | High |
| Opening formulas | 80%+ AI articles | Critical |
| Capitals after colons | 85%+ detection | Critical |
| Title Case | 90%+ detection | Critical |
| Triple lists (3+ instances) | 75%+ AI articles | Very High |
| Antithesis (2+ instances) | 60%+ AI persuasive | High |

### Vocabulary Reduction

- **AI**: 30-31% vocabulary reduction compared to human writers
- **Explanation**: AI repeats preferred terms; humans use richer synonyms
- **Detection**: Calculate unique words / total words ratio

---

## Grep Patterns for Quick Detection

Use these regex patterns to scan text files for AI tells:

### Critical Patterns
```regex
# Opening formulas
^(In un mondo|Nell'era|Nel panorama|Oggigiorno)

# Signature phrases
(È interessante notare|Vale la pena menzionare|È importante sottolineare)

# Conclusion formulas
(In conclusione|Per concludere|In sintesi|In definitiva)

# Capitals after colons (context needed)
: [A-Z][a-z]
```

### High-Frequency Terms
```regex
\b(Inoltre|Tuttavia|Nonostante|Infatti)\b
\b(Innovativo|Rivoluzionario|Cruciale|Fondamentale)\b
\b(Ottimizzazione|Implementazione|Massimizzare)\b
```

### Structural Patterns
```regex
# Triple lists (requires context analysis)
(\w+), (\w+), e (\w+)\.

# Antithesis
Non (si tratta|è solo|basta) .+ (ma|È|Serve)
```

---

## Model-Specific Signatures

### ChatGPT Italian Hallmarks
1. "È interessante notare che" (appears in 40%+ of Italian ChatGPT outputs)
2. Em dash without spaces (—)
3. Immediate structured lists after brief intro
4. Clinical, formal tone even in casual contexts
5. Capitals after colons
6. Title Case in headings

### Claude Italian Patterns
- Generally more natural and conversational
- Less prone to buzzwords
- Still may overuse "tuttavia", "inoltre" in formal mode
- Better at cultural appropriateness

### Gemini Italian Patterns
- More casual, sometimes too informal
- Prefers simple terms over complex ones
- Less systematic in structure
- Can lack depth in professional contexts

---

## False Positives - When to Ignore Flags

### Legitimate Academic/Technical Use
- Research papers, theses: Formal terms are appropriate
- Technical documentation: "Implementazione", "ottimizzazione" are standard
- Legal documents: Formal connectors expected

### Editorial Style Differences
- Some publications require capitals after colons (check style guide)
- Some allow capitals in bullet points
- Title Case may be house style (rare, but possible)

### Cultural Context
- Formal business communication may use "Inoltre", "Tuttavia" moderately
- Official communications legitimately use formal register

**Key Distinction**: Concentration and combination matter. 1-2 flags in appropriate context ≠ AI. 10+ flags in casual content = Very High AI probability.

---

## Summary Detection Checklist

**CRITICAL (Any one = Very High AI Probability):**
- [ ] Opening formula ("In un mondo in cui...", "Nell'era di...")
- [ ] "È interessante notare che" or "Vale la pena menzionare"
- [ ] Capitals after colons (3+ instances)
- [ ] Title Case in Italian headings
- [ ] Citation artifacts or metadata tells

**HIGH (3+ = Very High AI Probability):**
- [ ] "Inoltre" used 3+ times
- [ ] "Innovativo", "Cruciale", "Rivoluzionario" (2+ buzzwords)
- [ ] Antithesis pattern "Non X ma Y" (2+ instances)
- [ ] Triple lists (3+ instances of exactly 3 items)
- [ ] Generic "Conclusione" section with formula
- [ ] Gerund chains (3+ gerunds in sentence)

**MEDIUM (5+ = Medium-High AI Probability):**
- [ ] Formal academic terms in casual context (5+ different terms)
- [ ] Word repetition violating VARIATIO (3+ repetitions)
- [ ] Uniform sentence length (StdDev <5)
- [ ] Excessive emoji in professional context
- [ ] USA motivational tone in Italian
- [ ] Perfect grammar, zero typos in 1000+ words

---

**For detailed alternatives and rewrites, see `alternatives-guide.md`.**
**For cultural context on Italian vs USA tone, see `cultural-context.md`.**
