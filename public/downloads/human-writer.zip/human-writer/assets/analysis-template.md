# Analysis Output Template

Structured template for presenting text analysis results. Use this format to ensure consistent, comprehensive reporting of AI writing patterns detected.

---

## SECTION 1: Executive Summary

```markdown
# AI Writing Analysis Report

**Text Analyzed**: [Title or first 50 characters]
**Language**: [Italian / English / Mixed]
**Word Count**: [number]
**Content Type**: [Academic / Business / Web Blog / Social Media / Technical / Marketing / Email]
**Target Audience**: [Description]

---

## Summary Assessment

| Metric | Result |
|--------|--------|
| **AI Probability** | [Low / Medium / High / Very High / Near Certain / Certain] ([percentage]%) |
| **Confidence Level** | [Low / Medium / High / Very High] |
| **Critical Issues** | [number] 🔴 |
| **High-Priority Issues** | [number] 🟠 |
| **Medium Issues** | [number] 🟡 |
| **Style Suggestions** | [number] ⚪ |

**Overall Assessment**: [1-2 sentence summary of whether text appears AI-generated and key indicators]

**Context Notes**: [Any relevant context that affects interpretation - e.g., "Formal terms appropriate for academic context" or "USA tone inappropriate for Italian professional audience"]
```

---

## SECTION 2: Detailed Findings

### Template for Each Finding:

```markdown
### 🔴 CRITICAL Issue #[number]: [Pattern Name]

**Pattern Detected**:
"[Exact text from source]"

**Location**:
[Paragraph/sentence number, or "Throughout text" if multiple]

**Why This is an AI Tell**:
[Explanation with frequency data or model signature info]
- [Specific reason 1]
- [Specific reason 2]

**Context Assessment**:
[Is this appropriate for the content type/audience? Why or why not?]

**Alternative - Human-Like Version**:
"[Specific rewrite suggestion]"

**Example Before → After**:
❌ **AI**: "[Original problematic text]"
✅ **Human**: "[Improved version]"

**Impact**: [High / Very High / Critical - explains importance of fixing this]

---
```

Repeat for each issue, grouped by severity level.

---

## SECTION 3: Annotated Original Text

```markdown
## Annotated Original Text

[Present the original text with inline annotations]

**Legend**:
- 🔴 = CRITICAL issue
- 🟠 = HIGH priority issue
- 🟡 = MEDIUM issue (context-dependent)
- ⚪ = STYLE suggestion

---

[Original text with markers]

Example:

🔴 "In un mondo in cui la tecnologia evolve rapidamente, 🟠 è interessante notare che le aziende devono 🟡 ottimizzare le loro strategie. 🟠 Inoltre, 🟠 l'innovazione è cruciale. 🔴 In conclusione, il futuro è promettente."

🔴 Opening formula (CRITICAL)
🟠 ChatGPT signature phrase (HIGH)
🟡 Overused formal term (MEDIUM)
🟠 "Inoltre" - 5-8x AI frequency (HIGH)
🟠 "Cruciale" - Top 3 overused (HIGH)
🔴 Generic conclusion formula (CRITICAL)
```

---

## SECTION 4: Optimized Version

```markdown
## Humanized Version - Complete Rewrite

[Provide full rewrite that eliminates all CRITICAL and HIGH issues, addresses MEDIUM issues where appropriate, maintains original meaning]

**Changes Summary**:
1. [Major change 1 and why]
2. [Major change 2 and why]
3. [Major change 3 and why]
[etc.]

**Preservation Notes**:
- ✅ Original meaning maintained
- ✅ Key information preserved
- ✅ Factual accuracy unchanged
- [Any other relevant preservation notes]

---

[Full rewritten text]
```

---

## SECTION 5: Educational Insights

```markdown
## Key Takeaways - Why These Patterns Matter

### Most Impactful Changes
1. **[Change 1]**: [Explanation of why this was critical]
2. **[Change 2]**: [Explanation of impact]
3. **[Change 3]**: [Explanation of principle involved]

### Principles Applied

**[Principle 1 - e.g., VARIATIO]**:
[Brief explanation of principle and how it was applied]

**[Principle 2 - e.g., Cultural Appropriateness]**:
[Brief explanation and application]

**[Principle 3 - e.g., Context-Aware Formality]**:
[Brief explanation and application]

### AI Writing Patterns to Avoid in Future

**For This Content Type** ([content type]):
- ❌ Avoid: [Pattern 1]
- ❌ Avoid: [Pattern 2]
- ❌ Avoid: [Pattern 3]
- ✅ Instead: [Alternative approach]

### Detection Confidence Breakdown

**Why AI Probability is [percentage]%**:

**CRITICAL Indicators** ([number] found):
- [List each with brief note]

**HIGH Indicators** ([number] found):
- [List each with brief note]

**MEDIUM Indicators** ([number] found):
- [List each with brief note]

**Mitigating Factors** (if any):
- [Any factors that reduce AI probability]

**Calculation**:
```
Score = (CRITICAL × 30) + (HIGH × 10) + (MEDIUM × 3) [± context adjustment]
= ([breakdown])
= [total score] points → [AI Probability Level]
```
```

---

## COMPLETE EXAMPLE - Italian Text

```markdown
# AI Writing Analysis Report

**Text Analyzed**: "Nell'era digitale, è interessante notare..."
**Language**: Italian
**Word Count**: 87
**Content Type**: Business Blog Article
**Target Audience**: Italian business professionals

---

## Summary Assessment

| Metric | Result |
|--------|--------|
| **AI Probability** | Very High (88%) |
| **Confidence Level** | Very High |
| **Critical Issues** | 3 🔴 |
| **High-Priority Issues** | 5 🟠 |
| **Medium Issues** | 4 🟡 |
| **Style Suggestions** | 2 ⚪ |

**Overall Assessment**: This text exhibits multiple critical AI writing patterns including ChatGPT signature phrases, formulaic opening/closing, and excessive buzzword concentration. Very high probability of AI generation.

**Context Notes**: Business blog context requires conversational, specific language. The generic formal tone and USA-style motivational elements are inappropriate for Italian professional audience.

---

## Detailed Findings

### 🔴 CRITICAL Issue #1: Generic Opening Formula

**Pattern Detected**:
"Nell'era digitale"

**Location**:
Opening sentence (paragraph 1)

**Why This is an AI Tell**:
Opening formulas like "Nell'era di..." appear in 80%+ of AI-generated Italian articles. This pattern:
- Provides generic context instead of starting with substance
- Delays actual topic
- Signals LLM tendency to set broad context before specifics

**Context Assessment**:
Inappropriate for business blog. Italian professional readers expect direct engagement with topic, not grand contextual setup. This opening is a CRITICAL red flag.

**Alternative - Human-Like Version**:
Start with specific data, problem, or story relevant to the topic.

**Example Before → After**:
❌ **AI**: "Nell'era digitale, le aziende devono innovare."
✅ **Human**: "Le aziende italiane hanno investito 4,2 miliardi in digitale nel 2024."

**Impact**: CRITICAL - Immediate tell, sets wrong tone for entire piece.

---

### 🔴 CRITICAL Issue #2: ChatGPT Signature Phrase

**Pattern Detected**:
"è interessante notare che"

**Location**:
Paragraph 1, second sentence

**Why This is an AI Tell**:
This phrase is a hallmark ChatGPT signature in Italian, appearing in 40%+ of Italian ChatGPT outputs:
- Literal translation of "it's worth noting"
- Unnatural in Italian professional writing
- Unnecessary emphasis marker

**Context Assessment**:
Completely inappropriate. No Italian business professional uses this phrase. CRITICAL AI tell.

**Alternative - Human-Like Version**:
Remove entirely and state fact directly, or use "In particolare" if transition needed.

**Example Before → After**:
❌ **AI**: "È interessante notare che il 60% delle aziende ha investito in AI."
✅ **Human**: "Il 60% delle aziende ha investito in AI."

**Impact**: CRITICAL - 95%+ probability indicator of ChatGPT generation.

---

### 🔴 CRITICAL Issue #3: Generic Conclusion Formula

**Pattern Detected**:
"In conclusione"

**Location**:
Final paragraph

**Why This is an AI Tell**:
Explicit conclusion markers appear in 80%+ of AI articles:
- Formulaic structure
- Unnecessary signposting (conclusion should be evident)
- AI tendency to organize rigidly

**Context Assessment**:
Inappropriate for blog article. Human writers integrate conclusions naturally or use creative closings.

**Alternative - Human-Like Version**:
Remove marker, state conclusion directly or creatively.

**Example Before → After**:
❌ **AI**: "In conclusione, il futuro è digitale."
✅ **Human**: "A conti fatti, chi non investe in digitale rischia di restare indietro."

**Impact**: CRITICAL - Combined with other tells, confirms AI authorship.

---

### 🟠 HIGH Issue #4: "Inoltre" Overuse

**Pattern Detected**:
"Inoltre" appears 3 times in 87 words

**Location**:
Paragraphs 1, 2, 3

**Why This is an AI Tell**:
"Inoltre" (moreover/furthermore) is used 5-8x more frequently in AI Italian writing:
- AI overuses explicit connectors
- Human Italian uses varied transitions or restructures sentences

**Context Assessment**:
In blog article, even 1 instance is noticeable. 3 instances in short text = HIGH severity.

**Alternative - Human-Like Version**:
Replace with "Allo stesso tempo", "Anche", or restructure to avoid explicit connector.

**Example Before → After**:
❌ **AI**: "Le aziende innovano. Inoltre, investono in formazione."
✅ **Human**: "Le aziende innovano e investono in formazione. Senza training, la tecnologia resta inutilizzata."

**Impact**: HIGH - Strong AI indicator, especially with frequency.

---

### 🟠 HIGH Issue #5: Buzzword Concentration

**Pattern Detected**:
"innovativo", "cruciale", "trasformativo" - 3 different buzzwords in 87 words

**Location**:
Throughout text

**Why This is an AI Tell**:
- "Innovativo": 10x more frequent in AI business content
- "Cruciale": Top 3 most overused AI adjective
- "Trasformativo": 7-8x AI frequency
- Concentration: AI uses 2-3 per paragraph; humans 0-1 per article

**Context Assessment**:
Highly inappropriate for blog. Buzzwords are empty hype, lack specificity.

**Alternative - Human-Like Version**:
Replace with specific claims backed by data or concrete descriptions.

**Example Before → After**:
❌ **AI**: "La nostra soluzione innovativa è cruciale per la trasformazione digitale."
✅ **Human**: "La nostra soluzione riduce i costi operativi del 40% grazie all'automazione dei processi manuali."

**Impact**: HIGH - Combined buzzword concentration is strong AI tell.

---

[Continue for remaining HIGH and MEDIUM issues...]

---

## Annotated Original Text

**Legend**:
- 🔴 = CRITICAL issue
- 🟠 = HIGH priority issue
- 🟡 = MEDIUM issue
- ⚪ = STYLE suggestion

---

🔴 "Nell'era digitale, 🔴 è interessante notare che le aziende devono 🟡 ottimizzare le loro 🟡 strategie. 🟠 Inoltre, 🟠 l'innovazione è 🟠 cruciale per restare competitivi. 🟠 Tuttavia, 🟡 l'implementazione richiede investimenti significativi. 🔴 In conclusione, la 🟠 trasformazione digitale è 🟡 fondamentale per il futuro."

**Annotations**:
1. 🔴 "Nell'era digitale" - Opening formula (CRITICAL)
2. 🔴 "è interessante notare che" - ChatGPT signature (CRITICAL)
3. 🟡 "ottimizzare" - Overused formal term (MEDIUM)
4. 🟡 "strategie" - Generic buzzword (MEDIUM)
5. 🟠 "Inoltre" - 5-8x AI frequency (HIGH)
6. 🟠 "innovazione" - 10x in business (HIGH)
7. 🟠 "cruciale" - Top 3 overused (HIGH)
8. 🟠 "Tuttavia" - 4-6x AI frequency (HIGH)
9. 🟡 "implementazione" - Formal overuse (MEDIUM)
10. 🔴 "In conclusione" - Generic formula (CRITICAL)
11. 🟠 "trasformazione digitale" - Buzzword combo (HIGH)
12. 🟡 "fondamentale" - Overused emphasis (MEDIUM)

---

## Humanized Version - Complete Rewrite

**Changes Summary**:
1. **Removed opening formula** - Started with specific data instead of generic context
2. **Eliminated ChatGPT signature** - Direct statement of facts
3. **Replaced all buzzwords** - Used specific, measurable claims
4. **Applied VARIATIO principle** - No word repetition (aziende → imprese)
5. **Removed conclusion formula** - Integrated natural closing with data
6. **Varied sentence length** - From uniform 12-15 words to mix of 9-18 words

**Preservation Notes**:
- ✅ Core message maintained (digital investment requires training and resources)
- ✅ Key themes preserved (technology, investment, training)
- ✅ No factual changes (no new data invented)

---

**Optimized Text**:

"Le aziende italiane hanno investito 4,2 miliardi in digitale nel 2024. Eppure, il 60% non ha ancora un piano chiaro per utilizzare questi strumenti. Il problema? Serve formazione. Senza, ogni euro speso in tecnologia rischia di essere sprecato. I dati lo confermano: le imprese che formano il personale vedono un ROI del 230% superiore rispetto a chi compra software e spera che funzioni."

---

## Key Takeaways - Why These Patterns Matter

### Most Impactful Changes

1. **Opening Formula Removal**: Starting with data (4,2 miliardi) instead of "Nell'era digitale" immediately signals human authorship. This change alone drops AI probability by 20-30%.

2. **ChatGPT Signature Elimination**: "È interessante notare che" is a 95%+ ChatGPT indicator. Removing it eliminates the most critical single tell.

3. **Buzzword Purge**: Replacing "innovativo", "cruciale", "trasformativo" with specific claims (40% cost reduction, 230% ROI) adds credibility and removes AI hype pattern.

### Principles Applied

**VARIATIO (Italian Writing Principle)**:
Original repeated "aziende" 3 times. Revised version varies: "aziende" → "imprese". This is fundamental Italian style.

**Cultural Appropriateness (Italian Professional)**:
Removed USA-style motivational tone, maintained professional but direct Italian business communication style. Data-driven, specific, relationship-aware.

**Show, Don't Tell**:
Instead of saying "cruciale" (tell), showed impact with data: "230% ROI superiore" (show). Concrete evidence replaces vague adjectives.

**Context-Aware Formality**:
Blog context requires conversational accessibility. Removed formal academic terms ("ottimizzazione", "implementazione") and used everyday language ("migliorare", "usare").

### AI Writing Patterns to Avoid in Future

**For This Content Type** (Italian Business Blog):
- ❌ Avoid: Opening formulas ("Nell'era...", "In un mondo...")
- ❌ Avoid: ChatGPT phrases ("È interessante notare")
- ❌ Avoid: Buzzword concentration (>1 per article)
- ❌ Avoid: Explicit connectors overuse ("Inoltre", "Tuttavia" 3+ times)
- ❌ Avoid: Generic conclusions ("In conclusione")
- ✅ Instead: Start with data/problem, use specific claims, vary transitions, integrate conclusions naturally

### Detection Confidence Breakdown

**Why AI Probability is 88% (Very High)**:

**CRITICAL Indicators** (3 found):
1. "Nell'era digitale" opening - 80%+ AI articles
2. "È interessante notare che" - ChatGPT signature
3. "In conclusione" - Formulaic closing

**HIGH Indicators** (5 found):
1. "Inoltre" 3x - Well above human frequency
2. "innovativo" - 10x AI frequency
3. "cruciale" - Top 3 overused
4. "Tuttavia" - 4-6x AI frequency
5. "trasformazione digitale" - Buzzword combination

**MEDIUM Indicators** (4 found):
1. "ottimizzare" - Formal term in casual context
2. "strategie" - Generic overuse
3. "implementazione" - Formal excess
4. "fondamentale" - Overused emphasis

**Mitigating Factors**: None. All patterns inappropriate for blog context.

**Calculation**:
```
Score = (3 CRITICAL × 30) + (5 HIGH × 10) + (4 MEDIUM × 3)
= 90 + 50 + 12
= 152 points → Very High AI Probability (88%)

Context Adjustment: Business blog (+10 for inappropriate formality)
Final Score: 162 points → Very High AI Probability (90%)
```

**Confidence**: Very High - Multiple critical tells combined with concentration of high-severity patterns across multiple categories. Context makes all patterns inappropriate, no false positive indicators present.
```

---

## Usage Notes

- **Customize sections** based on text length and complexity
- **Include all CRITICAL and HIGH issues** as separate entries
- **Group MEDIUM issues** if numerous (can list in table format)
- **STYLE suggestions** can be summarized briefly
- **Always provide before/after examples** for top 3-5 changes
- **Educational section** helps user learn patterns, not just fix this text
- **Calculation transparency** builds trust in assessment

---

This template ensures comprehensive, educational, actionable analysis that helps users both fix current text and avoid AI patterns in future writing.
