# Workflow Orchestration Guide

**Purpose**: This document provides the **procedural intelligence** for the Sales Methodology Pro system. It tells you WHEN to use each workflow, in WHAT SEQUENCE, and WHY.

**Critical Principle**: The methodology is not a menu of isolated tools. It is an integrated system where each framework builds on previous ones and prepares for the next.

---

## Core Principle: Progressive Value Building

This methodology follows a **progressive value building** approach:

```
RESEARCH → ANALYSIS → STRATEGY → EXECUTION → CAPTURE

Each stage builds the foundation for the next.
Skipping steps weakens the entire process.
```

---

## Workflow Orchestration by User Intent

### Intent: "I need to prepare for a meeting with [Client]"

**Correct Sequence**:

1. **Pre-Research** (`prepare-meeting.md` Step 0)
   - **WHY**: You cannot strategize without understanding the client's context
   - **WHAT**: Company background, industry, strategic priorities, attendees
   - **OUTPUT**: Pre-Research Briefing

2. **C-SWOT Analysis** (`prepare-meeting.md` Step 2 OR `create-cswot.md`)
   - **WHY BEFORE VALUE AREAS**: You must understand client's strengths, weaknesses, opportunities, threats BEFORE you can position your value
   - **WHAT**: 4 quadrants (Strengths, Weaknesses, Opportunities, Threats) with implications
   - **OUTPUT**: C-SWOT document with strategic insights
   - **CRITICAL**: All implications must connect to YOUR value proposition potential

3. **Value Areas Mapping** (`prepare-meeting.md` Step 3)
   - **WHY AFTER C-SWOT**: Now you can map your capabilities to their specific needs identified in C-SWOT
   - **WHAT**: 3-5 value propositions connecting their problems to your solutions
   - **OUTPUT**: Value areas with problem-solution-benefit structure

4. **One-Pager & Email** (`prepare-meeting.md` Step 4)
   - **WHY AFTER VALUE AREAS**: You now have the content to craft a compelling pre-meeting document
   - **WHAT**: Executive summary + 5 value quadrants for email body
   - **OUTPUT**: One-pager document + email template to request meeting

5. **Discovery Questions** (`prepare-meeting.md` Step 5)
   - **WHY AFTER VALUE AREAS**: Questions must validate the hypotheses you have formed about their needs
   - **WHAT**: SPICED framework questions (Situation, Pain, Impact, Critical Event, Decision) - developed by Winning by Design
   - **INCLUDE**: Challenger-style questions that reframe their thinking
   - **OUTPUT**: Categorized question bank with rationales

6. **Battle Plan / Final Briefing** (`prepare-meeting.md` Step 6)
   - **WHY LAST**: Synthesizes all previous work into executable meeting strategy
   - **WHAT**: Meeting objectives (Think-Feel-Do), talking points, Q&A prep
   - **OUTPUT**: Complete briefing for sales team

**NEVER**:
- Skip directly to One-Pager without C-SWOT and Value Areas
- Create discovery questions before understanding their context
- Generate a briefing before doing analysis

### Judgment Checkpoint: Meeting Preparation

**After completing the sequence, PAUSE and verify:**

| Dimension | Verification Question |
|-----------|----------------------|
| **Decision** | Have I clearly defined the Think-Feel-Do objectives for the meeting? |
| **Assumptions** | Are my hypotheses about the client (C-SWOT) based on evidence or speculation? |
| **Alternatives** | Have I considered alternative approaches if the meeting does not go as planned? |
| **Trade-offs** | What compromises have I accepted in the preparation (time vs. depth)? |
| **Confidence** | How confident am I in the value propositions? (High/Medium/Low) |
| **Next Actions** | What are the concrete next steps after the meeting? |

**Red Flags** - Stop if:
- C-SWOT not connected to value propositions
- Buying Committee incomplete (Economic Buyer unknown)
- Discovery questions are generic, not grounded in C-SWOT
- Cannot articulate the "ONE big insight"

**Proceed only if**:
- Value propositions linked to specific C-SWOT findings
- Economic Buyer identified with engagement strategy
- Team briefed on key talking points

---

### Intent: "Help me build a business case for [Solution]"

**Correct Sequence**:

1. **Value Chain Analysis** (`value-chain-analysis.md`) - **DO THIS FIRST**
   - **WHY BEFORE BUSINESS CASE**: Business case needs concrete value elements to quantify
   - **WHAT**: Map ALL value elements (tangible + intangible) your solution provides
   - **OUTPUT**: Comprehensive value chain with cost structure and differentiation
   - **CRITICAL**: This feeds the "Benefits" section of business case with specific, quantified elements

2. **C-SWOT Analysis** (if not already done)
   - **WHY**: Provides context for "Current Situation & Problem" section
   - **WHAT**: Client's challenges that justify the investment
   - **OUTPUT**: Problem statement grounded in client reality

3. **Business Case Generation** (`build-business-case.md`)
   - **WHY AFTER VALUE CHAIN**: Now you have the ingredients to build financial justification
   - **SECTIONS** (generated in order):
     1. Executive Summary (200 words)
     2. Current Situation & Business Problem (from C-SWOT)
     3. Proposed Solution (your offering)
     4. Expected Benefits (from Value Chain - Quantitative, Operational, Strategic)
     5. Required Investment (cost breakdown)
     6. ROI Analysis & Payback Period
     7. Implementation Approach & Timeline
     8. Risk Mitigation
     9. Next Steps & Decision Request
   - **OUTPUT**: Complete C-level business case document

**NEVER**:
- Build business case without doing Value Chain Analysis first
- Generic benefits ("improved efficiency") - always use Value Chain specifics
- Business case without financial quantification

### Judgment Checkpoint: Business Case

**After completing the sequence, PAUSE and verify:**

| Dimension | Verification Question |
|-----------|----------------------|
| **Decision** | Does the business case answer the question "Why invest NOW"? |
| **Assumptions** | Are benefit assumptions documented and verifiable? |
| **Alternatives** | Have I considered alternative scenarios (pessimistic, optimistic)? |
| **Trade-offs** | Have I balanced completeness vs. readability for the CFO? |
| **Confidence** | Are the ROI numbers based on client data or estimates? (High/Medium/Low) |
| **Next Actions** | Who must approve and what is the next step? |

**Red Flags** - Stop if:
- Benefits not quantified in currency/time/%
- ROI calculated without Value Chain Analysis
- Assumptions not documented
- No connection to C-SWOT (problem unclear)

**Proceed only if**:
- All benefits have specific quantification
- ROI, payback, NPV calculated with transparent formula
- A CFO would have sufficient information to decide

---

### Intent: "I need to qualify this opportunity"

**Correct Sequence**:

1. **MEDDPICC+RR Qualification** (`qualify-opportunity.md`)
   - **WHY FIRST**: Determines if opportunity is worth pursuing (GO/NO-GO)
   - **CRITERIA**:
     - **M** - Metrics: Quantifiable measures of success
     - **E** - Economic Buyer: Person with budget authority
     - **D** - Decision Criteria: How they will evaluate options
     - **D** - Decision Process: Steps and timeline to a decision
     - **P** - Paper Process: Legal, procurement, contracts
     - **I** - Identify Pain: Critical business pain driving action
     - **C** - Champion: Internal advocate who sells on your behalf
     - **C** - Competition: Competitive landscape and positioning
     - **R** - Relative Priority: Where the deal ranks among buyer's competing initiatives
     - **R** - Risk Factors: Strategic, organizational, and technical risks to the deal
   - **OUTPUT**: MEDDPICC+RR qualification score, GO/NO-GO/GO WITH CONDITIONS recommendation

2. **IF GO → Buying Committee Mapping** (`map-decision-center.md`)
   - **WHY AFTER MEDDPICC+RR**: Only map Buying Committee if opportunity is worth pursuing
   - **WHAT**: Buying Committee analysis (Champion, Economic Buyer, Technical Buyer, User, Coach)
   - **OUTPUT**: Stakeholder map with influence, position, strategy for each

3. **IF GO → Prepare Meeting** (see sequence above)
   - Continue with full meeting preparation workflow

**NEVER**:
- Spend time on full meeting prep before qualifying opportunity
- Weak MEDDPICC+RR score and still proceed (unless strategic exception)

### Judgment Checkpoint: Opportunity Qualification

**After completing the sequence, PAUSE and verify:**

| Dimension | Verification Question |
|-----------|----------------------|
| **Decision** | Is the GO/NO-GO recommendation clear and justified? |
| **Assumptions** | Are the MEDDPICC+RR scores based on evidence or impressions? |
| **Alternatives** | Have I considered "GO WITH CONDITIONS" if borderline? |
| **Trade-offs** | Have I balanced sales optimism vs. realism? |
| **Confidence** | How confident am I in the qualification? (High/Medium/Low) |
| **Next Actions** | If GO, what are the first 3 concrete steps? |

**Red Flags** - Stop if:
- Critical gaps in 3+ MEDDPICC+RR criteria without documented strategic exception
- No Champion identified
- Budget not confirmed for deal > $50K
- Client urgency not validated

**Proceed only if**:
- GO/NO-GO decision clear with evidence for each criterion
- If GO, Buying Committee mapping as next step
- Conditions for GO documented if score is borderline

---

### Intent: "Analyze this RFQ/tender document"

**Correct Sequence** (Multi-Deliverable Approach):

**PHASE 1: Preliminary Analysis**
1. **Administrative Analysis** (`analyze-rfq.md` Deliverable 1)
   - **WHY FIRST**: Must know if we CAN bid (eligibility, certifications, deadlines)
   - **OUTPUT**: Compliance checklist, disqualification risks

2. **Technical Analysis** (`analyze-rfq.md` Deliverable 2)
   - **WHY SECOND**: Must know if we can DELIVER (technical capabilities, gaps)
   - **OUTPUT**: Requirements matrix, gap analysis, differentiation opportunities

3. **Economic Analysis** (`analyze-rfq.md` Deliverable 3)
   - **WHY THIRD**: Must know if we can WIN PROFITABLY (pricing, terms, risks)
   - **OUTPUT**: Pricing strategy, TCO analysis, financial risks

**PHASE 2: Strategic Synthesis**
4. **Holistic Analysis** (`analyze-rfq.md` Deliverable 4)
   - **WHY AFTER ALL 3 ANALYSES**: Synthesizes findings into strategic decision
   - **OUTPUT**: Win themes, red flags, positioning strategy, GO/NO-GO recommendation

**PHASE 3: Action Deliverables** (IF GO)
5. **Clarification Questions Email** (`analyze-rfq.md` Deliverable 5)
   - **WHY**: Address gaps and ambiguities identified in analyses
   - **OUTPUT**: Professional email to procurement office

6. **Compliance Checklist** (`analyze-rfq.md` Deliverable 6)
   - **WHY**: Track requirement-by-requirement compliance during proposal development
   - **OUTPUT**: Master tracking checklist

7. **Technical-Economic Response Draft** (`analyze-rfq.md` Deliverable 7)
   - **WHY LAST**: Creates proposal skeleton with all RFQ section references
   - **OUTPUT**: Compliant proposal outline ready for team development

**NEVER**:
- Skip straight to proposal writing without analyses
- Make GO/NO-GO decision without completing all 3 preliminary analyses
- Submit clarification questions before completing analyses (you do not know what to ask yet)

---

### Intent: "Prepare for negotiation with [Client]"

**Prerequisite Check**:
- Do you have a proposal on the table? (If NO, not ready for negotiation workflow)
- Has client indicated acceptance in principle? (If NO, too early)
- Are you entering contract/commercial discussions? (If NO, wrong workflow)

**Correct Sequence**:

1. **BATNA Analysis** (`prepare-negotiation.md` Step 2)
   - **WHY FIRST**: Establishes your power position and walk-away point
   - **WHAT**: Your Best Alternative to a Negotiated Agreement (Fisher & Ury) vs. their best alternative
   - **OUTPUT**: Power assessment (who needs whom more)

2. **ZOPA Definition** (`prepare-negotiation.md` Step 3)
   - **WHY AFTER BATNA**: Defines the range where deal is mathematically possible
   - **WHAT**: Your walk-away price to their maximum budget (Fisher & Ury)
   - **OUTPUT**: ZOPA visualization, target settlement range

3. **Objectives Definition** (`prepare-negotiation.md` Step 4)
   - **WHY**: Defines what you want at 3 levels (Ideal, Acceptable, Walk-Away)
   - **WHAT**: All negotiable variables (price, terms, scope, timeline, SLA, etc.)
   - **OUTPUT**: 3-level objectives table

4. **Trading Variables** (`prepare-negotiation.md` Step 5)
   - **WHY**: Prepares If-Then Trading conditional concessions
   - **WHAT**: High-value-to-them/low-cost-to-us trades
   - **OUTPUT**: Trading matrix with planned concession sequence

5. **Power Dynamics & Tactics** (`prepare-negotiation.md` Step 6)
   - **WHY**: Prepares for their tactics and defines yours
   - **WHAT**: Defensive counters (good cop/bad cop, deadline pressure) + offensive moves
   - **OUTPUT**: Tactical playbook

6. **Team Strategy** (`prepare-negotiation.md` Step 7)
   - **WHY**: Defines roles for coordinated team approach
   - **WHAT**: 5 roles (Leader, Vice, Observer, Manager, Expert) with responsibilities
   - **OUTPUT**: Team coordination plan with private signals

7. **Scenario Planning** (`prepare-negotiation.md` Step 8)
   - **WHY LAST**: Practice responses to likely scenarios
   - **WHAT**: Role-play scripts for common situations
   - **OUTPUT**: Scenario response scripts

**NEVER**:
- Enter negotiation without knowing your BATNA and ZOPA
- Make concessions without getting something in return (always If-Then Trading)
- Negotiate alone if deal >$100K (use team approach)

### Judgment Checkpoint: Negotiation Preparation

**After completing the sequence, PAUSE and verify:**

| Dimension | Verification Question |
|-----------|----------------------|
| **Decision** | Have I clearly defined what I want to achieve (Ideal/Acceptable/Walk-Away)? |
| **Assumptions** | Are my estimates of ZOPA and negotiation power realistic? |
| **Alternatives** | Do I have a solid BATNA if the negotiation fails? |
| **Trade-offs** | Are the trading variables balanced (give and get)? |
| **Confidence** | How prepared am I for the client's tactics? (High/Medium/Low) |
| **Next Actions** | Is the team briefed on roles and private signals? |

**Red Flags** - Stop if:
- BATNA not clearly defined
- ZOPA is negative or unrealistic (gap too wide)
- Trading variables are one-sided (only concessions, no gains)
- Team not aligned on roles and limits

**Proceed only if**:
- BATNA and ZOPA defined with specific numbers
- At least 5 trading variables prepared with If-Then conditions
- Team briefed (if deal > $100K)
- Exit strategy clear if walk-away point is reached

---

### Intent: "Create a presentation for [Client/Opportunity]"

**Prerequisite Check**: What analyses have been done?

**Correct Sequence**:

1. **Gather Foundation** (`presentation-builder.md` Step 1)
   - **REQUIRED INPUTS**:
     - C-SWOT analysis (for "Your Challenges" slides)
     - Value Areas or Value Chain (for "Our Solution Benefits" slides)
     - Business Case (for "ROI & Investment" slides)
     - MEDDPICC+RR if available (for "Why Now" urgency slides)
   - **WHY**: Presentation content must come from prior analyses, not created from scratch

2. **Define Outline** (`presentation-builder.md` Step 2)
   - **WHAT**: Select structure based on audience and objective
   - **OPTIONS**:
     - Problem-Solution-Value (for new opportunities)
     - Strategic Partnership (for C-level)
     - Technical Solution (for IT/technical audiences)
     - Business Case Presentation (for investment decisions)
   - **OUTPUT**: Approved slide outline with timing

3. **Generate Content** (`presentation-builder.md` Step 3)
   - **WHAT**: Create slide content + speaker notes for each slide
   - **INCLUDE**: Visual suggestions (charts, diagrams, icons)
   - **OUTPUT**: Complete slide deck with detailed speaker notes

4. **Review & Refine** (`presentation-builder.md` Step 4)
   - **WHAT**: Iterate on slides, reorder, regenerate as needed
   - **OUTPUT**: Final presentation ready for formatting

**NEVER**:
- Build presentation without foundational analyses (C-SWOT, Value Areas, Business Case)
- Generic "company overview" presentations (always client-specific)
- Slides without speaker notes (notes should be 2-3x slide content)

---

### Intent: "Summarize this meeting / Create follow-up"

**Correct Sequence**:

1. **Post-Meeting Summary** (`generate-post-meeting-summary.md`)
   - **TWO MODES**:
     - **Client Memo**: Professional summary for customer sharing
     - **Internal Report**: Detailed notes for CRM and internal team
   - **WHAT**: Meeting recap, decisions made, action items, next steps
   - **INCLUDE**: Mutual Action Plan with specific deadlines
   - **OUTPUT**: Formatted memo ready for email or CRM

2. **Update Opportunity Data**:
   - **MEDDPICC+RR**: Re-score if significant new information emerged
   - **Buying Committee**: Update stakeholder positions if dynamics changed
   - **Business Case**: Update if new financials or timelines discussed

**NEVER**:
- Generic "thank you for the meeting" emails
- Meeting summary without clear next steps and owners

---

## Framework Dependencies Map

### Before Business Case, MUST Have:
1. Value Chain Analysis (provides quantified benefits)
2. C-SWOT Analysis (provides problem statement)

### Before Presentation, MUST Have:
1. At least one of: C-SWOT, Value Areas, Business Case
2. Clear audience definition

### Before Negotiation, MUST Have:
1. Proposal submitted and acknowledged
2. Client indication of interest/acceptance in principle

### Before RFQ Response, MUST Have:
1. All 3 preliminary analyses (Admin, Technical, Economic)
2. Holistic analysis with GO/NO-GO decision

---

## Methodology Integration Points

### 4-Phase Sales Conversation - Individual Sales Conversations
**Use when**: Single meeting, discovery conversation, relationship building
**Key Frameworks**:
- SPICED Discovery (Winning by Design) (in `prepare-meeting.md` Step 5)
- FAB Translation (Features-Advantages-Benefits) (in Value Areas, Value Chain)
- Trust Equation (Maister/Green) building (relationship-first approach)

**Integration Point**: The 4-Phase Sales Conversation is embedded in meeting preparation workflows

---

### 7-Phase Strategic Selling - Complex Multi-Stakeholder Deals
**Use when**: Deal >$100K, multiple stakeholders, 3+ month sales cycle
**Key Frameworks**:
- **MEDDPICC+RR** (multi-criteria qualification) → `qualify-opportunity.md`
- **Buying Committee** (stakeholder mapping) → `map-decision-center.md`
- **C-SWOT** (client-focused analysis) → `prepare-meeting.md` Step 2 or `create-cswot.md`
- **Competitive Strategy** (5 strategies) → embedded in RFQ holistic analysis

**Integration Point**: MEDDPICC+RR is the gateway - if qualification is GO, proceed through other frameworks

---

### 5-Phase Negotiation - Contract Discussions
**Use when**: Deal terms being negotiated, contract phase
**Key Frameworks**:
- **BATNA** (Best Alternative to a Negotiated Agreement, Fisher & Ury) → `prepare-negotiation.md` Step 2
- **ZOPA** (Zone of Possible Agreement, Fisher & Ury) → `prepare-negotiation.md` Step 3
- **Trading Variables** → `prepare-negotiation.md` Step 5
- **Team Roles** (Leader, Vice, Observer, Manager, Expert) → `prepare-negotiation.md` Step 7

**Integration Point**: Only use after proposal acceptance in principle

---

## Decision Tree: What to Do When

```
USER REQUEST → INTENT CLASSIFICATION → PREREQUISITE CHECK → ORCHESTRATED WORKFLOW

Examples:

"Prepare for meeting with Acme Corp"
  → Intent: Meeting Preparation
  → Check: Do we have company context? (If NO, start with research)
  → Workflow: prepare-meeting.md (Steps 0-6 in sequence)

"Build business case for Cloud Migration project"
  → Intent: Business Case
  → Check: Have we done Value Chain Analysis? (If NO, DO THAT FIRST)
  → Workflow: value-chain-analysis.md → build-business-case.md

"Should we pursue this RFQ?"
  → Intent: Opportunity Qualification + RFQ Analysis
  → Check: Is this RFQ or direct opportunity? (RFQ = analyze-rfq.md)
  → Workflow: analyze-rfq.md (Deliverables 1-4 for GO/NO-GO)

"Negotiate with client on pricing"
  → Intent: Negotiation Preparation
  → Check: Is proposal accepted in principle? (If NO, too early)
  → Workflow: prepare-negotiation.md (Steps 1-8 in sequence)
```

---

## Proactive Guidance Principles

### When User Requests Single Framework, Ask:
"Before we create [X], have you completed [prerequisite Y]? It will make [X] much more effective."

**Examples**:
- User: "Create a business case"
  - You: "Before we build the business case, have you done a Value Chain Analysis? It will provide the quantified benefits we need for the business case. Would you like me to do that first?"

- User: "Generate a one-pager for this client"
  - You: "Before we create the one-pager, have we done a C-SWOT analysis to understand their specific challenges and opportunities? That will make the one-pager much more targeted."

- User: "Help me prepare for negotiation"
  - You: "Before we prepare negotiation strategy, can you confirm: (1) Has your proposal been submitted? (2) Have they indicated acceptance in principle? If not, we should focus on proposal refinement first."

### When User Skips Critical Step, Interrupt:
"I notice you're asking for [X] without [prerequisite Y]. In this methodology, [Y] always precedes [X] because [reason]. Should we do [Y] first, or do you already have it completed?"

### When Multiple Paths Exist, Offer Choice:
"I see you want to [objective]. You have two paths:
- **Path A**: [Quick approach] - Takes [time], provides [outcome]
- **Path B**: [Comprehensive approach] - Takes [time], provides [outcome]

Based on your timeline and goals, which would you prefer?"

---

## Workflow Combination Strategies

### Common Combinations

**New Opportunity - Full Cycle**:
1. MEDDPICC+RR Qualification → (if GO) →
2. Buying Committee Mapping →
3. Prepare Meeting (with C-SWOT, Value Areas, Discovery Questions) →
4. Meeting Execution →
5. Post-Meeting Summary + Update MEDDPICC+RR →
6. Build Business Case (with Value Chain Analysis) →
7. Present to Decision Committee →
8. Negotiate Terms →
9. Close Deal

**RFQ Response - Full Cycle**:
1. RFQ Analysis (Admin, Technical, Economic, Holistic) → (if GO) →
2. Clarification Questions Email →
3. Compliance Checklist Creation →
4. Value Chain Analysis (for benefits section) →
5. Technical-Economic Response Draft →
6. Proposal Development (team effort using checklist + draft) →
7. Presentation (if required) →
8. Negotiate Terms (if shortlisted) →
9. Contract Award

**Quick Meeting Prep - Minimal Cycle**:
1. Pre-Research →
2. C-SWOT Analysis →
3. Value Areas →
4. Discovery Questions →
5. Quick briefing (skip formal battle plan)

---

## Success Metrics: Is the Methodology Being Followed?

**Correct Application**:
- Workflows used in documented sequence
- Prerequisites checked before proceeding
- No steps skipped without explicit user override
- Output from one workflow feeds input to next
- User understands WHY each step matters

**Incorrect Application**:
- User jumps to deliverable without foundation
- Generic outputs not grounded in client analysis
- Workflows used in isolation (not integrated)
- Prerequisites ignored
- User does not understand methodology logic

---

**This orchestration guide ensures the Sales Methodology Pro system is applied as an integrated methodology, not a random collection of tools.**
