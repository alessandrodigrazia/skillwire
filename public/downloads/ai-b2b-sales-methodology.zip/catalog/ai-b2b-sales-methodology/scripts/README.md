# Sales Methodology Pro - Scripts

Executable scripts for deterministic operations in sales workflows.

---

## Overview

These Python scripts provide consistent, reliable calculations and validations for enterprise B2B sales processes. They complement the AI-powered workflows by handling deterministic operations that require exact numerical accuracy.

---

## Available Scripts

### 1. `calculate_roi.py` - Financial Analysis

Calculate ROI, payback period, NPV, and TCO for business cases.

**Use in workflow**: `build-business-case`

**Example**:
```bash
# Simple ROI calculation
python calculate_roi.py \
  --benefits 150000 200000 250000 \
  --initial-investment 200000 \
  --annual-costs 30000 \
  --discount-rate 0.08

# From JSON input file
python calculate_roi.py --input-json business_case_data.json --output json
```

**JSON Input Format**:
```json
{
  "benefits": [150000, 200000, 250000],
  "implementation_costs": {
    "licenses": 100000,
    "services": 80000,
    "hardware": 20000
  },
  "annual_operating_costs": 30000,
  "discount_rate": 0.08,
  "timeframe_years": 3
}
```

**Output**:
- ROI percentage
- Payback period (months)
- NPV (Net Present Value)
- TCO breakdown
- Year-by-year cash flow analysis
- GO/NO-GO recommendation based on financial thresholds

---

### 2. `generate_spiced_questions.py` - Discovery Question Generator

Generate industry-specific SPICED discovery questions (Winning by Design framework).

**Use in workflow**: `prepare-meeting`, `qualify-opportunity`

**Example**:
```bash
# Manufacturing industry
python generate_spiced_questions.py \
  --industry manufacturing \
  --use-case "predictive maintenance" \
  --output markdown

# Finance sector
python generate_spiced_questions.py \
  --industry finance \
  --use-case "digital onboarding" \
  --count 5 \
  --output-file discovery_questions.md
```

**Supported Industries**:
- `manufacturing`
- `finance`
- `retail`
- `healthcare`
- `generic`

**Output**: 15-20 tailored SPICED questions across 5 categories:
- **S**ituation: Current state, context
- **P**ain: Problems and challenges
- **I**mpact: Business consequences
- **CE**: Critical Event - Urgency drivers
- **D**ecision: Process and criteria

---

### 3. `validate_meddpicc.py` - MEDDPICC+RR Qualification Validator

Validate MEDDPICC+RR opportunity qualification completeness and generate GO/NO-GO recommendation.

**Use in workflow**: `qualify-opportunity`

**Example**:
```bash
# Interactive mode
python validate_meddpicc.py --interactive

# From JSON file
python validate_meddpicc.py --input qualification_scores.json --output text
```

**JSON Input Format**:
```json
{
  "metadata": {
    "name": "Cloud Migration - Acme Manufacturing",
    "value": 500000,
    "client": "Acme Manufacturing",
    "owner": "Sales Lead"
  },
  "scores": {
    "metrics": 4,
    "economic_buyer": 5,
    "decision_criteria": 3,
    "decision_process": 4,
    "paper_process": 3,
    "identify_pain": 5,
    "champion": 4,
    "competition": 3,
    "risks": 4,
    "roadblocks": 4
  }
}
```

**MEDDPICC+RR Scoring** (10 criteria):
- Each criterion: 1-5 (1=Red, 3=Yellow, 5=Green)
- Total: 10-50 points
- **STRONG GO**: >= 40 points (80%+)
- **GO**: 30-39 points (60-79%)
- **GO WITH CONDITIONS**: 20-29 points (40-59%)
- **NO-GO**: < 20 points (< 40%)

**Output**:
- Total MEDDPICC+RR score and percentage
- GO/NO-GO decision
- Risk level assessment
- Breakdown (green lights, yellow flags, red flags, critical blockers)
- Recommended actions to improve score

---

## Installation

### Prerequisites

```bash
# Python 3.8 or higher
python --version

# No external dependencies required (uses Python stdlib only)
```

### Make Scripts Executable (macOS/Linux)

```bash
cd scripts/
chmod +x *.py
```

---

## Integration with Workflows

These scripts are designed to be called by Claude during workflow execution for deterministic operations.

### Example: Business Case Workflow

```
User: "Build a business case for $500K cloud migration"

Claude:
  1. Gathers inputs (benefits, costs, timeframe)
  2. Calls calculate_roi.py with collected data
  3. Parses JSON output
  4. Integrates financial analysis into business case template
  5. Presents complete business case with ROI, NPV, payback
```

### Example: MEDDPICC+RR Qualification

```
User: "Qualify this opportunity"

Claude:
  1. Asks 10 MEDDPICC+RR criterion questions
  2. User provides scores (1-5 for each)
  3. Calls validate_meddpicc.py with scores
  4. Receives GO/NO-GO recommendation + action items
  5. Presents qualification report
```

---

## Script Design Principles

All scripts follow these principles (per Anthropic best practices):

1. **Deterministic**: Same input -> Same output (no randomness)
2. **Error Handling**: Explicit error messages for invalid inputs
3. **Standalone**: No external dependencies beyond Python stdlib
4. **CLI & Programmatic**: Usable via command-line or imported as modules
5. **Validated I/O**: All inputs validated before processing
6. **Documented**: Clear docstrings and help text

---

## Testing Scripts

Each script includes `--help` documentation:

```bash
python calculate_roi.py --help
python generate_spiced_questions.py --help
python validate_meddpicc.py --help
```

---

## Extending Scripts

To add new scripts:

1. Follow naming convention: `verb_noun.py` (e.g., `calculate_tco.py`)
2. Include CLI argument parsing with `argparse`
3. Support both JSON input files and CLI args
4. Provide `--help` documentation
5. Add entry to this README
6. Update SKILL.md with reference
