#!/usr/bin/env python3
"""
SPICED Discovery Questions Generator

Generates industry-specific SPICED discovery questions based on:
- Industry vertical (manufacturing, finance, retail, etc.)
- Use case / pain point
- Seller's solution positioning

SPICED Framework:
- S: Situation (current state, context)
- P: Pain (problems, challenges)
- I: Impact (business consequences)
- CE: Critical Event (urgency, deadlines, timing pressures)
- D: Decision (process, criteria)

Usage:
    python generate_spiced_questions.py --industry manufacturing --use-case "predictive-maintenance"
    python generate_spiced_questions.py --input questions_config.json --output markdown
"""

import json
import argparse
from typing import Dict, List


# Question templates organized by SPICED category
QUESTION_TEMPLATES = {
    "situation": [
        "Can you describe your current {process_area} process?",
        "How are you currently handling {pain_point}?",
        "What tools or systems do you use today for {function}?",
        "How is your team organized around {activity}?",
        "What's your current approach to {challenge_area}?",
    ],
    "pain": [
        "What are the main challenges you face with {process_area}?",
        "What's not working as well as you'd like in {function}?",
        "Where do you see bottlenecks in your {workflow}?",
        "What keeps you up at night regarding {concern_area}?",
        "If you could change one thing about your current {system}, what would it be?",
    ],
    "impact": [
        "How does this challenge impact {business_metric}?",
        "Can you quantify the cost of {pain_point} in terms of {metric}?",
        "What's the impact on {stakeholder_group} when {problem} occurs?",
        "How does this affect your ability to {strategic_goal}?",
        "What would a 20% improvement in {kpi} mean for your business?",
    ],
    "critical_event": [
        "Why is addressing this important now vs. 6 months from now?",
        "Are there upcoming deadlines or business events driving this?",
        "What changes in your market are making this more urgent?",
        "Are there regulatory or compliance pressures creating urgency?",
        "What happens if you don't solve this by {timeframe}?",
        "What triggered the decision to address this now?",
        "Are there strategic initiatives or board mandates creating pressure?",
    ],
    "decision": [
        "How do you typically evaluate and select solutions like this?",
        "Who else needs to be involved in this decision?",
        "What criteria will be most important in your evaluation?",
        "What's your expected timeline for making a decision?",
        "Have you allocated budget for this initiative?",
    ]
}


# Industry-specific question templates
INDUSTRY_QUESTIONS = {
    "manufacturing": {
        "situation": [
            "What production planning system do you currently use?",
            "How do you track OEE (Overall Equipment Effectiveness) today?",
            "What's your current approach to preventive vs. predictive maintenance?",
        ],
        "pain": [
            "What percentage of downtime is unplanned vs. planned?",
            "How much time do your teams spend on manual data collection?",
            "What visibility do you have into your supply chain in real-time?",
        ],
        "impact": [
            "What's the cost per hour of unplanned downtime?",
            "How does equipment failure impact your delivery commitments?",
            "What's the impact of quality issues on your margin?",
        ],
        "critical_event": [
            "Are you facing increased customer demands for shorter lead times?",
            "Is Industry 4.0 transformation part of your strategic plan?",
            "Are there upcoming production deadlines that make this urgent?",
        ],
    },
    "finance": {
        "situation": [
            "How are you currently managing customer onboarding (KYC/AML)?",
            "What's your tech stack for digital banking services?",
            "How do you handle fraud detection today?",
        ],
        "pain": [
            "What's your average time for customer onboarding?",
            "How many false positives do you get from your fraud detection system?",
            "What percentage of transactions are manual vs. automated?",
        ],
        "impact": [
            "What's the cost of a security breach or compliance failure?",
            "How does slow onboarding impact customer acquisition?",
            "What's the impact of manual processes on operational costs?",
        ],
        "critical_event": [
            "Are new regulations (e.g., DORA, PSD3) driving urgency?",
            "Is digital transformation on your CEO's agenda for this year?",
            "Are there compliance deadlines you need to meet?",
        ],
    },
    "retail": {
        "situation": [
            "How do you manage inventory across physical and online channels?",
            "What's your current customer data platform?",
            "How do you personalize the customer experience today?",
        ],
        "pain": [
            "What percentage of stockouts do you experience?",
            "How fragmented is your view of the customer across channels?",
            "What's your return rate and how much does it cost you?",
        ],
        "impact": [
            "What revenue do you lose annually due to stockouts?",
            "How does poor personalization impact conversion rates?",
            "What's the cost of excess inventory?",
        ],
        "critical_event": [
            "Are you facing increased competition from digital-native brands?",
            "Is omnichannel integration a strategic priority this year?",
            "Are there seasonal peaks or market pressures driving urgency?",
        ],
    },
    "healthcare": {
        "situation": [
            "How do you currently manage patient data across departments?",
            "What systems do you use for appointment scheduling and resource planning?",
            "How do you ensure compliance with GDPR and health data regulations?",
        ],
        "pain": [
            "How many separate systems do clinicians need to access for patient care?",
            "What's your average wait time for diagnostic results?",
            "How much time do staff spend on administrative tasks vs. patient care?",
        ],
        "impact": [
            "How does fragmented data impact patient outcomes?",
            "What's the cost of inefficient resource utilization?",
            "How do administrative burdens affect staff retention?",
        ],
        "critical_event": [
            "Are you under pressure to improve patient satisfaction scores?",
            "Is digital health transformation mandated by your board?",
            "Are there regulatory requirements or accreditation deadlines?",
        ],
    },
    "generic": {
        "situation": [
            "How do you currently approach {process_area}?",
            "What systems or tools support your {function} today?",
        ],
        "pain": [
            "What are your top 3 challenges in {area}?",
            "Where do you see the biggest inefficiencies?",
        ],
        "impact": [
            "How does this impact your bottom line?",
            "What would a 25% improvement mean to your business?",
        ],
        "critical_event": [
            "What's driving the need to address this now?",
            "Are there time-sensitive factors we should be aware of?",
        ],
    }
}


def generate_spiced_questions(industry: str, use_case: str = None,
                              business_unit: str = None,
                              count_per_category: int = 3) -> Dict[str, List[str]]:
    """
    Generate SPICED discovery questions tailored to industry and use case.

    Args:
        industry: Target industry (manufacturing, finance, retail, healthcare, generic)
        use_case: Specific use case or pain point (optional)
        business_unit: Relevant business unit (optional, for context)
        count_per_category: Number of questions per SPICED category

    Returns:
        Dictionary with SPICED categories as keys and question lists as values
    """
    industry_lower = industry.lower()

    # Select industry-specific questions or fall back to generic
    if industry_lower in INDUSTRY_QUESTIONS:
        industry_qs = INDUSTRY_QUESTIONS[industry_lower]
    else:
        industry_qs = INDUSTRY_QUESTIONS["generic"]

    questions = {}

    for category in ["situation", "pain", "impact", "critical_event", "decision"]:
        qs = []

        # Add industry-specific questions for this category
        if category in industry_qs:
            qs.extend(industry_qs[category][:count_per_category])

        # Fill remaining with generic templates if needed
        remaining = count_per_category - len(qs)
        if remaining > 0 and category in QUESTION_TEMPLATES:
            generic = QUESTION_TEMPLATES[category][:remaining]

            # Customize generic templates if use_case provided
            if use_case:
                generic = [q.replace("{process_area}", use_case)
                          .replace("{pain_point}", use_case)
                          .replace("{function}", use_case) for q in generic]

            qs.extend(generic)

        questions[category] = qs

    return questions


def format_output_markdown(questions: Dict[str, List[str]],
                           metadata: Dict[str, str]) -> str:
    """
    Format SPICED questions as markdown document.

    Args:
        questions: Dictionary of SPICED questions
        metadata: Industry, use case, BU info

    Returns:
        Formatted markdown string
    """
    md = f"""# SPICED Discovery Questions

**Industry**: {metadata.get('industry', 'Generic')}
**Use Case**: {metadata.get('use_case', 'General Discovery')}
**Business Unit**: {metadata.get('business_unit', 'Multiple')}

---

## S - SITUATION (Current State)

Current state, context, and baseline understanding.

"""

    for i, q in enumerate(questions.get("situation", []), 1):
        md += f"{i}. {q}\n"

    md += "\n---\n\n## P - PAIN (Problems & Challenges)\n\nProblems, challenges, and what's not working.\n\n"

    for i, q in enumerate(questions.get("pain", []), 1):
        md += f"{i}. {q}\n"

    md += "\n---\n\n## I - IMPACT (Business Consequences)\n\nQuantified impact on business metrics and objectives.\n\n"

    for i, q in enumerate(questions.get("impact", []), 1):
        md += f"{i}. {q}\n"

    md += "\n---\n\n## CE - CRITICAL EVENT (Urgency & Timing)\n\nEvents, pressures, or deadlines creating urgency and driving the need for action.\n\n"

    for i, q in enumerate(questions.get("critical_event", []), 1):
        md += f"{i}. {q}\n"

    md += "\n---\n\n## D - DECISION (Process & Criteria)\n\nDecision-making process, stakeholders, and criteria.\n\n"

    for i, q in enumerate(questions.get("decision", []), 1):
        md += f"{i}. {q}\n"

    md += "\n---\n\n*Generated by SPICED Question Generator (Winning by Design framework)*\n"

    return md


def main():
    """CLI interface for SPICED question generator."""
    parser = argparse.ArgumentParser(
        description="Generate SPICED discovery questions for B2B enterprise sales"
    )

    parser.add_argument(
        "--industry",
        type=str,
        required=True,
        choices=["manufacturing", "finance", "retail", "healthcare", "generic"],
        help="Target industry vertical"
    )

    parser.add_argument(
        "--use-case",
        type=str,
        help="Specific use case or pain point"
    )

    parser.add_argument(
        "--business-unit",
        type=str,
        help="Relevant business unit (for context)"
    )

    parser.add_argument(
        "--count",
        type=int,
        default=3,
        help="Number of questions per SPICED category (default: 3)"
    )

    parser.add_argument(
        "--output",
        type=str,
        choices=["json", "markdown", "text"],
        default="markdown",
        help="Output format (default: markdown)"
    )

    parser.add_argument(
        "--output-file",
        type=str,
        help="Save output to file instead of stdout"
    )

    args = parser.parse_args()

    # Generate questions
    questions = generate_spiced_questions(
        industry=args.industry,
        use_case=args.use_case,
        business_unit=args.business_unit,
        count_per_category=args.count
    )

    # Format output
    metadata = {
        "industry": args.industry,
        "use_case": args.use_case or "General Discovery",
        "business_unit": args.business_unit or "Multiple"
    }

    if args.output == "json":
        output = json.dumps({"metadata": metadata, "questions": questions}, indent=2)
    elif args.output == "markdown":
        output = format_output_markdown(questions, metadata)
    else:
        # Text format
        output = f"SPICED DISCOVERY QUESTIONS\n"
        output += f"Industry: {metadata['industry']}\n"
        output += f"Use Case: {metadata['use_case']}\n\n"

        for category, qs in questions.items():
            output += f"\n{category.upper()}:\n"
            for i, q in enumerate(qs, 1):
                output += f"  {i}. {q}\n"

    # Output to file or stdout
    if args.output_file:
        with open(args.output_file, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"✅ Questions saved to {args.output_file}")
    else:
        print(output)


if __name__ == "__main__":
    main()
