#!/usr/bin/env python3
"""
ROI Calculator for Business Case Workflows

Calculates financial metrics for B2B enterprise business cases:
- ROI % (Return on Investment)
- Payback Period (months)
- NPV (Net Present Value)
- TCO (Total Cost of Ownership)

Usage:
    python calculate_roi.py --benefits 500000 --costs 200000 --timeframe 36 --discount-rate 0.08

Input: JSON or command-line arguments
Output: Structured financial analysis
"""

import json
import argparse
from typing import Dict, List, Tuple


def calculate_roi(total_benefits: float, total_costs: float) -> float:
    """
    Calculate Return on Investment percentage.

    Formula: ROI = ((Total Benefits - Total Costs) / Total Costs) * 100

    Args:
        total_benefits: Total quantified benefits over project lifetime
        total_costs: Total investment required

    Returns:
        ROI percentage
    """
    if total_costs == 0:
        raise ValueError("Total costs cannot be zero")

    roi = ((total_benefits - total_costs) / total_costs) * 100
    return round(roi, 2)


def calculate_payback_period(initial_investment: float, annual_cash_flow: float) -> float:
    """
    Calculate payback period in months.

    Formula: Payback = (Initial Investment / Annual Cash Flow) * 12

    Args:
        initial_investment: Upfront investment
        annual_cash_flow: Average annual net cash flow from benefits

    Returns:
        Payback period in months
    """
    if annual_cash_flow <= 0:
        raise ValueError("Annual cash flow must be positive")

    payback_years = initial_investment / annual_cash_flow
    payback_months = payback_years * 12
    return round(payback_months, 1)


def calculate_npv(cash_flows: List[float], discount_rate: float, initial_investment: float) -> float:
    """
    Calculate Net Present Value.

    Formula: NPV = Σ(Cash Flow_t / (1 + r)^t) - Initial Investment

    Args:
        cash_flows: List of annual cash flows (benefits - costs per year)
        discount_rate: Discount rate (e.g., 0.08 for 8%)
        initial_investment: Upfront investment

    Returns:
        NPV value
    """
    npv = -initial_investment

    for year, cash_flow in enumerate(cash_flows, start=1):
        discounted_cf = cash_flow / ((1 + discount_rate) ** year)
        npv += discounted_cf

    return round(npv, 2)


def calculate_tco(implementation_costs: Dict[str, float],
                  annual_operating_costs: float,
                  years: int) -> Dict[str, float]:
    """
    Calculate Total Cost of Ownership.

    TCO = Implementation Costs + (Annual Operating Costs * Years)

    Args:
        implementation_costs: Dictionary of one-time costs (licenses, services, hardware)
        annual_operating_costs: Yearly recurring costs (maintenance, support, etc.)
        years: Project lifetime in years

    Returns:
        Dictionary with TCO breakdown
    """
    total_implementation = sum(implementation_costs.values())
    total_operating = annual_operating_costs * years
    total_tco = total_implementation + total_operating

    return {
        "implementation_costs": round(total_implementation, 2),
        "operating_costs": round(total_operating, 2),
        "total_tco": round(total_tco, 2),
        "annual_tco": round(total_tco / years, 2)
    }


def generate_business_case_metrics(input_data: Dict) -> Dict:
    """
    Generate complete financial analysis for a business case.

    Args:
        input_data: Dictionary with:
            - benefits: List of annual benefits
            - implementation_costs: Dict of one-time costs
            - annual_operating_costs: Yearly recurring costs
            - discount_rate: Discount rate for NPV
            - timeframe_years: Project lifetime

    Returns:
        Complete financial metrics dictionary
    """
    # Extract inputs
    benefits = input_data.get("benefits", [])
    impl_costs = input_data.get("implementation_costs", {})
    annual_op_costs = input_data.get("annual_operating_costs", 0)
    discount_rate = input_data.get("discount_rate", 0.08)
    timeframe = input_data.get("timeframe_years", 3)

    # Calculate totals
    total_benefits = sum(benefits)
    initial_investment = sum(impl_costs.values())

    # TCO Analysis
    tco = calculate_tco(impl_costs, annual_op_costs, timeframe)
    total_costs = tco["total_tco"]

    # ROI
    roi = calculate_roi(total_benefits, total_costs)

    # Payback Period
    avg_annual_benefit = sum(benefits) / len(benefits) if benefits else 0
    avg_annual_cost = annual_op_costs
    annual_net_cash_flow = avg_annual_benefit - avg_annual_cost

    if annual_net_cash_flow > 0:
        payback = calculate_payback_period(initial_investment, annual_net_cash_flow)
    else:
        payback = None  # Project doesn't pay back

    # NPV (cash flows = benefits - annual operating costs)
    cash_flows = [b - annual_op_costs for b in benefits]
    npv = calculate_npv(cash_flows, discount_rate, initial_investment)

    # Compile results
    results = {
        "summary": {
            "total_benefits": round(total_benefits, 2),
            "total_costs": round(total_costs, 2),
            "net_value": round(total_benefits - total_costs, 2),
            "roi_percentage": roi,
            "payback_months": payback,
            "npv": npv
        },
        "tco_breakdown": tco,
        "year_by_year": []
    }

    # Year-by-year breakdown
    cumulative_benefit = 0
    cumulative_cost = initial_investment

    for year in range(1, timeframe + 1):
        year_benefit = benefits[year - 1] if year <= len(benefits) else 0
        year_cost = annual_op_costs
        cumulative_benefit += year_benefit
        cumulative_cost += year_cost

        results["year_by_year"].append({
            "year": year,
            "benefit": round(year_benefit, 2),
            "cost": round(year_cost, 2),
            "net_cash_flow": round(year_benefit - year_cost, 2),
            "cumulative_benefit": round(cumulative_benefit, 2),
            "cumulative_cost": round(cumulative_cost, 2),
            "cumulative_net": round(cumulative_benefit - cumulative_cost, 2)
        })

    # Decision recommendation
    if roi > 100 and (payback is None or payback < 24):
        results["recommendation"] = "STRONG GO - Excellent financial case"
    elif roi > 50 and (payback is None or payback < 36):
        results["recommendation"] = "GO - Solid financial justification"
    elif roi > 20:
        results["recommendation"] = "GO WITH CONDITIONS - Moderate returns, consider strategic value"
    else:
        results["recommendation"] = "REVIEW - Financial returns below threshold, strategic justification required"

    return results


def main():
    """CLI interface for ROI calculator."""
    parser = argparse.ArgumentParser(
        description="Calculate ROI metrics for B2B enterprise business cases"
    )

    parser.add_argument(
        "--input-json",
        type=str,
        help="Path to JSON file with complete input data"
    )

    parser.add_argument(
        "--benefits",
        type=float,
        nargs="+",
        help="Annual benefits (space-separated, e.g., 100000 150000 200000)"
    )

    parser.add_argument(
        "--initial-investment",
        type=float,
        help="Initial investment amount"
    )

    parser.add_argument(
        "--annual-costs",
        type=float,
        default=0,
        help="Annual operating costs"
    )

    parser.add_argument(
        "--discount-rate",
        type=float,
        default=0.08,
        help="Discount rate for NPV (default: 0.08 = 8%%)"
    )

    parser.add_argument(
        "--output",
        type=str,
        choices=["json", "text"],
        default="text",
        help="Output format"
    )

    args = parser.parse_args()

    # Load input data
    if args.input_json:
        with open(args.input_json, 'r') as f:
            input_data = json.load(f)
    else:
        # Build from CLI args
        if not args.benefits or not args.initial_investment:
            parser.error("Either --input-json or (--benefits AND --initial-investment) required")

        input_data = {
            "benefits": args.benefits,
            "implementation_costs": {"initial_investment": args.initial_investment},
            "annual_operating_costs": args.annual_costs,
            "discount_rate": args.discount_rate,
            "timeframe_years": len(args.benefits)
        }

    # Calculate metrics
    results = generate_business_case_metrics(input_data)

    # Output
    if args.output == "json":
        print(json.dumps(results, indent=2))
    else:
        # Formatted text output
        print("\n" + "="*60)
        print("  BUSINESS CASE FINANCIAL ANALYSIS")
        print("="*60)

        print(f"\n📊 SUMMARY")
        print(f"  Total Benefits (3Y):  €{results['summary']['total_benefits']:,.2f}")
        print(f"  Total Costs (3Y):     €{results['summary']['total_costs']:,.2f}")
        print(f"  Net Value:            €{results['summary']['net_value']:,.2f}")
        print(f"  ROI:                  {results['summary']['roi_percentage']}%")

        if results['summary']['payback_months']:
            print(f"  Payback Period:       {results['summary']['payback_months']} months")
        else:
            print(f"  Payback Period:       N/A (project doesn't pay back)")

        print(f"  NPV (@ {input_data['discount_rate']*100}%):          €{results['summary']['npv']:,.2f}")

        print(f"\n💰 TCO BREAKDOWN")
        print(f"  Implementation:       €{results['tco_breakdown']['implementation_costs']:,.2f}")
        print(f"  Operating ({input_data['timeframe_years']}Y):        €{results['tco_breakdown']['operating_costs']:,.2f}")
        print(f"  Total TCO:            €{results['tco_breakdown']['total_tco']:,.2f}")

        print(f"\n📅 YEAR-BY-YEAR CASH FLOW")
        print(f"  {'Year':<6} {'Benefit':<15} {'Cost':<15} {'Net CF':<15} {'Cumulative':<15}")
        print(f"  {'-'*66}")

        for year_data in results['year_by_year']:
            print(f"  {year_data['year']:<6} "
                  f"€{year_data['benefit']:>13,.0f} "
                  f"€{year_data['cost']:>13,.0f} "
                  f"€{year_data['net_cash_flow']:>13,.0f} "
                  f"€{year_data['cumulative_net']:>13,.0f}")

        print(f"\n✅ RECOMMENDATION: {results['recommendation']}")
        print("="*60 + "\n")


if __name__ == "__main__":
    main()
