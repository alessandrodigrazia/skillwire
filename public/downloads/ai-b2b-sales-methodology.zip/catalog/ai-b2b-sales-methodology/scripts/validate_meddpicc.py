#!/usr/bin/env python3
"""
MEDDPICC+RR Opportunity Qualification Validator

Validates completeness of MEDDPICC+RR opportunity qualification and generates
GO/NO-GO recommendation.

MEDDPICC+RR 10 Criteria:
1. Metrics - Quantifiable business outcomes the buyer wants to achieve
2. Economic Buyer - Person with authority to approve budget and sign off
3. Decision Criteria - Factors the buyer uses to evaluate options
4. Decision Process - Steps, approvals, and timeline to reach a decision
5. Paper Process - Legal, procurement, and administrative steps to close
6. Identify Pain - Critical business pain driving the initiative
7. Champion - Internal advocate with power and influence
8. Competition - Competitive landscape including status quo
9. Risks - Internal and external deal risks
10. Roadblocks - Organizational, political, or technical obstacles

Framework origin: MEDDIC was originally developed by Jack Napoli and Dick Dunkel
at PTC Corporation. Extended to MEDDPICC by adding Paper Process and Competition,
and further to MEDDPICC+RR by adding Risks and Roadblocks.

Scoring:
- Each criterion: 1-5 (1=Red/Weak, 3=Yellow/Moderate, 5=Green/Strong)
- Total: 10-50 points
- GO threshold: >= 30 points (60%)
- Strong GO: >= 40 points (80%)

Usage:
    python validate_meddpicc.py --input qualification.json
    python validate_meddpicc.py --interactive
"""

import json
import argparse
from typing import Dict, List, Tuple
from enum import Enum


class MEDDPICCCriterion(Enum):
    """MEDDPICC+RR evaluation criteria."""
    METRICS = "metrics"
    ECONOMIC_BUYER = "economic_buyer"
    DECISION_CRITERIA = "decision_criteria"
    DECISION_PROCESS = "decision_process"
    PAPER_PROCESS = "paper_process"
    IDENTIFY_PAIN = "identify_pain"
    CHAMPION = "champion"
    COMPETITION = "competition"
    RISKS = "risks"
    ROADBLOCKS = "roadblocks"


# Criterion descriptions and evaluation rubrics
CRITERION_RUBRICS = {
    MEDDPICCCriterion.METRICS: {
        "name": "Metrics",
        "description": "Are the quantifiable business outcomes clearly defined?",
        "5": "Metrics co-created with buyer, tied to strategic KPIs, baseline established",
        "3": "Some metrics identified but not fully quantified or validated",
        "1": "No clear metrics or business outcomes defined"
    },
    MEDDPICCCriterion.ECONOMIC_BUYER: {
        "name": "Economic Buyer",
        "description": "Have we identified and engaged the person with budget authority?",
        "5": "Economic Buyer identified, engaged, and supportive of the initiative",
        "3": "Economic Buyer identified but not yet directly engaged",
        "1": "Economic Buyer unknown or inaccessible"
    },
    MEDDPICCCriterion.DECISION_CRITERIA: {
        "name": "Decision Criteria",
        "description": "Do we understand how the buyer will evaluate options?",
        "5": "Decision criteria documented, we influenced them, strong alignment with our strengths",
        "3": "Criteria partially known, some alignment with our strengths",
        "1": "Criteria unknown or heavily favor a competitor"
    },
    MEDDPICCCriterion.DECISION_PROCESS: {
        "name": "Decision Process",
        "description": "Do we understand the steps and timeline to reach a decision?",
        "5": "Full process mapped (steps, approvals, timeline), aligned with our plan",
        "3": "General understanding of process but gaps in detail or timeline",
        "1": "Decision process unclear or unpredictable"
    },
    MEDDPICCCriterion.PAPER_PROCESS: {
        "name": "Paper Process",
        "description": "Do we understand the legal, procurement, and admin steps to close?",
        "5": "Paper process mapped, legal/procurement engaged, no blockers anticipated",
        "3": "Paper process partially understood, some steps unclear",
        "1": "Paper process unknown, or known to be lengthy and complex"
    },
    MEDDPICCCriterion.IDENTIFY_PAIN: {
        "name": "Identify Pain",
        "description": "Is there a critical business pain driving the initiative?",
        "5": "Pain quantified, felt at C-level, urgent and compelling",
        "3": "Pain identified at mid-management level, moderate urgency",
        "1": "Pain vague, not quantified, or not felt by decision-makers"
    },
    MEDDPICCCriterion.CHAMPION: {
        "name": "Champion",
        "description": "Is there an internal advocate with power and influence?",
        "5": "Champion actively selling internally, has political capital, invested in our success",
        "3": "Supporter exists but limited influence or not yet fully committed",
        "1": "No champion identified or champion is weak/uncommitted"
    },
    MEDDPICCCriterion.COMPETITION: {
        "name": "Competition",
        "description": "Do we understand the competitive landscape including status quo?",
        "5": "We are preferred or sole provider, clear differentiation, strong relationships",
        "3": "Competitive but differentiated, fair evaluation process",
        "1": "Competitor is incumbent, or we're late to the process, or status quo is winning"
    },
    MEDDPICCCriterion.RISKS: {
        "name": "Risks",
        "description": "Are deal risks identified and mitigable?",
        "5": "Low risk profile, clear mitigation plan for all identified risks",
        "3": "Moderate risks identified, most mitigable with effort",
        "1": "High-risk profile (technical, political, financial, or execution risks)"
    },
    MEDDPICCCriterion.ROADBLOCKS: {
        "name": "Roadblocks",
        "description": "Are there organizational, political, or technical obstacles?",
        "5": "No significant roadblocks, or clear path to remove them",
        "3": "Some roadblocks identified, plan in progress to address them",
        "1": "Major roadblocks (reorg, budget freeze, political resistance, tech debt)"
    }
}


def validate_score(score: int) -> bool:
    """Validate that score is in valid range 1-5."""
    return 1 <= score <= 5


def calculate_meddpicc_score(scores: Dict[str, int]) -> Dict:
    """
    Calculate MEDDPICC+RR total score and generate recommendation.

    Args:
        scores: Dictionary mapping criterion name to score (1-5)

    Returns:
        Dictionary with scoring analysis and recommendation
    """
    # Validate all scores
    for criterion, score in scores.items():
        if not validate_score(score):
            raise ValueError(f"Invalid score for {criterion}: {score}. Must be 1-5.")

    # Calculate total
    total_score = sum(scores.values())
    max_score = len(scores) * 5
    percentage = (total_score / max_score) * 100

    # Categorize scores
    red_flags = [k for k, v in scores.items() if v <= 2]
    yellow_flags = [k for k, v in scores.items() if v == 3]
    green_lights = [k for k, v in scores.items() if v >= 4]

    # Generate recommendation
    if total_score >= 40:  # 80%+
        decision = "STRONG GO"
        rationale = "Excellent opportunity with strong scores across all criteria. Invest full resources."
        risk_level = "Low"
    elif total_score >= 30:  # 60-80%
        decision = "GO"
        rationale = "Solid opportunity worth pursuing. Address yellow/red flags proactively."
        risk_level = "Moderate"
    elif total_score >= 20:  # 40-60%
        decision = "GO WITH CONDITIONS"
        rationale = "Qualified opportunity but with significant gaps. Proceed only if red flags can be resolved."
        risk_level = "Moderate-High"
    else:  # <40%
        decision = "NO-GO"
        rationale = "Weak qualification. Not recommended unless fundamental changes occur (budget allocation, champion engagement, etc.)"
        risk_level = "High"

    # Critical blockers (any criterion with score 1)
    critical_blockers = [k for k, v in scores.items() if v == 1]

    result = {
        "total_score": total_score,
        "max_score": max_score,
        "percentage": round(percentage, 1),
        "decision": decision,
        "risk_level": risk_level,
        "rationale": rationale,
        "breakdown": {
            "green_lights": green_lights,
            "yellow_flags": yellow_flags,
            "red_flags": red_flags,
            "critical_blockers": critical_blockers
        },
        "scores_detail": scores
    }

    # Add specific action items based on red flags
    action_items = []

    if "metrics" in red_flags:
        action_items.append("Co-create quantified success metrics with the buyer, tied to strategic KPIs")
    if "economic_buyer" in red_flags:
        action_items.append("Identify and engage the Economic Buyer through your Champion")
    if "decision_criteria" in red_flags:
        action_items.append("Influence decision criteria to align with your differentiators")
    if "decision_process" in red_flags:
        action_items.append("Map the full decision process including approvals, timeline, and stakeholders")
    if "paper_process" in red_flags:
        action_items.append("Engage legal/procurement early to understand and accelerate paper process")
    if "identify_pain" in red_flags:
        action_items.append("Escalate pain to C-level by quantifying cost of inaction")
    if "champion" in red_flags:
        action_items.append("Cultivate an internal Champion who will advocate and sell on your behalf")
    if "competition" in red_flags:
        action_items.append("Differentiate via unique value or change evaluation criteria to favor your strengths")
    if "risks" in red_flags:
        action_items.append("Document risks and build mitigation plans for each identified risk")
    if "roadblocks" in red_flags:
        action_items.append("Identify roadblock owners and create specific plans to remove obstacles")

    result["action_items"] = action_items

    return result


def format_output_text(result: Dict, metadata: Dict = None) -> str:
    """
    Format MEDDPICC+RR validation result as text report.

    Args:
        result: Output from calculate_meddpicc_score
        metadata: Optional deal metadata (name, value, etc.)

    Returns:
        Formatted text report
    """
    output = "\n" + "="*70 + "\n"
    output += "  MEDDPICC+RR QUALIFICATION ANALYSIS\n"
    output += "="*70 + "\n"

    if metadata:
        output += f"\n  OPPORTUNITY\n"
        output += f"  Name:          {metadata.get('name', 'N/A')}\n"
        output += f"  Value:         ${metadata.get('value', 0):,}\n"
        output += f"  Client:        {metadata.get('client', 'N/A')}\n"
        output += f"  Sales Owner:   {metadata.get('owner', 'N/A')}\n"

    output += f"\n  MEDDPICC+RR SCORE\n"
    output += f"  Total Score:   {result['total_score']}/{result['max_score']} ({result['percentage']}%)\n"
    output += f"  Decision:      {result['decision']}\n"
    output += f"  Risk Level:    {result['risk_level']}\n"

    output += f"\n  RATIONALE\n  {result['rationale']}\n"

    output += f"\n  GREEN LIGHTS ({len(result['breakdown']['green_lights'])})\n"
    if result['breakdown']['green_lights']:
        for item in result['breakdown']['green_lights']:
            output += f"  + {CRITERION_RUBRICS[MEDDPICCCriterion(item)]['name']} (Score: {result['scores_detail'][item]})\n"
    else:
        output += "  (None)\n"

    output += f"\n  YELLOW FLAGS ({len(result['breakdown']['yellow_flags'])})\n"
    if result['breakdown']['yellow_flags']:
        for item in result['breakdown']['yellow_flags']:
            output += f"  ~ {CRITERION_RUBRICS[MEDDPICCCriterion(item)]['name']} (Score: {result['scores_detail'][item]})\n"
    else:
        output += "  (None)\n"

    output += f"\n  RED FLAGS ({len(result['breakdown']['red_flags'])})\n"
    if result['breakdown']['red_flags']:
        for item in result['breakdown']['red_flags']:
            output += f"  x {CRITERION_RUBRICS[MEDDPICCCriterion(item)]['name']} (Score: {result['scores_detail'][item]})\n"
    else:
        output += "  (None)\n"

    if result['breakdown']['critical_blockers']:
        output += f"\n  CRITICAL BLOCKERS\n"
        for item in result['breakdown']['critical_blockers']:
            output += f"  ! {CRITERION_RUBRICS[MEDDPICCCriterion(item)]['name']} (Score: 1)\n"

    if result['action_items']:
        output += f"\n  RECOMMENDED ACTIONS\n"
        for i, action in enumerate(result['action_items'], 1):
            output += f"  {i}. {action}\n"

    output += "\n" + "="*70 + "\n"

    return output


def interactive_meddpicc():
    """Interactive CLI for MEDDPICC+RR scoring."""
    print("\n" + "="*70)
    print("  MEDDPICC+RR INTERACTIVE QUALIFICATION")
    print("="*70 + "\n")

    print("Score each criterion from 1-5:")
    print("  5 = Green (Strong)")
    print("  3 = Yellow (Moderate)")
    print("  1 = Red (Weak)\n")

    scores = {}

    for criterion in MEDDPICCCriterion:
        rubric = CRITERION_RUBRICS[criterion]
        print(f"\n{rubric['name']}: {rubric['description']}")
        print(f"  5 (Green):  {rubric['5']}")
        print(f"  3 (Yellow): {rubric['3']}")
        print(f"  1 (Red):    {rubric['1']}")

        while True:
            try:
                score = int(input(f"\nScore (1-5): "))
                if validate_score(score):
                    scores[criterion.value] = score
                    break
                else:
                    print("Invalid score. Please enter 1-5.")
            except ValueError:
                print("Invalid input. Please enter a number 1-5.")

    return scores


def main():
    """CLI interface for MEDDPICC+RR validator."""
    parser = argparse.ArgumentParser(
        description="Validate MEDDPICC+RR opportunity qualification"
    )

    parser.add_argument(
        "--input",
        type=str,
        help="Path to JSON file with MEDDPICC+RR scores and metadata"
    )

    parser.add_argument(
        "--interactive",
        action="store_true",
        help="Interactive mode for scoring"
    )

    parser.add_argument(
        "--output",
        type=str,
        choices=["json", "text"],
        default="text",
        help="Output format"
    )

    parser.add_argument(
        "--output-file",
        type=str,
        help="Save output to file"
    )

    args = parser.parse_args()

    # Get scores
    if args.interactive:
        scores = interactive_meddpicc()
        metadata = None
    elif args.input:
        with open(args.input, 'r') as f:
            data = json.load(f)
        scores = data.get("scores", {})
        metadata = data.get("metadata", {})
    else:
        parser.error("Either --input or --interactive required")

    # Calculate and generate output
    result = calculate_meddpicc_score(scores)

    if args.output == "json":
        output_data = {"result": result}
        if metadata:
            output_data["metadata"] = metadata
        output = json.dumps(output_data, indent=2)
    else:
        output = format_output_text(result, metadata)

    # Output to file or stdout
    if args.output_file:
        with open(args.output_file, 'w') as f:
            f.write(output)
        print(f"\nMEDDPICC+RR analysis saved to {args.output_file}")
    else:
        print(output)


if __name__ == "__main__":
    main()
