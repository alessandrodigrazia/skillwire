# Templates Library - Strategic B2B Sales Methodology

**Complete Library of Templates for Strategic B2B Selling**

---

## Index

1. [Overview](#overview)
2. [How to Use Templates](#how-to-use-templates)
3. [Templates by Category](#templates-by-category)
4. [Recommended Workflows](#recommended-workflows)
5. [Quick Guide: Which Template to Use?](#quick-guide-which-template-to-use)

---

## Overview

This directory contains **22 standardized templates** designed to support every phase of the strategic B2B sales cycle.

### Template Principles

- **Standardization**: Ensure consistency and professional quality across the entire organization
- **Completeness**: Each template covers all critical aspects of its phase
- **Integration**: Templates are designed to work together in sequential workflows
- **Best Practice**: Incorporate years of commercial experience
- **CRM-Ready**: Formats easily integrable into CRM systems

---

## How to Use Templates

### Template Format

All templates are in **Markdown (.md)** format for:
- Ease of reading and editing
- Version control with Git
- Compatibility with documentation systems
- Exportability to other formats (PDF, DOCX, HTML)

### Filling In Templates

1. **Copy the template** to a working directory or your CRM system
2. **Replace the placeholders** (indicated with `_____` or `[...]`) with real information
3. **Remove non-applicable sections** if necessary
4. **Save and share** with the team or client when appropriate

### File Naming Convention

Templates follow a clear convention:
- `[function-name]-template.md` - E.g.: `meddpicc-rr-template.md`, `meeting-memo-template.md`
- Descriptive name that clearly indicates the purpose

---

## Templates by Category

### 1. OPPORTUNITY QUALIFICATION

#### `meddpicc-rr-template.md` - MEDDPICC+RR Qualification Profile
**Purpose**: Objectively evaluate an opportunity on critical criteria to decide whether to invest resources.

**When to use**:
- After the first significant contact with a prospect
- Before investing time in complex pre-sales
- During periodic reviews of active opportunities

**Key output**:
- Traffic light assessment (green/yellow/red) for each criterion
- Score 1-5 for each dimension
- GO/NO-GO/GO WITH CONDITIONS decision

**Integrates with**: `buying-committee-template.md`, `strategic-sales-roadmap-template.md`

---

#### `ideal-customer-profile-template.md` - Ideal Customer Profile (ICP)
**Purpose**: Define the characteristics of the ideal customer to focus commercial efforts.

**When to use**:
- When defining the annual commercial strategy
- To segment the territory
- Before lead generation campaigns

**Key output**:
- Firmographic profile (industry, size, geography)
- Behavioral profile (digital maturity, innovation propensity)
- Red flags to avoid

---

### 2. STAKEHOLDER MAPPING

#### `buying-committee-template.md` - Buying Committee Mapping
**Purpose**: Identify and map all stakeholders according to the Buying Committee model (Champion, Economic Buyer, Technical Buyer, User, Coach).

**When to use**:
- As soon as a qualified opportunity is identified
- Before every strategic meeting with a new stakeholder
- Continuously update throughout the entire sales cycle

**Key output**:
- Complete Buying Committee map with roles
- Influence analysis, perceived urgency, opinion of us
- Engagement strategy for each stakeholder

**Integrates with**: `individual-value-proposition-template.md`, `strategic-sales-roadmap-template.md`

---

#### `buying-committee-roles-template.md` - Quick Reference for Buying Committee Roles
**Purpose**: Quick reference to understand characteristics and strategies for each Buying Committee role.

**When to use**:
- As a guide when filling in `buying-committee-template.md`
- For sales team training
- As a checklist before strategic meetings

**Key output**:
- Comparative table of 5 roles
- Specific engagement strategies
- Common mistakes to avoid

---

#### `individual-value-proposition-template.md` - Value Proposition per Stakeholder
**Purpose**: Create personalized value messages for each mapped stakeholder.

**When to use**:
- After completing the Buying Committee mapping
- Before preparing targeted communications (emails, presentations)
- For team briefing before multi-stakeholder meetings

**Key output**:
- Role-specific value proposition (Champion, Economic Buyer, Technical Buyer, etc.)
- Key messages adapted to personal/business objectives
- Pain points and benefits relevant to each

---

### 3. STRATEGIC ANALYSIS

#### `customer-swot-template.md` - Customer-Focused SWOT
**Purpose**: Analyze the client through the SWOT lens to identify strategic leverage points.

**When to use**:
- During preparation for strategic meetings
- Before creating business cases or proposals
- To develop competitive strategies

**Key output**:
- Client Strengths we can amplify
- Weaknesses we can solve
- Market Opportunities we can help seize
- Threats we can mitigate

**Integrates with**: `value-areas-mapping-template.md`, `business-case-template.md`

---

#### `value-areas-mapping-template.md` - Value Areas Mapping
**Purpose**: Identify strategic areas where we can create value for the client.

**When to use**:
- After C-SWOT, before strategic meetings
- To develop the first meeting agenda
- As a foundation for value presentations

**Key output**:
- Priority value areas
- Solution hypothesis for each area
- Targeted discovery questions

**Integrates with**: `first-meeting-structure-template.md`, `value-chain-template.md`

---

#### `competitive-analysis-template.md` - Competitive Analysis
**Purpose**: Analyze active competitors on the opportunity to define competitive strategy.

**When to use**:
- As soon as competitor presence is identified
- Before final presentations
- During preparation of RFQ/tender responses

**Key output**:
- Competitor profile (strengths/weaknesses)
- Their probable strategy
- Our competitive strategy (Direct/Change the Game/Partition)
- Differentiating messages

**Integrates with**: `strategic-sales-roadmap-template.md`, `deal-one-pager-template.md`

---

### 4. BUSINESS CASE AND ROI

#### `value-chain-template.md` - Value Chain Analysis
**Purpose**: Translate technical features into quantified business benefits following the Feature -> Advantage -> Benefit -> Impact -> EUR Value model.

**When to use**:
- Before creating business cases
- During commercial proposal development
- To prepare ROI-focused presentations

**Key output**:
- Complete Feature -> Quantified Value mapping
- Quantitative, operational, strategic benefits
- Foundation for ROI calculation

**Integrates with**: `business-case-template.md`, `deal-one-pager-template.md`

---

#### `business-case-template.md` - Executive Business Case
**Purpose**: Formal document for CFO/C-Level with complete cost-benefit analysis.

**When to use**:
- For opportunities >EUR 100K
- When explicitly requested by the client
- Before the Economic Buyer's final decision

**Key output**:
- Executive Summary
- Current situation analysis and business problem
- Proposed solution with quantified benefits
- Required investment and ROI
- Implementation roadmap

**Integrates with**: `value-chain-template.md`, `deal-one-pager-template.md`

---

#### `deal-one-pager-template.md` - Executive Summary (1 Page)
**Purpose**: Executive summary of maximum 1 page for C-Level.

**When to use**:
- Before meetings with Economic Buyer (C-Level)
- As a leave-behind after strategic presentations
- When the decision maker has limited time

**Key output**:
- Strategic challenge (1 paragraph)
- Proposed solution (bullet points)
- Quantified benefits (3-5 key metrics)
- Why us (differentiators)
- Investment and next steps

**Integrates with**: `business-case-template.md`, `meeting-memo-template.md`

---

### 5. MEETING PREPARATION AND FOLLOW-UP

#### `pre-meeting-checklist-template.md` - Pre-Meeting Checklist
**Purpose**: Operational checklist to ensure everything is prepared before a strategic meeting.

**When to use**:
- 24-48 hours before every important meeting
- As a quality gate before C-Level visits
- For pre-sales team briefing

**Key output**:
- Pre-meeting research checklist
- Materials to prepare
- Logistics and technical setup
- Team roles and responsibilities

**Integrates with**: `first-meeting-structure-template.md`, `discovery-questions-template.md`

---

#### `first-meeting-structure-template.md` - First Meeting Framework
**Purpose**: Detailed framework for structuring the first strategic meeting in 4 phases (Opening, Analysis, Presentation, Commitment).

**When to use**:
- To prepare strategic first meetings
- As a guide during the meeting itself
- For sales training

**Key output**:
- Opening script (value statement)
- Structured discovery questions
- Solution presentation framework
- Closing techniques with commitment

**Integrates with**: `discovery-questions-template.md`, `meeting-memo-template.md`

---

#### `discovery-questions-template.md` - Discovery Questions Bank
**Purpose**: Library of strategic questions organized by framework and sales phase.

**When to use**:
- During preparation for any discovery meeting
- For sales team training
- As a cheat sheet during meetings

**Key output**:
- 50+ categorized questions
- Situation, Problem, Impact, Benefit, Decision questions
- Questions for every phase of the sales cycle

**Integrates with**: `first-meeting-structure-template.md`, `buying-committee-template.md`

---

#### `meeting-memo-template.md` - Post-Meeting Follow-Up Email
**Purpose**: Structured follow-up email to send within 24-48 hours of the meeting.

**When to use**:
- ALWAYS after every strategic meeting
- Maximum 48 hours after the meeting
- As a commitment tool

**Key output**:
- Summary of client objectives (in their words)
- Decision criteria emerged
- Hypothesized solution and benefits
- Mutual Action Plan (MAP) with dates
- Explicit feedback request

**Integrates with**: `mutual-action-plan-template.md`, `internal-debrief-template.md`

**Key principle**: "Don't just trust me, trust what I got you to put in writing!"

---

#### `internal-debrief-template.md` - Internal Debrief Report
**Purpose**: Internal post-meeting report for team alignment and CRM update.

**When to use**:
- After every significant meeting
- Before sharing with management
- For structured CRM update

**Key output**:
- Meeting summary and attendees
- Key learnings and insights
- MEDDPICC+RR and Buying Committee update
- Red flags and opportunities
- Next actions with owners

**Integrates with**: `meeting-memo-template.md`, `strategic-sales-roadmap-template.md`

---

### 6. DEAL PLANNING AND MANAGEMENT

#### `mutual-action-plan-template.md` - MAP (Mutual Action Plan)
**Purpose**: Shared plan with the client defining who does what and by when.

**When to use**:
- After discovery/qualification meetings
- As an attachment to the Meeting Memo
- To formalize reciprocal commitments

**Key output**:
- Action table with owners (client/our team)
- Dates and milestones
- Objective of each action
- Success criteria

**Key principle**: The MAP transforms a generic intention into concrete commitment. Without a MAP, the deal is at risk of ghosting.

**Integrates with**: `meeting-memo-template.md`, `strategic-sales-roadmap-template.md`

---

#### `strategic-sales-roadmap-template.md` - Strategic Sales Roadmap
**Purpose**: "Living" document for complex opportunities that integrates MEDDPICC+RR, Buying Committee, competitive analysis, value proposition, and action plan.

**When to use**:
- For opportunities >EUR 100K
- Deals with sales cycle >3 months
- Multiple stakeholders and active competitors
- Periodic reviews with management

**Key output**:
- Opportunity reference data
- MEDDPICC+RR alignment (summary)
- Competitor analysis (3 competitors)
- Buying Committee mapping (stakeholder summary)
- Personalized value proposition
- Strengths/weaknesses assessment
- Action plan with milestones

**Update frequency**: Weekly for deals >EUR 100K

**Integrates with**: Virtually all other templates (it is the "master document")

---

#### `account-plan-template.md` - Strategic Account Plan
**Purpose**: Long-term strategic plan for key accounts (not a single opportunity).

**When to use**:
- For Key Account / Strategic Account
- Annual account planning
- When managing multi-opportunity relationships

**Key output**:
- Complete account profile
- Account SWOT analysis
- Strategic objectives (ours and the client's)
- Opportunity pipeline
- Relationship map
- Penetration and up-selling strategy

**Integrates with**: `strategic-sales-roadmap-template.md` (for individual opportunities within the account)

---

### 7. TENDERS AND RFQ

#### `ideal-sales-process-template.md` - Ideal Sales Process Definition
**Purpose**: Define the ideal evaluation/buying process for the client to adopt (when there is no formal RFQ).

**When to use**:
- Consultative sales without RFQ
- To educate the client on vendor selection best practices
- As a strategy to "control" the decision process

**Key output**:
- Ideal process phases
- Stakeholders to involve
- Suggested evaluation criteria
- Recommended timeline

**Principle**: Whoever defines the process influences the outcome.

---

### 8. ORGANIZATION AND PROCESS

#### `buying-committee-roles-template.md` - Buying Committee Roles Quick Reference
*(Already described in the Stakeholder Mapping section)*

---

## Recommended Workflows

### Workflow 1: New Prospect -> First Qualification

```
1. ideal-customer-profile-template.md
   | (verify fit)
2. meddpicc-rr-template.md
   | (if GO)
3. pre-meeting-checklist-template.md
   |
4. customer-swot-template.md + value-areas-mapping-template.md
   |
5. first-meeting-structure-template.md + discovery-questions-template.md
   |
6. meeting-memo-template.md + mutual-action-plan-template.md
   |
7. internal-debrief-template.md
```

---

### Workflow 2: Qualified Opportunity -> Close

```
1. buying-committee-template.md (stakeholder mapping)
   |
2. individual-value-proposition-template.md (for each key stakeholder)
   |
3. competitive-analysis-template.md (if active competitors)
   |
4. strategic-sales-roadmap-template.md (start "living" document)
   |
5. value-chain-template.md
   |
6. business-case-template.md OR deal-one-pager-template.md
   |
7. Update strategic-sales-roadmap-template.md continuously
```

---

### Workflow 3: C-Level Meeting Preparation

```
1. Update buying-committee-template.md for the target C-Level
   |
2. Create/update specific individual-value-proposition-template.md
   |
3. Prepare deal-one-pager-template.md (leave-behind)
   |
4. pre-meeting-checklist-template.md
   |
5. Meeting with discovery questions from discovery-questions-template.md
   |
6. meeting-memo-template.md (within 24-48 hours)
```

---

### Workflow 4: Key Account Management

```
1. account-plan-template.md (annual planning)
   |
2. For each opportunity within the account:
   - meddpicc-rr-template.md
   - strategic-sales-roadmap-template.md
   |
3. Quarterly review of account-plan-template.md
   |
4. Identify up-selling / cross-selling opportunities
```

---

### Workflow 5: RFQ/Tender Response

```
1. meddpicc-rr-template.md (is it worth participating?)
   |
2. competitive-analysis-template.md
   |
3. buying-committee-template.md (who really decides?)
   |
4. value-chain-template.md (for technical scoring)
   |
5. business-case-template.md (for economic section)
```

---

## Quick Guide: Which Template to Use?

### "I have a new lead, where do I start?"
-> `ideal-customer-profile-template.md` to verify fit
-> `meddpicc-rr-template.md` after first qualified contact

### "I need to prepare a strategic first meeting"
-> `pre-meeting-checklist-template.md`
-> `customer-swot-template.md`
-> `value-areas-mapping-template.md`
-> `first-meeting-structure-template.md`

### "I don't know who the decision makers are"
-> `buying-committee-template.md`
-> `buying-committee-roles-template.md` (quick reference)

### "I need to create a proposal/business case"
-> `value-chain-template.md` (first)
-> `business-case-template.md` (formal complete document)
-> `deal-one-pager-template.md` (1-page executive summary)

### "Just finished an important meeting"
-> `internal-debrief-template.md` (immediately, for the team)
-> `meeting-memo-template.md` (within 24-48h, to the client)
-> `mutual-action-plan-template.md` (as attachment to the memo)

### "I have a complex deal with many competitors"
-> `strategic-sales-roadmap-template.md` (master document)
-> `competitive-analysis-template.md`
-> Update roadmap weekly

### "The client has gone silent (ghosting)"
-> Check if you sent `meeting-memo-template.md` with MAP
-> If not, recover with `mutual-action-plan-template.md`
-> Re-evaluate with `meddpicc-rr-template.md` (maybe it's a NO-GO)

### "I need to manage a strategic Key Account"
-> `account-plan-template.md` (annual plan)
-> + `strategic-sales-roadmap-template.md` for each opportunity

### "There's a tender/RFQ to evaluate"
-> `meddpicc-rr-template.md` (qualify first)
-> `competitive-analysis-template.md`
-> `ideal-sales-process-template.md` (if we can influence the process)

---

## Cross-Cutting Best Practices

### Do's

1. **Update continuously** during the sales cycle (these are "living documents")
2. **Share with the team** for alignment and visibility
3. **Archive in CRM** for traceability and analytics
4. **Use as a coaching foundation** with managers and colleagues
5. **Personalize** when necessary, but maintain the base structure
6. **Combine templates** to maximize value (see recommended workflows)
7. **Review before deal reviews** with management

### Don'ts

1. **Don't fill in once and forget** - Templates must be continuously updated
2. **Don't skip critical steps** - E.g., always do MEDDPICC+RR before investing in pre-sales
3. **Don't send empty or partial templates** to the client - Complete them thoroughly
4. **Don't use templates for wrong opportunities** - E.g., no roadmap needed for deals <EUR 10K
5. **Don't hide red flags** - Templates exist to be honest, not optimistic
6. **Don't work in silos** - Share with the team to maximize synergies

---

## Support and Training

### Questions About How to Use a Template?

1. **Read the template itself** - Every template contains detailed usage instructions
2. **Consult this guide** - Search for the template in the index above
3. **Ask your manager** - Sales Managers are trained on the methodology
4. **Use the AI Skill** - The AI skill can guide you step-by-step through completion

### Available Training

- **Sales Academy** - "Strategic B2B Sales Methodology" module (includes template training)
- **Practical workshops** - Hands-on sessions with real cases
- **Deal Review** - Weekly review where templates are used in practice
- **1:1 Coaching** - Individual support from Sales Manager

---

## Updates and Maintenance

**Current Version**: 1.0.0
**Last Update**: October 2025
**Owner**: Sales Enablement Team

### How to Propose Improvements

If you have suggestions to improve a template:
1. Document the problem/improvement opportunity
2. Propose the specific change
3. Share with your Sales Manager
4. Approved changes will be integrated in the next version

---

## Template Quick Reference Table

| Template | Category | When to Use | Time to Complete | Priority |
|----------|----------|-------------|-----------------|----------|
| `meddpicc-rr-template.md` | Qualification | After first qualified contact | 30-45 min | CRITICAL |
| `buying-committee-template.md` | Stakeholder | As soon as opportunity is qualified | 45-60 min | CRITICAL |
| `strategic-sales-roadmap-template.md` | Planning | Deal >EUR 100K, >3 months | 60-90 min initial | CRITICAL |
| `meeting-memo-template.md` | Follow-up | After EVERY strategic meeting | 20-30 min | CRITICAL |
| `mutual-action-plan-template.md` | Follow-up | With meeting memo | 15-20 min | CRITICAL |
| `deal-one-pager-template.md` | Business Case | Before C-Level meeting | 30-45 min | HIGH |
| `value-chain-template.md` | ROI | Before business case | 45-60 min | HIGH |
| `business-case-template.md` | ROI | Deal >EUR 100K, on request | 90-120 min | HIGH |
| `first-meeting-structure-template.md` | Meeting Prep | Strategic first meeting | 60 min | HIGH |
| `customer-swot-template.md` | Analysis | Before strategic meetings | 30-45 min | HIGH |
| `value-areas-mapping-template.md` | Analysis | With C-SWOT | 20-30 min | HIGH |
| `competitive-analysis-template.md` | Competitive | When active competitors | 30-45 min | HIGH |
| `individual-value-proposition-template.md` | Stakeholder | After Buying Committee mapping | 20 min/stakeholder | MEDIUM |
| `discovery-questions-template.md` | Meeting Prep | Before every discovery | 10-15 min | MEDIUM |
| `pre-meeting-checklist-template.md` | Meeting Prep | 24-48h before meeting | 15 min | MEDIUM |
| `internal-debrief-template.md` | Follow-up | After significant meetings | 15-20 min | MEDIUM |
| `account-plan-template.md` | Key Account | Annual planning | 2-3 hours | MEDIUM |
| `buying-committee-roles-template.md` | Reference | Buying Committee reference | 5 min read | MEDIUM |
| `ideal-customer-profile-template.md` | Strategy | Territory planning | 60 min | LOW |
| `ideal-sales-process-template.md` | Strategy | Consultative sales | 45 min | LOW |

**Priority Legend**:
- **CRITICAL**: Always use, never skip
- **HIGH**: Strongly recommended for qualified opportunities
- **MEDIUM**: Useful but optional depending on context
- **LOW**: For specific situations or strategic planning

---

**End of Document**

For questions or support: Sales Academy | Sales Enablement Team | Your Sales Manager
