# TEMPLATE - NEGOTIATION ZONE AND TRADE VARIABLES
*(Strategic Negotiation Preparation Tool)*

## Reference Information:
- **Sales Rep/Negotiation Team:** ____________________
- **Customer/Counterparty:** ____________________
- **Opportunity/Project/Agreement Under Negotiation:** ____________________
- **Preparation Date:** ____/____/____

---

## Instructions for Completion:
This template is used to prepare the negotiation strategy by clearly defining your limits and objectives (Negotiation Zone) and identifying elements that can be exchanged to reach a mutually beneficial agreement (Trade Variables). Be realistic and base your assessments on concrete information.

---

## PART 1: DEFINING THE NEGOTIATION ZONE (For Our Side)

### 1.1 Identification of Key Negotiation Factors:
*(List all elements that will be subject to discussion and agreement. E.g.: Price, Payment Terms, Service Levels (SLA), Contract Duration, Warranties, Training, Support, Customizations, Delivery Timelines, Intellectual Property, Exclusivity, etc.)*

1.  **Key Factor 1:** ____________________
2.  **Key Factor 2:** ____________________
3.  **Key Factor 3:** ____________________
4.  **Key Factor 4:** ____________________
5.  **Key Factor 5:** ____________________

### 1.2 Defining the Negotiation Zone for Each Key Factor (Our Position):

| Key Negotiation Factor | Our OPENING Position (Ideal/Maximum Aspiration) | Our TARGET (Realistic/Desired Outcome) | Our MINIMUM ACCEPTABLE / ZOPA (Walk-Away Point) | Notes/Justifications for Our Positions |
|---|---|---|---|---|
| 1. [Key Factor 1 Name] | | | | |
| 2. [Key Factor 2 Name] | | | | |
| 3. [Key Factor 3 Name] | | | | |

### 1.3 Estimating the Counterparty's Negotiation Zone (As Known/Hypothesized):
*(This requires research and analysis. It is fundamental to understanding the potential Zone of Possible Agreement - ZOPA)*

| Key Negotiation Factor | THEIR OPENING Position (Hypothesized) | THEIR TARGET (Hypothesized) | THEIR MINIMUM ACCEPTABLE / ZOPA (Hypothesized) | Sources/Rationale for These Hypotheses |
|---|---|---|---|---|
| 1. [Key Factor 1 Name] | | | | |
| 2. [Key Factor 2 Name] | | | | |
| 3. [Key Factor 3 Name] | | | | |

---

## PART 2: IDENTIFYING AND PRIORITIZING TRADE VARIABLES (If-Then Trading)

### 2.1 Trade Variables We CAN GIVE (Potential Concessions):
*(List elements that have a relatively low cost for us, but a high perceived value for the counterparty, or vice versa, that we can concede in exchange for something else. Apply the If-Then Trading principle: never give something without getting something in return.)*

| Trade Variable We CAN GIVE | Specific Description | Cost to Us (High/Medium/Low/None) | Perceived Value by Counterparty (High/Medium/Low) | Concession Priority (1=Last resort, 5=Easy to concede) | Strategic Notes (When/How/In exchange for what?) |
|---|---|---|---|---|---|
| 1. E.g. Extended warranty period | From 12 to 18 months | Low | Medium/High | 3 | If they request a deep discount on price |
| 2. E.g. Additional training | 2 extra days for 5 key users | Medium | High | 2 | To close quickly or obtain a reference |

### 2.2 Trade Variables We WANT TO GET (Potential Requests):
*(List elements that have a high value for us, but a relatively low cost for the counterparty, or that are otherwise desirable for us.)*

| Trade Variable We WANT TO GET | Specific Description | Value to Us (High/Medium/Low) | Perceived Cost for Counterparty (High/Medium/Low/None) | Request Priority (1=Essential, 5=Nice to have) | Strategic Notes (How/When to ask? What to offer in exchange?) |
|---|---|---|---|---|---|
| 1. E.g. Publishable testimonial/case study | Within 3 months of go-live | High | Low/Medium | 2 | In exchange for a small concession or as part of the value |
| 2. E.g. Advance payment | 50% at order instead of 30% | Medium | Medium | 3 | If we grant flexibility on other terms |

---

## PART 3: INITIAL TRADING STRATEGY (HYPOTHESES)

- **What concessions are we willing to make first and in exchange for what? (Hypothetical trade packages):**
  - If the customer asks for [Customer Request X], we could concede [Our Concession Y] in exchange for [Our Request Z].

- **What are our most valuable "trading chips" that we want to use only to obtain equally valuable concessions?**

- **How will we handle the first concession request from them? (If-Then Trading principle -- never concede without receiving something in return):**

---

## GENERAL NOTES ON NEGOTIATION PREPARATION
*(Space for further reflections, BATNA analysis, negotiation team composition, logistics, etc.)*

- **Our BATNA (Best Alternative To a Negotiated Agreement) -- Fisher & Ury:**
  - Description: ...
  - Strength of our BATNA: ...

- **Hypothesized Counterparty's BATNA:**
  - Description: ...
  - Hypothesized strength of their BATNA: ...

- **Negotiation Team (Roles):**
  - Leader: ...
  - Observer/Analyst: ...
  - Technical Expert (if needed): ...

- **Other Strategic Considerations:**
  ...
