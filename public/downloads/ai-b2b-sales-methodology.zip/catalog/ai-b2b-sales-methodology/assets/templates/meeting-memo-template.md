# TEMPLATE - MEETING MEMO

**Tool for Post-Meeting Alignment and Commitment Creation**

---

## 1. The Purpose of the Meeting Memo: Your Strategic Goal

Your objective is twofold:

### Alignment and Understanding
Demonstrate to the client that you **actively listened** and **deeply understood** their needs, objectives, and decision criteria.

> _"Don't just trust me, trust what I got you to put in writing!"_

### Creating Commitment and Next Steps
Define clearly and jointly the **next actions**, who will carry them out, and by when. This is the real client **"commitment"** that pushes the deal forward.

---

## 2. The Structure of an Effective Meeting Memo

The meeting memo is a **distillation of our methodology**, a strategic summary that anticipates the value proposition itself.

### Key Characteristics

- **Brief**: Concise and direct
- **Clear**: Avoid bureaucratic jargon
- **Timely**: Send within **24-48 hours** of the meeting

---

## A. THE EMAIL SUBJECT LINE: Your Hook!

The subject line is the **first impression**, it must capture attention and spark curiosity. Don't be generic. Think as if you were writing marketing copy: **it must stand out!**

It is recommended to write it **after** drafting the body of the email.

### Key Points to Draw From

- A potential challenge or opportunity you identified in their business
- A highlight of the discussion that particularly interested them
- A specific value you can bring

### Subject Line Examples

**Generic** (bad):
```
Follow-up: Our productive meeting on [Meeting Date] about [Main Topic/Opportunity Name] - Next Steps
```

**Impactful** (good):
```
[Your Company] - [Client]: 1 + 1 = 3
```
_A strong statement that emerged during the discussion with the client_

---

## B. THE EMAIL BODY: Your Strategic Narrative

The email body should retrace the key points of the meeting, reworked through our value logic.

### 1. Acknowledgments and Personalized Opening

Always start with a **thank you** for the precious time dedicated. Don't be banal, reference a **specific and positive point** that emerged from the conversation to build rapport.

**Template**:

```
Dear [Client Contact Name],

I want to thank you again for the precious time you dedicated to us during
our meeting on [Day of the week, Meeting Date].

It was a truly stimulating and productive discussion, and we particularly
appreciated your vision on [mention a specific positive point from the
discussion, e.g., 'the current challenges in your industry' or 'your growth aspirations'].
```

---

### 2. Summary of Objectives (in their words!)

Summarize the problems to solve or opportunities to seize that the client shared with you. **Use their own words** whenever you can, to reinforce the perception of understanding.

**Concrete Action**: Reflect on the questions you asked during the Ask phase (objectives, quantification).

**Template**:

```
The main objectives you shared with me, among others, include:

- [Objective 1]
- [Objective 2]
- [Objective 3]

Right now, these play a fundamentally important role, which is why
it is necessary to start building a culture around...
```

---

### 3. Summary of Decision Criteria

Recall the **factors** the client indicated as important for their choice, both of the solution and the vendor.

**Concrete Action**: This comes from the questions about decision criteria asked during the Ask phase.

**Template**:

```
In choosing the partner to entrust with this journey toward
achieving the objectives outlined above, it will be important that they are able to:

- [Decision Criterion 1]
- [Decision Criterion 2]
- [Decision Criterion 3]
```

---

### 4. Hypothesized Scenario/Solution and Benefits

Present in summary the solution you began to outline together and, above all, the **specific and quantified benefits** the client will gain.

**Focus**: Don't focus on features, but on the **impact on their business** (euros gained/saved, time saved).

**Concrete Action**: Leverage the information collected during the Ask phase on impact quantification. Refer to the Value Chain.

**Template**:

```
Based on what was shared, we have started to hypothesize some of the possible
solutions, such as the possibility of:

- [Solution/Approach 1]
- [Solution/Approach 2]

Expected benefits:
- [Quantified Benefit 1]
- [Quantified Benefit 2]

Strengths of our solution:
- [Differentiating Factor 1]
- [Differentiating Factor 2]
```

---

### 5. Why Us (Differentiating Factors)

Briefly emphasize your **strengths** and **differentiating factors** that align with their criteria and needs.

**Use "data, evidence, facts"** to increase credibility.

**Template**:

```
We stand out for:

- [Differentiator 1 with evidence]
- [Differentiator 2 with evidence]
- [Differentiator 3 with evidence]
```

---

### 6. Mutual Action Plan (MAP) and Next Steps

**This is the heart of the close.** Clearly define the agreed actions, who is responsible (client or our team), and the deadlines.

It's the **"who does what and by when"**.

**Concrete Action**: If you already have a MAP, attach it or reference it. Otherwise, indicate that you will send it shortly. It is essential to **schedule a next synchronous meeting**.

**Template**:

```
As agreed, to proceed in a structured and transparent manner toward
achieving our shared objective of '[Recall the General Shared Objective
of the Project defined in the MAP]', we have defined the following actions:
```

| Action | Owner | Deadline | Objective |
|--------|-------|----------|-----------|
| [Action 1] | [Our Team/Client] | [Date] | [Objective] |
| [Action 2] | [Our Team/Client] | [Date] | [Objective] |
| [Action 3] | [Our Team/Client] | [Date] | [Objective] |

```
Our next contact/meeting is scheduled for: [Date and Time]
```

---

### 7. Request for Feedback and Validation

It is essential to **ask the client to confirm, add to, or modify** what you have summarized. This:
- Demonstrates professionalism
- Gives you further confirmation of their commitment
- Helps you avoid ghosting

**Template**:

```
I ask for your feedback regarding my level of understanding of your needs,
feeling completely free to add to and/or modify anything you see fit.
```

---

### 8. Closing and Contacts

Professional closing with all your contact details.

**Template**:

```
I remain at your complete disposal for any clarification.

Best regards,

[First Name Last Name]
[Title/Role]
[Company]
Email: [email]
Phone: [phone]
```

---

## C. FORMAT AND TOOLS

### Image, Not Attachment

Instead of attaching a PDF, **paste the content of the meeting memo** (or at least the key points) as an **image directly in the email body**.

**Advantages**:
- The client sees it immediately without having to click
- Increases immediacy and likelihood of being read

---

## Best Practices for the Meeting Memo

### Timing

- **Send within 24-48 hours** of the meeting
- Write while things are still fresh

### Style

- **Use their words**: Repeat client terminology and phrases
- **Be specific**: Avoid generalizations
- **Quantify**: Use numbers whenever you can

### Structure

- **Brief but complete**: Cover all points but concisely
- **Clear actions**: Who, what, when for every next step
- **Visually organized**: Use bullet points, tables, sections

### Follow-up

- If you don't receive a response in 3-5 days, make a phone follow-up
- "I wanted to make sure you received my memo and collect any feedback"

---

## Common Mistakes to Avoid

**Generic memo** (bad): "It was a great meeting" (useless)
**Specific memo** (good): "The CFO highlighted the need to reduce operational costs by 15% by Q2"

**No concrete action** (bad): Discussions without commitment
**Precise actions** (good): "Marco will send the data by Friday the 15th"

**Only our point of view** (bad): Presenting only our solution
**Client's perspective** (good): Start from their needs, then connect the solution

**Late delivery** (bad): After 1 week (too late)
**Timely delivery** (good): Within 24-48 hours (maximum relevance)

---

## Integration with Other Tools

- **4-Phase Sales Conversation Framework**: The memo reflects the Trust-Ask-Solution-Keep structure
- **Mutual Action Plan**: The memo introduces or confirms the Mutual Action Plan
- **Buying Committee**: Personalize the memo for the Buying Committee role of the contact
- **Internal Debrief**: Use the debrief to compile the memo

---

## Complete Meeting Memo Example

```
Subject: [Your Company] - [Client]: Opportunity to reduce operational costs by 18% - Next Steps

Dear Dr. Smith,

I want to thank you again for the precious time you dedicated to us during
our meeting on Tuesday, October 15. It was a truly stimulating and productive
discussion, and we particularly appreciated your vision on the current
challenges in the insurance industry.

KEY OBJECTIVES EMERGED:
- Reduce underwriting department operational costs by 15-20% by Q2 2025
- Accelerate time-to-market for new insurance products
- Improve customer experience in the underwriting process

IMPORTANT DECISION CRITERIA FOR YOU:
- Clear and verifiable ROI within 12 months
- Scalable solution that grows with the company
- Partner with proven experience in the insurance industry
- Ongoing post-implementation support

HYPOTHESIZED SOLUTION:
Based on what was shared, we have identified how our Digital Underwriting
platform can help you:
- Automate 70% of current manual processes
- Reduce underwriting time from 8 days to 24 hours
- Generate an estimated savings of EUR 450K annually

WHY US:
- 15+ implementations in the insurance industry
- Proven methodology that guarantees go-live in 90 days
- Dedicated team with specific underwriting experience

AGREED NEXT STEPS:

| Action | Owner | Deadline |
|--------|-------|----------|
| Send detailed technical documentation | Our Team (John) | October 18 |
| Organize demo with CTO | Client (Dr. Smith) | October 25 |
| Prepare detailed business case | Our Team (John) | October 28 |

Our next meeting is scheduled for: Wednesday, October 30, 2:00 PM.

I ask for your feedback regarding my level of understanding of your needs,
feeling completely free to add to or modify anything you see fit.

Best regards,

John White
Senior Account Manager
[Company]
Email: john.white@company.com
Phone: +1 555 123 4567
```
