# TEMPLATE -- BUYING COMMITTEE MAPPING

**Tool for Mapping and Analyzing Key Stakeholders**

---

## General Opportunity Information

_Complete once for the entire mapping exercise_

- **Sales Rep (Author)**: ________________________________
- **Customer/Prospect Company**: ________________________________
- **Opportunity/Project Name**: ________________________________
- **Date of Analysis/Update**: ____/____/________

---

## INDIVIDUAL STAKEHOLDER CARD #___

_Replicate this section for EVERY identified member of the Buying Committee_

---

### 1. Contact Identification

- **Full Name**: ________________________________

- **Official Title/Position**: ________________________________

- **Department/Functional Area**: ________________________________

- **Our Point of Contact** (if specific for this person): ________________________________

- **Source of Information** (how we identified/met them): ________________________________

---

### 2. Role in the Buying Committee for THIS Opportunity

_Select the primary role and, if necessary, a secondary role. Briefly justify your choice._

#### Buying Committee Roles

- [ ] **Champion**: Has power, influence, and a personal stake in our solution winning. Actively sells on our behalf internally.

- [ ] **Economic Buyer**: Has final budget authority and can approve or veto the purchase. Often the most senior stakeholder.

- [ ] **Technical Buyer**: Evaluates technical/functional alternatives, provides specialist opinions, can strongly influence or block the decision.

- [ ] **User**: Will directly use the solution day-to-day; their feedback is crucial for adoption and success.

- [ ] **Coach**: Guides us inside the organization, provides "inside" information, helps us navigate politics and process.

#### Role Assignment

- **Primary Role Assigned**: ________________________________

- **Secondary Role** (if applicable): ________________________________

- **Rationale/Evidence for Role**:

```
[Enter detailed rationale with specific evidence]
```

---

### 3. Degree of Influence on the Final Decision

_Assess this person's real influence on the specific decision for this opportunity, regardless of formal title._

#### Rating Scale

- [ ] **High**: Has a decisive weight on the final decision.
- [ ] **Medium**: Can significantly influence the decision, but is not the sole voice.
- [ ] **Low**: Has limited or only advisory influence.

#### Rationale/Evidence of Influence

```
[Enter evidence of influence: Who listens to this person? Do they have budget authority?
Do they have veto power? Do other stakeholders depend on their approval?]
```

---

### 4. Perception of Urgency of the Problem/Project

_How much does this person feel the problem or project is urgent and a priority?_

#### Rating Scale

- [ ] **Urgent**: Considers the problem/project a top priority that must be resolved immediately.

- [ ] **Significant**: Recognizes the importance, but it may not be their top priority.

- [ ] **Low**: Views the problem/project as "nice to have" or low priority.

- [ ] **None/Not Perceived**: Does not see the problem or does not consider it one.

- [ ] **Unknown** (To Be Verified)

#### Rationale/Evidence of Urgency Perception

```
[Enter evidence: Have they mentioned deadlines? Are there consequences of inaction?
What are their declared priorities? How much time do they dedicate to this problem?]
```

---

### 5. Current Opinion on Us / Our Proposed Solution

_What is this person's attitude toward us and/or the solution we are (or could be) proposing?_

#### Rating Scale

- [ ] **++ (Strongly Positive/Sponsor)**: Actively in our favor, promotes us.

- [ ] **+ (Positive/Favorable)**: Well-disposed, sees value.

- [ ] **0 (Neutral)**: Impartial, open, has not formed an opinion.

- [ ] **- (Negative/Skeptical)**: Has doubts, concerns, or preferences for alternatives.

- [ ] **-- (Strongly Negative/Obstacle)**: Actively opposed or favoring a competitor.

- [ ] **? (Unknown/To Be Verified)**

#### Rationale/Evidence for Opinion

```
[Enter evidence: What have they said or done to indicate this opinion?
Have they defended us in meetings? Have they raised objections? Do they compare our solution
positively/negatively with alternatives?]
```

---

### 6. Relevant Goals for This Person

_In relation to the opportunity_

#### Primary Business Goals

_That this person must achieve and to which our solution can contribute_

1. ________________________________

2. ________________________________

3. ________________________________

#### Personal Goals

_What motivates them at an individual level in this context: visibility, career advancement, stress reduction, innovation, stability, risk avoidance_

1. ________________________________

2. ________________________________

3. ________________________________

#### Guiding Questions

**Reflect on:**
- What does this person need to deliver to be considered successful in their role?
- What makes them shine in front of their superiors?
- What keeps them up at night regarding this opportunity/problem?

```
[Enter insights based on conversations, LinkedIn, research]
```

---

### 7. Key Decision Criteria for This Person

_What specific factors does this person consider most important when evaluating a solution/proposal like ours?_

#### Top 3 Criteria

1. **Criterion 1**: ________________________________
   - Example: Short-term ROI, ease of implementation, proven reliability, technological innovation, post-sales support, total cost of ownership, relationship with the vendor

2. **Criterion 2**: ________________________________

3. **Criterion 3**: ________________________________

#### Must-Have vs Nice-to-Have Priorities

**Must-Have** (non-negotiable):
- ________________________________
- ________________________________

**Nice-to-Have** (desirable but flexible):
- ________________________________
- ________________________________

#### Guiding Questions

**Reflect on:**
- On what will they base their "yes" or "no"?
- What would convince them that ours is the best choice FOR THEM?
- What objections might they raise?

```
[Enter decision criteria analysis]
```

---

### 8. Notes on Relationship and Individual Engagement Strategy

#### Quality of Our Current Relationship

- [ ] **Excellent**: Consolidated partnership, high level of trust
- [ ] **Good**: Positive relationship, regular communication
- [ ] **Adequate**: Sporadic contacts, basic professional relationship
- [ ] **Poor**: Few contacts, cold or difficult relationship
- [ ] **Non-existent**: No contact established yet

#### Relationships with Other Buying Committee Members

_Alliances, known conflicts, power dynamics_

```
[Enter observed dynamics: Who influences them? Who influences them?
Are there tensions with other members? Strategic alliances?]
```

#### Known Relationships with Competitors

```
[Enter: Have they worked with a competitor in the past? Do they have bias toward competitive solutions?
Do they know competitor representatives personally?]
```

#### Specific Communication/Engagement Strategy

_How will we best interact? What key messages should we emphasize? Who on our team is best suited to build a relationship with them?_

**Preferred Communication Channel**:
- [ ] Formal emails
- [ ] Phone calls
- [ ] In-person meetings
- [ ] Video calls
- [ ] Messaging/Instant

**Communication Style**:
- [ ] Analytical/Data-driven
- [ ] Visionary/Strategic
- [ ] Practical/Operational
- [ ] Relational/Empathetic

**Key Messages to Emphasize**:
1. ________________________________
2. ________________________________
3. ________________________________

**Who on Our Team**:
- **Account Owner**: ________________________________
- **Technical Contact** (if needed): ________________________________
- **Executive Sponsor** (if needed): ________________________________

**Contact Frequency**:
- [ ] Weekly
- [ ] Bi-weekly
- [ ] Monthly
- [ ] On-demand/milestone-based

**Next Actions with This Person**:

| Action | Target Date | Owner | Objective |
|---|---|---|---|
| | | | |
| | | | |

---

_(End of Individual Card - Replicate for each Buying Committee member)_

---

## BUYING COMMITTEE SUMMARY

### Buying Committee Visual Map

_Create a visual representation of the identified roles_

| Name | BC Role | Influence | Urgency | Opinion | Engagement Priority |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

### Overall Analysis

#### Buying Committee Role Coverage

- **Champion**: [ ] Identified [ ] Not identified [ ] Strength: ___
- **Economic Buyer**: [ ] Identified [ ] Not identified [ ] Access: ___
- **Technical Buyer**: [ ] Identified [ ] Not identified [ ] Access: ___
- **User**: [ ] Identified [ ] Not identified [ ] Access: ___
- **Coach**: [ ] Identified [ ] Not identified [ ] Strength: ___

#### Sentiment Distribution

- **Strongly Positive (++)**: ___ people
- **Positive (+)**: ___ people
- **Neutral (0)**: ___ people
- **Negative (-)**: ___ people
- **Strongly Negative (--)**: ___ people
- **Unknown (?)**: ___ people

#### Relationship Health Score

```
Calculation: (Positive x 2 + Neutral) / Total Stakeholders x 100

Health Score: ___%

Interpretation:
- >70%: Strong relational position
- 50-70%: Balanced position
- <50%: Weak position, corrective action needed
```

### Group Dynamics Observed

```
[Enter observations on overall Buying Committee dynamics:
- Who has the most influence on whom?
- Are there coalitions or factions?
- Decision-making process: consensus-driven or hierarchical?
- Internal conflicts that could impact the decision?
- Opportunities to leverage in the group dynamics?]
```

### Critical Gaps and Risks

#### Access Gaps

```
[Identify Buying Committee roles not yet reached or with limited access]

Example:
- We have not yet met the CFO (Economic Buyer for budget >$500K)
- Limited access to Users (only through Technical Buyer, no direct contact)
```

#### Red Flags

```
[Identify critical risks in the Buying Committee structure]

Example:
- No strong Champion identified (navigating blind)
- Technical Buyer strongly negative toward our solution
- Presence of a "Ghost Economic Buyer" (unclear who has final authority)
```

### Strategic Action Plan

#### Priority 1 (Immediate - Current Week)

| Action | Target Stakeholder | Owner | Objective | Deadline |
|---|---|---|---|---|
| | | | | |

#### Priority 2 (Short Term - Next 2 Weeks)

| Action | Target Stakeholder | Owner | Objective | Deadline |
|---|---|---|---|---|
| | | | | |

#### Priority 3 (Medium Term - Next Month)

| Action | Target Stakeholder | Owner | Objective | Deadline |
|---|---|---|---|---|
| | | | | |

### Competitive Strategy vs Buying Committee

```
[If there are known relationships with competitors, define strategy to neutralize or counter them]

Example:
- The Technical Buyer has worked with Competitor X in the past -> Strategy: Emphasize innovation and future-readiness (area where X is weak)
- Competitor Y has a relationship with the Economic Buyer -> Strategy: Work through Champion and Coach to build bottom-up consensus
```

---

## General Notes on the Buying Committee Mapping

_Space for overall strategic considerations_

```
[Enter overall strategic reflections:
- What is the most probable path toward a decision?
- What are the biggest obstacles?
- What are the opportunities to leverage?
- How does our sales strategy change based on this map?]
```

---

## Update Log

| Date | Update Made | Updated By |
|---|---|---|
| | | |
| | | |

---

## Completeness Checklist

Before considering the Buying Committee map "complete", verify:

- [ ] All 5 Buying Committee roles are identified (or documented why they are missing)
- [ ] We have direct or indirect access to the Economic Buyer and Champion
- [ ] At least ONE strong Coach has been identified
- [ ] Every key stakeholder has a complete individual card
- [ ] We have an engagement strategy for each stakeholder
- [ ] Sentiment is assessed for all stakeholders we have interacted with
- [ ] Critical gaps are identified with an action plan to close them
- [ ] The map has been shared and validated with the manager

---

## Best Practices for Using This Template

### Frequency of Updates

- **After every interaction** with any Buying Committee member
- **Weekly** for opportunities >$100K
- **Before critical milestones** (demo, proposal, negotiation)
- **When new stakeholders emerge** (add a card immediately)

### Sharing

- **With the Team**: Share in weekly deal reviews
- **With the Manager**: Formal review at every qualification gate
- **With Presales**: To personalize demos and presentations
- **With Exec Sponsor**: When escalation to executive level is needed

### Integration with Other Tools

- **MEDDPICC+RR (Criteria 2, 3, 4, 7)**: Buying Committee completeness feeds the qualification score
- **Business Case**: Personalize benefits for each stakeholder's goals
- **Proposal**: Create dedicated sections for each Buying Committee role (executive summary for Economic Buyer, tech appendix for Technical Buyer, etc.)
- **Negotiation**: Identify who will be at the table and their motivations

### Common Pitfalls to Avoid

**Mistake 1**: Stopping at the first contact (single-threaded)
**Solution**: Push to broaden the network, use the Coach for introductions

**Mistake 2**: Confusing title with Buying Committee role
**Solution**: A VP may be a User, a Manager may be the Economic Buyer

**Mistake 3**: Not updating the map
**Solution**: Update after every interaction -- sentiments and opinions change

**Mistake 4**: Ignoring the Users
**Solution**: Involve them early -- they can sabotage the implementation

**Mistake 5**: Not having a Coach
**Solution**: Actively cultivate at least one insider who can guide you
