# TEMPLATE - DEAL ONE PAGER (EXECUTIVE SUMMARY FOR MANAGEMENT)

**Document for C-Level Decision Makers**

---

## Project [Opportunity Name] - Strategic Partnership

**For: [Primary Benefit for the Client]**

### Reference Information

- **Client Company**: ________________________________
- **Project/Opportunity**: ________________________________
- **Prepared for**: [Name of the Decision Maker(s) this is addressed to]
- **Date**: ____/____/________

---

## Instructions for Completion

**Audience**: Senior decision makers (Economic Buyer/C-Level)

**Format**: Extremely concise (ideally **no more than one page**)

**Style**:
- Clear and focused on business outcomes
- Every sentence must have impact
- Avoid unnecessary technical jargon

**Objective**: Gain attention and a "yes in principle" to go deeper

---

## 1. YOUR STRATEGIC CHALLENGE / KEY OPPORTUNITY

_Describe in 1-2 sentences the critical business problem or strategic opportunity. It must be a topic relevant to top management._

[Client Company Name] is facing the challenge/opportunity of:

```
[Insert description of the strategic challenge/opportunity]
```

**Direct Impact On**:

```
[E.g., profitability, market share, operational efficiency, ability to innovate]
```

---

## 2. OUR PROPOSED STRATEGIC SOLUTION

_Describe in 1-2 sentences, clearly and non-technically, the solution or approach proposed._

We propose to implement:

```
[Insert description of the solution in business language, not technical]
```

**This approach will enable you to**:

```
[E.g., transform X, optimize Y, unlock Z]
```

---

## 3. KEY QUANTIFIED BENEFITS AND BUSINESS IMPACT

_This is the heart of the Summary. **Numbers, numbers, numbers!** Demonstrate ROI and concrete impact._

The collaboration on the **[Opportunity/Project Name]** project will deliver the following measurable benefits to **[Client Company Name]**:

### Quantifiable Benefits

**Benefit #1**: ________________________________

_Example: Reduction in operational costs by **X%** within **Y months**, equivalent to an estimated saving of **EUR ZZZ,ZZZ** annually._

**Benefit #2**: ________________________________

_Example: Increase in [Team Name] team productivity by **A%**, freeing up **B person-hours** weekly for higher-value activities._

**Benefit #3** _(if particularly strong)_: ________________________________

_Example: Increase in sales conversion rate by **C%**, generating a potential revenue increase of **EUR WWW,WWW**._

### Overall Strategic Impact

_Brief sentence linking these benefits to a broader strategic objective of the client._

```
Example: "These results will directly contribute to improving your margins
and strengthening your competitive position in market X."
```

---

## 4. OUR DISTINCTIVE VALUE ADDED (WHY US?)

_In 1-2 sentences, highlight what makes us the ideal partner for this specific project. Focus on unique differentiators relevant to C-Level._

Choosing us means relying on:

```
[Insert key differentiators]

Example:
...a partner with proven experience in your industry, a methodological approach
that guarantees rapid and sustainable results, and a team dedicated to your success.
```

---

## 5. INVESTMENT PROPOSAL AND NEXT STEPS

### Investment

To realize these benefits, we propose an investment of:

________________________________

_Or: "investment details will be defined in the full proposal"_

### Call to Action

We ask for your **approval** to proceed with:

```
[E.g., the next phase of the project, an in-depth meeting with the technical team,
the presentation of the detailed proposal]
```

---

## We Are at Your Complete Disposal

To further discuss this summary and answer any of your questions.

### Contacts

- **[Sales Rep/Account Manager Name]**: [Email] | [Phone]
- **[Other Key Contact (if applicable)]**: [Email] | [Phone]

---

## Best Practices for Usage

### When to Use the Deal One Pager

- **For C-Level escalation**: When executive approval is needed
- **Before strategic meetings**: As an opening for high-level discussion
- **To summarize complex deals**: When the technical proposal is too detailed for executives
- **During final decision phase**: To recap value before signing

### How to Optimize Impact

1. **Maximum Brevity**: If it exceeds 1 page, cut it down
2. **Credible Numbers**: Use only validated data or conservative estimates
3. **Business Language**: Zero technical jargon, everything in terms of business outcomes
4. **Visual Appeal**: Use clear formatting, bullet points, bold text
5. **Total Personalization**: Every sentence must resonate with that specific client

### Mistakes to Avoid

- **Listing technical features**: C-Level does not care
- **Generic benefits**: "Improves efficiency" says nothing
- **Too much information**: More than 1 page = it will not be read
- **Lack of numbers**: Without quantified ROI, no decision
- **Salesperson language**: Avoid superlatives and hype

### Integration with Other Tools

- **MEDDPICC+RR**: Use the quantified benefits from the qualification
- **Business Case**: Extract key numbers from the detailed business case
- **Buying Committee**: Personalize for the specific role of the Economic Buyer
- **Commercial Proposal**: The One Pager is the executive summary of the proposal
