# TEMPLATE - IDEAL CUSTOMER PROFILE (ICP)

## Reference Information:
- **Sales Rep (Author):** ____________________
- **Reference Customer for Analysis (if applicable, e.g., one of your best current customers):** ____________________
- **Date Created:** ____/____/____

---

## Section 1: Demographic/Firmographic Characteristics of the Ideal Customer
*Objective: Paint a clear picture of WHO our ideal customer is in measurable, identifiable terms.*

- **Primary Industry/Sector:** ____________________
  - *Guiding Question: In which industries have we historically had the most success or see the greatest potential? Are there specific niches?*

- **Company Size (e.g., annual revenue, number of employees):**
  - Revenue: From __________ to __________
  - Number of Employees: From __________ to __________
  - *Guiding Question: What "size" of company best fits our solutions and our capacity to serve?*

- **Geographic Location (if relevant):** ____________________
  - *Guiding Question: Are there priority geographic areas or where we have a competitive advantage?*

- **Organizational/Corporate Structure (e.g., centralized, decentralized, presence of specific key departments):** ____________________
  - *Guiding Question: What type of structure facilitates the adoption of our solutions?*

- **Technological/Digital Maturity:** ____________________
  - *Guiding Question: Is our ideal customer an early adopter, a follower, or a laggard? How does this influence their approach to our services?*

- **Financial Situation (e.g., growing, stable, restructuring):** ____________________
  - *Guiding Question: Which financial state indicates a greater propensity to invest in our solutions?*

- **Other Relevant Firmographic Factors (e.g., public/private ownership, part of a group, etc.):** ____________________

---

## Section 2: Typical Needs of the Ideal Customer
*Objective: Deeply understand WHAT drives our ideal customer to seek solutions like ours.*

- **Primary Business Needs (linked to achieving business objectives):**
  1. ____________________
  2. ____________________
  3. ____________________
  - *Guiding Question: What strategic objectives are our ideal customers trying to achieve and where can our solutions make a difference (e.g., increase efficiency, reduce costs, improve customer experience, innovate)?*

- **Operational Needs (linked to processes and daily activities):**
  1. ____________________
  2. ____________________
  - *Guiding Question: Which internal or external processes are critical for them and where do they encounter bottlenecks or inefficiencies that we can resolve?*

- **Personal Needs of Decision Makers (what motivates them individually -- e.g., career, recognition, stress reduction):**
  1. ____________________
  2. ____________________
  - *Guiding Question: Beyond business objectives, what do the people we interact with seek? How can we help them achieve their personal goals through our collaboration?*

---

## Section 3: Common Challenges of the Ideal Customer ("Pain Points")
*Objective: Identify the specific problems, the "pains" that our ideal customer is facing and that we are good at solving.*

- **Strategic Challenges (obstacles to achieving long-term objectives):**
  1. ____________________
  2. ____________________
  - *Guiding Question: What major obstacles or competitive threats prevent them from achieving their vision?*

- **Operational/Process Challenges (daily problems, inefficiencies):**
  1. ____________________
  2. ____________________
  - *Guiding Question: Where do they lose time, money, or resources due to non-optimal processes or obsolete technologies?*

- **Competition/Market-Related Challenges:**
  1. ____________________
  - *Guiding Question: How are competitive pressure or market changes impacting their business?*

- **Negative Consequences of "Not Acting" (Cost of Inaction):**
  - *Guiding Question: What happens if they don't address these challenges? What is the measurable impact (revenue loss, increased costs, market share loss, employee demotivation)?*

---

## Section 4: Preferred Purchasing Criteria of the Ideal Customer
*Objective: Understand WHAT is truly important to our ideal customer when choosing a vendor and a solution.*

- **Key Decision Factors (e.g., ROI, reliability, innovation, support, price, ease of use, integration, vendor reputation):**
  1. Criterion: ____________________ Importance (High/Medium/Low): ____
  2. Criterion: ____________________ Importance (High/Medium/Low): ____
  3. Criterion: ____________________ Importance (High/Medium/Low): ____
  - *Guiding Question: When they have to choose, what are the 3-5 non-negotiable elements or those that weigh the most? How can we align our offering with these criteria?*

- **Typical Decision-Making Process (who is involved, timelines, formal steps):**
  - *Guiding Question: How do they typically make decisions of this type? Is it a fast and agile process or long and structured?*

- **Attitude toward Risk/Innovation:**
  - *Guiding Question: Are they inclined to experiment with innovative solutions or do they prefer proven, low-risk paths?*

---

## Section 5: "Warning Signs" -- Characteristics of Customers to Avoid (Anti-ICP)
*Objective: Identify the distinctive traits of customers that, historically or potentially, represent a bad investment of our time and resources.*

- **Characteristics or Behaviors Indicating Low Probability of Success or High Unjustified Effort:**
  1. ____________________
  2. ____________________
  - *Example: Exclusive focus on the lowest price, lack of strategic vision, high internal conflict, unrealistic expectations.*
  - *Guiding Question: What were the "red flags" in lost opportunities or difficult projects in the past? Which customers "drain" us without providing mutual value?*

- **Incompatibility with Our Values or Way of Working:**
  - *Guiding Question: Are there companies or people with whom we simply cannot create a constructive partnership due to fundamental differences?*

---

## Section 6: Ideal Customer Profile Summary (ICP Elevator Pitch)
*Objective: Create a concise and memorable description of our ideal customer.*

- **Describe your Ideal Customer in 2-3 sentences:**
  ______________________________________________________________________________
  ______________________________________________________________________________
  ______________________________________________________________________________
