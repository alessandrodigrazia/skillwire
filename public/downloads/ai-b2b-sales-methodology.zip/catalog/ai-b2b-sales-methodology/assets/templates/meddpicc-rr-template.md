# TEMPLATE - MEDDPICC+RR OPPORTUNITY QUALIFICATION

**Strategic Tool for Evaluating Sales Opportunities**

---

## Reference Information

- **Sales Rep (Author)**: ________________________________
- **Customer/Prospect Company**: ________________________________
- **Opportunity/Project Name**: ________________________________
- **Date Created/Updated**: ____/____/________
- **Current Stage in Sales Cycle**: ________________________________

---

## Instructions for Completion and Scoring

### Guiding Principles

- **Assess honestly** each criterion based on available information. The goal is not to "pass the test" at all costs, but to have a realistic view of the opportunity.
- **Update the MEDDPICC+RR** as you acquire new information throughout the sales cycle.

### Scoring Scale for Each Criterion

#### Traffic Light

- **Green**: The aspect is positive, well-defined, and strongly supports the probability of winning. Risks are low or manageable.

- **Yellow**: The aspect presents uncertainties, requires further investigation, or carries medium risk. Specific actions are needed to move it to "Green".

- **Red**: The aspect is negative, undefined, or represents a significant obstacle/high risk for success. Requires immediate attention and could jeopardize the opportunity.

#### Numeric Scale (1-5)

- **5 (Very Strong/Positive)**: Excellent alignment, optimal situation.
- **4 (Strong/Positive)**: Good alignment, favorable situation.
- **3 (Neutral/Medium)**: Uncertain situation, neither positive nor negative, requires investigation.
- **2 (Weak/Negative)**: Poor alignment, unfavorable situation.
- **1 (Very Weak/Critical)**: Severe misalignment, critical situation.

**Note**: The traffic light gives an immediate overview, while the numeric score allows finer granularity to indicate intensity within that color.

### Using the Notes/Actions Fields

In the "Notes/Actions" sections, indicate the steps to take to:
- **Improve** the score (if Yellow or Red)
- **Consolidate** (if Green)

### Overall MEDDPICC+RR Score and GO/NO-GO Decision

**There is no rigid mathematical formula**, but:

- **Predominantly Green and scores 4-5**: Indicates a strong opportunity -> **GO**

- **Predominantly Yellow and scores 3**: Suggests caution and the need for a robust action plan to resolve uncertainties before investing too many resources -> **GO WITH CONDITIONS**

- **Predominantly Red and scores 1-2**: Especially on critical criteria like Economic Buyer, Metrics, or Identify Pain, should lead to serious consideration of a **NO-GO** or a radical strategy redefinition.

**Weight the relative importance of criteria**: A "Red" on Economic Buyer may be more blocking than a "Yellow" on Competition, depending on the stage and context.

**The final GO/NO-GO decision should be discussed as a team**, if possible, based on the overall analysis.

---

## MEDDPICC+RR QUALIFICATION CRITERIA

### 1. METRICS (Quantified Business Outcomes)

**Key Question**: Has the customer identified and agreed upon the measurable outcomes they expect from the solution?

#### Current Situation Description

_Has the customer defined specific, quantifiable business outcomes they expect? Are these metrics tied to strategic objectives? Have we helped articulate the before/after impact in numbers (revenue gain, cost reduction, time saved, risk mitigated)?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_How can we help the customer quantify the expected impact? What data or benchmarks can we provide? Which stakeholders can validate these metrics?_

```
[Enter specific actions]
```

---

### 2. ECONOMIC BUYER (Final Authority on Budget and Decision)

**Key Question**: Have we identified and engaged the person with the ultimate authority to approve budget and sign off on the deal?

#### Current Situation Description

_Who is the Economic Buyer? Have we met them directly? Do they understand and support the business case? Can they release budget independently or do they need further approval? What are their personal success metrics and priorities?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_What is our strategy to access or further engage the Economic Buyer? Can our Champion facilitate an introduction? What executive-level materials do we need to prepare?_

```
[Enter specific actions]
```

---

### 3. DECISION CRITERIA (How They Will Evaluate Solutions)

**Key Question**: Do we know the specific criteria the customer will use to evaluate and compare solutions, and are we aligned with them?

#### Current Situation Description

_What are the customer's formal and informal decision criteria? Are they documented? Can we influence or shape them? Are our strengths aligned with their top priorities? Have we differentiated against competitors on these criteria?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_How can we influence the decision criteria in our favor? Which criteria do we need to address or reframe? Can we introduce new criteria where we have a clear advantage?_

```
[Enter specific actions]
```

---

### 4. DECISION PROCESS (Steps to Reach a Decision)

**Key Question**: Do we fully understand the customer's decision-making process, including all steps, approvals, and timelines?

#### Current Situation Description

_What is the step-by-step process the customer follows to make a purchasing decision? Who is involved at each stage? What are the formal approval gates? Is there a procurement process? Have we validated this process with our Champion or Coach?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_What steps in the decision process are unclear? How can we help accelerate or streamline the process? Do we have a Mutual Action Plan aligned with their timeline?_

```
[Enter specific actions]
```

---

### 5. PAPER PROCESS (Contract, Legal, and Procurement)

**Key Question**: Do we understand the formal procurement, legal review, and contract signing process, and have we planned for it?

#### Current Situation Description

_What legal, procurement, and administrative steps are required to finalize the deal? Who handles contract review? What are typical timelines for legal/procurement? Are there standard terms that may conflict with ours? Have we engaged procurement early?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_What can we do proactively to facilitate and accelerate the paper process? Should we share redlines early? Do we need executive-to-executive engagement to unblock procurement?_

```
[Enter specific actions]
```

---

### 6. IDENTIFY PAIN (Recognized and Prioritized Business Pain)

**Key Question**: Does the customer perceive a real, urgent problem to solve or a clear opportunity to seize?

#### Current Situation Description

_Has the customer articulated a compelling business pain? Is the pain acknowledged across the organization or just by our contact? Is there a deadline or compelling event creating urgency? What are the consequences of "doing nothing" for the customer?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_How can we validate or increase the perception of urgency? What questions should we ask to surface the cost of inaction? Can we quantify the pain in financial terms?_

```
[Enter specific actions]
```

---

### 7. CHAMPION (Internal Advocate with Power and Influence)

**Key Question**: Have we identified a strong internal Champion who actively sells on our behalf within the organization?

#### Current Situation Description

_Who is our Champion? Do they have influence, access to the Economic Buyer, and a personal stake in our solution winning? Are they willing and able to advocate for us in internal meetings? Have we tested their commitment? Do they provide us with inside information and guidance?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_How can we strengthen our Champion's position? What ammunition (business case, ROI data, competitive insights) do they need to sell internally? Is there a secondary Champion we should cultivate?_

```
[Enter specific actions]
```

---

### 8. COMPETITION (Competitive Landscape and Win Strategy)

**Key Question**: Who are the main competitors and do we have a clear competitive strategy to win?

#### Current Situation Description

_Who are the active competitors on this opportunity? What is their perceived strength from the customer's perspective and their prior relationship? Do we have a clear and advantageous competitive strategy (e.g., Head-on, Flanking, Fragmenting) to differentiate and win? What is our estimated win probability?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_Do we need to deepen our analysis of a specific competitor? Is our differentiation strategy strong enough and effectively communicated? What actions can we take to improve our competitive position?_

```
[Enter specific actions]
```

---

### 9. RISKS (Factors That Could Derail the Deal)

**Key Question**: Have we identified all risks that could prevent the deal from closing or cause it to slip, and do we have mitigation plans?

#### Current Situation Description

_What internal or external factors could derail this deal? Are there organizational changes, budget freezes, competing priorities, or political dynamics that pose a risk? Have we stress-tested our assumptions? Is the customer's timeline realistic? Are there technical risks in implementation?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_What risk mitigation strategies do we have in place? How can we reduce exposure on the highest-impact risks? Who on our team should own each risk?_

```
[Enter specific actions]
```

---

### 10. ROADBLOCKS (Specific Obstacles to Overcome)

**Key Question**: Are there specific, identifiable obstacles (political, technical, financial, procedural) standing in the way of closing, and do we have a plan to remove them?

#### Current Situation Description

_What concrete obstacles have we identified? Are there hostile stakeholders, technical objections, budget constraints, or internal politics blocking progress? Is there a "no decision" risk? Have we mapped each roadblock to a resolution plan?_

```
[Enter detailed description]
```

#### Scoring

- **Traffic Light**: Green / Yellow / Red
- **Scale 1-5**: ___

#### Notes/Actions

_What specific actions will we take to remove each roadblock? Who is responsible? What is the timeline? Can our Champion help neutralize internal opposition?_

```
[Enter specific actions]
```

---

## QUALIFICATION SUMMARY AND GO/NO-GO DECISION

### Overall MEDDPICC+RR Score

- **Green Lights**: ___
- **Yellow Lights**: ___
- **Red Lights**: ___
- **Average Numeric Score** (if used): ___
- **Overall Qualitative Assessment**:
  - [ ] Strong Opportunity
  - [ ] Promising Opportunity with Reservations
  - [ ] Weak/High-Risk Opportunity

```
[Enter detailed qualitative assessment]
```

### Key Strengths of the Opportunity

_Based on criteria with Green/High scores:_

1. _________________________________
2. _________________________________
3. _________________________________

### Key Risks/Weaknesses of the Opportunity

_Based on criteria with Red/Yellow/Low scores:_

1. _________________________________
2. _________________________________
3. _________________________________

### Strategic Decision

- [ ] **GO**
- [ ] **NO-GO**
- [ ] **GO WITH SPECIFIC CONDITIONS**

#### Detailed Decision Rationale

_Based on the overall MEDDPICC+RR analysis and weighted criteria:_

```
[Enter detailed rationale]
```

### Key Next Actions

_If GO or GO WITH CONDITIONS -- must aim to turn Yellows/Reds into Greens:_

| # | Action | Owner | Deadline |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

---

**Last Review Date**: ____/____/________
**Next Planned Review**: ____/____/________

---

## Template Usage Notes

### When to Complete the MEDDPICC+RR

- **Initial**: After the first 2-3 discovery meetings
- **Update**: Before any significant investment (presales, custom demo, proposal)
- **Review**: Weekly for opportunities >$100K
- **Final**: Before the formal proposal

### Best Practices

1. **Be Honest**: Self-deception ("happy ears") is the enemy of strategic selling
2. **Involve the Team**: Conduct reviews with your manager or peers for objectivity
3. **Document Sources**: Cite where information comes from (meeting notes, email, coach)
4. **Update Regularly**: The MEDDPICC+RR is a living document, not static
5. **Use as a Guide**: If a criterion is Yellow/Red, create an action to improve it

### Critical Criteria (Red Flags)

If ANY of these is Red, the opportunity is extremely high risk:
- **Criterion 6 (Identify Pain)**: No pain = no decision
- **Criterion 2 (Economic Buyer)**: No Economic Buyer access = no deal
- **Criterion 7 (Champion)**: No Champion = flying blind

### Integration with Other Tools

- **Buying Committee Map**: Criteria 2, 3, 4, and 7 require a complete Buying Committee map
- **Business Case**: Criterion 1 (Metrics) benefits from a quantified business case
- **Competitive Analysis**: Criterion 8 requires competitive battlecards
- **Mutual Action Plan**: Criteria 4 and 5 should produce a formal MAP
