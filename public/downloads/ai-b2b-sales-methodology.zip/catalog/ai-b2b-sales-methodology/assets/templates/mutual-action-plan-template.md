# TEMPLATE - MUTUAL ACTION PLAN (MAP)
**[YOUR COMPANY] & [CLIENT NAME]**

## Reference Information:
- **Primary Contact (Our Team):** ...
  - Email: ... Phone: ...
- **Primary Contact (Client):** ...
  - Email: ... Phone: ...
- **Client Company:** ...
- **Opportunity/Project Name:** ...
- **MAP Creation Date:** ...
- **Next MAP Review Date:** ...
- **MAP Version:** ...

---

## SHARED OVERALL OBJECTIVE OF THE PROJECT/OPPORTUNITY
*(Describe clearly, concisely, and most importantly as **mutually agreed** between both parties, what the final outcome is that we intend to achieve through the actions defined in this MAP. It should be SMART: Specific, Measurable, Achievable, Relevant, Time-bound.)*

...

---

## PHASES AND ACTIVITIES TABLE

| Phase/Activity (ID) | Specific Action Description | Owner (Our Team) | Owner (Client) | Planned Start Date | Planned End Date | Expected Output/Milestone | Notes/Current Status (e.g., Not Started, In Progress, Completed, Blocked, etc.) |
|---|---|---|---|---|---|---|---|
| **PHASE 1: [Phase 1 Name - e.g., In-Depth Analysis]** | | | | | | | |
| 1.1 | ... | ... | ... | ... | ... | ... | ... |
| 1.2 | ... | ... | ... | ... | ... | ... | ... |
| **PHASE 2: [Phase 2 Name - e.g., Proposal Development]** | | | | | | | |
| 2.1 | ... | ... | ... | ... | ... | ... | ... |
| 2.2 | ... | ... | ... | ... | ... | ... | ... |
| **PHASE X: [Phase X Name - e.g., Decision and Close]** | | | | | | | |
| X.1 | ... | ... | ... | ... | ... | ... | ... |

*(Add additional PHASES and related Activities as needed)*

---

## ADDITIONAL NOTES AND SPECIFIC AGREEMENTS
*(Space for any clarifications, assumptions, dependencies between activities, or specific agreements between the parties not detailed in the table.)*

...

---

## NEXT MAP REVIEW

- **Agreed Date for Next Review:** ...
- **Review Format (e.g., meeting, call):** ...
- **Key Points to Verify/Discuss in the Next Review:**
  - ...
  - ...
  - ...

---

## Signatures for Acceptance (if applicable to formalize commitment):

**Our Team Representative**

_________________________

**Client Representative**

_________________________
