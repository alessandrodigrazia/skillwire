
# TEMPLATE - INDIVIDUAL VALUE PROPOSITION
*(Adapt the Message to Maximize Resonance and Impact)*

## Reference Information:
- **Sales Rep (Author):** ____________________
- **Client Company:** ____________________
- **Opportunity/Project Name:** ____________________
- **Date Created/Updated:** ____/____/____
- **Target Buying Committee Member:**
  - Full Name: ...
  - Official Position/Title: ...
  - Primary Buying Committee Role (for this opportunity): (Champion / Economic Buyer / Technical Buyer / User / Coach)

---

## Instructions for Completion:
*This template is used to create a specific, personalized value message for a single member of the Buying Committee (Champion, Economic Buyer, Technical Buyer, User, Coach). The goal is to demonstrate how our solution not only helps the company as a whole but also addresses the specific needs, goals, and evaluation criteria of this person. Base your work on the information gathered during the Buying Committee mapping (Member Analysis Sheet).*

---

### 1. SUMMARY OF SPECIFIC BUSINESS OBJECTIVES RELEVANT TO THIS STAKEHOLDER
*(Which strategic or operational company objectives are this person's direct responsibility or strong interest? How does this opportunity/project contribute to those objectives?)*

- **Relevant Business Objective #1:** ...
  - Description and connection to the stakeholder's role: ...
- **Relevant Business Objective #2 (if applicable):** ...
  - Description and connection to the stakeholder's role: ...

- **Guiding Questions:** What are the business KPIs this person is measured on or absolutely must achieve? How does our project directly impact these numbers or strategic priorities that matter to them?

---

### 2. SUMMARY OF RELEVANT PERSONAL OBJECTIVES (PERSONAL WIN)
*(What motivates this person at an individual level in this specific context? What are they seeking to achieve or avoid personally through the success of this project? E.g., visibility, career advancement, stress reduction, competence recognition, innovation, stability, avoiding failures or reputational risks.)*

- **Relevant Personal Objective #1:** ...
  - Evidence or hypotheses about this objective: ...
- **Relevant Personal Objective #2 (if applicable):** ...
  - Evidence or hypotheses about this objective: ...

- **Guiding Questions:** What's "in it" for them? How can this project make them shine or simplify their life? What personal fears or aspirations could we positively address? Remember, people also buy (and often primarily) for emotional and personal reasons!

---

### 3. THEIR PRIORITY DECISION CRITERIA (FOR THIS OPPORTUNITY)
*(What are the 2-3 most important factors this specific person will use to evaluate our proposal and the alternatives? Not the company's generic criteria, but their personal and professional filters.)*

1.  **Priority Criterion #1:** ...
    - Why is it important to them? ...
2.  **Priority Criterion #2:** ...
    - Why is it important to them? ...
3.  **Priority Criterion #3 (if applicable):** ...
    - Why is it important to them? ...

- **Guiding Questions:** What do they absolutely need to see in our proposal to say "Yes, this is for me/us"? What are their "hot buttons" for decision-making? What is non-negotiable for them?

---

### 4. HOW OUR SOLUTION SPECIFICALLY ADDRESSES THESE THREE POINTS
*(This is the core of the individual value proposition. Explicitly connect our offering to points 1, 2, and 3.)*

- **Alignment with Relevant Business Objectives:**
  - Our solution [Solution/Approach Name] directly contributes to [Relevant Business Objective #1 of the stakeholder] because [explain the mechanism, e.g., "by automating X, we free up resources for Y" or "by providing Z, we improve visibility on W"].
  - (any other connections)

- **Support for Personal Objectives:**
  - By implementing [Solution/Approach Name], you will be able to [Personal Benefit, e.g., "demonstrate leadership in innovation", "reduce your team's workload", "obtain more reliable data for your board presentations"].
  - (any other connections)

- **Response to Priority Decision Criteria:**
  - We know that [Priority Criterion #1] is fundamental for you. Our solution addresses this through [specific Feature/Aspect of the solution that satisfies the criterion].
  - Regarding [Priority Criterion #2], our approach guarantees [specific Feature/Aspect of the solution that satisfies the criterion].
  - (any other connections)

- **Guiding Questions:** Are we speaking their language? Are we striking the right chord? Is it clear how our solution is THE answer to THEIR specific needs and priorities?

---

### 5. QUANTIFIABLE AND QUALIFIABLE BENEFITS FOR THEM (AND THEIR AREA OF RESPONSIBILITY)
*(Translate solution features into concrete and, where possible, measurable benefits, specific to the impact they will have on this person and their department/area.)*

- **Quantifiable Benefit #1:** ...
  - Metric and expected impact (e.g., "Reduction in time for process X by Y% for their team", "Potential savings of EUR Z in their departmental budget").
- **Quantifiable Benefit #2 (if applicable):** ...
  - Metric and expected impact.
- **Qualitative Benefit #1:** ...
  - Impact description (e.g., "Greater reliability of data for their decisions", "Improved collaboration between their team and department Y", "Reduced risk of [specify]").
- **Qualitative Benefit #2 (if applicable):** ...
  - Impact description.

- **Guiding Questions:** What will change for the better in their daily work or in the results of their area thanks to us? Can we put numbers on these improvements, even if they are initial estimates?

---

### 6. PERSONALIZED KEY MESSAGE (The Elevator Pitch for This Stakeholder)
*(Synthesize in 1-2 powerful sentences the reason this person should support our solution. It should be the distillation of everything above.)*

"Mr./Ms. [Stakeholder Last Name], by collaborating with us on [Opportunity/Project Name] through our [Specific Solution Name], you will not only significantly contribute to [Key Business Objective for them], but also personally [Key Personal Benefit], thanks to our approach that guarantees [Response to their Priority Decision Criterion #1]."

Or (shorter):

"For you, Mr./Ms. [Stakeholder Last Name], our solution for [Opportunity/Project Name] means [Strongest Personal/Business Benefit] by directly addressing your priority of [Priority Decision Criterion #1]."

**Space for the Final Key Message:**
______________________________________________________________________________

---

### Additional Notes / Communication Strategy:
*(Any notes on how and when to present this individual value proposition, the stakeholder's preferred channels, possible objections to anticipate, etc.)*

...
