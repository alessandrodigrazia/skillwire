# TEMPLATE - FIRST MEETING DETAILED STRUCTURE

**Foundation for Preparing and Conducting a Successful First Meeting**

---

## Reference Information

### General Information

- **Sales Rep**: ________________________________
- **Client/Prospect Company**: ________________________________
- **Opportunity/Project Name**: ________________________________
- **Meeting Date and Time**: ____/____/________ at ______:______
- **Expected Duration**: _______ minutes

### Attendees

#### From the Client

**Primary Contact**:
- **Full Name**: ________________________________
- **Role**: ________________________________
- **Probable Buying Committee Role**: [ ] Champion  [ ] Economic Buyer  [ ] Technical Buyer  [ ] User  [ ] Coach
- **LinkedIn Profile**: ________________________________

**Other Client Attendees**:

| Name | Role | Probable Buying Committee Role | Notes |
|------|------|-------------------------------|-------|
| | | | |
| | | | |

#### From Our Team

**Our Attendees**:

| Name | Role | Responsibility in the Meeting |
|------|------|-------------------------------|
| | | |
| | | |

### Format

- **Location/Format**:
  - [ ] In-person at client's office (address: ________________________________)
  - [ ] In-person at our office
  - [ ] Video call (platform: ________________________________)
  - [ ] Phone call

---

## PRIMARY MEETING OBJECTIVE

**My specific objective for this meeting is**:
```
[Insert SMART objective - Specific, Measurable, Achievable, Relevant, Time-bound]

Examples:
Good: "Identify at least 2-3 priority client needs and obtain agreement for a technical demo within 2 weeks"
Good: "Map the Buying Committee (at least 3 key stakeholders) and schedule a meeting with the CIO"
Good: "Qualify the opportunity (budget, timeline, decision criteria) and propose a Mutual Action Plan"

Bad: "Get to know the client" (too generic)
Bad: "Present our company" (focus on us, not the client)
```

---

## PRE-MEETING: RESEARCH AND PREPARATION

### Research on the Client/Company

**Company Information Gathered**:
- **Industry**: ________________________________
- **Size**: _______ employees, revenue EUR ________________
- **Markets**: ________________________________
- **Main Products/Services**: ________________________________
- **Recent News** (last 3-6 months): ________________________________

**Sources**:
- [ ] Company website
- [ ] LinkedIn company page
- [ ] Google News
- [ ] Industry reports
- [ ] CRM (previous interactions)

---

### Research on the Primary Contact

**Personal Information Gathered**:
- **Professional background**: ________________________________
- **Years at company**: _______
- **Previous experience**: ________________________________
- **Education**: ________________________________
- **Professional interests** (from LinkedIn, articles, speeches): ________________________________

**Possible rapport-building hooks**:
```
[Identify 1-2 authentic hooks for initial small talk]

Examples:
- "I saw on LinkedIn that you attended [Event X]..."
- "I read that your company recently [News Y]..."
- "I see you have experience in [Sector Z], interesting because..."
```

---

### Hypotheses on Potential Needs

**Based on research, I hypothesize the client may have these needs**:

| Potential Need | Evidence/Clue | Questions to Validate |
|----------------|---------------|----------------------|
| | | |
| | | |
| | | |

**Note**: These are **hypotheses to validate**, not certainties. The meeting's objective is to discover real needs through questions, not to confirm our assumptions.

---

### Potentially Relevant Solutions

**Products/Services to keep in mind** (but NOT to "push" prematurely):

| Our Solution | Why it might be relevant | Similar Case Study/Reference |
|-------------|--------------------------|-------------------------------|
| | | |
| | | |

---

## MEETING STRUCTURE: 4 PHASES

The first meeting follows the **4-Phase Sales Conversation** structure:

1. **OPENING** (5-10 min) - Build rapport and establish agenda
2. **NEEDS ANALYSIS** (20-30 min) - Discover the situation, problems, impacts, desired benefits
3. **EMBRYONIC SOLUTION PRESENTATION** (10-15 min) - Connect needs to how we can help
4. **COMMITMENT AND NEXT STEPS** (5-10 min) - Obtain commitment for the next step

**Expected Total Duration**: _______ minutes

---

## PHASE 1: OPENING

**Estimated Duration**: 5-10 minutes

**Objective**: Build rapport, establish credibility, confirm agenda, and obtain agreement on meeting objectives.

### 1.1 Professional Greetings and Introductions

**Prepared approach**:
```
[How I introduce myself and our company in a way relevant to the contact]

Template:
"Good morning [Name], I'm [Your Name], [Your Role] at [Company].
We specialize in [Value Proposition brief and specific to their sector/role].
With me today is [Colleague], [Colleague's Role]."
```

**Considerations for this specific contact**:
```
[Notes on how to personalize the approach based on their role and style]

Examples:
- If they're a CFO -> Direct approach, focus on business outcomes and ROI
- If they're a CTO -> More technical approach, focus on innovation and best practices
- If they're an Operations Manager -> Practical approach, focus on efficiency and complexity reduction
```

---

### 1.2 Initial Rapport Building (Small Talk)

**Prepared hook** (based on research):
```
[Insert the hook identified during the research phase]

Examples:
"I saw that your company recently [Event/Recent News].
How is that impacting your [Relevant Area]?"

"I noticed on LinkedIn that you have experience in [Specific Background].
That's an interesting background for your current position."
```

**Important**: Keep small talk **brief** (1-2 minutes max) and **authentic**. Get to the point without being abrupt.

---

### 1.3 Statement of Meeting Purpose (Value Statement)

**Prepared Value Statement**:
```
[Opening sentence explaining why we are here and what we hope to achieve together]

Template:
"[Title] [Last Name], we're here today because, given your responsibility in
[Area of responsibility], we think we could concretely help you with
[Key hypothesized benefit based on research].

Today's objective is to better understand if [Topic] is a current priority for you
and, if so, how we could support you. Does that sound like a good starting point?"
```

**Value Statement for this meeting**:
```
[Insert your personalized value statement]
```

---

### 1.4 Agenda and Time Confirmation

**Agenda to propose**:
```
[Propose clear agenda and ask for confirmation]

Template:
"We have [X minutes] available, correct?
I was thinking of structuring our time like this:
1. First, I'd like to better understand your current situation regarding [Topic]
   and your priorities (about 20 minutes)
2. Then, if relevant themes emerge, I can briefly share how we've
   helped other clients in similar situations (10-15 minutes)
3. Finally, if there's interest, we define concrete next steps (5 minutes)

Does that sound reasonable? Is there anything else you'd like to add to the agenda?"
```

**Agenda for this meeting**:
```
[Insert personalized agenda]
```

---

### 1.5 Obtain Agreement on Meeting Objectives

**Alignment question**:
```
[Question to confirm we are aligned]

Template:
"At the end of this meeting, my objective is [Repeat objective].
From your perspective, what would make this meeting a success for you?"
```

**Important**: **Listen carefully** to the response. It may reveal priorities different from your assumptions. Adapt your approach accordingly.

---

### Expected Outputs from Phase 1

- [x] Positive climate and mutual trust established
- [x] Company credibility communicated
- [x] Agenda and timelines confirmed
- [x] Agreement on meeting objectives obtained
- [x] Permission to proceed with analysis phase

---

## PHASE 2: NEEDS AND BENEFITS ANALYSIS

**Estimated Duration**: 20-30 minutes

**Objective**: Deeply understand the client's current situation, their specific problems, the impact of these problems, and the benefits they seek in a solution.

**Key Principle**: In this phase, **YOU LISTEN, THE CLIENT TALKS**. Your job is to ask intelligent questions and take notes, not present solutions.

---

### Questioning Framework: Information -> Problem -> Impact -> Benefits -> Decision

Follow this logical flow to build a complete understanding:

```
1. INFORMATION (Current Situation)
   |
2. PROBLEM (Pain Point)
   |
3. IMPACT (Cost of Inaction)
   |
4. BENEFITS (Ideal Solution)
   |
5. DECISION (Criteria and Process)
```

---

### 2.1 INFORMATION Questions (Current Situation)

**Objective**: Understand the client's current context regarding the relevant area.

**Questions prepared for this meeting**:

1. **General context**:
```
[Insert 2-3 open-ended questions to understand the as-is situation]

Examples:
- "How do you currently manage [Relevant Process/Area]?"
- "Can you describe how your [Relevant Department/Team] is organized?"
- "What tools/systems do you use today for [Specific Activity]?"
```

Specific questions:
- ________________________________
- ________________________________
- ________________________________

2. **Objectives and priorities**:
```
[Questions to understand what they are trying to achieve]

Examples:
- "What are the main objectives for your [Department/Project] this year?"
- "What are you focusing on during this period?"
- "What needs to happen for [Project/Initiative] to be considered a success?"
```

Specific questions:
- ________________________________
- ________________________________

---

### 2.2 PROBLEM Questions (Identifying the "Pain Point")

**Objective**: Surface the challenges, frustrations, and obstacles the client is facing.

**Questions prepared for this meeting**:

1. **Problem identification**:
```
[Questions that surface the pain]

Examples:
- "What are the main challenges you're facing in [Area]?"
- "What isn't working as you'd like in the current process?"
- "If you could change one thing about your [Current System/Process], what would it be?"
- "What keeps you up at night regarding [Topic]?"
```

Specific questions:
- ________________________________
- ________________________________
- ________________________________

2. **Problem deep-dive**:
```
[Follow-up questions to better understand the problem]

Examples:
- "Can you give me a concrete example of when this problem manifested?"
- "How long has this situation been present?"
- "Have you already tried to solve this problem? What have you attempted?"
```

Follow-up questions:
- ________________________________
- ________________________________

---

### 2.3 IMPACT Questions (Quantifying the Pain/Cost of Inaction)

**Objective**: Get the client to reflect on the concrete impact (time lost, costs, missed opportunities, risks) of the problems that emerged.

**This is the most important phase**: If the client doesn't perceive a significant impact, they will never buy.

**Questions prepared for this meeting**:

1. **Operational impact**:
```
[Questions to quantify the practical impact]

Examples:
- "How much time/resources do you dedicate every [week/month] to managing this problem?"
- "How many people are involved in [Activity that could be automated]?"
- "How long does it take on average for [Problematic Process]?"
```

Specific questions:
- ________________________________
- ________________________________

2. **Financial impact**:
```
[Questions to quantify costs and missed opportunities]

Examples:
- "Can you estimate an approximate cost of this inefficiency?"
- "Are there business opportunities you're losing because of [Problem]?"
- "What is the cost of an error in [Critical Process]?"
```

Specific questions:
- ________________________________
- ________________________________

3. **Strategic impact**:
```
[Questions to connect the problem to strategic objectives]

Examples:
- "How does this problem impact your [Growth/Efficiency/Quality] objectives?"
- "If this problem persisted for the next 12 months, what would the consequences be?"
- "What does this problem prevent you from doing/achieving?"
```

Specific questions:
- ________________________________
- ________________________________

---

### 2.4 BENEFITS Questions (Visualizing the Ideal Solution)

**Objective**: Get the client to articulate the benefits they expect from a solution. Use their words to describe the "ideal world."

**Questions prepared for this meeting**:

1. **Ideal solution**:
```
[Questions to have them describe the desired state]

Examples:
- "If you could wave a magic wand, what would the ideal process look like?"
- "What would concretely change if this problem were solved?"
- "How will you measure the success of a solution to this problem?"
```

Specific questions:
- ________________________________
- ________________________________

2. **Benefit priorities**:
```
[Questions to understand what is most important]

Examples:
- "Between [Benefit A] and [Benefit B], which would be more impactful for you?"
- "If you had to choose the most important benefit, what would it be?"
```

Specific questions:
- ________________________________
- ________________________________

---

### 2.5 DECISION CRITERIA and BUYING PROCESS Questions

**Objective**: Understand how the client will make the decision, who will be involved, and what the key criteria are.

**Questions prepared for this meeting**:

1. **Evaluation criteria**:
```
[Questions about decision factors]

Examples:
- "When you evaluate solutions for this problem, what will be the most important factors?"
- "What is absolutely must-have vs nice-to-have in a solution?"
- "Are there specific [Budget/Time/Compliance] constraints to consider?"
```

Specific questions:
- ________________________________
- ________________________________

2. **Decision process**:
```
[Questions about the Buying Committee and the process]

Examples:
- "Who else will be involved in evaluating solutions for [Area]?"
- "How does the decision process typically work for projects of this type?"
- "Is there a budget already allocated or would it need to be requested?"
- "What is the ideal timeline for solving this problem?"
```

Specific questions (to start mapping the Buying Committee):
- ________________________________
- ________________________________
- ________________________________

---

### 2.6 Active Listening and Note-Taking

**Throughout Phase 2, remember to**:

**Listen more than you talk** (80/20 rule: client talks 80%, you 20%)

**Take detailed notes** on:
- Specific problems mentioned (use their exact words)
- Numbers and metrics shared (time, costs, volumes)
- Emotions and tone (frustration, enthusiasm, urgency)
- Names of other people mentioned (potential Buying Committee stakeholders)

**Use strategic silence**: After a powerful question, BE QUIET and let them respond (don't fill the silence)

**Ask follow-up questions**:
- "Can you tell me more about..."
- "That's interesting, can you give me an example?"
- "How do you feel about..."

**Rephrase to confirm understanding**:
- "If I understand correctly, you're saying that..."
- "In other words, the main problem is..."

---

### Space for Notes During the Meeting

**Problems emerged**:
```
[During the meeting, note key problems in the client's words here]
```

**Quantified impacts**:
```
[Numbers, metrics, costs mentioned]
```

**Desired benefits**:
```
[What the client hopes to achieve, in their words]
```

**Decision criteria emerged**:
```
[Factors the client considers important]
```

**Stakeholders mentioned**:
```
[Names of other people who might be part of the Buying Committee]
```

---

### Expected Outputs from Phase 2

- [x] Clear and shared understanding of needs, problems, and impacts
- [x] Identification of the most promising value areas
- [x] Preliminary information on the Buying Committee
- [x] Information on the buying process and decision criteria
- [x] Client who feels listened to and understood

---

## PHASE 3: EMBRYONIC SOLUTION PRESENTATION

**Estimated Duration**: 10-15 minutes

**Objective**: Connect the needs that emerged in Phase 2 to how we can help, focusing on benefits relevant to this specific client.

**Important**: This is NOT a standard company presentation. It is a **tailored conversation** based on what you learned in Phase 2.

---

### 3.1 Summarize Key Needs Emerged (from their perspective)

**Before presenting any solution**, summarize what you understood to:
1. Demonstrate that you listened
2. Confirm your understanding
3. Obtain their agreement before proceeding

**Prepared transition phrase**:
```
[How you transition from listening to solution]

Template:
"Thank you [Name] for sharing this detailed picture.
If I may summarize, it seems to me that the main challenges are:
1. [Problem 1 in their words]
2. [Problem 2 in their words]
3. [Problem 3 in their words]

And that the impact of these challenges is [Quantified impact emerged].

Did I understand correctly? Is there anything you'd like to add or correct?"

[WAIT FOR CONFIRMATION]

"Great. In light of this, I think we may be able to help.
May I briefly share how we've supported other companies in similar situations?"
```

**Summary to make during this meeting** (to complete after Phase 2):
```
[Insert here the 2-3 key needs that will emerge, using the client's exact words]
```

---

### 3.2 Present How We Can Help (Targeted Value Proposition)

**Need-to-Solution connection structure**:

```
For [Client Need 1],
our solution [Solution/Service Name]
can help you [Specific benefit connected to the need].

We did this for [Similar Client/Industry],
where they achieved [Quantified result].
```

**Prepared connection for the most likely solutions**:

#### Solution #1: ________________________________

**Connection to needs**:
```
[How this solution responds to the hypothesized needs]
```

**Key FAB (Features, Advantages, Benefits) to highlight** (for the contact's role):
```
[2-3 most relevant features/benefits]

Remember: Feature = What it does / Benefit = Why it matters to them

Example:
Bad - Feature alone: "The platform has real-time dashboards"
Good - FAB: "The platform has real-time dashboards, which means that
   [Contact's Role] can monitor [Metric] without waiting for weekly reports,
   reducing reaction time from days to hours."
```

---

#### Solution #2: ________________________________

**Connection to needs**:
```
[How this solution responds to the hypothesized needs]
```

**Key FAB to highlight**:
```
[2-3 most relevant features/benefits for this contact]
```

---

### 3.3 Provide Examples or Brief Relevant Case Studies

**Case Study #1 - Similar Client**:

**Client/Industry**: ________________________________
**Similar problem**: ________________________________
**Solution implemented**: ________________________________
**Results achieved** (quantified):
```
[Specific and measurable results]

Example:
- 40% reduction in [Process] time
- EUR 150K annual savings
- 25% productivity increase
- 60% error reduction
- ROI achieved in 8 months
```

---

**Case Study #2** (optional):

**Client/Industry**: ________________________________
**Similar problem**: ________________________________
**Results achieved**: ________________________________

---

### 3.4 Maintain Interactivity (Mental Test Drive)

**After presenting the solution-needs connection**, engage the client with validation questions.

**Prepared engagement questions**:
```
[Questions to test interest and gather feedback]

Examples:
- "How would you see the application of a similar approach in your specific context?"
- "Does this type of solution align with what you're looking for?"
- "Which aspects of what I've shared seem most relevant to you?"
- "Do you have questions about how this would work in your environment?"
```

Questions for this meeting:
- ________________________________
- ________________________________

**Important**: If the client expresses doubts or objections, DO NOT defend yourself immediately. Listen, ask questions to better understand the concern, then address it.

---

### Expected Outputs from Phase 3

- [x] Client broadly understands how we can help
- [x] Interest generated toward the proposed solutions
- [x] Initial client feedback on the potential fit of the solution
- [x] Any objections or concerns emerged and understood

---

## PHASE 4: COMMITMENT AND NEXT STEPS

**Estimated Duration**: 5-10 minutes

**Objective**: Obtain a concrete commitment for a clear and specific next step. **No meeting should end without an agreed next step.**

**This is the critical phase**: Without commitment, the deal dies.

---

### 4.1 Summarize Key Points and Value Discussed

**Prepared synthesis phrase**:
```
[Summary of key conversation points]

Template:
"[Name], thank you for this very useful conversation.
To summarize, we discussed:
- Your objectives of [Main objective]
- The challenges related to [Main problem]
- The impact of [Quantified impact]
- And how our solution [Solution Name] could help you [Key benefit]

Before defining next steps, is there anything else you'd like to add or explore?"
```

---

### 4.2 Propose a Clear and Logical Next Step

**The next step must be**:
- **Specific**: What exactly
- **With owner**: Who does it
- **With date**: By when
- **With objective**: Why (what value it adds)

**Possible next steps** (choose based on the client's level of interest):

#### Option A: High Interest -> Technical Demo / Workshop

```
"Based on what we've discussed, I think the logical next step
could be to organize a more in-depth [technical demo/workshop] where:
- We can show you exactly how [Feature X] would work in your context
- You can involve [Other relevant stakeholders, e.g., the IT team]
- We can go into the details of [Specific technical/functional aspect]

Does this seem useful? Could we do this in the next 2 weeks?"
```

#### Option B: Medium Interest -> Materials + Follow-up

```
"To give you time to evaluate further, I can send you:
- [Detailed case study] of [Similar client]
- [Technical material] on [Specific aspect discussed]
- [ROI calculator/Business case] for your context

And then we could reconnect [Next week/In 10 days] to discuss
any questions and decide whether to go deeper. Does that sound reasonable?"
```

#### Option C: High Interest + Ready -> Propose MAP (Mutual Action Plan)

```
"It seems to me there's a clear alignment between your needs and what we can offer.
Would it be useful to define together a Mutual Action Plan where we map out:
- The steps needed to reach a decision
- Who does what and by when (both from your side and ours)
- Key milestones

This way we both have clarity on the path forward.
Does it make sense to work together on this?"
```

---

**Next step proposed for this meeting** (to be decided based on client's response):

**Type of next step**:
- [ ] Technical demo / Proof of Concept
- [ ] Meeting with other stakeholders (specify roles)
- [ ] Send materials + follow-up call
- [ ] In-depth workshop
- [ ] Business case preparation
- [ ] Draft MAP (Mutual Action Plan)
- [ ] Other: ________________________________

**Details**:
```
[What exactly we will do, who will be involved, when]
```

---

### 4.3 Ask for Commitment

**Don't take commitment for granted. Ask explicitly.**

**Phrase to request commitment**:
```
[Direct commitment question]

Examples:
- "Do you agree with this next step?"
- "Does it make sense to you to proceed in this direction?"
- "Can we consider this our concrete next step?"
```

**If they hesitate or respond vaguely** ("I'll think about it and let you know"), **don't give up**:

```
"I understand. May I ask what you would need to feel more confident taking this step?"

Or:

"Perfect. To make sure I reach out at the right time,
when do you think you'll have had a chance to [Think/Evaluate/Discuss internally]?
Could we already schedule a call for [Specific date]?"
```

---

### 4.4 Handle Final Objections or Hesitations

**If the client raises objections in the final phase**:

**4-step Framework for handling objections**:

1. **Listen** to the complete objection without interrupting
2. **Acknowledge** the concern (it's legitimate)
3. **Clarify** with questions to understand the real objection
4. **Respond** with evidence or solutions

**Example**:
```
Client: "I don't know if we have budget for this..."

You: [Listen]
You: "I understand, budget is an important consideration." [Acknowledge]
You: "May I ask, is the budget an absolute constraint this year or is it a
     question of prioritization?" [Clarify]
Client: [Responds]
You: [Respond based on their answer - could be: propose phasing,
     help build business case, involve whoever controls budget, etc.]
```

**Common objections and prepared responses**:

| Objection | Clarification | Response |
|-----------|--------------|----------|
| "We don't have budget" | "Is it an absolute limit or a prioritization issue?" | [Prepare response] |
| "I need to discuss with the team" | "Who else needs to be involved? Can we include them in the next step?" | [Prepare response] |
| "It's not the right time" | "What needs to happen for it to become the right time?" | [Prepare response] |
| "We're evaluating other solutions" | "May I ask who you're evaluating and on what criteria?" | [Prepare response] |

---

### 4.5 Confirm Next Step: Date, Time, and Owners

**Once commitment is obtained, FIX THE DETAILS IMMEDIATELY** (don't leave it as "we'll be in touch"):

**Confirmation to obtain**:
```
[Specific details to lock in before closing]

- Next step: ________________________________
- Date and time: ____/____/________ at ______:______
- Expected duration: _______ minutes
- Participants (Client): ________________________________
- Participants (Our Team): ________________________________
- Location/Format: ________________________________
- Preparation required (Client): ________________________________
- Preparation required (Our Team): ________________________________
```

**Send calendar invite immediately** (if possible, even during the call):
```
"Perfect, I'll send you the calendar invite for [Date] right away so it's already in our schedules."
```

---

### 4.6 Thank and Close Positively

**Prepared closing phrase**:
```
[Professional and positive closing]

Template:
"Thank you again [Name] for the time dedicated today and for sharing so openly
about your situation. I'm convinced we can truly help you with [Key benefit].

Summarizing:
- I will send [Material/Info] by [Date]
- You will [Any client action]
- We will meet again on [Date of next step]

If in the meantime you have questions or want to explore something further, I'm at your complete disposal.

[If in person: Handshake]
[If virtual: "Thank you and see you soon!"]"
```

---

### Expected Outputs from Phase 4

- [x] Clear and agreed commitment for a specific next step
- [x] Date, time, and participants defined for the next meeting
- [x] Intermediate actions assigned (who does what by when)
- [x] Ideally, a draft MAP or agreement to create one
- [x] Positive and professional meeting close

---

## POST-MEETING: IMMEDIATE FOLLOW-UP

### Immediate Actions (within 24 hours)

#### 1. Send Calendar Invite
- [x] Calendar invite sent for next step
- [x] Correct participants included
- [x] Preliminary agenda in the invite body

#### 2. Send Meeting Memo (within 24-48 hours)

**Use the template**: `meeting-memo-template.md`

The Meeting Memo must include:
- Personalized acknowledgments
- Summary of objectives emerged (in their words)
- Summary of decision criteria discussed
- Hypothesized solution and benefits
- Next steps with responsibilities and dates

**Importance**: The Meeting Memo is your "proof" that you listened and understood. It drastically increases client commitment.

#### 3. Update CRM

Enter in CRM:
- Detailed meeting notes
- Stakeholders identified (start Buying Committee map)
- Needs emerged
- Next steps and dates
- Update opportunity phase
- Update estimated value (if emerged)

#### 4. Internal Debrief

If you involved colleagues in the meeting:
- [ ] 15-min debrief to align impressions
- [ ] Distribute responsibilities for follow-up actions
- [ ] Update strategy based on what emerged

---

### Short-Term Actions (within 1 week)

#### 5. Send Promised Materials

If you promised to send:
- [ ] Case study: ________________________________
- [ ] Technical documentation: ________________________________
- [ ] ROI calculator / Business case: ________________________________
- [ ] Other material: ________________________________

**Send with a personalized email** that references the specific needs that emerged.

#### 6. Begin Full Buying Committee Mapping

Based on what emerged:
- [ ] Complete `buying-committee-template.md` for the stakeholder met
- [ ] Identify other stakeholders to map (mentioned during the meeting)
- [ ] Plan strategy to access missing stakeholders

#### 7. Qualify Opportunity with MEDDPICC+RR

- [ ] Complete `meddpicc-rr-template.md` with gathered information
- [ ] Identify information gaps (MEDDPICC+RR criteria with low scores)
- [ ] Plan actions to close the gaps

---

## FINAL PREPARATION CHECKLIST

**Before the meeting, verify you have completed**:

### Information Preparation
- [ ] Client/company research completed
- [ ] Primary contact research completed
- [ ] Needs hypotheses formulated
- [ ] Relevant solutions identified
- [ ] Relevant case studies prepared

### Structural Preparation
- [ ] Primary meeting objective clear and specific
- [ ] Personalized value statement prepared
- [ ] Proposed agenda defined
- [ ] Key questions for each phase prepared

### Logistics Preparation
- [ ] Calendar invite sent and confirmed
- [ ] Video call link tested (if virtual)
- [ ] Materials/slides ready (if needed)
- [ ] Participating colleagues briefed (if involved)
- [ ] Notepad/CRM ready for notes

### Mental Preparation
- [ ] Mindset: "I'm here to help, not to sell"
- [ ] Focus: Listening > Presenting (80/20 rule)
- [ ] Clear objective: Leave with a concrete next step

---

## COMMON MISTAKES TO AVOID

### Mistake #1: Talking too much about our company at the beginning
**Problem**: Starting with 15 minutes of company presentation

**Solution**: Company presentation < 2 minutes. Immediate focus on the client.

---

### Mistake #2: Not asking enough questions
**Problem**: Jumping to the solution without understanding needs

**Solution**: Phase 2 (Needs Analysis) should take 50% of the meeting. Client talks 80%.

---

### Mistake #3: Not quantifying impact
**Problem**: Accepting vague problems without exploring impact

**Solution**: Always ask impact questions. No quantified impact = No urgency = No sale.

---

### Mistake #4: Presenting all features
**Problem**: Generic demo/presentation with all capabilities

**Solution**: Show ONLY what is relevant to the needs that emerged in Phase 2.

---

### Mistake #5: Not obtaining commitment for next step
**Problem**: Ending with "we'll be in touch soon" (= guaranteed ghosting)

**Solution**: ALWAYS set a specific next step with a date before closing.

---

### Mistake #6: Not sending timely follow-up
**Problem**: Sending a generic email after 3-4 days (or not sending one)

**Solution**: Personalized Meeting Memo within 24-48 hours. Strike while the iron is hot.

---

### Mistake #7: Not mapping the Buying Committee
**Problem**: Assuming the contact is "the decision maker" without verifying

**Solution**: Always ask questions about the Buying Committee ("Who else will be involved?"). Start mapping.

---

## RESOURCES AND RELATED TEMPLATES

### Templates to Use

**Before the meeting**:
- This template (`first-meeting-structure-template.md`)

**After the meeting**:
- `meeting-memo-template.md` - Send within 24-48 hours
- `buying-committee-template.md` - Map the stakeholder met
- `meddpicc-rr-template.md` - Qualify the opportunity

**For next steps**:
- `mutual-action-plan-template.md` - If client is ready for a mutual action plan
- `business-case-template.md` - If ROI needs to be quantified
- `strategic-sales-roadmap-template.md` - For complex opportunities

---

### Related Workflows

- `generate-post-meeting-summary.md` - Guide for creating the meeting memo
- `qualify-opportunity.md` - Qualification process with MEDDPICC+RR
- `map-decision-center.md` - Process for mapping the Buying Committee
- `create-business-case.md` - For building the economic case
