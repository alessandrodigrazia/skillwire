# TEMPLATE - ACCOUNT PLAN
*(Tool for Strategic Management and Growth of Key Accounts)*

## Account Information:
- **Customer Name:** ____________________
- **Primary Industry:** ____________________
- **Approximate Size (Revenue/Employees):** ____________________
- **Sales Rep/Account Manager Responsible:** ____________________
- **Plan Creation Date:** ____/____/____
- **Next Planned Review Date:** ____/____/____

---

## ACCOUNT EXECUTIVE SUMMARY
*(Objective: Provide a concise overview of the customer, their strategic importance, and the key goals of this plan.)*

- **Concise Description of the Customer and Their Business:**
  ______________________________________________________________________________

- **Strategic Importance of This Customer:**
  *(Why is this customer considered a key account? E.g., growth potential, strategic reference, long-term partnership, joint innovation).*
  ______________________________________________________________________________

- **Primary Goals of This Account Plan (next 12-24 months):**
  *(What do we specifically want to achieve with this customer in the indicated period? Be SMART).*
  1. ____________________
  2. ____________________
  3. ____________________

---

## IN-DEPTH CUSTOMER ANALYSIS
*(Objective: Demonstrate deep understanding of the customer's business, challenges, and goals. Reference and summarize key information from ICP and C-SWOT, if already completed.)*

- **Customer's Current Primary Business Needs:**
  ______________________________________________________________________________

- **Key Challenges (Internal/External) the Customer Is Facing:**
  ______________________________________________________________________________

- **Customer's Declared or Intuited Strategic Objectives (Short/Medium/Long Term):**
  ______________________________________________________________________________

- **Customer C-SWOT Summary (Key Highlights):**
  - Key Strengths: ____________________
  - Relevant Weaknesses (for us): ____________________
  - Market/Internal Opportunities for them: ____________________
  - Main Threats they face: ____________________

---

## BUYING COMMITTEE MAPPING AND KEY RELATIONSHIPS
*(Objective: Identify and understand the power and influence dynamics within the account.)*
*(Use or attach the "Buying Committee Stakeholder Analysis Card" for each key stakeholder. Summarize here or provide a relationship org chart.)*

- **Functional/Relational Org Chart (even schematic) with Buying Committee Roles for Key Areas of Interest:**
  *(Space for drawing or description)*

- **Key Stakeholders Identified (Name, Title, Buying Committee Role, Influence Level, Our Relationship):**
  1. **Name:** __________ **Title:** __________ **BC Role:** __________ **Influence (H/M/L):** __________ **Relationship:** (Excellent/Good/Adequate/Poor/To Build)
  2. **Name:** __________ **Title:** __________ **BC Role:** __________ **Influence (H/M/L):** __________ **Relationship:** __________
  3. **Name:** __________ **Title:** __________ **BC Role:** __________ **Influence (H/M/L):** __________ **Relationship:** __________

- **Identified Internal Champions/Sponsors:** ____________________
- **Identified Potential Detractors/Internal Obstacles:** ____________________
- **Observed Power Dynamics and Informal Relationships:** ____________________

---

## CURRENT PARTNERSHIP STATUS AND CROSS-BUSINESS UNIT SYNERGY POTENTIAL

- **Products/Services Currently Used by the Customer (specify the relevant team/division):**
  - Product/Service 1: ____________________ (Team: ________)
  - Product/Service 2: ____________________ (Team: ________)

- **Overall Customer Satisfaction Level (CSAT/NPS or qualitative):** ____________________
- **Current Annual Business Value (estimate):** $ __________
- **Estimated Growth Potential (LTV over next 3-5 years):** $ __________

- **Active Competitive Analysis on the Account:**
  - Main Competitor: ____________________ (Their strengths/weaknesses as perceived by the customer)
  - Other Competitors: ____________________

- **Cross-Business Unit Synergy Potential:**
  - **Business Unit #1 with Potential:** ____________________
    - Specific Solution/Competency of the BU: ____________________
    - Customer Need/Opportunity it would address: ____________________
  - **Business Unit #2 with Potential:** ____________________
    - Specific Solution/Competency of the BU: ____________________
    - Customer Need/Opportunity it would address: ____________________

---

## STRATEGIC OBJECTIVES FOR THE ACCOUNT (SMART - Next 12-24 months)

- **Revenue Objective #1:** E.g. Increase annual revenue with [Customer Name] by X% by [Date].
- **Penetration/Cross-selling Objective #1:** E.g. Introduce [Specific Solution Name] from [Team/BU Name] into the [Customer Department Name] by [Date].
- **Relationship Objective #1:** E.g. Be recognized by [Key Customer Stakeholder Name] as a trusted strategic advisor for [Specific Area] by [Date].
- **Other Strategic Objective (e.g., reference, case study, joint innovation):**

---

## SPECIFIC OPPORTUNITY IDENTIFICATION (Cross-selling, Up-selling, New Projects)

| Opportunity ID | Brief Description | Proposed Solution/Service | Customer Need Addressed | Estimated Potential Value ($) | Close Probability (High/Medium/Low) | Key Next Steps | Notes/Key Customer Stakeholder |
|---|---|---|---|---|---|---|---|
| OPP_001 | | | | | | | |
| OPP_002 | | | | | | | |
| OPP_003 | | | | | | | |

---

## STRATEGIC ACTION PLAN (Next 6-12 months)
*(Concrete actions to achieve the defined objectives, leveraging identified opportunities. Assign responsibilities and timelines.)*

| Key Strategic Action | Linked Objective | Owner | Teams Involved | Target Timeline (By) | Required Resources / Support Needed | Notes / Success KPIs |
|---|---|---|---|---|---|---|
| 1. E.g. Organize strategic workshop on [Topic X] with the customer's Buying Committee | Relationship Objective #1 | {{SALES_REP_NAME}} | {{TEAM_1}}, {{TEAM_2}} | {{ACTION_1_DATE}} | Presales support, demo materials | Obtain positive feedback and MAP |
| 2. {{ACTION_2}} | {{ACTION_2_OBJECTIVE}} | {{ACTION_2_OWNER}} | {{ACTION_2_TEAMS}} | {{ACTION_2_DATE}} | {{ACTION_2_RESOURCES}} | {{ACTION_2_NOTES}} |
| 3. {{ACTION_3}} | {{ACTION_3_OBJECTIVE}} | {{ACTION_3_OWNER}} | {{ACTION_3_TEAMS}} | {{ACTION_3_DATE}} | {{ACTION_3_RESOURCES}} | {{ACTION_3_NOTES}} |

---

## RISK ANALYSIS AND MITIGATION PLANS (Related to this Account Plan)

- **Risk #1:** E.g. Loss of our internal Champion [Champion Name].
  - Probability (H/M/L): ____ Impact (H/M/L): ____
  - Mitigation Plan: ____________________

- **Risk #2:** E.g. Competitor [Competitor Name] launches an aggressive offer.
  - Probability (H/M/L): ____ Impact (H/M/L): ____
  - Mitigation Plan: ____________________

*(Add other account-specific risks)*

---

## PLAN REVIEW AND UPDATE

- **Agreed Review Frequency:** (E.g. Quarterly, Semi-annual, or upon key events) ____________________
- **Key Indicators to Monitor for Plan Effectiveness:**
  1. ____________________
  2. ____________________
- **Notes for Next Review:**
  ______________________________________________________________________________
