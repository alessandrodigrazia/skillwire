# TEMPLATE - C-SWOT ANALYSIS
(Customer - Strengths, Weaknesses, Opportunities, Threats)

## Reference Information:
- **Sales Rep (Author):** ____________________
- **Customer Prospect:** ____________________
- **Opportunity/Project Name:** ____________________
- **Date Created:** ____/____/____

---

## Instructions for Completion:
The objective of this C-SWOT analysis is to deeply understand your customer prospect's context. For each element identified, don't stop at a simple description: dig deep to understand the **IMPACT** it has on their business (both positive and negative) and what **IMPLICATIONS** this carries for our sales strategy and value proposition. Be surgical!

---

## C-S: Customer STRENGTHS
*INTERNAL factors of the customer's business that represent a competitive advantage or area of excellence.*

| Identified Strength (What?) | Detailed Description (How does it manifest? Why is it a strength?) | IMPACT on the Customer's Business (What concrete benefits does the customer gain from this strength? E.g., market share, efficiency, reputation) | IMPLICATIONS for Our Sales Strategy (How can we leverage this strength? How can our solution further enhance it? Are there synergies?) |
|---|---|---|---|
| | | | |
| | | | |

**Incisive Guiding Questions:**
- What are they exceptional at? What is their recognized "superpower" in the market?
- What unique resources or capabilities do they possess that their competitors envy?
- Is this strength sustainable over time or is it at risk of fading?

---

## C-W: Customer WEAKNESSES
*INTERNAL factors of the customer's business that represent a disadvantage, an area for improvement, or a vulnerability.*

| Identified Weakness (What?) | Detailed Description (How does it manifest? Why is it a weakness?) | IMPACT on the Customer's Business (What problems or costs does this weakness generate? E.g., loss of efficiency, customer dissatisfaction, hidden costs) | IMPLICATIONS for Our Sales Strategy (How can our solution resolve or mitigate this weakness? Is this our "hook"?) |
|---|---|---|---|
| | | | |
| | | | |

**Incisive Guiding Questions:**
- Where do they "creak"? What is their Achilles' heel that they may be trying to hide?
- What holds them back from reaching their full potential? Are there inefficient processes or obsolete technologies?
- Is this weakness perceived internally or is it our own "insight"? How much real pain is it causing?

---

## C-O: Customer OPPORTUNITIES
*EXTERNAL factors (market trends, technological changes, regulatory shifts, competitor weaknesses, etc.) that could be leveraged to the customer's advantage.*

| Identified External Opportunity (What?) | Detailed Description (How does this trend/change manifest? Why is it an opportunity?) | Potential IMPACT on the Customer's Business (If they seized it, what advantages could they gain? E.g., new markets, revenue increase, competitive advantage) | IMPLICATIONS for Our Sales Strategy (How can we help the customer seize this opportunity? Is our solution an enabler?) |
|---|---|---|---|
| | | | |
| | | | |

**Incisive Guiding Questions:**
- What "moving trains" could they catch to accelerate their growth or improve their position?
- Are there "gaps" left by competitors that they could fill?
- Are they aware of these opportunities or do we need to "light the way"?

---

## C-T: Customer THREATS
*EXTERNAL factors (negative market trends, fierce new competitors, unfavorable regulatory changes, technological risks, etc.) that could jeopardize the customer's business or position.*

| Identified External Threat (What?) | Detailed Description (How does this risk/change manifest? Why is it a threat?) | Potential IMPACT on the Customer's Business (If it materializes, what damage could they suffer? E.g., market share loss, margin reduction, obsolescence) | IMPLICATIONS for Our Sales Strategy (How can we help the customer mitigate or neutralize this threat? Does our solution offer protection?) |
|---|---|---|---|
| | | | |
| | | | |

**Incisive Guiding Questions:**
- What "dark shadows" are looming on their horizon? Is there a wolf in sheep's clothing?
- What could bring down their house of cards if they don't act quickly?
- Are they underestimating an emerging risk that we can clearly see?

---

## Strategic Summary and Next Steps:
- **Key Insights from the C-SWOT Analysis:**
  1. ____________________
  2. ____________________
  3. ____________________

- **How do these insights influence our Value Proposition for this customer?**
  ________________________________________________________________________________

- **Actions to take / Missing information to gather:**
  1. ____________________
  2. ____________________
