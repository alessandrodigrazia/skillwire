# TEMPLATE - IDEAL SALES PROCESS

## Phase 1: Identification
- **Activities:**
  - Identify a target company based on the Ideal Customer Profile (ICP).
  - Gather and analyze information.
  - Identify possible areas of value.
  - Prepare the One Pager.
  - Define the ideal entry contact (person with Pain and Power).
  - Validate the entry strategy with a Coach, if possible.
  - Determine how to reach out to this person.
- **Phase Objective:** Obtain the first meeting.
- **Output:** Meeting at the appropriate level.

---

## Phase 2: Qualification
- **Activities:**
  - Conduct first meeting.
  - Gather information and compare against the MEDDPICC+RR qualification framework.
  - Identify the members of the Buying Committee.
  - Identify the Competition.
  - Define the Sales Team.
  - First Go/No-Go decision.
  - Use the Roadmap for complex projects.
  - Prepare a plan to address problematic aspects.
  - Ensure Buying Committee mapping is underway.
- **Phase Objective:** Develop the Mutual Action Plan.
- **Output:** Agreement on the Mutual Action Plan.

---

## Phase 3: 4-Phase Sales Conversation -- Stakeholder Engagement
- **Activities:**
  - Align the Sales Team with the Buying Committee.
  - Contact all members of the Buying Committee.
  - Develop a strong relationship with one or more Coaches.
  - Gather intelligence on: Stakeholder roles, Degree of influence, Urgency, Business and Personal objectives, Decision criteria, and Sentiment.
  - Define the Competitive Strategy.
  - Develop Individual Value Propositions.
  - Second Go/No-Go decision by the team.
- **Phase Objective:** Buying Committee under control.
- **Output:** Buying Committee under control.

---

## Phase 4: Proposal
- **Activities:**
  - Formal request for proposal from the Customer.
  - For projects entered late, seek to complete the activities from Phases 2 and 3.
  - Define the proposal content based on the needs identified in previous phases.
  - Review the draft proposal with the Coach.
  - Finalize and present the proposal.
  - Define and involve the delivery team.
  - Present the proposal to all key members of the Buying Committee.
  - Ensure that Buying Committee members experience your value proposition.
- **Phase Objective:** Present a Win-Win Proposal.
- **Output:** Win-Win Proposal Presented.

---

## Phase 5: Decision
- **Activities:**
  - Present the proposal to all key Buying Committee members not yet engaged.
  - Request feedback from the most influential Buying Committee members.
  - Monitor competitive activity and set traps.
  - Define a closing tactic.
  - Final negotiations.
  - Obtain the order.
  - Sign contracts.
  - Conduct the win/loss analysis with the customer.
- **Phase Objective:** Order.
- **Output:** Order.

---

## Phase 6: Implementation
- **Activities:**
  - Assign necessary resources.
  - Implement the solution.
  - Ensure implementation quality.
  - Maintain open communication at all levels during the implementation phase.
  - Exceed, where possible, the Customer's expectations.
  - Post-implementation review.
- **Phase Objective:** Develop as a Reference.
- **Output:** Delighted Customer.

---

## Phase 7: Account Development
- **Activities:**
  - Expand the relationship with the Customer.
  - Collect testimonials.
  - Prepare and conduct periodic planning meetings.
  - Ensure continuity of contacts with senior executives.
  - Define activities that provide added value to the customer.
  - Collect referrals.
  - Identify new sales opportunities.
  - Initiate the sales process for new opportunities.
- **Phase Objective:** New Opportunity.
- **Output:** New Opportunity.
