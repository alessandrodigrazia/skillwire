# TEMPLATE - The 65 Discovery Questions

## Business Goals
1. What are your goals for this project?
2. What do you want to achieve through this project?
3. Why are we meeting today?
4. Why did you choose to meet with me?
5. What do you expect from me?
6. If I had a magic wand -- which I don't -- what would you want me to help you achieve?
7. What are your goals for the next year in the area of...?
8. Would you be satisfied at the end of our journey together if...?
9. How can I help improve the skills of your team?
10. What do you want to achieve through...?

---

## Decision Criteria
11. On what criteria will you choose your next partner?
12. What will help you identify the best proposal for your company?
13. How will you choose your next partner?
14. What are you looking for in your next partner?
15. If I were your next partner, you would have chosen me because...?
16. Will you choose me if...?

---

## Buying Committee
17. Who will be involved in the decision?
18. What is the decision-making process for selecting your next partner?
19. Who will be involved in this project?
20. Who will be responsible for this project?

---

## Budget
21. What is the budget you have allocated for this project?
22. Roughly, what is the amount you have decided to invest in this project?

---

## Urgency
23. When do you plan to start?
24. In what period do you want to begin?
25. By when will you choose your next partner?
26. What are the timelines you have set for this project?

---

## Competition
27. Who have you already worked with on these topics?
28. What did you particularly appreciate?
29. What would you improve?
30. Are there other companies you are contacting for this project?
31. Which ones?
32. Who have you already met with?
33. What did you particularly like?

---

## Situation (SPICED -- Winning by Design)
34. What is the situation you are experiencing right now?
35. What are the challenges you are facing right now?
36. How is your sales organization structured?
37. How is your sales process structured?
38. How is your new customer acquisition process structured?
39. How is your new opportunity acquisition process structured?
40. How do you convince a customer to meet you for a first appointment?
41. How do you prepare for first appointments or customer meetings?
42. How do you structure your value propositions for customers?
43. How do you ensure you maximize your close rate?
44. What tools do you use to maximize the accuracy of your sales forecasts?
45. How do you develop new opportunities within existing customers?
46. How do you maximize customer retention?
47. What mechanism do you use to develop referrals?
48. How do you ensure you can access and engage the key decision-makers within the customer?
49. What do you do to monitor your competition and make sure you beat them on your sales opportunities?
50. What tools and methodology are you currently using?

---

## Problem
51. What are the main challenges you encounter in your current sales process?
52. What are the main inefficiencies in your sales organization?
53. What are the main inefficiencies in your new customer acquisition process?
54. What are the main difficulties you encounter in opening new opportunities?
55. What are the main difficulties you have in successfully closing deals?
56. If there were something you could improve, what would you change about your current approach?
57. What would you improve about the way you currently present your proposals?
58. What are the main challenges you encounter regarding pricing and potential discounting?
59. What do your customers say you could improve about your sales approach?

---

## Impact
60. If you had to quantify it, how much could you recover by improving the quality of your sales process?
61. How many more deals could you realistically close by improving the skills and abilities of your salespeople?
62. How many more opportunities could you open by improving the skills and abilities of your salespeople?
63. By how much could you reduce the discount percentage if your salespeople were better at communicating value to the customer?
64. By how much could you reduce deal cycle times by gaining access to the real decision-makers and optimizing the sales process?
65. What impact does the lack of a common methodology and shared tools have on your sales effectiveness?
