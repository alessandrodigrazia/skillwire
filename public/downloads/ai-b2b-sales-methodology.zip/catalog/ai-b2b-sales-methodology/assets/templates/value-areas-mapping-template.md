
# TEMPLATE - VALUE AREAS MAPPING
(Tool for First Contact Preparation and Initial Value Proposition Definition)

## Reference Information:
- **Sales Rep (Author):** ____________________
- **Client Prospect/Target Company:** ____________________
- **Opportunity/Project Name (if already defined):** ____________________
- **Date:** ____/____/____

---

## Instructions for Completion:
This tool is designed to focus your preparation by identifying areas where you can deliver the greatest value to the client. For each potential Value Area, complete the following sections. Be specific and base your work on preliminary research (C-SWOT, ICP, industry news, etc.). The goal is to formulate concrete hypotheses to validate during the first contact.

---

## VALUE AREA #1

**1. Client's Specific Problem/Opportunity (Their "Pain Point" or the Goal They Want to Achieve):**
   - **Description:** Detailed description of the problem the client is likely facing or the opportunity they might want to seize. Be as specific as possible.
   - **Guiding Questions:** What is the main challenge preventing the client from reaching their goals? What market or internal opportunity are they not fully capitalizing on? What are the direct and indirect consequences of this problem or missed opportunity (e.g., lost revenue, inefficiencies, risks, low morale)?

**2. Our Macro Solution That Addresses the Problem/Opportunity:**
   - **Description:** Identify the main solution or service that directly responds to the problem/opportunity described above. Provide a brief description of how the solution works in this context and what its key differentiating elements are.
   - **Guiding Questions:** Which of our specific offerings is best suited to solve this pain point? What are the 2-3 main reasons our solution is superior or better suited compared to alternatives (including competition or "doing nothing")?

**3. Target Person Within the Client Organization (Who Feels the "Pain" Most or Benefits from the Opportunity):**
   - **Role/Function:** Identify the specific role/function within the client organization that is most directly impacted by the problem or would benefit most from the solution.
   - **Name (if known):** ____________________
   - **Why is this person/role particularly sensitive to this Value Area?** What are their personal and professional goals that our solution could help achieve?
   - **Guiding Questions:** Who is the primary person responsible for resolving this problem or seizing this opportunity? Who has the authority to push for a solution? What are their main concerns and aspirations related to this area?

**4. Possible Impact Metrics or Initial Hypothesized Benefits (Quantitative and Qualitative):**
   - **Hypothesized Quantitative Benefit #1:** (e.g., reduction in operational costs by X% within Y months, revenue increase of EUR Z in the first year, process efficiency improvement of W%):
   - **Hypothesized Quantitative Benefit #2:**
   - **Hypothesized Qualitative Benefit #1:** (e.g., improved employee satisfaction, reduced compliance risk, enhanced brand image, greater decision-making agility):
   - **Hypothesized Qualitative Benefit #2:**
   - **Guiding Questions:** What measurable results can we realistically hypothesize? How do these benefits translate into a tangible advantage for the client's business and for the Target Person? Which client KPIs could improve thanks to our solution?

---

## VALUE AREA #2

_(Repeat the structure of Value Area #1)_

---

## VALUE AREA #3

_(Repeat the structure of Value Area #1)_

---

## Summary and Prioritization of Value Areas for the Initial Approach:

- **Primary Value Area (or Combination of Areas) to Focus On for the First Contact:**
  ________________________________________________________________________________

- **Rationale for the Choice (Why is this the most impactful or urgent for the client and for the Target Person?):**
  ________________________________________________________________________________

- **Key Initial Message (Elevator Pitch based on the chosen Value Area - max 2-3 sentences to capture interest):**
  ________________________________________________________________________________
