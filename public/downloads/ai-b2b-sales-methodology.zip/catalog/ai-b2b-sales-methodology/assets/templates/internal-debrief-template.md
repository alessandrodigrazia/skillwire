
# TEMPLATE - INTERNAL POST-MEETING DEBRIEF
*(Tool for Shared Analysis and Follow-up Planning)*

## Meeting Information:
- **Client/Prospect Company:** ____________________
- **Opportunity/Project Name (if applicable):** ____________________
- **Meeting Date and Time:** ____/____/____ at ____:____
- **Client Attendees (Name, Role):**
  1. ____________________
  2. ____________________
  3. (Add as needed)
- **Our Attendees (Name, Role):**
  1. ____________________
  2. ____________________
  3. (Add as needed)
- **Debrief Date:** ____/____/____
- **Completed by:** ____________________

---

## Instructions for Completion (Guide for the Team):
*This debrief should be completed as soon as possible after the meeting, ideally within a few hours, while details are still fresh. The goal is to create shared understanding, identify actions, and learn from every interaction. If a meeting transcript is available, AI can help pre-fill some sections.*

---

### Initial Meeting Objectives (From Preparation):
*(Brief recall of the objectives we set for this meeting).*
1. ____________________
2. ____________________

### Objectives Actually Achieved During the Meeting:
*(Honestly assess what we managed to accomplish relative to initial objectives).*
______________________________________________________________________________

### Key Points Emerged / Relevant New Information:
*(What did we learn that is new and significant? AI: If you analyzed the transcript, what are the emerging themes?)*

- **About the Client/Company (strategies, changes, culture, etc.):**
  ______________________________________________________________________________
- **About the Client's Needs/Problems ("Pain Points"):**
  (Confirmations, refutations of our hypotheses, new discoveries, stated priorities, urgency).
  ______________________________________________________________________________
- **About Our Solution/Proposal (Feedback received, interest, doubts):**
  ______________________________________________________________________________
- **About the Buying Committee (New stakeholders, influence shifts, alliances, role of those present):**
  ______________________________________________________________________________
- **About the Competition (Information on competitors, their positioning):**
  ______________________________________________________________________________
- **Other Relevant Information:**
  ______________________________________________________________________________

### Green Flags Observed (Positive Signals from the Meeting):
*(What client statements, questions, or behaviors indicate interest, alignment, or progress? AI: Did you detect positive signals in the transcript?)*
1. ____________________
2. ____________________

### Red Flags Observed (Objections, Issues, Risks Emerged):
*(What objections were raised? What doubts or concerns did the client express? What risks to the opportunity emerged? AI: Did you detect objections or concern signals in the transcript?)*
1. **Objection/Issue:** ____________________
   - How was it handled during the meeting? ____________________
   - Does it require additional follow-up? ____________________
2. **Objection/Issue:** ____________________
   - How was it handled during the meeting? ____________________
   - Does it require additional follow-up? ____________________

### Rapport and Meeting Dynamics Assessment:
*(How was the overall interaction? Was the client open, collaborative, skeptical, rushed? Was there good rapport?)*
______________________________________________________________________________

---

## Next Steps and Actions

### Next Steps Agreed with the Client (Actions, Owners, Timelines):
*(AI: What clear commitments were made by both parties?)*

1.  **Action:** ____________________
    - Owner (Client): ____________________
    - Owner (Our Team): ____________________
    - By: ____/____/____
2.  **Action:** ____________________
    - Owner (Client): ____________________
    - Owner (Our Team): ____________________
    - By: ____/____/____

### Internal Actions to Take (Immediate and Strategic Follow-up):
*(What do WE as a team need to do now?)*

1.  **Action:** E.g., Send summary email to the client.
    - Owner: ____________________ By: __________ (within 24-48h)
2.  **Action:** E.g., Update CRM with detailed notes and next steps.
    - Owner: ____________________ By: __________
3.  **Action:** E.g., Prepare the requested technical demo.
    - Owner: ____________________ By: __________

---

## What Did We Learn? (Team's "Win or Learn" Moment):

- **What worked particularly well in this meeting (approach, questions, materials, objection handling)?**
  ______________________________________________________________________________

- **What could we have done differently or better?**
  ______________________________________________________________________________

- **Key Lessons Learned for future meetings (with this or other clients):**
  ______________________________________________________________________________

---

## Required Updates to Existing Sales Tools:
*(Did this meeting provide information that requires an update to...)*

- [ ] **Ideal Customer Profile (ICP)?** (If yes, which aspects?)
- [ ] **Client C-SWOT Analysis?** (If yes, which aspects?)
- [ ] **Account Plan?** (If yes, which sections?)
- [ ] **MEDDPICC+RR Qualification Profile?** (If yes, which criteria?)
- [ ] **Opportunity Roadmap?** (If yes, which changes?)
- [ ] **Other?** (Specify) ____________________
