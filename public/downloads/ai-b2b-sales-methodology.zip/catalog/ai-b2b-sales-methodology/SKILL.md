---
name: ai-b2b-sales-methodology
description: AI-powered B2B enterprise sales methodology combining MEDDPICC+RR qualification, SPICED discovery, structured negotiation with ZOPA/BATNA, and 22 ready-to-use templates for the full sales cycle from prospecting to deal closure.
---

# AI-Powered B2B Sales Methodology

Comprehensive B2B enterprise sales methodology with frameworks, workflows, templates, and scripts for the full deal cycle.

**Core Capabilities**:
- Prepare strategic meetings with C-level executives
- Qualify opportunities using MEDDPICC+RR (10-criteria framework)
- Map buying committees (Champion, Economic Buyer, Technical Buyer, User, Coach)
- Build ROI-based business cases with quantified value chains
- Navigate complex multi-stakeholder deals
- Prepare structured contract negotiations with BATNA/ZOPA analysis
- Analyze RFQs and tenders with 3-phase methodology

---

## When to Use This Skill

Use this skill when you need to:
- **Qualify an enterprise deal** using MEDDPICC+RR (GO/NO-GO with action items)
- **Prepare for a client meeting** with a C-level executive or buying committee
- **Map a buying committee** (Champion, Economic Buyer, Technical Buyer, User, Coach)
- **Build a business case** with ROI, NPV, payback period, and TCO analysis
- **Prepare a structured negotiation** with BATNA/ZOPA analysis and trading variables
- **Run SPICED discovery questions** (Winning by Design framework) tailored by industry
- **Analyze an RFQ/tender** with administrative, technical, and commercial phases
- **Create a C-SWOT analysis** (Customer-focused SWOT) for strategic positioning
- **Generate email nurturing sequences** for prospect engagement
- **Document meeting outcomes** in multiple formats (memo, CRM, email, internal debrief)

---

## Skill Content Structure

### references/methodology/
Core sales frameworks

```
├── 01-tactical-selling.md      # 4-Phase Sales Conversation Framework
│                                 - Phase 1: Trust Building (Trust Equation - Maister/Green)
│                                 - Phase 2: Discovery (SPICED - Winning by Design)
│                                 - Phase 3: Solution Design (FAB model)
│                                 - Phase 4: Closing (strategic next steps)
│
├── 02-strategic-selling.md     # Strategic Selling for Complex Deals
│                                 - MEDDPICC+RR 10-criteria qualification
│                                 - Buying Committee roles and strategies
│                                 - Deal strategy and competitive positioning
│                                 - C-SWOT analysis methodology
│
├── 03-negotiation.md           # 5-Phase Negotiation Process
│                                 - Analysis → Preparation → Execution → Closure → Review
│                                 - BATNA analysis (Fisher & Ury)
│                                 - ZOPA definition and management
│                                 - If-Then Trading principle
│                                 - Trading variables and team roles
│
└── orchestration/              # Workflow routing and dependencies
    ├── decision-tree.md        # Intent classification → workflow routing
    ├── workflow-orchestration.md  # Workflow sequencing and integration logic
    ├── framework-dependencies.md  # Prerequisites mapping between frameworks
    └── prospect-research-methodology.md  # Anti-hallucination research protocol
```

### references/workflows/
12 standard sales workflows

```
├── prepare-meeting.md          # Strategic meeting preparation
│                                 → Output: Battle plan, C-SWOT, one-pager
│
├── qualify-opportunity.md      # MEDDPICC+RR qualification
│                                 → Output: GO/NO-GO recommendation
│                                 → Script: validate_meddpicc.py
│
├── map-decision-center.md      # Buying Committee mapping
│                                 → Output: Stakeholder map + engagement strategies
│
├── build-business-case.md      # Basic ROI justification
│                                 → Output: Executive business case
│                                 → Script: calculate_roi.py
│
├── business-case-advanced.md   # 6-section comprehensive business case
│                                 → PREREQUISITE: value-chain-analysis
│
├── value-chain-analysis.md     # Feature-to-value mapping
│                                 → Output: Quantified benefits by stakeholder
│
├── presentation-builder.md     # Executive presentations
│                                 → 4 structures: Problem-Solution, Strategic, ROI, Competitive
│
├── prepare-negotiation.md      # Contract negotiation preparation
│                                 → Output: Playbook with BATNA, ZOPA, trading variables
│
├── analyze-rfq.md              # RFQ/Tender response (7 deliverables)
│                                 → 3 phases: Administrative → Technical → Commercial
│
├── create-cswot.md             # Customer-focused SWOT analysis
│                                 → Output: Strategic leverage points
│
├── generate-nurturing-sequence.md  # Email nurturing campaign
│                                 → Output: 5-7 email sequence
│
├── generate-post-meeting-summary.md  # Meeting documentation
│                                 → 4 formats: Memo, CRM, Email, Internal Debrief
│
└── README.md                   # Complete workflow reference
```

### assets/templates/
22 standard output templates

```
├── meddpicc-rr-template.md            # MEDDPICC+RR 10-criteria qualification grid
├── buying-committee-template.md       # Buying Committee stakeholder map
├── decision-center-template.md        # Decision center roles and strategies
├── negotiation-zone-template.md       # Negotiation playbook (BATNA, ZOPA, trading variables)
├── discovery-questions-template.md    # SPICED discovery questions (Winning by Design)
├── ideal-sales-process-template.md    # Ideal sales process mapping
├── ideal-customer-profile-template.md # Ideal customer profile
├── value-chain-template.md            # Value chain analysis
├── c-swot-analysis-template.md        # Customer-focused SWOT analysis
├── competitive-analysis-template.md   # Competitive positioning analysis
├── account-plan-template.md           # Strategic account planning
├── business-case-template.md          # ROI business case
├── pre-meeting-checklist-template.md  # Meeting preparation checklist
├── deal-one-pager-template.md         # Deal summary one-pager
├── internal-debrief-template.md       # Internal team debrief
├── value-areas-mapping-template.md    # Value areas mapping
├── meeting-memo-template.md           # Meeting memo
├── one-pager-template.md              # Client-facing one-pager
├── mutual-action-plan-template.md     # Mutual action plan (joint next steps)
├── individual-value-proposition-template.md  # Stakeholder-specific value proposition
├── strategic-sales-roadmap-template.md      # Strategic sales roadmap
├── first-meeting-structure-template.md      # First meeting structure and agenda
└── README.md                          # Template index and usage guide
```

### scripts/
Deterministic calculation scripts (Python, no dependencies)

```
├── calculate_roi.py            # Financial calculations (ROI, NPV, Payback, TCO)
├── validate_meddpicc.py        # MEDDPICC+RR opportunity scoring and GO/NO-GO
├── generate_spiced_questions.py  # Industry-specific SPICED discovery questions
└── README.md                   # Script documentation and examples
```

---

## Quick Start

### Most Common: Prepare for Client Meeting

**Trigger**: "Prepare for meeting with [role] at [company]"

**Workflow**: `prepare-meeting`
**Files used**: `references/workflows/prepare-meeting.md` + `assets/templates/c-swot-analysis-template.md`
**Output**: Battle plan, C-SWOT analysis, discovery questions, one-pager

---

## Decision Tree: Which Workflow When?

**IMPORTANT**: For comprehensive intent classification, load `references/methodology/orchestration/decision-tree.md`.

### Quick Reference

| Scenario | Workflow | Key Output |
|----------|----------|------------|
| "Should I pursue this deal?" | `qualify-opportunity` | MEDDPICC+RR GO/NO-GO |
| "Prepare for meeting with CFO" | `prepare-meeting` | Battle plan + C-SWOT |
| "Map the buying committee" | `map-decision-center` | Stakeholder map + strategies |
| "Quantify the value" | `value-chain-analysis` | Feature-to-value mapping |
| "Build business case" | `build-business-case` | Executive ROI case |
| "Comprehensive ROI for executive" | `business-case-advanced` | 6-section business case |
| "Build presentation" | `presentation-builder` | Client deck |
| "Prepare for negotiation" | `prepare-negotiation` | Negotiation playbook |
| "Analyze this RFQ" | `analyze-rfq` | 7 deliverables |
| "Analyze competition" | `create-cswot` | Customer-focused SWOT |
| "Email nurturing campaign" | `generate-nurturing-sequence` | 5-7 email sequence |
| "Document this meeting" | `generate-post-meeting-summary` | 4 format options |

---

## Methodology Quick Reference

### 4-Phase Sales Conversation (Tactical Selling)

| Framework | Purpose | When | Attribution |
|-----------|---------|------|-------------|
| Trust Equation | Build rapport and credibility | Every interaction | Maister & Green, *The Trusted Advisor* |
| SPICED | Structured discovery questions | Discovery meetings | Winning by Design (Jacco van der Kooij) |
| FAB Model | Feature-Advantage-Benefit translation | Presentations, proposals | Standard sales methodology |
| Objection Handling | Listen-Validate-Reframe-Respond | Whenever objections arise | Standard sales methodology |

**File**: `references/methodology/01-tactical-selling.md`

### Strategic Selling

| Framework | Purpose | When |
|-----------|---------|------|
| MEDDPICC+RR (10 criteria) | Opportunity qualification | Before investing resources |
| Buying Committee (5 roles) | Stakeholder mapping | Multi-stakeholder deals |
| C-SWOT | Customer-focused analysis | Strategic positioning |

**File**: `references/methodology/02-strategic-selling.md`

### 5-Phase Negotiation

| Framework | Purpose | When | Attribution |
|-----------|---------|------|-------------|
| BATNA | Best alternative analysis | Contract phase | Fisher & Ury, *Getting to Yes* |
| ZOPA | Zone of possible agreement | Pricing discussions | Fisher & Ury, *Getting to Yes* |
| If-Then Trading | Conditional concessions | Every negotiation exchange | Standard negotiation principle |
| Trading Variables | Give/get balance | Negotiation planning | Standard negotiation methodology |
| 5 Team Roles | Negotiation team structure | Contract meetings | Standard negotiation methodology |

**File**: `references/methodology/03-negotiation.md`

---

## Workflow Dependencies

**IMPORTANT**: Some workflows require prerequisites. Never skip dependencies.

```
value-chain-analysis ──→ business-case-advanced (REQUIRED)
                    ──→ presentation-builder (RECOMMENDED)

qualify-opportunity ──→ map-decision-center ──→ prepare-negotiation
```

**Complete dependency map**: `references/methodology/orchestration/framework-dependencies.md`

---

## Quality Gates

### Business Case Review
- [ ] Problem statement linked to C-SWOT findings
- [ ] All benefits quantified (currency/time/percentage)
- [ ] Assumptions documented and sourced
- [ ] ROI calculation transparent and reproducible
- [ ] CFO would have enough information to decide

### Presentation Review
- [ ] Hook in first 2 slides
- [ ] Claims supported by evidence within 2 slides
- [ ] Speaker notes 2-3x more detailed than slide content
- [ ] Clear call to action

### Negotiation Playbook Review
- [ ] BATNA clearly defined (ours and theirs)
- [ ] ZOPA realistic with documented assumptions
- [ ] Trading variables balanced (high value/low cost trades first)
- [ ] Team roles assigned with clear responsibilities
- [ ] Walk-away point and exit strategy prepared

---

## Scripts Reference

| Script | Input | Output | When |
|--------|-------|--------|------|
| `calculate_roi.py` | Investment, benefits, timeline | ROI, NPV, Payback, TCO | Business case workflows |
| `validate_meddpicc.py` | 10 MEDDPICC+RR criteria scores | Weighted score, GO/NO-GO, action items | Opportunity qualification |
| `generate_spiced_questions.py` | Industry, use case | Tailored discovery questions | Meeting preparation |

---

## Core Principles

1. **C-Level Business Outcomes** - Quantify value in business metrics the buyer cares about
2. **Coaching Mindset** - Include rationale sections explaining WHY each step matters
3. **Enterprise-Grade Outputs** - Professional, CRM-ready deliverables
4. **Foundation Before Superstructure** - Always follow workflow dependencies
5. **Evidence Over Assumptions** - Source every claim, flag gaps explicitly

---

## Complete Documentation

- **Workflows**: `references/workflows/README.md`
- **Templates**: `assets/templates/README.md`
- **Scripts**: `scripts/README.md`
- **Orchestration**: `references/methodology/orchestration/workflow-orchestration.md`

---

Begin by describing what you need help with.
