# Workflow: Prepare Strategic Meeting

**Purpose**: Guide a salesperson through comprehensive preparation for a strategic client meeting, generating all necessary materials and strategic insights.

**Duration**: 30-45 minutes
**Output**: Complete battle plan with research, analysis, questions, and one-pager

---

## When to Use This Workflow

Use this workflow when you need to prepare for:
- First discovery meetings with new prospects
- Strategic meetings with C-level executives
- Meetings at critical inflection points in an opportunity
- Presentations to decision committees

**Prerequisites**:
- You have basic information about the prospect (company name, industry, context)
- You know who will attend the meeting
- You have some understanding of why they're meeting with you

---

## Overview: The 6-Step Process

This workflow follows a structured 6-step process:

```
1. Pre-Research → Gather intelligence
2. C-SWOT Analysis → Identify strategic leverage points
3. Value Areas → Define value propositions
4. One-Pager → Create leave-behind document
5. Discovery Questions → Prepare SPICED questions
6. Battle Plan → Synthesize final briefing
```

Each step builds on the previous one, creating a comprehensive preparation package.

---

## Step 1: Pre-Research Intelligence

### What This Step Does
Generates a comprehensive research briefing about the prospect to inform all subsequent analyses.

### Information Needed

**Required**:
- Prospect company name
- Industry/sector
- Meeting context (why are they interested?)

**Optional but Valuable**:
- Documents about the prospect (annual reports, website content, press releases)
- Previous meeting notes or emails
- Background on attendees (LinkedIn profiles, bios)
- Competitive intelligence

### Questions I'll Ask You

1. **Company Context**:
   - "What is [Company Name]'s primary industry and business model?"
   - "Do you have any background documents I can analyze?"

2. **Meeting Context**:
   - "What triggered this meeting? (e.g., inbound inquiry, your outreach, referral)"
   - "What are they looking to solve or achieve?"

3. **Attendees**:
   - "Who will be in the meeting? (names, titles)"
   - "What do you know about them professionally?"

### What You'll Receive

A **Pre-Research Briefing** that includes:
- Company overview and strategic priorities
- Industry trends and challenges
- Potential pain points and opportunities
- Initial hypotheses about their needs
- Recommended talking points
- Questions to validate assumptions

### Example Output Structure

```markdown
# Pre-Research Briefing: [Company Name]

## Company Overview
- Industry: Financial Services - Insurance
- Size: 5,000 employees, €1.2B revenue
- Key Business Lines: Property & Casualty, Life Insurance
- Recent News: Announced digital transformation initiative

## Strategic Context
- CEO publicly committed to "modernization" by 2025
- Legacy systems (mainframe-based) causing agility issues
- Losing market share to insurtech startups

## Hypothesis on Pain Points
1. **Legacy Tech Debt**: Core systems are 20+ years old
2. **Customer Experience Gap**: Digital-native competitors winning younger customers
3. **Operational Inefficiency**: Manual processes in underwriting

## Initial Value Proposition Angles
1. Cloud-native platform → faster time-to-market for new products
2. AI-powered underwriting → reduce costs + improve accuracy
3. Omnichannel customer experience → compete with insurtechs

## Questions to Validate
- What % of policies are still processed manually?
- What is their current time-to-market for new products?
- Have they evaluated build vs buy?
```

---

## Step 2: C-SWOT Analysis

### What This Step Does
Analyzes the prospect from THEIR perspective: their Customer Strengths, Weaknesses, Opportunities, and Threats. This is not about YOU—it's about understanding THEM deeply.

### Information Needed

**Builds on**:
- Pre-Research from Step 1

**Additional Input**:
- Any specific knowledge you have about their competitive position
- Information about their current state (technology, processes, team)

### Questions I'll Ask You

1. **Strengths**:
   - "What are [Company]'s existing competitive advantages?"
   - "What do they do well today?"

2. **Weaknesses**:
   - "What are their known pain points or limitations?"
   - "Where are they vulnerable?"

3. **Opportunities**:
   - "What market opportunities could they capture?"
   - "What untapped potential do they have?"

4. **Threats**:
   - "Who are their key competitors?"
   - "What external factors threaten their business?"

### What You'll Receive

A **C-SWOT Analysis Matrix** with:
- 4 quadrants (Strengths, Weaknesses, Opportunities, Threats)
- 3-5 elements per quadrant
- Each element includes: description, impact assessment, implications for your approach

### Example Output Structure

```markdown
# C-SWOT Analysis: [Company Name]

## STRENGTHS (What They Do Well)
1. **Strong Brand Legacy**
   - Impact: HIGH
   - Description: 80 years in market, trusted by enterprise customers
   - Implication for Us: Position as "partner that protects their legacy while modernizing"

2. **Financial Stability**
   - Impact: MEDIUM
   - Description: Profitable, strong balance sheet
   - Implication for Us: Budget likely available; focus on ROI not just cost

## WEAKNESSES (Their Vulnerabilities)
1. **Legacy Technology Stack**
   - Impact: CRITICAL
   - Description: Mainframe-based core systems, slow to change
   - Implication for Us: PRIMARY PAIN POINT - our cloud modernization story is core

2. **Aging Customer Base**
   - Impact: HIGH
   - Description: Average customer age 55+, losing millennial/Gen-Z market
   - Implication for Us: Emphasize omnichannel UX and digital-native features

## OPPORTUNITIES (Market Potential)
1. **Insurtech Disruption**
   - Impact: HIGH
   - Description: Could acquire or partner with insurtechs
   - Implication for Us: Position our platform as "enabler of innovation"

## THREATS (External Risks)
1. **Regulatory Compliance**
   - Impact: CRITICAL
   - Description: New data privacy regulations (GDPR, etc.)
   - Implication for Us: Emphasize compliance and security features
```

---

## Step 3: Value Areas Definition

### What This Step Does
Translates the C-SWOT analysis into 4 concrete value propositions tailored to this specific prospect.

### Information Needed

**Builds on**:
- C-SWOT Analysis from Step 2
- Your solution's capabilities

**Additional Context**:
- Which Our Company solutions are you proposing?
- Any specific differentiators you want to highlight?

### Questions I'll Ask You

1. **Solution Context**:
   - "Which Our Company offerings are most relevant for this prospect?"
   - "What makes your approach unique for their situation?"

2. **Prioritization**:
   - "Are there specific weaknesses or opportunities you want to focus on?"

### What You'll Receive

A **Value Areas Document** with 4 value propositions, each including:
- **Title**: Catchy, benefit-focused name
- **Problem**: The specific problem it solves (from C-SWOT)
- **Solution**: How Our Company addresses it
- **Target Audience**: Which Buying Committee roles care most
- **Benefits**: Quantified where possible

### Example Output Structure

```markdown
# Value Areas: [Company Name]

## Value Area 1: "Accelerate Innovation Without Ripping Out Legacy"
**Problem**: Current mainframe systems create 9-12 month lead time for new product launches. Insurtechs can launch in weeks.

**Solution**: Our hybrid cloud architecture wraps around existing core systems, enabling rapid development of new digital services without replacing the mainframe.

**Target Audience**: CTO (technical feasibility), CEO (strategic urgency), Product Owners (time-to-market)

**Expected Benefits**:
- Reduce time-to-market from 9 months to 6 weeks
- Launch 5x more product experiments per year
- Maintain compliance with existing core systems

**Proof Points**: [Insurance Company X] launched 12 new digital products in Year 1 vs 2 in previous 5 years

---

## Value Area 2: "Capture the Millennial Market with Omnichannel UX"
[Similar structure]

## Value Area 3: "AI-Powered Underwriting for 40% Cost Reduction"
[Similar structure]

## Value Area 4: "Cloud Economics: OPEX Model for Transformation"
[Similar structure]
```

---

## Step 4: One-Pager Creation

### What This Step Does
Creates a visually appealing, 1-page document you can leave with the prospect after the meeting. It summarizes your understanding of their challenge and your proposed value.

### Information Needed

**Builds on**:
- All previous steps
- Meeting details (date, attendees)

### Questions I'll Ask You

1. **Customization**:
   - "Do you want to emphasize all 4 value areas or focus on 1-2?"
   - "Any specific branding or design preferences?"

2. **Tone**:
   - "Is this for a technical audience (CTO) or business audience (CEO/CFO)?"

### What You'll Receive

A **One-Pager Document** structured as:
- Header (Our Company branding + prospect logo)
- "Our Understanding" section (their challenge)
- "Our Approach" section (your solution)
- Value proposition highlights (key benefits)
- Next steps / call to action

### Example Output Structure

```markdown
# One-Pager: Digital Transformation Partnership
## [Company Name] + Our Company

### Our Understanding
[Company] faces a critical challenge: maintaining your market leadership while legacy systems slow innovation. With insurtechs capturing the millennial market and regulatory pressures increasing, the status quo threatens long-term competitiveness.

### Our Approach
Our Company's Insurance Modernization Framework enables you to:
✓ Modernize incrementally without "rip and replace"
✓ Launch digital products 10x faster
✓ Reduce underwriting costs by 40% with AI
✓ Ensure compliance at every step

### Why This Matters
- **Time-to-Market**: 6 weeks vs 9 months
- **Cost Efficiency**: €5M annual savings (estimated)
- **Market Share**: Capture millennial segment
- **Risk Mitigation**: Cloud security + compliance

### Proven Track Record
15+ insurance carriers transformed, including [Reference Client A] and [Reference Client B]

### Next Steps
- Deep-dive discovery workshop (proposed: [Date])
- Technical architecture review
- Business case development
```

---

## Step 5: Discovery Questions (SPICED Framework, Winning by Design)

### What This Step Does
Generates 15 strategic questions (3 per SPICED category, based on the Winning by Design methodology) designed to validate your hypotheses and uncover information critical for advancing the opportunity.

### Information Needed

**Builds on**:
- All previous steps

**Mode Selection**:
- **Consultant Mode** (default): Empathetic, exploratory questions
- **Challenger Mode**: Provocative questions that challenge assumptions

### Questions I'll Ask You

1. **Approach**:
   - "Which mode do you prefer: Consultant (empathetic) or Challenger (provocative)?"

2. **Specific Focus**:
   - "Are there particular areas you want to dig deeper on?"

### What You'll Receive

A **Discovery Question Bank** with 15 questions across 5 categories:

**S (Situation)**: Understand current state
**P (Pain)**: Identify problems
**I (Impact)**: Quantify business impact
**CE (Critical Event)**: Uncover urgency, timing pressures, and critical deadlines
**D (Decision)**: Map decision process

Each question includes a **Rationale** explaining WHY you're asking it.

### Example Output Structure

```markdown
# Discovery Questions: [Company Name]

## S - SITUATION (Current State)
### Question 1
**Q**: "Can you walk me through your current process for launching a new insurance product, from concept to market?"

**Rationale**: Establishes baseline for time-to-market. Will reveal bottlenecks and manual steps that our solution addresses.

### Question 2
**Q**: "What percentage of your underwriting is still manual vs automated today?"

**Rationale**: Quantifies the automation opportunity. Sets up the AI-powered underwriting value area.

### Question 3
**Q**: "How would you describe your current tech stack architecture? What are the core systems that everything depends on?"

**Rationale**: Technical discovery. Identifies integration challenges and validates hybrid approach.

---

## P - PAIN (Problems)
### Question 4
**Q**: "When you think about competing with digital-native insurtechs, what keeps you up at night?"

**Rationale**: Emotional question to uncover perceived threats. Opens up strategic discussion.

### Question 5
**Q**: "Where do you feel the legacy systems are holding you back the most?"

**Rationale**: Validates weakness from C-SWOT. Helps prioritize which pain to solve first.

[Continue for all 15 questions...]

---

## QUESTION SEQUENCING NOTES
- Start with Situation questions (non-threatening, factual)
- Move to Pain once rapport is established
- Impact questions require trust—ask after they've opened up
- Critical Event questions create urgency—use mid-to-late
- Exploration questions are co-creative—use when they're engaged
- Decision questions are tactical—save for end of meeting
```

---

## Step 6: Final Battle Plan

### What This Step Does
Synthesizes all previous steps into a concise, 1-page briefing for the salesperson. This is YOUR internal cheat sheet for the meeting.

### Information Needed

**Builds on**:
- All previous steps (this is a synthesis)

### What You'll Receive

A **Battle Plan** that includes:
- **Objective**: What you want them to Think, Feel, and Do
- **Leverage**: Your strongest, most provocative argument
- **Objection**: The #1 objection to expect and how to handle it
- **Closing Action**: The specific next step to propose
- **Key Points**: 3 tactical "munitions" (data, reframe question, anecdote)

### Example Output Structure

```markdown
# Battle Plan: Meeting with [Company Name]
**Date**: [Meeting Date]
**Attendees**: CTO, VP Digital, Head of Underwriting

---

## OBJECTIVE (Think-Feel-Do)

**THINK**: "Our legacy systems are a liability, not an asset. We need to act now."
**FEEL**: Urgency + Confidence (they CAN transform without massive risk)
**DO**: Commit to a 2-day discovery workshop next week

---

## LEVERAGE (Our Provocative Thesis)

**Title**: "The Incumbent's Dilemma: Why Waiting Is More Expensive Than Acting"

**Content**:
"Most insurers think, 'We'll modernize when we have time.' But the data shows that waiting costs more than acting. Every quarter you delay, you lose 2% market share to insurtechs AND your tech debt compounds by €500K. The real risk isn't transformation—it's staying still."

**Delivery**: Use after they express concern about "disruption risk." Reframe risk from "change" to "inaction."

---

## OBJECTION TO DEFUSE

**Title**: "The Integration Nightmare Objection"

**Expected Quote**: "We've tried this before. Integrating with our mainframe is a nightmare. Every vendor promises it, but it never works."

**Response** (3-part):
1. **Validate**: "You're right to be skeptical. Mainframe integration IS complex, and many vendors overpromise."
2. **Reframe**: "But the question isn't 'Can we integrate?'—it's 'Can you afford NOT to?' The cost of your current 9-month product cycle is [€X based on pre-research]."
3. **Prove**: "We've done this exact integration 8 times in banking (similar mainframe environment). Let me show you the architecture from [Reference Client]."

---

## CLOSING ACTION (The Ask)

**Title**: "Discovery Workshop Proposal"

**Content**:
"Based on our conversation today, I propose a 2-day discovery workshop next week where we:
- Day 1: Map your current architecture and identify integration points
- Day 2: Co-design a proof-of-concept roadmap with your team

**Value for You**: By the end, you'll have a concrete, risk-mitigated plan—whether you work with us or not. And if there's no fit, we'll tell you honestly."

**Why This Works**: Low risk, high value. Positions us as consultative, not just transactional.

---

## KEY POINTS (Tactical Munitions)

1. **Data Point**: "Insurtechs have captured 18% of the under-35 market in just 3 years. At current trajectory, that's 30% by 2026."

2. **Reframe Question** (based on C-SWOT): "You mentioned your brand legacy as a strength. But I'm curious: could it also be a weakness? Do younger customers see 'legacy' as 'trusted' or 'outdated'?"

3. **Anecdote**: "[Insurance Company X], a similar-sized incumbent, was losing €10M/year to digital competitors. We helped them launch a mobile-first product in 8 weeks. It captured 50K millennial customers in the first quarter—a segment they'd written off."

---

## PRE-MEETING CHECKLIST
- [ ] Review C-SWOT and Value Areas (refresh memory)
- [ ] Print One-Pager (2 copies—one for them, one for you)
- [ ] Prep discovery questions in notes
- [ ] Confirm attendees (any changes since planning?)
- [ ] Bring case study materials (Insurance Company X)
- [ ] Set up demo environment (if showing product)
```

---

## How This Workflow Progresses

### Conversational Style
I will guide you through each step with **progressive disclosure**—asking just what's needed for that step, not overwhelming you with all questions upfront.

### Iteration Allowed
At any step, you can say:
- "Regenerate that section with more emphasis on [X]"
- "This doesn't feel right, can we adjust?"
- "Skip Step [X], I already have that"

### Time Estimates Per Step
- Step 1 (Pre-Research): 5-10 minutes
- Step 2 (C-SWOT): 5 minutes
- Step 3 (Value Areas): 5 minutes
- Step 4 (One-Pager): 5 minutes
- Step 5 (Discovery Questions): 5-10 minutes
- Step 6 (Battle Plan): 5 minutes

**Total**: 30-45 minutes for a complete meeting prep package.

---

## Output Formats

All outputs will be provided in **Markdown format**, which you can:
- Copy directly into your notes
- Export to PDF for sharing
- Convert to presentation slides
- Store in your CRM

---

## Getting Started

When you're ready to begin, simply tell me:
- The company name
- The meeting context
- Any background information you have

I'll guide you through the rest step by step.

**Ready? Let's prepare you to dominate that meeting.**
