# Workflow: Prepare Negotiation

**Purpose**: Build a complete negotiation architecture with BATNA, ZOPA, power dynamics, trading variables, and tactical playbook.

**Duration**: 30-45 minutes
**Output**: Negotiation strategy document with objectives, tactics, and scenario responses

---

## When to Use This Workflow

Use negotiation preparation when:
- Your proposal has been accepted in principle and you're entering contract negotiation
- The customer is pushing for discounts or better terms
- You're facing a complex, multi-stakeholder negotiation
- Stakes are high (large deal, strategic customer, competitive situation)
- You want to avoid leaving money on the table or making bad concessions

**Critical Timing**: Complete this workflow BEFORE the negotiation meeting. Never negotiate unprepared.

---

## The Negotiation Preparation Process

### Step 1: Context & Situation Analysis

#### Questions I'll Ask

**Opportunity Background**:
1. "What's the deal? Company name, solution, estimated value?"
2. "What stage are you at?" (proposal submitted, verbal yes, contract negotiation, final terms)
3. "What has been agreed so far?"

**Negotiation Triggers**:
4. "What triggered the negotiation?" (customer asked for discount, procurement involved, competitor pressure)
5. "Who will be at the negotiation table?" (names, roles)
6. "What are their initial requests?" (price reduction, better terms, scope changes)

**Timing & Urgency**:
7. "When is the negotiation happening?"
8. "Are there any deadlines?" (budget cycle, project start date, fiscal year end)

---

### Step 2: BATNA Analysis (Best Alternative To a Negotiated Agreement)

**BATNA** (Fisher & Ury, *Getting to Yes*) is the foundation of negotiation power: understanding your alternatives.

#### Your BATNA (What You Do If This Deal Falls Through)

**Questions I'll Ask**:
1. "If this deal dies, what's your best alternative?"
   - Walk away and focus on other opportunities?
   - Offer reduced scope or pricing?
   - Wait and revisit in 6 months?

2. "What's that alternative worth to you?"
   - Other pipeline opportunities?
   - Cost savings from not doing the deal?

3. "How painful is walking away?"
   - Is this a must-win deal (strategic account, reference, quota)?
   - Or can you afford to lose it?

#### Their BATNA (What They Do If This Deal Falls Through)

**Questions I'll Ask**:
4. "What are their alternatives?"
   - Buy from a competitor? (which one, at what price?)
   - Build in-house? (feasibility, cost, timeline?)
   - Do nothing / status quo? (cost of inaction?)

5. "How attractive are their alternatives?"
   - Competitor solution: Same quality? Better price? Longer timeline?
   - Build in-house: Do they have the capability? What's the risk?
   - Status quo: Can they afford to wait?

6. "How painful is NOT doing this deal for them?"
   - Regulatory deadline forcing action?
   - Competitive pressure?
   - Executive mandate?

#### Power Analysis

```
If YOUR BATNA > THEIR BATNA → You have power (they need you more)
If YOUR BATNA < THEIR BATNA → They have power (you need them more)
If YOUR BATNA ≈ THEIR BATNA → Balanced power (fair negotiation)
```

#### Output Example

```markdown
## BATNA Analysis

### Our BATNA (Best Alternative)
**Option A**: Walk away and close the €200K deal with Company B (probability: 70%)
- **Value**: €200K revenue, 35% margin, familiar industry
- **Timeline**: Can close in 4 weeks

**Option B**: Offer scaled-down solution (Phase 1 only) at lower price
- **Value**: €150K revenue, maintains relationship
- **Risk**: Sets bad precedent on pricing

**Option C**: Wait 6 months and revisit
- **Value**: €0 in short-term, may lose opportunity
- **Risk**: They go with competitor

**BEST ALTERNATIVE**: Option A (Company B deal)
**BATNA Value**: €200K deal (confirmed alternative)

---

### Their BATNA (Best Alternative)
**Option A**: Buy from Competitor X
- **Estimated price**: €500K (vs our €480K ask)
- **Timeline**: 8-month implementation (vs our 6 months)
- **Quality**: Similar features, but no insurance vertical expertise
- **Probability**: 40% (they've met with Competitor X twice)

**Option B**: Build in-house
- **Estimated cost**: €700K (internal dev team + infrastructure)
- **Timeline**: 12-18 months (no proven track record)
- **Risk**: High (they've never built anything like this)
- **Probability**: 10% (CTO skeptical of in-house capability)

**Option C**: Do nothing / status quo
- **Cost of inaction**: €8.5M/year (operational inefficiency)
- **Risk**: Regulatory non-compliance by Q4 2025 (PENALTY: €2M fine)
- **Probability**: 20% (CFO might veto due to budget concerns)

**BEST ALTERNATIVE**: Option A (Competitor X at €500K)
**BATNA Value**: Competitor solution at +€20K cost, +2 months delay

---

### Power Assessment

**Our BATNA**: €200K confirmed alternative (strong)
**Their BATNA**: €500K with Competitor X (weak - costs more, slower)

**Power Balance**: **SLIGHT ADVANTAGE TO US**

**Implication**:
- We can defend our price (€480K)
- They have more to lose than we do
- BUT they still have alternatives (not desperate)
- Strategy: Be firm on price, flexible on terms
```

---

### Step 3: ZOPA Definition (Zone of Possible Agreement)

**ZOPA** (Fisher & Ury, *Getting to Yes*) is the range where a deal is mathematically possible.

```
[Our Walk-Away Price] <---ZOPA---> [Their Maximum Budget]
```

If there's NO overlap, there's NO deal possible (without changing scope).

#### Questions I'll Ask

**Our Position**:
1. "What's your TARGET price?" (ideal outcome)
2. "What's your WALK-AWAY price?" (minimum acceptable)
   - Below this, the deal is unprofitable or not worth it
   - Factors: COGS, opportunity cost, strategic value

**Their Position**:
3. "What's their stated budget?"
4. "Do you believe that's their REAL maximum?" (or negotiating tactic?)
5. "What's the value we deliver to them?" (helps estimate their true max)

#### Output Example

```markdown
## ZOPA (Zone of Possible Agreement)

### Our Position

**TARGET Price**: €480K
- Rationale: Standard pricing for this scope, 40% margin
- This is our "first ask"

**ACCEPTABLE Price**: €420K
- Rationale: Covers costs + 25% margin (minimum acceptable)
- Below this, deal is not worth pursuing

**WALK-AWAY Price**: €400K
- Below this, we walk (unprofitable)

---

### Their Position (Estimated)

**Stated Budget**: €400K
- Their initial position ("We only have €400K budgeted")
- Likely a negotiating anchor (not their true max)

**Estimated TRUE Maximum**: €450K-€470K
- Evidence:
  - Competitor X quoted €500K (they know market rate)
  - Business case shows €6M/year benefit (high ROI even at €480K)
  - CFO has authority to approve up to €500K (per Buying Committee map)
- Our coach (CIO) hinted "there's flex if the value is clear"

---

### ZOPA Visualization

```
€400K        €420K         €450K    €470K  €480K         €500K
  |            |              |        |      |              |
[Their      [Our          [Realistic  |   [Our         [Competitor
 Stated]     Walk-Away]     ZOPA]     |    Target]      Price]
                                      ↑
                              [Likely Deal Price]
```

**ZOPA EXISTS**: YES (€420K-€470K overlap)

**Target Settlement**: €450K-€460K
- Rationale:
  - Above our walk-away (profitable)
  - Below their max (they save €20-40K vs competitor)
  - Perceived "win-win"

**Strategy**:
1. Anchor at €480K (our target)
2. Defend value (don't drop immediately)
3. If pressured, trade concessions (not just discount)
4. Don't go below €420K (walk away if they insist)
```

---

### Step 4: Objectives Definition (3 Levels)

Define what you're trying to achieve at 3 levels: Ideal, Acceptable, Walk-Away.

#### Questions I'll Ask

For each negotiable variable:
1. "What's your IDEAL outcome?" (best case)
2. "What's ACCEPTABLE?" (you can live with)
3. "What's your RED LINE?" (non-negotiable)

Variables typically include: Price, Payment Terms, Scope, Timeline, SLA, Support, Warranties, IP Rights, etc.

#### Output Example

```markdown
## Negotiation Objectives (3-Level)

| Variable | TARGET (Ideal) | ACCEPTABLE | WALK-AWAY (Red Line) |
|---|---|---|---|
| **Price** | €480K | €420K | €400K (below = NO DEAL) |
| **Payment Terms** | 40% upfront, 60% at go-live | 30% upfront, 70% at 90 days | 20% upfront, 80% at 120 days |
| **Scope** | Phase 1 + Phase 2 | Phase 1, Phase 2 optional | Phase 1 only (reduced) |
| **Timeline** | Start Feb 1, go-live Aug 1 | Start Mar 1, go-live Sep 1 | Start Apr 1 (later = NO DEAL due to resource allocation) |
| **SLA** | 99.5% uptime, 8-hour response | 99% uptime, next-day response | 98% uptime, 2-day response |
| **Warranty** | 90-day warranty | 60-day warranty | 30-day warranty |
| **Training** | 5 days included | 3 days included | 2 days included (more = extra cost) |
| **IP Rights** | Custom code = ours, configs = theirs | Custom code shared | All code = ours (non-negotiable) |

---

### Prioritization

**Must-Have** (Non-Negotiable):
- Price ≥ €400K
- IP rights (we own core platform code)

**Important** (Flexible with Trade):
- Payment terms (can extend if they commit to Phase 2)
- Timeline (can delay if they sign sooner)

**Nice-to-Have** (Easy to Trade):
- Training days (low cost to us, high value to them)
- SLA levels (can upgrade for a price)
- Scope additions (can include for commitment)
```

---

### Step 5: Trading Variables & Concession Strategy

**Core Principle**: Never give without getting. Every concession you make should be conditional (**If-Then Trading**: "If you give X, then we can offer Y").

#### Questions I'll Ask

1. "What might they ask for?" (discount, better terms, scope additions, guarantees)
2. "What can you give that has HIGH value to them, LOW cost to you?"
3. "What can you ask for in return?"

#### Output Example

```markdown
## Trading Variables & Concession Architecture

### High-Value (to Them) / Low-Cost (to Us) → GREAT TRADES

| What We Give | Cost to Us | Value to Them | What We Ask in Return |
|---|---|---|---|
| **Extended payment terms** (120 days vs 60 days) | €10K (finance cost) | High (CFO loves cash flow) | **Commit to Phase 2** (€200K revenue) |
| **2 extra training days** | €5K (trainer cost) | High (reduces adoption risk) | **Sign by end of week** (accelerates deal) |
| **Upgraded SLA** (99.5% vs 99%) | €8K/year (monitoring cost) | Medium (operational peace of mind) | **3-year contract** (vs 1-year) |
| **Free POC before commit** (2-week pilot) | €15K (presales time) | High (reduces perceived risk) | **Exclusive negotiation** (no talking to competitors) |

---

### Medium-Value (to Them) / Medium-Cost (to Us) → TRADE CAREFULLY

| What We Give | Cost to Us | Value to Them | What We Ask in Return |
|---|---|---|---|
| **10% price discount** (€48K off) | €48K (direct margin hit) | High (budget relief) | **Commit all 3 phases**, **6-month earlier start**, **Reference customer rights** |
| **Scope addition** (extra feature) | €30K (dev cost) | Medium (nice-to-have feature) | **Price increase €30K OR extended timeline** |

---

### High-Cost (to Us) / High-Value (to Them) → ONLY IF THEY GIVE A LOT

| What We Give | Cost to Us | Value to Them | What We Ask in Return |
|---|---|---|---|
| **20% price discount** (€96K off) | €96K (major margin hit) | Very High | **Multi-year commit (Phases 1-3)**, **PR/case study rights**, **Fast signature (this week)**, **Introduce us to 2 peer companies** |
| **Custom development** (bespoke feature) | €80K (significant dev cost) | Very High (strategic capability) | **Price increase €100K**, **12-month timeline extension** |

---

### Non-Negotiable (DO NOT TRADE)

- **Below €400K price** → Walk away
- **Unlimited liability** → Legal risk unacceptable
- **All IP rights transfer to customer** → Destroys our platform business
- **Unilateral termination without cause** → Too much risk

---

### Pre-Planned Concession Sequence

**If They Push on Price**:

1. **First Response**: Defend value (show ROI, compare to competitor)
   - "At €480K with a 12-month payback and 643% ROI, this is already exceptional value"

2. **If They Persist**: Test reality
   - "Can I ask: Is price the only obstacle, or are there other concerns?"
   - "If we were at €400K, would you sign today?"

3. **If They're Serious**: Conditional trade (If-Then Trading)
   - "I can explore €440K IF you can:
     - Commit to Phase 2 today (adds €200K)
     - Sign this week (helps my Q1 forecast)
     - Provide a case study (marketing value)"

4. **If They Push Further**: Escalate or walk
   - "€440K is my absolute best, and it required me to get VP approval. Below that, we'd be losing money. If that doesn't work, I respect that, but we can't go lower."

5. **Walk-Away if <€400K**:
   - "I appreciate your situation. Unfortunately, at €400K we'd be below cost. If budget becomes available, I'd love to revisit. Otherwise, I wish you the best."
```

---

### Step 6: Power Dynamics & Tactics

#### Questions I'll Ask

1. "Who has more leverage?" (based on BATNA analysis)
2. "What tactics might they use?" (good cop/bad cop, deadline pressure, competitor threat)
3. "What's your negotiating style?" (collaborative vs competitive)

#### Output Example

```markdown
## Power Dynamics & Tactical Plan

### Power Summary (from BATNA analysis)
**Slight advantage to us** (their BATNA is weaker)

**Implication**:
- We can be FIRM on price
- We have FLEXIBILITY on terms
- We can WALK if they're unreasonable

---

### Defensive Tactics (Countering Their Moves)

#### If They Use: "Good Cop / Bad Cop"
**Scenario**: CFO (bad cop) pushes hard on price. CIO (good cop) says "I want to work with you, but I can't convince the CFO."

**Our Response**:
- **Acknowledge**: "I understand you both have different perspectives."
- **Redirect to value**: "Let's make sure the CFO sees the full financial picture. Can we walk through the ROI analysis together?"
- **Don't cave to bad cop**: Stand firm, address concerns directly

---

#### If They Use: "Competitor is Cheaper"
**Scenario**: "Competitor X quoted us €400K, 20% less than you."

**Our Response**:
- **Verify**: "Can I ask: Is that for the same scope and timeline?"
- **Differentiate**: "Our price reflects 6-month delivery vs their 8-month, plus insurance vertical expertise. The 2-month earlier go-live is worth €1.4M in benefits."
- **Challenge their BATNA**: "Have you validated their references? We've done this 8 times in insurance. Have they?"
- **Conditional trade**: "If we match €400K, would you commit to Phases 1+2 today?"

---

#### If They Use: "We Need to Decide by Friday or We Go with Competitor"
**Scenario**: Artificial deadline pressure.

**Our Response**:
- **Call the bluff** (if we have power): "I understand the urgency. But making the wrong decision quickly is worse than making the right decision on Monday. What changes between Friday and Monday?"
- **Test reality**: "Can I ask: If we gave you everything you wanted, could you sign Friday? Or are there other approvals needed?"
- **Conditional urgency**: "I can expedite approval on my side to meet Friday IF you can commit to [X terms]."

---

#### If They Use: "Budget is Hard Capped at €400K"
**Scenario**: "There's literally no more money."

**Our Response**:
- **Test reality**: "Can I ask: Is this a budget availability issue, or a budget approval issue? If the ROI were clearer, could you get more approved?"
- **Offer financing**: "What if we structured this as OPEX over 3 years vs CAPEX upfront? That's €140K/year, which might fit your budget model."
- **Reduce scope**: "At €400K, we can deliver Phase 1 only. Phase 2 would be a separate engagement next year."
- **Walk away if truly capped**: "I respect the budget constraint. If additional funds become available, we'd love to work with you."

---

### Offensive Tactics (Our Moves)

#### Tactic 1: Anchoring
**When to Use**: Early in negotiation
**How**: We state our price FIRST (€480K)
**Why**: Sets the reference point. All negotiation happens relative to our anchor.

#### Tactic 2: Silence
**When to Use**: After stating our price or making a conditional offer
**How**: Stop talking. Let them respond. Count to 10.
**Why**: Silence creates psychological pressure. Whoever speaks first "loses."

#### Tactic 3: Flinch
**When to Use**: When they make a big request (e.g., "We need 20% off")
**How**: Visible reaction (slight surprise, pause, deep breath)
**Why**: Signals their request is unreasonable without saying "no."

#### Tactic 4: Escalation (The "I Need to Ask My Boss" Move)
**When to Use**: When we need time or want to add weight to a concession
**How**: "That discount exceeds my authority. I need to get VP approval."
**Why**:
- Buys time to think
- Makes the concession seem more valuable ("I fought for this internally")
- Adds legitimacy (not just you caving)

#### Tactic 5: Final Offer
**When to Use**: Late stage, when close to agreement
**How**: "Here's my final offer: €440K, Phase 1+2 commit, sign this week. This is the best I can do. Yes or no?"
**Why**: Forces a decision. Creates urgency.
**WARNING**: Only use if you're TRULY ready to walk away.

---

### Negotiation Style Selection

**Style Options**:
1. **Collaborative** ("Let's solve this together")
   - Use when: Long-term relationship, strategic account, high trust
   - Approach: Transparency, joint problem-solving, win-win focus

2. **Competitive** ("This is a business transaction")
   - Use when: One-time deal, low trust, customer is aggressive
   - Approach: Defend position, extract maximum value, protect margins

**Recommendation for This Negotiation**: **Collaborative with Firm Boundaries**
- Rationale: Strategic account (long-term potential), but they're pushing hard on price
- Approach: Be consultative and solution-oriented, but defend price and use If-Then Trading for all concessions
```

---

### Step 7: Team Strategy & Role Definition

**Purpose**: Define negotiation team structure and assign clear roles for maximum effectiveness.

Complex negotiations require a coordinated team approach. Each role has specific responsibilities.

#### The 5 Negotiation Team Roles

**1. LEADER**
- **Primary Responsibility**: Leads the negotiation, makes proposals, drives toward agreement
- **Activities**:
  - Opens the meeting and sets agenda
  - Presents our position and rationale
  - Makes offers and counter-offers
  - Controls pacing and flow
  - Decides when to take breaks
  - Makes final commitments (within authority)
- **Skills Required**: Authority, confidence, decisiveness, strategic thinking
- **Who Should Be Leader**: Senior sales exec, account director, or sales manager

**2. VICE / CONTROLLER**
- **Primary Responsibility**: Controls negotiation flow, asks clarifying questions, manages details
- **Activities**:
  - Asks clarifying questions when things are unclear
  - Tests understanding ("So what I'm hearing is...")
  - Slows down the pace if moving too fast
  - Redirects if conversation goes off-track
  - Takes detailed notes
  - Reminds team of key points
  - Can "interrupt" leader tactically ("Can I ask a clarifying question?")
- **Skills Required**: Analytical thinking, attention to detail, good listener
- **Who Should Be Vice**: Sales engineer, deal strategist, or senior account manager

**3. OBSERVER**
- **Primary Responsibility**: Monitors non-verbal cues, body language, and behavioral signals
- **Activities**:
  - Watches their reactions (facial expressions, body language, tone changes)
  - Identifies emotional shifts (frustration, excitement, hesitation)
  - Detects power dynamics (who defers to whom, who's really deciding)
  - Notes when they're bluffing vs. serious
  - Signals to team when something is "off"
  - Identifies decision-making patterns
  - Observes who's aligned, who's resistant
- **Skills Required**: Emotional intelligence, observation, psychology awareness
- **Who Should Be Observer**: Sales ops, deal coach, or experienced negotiator (often sits back, says little)

**4. MANAGER / AUTHORITY**
- **Primary Responsibility**: Has final authority, sets limits, approves exceptions
- **Activities**:
  - Sets strategic direction before negotiation
  - Approves any concessions beyond leader's authority
  - Available "on call" during negotiation (phone/video)
  - Steps in if negotiation escalates beyond leader's scope
  - Makes go/no-go decision on final terms
  - Provides "escalation" option ("I need to check with my VP")
- **Skills Required**: Strategic judgment, P&L ownership, authority
- **Who Should Be Manager**: VP Sales, Regional Director, or GM (often NOT in room, available on call)

**5. EXPERT (Technical / Legal / Financial)**
- **Primary Responsibility**: Provides subject-matter expertise when specific questions arise
- **Activities**:
  - Answers technical questions (solution capabilities, architecture, integration)
  - Explains financial models (ROI calculations, payment structures)
  - Clarifies legal terms (contracts, SLAs, warranties, IP rights)
  - Provides evidence for claims (case studies, data, references)
  - Validates feasibility of commitments
  - Should speak ONLY when asked (by leader or vice)
- **Skills Required**: Deep domain knowledge, credibility, clarity
- **Who Should Be Expert**: Sales engineer (technical), finance analyst (commercial), legal counsel (contracts)

#### Questions I'll Ask You

1. **Team Composition**:
   - "Who from Our Company will be in the negotiation?"
   - "What are their roles and strengths?"

2. **Role Assignment**:
   - "Who should lead the negotiation?"
   - "Who will take notes and ask clarifying questions?" (Vice)
   - "Who will watch their body language and reactions?" (Observer)
   - "Who has final authority on concessions?" (Manager)
   - "Do you need technical or legal experts present?"

3. **Their Team**:
   - "Who will be on their side of the table?"
   - "Who's their decision maker? Who's their expert? Who's playing what role?"

#### Output Example

```markdown
## Negotiation Team Strategy

### OUR TEAM

**LEADER**: James Wilson (Account Director)
- **Role**: Leads negotiation, presents proposals, makes commitments within €50K authority
- **Strengths**: 15 years experience, strong relationship with CIO, confident presenter
- **Limits**: Cannot approve >€50K discount without VP approval
- **Tactics**: Will use collaborative style, anchor at €480K, use If-Then Trading for all concessions

**VICE**: Sarah Mitchell (Senior Sales Engineer)
- **Role**: Asks clarifying questions, manages timeline discussion, takes notes
- **Strengths**: Technical credibility, detail-oriented, trusted by customer's IT team
- **Tactics**: Will slow pace if moving too fast, test understanding with "So what I'm hearing is..."

**OBSERVER**: David Chen (Deal Strategist)
- **Role**: Watches body language, identifies emotional shifts, signals team via pre-agreed cues
- **Strengths**: 20 years in sales, excellent at reading people, poker face
- **Tactics**: Will sit back, say little, observe CFO reactions to price discussions
- **Private Signals**:
  - Touches pen to paper = "They're bluffing"
  - Leans forward = "They're serious, this is important"
  - Crosses arms = "They're resistant, back off"

**MANAGER** (On Call): Karen Taylor (VP Sales)
- **Role**: Available by phone for concessions >€50K, final authority on walk-away decision
- **Tactics**: Will join via video if we need to escalate ("Let me bring in my VP to discuss this")

**EXPERT** (If Needed): Technical Expert - Mike Reynolds (Solution Architect)
- **Role**: On standby to answer deep technical questions (integration, security, architecture)
- **When to Bring In**: Only if customer raises specific technical objections
- **Tactics**: Will provide crisp, confident answers; will NOT volunteer concerns

---

### THEIR TEAM (Expected)

**LEADER**: CFO (Linda Park)
- **Read**: Will push hard on price, ROI, payment terms
- **Strategy**: She's the "bad cop" - address her financial concerns directly with data

**VICE**: Procurement Manager (Tom Edwards)
- **Read**: Will ask detailed questions on contract terms, SLAs, warranties
- **Strategy**: Provide clear, confident answers; don't negotiate terms on the fly (escalate complex items)

**DECISION MAKER**: CIO (Robert Collins)
- **Read**: Our champion, wants this to happen, but must satisfy CFO
- **Strategy**: Support him by giving CFO-friendly arguments (ROI, risk mitigation, payment flexibility)

**OBSERVER**: VP Operations (Diana Ross)
- **Read**: Cares about implementation risk, timeline, business disruption
- **Strategy**: Emphasize our proven 6-month delivery, change management support, reference customers

**EXPERT** (Likely): IT Director (Mark Spencer)
- **Read**: Technical validator, will challenge on architecture, integration, security
- **Strategy**: Our Sales Engineer (Sarah) should build rapport, technical peer-to-peer

---

### TEAM COORDINATION

**Pre-Meeting Alignment** (30 min before):
- Review BATNA, ZOPA, trading variables
- Assign roles explicitly
- Agree on private signals
- Set "break triggers" (when to pause and regroup)

**Private Signals During Meeting**:
- **"Let's take a 5-minute break"** = We need to regroup privately
- **"Let me check my notes"** (Vice) = Slow down, we're moving too fast
- **"Can I get your thoughts, David?"** (Leader to Observer) = What are you seeing in their reactions?

**Break Triggers** (When to Pause):
- They make unexpected big ask (>20% discount)
- We're not aligned as team on response
- Observer signals they're using tactic we didn't prepare for
- We need to escalate to Manager (VP call)

**Post-Meeting Debrief** (Immediately after):
- What worked? What didn't?
- Did we stay aligned?
- What did Observer notice?
- What's our next move?

---

### ROLE-SPECIFIC TALKING POINTS

**LEADER Script**:
- Opening: "Thanks for making time. Our goal today is to finalize terms so we can start in February. We've prepared a proposal we think is fair. Let's walk through it."
- Presenting price: "Our proposal is €480K for Phases 1+2, with go-live in August. This reflects market rates for this scope and our proven expertise. Let me show you the ROI..."
- Responding to discount request: "I understand budget is important. Can I ask: If we address the price, are there other concerns, or is this the final piece?"

**VICE Script**:
- Clarifying: "Just to make sure I understand: When you say €400K is your max, is that a budget cap, or an approval threshold? What would it take to get more approved?"
- Testing: "So what I'm hearing is: You love the solution, the timeline works, but you need us at €400K to make it happen. Is that accurate?"
- Slowing down: "Before we move forward, can we clarify the scope one more time? I want to make sure we're comparing apples to apples."

**OBSERVER Actions**:
- Says very little
- Watches CFO when we mention price (does she flinch? lean back? stay neutral?)
- Watches CIO when CFO pushes back (is he surprised? supportive of CFO? conflicted?)
- Signals to Leader with pre-agreed cues
- May interject once or twice if critical insight: "Can I add one observation? I noticed [insight]..."

**MANAGER (If Escalated)**:
- Joins via video: "Hi everyone, James asked me to join to discuss the pricing structure. I've reviewed the situation..."
- Provides "I fought for this" narrative: "I spoke with our executive team. €440K is truly our best price. Below that, we can't deliver the quality you need."
- Approves walk-away: "I appreciate your position, but €380K isn't viable for us. If budget changes, we're here."

---

### SUCCESS METRICS FOR TEAM PERFORMANCE

✅ **All roles executed**: Leader led, Vice clarified, Observer watched, Manager available, Expert ready
✅ **No stepping on each other**: Clear who speaks when, no contradictions
✅ **Effective signals used**: Team communicated privately without customer noticing
✅ **Break used strategically**: Paused when needed to regroup
✅ **Aligned on outcome**: Team agreed on final terms before committing
```

---

### Step 8: Scenario Planning & Role-Play

Practice likely scenarios to build confidence.

#### Output Example

```markdown
## Negotiation Scenarios & Responses

### Scenario 1: "We Love the Solution, But We Only Have €400K Budget"

**Our Response Script**:
"I appreciate the transparency on budget. Let me ask: Is €400K a hard cap, or is there flexibility if we can show the CFO the ROI justifies more?

[Wait for answer]

If it's truly capped, I have two options:
1. **Option A**: We deliver Phase 1 only at €400K. Phase 2 becomes a separate project next year.
2. **Option B**: We structure this as €140K/year OPEX over 3 years (€420K total) instead of upfront CAPEX. Does that fit your budget model better?

Which would you prefer?"

---

### Scenario 2: "Competitor X Quoted €400K for the Same Thing"

**Our Response Script**:
"Thanks for sharing that. Can I ask a few clarifying questions?

1. Is their scope identical? (e.g., do they include Phase 2, training, integration?)
2. What's their timeline? (We're at 6 months go-live)
3. Have they done this before in insurance? (We've done this 8 times)

[Let them answer]

Here's what I know: Our price is €480K for 6-month delivery with proven insurance expertise. If they're at €400K for 8 months with less track record, you're comparing apples to oranges.

The real question is: What's 2 months of faster time-to-value worth to you? Based on your business case, every month of delay costs you €700K in lost benefits.

So the €80K price difference is recovered in 1 month. After that, you're ahead.

Would you like me to create a side-by-side comparison to make this clear for your CFO?"

---

### Scenario 3: "We Need a 20% Discount to Make This Work"

**Our Response Script**:
[Flinch slightly]

"20% is... significant. That would bring us to €384K, which is honestly below our cost for this scope.

Can I ask: If we found a way to get close to that, what would you be willing to commit to in return?

[Wait for their response]

Here's what I can do. I'd need VP approval, but IF you can:
- Commit to Phases 1, 2, AND 3 today (€680K total)
- Sign the contract this week
- Agree to be a public reference customer (case study, PR)

I could potentially get approval for 10% off Phase 1 (€432K) plus preferential pricing on Phases 2-3.

Does that work, or is 20% a hard requirement?"

---

### Scenario 4: "We Need Time to Think. We'll Get Back to You in 2 Weeks."

**Our Response Script**:
"Absolutely, I want you to feel confident. Can I ask: What specifically do you need to think about? Is it:
- Budget approval?
- Technical validation?
- Comparison to competitors?
- Internal alignment?

[Let them answer]

The reason I ask is, if it's [specific issue], I might be able to help address that now and save you 2 weeks.

Also, I should mention: My implementation team is allocated for a February start. If we push 2 weeks, the next available slot is April. That delays your go-live to October (vs August), which per your business case costs you €1.4M in delayed benefits.

Would it help if I set up a call with our CFO and your CFO to address financial questions directly? We could do that this week."

---

### Scenario 5: "This is Our Final Offer: €380K, Take It or Leave It"

**Our Response Script**:
[Pause, take a breath]

"I appreciate you being direct. Let me be equally direct: €380K is below our cost for this scope. We can't deliver what you need at that price and maintain quality.

I have two options:

**Option 1**: We reduce scope to fit €380K. That would be Phase 1 basic version only—no advanced features, limited training. It solves the immediate regulatory need but doesn't deliver the full transformation.

**Option 2**: We revisit this when budget is available. I respect your constraints, and I'd rather walk away on good terms than deliver something that underperforms.

Which would you prefer?

[If they insist on €380K with full scope]:

"I'm sorry, but I can't accept that. It would be unfair to both of us—you wouldn't get the quality you deserve, and we'd lose money. If anything changes on budget, I'm here. Otherwise, I wish you the best with your project."

[Prepare to walk away]
```

---

## Final Negotiation Playbook Document

```markdown
# NEGOTIATION PLAYBOOK
## [Company Name] - [Solution Name]

**Deal Value**: €480K (target) / €400K (walk-away)
**Negotiation Date**: [Date]
**Participants**: [Names]
**Prepared By**: [Your Name]
**Date**: [Today]

---

## EXECUTIVE SUMMARY

**Our Position**: Strong (their BATNA is weaker)
**ZOPA**: YES (€420K-€470K overlap)
**Target Outcome**: €450K-€460K, Phase 1+2 commit, February start
**Walk-Away**: <€400K or unreasonable terms

**Key Strategy**: Firm on price, flexible on terms. Use If-Then Trading for all concessions.

---

## 1. BATNA ANALYSIS
[Complete BATNA from Step 2]

## 2. ZOPA DEFINITION
[Complete ZOPA from Step 3]

## 3. OBJECTIVES (3-LEVEL)
[Complete objectives table from Step 4]

## 4. TRADING VARIABLES & CONCESSIONS
[Complete trading variables from Step 5]

## 5. POWER DYNAMICS & TACTICS
[Complete tactics from Step 6]

## 6. SCENARIO RESPONSES
[Complete scenarios from Step 7]

---

## NEGOTIATION CHECKLIST

**Pre-Meeting**:
- [ ] Review this playbook
- [ ] Confirm negotiation team roles (who speaks, who takes notes)
- [ ] Set private signals ("Let's take a break" = regroup)
- [ ] Pre-approve concession limits with manager

**During Meeting**:
- [ ] Anchor first (€480K)
- [ ] Use If-Then Trading for every concession
- [ ] Don't fill silence (let them talk)
- [ ] Take notes on their requests and rationale
- [ ] Escalate to "need approval" if needed (buy time)

**Post-Meeting**:
- [ ] Send summary email confirming agreed terms
- [ ] Update CRM with negotiation notes
- [ ] Debrief with manager on what worked/didn't
- [ ] If no deal, document why (learning for future)

---

**Prepared By**: [Your Name], [Date]
**Reviewed By**: [Sales Manager], [Date]
```

---

## Getting Started

To prepare your negotiation, tell me:
1. The deal details (company, solution, deal size)
2. What's been proposed and where you're at
3. What they're asking for (discount, terms, etc.)
4. Your alternatives (other deals, other options)
5. Their alternatives (competitors, build, do nothing)

I'll build you a comprehensive negotiation playbook to maximize your outcome.

**Ready to negotiate from a position of strength? Let's build your strategy.**
