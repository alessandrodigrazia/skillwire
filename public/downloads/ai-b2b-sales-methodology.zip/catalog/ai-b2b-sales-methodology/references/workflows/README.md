# Workflows Directory

This directory contains operational workflows for the Sales Methodology Pro skill. Each workflow is a self-contained, step-by-step guide for completing a specific sales task.

---

## 🧠 Methodology Intelligence (NEW)

**CRITICAL**: Before using workflows, understand WHEN to use them and in WHAT SEQUENCE.

Three new methodology intelligence files provide the "brain" of the system:

### 1. **workflow-orchestration.md** (in `references/methodology/`)
Answers "WHEN should I use which workflow?" and "In what SEQUENCE?"
- Progressive value building principle: RESEARCH → ANALYSIS → STRATEGY → EXECUTION → CAPTURE
- Intent-based orchestration (10 intent categories)
- Framework combination strategies for common sales cycles
- Proactive guidance templates (e.g., "Before Business Case, you need Value Chain Analysis")

### 2. **framework-dependencies.md** (in `references/methodology/`)
Maps ALL framework prerequisites - what must come BEFORE what
- Dependency hierarchy (5 levels)
- Critical dependencies table (MUST HAVE vs Optional Enhancers)
- Dependency chains for common paths (New Opportunity, RFQ Response, Existing Client Expansion)
- 4 Integration Rules: Analysis Before Strategy, Qualification Before Investment, Foundation Before Superstructure, Sequential Not Parallel
- **Example**: "Value Chain Analysis → Business Case" is a CRITICAL dependency (never skip!)

### 3. **decision-tree.md** (in `references/methodology/`)
Intent classification system for routing user requests to correct workflows
- 10 primary intent categories with trigger phrases and decision logic
- Multi-intent handling (e.g., "meeting prep AND business case" → correct sequencing)
- Common user mistakes with corrections

**When to consult these files**:
- User asks for multiple workflows → Load workflow-orchestration.md
- User might be skipping a prerequisite → Load framework-dependencies.md
- User request is ambiguous → Load decision-tree.md

---

## Available Workflows

### 🎯 Core Strategic Workflows

#### 1. **prepare-meeting.md**
**Prepare for Strategic Meetings**
- Duration: 30-45 minutes
- Output: Complete battle plan with research, C-SWOT, value areas, questions, and one-pager
- Use when: Preparing for discovery meetings, executive presentations, or critical client interactions

#### 2. **qualify-opportunity.md**
**MEDDPICC+RR Opportunity Qualification**
- Duration: 20-30 minutes
- Output: 10-criteria MEDDPICC+RR analysis with GO/NO-GO recommendation
- Use when: Deciding whether to invest resources in an opportunity

#### 3. **map-decision-center.md**
**Buying Committee Stakeholder Mapping**
- Duration: 20-30 minutes
- Output: Complete Buying Committee map with engagement strategies for each stakeholder
- Use when: Navigating complex, multi-stakeholder deals

#### 4. **value-chain-analysis.md** ⭐ NEW
**Value Chain Analysis (Feature → Benefit → Value)**
- Duration: 30-40 minutes
- Output: Feature-to-value mapping with quantified tangible/intangible benefits + cost structure
- Use when: Quantifying solution value (CRITICAL: This is a PREREQUISITE for business-case-advanced)
- Note: 5-step workflow transforms technical capabilities into business outcomes

#### 5. **build-business-case.md**
**Business Case Development (Basic)**
- Duration: 45-60 minutes
- Output: Executive-ready business case with ROI, TCO, and value quantification
- Use when: Quick ROI justification to C-level or CFO

#### 6. **business-case-advanced.md** ⭐ NEW
**Business Case Development (Advanced/Executive-Grade)**
- Duration: 60-90 minutes
- Output: 6-section business case generated section-by-section (Exec Summary, Current Situation, Proposed Solution, Expected Benefits, Required Investment, Implementation Methodology)
- Use when: Comprehensive ROI justification for major investments, executive presentations
- CRITICAL PREREQUISITE: Value Chain Analysis must be completed first (see framework-dependencies.md)

#### 7. **presentation-builder.md** ⭐ NEW
**Client-Specific Presentation Builder**
- Duration: 40-60 minutes
- Output: Complete presentation with speaker notes (2-3x more content in notes than slides)
- Use when: Executive presentations, demos, decision committee pitches
- 4 Standard Structures: Problem-Solution-Value, Strategic Partnership, Technical Solution, Business Case

#### 8. **prepare-negotiation.md** ⭐ ENHANCED
**Negotiation Strategy & Architecture (6-Step Framework)**
- Duration: 30-45 minutes
- Output: Complete negotiation playbook with BATNA, ZOPA, trading variables, tactics, PLUS team strategy (5 negotiation roles: Leader, Vice, Observer, Manager, Expert)
- Use when: Entering contract negotiation phase

### 📊 Analytical Workflows

#### 9. **create-cswot.md**
**Customer SWOT Analysis**
- Duration: 15-20 minutes
- Output: 4-quadrant C-SWOT analysis identifying strategic leverage points
- Use when: Analyzing a customer's strategic position to find value angles

#### 10. **analyze-rfq.md** ⭐ ENHANCED
**RFQ/Tender Analysis (Comprehensive 7-Deliverable Process)**
- Duration: 90-120 minutes
- Output: 7 deliverables across 3 phases:
  - Phase 1: Administrative Analysis, Technical Analysis, Economic Analysis
  - Phase 2: Holistic Analysis with GO/NO-GO recommendation and win themes
  - Phase 3: Clarification Email, Compliance Checklist, Technical-Economic Response Draft
- Use when: Responding to complex RFPs, RFQs, or tender documents
- Note: Not just preliminary analysis - full bid preparation with compliance mapping

### 📝 Content Generation Workflows

#### 11. **generate-nurturing-sequence.md**
**Email Nurturing Sequence**
- Duration: 20-30 minutes
- Output: Multi-email nurturing sequence for prospect warming
- Use when: Converting cold prospects or maintaining engagement over time

#### 12. **generate-post-meeting-summary.md** ⭐ ENHANCED
**Post-Meeting Documentation (Advanced Multi-Format)**
- Duration: 10-20 minutes
- Output: 4 format options (Client-Facing Memo, Internal CRM Report, Email Draft, Teams Message) with transcript processing, sentiment analysis, Buying Committee/MEDDPICC+RR updates
- Use when: Documenting meeting outcomes and next steps
- Advanced Features: Supports manual input, transcript upload, or structured notes; automatic framework integration

---

## Workflow Design Principles

All workflows follow these principles:

### 1. Progressive Disclosure
- Information is requested **step-by-step**, not all at once
- Each question explains **why** it's being asked
- Optional vs required inputs are clearly marked

### 2. Evidence-Based
- All recommendations are grounded in the data you provide
- No generic advice—everything is contextualized to your specific situation

### 3. Actionable Outputs
- Every workflow produces a **concrete deliverable** you can use immediately
- Outputs are in professional, sharable formats (Markdown, ready for PDF export)

### 4. Teaching-Oriented
- Workflows don't just DO the work—they TEACH you the methodology
- Rationale sections explain the "why" behind recommendations
- Strategic notes highlight key insights

### 5. Iterative
- At any step, you can request regeneration with different emphasis
- You can skip steps if you already have that information
- You can revisit and update outputs as situations evolve

---

## How to Choose a Workflow

### By Sales Stage

**Early Stage (Prospecting)**:
- generate-nurturing-sequence
- prepare-meeting (first discovery)

**Mid Stage (Qualification & Discovery)**:
- qualify-opportunity (MEDDPICC+RR)
- map-decision-center (Buying Committee)
- create-cswot
- analyze-value-chain

**Late Stage (Proposal & Negotiation)**:
- build-business-case
- create-presentation
- prepare-negotiation

**Post-Sale**:
- generate-post-meeting-summary

**Special Situations**:
- analyze-rfq (when responding to tenders)

### By Objective

**"I need to decide if this deal is worth pursuing"**
→ qualify-opportunity

**"I need to prepare for an important meeting"**
→ prepare-meeting

**"I need to understand the stakeholder landscape"**
→ map-decision-center

**"I need to justify the investment to a CFO"**
→ build-business-case

**"I need to build a compelling value story"**
→ value-chain-analysis → build-business-case

**"I'm about to enter negotiation"**
→ prepare-negotiation

**"I need to respond to an RFP"**
→ analyze-rfq

**"I want to stay top-of-mind with prospects"**
→ generate-nurturing-sequence

---

## Workflow Combinations (Power Moves)

**IMPORTANT**: For detailed guidance on workflow sequences and dependencies, consult:
- `references/methodology/workflow-orchestration.md` - WHEN to use workflows and in WHAT SEQUENCE
- `references/methodology/framework-dependencies.md` - Prerequisites and critical dependencies

Some workflows are designed to feed into others:

### Power Move 1: New Opportunity → Major Proposal (Full Cycle)
```
qualify-opportunity (MEDDPICC+RR)
    ↓ (GO/NO-GO decision)
map-decision-center (Buying Committee)
    ↓ (understand stakeholders)
prepare-meeting
    ↓ (first strategic meeting)
generate-post-meeting-summary
    ↓ (document outcomes, update Buying Committee/MEDDPICC+RR)
create-cswot
    ↓ (competitive analysis)
value-chain-analysis ⚠️ CRITICAL STEP
    ↓ (quantify solution value - DON'T SKIP!)
business-case-advanced
    ↓ (comprehensive ROI justification)
presentation-builder
    ↓ (executive presentation)
prepare-negotiation
    ↓ (6-step framework, team strategy)
```
**Result**: Complete strategic approach from qualification to contract closure.

**Key Dependency**: Value Chain Analysis is MANDATORY before Business Case - see `framework-dependencies.md`

### Power Move 2: RFQ/Tender Response (Comprehensive)
```
analyze-rfq
    ↓ Phase 1: Admin + Technical + Economic analyses
    ↓ Phase 2: Holistic Analysis with GO/NO-GO
    ↓ Phase 3: Clarification + Compliance + Response Draft
    ↓ (if GO)
value-chain-analysis
    ↓ (quantify benefits for proposal)
business-case-advanced
    ↓ (build financial section)
presentation-builder
    ↓ (prepare oral defense, if required)
prepare-negotiation
    ↓ (prepare for post-award negotiations)
```
**Result**: A winning, compliant response to a complex tender with full deliverables.

**Critical Path**: All 3 RFQ analyses must complete before Holistic Analysis

### Power Move 3: Existing Client → Expansion (Relationship Leverage)
```
Pre-research
    ↓ (update client context - what's changed?)
create-cswot
    ↓ (new challenges/opportunities)
value-chain-analysis
    ↓ (what value delivered? What's next?)
business-case-advanced
    ↓ (ROI for expansion)
presentation-builder
    ↓ (Quarterly Business Review format)
prepare-negotiation
    ↓ (expansion terms)
```
**Result**: Systematic expansion approach leveraging existing relationship

### Power Move 4: Late-Stage Deal Acceleration (Fast-Track)
```
map-decision-center (Buying Committee)
    ↓ (final stakeholder validation)
value-chain-analysis
    ↓ (refresh/strengthen value story if not done)
business-case-advanced
    ↓ (financial validation for skeptical CFO)
presentation-builder
    ↓ (decision committee presentation)
prepare-negotiation
    ↓ (BATNA, ZOPA, team roles)
```
**Result**: Accelerated path for late-stage deals

**Fast-Track Option**: Use `build-business-case` (basic) instead of `business-case-advanced` if time-constrained

---

## Workflow Status Indicators

Each workflow includes difficulty and time estimates:

| Workflow | Difficulty | Duration | Prerequisites |
|---|---|---|---|
| prepare-meeting | ⭐⭐ Medium | 30-45 min | Basic opportunity info |
| qualify-opportunity | ⭐⭐ Medium | 20-30 min | Initial discovery completed |
| map-decision-center | ⭐⭐⭐ Advanced | 20-30 min | Multiple stakeholder interactions |
| value-chain-analysis | ⭐⭐ Medium | 30-40 min | Solution description, client context |
| build-business-case | ⭐⭐⭐ Advanced | 45-60 min | Value chain or CSWOT preferred |
| business-case-advanced | ⭐⭐⭐⭐ Expert | 60-90 min | **MANDATORY**: Value Chain Analysis + C-SWOT + cost info |
| presentation-builder | ⭐⭐ Medium | 40-60 min | At least ONE of: C-SWOT, Value Areas, Business Case |
| prepare-negotiation | ⭐⭐⭐ Advanced | 30-45 min | Proposal submitted, client interest confirmed |
| create-cswot | ⭐ Easy | 15-20 min | Basic customer research |
| analyze-rfq | ⭐⭐⭐ Advanced | 90-120 min | RFQ documents (admin/technical/economic sections) |
| generate-nurturing-sequence | ⭐ Easy | 20-30 min | Target audience definition |
| generate-post-meeting-summary | ⭐ Easy | 10-20 min | Meeting notes, recording, or transcript |

---

## Getting Started

To use any workflow:

1. **Open the workflow file** you need (e.g., `prepare-meeting.md`)
2. **Read the "When to Use" section** to confirm it's the right tool
3. **Gather prerequisite information** (if any)
4. **Invoke the skill** and reference the workflow name
5. **Follow the guided conversation**—I'll ask questions step-by-step
6. **Receive your output** and iterate if needed

### Example Invocation

Instead of reading the workflow files yourself, simply tell me:

> "I need to prepare for a strategic meeting with Acme Corp next week. Can you guide me through the meeting preparation workflow?"

I'll handle the rest, walking you through each step conversationally.

---

## Customization and Feedback

These workflows are living documents. If you need:
- **A variation**: "Can we do the MEDDPICC+RR analysis but skip criterion X because I already know the answer?"
- **More depth**: "Can you provide more examples for the C-SWOT analysis?"
- **Less detail**: "Can you give me a quick version of the business case workflow?"

Just ask. The workflows are guidelines, not rigid scripts.

---

## Support

If you're unsure which workflow to use, just describe your situation:

> "I have a meeting with a CFO next week and I need to justify a €500K investment. What workflow should I use?"

I'll recommend the appropriate workflow(s) and guide you through them.

---

## Workflow Updates

**Version**: 2.0.0 (Current)
**Last Updated**: 2025-02-11

### What's New in v2.0

**NEW WORKFLOWS**:
- ✅ `value-chain-analysis.md` - Feature-to-value mapping with quantified benefits (CRITICAL prerequisite for business-case-advanced)
- ✅ `business-case-advanced.md` - Section-by-section executive-grade business case (6 sections, comprehensive)
- ✅ `presentation-builder.md` - Client-specific presentations with speaker notes (4 standard structures)

**ENHANCED WORKFLOWS**:
- ✅ `prepare-negotiation.md` - Added 6-step framework with team strategy (5 negotiation roles: Leader, Vice, Observer, Manager, Expert)
- ✅ `analyze-rfq.md` - Comprehensive 7-deliverable process (Admin/Technical/Economic → Holistic → Clarification → Checklist → Response Draft)
- `generate-post-meeting-summary.md` - Multi-format output (4 options), transcript processing, sentiment analysis, automatic framework integration

**METHODOLOGY INTELLIGENCE** (in `references/methodology/`):
- ✅ `workflow-orchestration.md` - WHEN to use workflows and in WHAT SEQUENCE
- ✅ `framework-dependencies.md` - Prerequisites and critical dependencies map
- ✅ `decision-tree.md` - Intent classification and workflow routing logic

### Previous Versions

**Version 1.0.0** (2024-01-20):
- Initial release with 11 core workflows

### Future Workflows Planned
- Competitive battlecard generation
- Lost deal post-mortem analysis
- Account expansion planning
- Reference customer cultivation
- Multi-threaded sales campaign orchestration

---

**Ready to get started? Just tell me what you're working on, and I'll guide you through the right workflow.**
