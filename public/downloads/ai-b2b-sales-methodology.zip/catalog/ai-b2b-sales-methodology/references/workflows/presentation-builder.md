# Workflow: Presentation Builder

**Purpose**: Create compelling, client-specific sales presentations with structured content and speaker notes to deliver persuasive pitches to decision makers.

**Duration**: 25-40 minutes
**Output**: Complete presentation outline with slide content and detailed speaker notes

---

## When to Use This Workflow

Use this workflow when you need to:
- Prepare formal presentations for C-level executives or decision committees
- Create pitch decks for new business opportunities
- Build solution presentations for technical and business audiences
- Develop presentation materials for RFP/tender responses
- Prepare quarterly business reviews or strategic account presentations

**Prerequisites**:
- You have completed analysis (C-SWOT, Value Areas, or Business Case recommended)
- You understand the audience and their priorities
- You have a clear objective for what the presentation should achieve

---

## Overview: The 4-Step Presentation Building Process

```
1. CONTEXT GATHERING → Upload analyses, define audience & objective
2. OUTLINE DEFINITION → Structure the story and key messages
3. CONTENT GENERATION → Create slides with speaker notes
4. REVIEW & REFINEMENT → Edit, adjust, and finalize
```

This workflow focuses on creating **content and structure**, which you can then format in PowerPoint, Google Slides, or your preferred presentation tool.

---

## Step 1: Gather Context and Define Objective

### What This Step Does
Collects all relevant analyses and defines what you want the presentation to achieve.

### Information Needed

**Analysis Documents** (at least one recommended):
- C-SWOT analysis
- Value Areas mapping
- Business Case document
- MEDDPICC+RR qualification report
- Meeting preparation materials
- Previous presentations or proposals

**Audience Information** (Required):
- Who will attend? (titles, roles, departments)
- What is their level? (C-level, director, manager, technical)
- What do they care about most? (business outcomes, technical details, risk, cost)
- How much do they know already? (first meeting vs. advanced stage)

**Presentation Objective** (Required):
- What decision or action do you want from this presentation?
- What is the primary message you want to convey?
- How much time do you have? (15 min, 30 min, 60 min)

### Questions I'll Ask You

1. **Context Upload**:
   - "Do you have C-SWOT, Value Areas, or Business Case documents I can use as foundation?"
   - "Please share any previous materials or background on this opportunity"

2. **Audience**:
   - "Who exactly will be in the room? What are their roles?"
   - "What matters most to each person?"
   - "Is this a technical audience, business audience, or mixed?"

3. **Objective**:
   - "What do you want to happen as a result of this presentation?"
   - "What is the ONE key message they must remember?"
   - "How much time do you have to present?"

---

## Step 2: Define Presentation Outline

### What This Step Does
Creates a structured flow that tells a compelling story aligned with your objective.

### Standard Presentation Structures

I'll recommend one of these proven structures based on your objective:

#### **Structure A: Problem-Solution-Value (Best for new opportunities)**
```
1. Title Slide
2. Agenda / Meeting Objectives
3. Understanding Your Situation (Problem framing)
4. Strategic Challenges You Face (C-SWOT insights)
5. Our Approach to Solving This
6. Solution Overview
7. Key Benefits & Value Areas
8. Why Our Company / Differentiation
9. Implementation Approach
10. Investment & ROI
11. Next Steps / Call to Action
```

#### **Structure B: Strategic Partnership (Best for C-level)**
```
1. Title Slide
2. Executive Summary (The ask)
3. Your Strategic Context (Their world)
4. Our Strategic Recommendation
5. Business Case Overview
6. Expected Outcomes (Quantified)
7. How We're Different
8. Our Partnership Approach
9. Proposed Roadmap
10. Next Steps
```

#### **Structure C: Technical Solution (Best for IT/technical audiences)**
```
1. Title Slide
2. Agenda
3. Current State & Challenges
4. Technical Requirements
5. Solution Architecture
6. Key Capabilities
7. Integration Approach
8. Security & Compliance
9. Implementation Plan
10. Support & Evolution
11. Next Steps
```

#### **Structure D: Business Case Presentation (Best for investment decisions)**
```
1. Title Slide
2. Executive Summary
3. Current Situation & Problem
4. Financial Impact of Inaction
5. Proposed Solution
6. Quantified Benefits
7. Investment Required
8. ROI & Payback Analysis
9. Risk Mitigation
10. Implementation Timeline
11. Decision & Next Steps
```

### What You'll Receive

A **recommended presentation outline** with:
- Proposed slide titles in logical sequence
- Brief description of what each slide should cover
- Estimated time allocation per section
- Notes on which source materials feed each slide

### Example Output

```markdown
## Recommended Outline: Strategic Partnership Presentation for [Client Name]

**Total Duration**: 30 minutes (20 min presentation + 10 min Q&A)
**Audience**: CIO, CFO, VP Operations
**Objective**: Secure approval to proceed with POC and detailed business case phase

---

### SLIDE 1: Title Slide (0:30)
**Content**: Project name, Our Company logo, date, audience names
**Speaker Notes**: Warm welcome, thank them for their time

### SLIDE 2: Executive Summary - The Opportunity (2:00)
**Content**:
- The challenge: [Client]'s legacy systems limiting growth
- Our recommendation: Phased modernization approach
- Expected outcome: 30% cost reduction, 50% faster time-to-market
- What we're asking today: Approval for 4-week POC

**Speaker Notes**:
Start with the end in mind. Be crisp about what you're asking for.
Reference previous conversations with CIO about legacy constraints.

**Source**: Business Case executive summary

### SLIDE 3: Your Strategic Context (3:00)
**Content**:
- Industry trends forcing modernization
- Your specific challenges (from C-SWOT)
- Cost of inaction: competitive disadvantage

**Speaker Notes**:
Use their language. Reference their strategic plan.
CFO cares about cost; CIO cares about agility; VP Ops cares about reliability.

**Source**: C-SWOT analysis - Weaknesses & Threats

[Continue for all slides...]
```

You'll review this outline and can request changes before we generate content.

---

## Step 3: Generate Slide Content and Speaker Notes

### What This Step Does
Creates detailed content for each slide with comprehensive speaker notes.

### What You'll Receive

For each slide in your approved outline:

1. **Slide Title**: Clear, action-oriented headline
2. **Slide Content**: Bullet points, data points, key messages
3. **Visual Suggestions**: What charts, diagrams, or images would strengthen the slide
4. **Speaker Notes**: Detailed talking points (2-3x the content on the slide)
5. **Timing Guidance**: How long to spend on this slide

### Content Principles

**On Slides** (What the audience sees):
- Maximum 5-7 bullet points per slide
- Short phrases, not full sentences
- Key data points and numbers highlighted
- Consistent terminology
- Client's language, not vendor jargon

**In Speaker Notes** (What you say):
- Full context and explanation
- Stories, examples, case studies
- Transitions to next slide
- Anticipated questions and responses
- Emphasis on key points

### Example Output: Single Slide

```markdown
---

## SLIDE 5: Solution Overview - Phased Modernization Approach

### Slide Content:

**Our Recommended Approach: Phased, Risk-Managed Modernization**

**Phase 1 (Months 1-3): Foundation**
• Cloud infrastructure setup & security hardening
• Data migration strategy & pilot
• Team training & change management kickoff

**Phase 2 (Months 4-6): Core Systems**
• Policy administration platform deployment
• Integration with existing claims system
• User acceptance testing

**Phase 3 (Months 7-9): Optimization & Scale**
• Advanced analytics & reporting
• Full user rollout
• Performance optimization

✓ **Key Benefits**: Continuous value delivery, managed risk, flexibility to adjust

---

### Visual Suggestions:

**Recommended Visual**: Timeline diagram showing three phases with key milestones
- Use horizontal timeline with phase boxes
- Color-code by phase (Foundation=Blue, Core=Green, Optimization=Gold)
- Include checkmark icons for completed POC deliverables
- Add "YOU ARE HERE" marker if presenting mid-project

**Alternative Visual**: Gantt chart showing parallel workstreams

---

### Speaker Notes:

**Opening** (0:15):
"Let me walk you through how we'd approach this modernization. We've learned from 200+ implementations that trying to do everything at once creates unacceptable risk. Instead, we propose a phased approach."

**Phase 1 Detail** (0:45):
"In the first three months, we focus on the foundation. This means setting up your cloud infrastructure with the security and compliance controls that [CFO Name] emphasized in our last meeting. We also run a pilot data migration - purposely starting small to validate our approach before moving your entire policy database. And critically, we start change management early because [VP Operations Name], as you said, user adoption will make or break this project."

"At the end of Phase 1, you'll have a secure, compliant cloud environment and proven data migration process. That's tangible value even if we never proceeded to Phase 2 - though of course, that's where the big wins come."

**Phase 2 Detail** (0:45):
"Months 4-6 are about deploying the core policy administration platform. Notice we're integrating with your existing claims system, not replacing it yet. [CIO Name], this addresses your concern about managing too much change simultaneously. The claims system modernization can be Phase 4 next year if this goes well."

"By end of Phase 2, your policy team is working on the new platform for new business, while renewals continue on legacy. Parallel operation = zero risk."

**Phase 3 Detail** (0:30):
"The final three months are about optimization and scale. This is where we roll out to all users, tune performance, and deploy those advanced analytics that will give you the competitive intelligence [CEO Name] talked about in the board strategy."

**Closing** (0:15):
"The beauty of this phased approach: you see value every quarter, you can course-correct if needed, and we share the risk. If Phase 1 doesn't deliver, you haven't committed to Phase 2."

**Transition to Next Slide**:
"Now let me show you the specific benefits you'll realize in each phase..."

**Anticipated Questions**:
- Q: "Why 9 months? Can we go faster?"
  A: "We can compress to 7 months, but I'd caution against faster. The risk multiplies, and frankly, your team needs time to absorb the change. We've seen rushed implementations create technical debt that costs more to fix later."

- Q: "What if we want to pause between phases?"
  A: "Absolutely an option. Each phase delivers standalone value. Some clients take a 1-2 month pause between phases to consolidate learnings."

---

### Timing: 3:00

---
```

### Generation Process

I'll generate slides sequentially, allowing you to:
- Review each slide before moving to the next
- Request changes to content or speaker notes
- Add or remove bullet points
- Adjust the level of technical detail
- Insert additional slides if needed

---

## Step 4: Review, Refine, and Export

### What This Step Does
Gives you opportunity to edit, reorder, or regenerate any slides before final delivery.

### Review Checklist

Before finalizing, verify:

**Content Quality**:
- [ ] Every slide has clear, client-specific content (not generic)
- [ ] Data points and numbers are accurate
- [ ] Terminology matches client's language
- [ ] No vendor jargon or acronyms without explanation
- [ ] Claims are backed by evidence or source materials

**Story Flow**:
- [ ] Logical progression from slide to slide
- [ ] Smooth transitions in speaker notes
- [ ] Build to clear call-to-action at end
- [ ] Timing adds up to your target duration

**Audience Alignment**:
- [ ] Technical depth appropriate for audience
- [ ] Addresses each stakeholder's priorities
- [ ] Anticipated objections covered
- [ ] Supporting data for skeptics included

**Speaker Notes**:
- [ ] Detailed enough to present confidently
- [ ] Include stories and examples
- [ ] Cover anticipated questions
- [ ] Provide transitions between slides

### Refinement Options

At this stage, you can request:

1. **Regenerate specific slide**: "Make slide 7 more technical"
2. **Add new slide**: "Insert a slide about security between 5 and 6"
3. **Reorder slides**: "Move the ROI slide earlier"
4. **Adjust depth**: "Add more detail to implementation approach"
5. **Change tone**: "Make the executive summary more assertive"

### Export Formats

I'll provide your final presentation as:

**Primary Format**: **Markdown document** with clear slide breaks
- Easy to copy into PowerPoint, Google Slides, Keynote
- Slide content clearly separated from speaker notes
- Visual suggestions included

**Optional Formats** (you create):
- PowerPoint (.pptx) - Format slides with your brand template
- PDF - For distribution to attendees
- Speaker script - Just the speaker notes as presentation script

### Example: Final Deliverable Structure

```markdown
# FINAL PRESENTATION: [Client Name] Strategic Modernization
**Presenter**: [Your Name]
**Date**: [Presentation Date]
**Duration**: 30 minutes + Q&A
**Audience**: CIO, CFO, VP Operations

---

## SLIDE 1: [Title Slide]
[Content...]
[Speaker Notes...]

## SLIDE 2: [Executive Summary]
[Content...]
[Speaker Notes...]

[Continue for all slides...]

---

## APPENDIX: Backup Slides

[Additional technical details, extended ROI calculations, case studies, etc. - slides you have ready but only show if specific questions arise]

---

## PRE-PRESENTATION CHECKLIST

- [ ] Review client's recent news/announcements
- [ ] Confirm attendee list hasn't changed
- [ ] Test presentation equipment/remote setup
- [ ] Print handout version (if distributing materials)
- [ ] Prepare answers to likely tough questions
- [ ] Review speaker notes one final time

---

## POST-PRESENTATION ACTION ITEMS

- [ ] Send thank you email within 24 hours
- [ ] Distribute presentation (if appropriate)
- [ ] Follow up on commitments made during Q&A
- [ ] Update CRM with feedback and next steps
- [ ] Debrief with your team on what worked/didn't
```

---

## Integration with Other Workflows

This workflow integrates with:

- **Prepare Meeting** → Use battle plan and value areas as presentation foundation
- **Build Business Case** → Convert business case into presentation format
- **Value Chain Analysis** → Use value chain for benefits/differentiation slides
- **C-SWOT Analysis** → Use for "client situation" and "challenges" slides
- **MEDDPICC+RR Qualification** → Helps ensure you're presenting to right audience with right message

---

## Presentation Types & Variations

### First Discovery Meeting Presentation (15-20 min)
**Focus**: Understanding, not selling
- Agenda: 10% (what we'll cover)
- Your preliminary research: 20% (showing you did homework)
- Discovery questions: 40% (the real purpose)
- Our Company intro: 20% (credibility)
- Next steps: 10%

### Solution Presentation (30-45 min)
**Focus**: Demonstrating fit and value
- Executive summary: 10%
- Client situation: 15%
- Solution overview: 30%
- Value & differentiation: 25%
- Next steps: 10%
- Q&A: 10%

### Business Case Presentation (45-60 min)
**Focus**: Securing investment approval
- Exec summary & ask: 10%
- Problem & cost of inaction: 20%
- Solution & approach: 20%
- Financial analysis: 25%
- Risk mitigation: 10%
- Implementation plan: 10%
- Decision: 5%

### Quarterly Business Review (30-45 min)
**Focus**: Demonstrating value delivered, expanding relationship
- Previous quarter recap: 15%
- Value realized vs. committed: 25%
- Challenges addressed: 15%
- Optimization opportunities: 20%
- Roadmap for next quarter: 15%
- Strategic discussion: 10%

---

## Best Practices

### Do's ✅

- **Start with the ask**: Executive summary should state what you want
- **Use their language**: Quote their strategy documents, use their terminology
- **Tell stories**: Case studies and examples > bullet points
- **Quantify everything possible**: Numbers are memorable
- **Practice speaker notes**: Don't read slides, tell the story
- **Prepare for objections**: Have answers ready in speaker notes or backup slides
- **End with clear next steps**: Never "I'll follow up" - be specific

### Don'ts ❌

- **Don't lead with company intro**: They don't care about you yet, only their problems
- **Don't use >7 bullets per slide**: Slide is reminder, not documentation
- **Don't read slides verbatim**: Speaker notes should add 2-3x more content
- **Don't skip the "why"**: Always explain why each point matters to them
- **Don't ignore the audience mix**: CFO and CTO need different emphasis
- **Don't forget timing**: Practice with a timer, respect their schedule
- **Don't end weakly**: "Any questions?" is not a strong close

---

## Common Mistakes and How to Avoid Them

### Mistake #1: "All About Us" Opening
**Wrong**: Starting with "Our Company was founded in... we have X employees... our partners include..."
**Right**: Start with their challenge, their opportunity, their world

### Mistake #2: Feature Dumping
**Wrong**: "Our platform has 47 modules including..."
**Right**: "Your policy team will cut processing time by 40% because..."

### Mistake #3: Assuming Knowledge
**Wrong**: Using acronyms, assuming they know your tech stack
**Right**: Define terms, explain context, check for understanding

### Mistake #4: Ignoring the Decision Process
**Wrong**: Presenting only to your champion, ignoring CFO's ROI concerns
**Right**: Address each stakeholder's decision criteria explicitly

### Mistake #5: Weak Close
**Wrong**: "So... any questions? We'll follow up..."
**Right**: "Our recommendation: Approve the POC starting [date]. We'll deliver [specific outcome] by [date]. Can we move forward?"

---

## Visual Design Guidelines

While this workflow focuses on content, keep these design principles in mind when formatting:

### Slide Design Principles
- **One idea per slide**: Don't combine unrelated concepts
- **Visuals > text**: Use diagrams, charts, icons where possible
- **Consistent layout**: Same fonts, colors, spacing throughout
- **High contrast**: Ensure readability in any room lighting
- **Minimal animation**: Only to reveal points progressively, not for flash

### Recommended Visuals by Slide Type

**Timeline slides**: Horizontal timeline with milestones
**Process slides**: Flowchart or numbered steps
**Benefits slides**: Icons + short descriptions
**Data slides**: Bar/line charts, not tables
**Comparison slides**: Side-by-side columns
**Architecture slides**: Diagram with labeled components
**Team slides**: Photos + names + roles (if appropriate)

---

## Advanced: Backup Slides Strategy

Always prepare 5-10 **backup slides** you don't plan to show but have ready:

**Technical Deep-Dives**:
- Detailed architecture diagram
- Security & compliance details
- Integration specifications
- Data model overview

**Financial Details**:
- Detailed cost breakdown
- Extended ROI calculations
- TCO comparison
- Payment terms options

**Case Studies**:
- Similar client success stories
- Industry-specific examples
- Testimonials and references

**Competitive Analysis**:
- Feature comparison matrix
- TCO comparison
- Risk comparison

**Use backup slides when**:
- Specific technical question arises
- CFO asks for cost detail
- They want proof/evidence for a claim
- Conversation goes deeper than planned

---

## Success Metrics

You'll know this workflow succeeded when:
- ✅ Presentation tells clear, compelling story from client's perspective
- ✅ Every slide has purpose and builds to your call-to-action
- ✅ Speaker notes give you confidence to present without reading slides
- ✅ Content addresses each stakeholder's priorities
- ✅ You have backup slides ready for anticipated questions
- ✅ Timing is realistic and practiced
- ✅ Presentation achieves its stated objective (decision, approval, next meeting)

---

## Templates and Reference Materials

### Recommended Templates
- `assets/templates/first-meeting-structure-template.md` - First meeting structure
- `assets/templates/business-case-template.md` - Business case content
- `assets/templates/one-pager-template.md` - Executive summary format

### Related Workflows
- `prepare-meeting.md` - Use Step 4 (one-pager) as presentation foundation
- `build-business-case.md` - Convert business case to presentation
- `value-chain-analysis.md` - Source for benefits/value slides

---

## Prompting Strategy

When working with me on this workflow:

**Stage 1 - Context**:
"Let's build your presentation. First, who is the audience and what do you want to achieve?"
[Upload documents, define objective]

**Stage 2 - Outline**:
"Based on your objective and audience, I recommend this structure..."
[Present outline with rationale, get approval]

**Stage 3 - Generate**:
"I'll now create slides with detailed speaker notes. I'll go slide-by-slide so you can review."
[Generate each slide with content + notes]

**Stage 4 - Refine**:
"What would you like to adjust? I can regenerate slides, add detail, or change the emphasis."
[Iterate based on feedback]

**Stage 5 - Finalize**:
"Here's your complete presentation with all slides, speaker notes, and backup slides."
[Deliver final markdown document]

---

**Ready to build your presentation? Let's start with Step 1: What's your audience and objective?**
