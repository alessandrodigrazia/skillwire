# Workflow: Generate Post-Meeting Summary (Advanced)

**Purpose**: Document meeting outcomes and create professional summaries for clients or internal CRM, with automatic format selection, transcript processing, and framework integration.

**Duration**: 10-20 minutes (faster with transcript upload)
**Output**: Client-facing memo, internal CRM report, email draft, Teams message, or combination

---

## When to Use

- After discovery meetings (initial or follow-up)
- After executive presentations / demos
- After technical deep-dives
- After negotiation sessions
- After any customer interaction requiring documentation

**Integration Points**:
- Updates **Buying Committee mapping** with stakeholder sentiment changes
- Updates **MEDDPICC+RR scores** based on new information
- Feeds into **Battle Plan** for next meeting preparation
- Creates **CRM entry** for opportunity tracking

---

## Quick Start Options

### Option A: Manual Input (You Describe Meeting)

I'll ask you questions, you provide answers, I generate summary.
**Best for**: Short meetings, simple outcomes

### Option B: Transcript Upload (AI-Powered Extraction)

You provide meeting transcript (Teams, Zoom, Google Meet export), I extract key points automatically.
**Best for**: Long meetings (60+ minutes), complex discussions, regulatory compliance needs

### Option C: Structured Notes (You Provide Bullets)

You paste your raw notes (bullets, fragments), I structure them professionally.
**Best for**: When you took notes during meeting but need them formalized

**Choose your option, and I'll guide you through the appropriate workflow.**

---

## The Process

### STEP 0: Format Selection (Automatic)

**I'll Ask**:
"What type of summary do you need?"

- **Client-Facing Memo** - Professional document to send to customer (polished, collaborative tone)
- **Internal CRM Report** - Detailed notes for your team/CRM (candid, strategic, includes red flags)
- **Email Draft** - Ready-to-send follow-up email to customer (concise, action-focused)
- **Teams Message** - Quick update for internal team (ultra-concise, highlights only)
- **Both Client + Internal** - Generate both formats (most common choice)
- **Let Me Decide** - I'll recommend based on meeting type

**If you choose "Let Me Decide", I'll recommend based on**:

| Meeting Type | Recommended Output | Rationale |
|---|---|---|
| **First discovery meeting** | Client Memo + Internal CRM | Client expects follow-up email; you need to capture intelligence |
| **Technical deep-dive** | Client Memo + Email Draft | Clients value technical action items; email is more concise than full memo |
| **Executive presentation** | Client Memo (formal) + Internal CRM | Executives expect polished documentation; you need strategic notes |
| **Negotiation session** | Internal CRM ONLY | Don't send written summary during active negotiation (preserve flexibility) |
| **Internal prep meeting** (no client) | Teams Message | Just update your team, no client deliverable |
| **Informal check-in call** | Email Draft | Too casual for formal memo, but need to document actions |

---

### STEP 1: Meeting Context

**Questions I'll Ask**:

1. **Meeting Type?**
   - Discovery (initial or follow-up)
   - Technical / Demo
   - Proposal / Presentation
   - Negotiation
   - Executive Review
   - Check-in / Status Update

2. **Date and Duration?**
   - Example: "May 10, 2025, 2:00-4:00 PM (2 hours)"

3. **Attendees?** (For each person, provide: Name, Title, Company, Role if known)
   - Example: "James Wilson, CIO, TechCorp (decision-maker)"
   - I'll automatically map to Buying Committee if you've done Buying Committee mapping previously

4. **Client Context**:
   - Opportunity name (if exists in CRM)
   - Deal stage (Discovery, Proposal, Negotiation, etc.)
   - Any prior context I should know? (e.g., "This is follow-up to our Q3 proposal")

5. **Input Method**:
   - Manual (you'll answer my questions)
   - Transcript (you'll upload/paste transcript file)
   - Structured Notes (you'll paste your bullet points)

---

### STEP 2A: Content Gathering (Manual Input)

**If you chose Manual Input**, I'll ask:

6. **Key discussion points?** (What topics were covered?)
   - Example: "Discussed integration requirements, timeline, budget concerns"

7. **Decisions made?** (What was agreed or decided?)
   - Example: "Agreed to pilot approach starting with Milan office"

8. **Action items?** (Who does what by when?)
   - Example: "Our Company to send technical architecture by May 15; Client to review by May 20"

9. **Next steps?** (What happens next in the process?)
   - Example: "Schedule technical deep-dive for May 25"

10. **Important quotes or insights?** (Anything particularly revealing?)
    - Example: "CFO said 'We've been burned by vendors before' - indicates trust issue"

11. **Concerns or objections raised?** (What worries them? Red flags?)
    - Example: "CIO concerned about change management and user adoption"

12. **Positive signals?** (What went well? Enthusiasm? Buy-in?)
    - Example: "CTO said 'This aligns perfectly with our digital transformation strategy'"

13. **Competitive intelligence?** (Any mention of competitors?)
    - Example: "They mentioned talking to Oracle, but said Oracle's pricing is too high"

14. **Updated stakeholder sentiment?** (Did anyone's attitude change?)
    - Example: "Chief Architect was skeptical before meeting, now very supportive after seeing demo"

---

### STEP 2B: Content Gathering (Transcript Upload)

**If you chose Transcript Upload**:

**Supported Formats**:
- Microsoft Teams transcript (.vtt, .txt, .docx export)
- Zoom transcript (.vtt, .txt)
- Google Meet transcript (from Google Docs export)
- Plain text (speaker labels must be present, e.g., "James Wilson: [text]")
- Any format with timestamp + speaker + dialogue structure

**What I'll Do**:
1. **Parse transcript**: Extract speaker names, timestamps, dialogue
2. **Identify key moments**:
   - Decisions ("we agree to...", "let's proceed with...")
   - Action items ("I'll send...", "you'll provide...")
   - Concerns ("I'm worried about...", "our concern is...")
   - Positive signals ("this looks great", "we're excited about")
   - Competitive mentions ("we're also talking to [Competitor]")
3. **Summarize discussions by topic**: Group related exchanges together
4. **Extract quotes**: Highlight particularly important or revealing statements
5. **Generate summary**: Create both client memo and internal CRM report

**You Just Need To**:
- Upload/paste the transcript
- Answer a few clarification questions if needed (e.g., "Is James Wilson the CIO or CFO?")

**Privacy Note**: Transcripts stay in this conversation, not stored externally.

---

### STEP 2C: Content Gathering (Structured Notes)

**If you chose Structured Notes**:

**You Provide** (paste your raw notes in any format):
```
Example format:

Meeting: TechCorp Discovery, May 10, 2 hours
Attendees: James (CIO), Karenh (CFO), David (IT Dir), Karen (Architect)

Discussed:
- Integration requirements (they have SAP, Salesforce, legacy mainframe)
- Timeline (need to go live by Q4 due to regulatory deadline)
- Budget (CFO said budget available but didn't specify amount)

Decisions:
- Pilot approach starting with Milan office
- Technical deep-dive scheduled for May 25

Actions:
- We send architecture diagram by May 15
- They review and provide feedback by May 20

Concerns:
- CFO skeptical about ROI, wants proof points
- CIO concerned about user adoption

Good signs:
- Architect validated our technical approach
- CIO very engaged, extended meeting by 30 min

Competitors:
- Mentioned Oracle (too expensive) and IBM (in discussions)
```

**I'll Do**:
- Structure your notes into professional format
- Expand terse bullets into full sentences (for client memo)
- Keep strategic bullets as-is (for internal CRM)
- Identify any missing elements and ask clarifying questions

---

---

## Output Option 1: Client-Facing Memo

**Purpose**: Professional document to send to the customer after the meeting.

**Tone**: Collaborative, solution-oriented, customer-centric

### Output Structure

```markdown
# Meeting Summary: [Topic/Project Name]

**Date**: [Date]
**Attendees**:
- [Customer Name 1], [Title], [Company]
- [Customer Name 2], [Title], [Company]
- [Your Name], [Title], Our Company
- [Colleague Name], [Title], Our Company

**Duration**: [X hours]

---

## Meeting Objective

The purpose of this meeting was to [discuss/review/present/explore] [topic/project].

---

## Key Discussion Points

### 1. [Topic Area 1]

**Discussion**:
[Summary of what was discussed]

**[Company Name]'s Perspective**:
[Capture their viewpoints, concerns, requirements]

**Our Company's Response**:
[What you proposed/recommended/clarified]

---

### 2. [Topic Area 2]

[Same structure]

---

### 3. [Topic Area 3]

[Same structure]

---

## Decisions & Agreements

1. **[Decision 1]**: [What was decided and by whom]
2. **[Decision 2]**: [What was agreed]
3. **[Decision 3]**: [Confirmed approach or direction]

---

## Action Items

| # | Action | Owner | Due Date | Status |
|---|---|---|---|---|
| 1 | Provide technical architecture diagram | Our Company (Mike) | May 15 | In Progress |
| 2 | Share reference customer contact info | Our Company (You) | May 12 | ✅ Complete |
| 3 | Review and approve  scope document | [Company] (James) | May 20 | Pending |
| 4 | Schedule follow-up technical deep-dive | Both | May 18 | Scheduled |

---

## Next Steps

**Immediate** (This Week):
- Our Company to send technical architecture diagram by May 15
- [Company] to review and provide feedback by May 17

**Near-Term** (Next 2 Weeks):
- Technical deep-dive session scheduled for May 18, 2 PM
- Proposal v2 incorporating feedback to be delivered by May 25

**Milestone**:
- Target decision date: June 5
- Proposed project kickoff: July 1

---

## Open Questions / Items for Future Discussion

1. **Integration with Legacy System X**: Need to validate data mapping requirements (defer to technical session)
2. **Budget Approval Timeline**: [Company] to confirm internal approval process timeline
3. **Phase 2 Scope**: To be discussed after Phase 1 agreement

---

## Closing

Thank you for a productive discussion. We're excited about the opportunity to partner with [Company] on [project name].

Please don't hesitate to reach out if you have any questions or need clarification on any of the points above.

Looking forward to our next conversation on [date].

Best regards,

[Your Name]
[Title]
Our Company
[Email] | [Phone]

---

**Attachments**:
- [List any documents shared during or after the meeting]
```

---

## Output Option 2: Internal CRM Report

**Purpose**: Detailed notes for your CRM/deal file. Includes strategic observations and intelligence.

**Tone**: Candid, analytical, strategic

### Output Structure

```markdown
# Internal Meeting Report: [Company Name]

**Date**: [Date]
**Opportunity**: [Deal Name/ID]
**Meeting Type**: [Discovery / Demo / Negotiation / Executive Review]
**Attendees**: [List]

---

## EXECUTIVE SUMMARY

**Meeting Outcome**: ✅ Positive / 😐 Neutral / ⚠️ Concerns

**Key Takeaway** (One Sentence):
[e.g., "CIO is strong champion but CFO is skeptical about ROI. Need to strengthen business case before next meeting."]

**Recommended Next Action**:
[e.g., "Schedule 1-on-1 with CFO to present ROI analysis. Do NOT proceed to proposal until CFO concerns are addressed."]

---

## DETAILED NOTES

### What Went Well ✅

1. **Strong engagement from CIO**: Spent 20 extra minutes beyond scheduled time. Clearly excited about the solution.
2. **Technical validation**: Their Chief Architect confirmed our approach aligns with their strategy.
3. **Timeline alignment**: They have internal mandate to decide by end of Q2 (matches our timeline).

### Concerns / Red Flags ⚠️

1. **CFO skepticism**: CFO (who joined last 15 minutes) challenged ROI assumptions. Quote: "We've heard these promises before and been disappointed."
   - **Implication**: Need stronger proof points. Action: Prepare detailed ROI with peer benchmarks.

2. **Budget ambiguity**: CIO said "budget is available" but couldn't confirm amount. CFO remained silent.
   - **Implication**: May not have firm budget commitment. Action: Qualify budget more explicitly in next meeting.

3. **Competitor mention**: They casually mentioned they're "also talking to [Competitor X]."
   - **Implication**: We're not the only vendor. Action: Conduct competitive intelligence, build battlecard.

### New Information / Intelligence 🔍

1. **Regulatory Pressure**: They mentioned new IVASS regulation requiring compliance by Q4 2025. This creates URGENCY.
2. **Internal Politics**: CIO and CFO have tension (body language, contradicting statements). CIO is pushing, CFO is braking.
   - **Buying Committee Update**: CIO = Champion (champion), CFO = Economic Buyer (skeptical). Need to work both angles.
3. **Implementation Timing**: They mentioned "project must go live before end of year" (more aggressive than we thought).
4. **Reference Request**: Asked for 2-3 reference customers in insurance. **Action**: Line up reference calls ASAP.

---

## Buying Committee UPDATES

| Name | Role | Buying Committee | Sentiment | Notes from This Meeting |
|---|---|---|---|---|
| James Wilson | CIO | Champion | 👍 Strong | Very engaged. Our main champion. Said "I want to make this happen." |
| Karenh Mitchell | CFO | Economic Buyer | 😐→👎 Skeptical | Joined late, challenged ROI. Needs convincing. Critical path. |
| David Chen | Dir IT Ops | User | 😐 Neutral | Concerned about team training. Asked good questions about change mgmt. |
| Karen Taylor | Chief Architect | Technical Buyer | 👍 Supportive | Validated our technical approach. Previously skeptical, now supporter. **WIN!** |

**Strategic Insight**: We've won over the Technical Buyer (Karen). Now need to win the Economic Buyer (Karenh/CFO). Focus next efforts on financial case.

---

## COMPETITIVE INTEL

**Competitor Mentioned**: [Competitor X]

**What We Learned**:
- They met with Competitor X 2 weeks ago
- CIO said: "Their solution felt generic, not insurance-specific" (good for us)
- CFO non-committal (no indication of preference)

**Our Counter-Strategy**:
- Double down on insurance domain expertise
- Highlight our track record vs their lack of insurance focus
- Prepare competitive comparison (subtle, not aggressive)

---

## DEAL QUALIFICATION (MEDDPICC+RR Quick Check)

**Quick Assessment** (updated post-meeting):

| Criterion | Score (1-5) | Change | Notes |
|---|---|---|---|
| Metrics | 4 | → | Needs validated, but CFO wants more proof |
| Economic Buyer | 3 | ↓ | CFO skeptical, challenged ROI. Critical path. |
| Decision Criteria | 4 | → | Technical criteria clear, financial criteria need work |
| Decision Process | 3 | → | Timeline clear, but no mutual action plan yet |
| Paper Process | 3 | → | Procurement process not yet discussed |
| Identify Pain | 5 | ↑ | Regulatory deadline = strong urgency, pain confirmed |
| Champion | 5 | ↑ | CIO is strong champion. "I want to make this happen." |
| Competition | 3 | ↓ | Competitor X is in the mix. Need strategy. |
| Relative Priority | 3 | → | Competing with digital transformation initiative for budget |
| Risk Factors | 3 | → | CFO skepticism + competitive threat + budget not explicitly confirmed |

**Overall MEDDPICC+RR Score**: 3.6/5 (was 3.8 before meeting)

**Assessment**: Still GO, but CFO skepticism and competitive situation are risks. Need to address before proposal.

---

## ACTION ITEMS (Internal)

### CRITICAL (This Week)

- [ ] **Build enhanced ROI analysis for CFO** (Owner: You + Finance team)
  - Include peer benchmarks
  - Conservative assumptions
  - Sensitivity analysis
  - Due: May 15

- [ ] **Line up 2-3 insurance reference customers** (Owner: You)
  - Prefer CFO-to-CFO conversations
  - Due: May 12

- [ ] **Competitive research on Competitor X** (Owner: Sales Ops)
  - Battlecard, pricing intel, known weaknesses
  - Due: May 14

### IMPORTANT (Next 2 Weeks)

- [ ] **Schedule 1-on-1 with CFO** (Owner: You, via CIO introduction)
  - 30-min call to present financial case
  - Target: Week of May 20

- [ ] **Technical deep-dive session** (Owner: Solution Architect)
  - May 18, 2 PM (confirmed)
  - Include Karen (Architect) and David (IT Ops Lead)

- [ ] **Proposal v2** (Owner: You + Presales)
  - Incorporate feedback from this meeting
  - Strengthen financial section
  - Due: May 25

---

## FORECAST UPDATE

**Previous Forecast**:
- Stage: Discovery
- Close Date: Q2 2024 (June)
- Probability: 60%
- Amount: €480K

**Updated Forecast** (post-meeting):
- Stage: Proposal / Technical Validation
- Close Date: Q2 2024 (June 30) - pushed 2 weeks
- Probability: 55% (decreased due to CFO skepticism + competitive threat)
- Amount: €480K (unchanged)

**Recommendation**: Keep in forecast but flag risks. Address CFO concerns before advancing to contract stage.

---

## NEXT MEETING

**Date**: May 18, 2024, 2:00 PM - 4:00 PM
**Type**: Technical Deep-Dive
**Attendees**: Karen (Architect), David (IT Ops), Our Solution Architect
**Objective**: Validate integration approach, address technical concerns
**Preparation Needed**:
- Architecture diagrams
- Integration specifications
- Security documentation

---

## MANAGER NOTES / ESCALATION

**Do We Need Help?**:
- **YES**: Request Sales Director to join CFO call (exec-to-exec engagement may help)
- Consider: Finance team support for ROI analysis (need rigorous model)

**Deal Risks**:
1. CFO skepticism (MEDIUM-HIGH risk)
2. Competitive threat from Competitor X (MEDIUM risk)
3. Budget not explicitly confirmed (MEDIUM risk)

**Mitigation Plan**: Focus next 2 weeks on financial validation and reference customers. If CFO remains unconvinced after ROI presentation, consider bringing in our CFO for peer conversation.

---

**Report Prepared By**: [Your Name]
**Date**: [Today's Date]
**Last Updated**: [Date if updated later]
```

---

## Output Option 3: Email Draft (Client-Facing)

**Purpose**: Quick, action-focused follow-up email to send within hours of meeting.

**Tone**: Professional but concise, focuses on actions and next steps

**When to Use**: Informal meetings, check-in calls, when full memo is overkill

### Output Structure

```markdown
**Subject**: Follow-Up: [Meeting Topic] - [Company Name] & Our Company

Hi [Primary Contact First Name],

Thank you for the productive conversation today. I wanted to quickly recap our discussion and confirm next steps.

**Key Points**:
- [Bullet 1 - main discussion point]
- [Bullet 2 - decision or agreement]
- [Bullet 3 - key takeaway]

**Action Items**:
- **Our Company** (me): [Action] by [Date]
- **Our Company** ([Colleague]): [Action] by [Date]
- **[Company]** ([Name]): [Action] by [Date]

**Next Steps**:
[What happens next - e.g., "We'll schedule the technical deep-dive for the week of May 20"]

Please let me know if I missed anything or if you have questions.

Looking forward to [next interaction],

[Your Name]
[Title]
Our Company
[Phone] | [Email]
```

**Length**: 150-250 words (fits on single screen, no scrolling)

---

## Output Option 4: Teams Message (Internal Team Update)

**Purpose**: Ultra-concise update for internal team channel

**Tone**: Informal, bullet-heavy, highlights only

**When to Use**: Quick team update after meeting, no formal documentation needed

### Output Structure

```markdown
**[Company Name] Meeting Update - [Date]**

Met with [Key Attendees] for [X] hours to discuss [Topic].

✅ **Wins**:
- [Positive outcome 1]
- [Positive outcome 2]

⚠️ **Risks/Concerns**:
- [Red flag 1]
- [Challenge 2]

📋 **Actions (Our Side)**:
- [Action 1] - [Owner] - [Due Date]
- [Action 2] - [Owner] - [Due Date]

🎯 **Next**: [What's happening next]

Full CRM notes: [Link to CRM record]
Questions? Ping me.
```

**Length**: 50-100 words

---

## Framework Integration & Updates

After generating the meeting summary, I'll automatically:

### 1. Update Buying Committee Mapping (If Applicable)

**I'll identify**:
- New stakeholders met during this meeting → Add to Buying Committee
- Sentiment changes → Update existing Buying Committee entries
- New political dynamics → Flag in Buying Committee "Relationships" section

**Example Buying Committee Update** (shown to you for review):

```
**Buying Committee Updates Based on This Meeting**:

ADDED:
- Karenh Mitchell, CFO → Economic Buyer (Economic Buyer) - Sentiment: Skeptical 😐

UPDATED:
- Karen Taylor, Chief Architect → Was Neutral 😐, Now Supportive 👍
  Reason: Validated technical approach during demo, said "This solves our biggest pain point"

POLITICAL DYNAMIC NOTED:
- CIO (James) and CFO (Karenh) have tension. CIO pushing project, CFO braking.
  Implication: Need to work both angles - don't just rely on CIO champion.
```

**Recommendation**: "Shall I update your Buying Committee file with these changes? (Y/N)"

---

### 2. Update MEDDPICC+RR Qualification (If Applicable)

**I'll identify new information affecting MEDDPICC+RR criteria**:

| MEDDPICC+RR Criterion | Before Meeting | After Meeting | Change | Reason |
|---|---|---|---|---|
| **Identify Pain** | 3/5 | 5/5 | ↑ +2 | Regulatory deadline mentioned (Q4 2025) creates hard deadline |
| **Economic Buyer** | 4/5 | 3/5 | ↓ -1 | CFO didn't confirm budget amount when asked directly |
| **Competition** | 4/5 | 3/5 | ↓ -1 | Mentioned talking to Oracle and IBM (we didn't know before) |
| **Decision Criteria** | 4/5 | 5/5 | ↑ +1 | Technical validation from Chief Architect |

**Overall MEDDPICC+RR Score**: 3.5/5 → 3.6/5 (net improvement, still GO)

**Recommendation**: "Shall I update your MEDDPICC+RR assessment with this new information? (Y/N)"

---

### 3. Generate Next Meeting Preparation (Battle Plan Preview)

**I'll suggest**:

"Based on this meeting, I recommend preparing for the next interaction:

**Next Meeting Type**: Technical Deep-Dive (May 18)
**Critical Prep**:
- [ ] Prepare architecture diagram addressing Karen's (Architect) specific questions
- [ ] Build competitive comparison vs Oracle (subtle, not aggressive) since they mentioned Oracle
- [ ] Develop enhanced ROI model for CFO (she challenged our assumptions)
- [ ] Line up reference customer in insurance sector (they asked for this)

**Would you like me to generate a Battle Plan for the May 18 technical deep-dive? (Y/N)**"

---

### 4. CRM Entry Template (For Copy-Paste)

**I'll provide**:

```
**FOR YOUR CRM SYSTEM** (copy-paste ready):

Opportunity: [Company Name] - [Project Name]
Last Activity: Meeting - [Type]
Date: [Date]
Duration: [X hours]
Attendees: [Names, Titles]
Stage: [Current Stage]
Next Step: [Specific action]
Probability: [Updated %]
Close Date: [Updated date if changed]

Summary:
[2-3 sentence executive summary]

Key Concerns:
- [Concern 1]
- [Concern 2]

Next Actions:
- [Action 1] - [Owner] - [Due]
- [Action 2] - [Owner] - [Due]

Competitive Threats: [Competitors mentioned]
Updated Forecast: [Any changes to amount/close date/probability]

Full details: [Link to detailed memo/report]
```

---

## Advanced Features

### Feature 1: Sentiment Analysis (Transcript Upload Only)

**If you provide transcript**, I'll analyze:

**Engagement Metrics**:
- **Speaking Time Distribution**: Who talked most? (CIO: 40%, Architect: 25%, You: 20%, CFO: 10%, Others: 5%)
- **Question Count**: Who asked most questions? (indicates interest/skepticism)
- **Interruptions**: Who interrupted whom? (indicates power dynamics)

**Sentiment Indicators**:
- **Positive Language**: "excited", "perfect", "exactly what we need", "love this"
- **Negative/Concern Language**: "worried", "concerned", "not sure", "skeptical"
- **Commitment Language**: "we'll", "let's proceed", "approved" (strong signal)
- **Hedge Language**: "maybe", "we'll see", "need to think about" (weak signal)

**Example Output**:

```
**SENTIMENT ANALYSIS** (Transcript-Based):

📊 **Engagement**:
- CIO (James): 45% speaking time, asked 8 questions → Very engaged ✅
- CFO (Karenh): 10% speaking time, asked 3 challenging questions → Skeptical ⚠️
- Architect (Karen): 25% speaking time, asked 6 technical questions → Engaged & validating ✅

💬 **Language Patterns**:
- **Positive**: CIO used "excited" 3 times, "exactly" 2 times → Strong champion
- **Concern**: CFO used "concerned" 2 times, "skeptical" 1 time → Needs convincing
- **Commitment**: CIO said "let's proceed with pilot" (strong signal!)
- **Hedging**: CFO said "we'll need to think about budget" (weak commitment)

🎯 **Interpretation**:
Strong championship from CIO and technical validation from Architect.
CFO is gatekeeper - need to address her concerns directly before advancing.
```

---

### Feature 2: Competitive Intelligence Extraction

**I'll automatically flag**:

**Competitor Mentions**:
- **Who**: Oracle, IBM
- **Context**: "We're also talking to Oracle, but their pricing seems high" (price objection)
- **Stage**: In discussions (not just awareness)
- **Sentiment**: Negative on Oracle pricing (opportunity for us!)

**Competitive Strategy**:
```
**RECOMMENDED COUNTER-STRATEGY**:

vs. Oracle:
- They flagged Oracle pricing → Emphasize our value-based pricing, TCO advantage
- Don't mention Oracle directly in client materials, but prepare pricing comparison for internal use
- If asked, position as "We focus on value, not just cost" (don't race to bottom)

vs. IBM:
- Less intel on IBM (just mentioned "in discussions")
- Action: Research IBM's solution in this space, prepare battlecard
- Likely angle: IBM = complex, slow; We = agile, specialized

**Next Step**: Build competitive comparison matrix (internal use), prep counter-positioning
```

---

### Feature 3: Risk Flagging & Escalation Recommendation

**I'll automatically flag risks**:

🚨 **HIGH RISK** (requires immediate action):
- CFO skepticism threatens deal closure
- Competitive threat from Oracle/IBM (active evaluations)
- Budget not confirmed despite direct question

⚠️ **MEDIUM RISK** (monitor closely):
- Implementation timeline aggressive (Q4 deadline, 6-month project)
- User adoption concerns (from IT Director)

**Escalation Recommendation**:
```
**SHOULD YOU ESCALATE?**

YES - Consider:
- **Sales Director involvement**: CFO-level engagement may help (exec-to-exec)
- **Finance team support**: Need rigorous ROI model to address CFO concerns
- **Reference customers**: CFO asked for proof points - line up CFO-to-CFO calls

**Escalation Script**:
"Hi [Sales Director], quick heads-up on TechCorp deal.

Strong technical validation and CIO championship, but CFO is skeptical about ROI.
She specifically asked for peer benchmarks and proof points.

**Request**:
1. Join me on CFO call (exec-to-exec engagement)
2. Connect with Finance team for rigorous ROI model
3. Help line up 2-3 reference CFOs in insurance sector

Deal is still GO (3.6/5 MEDDPICC+RR) but these risks need proactive mitigation.

Thoughts?"
```

---

## Best Practices

### For Client-Facing Memos:

1. **Send Within 24 Hours**: Strike while the iron is hot (preferably same day)
2. **Be Accurate**: Reflect what was actually said/decided (don't embellish)
3. **Be Positive But Realistic**: Focus on progress, but don't overpromise
4. **Be Clear on Actions**: Who, what, when (specific, not vague)
5. **Professional Tone**: Collaborative, not salesy
6. **Use Their Language**: Mirror terminology they used (don't introduce new jargon)

**Pro Tip**: If negotiation is ongoing, be careful about locking yourself into positions via written memo. Sometimes it's better to send just email draft (less formal) or even just verbal follow-up call.

---

### For Internal CRM Reports:

1. **Be Candid**: Include concerns, red flags, political dynamics (this is for YOU, not client)
2. **Update Buying Committee**: Capture new stakeholders, sentiment changes, power dynamics
3. **Competitive Intel**: Document any competitor mentions (even casual references matter)
4. **Strategic Insights**: What did you LEARN about the deal? About the client? About their priorities?
5. **Action-Oriented**: Clear next steps with owners and deadlines
6. **Forecast Impact**: If new information changes close probability/date/amount, call it out

**Pro Tip**: The value of internal reports compounds over time. When you revisit this deal in 6 months, your past notes will be gold. Capture political dynamics and personalities - they matter.

---

### For Email Drafts:

1. **Keep It Short**: 150-250 words max (fits on phone screen without scrolling)
2. **Actions Above The Fold**: Most important info in first 3 lines
3. **Subject Line Matters**: Make it specific ("Follow-Up: Security Requirements Discussion") not generic ("Meeting Follow-Up")
4. **Mobile-Friendly**: Short paragraphs, bullet points (many executives read on mobile)

---

### For Teams Messages:

1. **Use Emojis Sparingly But Effectively**: ✅ ⚠️ 🎯 help scan quickly
2. **Link to Full Details**: "Full notes in CRM: [link]" (don't duplicate everything)
3. **Tag People If Needed**: "@Mike - see action item #2 for you"
4. **Update Channel Regularly**: Don't let your team be surprised by deal developments

---

## Common Mistakes to Avoid

❌ **Sending generic summary**: "We had a good meeting" (useless to everyone)
✅ **Be specific**: "CFO challenged ROI; needs peer benchmarks by May 15. CIO remains strong champion."

❌ **Overpromising in client memo**: "We'll solve all your problems and deliver in 2 months"
✅ **Be realistic**: "We agreed to explore feasibility of X in technical session on May 18"

❌ **Ignoring red flags in CRM**: Pretending everything is fine (optimism bias kills deals)
✅ **Document concerns**: "CFO skeptical - this is a risk to close date. Need exec-to-exec engagement."

❌ **No follow-through on actions**: Listing actions nobody owns or tracks
✅ **Assign owners and dates**: "Mike to provide architecture diagram by May 15 (I'll follow up May 14)"

❌ **Writing client memo that reveals internal strategy**: "We need to close this deal by June to hit quota"
✅ **Client-appropriate language**: "We're excited to support your Q3 go-live target"

❌ **Sending client memo before internal team alignment**: Client gets memo, your sales director finds out from client
✅ **Internal first, then external**: Update your team/manager BEFORE sending client memo

❌ **Transcript upload without context**: Just pasting 10,000-word transcript and saying "summarize this"
✅ **Provide context**: "This is technical deep-dive with TechCorp. Focus on Karen (Architect) and David (IT Dir) feedback."

---

## Troubleshooting

### Problem 1: "I don't remember specific details from the meeting"

**Solution**: Use what you have! Even partial information is better than nothing.

Tell me:
- What you DO remember (even if vague: "We talked about integration, timeline, and budget")
- What was decided (even if just "We agreed to schedule a follow-up")
- Any standout moments ("CFO was skeptical" - even if you don't remember exact words)

I'll generate a summary from partial information and highlight gaps for you to fill in if needed.

**Pro Tip**: Next time, take quick notes during meeting (even just bullets on paper). Or record meeting (with permission) and use transcript upload feature.

---

### Problem 2: "Meeting went poorly / we didn't get what we wanted"

**Solution**: Document it anyway!

**Client Memo**: Stay professional, focus on "areas for further discussion" (don't write "they hated our proposal")
**Internal CRM**: Be candid - "Proposal rejected. CFO said pricing is 2x their budget. Need to regroup."

Bad meetings are learning opportunities. Documenting what went wrong helps you (and your team) avoid repeating mistakes.

---

### Problem 3: "I need to send this in 10 minutes (client is waiting)"

**Solution**: Use **Email Draft** format (fastest).

Tell me:
- 3 key points from meeting
- 2-3 action items
- Next step

I'll generate a ready-to-send email in 2 minutes. You can do the full memo/CRM report later.

**Pro Tip**: Better to send quick accurate email in 1 hour than perfect memo in 3 days. Speed matters.

---

### Problem 4: "Transcript is 50 pages / 20,000 words"

**Solution**: I can handle it!

Upload/paste the full transcript. I'll:
1. Identify key moments (decisions, actions, concerns)
2. Summarize by topic (not chronologically)
3. Extract important quotes
4. Flag sensitive information (e.g., competitor trash-talk, pricing discussions)

**Note**: If transcript is VERY long (>30,000 words), I may need to process in chunks. I'll let you know.

---

## Getting Started

**Tell me**:

1. **What type of summary?**
   - Client-Facing Memo
   - Internal CRM Report
   - Email Draft
   - Teams Message
   - Both Client + Internal (most common)
   - Let Me Decide (I'll recommend based on meeting type)

2. **Input method?**
   - Manual (I'll ask you questions)
   - Transcript Upload (paste/upload transcript file)
   - Structured Notes (paste your bullet points)

3. **Meeting basics**:
   - Date, duration, attendees, meeting type

4. **Any special requests?**
   - "Focus on technical details" (e.g., for technical deep-dive)
   - "Keep it very concise" (e.g., for informal check-in)
   - "Include competitive analysis" (if competitors were discussed)
   - "Update Buying Committee and MEDDPICC+RR" (if you want framework integration)

**I'll handle the rest!**

---

## Integration with Sales Methodology

**This workflow integrates with**:

- **Buying Committee Mapping** ([buying-committee-template.md](../templates/buying-committee-template.md)): Updates stakeholder sentiment based on meeting observations
- **MEDDPICC+RR Qualification** ([meddpicc-rr-template.md](../templates/meddpicc-rr-template.md)): Updates qualification scores based on new information
- **Battle Plan** ([workflow: prepare-meeting.md](prepare-meeting.md)): Feeds forward to next meeting preparation
- **CRM Systems**: Provides formatted entries for Salesforce, HubSpot, Dynamics, etc.

**Workflow Orchestration**: See [workflow-orchestration.md](../methodology/workflow-orchestration.md) for guidance on when to use post-meeting summary in the sales cycle.

**Decision Tree**: See [decision-tree.md](../methodology/decision-tree.md) for intent classification (e.g., "document meeting" → this workflow).

---

**Ready? Let's document that meeting properly.**

**Tell me your summary type and input method, and we'll get started!**
