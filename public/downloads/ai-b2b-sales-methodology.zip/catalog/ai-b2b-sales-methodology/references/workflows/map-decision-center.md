# Workflow: Map Decision Center (Buying Committee)

**Purpose**: Identify and map all stakeholders in a complex B2B buying decision using the Buying Committee framework.

**Duration**: 20-30 minutes
**Output**: Complete stakeholder map with roles, influence levels, engagement strategies

---

## When to Use This Workflow

Use Buying Committee mapping when:
- You're dealing with enterprise deals involving multiple stakeholders
- You need to understand who influences or controls the decision
- You're blocked and need to find alternative pathways to decision makers
- You want to validate that you're engaging the right people
- Management asks "Who are you talking to?"

**Critical Timing**: Map the Buying Committee after initial discovery but before investing heavily in proposals. Update continuously as you learn more.

---

## What Is the Buying Committee?

The **Buying Committee** is the group of stakeholders involved in a complex B2B purchase decision. Every enterprise deal has 5 archetypal roles that must be identified and engaged:

- **Champion**: Your internal advocate who sells for you when you're not in the room
- **Economic Buyer**: The person with final authority and budget to approve the purchase
- **Technical Buyer**: The expert who validates feasibility, security, and architecture
- **User**: The people who will use your solution day-to-day
- **Coach**: Your inside ally who provides intelligence and guidance

**Critical Insight**: A single person can play MULTIPLE roles. Your CIO contact might be both Champion AND Coach.

---

## Why Buying Committee Mapping Matters

### The Cost of Getting It Wrong

**Scenario**: You spend 3 months working with a "Director of IT Operations" who seems engaged and supportive. You build a custom demo, present multiple times, invest presales resources. Then they say: "Great! I'll present this to the CIO for approval."

You realize: You've been selling to a User with no decision authority. The CIO (the real Economic Buyer) has never heard of you.

**Result**: Deal delayed 6 months or lost entirely.

### The Power of Getting It Right

When you have a complete Buying Committee map:
- **Efficiency**: Focus time on high-influence stakeholders
- **Strategy**: Tailor messages to each role's concerns
- **Risk Mitigation**: Identify detractors early and neutralize them
- **Velocity**: Navigate politics to accelerate decisions
- **Intelligence**: Your Coach warns you of obstacles before they appear

---

## The Buying Committee Framework: The 5 Roles

### CHAMPION

**Who They Are**:
The internal advocate who sponsors the initiative and has a personal stake in its success.

**Characteristics**:
- Has organizational power and budget influence
- Politically motivated to make this project succeed
- Can remove obstacles and allocate resources
- Has "skin in the game" (their reputation/career tied to success)

**What They Care About**:
- Looking good to their boss (CEO/Board)
- Achieving their strategic objectives
- Career advancement and recognition
- Building their legacy

**How to Identify**:
- "Who internally is driving this initiative?"
- "Who has the most to gain if this succeeds?"
- "Who championed the budget for this project?"

**Engagement Strategy**:
- Position them as the hero of the story
- Provide "air cover" (materials they can use to defend the project internally)
- Keep them informed and armed with talking points
- Make them look smart in front of their peers

**Red Flag**: No Champion = High risk. Someone needs to be internally selling for you when you're not in the room.

---

### ECONOMIC BUYER

**Who They Are**:
The person with FINAL authority to sign the contract. They can say "YES" when everyone else says "NO," or "NO" when everyone else says "YES."

**Characteristics**:
- Typically C-level (CEO, CFO, CIO) or VP with P&L authority
- Has veto power over the decision
- May not be involved in day-to-day evaluation
- Cares about strategic and financial implications

**What They Care About**:
- Risk mitigation (financial, operational, reputational)
- Strategic alignment with company goals
- ROI and business outcomes
- Fiduciary responsibility (protecting shareholders/board)

**How to Identify**:
- "Who has final signature authority for contracts of this size?"
- "If everyone else approved this, who could still say no?"
- Look at contract signatory policies

**Engagement Strategy**:
- **Direct access is critical**: If you can't meet them, find a way (through Champion or exec-to-exec)
- Executive-level communication: Business outcomes, not features
- Provide ROI/business case tailored to their concerns
- Address their specific risks proactively

**Red Flag**: If you haven't met the Economic Buyer by proposal stage, you're flying blind. They may have concerns no one has told you about.

---

### TECHNICAL BUYER

**Who They Are**:
The technical evaluator who validates that your solution is feasible, secure, and architecturally sound.

**Characteristics**:
- Deep technical knowledge
- Concerned with "how it works" not "why we need it"
- Can kill a deal with technical objections
- Creates evaluation criteria and scorecards

**What They Care About**:
- Technical feasibility and risk
- Integration with existing systems
- Security, scalability, compliance
- Not being blamed if it fails
- Professional reputation (won't recommend something that might break)

**How to Identify**:
- "Who will evaluate the technical architecture?"
- "Is there a CTO, Chief Architect, or Lead Engineer involved?"
- Often carries titles like "Solutions Architect," "Technical Director," "Head of Infrastructure"

**Engagement Strategy**:
- Respect their expertise (don't BS or oversimplify)
- Provide deep technical documentation
- Arrange technical deep-dives with your architects
- Offer POC or pilot to prove feasibility
- Address security/compliance concerns proactively

**Red Flag**: A Technical Buyer who doesn't trust you will create technical objections that are hard to overcome. Build credibility early.

---

### USER

**Who They Are**:
The people who will actually USE your solution day-to-day.

**Characteristics**:
- Cares about usability, workflow, and daily impact
- Often not at decision-making table but has VETO power through resistance
- Can sabotage implementation if not bought in
- Multiple Users in most deals (entire departments)

**What They Care About**:
- "Will this make my job easier or harder?"
- Training and learning curve
- Disruption to current workflows
- Job security (will this replace me?)

**How to Identify**:
- "Who will use this solution every day?"
- "Which teams will be impacted?"
- "Who needs to change their workflow?"

**Engagement Strategy**:
- Involve them EARLY (before decision, not after)
- Demonstrate ease of use
- Emphasize how it makes their job better (not just faster)
- Provide training and change management support
- Get their feedback and incorporate it (even small changes show you listened)

**Red Flag**: Users who feel ignored will resist adoption, making the project "fail" even if it's technically successful.

---

### COACH

**Who They Are**:
Your inside ally who provides intelligence, guidance, and advocacy when you're not in the room.

**Characteristics**:
- Trusts you and wants you to succeed
- Has access to information others don't share
- Warns you of political landmines
- Coaches you on how to navigate the organization
- **Critically**: They have something to gain from your success (not purely altruistic)

**What They Care About**:
- Often aligned with Champion's objectives (may be the same person)
- May personally benefit (promotion, easier job, political favor)
- Sometimes motivated by wanting the "right solution" to win

**How to Identify**:
- "Who has told me things others haven't?"
- "Who warned me about a problem before it appeared?"
- "Who is actively helping me navigate this organization?"
- "Who returns my calls immediately and provides honest feedback?"

**Engagement Strategy**:
- **Cultivate the relationship**: This is your most valuable asset
- Provide value to them (not just take)
- Keep them informed of progress
- Ask for guidance regularly: "What am I missing?" "Who should I be talking to?"
- Protect their confidentiality (never reveal they told you something)

**Red Flag**: No Coach = You're navigating blind. If you don't have one, you're in reactive mode. Cultivate one immediately.

---

## The Buying Committee Mapping Process

### Step 1: Stakeholder Identification

First, I'll help you list ALL stakeholders involved in or impacted by this decision.

#### Questions I'll Ask

1. **Initial Contact**:
   - "Who was your first point of contact?"
   - "How did you get introduced?" (referral, inbound, cold outreach)

2. **Meeting Participants**:
   - "Who have you met with so far?" (names, titles, departments)
   - "Who attended each meeting?"

3. **Mentioned Stakeholders**:
   - "Have they mentioned others who are involved?"
   - "Who do they report to?"
   - "Who do they collaborate with on this?"

4. **Procurement & Legal**:
   - "Is Procurement involved?"
   - "Has Legal been engaged?"

5. **Executive Layer**:
   - "Who is the highest-level person you know is aware of this initiative?"
   - "Do you know who will ultimately sign the contract?"

6. **End Users**:
   - "Which departments or teams will use this solution?"
   - "How many end users are there?"

#### Output

A raw list of stakeholders:

```markdown
## Stakeholder List: [Company Name]

1. James Wilson - CIO
2. Sarah Mitchell - VP Digital Transformation
3. David Chen - Director of IT Operations
4. Karen Taylor - Chief Architect
5. Mike Reynolds - Procurement Manager
6. Team: IT Operations (15 people)
7. Unknown: CFO (mentioned but not met)
```

---

### Step 2: Buying Committee Role Assignment

For each stakeholder, I'll help you assign Buying Committee roles.

**Remember**: One person can have MULTIPLE roles.

#### Questions I'll Ask Per Stakeholder

For each person on the list:

1. **Power & Authority**:
   - "Can [Name] sign contracts of this size?"
   - "Do they control budget?"
   - "What's their level of organizational influence?"

2. **Role in Evaluation**:
   - "What is [Name]'s role in this project?"
   - "Are they evaluating, deciding, using, or sponsoring?"

3. **Motivation**:
   - "What does [Name] care about?"
   - "What do they have to gain or lose?"

4. **Behavior**:
   - "Has [Name] provided insider information or guidance?"
   - "Are they supportive, neutral, or resistant?"

#### Output

Buying Committee role assignments:

```markdown
## Buying Committee Map: [Company Name]

| Name | Title | Role(s) | Notes |
|---|---|---|---|
| James Wilson | CIO | **Champion**, **Coach** | Strong sponsor. Has warned us about CFO concerns. Our primary advocate. |
| Sarah Mitchell | VP Digital | **Economic Buyer** (operational) | Has authority up to $500K. Above that, needs CFO approval. |
| David Chen | Director IT Ops | **User** (lead) | Will manage the solution. Concerned about team training. Neutral so far. |
| Karen Taylor | Chief Architect | **Technical Buyer** | Technical gatekeeper. Skeptical of cloud security. Must win her over. |
| Mike Reynolds | Procurement | Non-Committee (Facilitator) | Process-driven. Not an influencer, just executes once decision is made. |
| CFO (Unknown name) | CFO | **Economic Buyer** (final) | Final signature for >$500K. Risk-averse. Haven't met yet. **CRITICAL GAP** |
| IT Ops Team (15) | Various | **Users** | End users. Need to be trained and bought in. Not decision influencers but can sabotage adoption. |
```

---

### Step 3: Influence & Sentiment Analysis

For each key stakeholder (Buying Committee roles), I'll help you assess:

#### Influence (1-5)
How much does their opinion matter in the final decision?

| Score | Definition |
|---|---|
| 5 | Decisive influence. Their opinion determines the outcome. |
| 4 | Strong influence. Can sway the decision significantly. |
| 3 | Moderate influence. Their input is considered but not decisive. |
| 2 | Low influence. Aware of the decision but not consulted. |
| 1 | No influence. No role in the decision. |

#### Urgency (1-5)
How urgently do they need this solved?

| Score | Definition |
|---|---|
| 5 | Crisis. They need this yesterday. |
| 4 | High priority. Top 3 initiative for them. |
| 3 | Important but not urgent. Competing priorities. |
| 2 | Low priority. "Nice to have." |
| 1 | No urgency. Indifferent. |

#### Sentiment (Supporter / Neutral / Detractor)
What is their current opinion of your solution?

- **Supporter**: Actively advocates for you
- **Neutral**: Open-minded, needs convincing
- **Detractor**: Resistant, skeptical, or prefers competitor

#### Output

```markdown
## Influence, Urgency, Sentiment Analysis

| Name | Role | Influence | Urgency | Sentiment | Strategic Notes |
|---|---|---|---|---|---|
| James Wilson | Champion, Coach | 5 | 5 | Supporter | **Critical ally**. Keep armed with talking points. He's selling for us internally. |
| Sarah Mitchell | Economic Buyer | 5 | 4 | Neutral | **Decision maker**. Neutral but open. Needs business case focused on operational efficiency. |
| David Chen | User | 3 | 3 | Neutral | **Key user**. Concerned about change management. Must involve him in design. |
| Karen Taylor | Technical Buyer | 4 | 3 | Detractor | **Technical blocker**. Skeptical of cloud security. **URGENT**: Arrange deep-dive with our security architect. |
| CFO (Unknown) | Economic Buyer | 5 | 2 | Unknown | **Final signer**. Unknown sentiment. **CRITICAL GAP**: Must meet before proposal. Ask James for intro. |
```

---

### Step 4: Objectives & Motivations

For each key stakeholder, I'll help you understand what they REALLY want (beyond the stated project goals).

#### Questions I'll Ask

1. **Business Objectives**:
   - "What are [Name]'s stated goals for this project?"
   - "What business metrics are they responsible for?"
   - "What does success look like for them?"

2. **Personal Objectives**:
   - "What might [Name] personally gain if this succeeds?" (promotion, easier job, political capital)
   - "What do they risk if this fails?" (reputation, job security, political standing)
   - "Are they trying to prove something?" (competence, vision, innovation)

3. **Fears & Concerns**:
   - "What keeps [Name] up at night about this project?"
   - "What could go wrong that would hurt them?"

#### Output

```markdown
## Stakeholder Objectives & Motivations

### James Wilson (CIO) - Champion, Coach

**Business Objectives**:
- Modernize IT infrastructure to support digital transformation
- Reduce IT operating costs by 20%
- Improve system uptime to 99.9%

**Personal Objectives**:
- CEO has tasked him with "making IT an innovation enabler, not a cost center"
- Wants to leave a legacy of transformation (he's 2 years from retirement)
- Prove that experienced CIOs can drive innovation

**Fears & Concerns**:
- Major outage during migration would damage his reputation
- CFO will veto if ROI isn't clear
- Failure would undermine his credibility with CEO

**Implication for Us**:
- Emphasize risk mitigation and phased approach
- Provide ROI business case he can use with CFO
- Position as "your legacy project"
- Highlight our experience with zero-downtime migrations

---

### Karen Taylor (Chief Architect) - Technical Buyer

**Business Objectives**:
- Ensure technical solutions are scalable, secure, compliant
- Maintain architectural integrity of systems
- Avoid "technical debt" that she'll have to fix later

**Personal Objectives**:
- Protect her professional reputation (won't recommend something that fails)
- Maintain influence as "technical conscience"
- Concerned that cloud vendors lock them in

**Fears & Concerns**:
- Security breach would be blamed on her
- Vendor lock-in limits future flexibility
- Solution doesn't integrate cleanly with legacy systems

**Implication for Us**:
- Deep technical dive on security architecture
- Show multi-cloud strategy and exit options (no lock-in)
- Prove integration feasibility with detailed architecture diagrams
- Offer extended POC to build her confidence

[Repeat for each key stakeholder]
```

---

### Step 5: Engagement Strategy

For each stakeholder, I'll recommend a specific engagement strategy.

#### Output

```markdown
## Engagement Strategy by Stakeholder

### James Wilson (CIO) - Champion, Coach
**Current Status**: Strong ally, actively coaching us

**Strategy**: **Arm and Enable**
- **Frequency**: Weekly check-ins
- **Content**: Provide him with materials to sell internally:
  - Executive summary slides for CFO
  - Talking points for CEO updates
  - Case studies of similar transformations
- **Ask**: "What are you hearing internally that I should know?"
- **Next Action**: Send him draft business case by Friday for his feedback

---

### Sarah Mitchell (VP Digital) - Economic Buyer
**Current Status**: Decision maker, neutral, needs convincing

**Strategy**: **Value-Based Persuasion**
- **Frequency**: Bi-weekly meetings + proposal presentation
- **Content**: Focus on operational efficiency gains and team productivity
  - Quantified business case specific to her KPIs
  - Demo tailored to her use cases
- **Ask**: "What would make this a no-brainer for you?"
- **Next Action**: Schedule 1-hour business case presentation

---

### Karen Taylor (Chief Architect) - Technical Buyer
**Current Status**: Technical gatekeeper, skeptical

**Strategy**: **Build Technical Credibility**
- **Frequency**: Technical deep-dive sessions (2-3 over next month)
- **Content**:
  - Security architecture review with our Chief Security Officer
  - Integration architecture with our Solutions Architect
  - Reference architecture from similar clients
- **Ask**: "What are your top 3 technical concerns? Let's address them."
- **Next Action**: Schedule 2-hour technical workshop for next week

---

### CFO (Unknown) - Economic Buyer (Final)
**Current Status**: Unknown, not yet engaged, **CRITICAL GAP**

**Strategy**: **Executive Access via Champion**
- **Frequency**: Need at least ONE meeting before proposal
- **Content**: 30-minute business case focused on:
  - ROI and payback period
  - Risk mitigation
  - Financial structure (OPEX vs CAPEX)
- **Ask James (Champion)**: "Can you arrange a brief intro meeting with the CFO?"
- **Next Action**: Request James to facilitate introduction this week

---

### David Chen (Director IT Ops) - User Lead
**Current Status**: Key user, neutral, concerned about team impact

**Strategy**: **Involve and Co-Create**
- **Frequency**: Include in design sessions
- **Content**:
  - Hands-on demo for him and his team
  - Co-create training plan
  - Designate him as "internal champion" for his team
- **Ask**: "What would make your team excited about this vs resistant?"
- **Next Action**: Invite him to a "user feedback session" with 3 of his team members
```

---

## Step 6: Gap Analysis & Risks

I'll identify gaps and risks in your Buying Committee coverage.

### Critical Gaps to Identify

1. **Missing Roles**:
   - Do we have access to all 5 Buying Committee roles?
   - Are any roles unknown or unidentified?

2. **Blocked Access**:
   - Are we being gatekept from any critical role?
   - Who are we NOT talking to that we should be?

3. **No Coach**:
   - Do we have at least ONE strong Coach?
   - If not, who could we cultivate?

4. **Detractor Risk**:
   - Are there stakeholders actively working against us?
   - Can we neutralize them or go around them?

5. **Economic Buyer Access**:
   - Have we met the FINAL Economic Buyer?
   - If not, what's our path to access?

#### Output

```markdown
## Buying Committee Gap Analysis & Risk Assessment

### Strengths
- **Strong Champion/Coach**: James (CIO) is actively coaching us
- **Economic Buyer Identified**: Sarah (VP) is clear operational decision maker
- **Technical Buyer Engaged**: Karen is skeptical but engaged (better than ignored)

### Critical Gaps

#### GAP 1: No Access to Final Economic Buyer (CFO)
**Risk Level**: CRITICAL
- **Issue**: Deals >$500K require CFO signature. We haven't met them.
- **Impact**: CFO could veto at the last minute based on financial concerns we haven't addressed
- **Mitigation**:
  - Ask James to arrange intro meeting ASAP
  - Prepare CFO-specific business case (ROI, cash flow, risk)
  - Fallback: Request to present at finance committee meeting

#### GAP 2: Karen (Technical Buyer) is Skeptical
**Risk Level**: HIGH
- **Issue**: Chief Architect doesn't trust cloud security
- **Impact**: Could create technical objections that block or delay the deal
- **Mitigation**:
  - Schedule immediate technical deep-dive with our CSO
  - Provide detailed security architecture documentation
  - Offer extended POC to prove security compliance
  - Find reference customer with similar security requirements

#### GAP 3: Limited User Buy-In
**Risk Level**: MEDIUM
- **Issue**: Only talked to David (lead), not his 15-person team
- **Impact**: Team resistance during implementation could cause project to "fail"
- **Mitigation**:
  - Involve 3-5 team members in demo/feedback sessions
  - Co-create training plan with David
  - Emphasize "makes your job easier" messaging

### Role Coverage

| Role | Status | Action Required |
|---|---|---|
| **Champion** | Identified (James) | Keep engaged |
| **Economic Buyer** | Partial (Sarah yes, CFO no) | **URGENT: Access CFO** |
| **Technical Buyer** | Identified (Karen) | Neutralize skepticism |
| **User** | Limited (only lead) | Expand engagement |
| **Coach** | Strong (James) | Maintain relationship |

### Action Plan Priority

1. **Week 1**: Request CFO meeting via James
2. **Week 1**: Schedule technical deep-dive with Karen
3. **Week 2**: Conduct user feedback session with IT Ops team
4. **Week 2**: Present business case to Sarah (VP)
5. **Week 3**: Present financial case to CFO (if access granted)
```

---

## Output: Complete Buying Committee Map Document

At the end of this workflow, you'll receive a comprehensive document:

```markdown
# Buying Committee Map: [Company Name]
**Deal**: [Solution Name]
**Deal Size**: $[X]K
**Date**: [Today]
**Last Updated**: [Date]

---

## Executive Summary

**Decision Committee Size**: 7 stakeholders + 15 end users
**Key Decision Maker**: Sarah Mitchell (VP Digital), CFO for final approval >$500K
**Our Strongest Ally**: James Wilson (CIO) - Champion + Coach
**Biggest Risk**: CFO access + Karen (Architect) skepticism

**Recommendation**:
- **Do NOT submit proposal** until we meet CFO and neutralize Karen's concerns
- **Timeline**: 2-3 weeks to address gaps, then proceed to proposal

---

## Buying Committee Stakeholder Matrix

[Complete table from Step 3]

---

## Detailed Stakeholder Profiles

[Complete profiles from Step 4]

---

## Engagement Strategy

[Complete strategies from Step 5]

---

## Gap Analysis & Risk Mitigation

[Complete analysis from Step 6]

---

## Next Actions (Priority Order)

1. [ ] [Week 1] Request CFO intro via James
2. [ ] [Week 1] Schedule Karen technical deep-dive
3. [ ] [Week 2] User feedback session with IT Ops
4. [ ] [Week 2] Business case presentation to Sarah
5. [ ] [Week 3] CFO financial case presentation

---

## Appendix: Meeting History

| Date | Attendees | Key Takeaways |
|---|---|---|
| Jan 5 | James (CIO), Sarah (VP) | Initial discovery. James very engaged. |
| Jan 12 | David (Dir IT Ops) | Concerned about team training needs. |
| Jan 18 | Karen (Architect) | Skeptical of cloud security. Needs proof. |

---

**Status**: IN PROGRESS - Critical gaps to address before proposal
**Next Review**: [Date] (update after CFO meeting)
```

---

## How This Workflow Progresses

### Conversational Style
I'll walk you through each step, asking questions to fill in the Buying Committee map progressively. You don't need to have all the answers upfront.

### Iteration Allowed
If you realize you need to update the map:
- "I just learned that the CFO is actually very involved. Can we update that?"
- "Karen is more supportive than I thought. Let's change her sentiment."

### Regular Updates
Buying Committee maps are LIVING DOCUMENTS. Update after:
- Every new stakeholder interaction
- Any change in decision-making structure
- Political shifts (reorganizations, new hires, departures)

---

## Common Pitfalls

### Pitfall 1: Single-Threaded Relationship
**Symptom**: You only talk to one person who claims they'll "handle everything."

**Risk**: If that person leaves, gets sidelined, or loses political capital, your deal dies.

**Fix**: Insist on meeting other stakeholders. If blocked, consider it a red flag.

---

### Pitfall 2: No True Coach
**Symptom**: Everyone is polite and helpful, but no one gives you insider intelligence.

**Risk**: You're navigating blind. You'll be surprised by objections or political dynamics.

**Fix**: Actively cultivate a coach. Find someone with shared incentives.

---

### Pitfall 3: Mistaking Influencer for Economic Buyer
**Symptom**: You think your VP contact is the decision maker, but they need CFO approval.

**Risk**: After months of work, a new stakeholder (CFO) appears with concerns you've never addressed.

**Fix**: Always ask: "Who ELSE needs to approve this?" "Is there anyone above you who could veto?"

---

### Pitfall 4: Ignoring Users
**Symptom**: You sell to executives, but end users are never consulted.

**Risk**: Implementation fails because users resist or sabotage.

**Fix**: Involve users early. Make them feel heard.

---

## Integration with Other Workflows

### Buying Committee + MEDDPICC+RR
Use the Buying Committee map to score the **Economic Buyer** and **Champion** criteria in MEDDPICC+RR analysis.

### Buying Committee + Meeting Prep
When preparing for meetings, use the Buying Committee map to tailor messages to each stakeholder's role and motivations.

### Buying Committee + Negotiation
Use the Buying Committee map to understand power dynamics and who will be at the negotiation table.

---

## Getting Started

To begin mapping, tell me:
1. The company name and deal context
2. Who you've interacted with so far (names, titles)
3. What you know about the decision process

I'll guide you through building a complete, strategic Buying Committee map that turns stakeholder complexity into a competitive advantage.

**Ready to map your decision center? Let's identify who really controls this deal.**
