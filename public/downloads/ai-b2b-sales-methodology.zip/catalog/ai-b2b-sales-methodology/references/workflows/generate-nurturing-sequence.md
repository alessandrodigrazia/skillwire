# Workflow: Generate Nurturing Sequence

**Purpose**: Create a multi-touch email sequence to warm cold prospects or maintain engagement over time.

**Duration**: 20-30 minutes
**Output**: 5-7 email nurturing sequence with subject lines, body copy, and timing

---

## When to Use

- Converting cold leads to warm
- Maintaining engagement during long sales cycles
- Re-engaging dormant opportunities
- Building relationships with target accounts (Account-Based Marketing)

---

## The Process

### Step 1: Define Target & Context

**Questions I'll Ask**:
1. "Who is the target audience?" (title, industry, company size)
2. "What's the goal?" (book a meeting, download content, attend webinar)
3. "What's the relationship status?" (cold/never contacted, warm/engaged before, dormant/lost touch)
4. "How many touches?" (typically 5-7 emails over 2-4 weeks)
5. "Any specific pain points or value propositions to emphasize?"
6. "Tone preference?" (formal/professional, conversational, challenger/provocative)

### Step 2: Generate Email Sequence

#### Output Structure

```markdown
# Nurturing Sequence: [Target Audience]
## Goal: [Book Discovery Meeting]

**Audience**: CFOs at €100M+ insurance companies
**Sequence Length**: 6 emails over 3 weeks
**Tone**: Professional with Challenger insights

---

## EMAIL 1: Problem Awareness (Day 1)

**Subject**: The €8M problem hiding in your underwriting process

**Body**:
[First Name],

Most insurance CFOs I speak with don't realize that manual underwriting processes are costing them far more than the obvious labor costs.

Beyond the €2-3M in direct processing costs, there's the hidden cost of lost business: prospects who abandon applications because quotes take 8-10 days.

For a carrier writing 5,000 policies/year, that's typically €5M+ in lost premiums annually.

**Is this happening at [Company]?**

If you're curious how other insurers have solved this, I'd be happy to share what we've learned from 15+ implementations.

Best regards,
[Your Name]

**P.S.** - I'll send you a case study next week showing how one CFO turned this €8M problem into a €15M opportunity.

---

**Call-to-Action**: Soft (build awareness, no hard ask)
**Sending Time**: Tuesday 9 AM
**Follow-Up**: Email 2 in 3 days if no response

---

## EMAIL 2: Insight/Value (Day 4)

**Subject**: Case study: How [Insurance Company X] saved €2.7M in underwriting costs

**Body**:
[First Name],

Following up on my email about hidden underwriting costs.

I promised you a case study. Here it is:

**[Insurance Company X] Challenge**:
- 45 FTEs on manual underwriting
- 8-10 day quote turnaround
- 40% application abandonment rate
- €8.5M annual cost

**What They Did**:
- Implemented AI-powered underwriting decision engine
- Automated 70% of manual processes
- Reduced quote time to <24 hours

**Results** (Year 1):
- €2.7M labor cost savings (redeployed FTEs to growth initiatives)
- €5M revenue recovery (reduced abandonment)
- 643% ROI

**The full case study is here**: [Link]

If [Company]'s underwriting looks anything like theirs did, there's probably a similar opportunity.

Worth a 20-minute conversation?

Best regards,
[Your Name]

---

**Call-to-Action**: Medium (offer meeting, but not pushy)
**Sending Time**: Friday 10 AM
**Follow-Up**: Email 3 in 4 days if no response

---

## EMAIL 3: Challenger Reframe (Day 8)

**Subject**: Are you optimizing the wrong thing?

**Body**:
[First Name],

Most insurance CFOs focus on reducing underwriting **costs** (FTE efficiency, process optimization).

But here's a contrarian thought:

**What if the bigger opportunity isn't reducing costs, but increasing underwriting CAPACITY?**

Consider:
- Your underwriters can only process X policies/year
- That's a hard capacity constraint on revenue growth
- Hiring more underwriters is expensive and slow

But what if you could **triple capacity** without hiring?

That's what automation does. It's not just cost reduction—it's revenue acceleration.

**[Insurance Company Y]** took this approach:
- Tripled underwriting capacity (from 3K to 9K policies/year)
- Captured €30M in new business (without adding headcount)
- CFO told me: "I was optimizing for cost. I should have been optimizing for growth."

Are you optimizing for the right metric?

If this reframe resonates, let's talk.

Best regards,
[Your Name]

**P.S.** - This is how the fast-growing insurtechs are thinking. Just food for thought.

---

**Call-to-Action**: Stronger (challenge their thinking, prompt response)
**Sending Time**: Wednesday 2 PM
**Follow-Up**: Email 4 in 5 days if no response

---

## EMAIL 4: Breakup/Last Attempt (Day 13)

**Subject**: Should I close your file?

**Body**:
[First Name],

I've sent you a few emails about underwriting modernization, but I haven't heard back.

That's totally fine—I know you're busy, and this may not be a priority right now.

Before I close your file, I have one question:

**Is this not relevant, or just not the right time?**

- If it's **not relevant**: Please let me know, and I'll stop emailing you.
- If it's **not the right time**: When should I circle back? (Q2? Q4? Next year?)

Either way, I respect your time and don't want to clutter your inbox.

Just hit reply with "Not relevant" or "Reconnect in [timeframe]" and I'll act accordingly.

Best regards,
[Your Name]

---

**Call-to-Action**: Direct (breakup email to prompt response)
**Sending Time**: Monday 9 AM
**Follow-Up**: Email 5 in 7 days if no response OR if they say "reconnect later"

---

## EMAIL 5: Value Offer/Content (Day 20 - IF they said "not the right time")

**Subject**: [Free Resource] The CFO's Guide to Underwriting Modernization ROI

**Body**:
[First Name],

You mentioned that underwriting modernization isn't a priority right now, but might be in the future.

I thought you might find this useful when the time comes:

**"The CFO's Guide to Underwriting Modernization ROI"**
[Link to valuable content - whitepaper, calculator, framework]

It includes:
- ROI calculation framework
- TCO analysis template
- Vendor evaluation checklist
- Case studies from 3 insurers (with detailed financials)

No gates, no forms. Just value.

When you're ready to explore this, you know where to find me.

Best regards,
[Your Name]

---

**Call-to-Action**: Soft (provide value, stay top-of-mind)
**Sending Time**: Tuesday 10 AM
**Follow-Up**: None. Add to quarterly check-in cadence.

---

## EMAIL 6: Re-Engagement (Day 60 - Quarterly Check-In)

**Subject**: Quick question about [Company]'s 2024 priorities

**Body**:
[First Name],

It's been a couple months since we last connected.

I saw that [Company] [recent news: raised capital / announced growth target / appointed new CEO / expanded into new market].

Congrats!

Given that growth trajectory, I'm curious: Is modernizing underwriting on your roadmap for 2024?

If so, I'd love to reconnect. If not, no worries—I'll check in again next quarter.

Best regards,
[Your Name]

**P.S.** - We just helped [Competitor or Peer Company] reduce underwriting time from 10 days to 24 hours. Happy to share what we learned if it's relevant.

---

**Call-to-Action**: Soft (stay on radar, use news hook)
**Sending Time**: Any day, 10 AM
**Follow-Up**: Quarterly check-ins indefinitely

---

## SEQUENCE SUMMARY

| Email | Day | Subject | Goal | CTA Strength |
|---|---|---|---|---|
| 1 | 1 | The €8M problem... | Awareness | Soft |
| 2 | 4 | Case study | Credibility | Medium |
| 3 | 8 | Are you optimizing wrong? | Reframe | Strong |
| 4 | 13 | Should I close your file? | Breakup | Direct |
| 5 | 20 | Free resource | Value | Soft |
| 6 | 60 | 2024 priorities? | Re-engage | Soft |

---

## PERSONALIZATION VARIABLES

For each prospect, customize:
- [First Name]
- [Company]
- [Recent news/trigger event]
- [Specific pain point] (if known)
- [Competitor or Peer Company] (use relevant reference)

---

## SENDING CADENCE & RULES

**Timing**:
- Best open rates: Tues-Thurs, 9-11 AM or 2-3 PM
- Avoid Mondays (inbox overload) and Fridays (weekend mindset)

**Rules**:
- Stop immediately if they reply "not interested"
- Pause sequence if they engage (download content, visit website multiple times)
- Personalize each email before sending (don't batch-and-blast)

**Metrics to Track**:
- Open rate (target: >30%)
- Click rate (target: >5%)
- Reply rate (target: >3%)
- Meeting booked rate (target: >1%)
```

---

## Sequence Types

### Type 1: Cold Outbound (5-7 emails, 3 weeks)
Build awareness → credibility → reframe → breakup

### Type 2: Event Follow-Up (3-4 emails, 2 weeks)
Thank you → value/recap → CTA → last touch

### Type 3: Re-Engagement (3-4 emails, 2 weeks)
"It's been a while" → new value prop → soft ask

### Type 4: Long-Term Nurture (quarterly touches, indefinite)
Stay top-of-mind with valuable content

---

## Best Practices

1. **Personalize Beyond [First Name]**: Reference their company news, industry trends, specific pain points
2. **Provide Value in Every Email**: Don't just ask. Give insights, case studies, tools
3. **Vary Email Length**: Mix short (3 sentences) with longer (full case study)
4. **Use Challenger Insights**: Teach them something new about their business
5. **Track and Optimize**: A/B test subject lines, measure open/reply rates

---

## Getting Started

Tell me:
1. Target audience (title, industry)
2. Goal (meeting, content download, event registration)
3. Relationship status (cold, warm, dormant)
4. Key value propositions or pain points
5. Tone preference

I'll generate a custom nurturing sequence tailored to your audience.

**Ready? Let's warm up those cold prospects.**
