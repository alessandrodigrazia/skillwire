# Workflow: Qualify Opportunity (MEDDPICC+RR Analysis)

**Purpose**: Rigorously evaluate an opportunity using the 10-criteria MEDDPICC+RR framework to decide GO/NO-GO.

**Duration**: 20-30 minutes
**Output**: Complete MEDDPICC+RR analysis with scores, evidence, recommendations, and strategic decision

---

## When to Use This Workflow

Use MEDDPICC+RR analysis when:
- You have a new opportunity and need to decide whether to invest resources
- You're in the early stages of an opportunity (post-discovery, pre-proposal)
- Management asks "How qualified is this deal?"
- You need to justify resource allocation (presales, solution architects, etc.)
- A deal feels "off" but you can't articulate why

**Critical Timing**: MEDDPICC+RR should be done AFTER initial discovery but BEFORE significant investment in proposals or custom work.

---

## What Is MEDDPICC+RR?

**MEDDPICC** is a proven enterprise sales qualification framework originally developed by Jack Napoli and Dick Dunkel at PTC Corporation. The **+RR** extension adds Risks and Roadblocks for a more comprehensive assessment.

### The 10 Criteria

1. **Metrics**: What measurable outcomes does the customer expect?
2. **Economic Buyer**: Who has the authority and budget to approve this deal?
3. **Decision Criteria**: What factors will they use to evaluate solutions?
4. **Decision Process**: What steps and approvals are required to make a decision?
5. **Paper Process**: What legal, procurement, and administrative steps are needed to close?
6. **Identify Pain**: What critical business pain is driving this initiative?
7. **Champion**: Do we have an internal advocate with power and influence?
8. **Competition**: Who else is being evaluated and what is our differentiation?
9. **Risks**: What internal or external risks could derail this opportunity?
10. **Roadblocks**: What organizational, political, or technical obstacles exist?

---

## The MEDDPICC+RR Process

### Overview

```
Information Gathering
    |
Criterion-by-Criterion Evaluation (1-5 score + evidence)
    |
Overall Score Calculation
    |
Go/No-Go Recommendation
    |
Action Plan for Weak Criteria
```

---

## Step 1: Context Gathering

Before we evaluate the 10 criteria, I need to understand the opportunity context.

### Questions I'll Ask

**Opportunity Basics**:
- "What is the prospect company name and industry?"
- "What solution/service are you proposing?"
- "What is the estimated deal size?"
- "How did this opportunity originate?" (inbound, outbound, referral)

**Current Status**:
- "How many interactions have you had with them?"
- "Who have you spoken with so far?" (names, titles)
- "What materials have you shared?" (proposals, presentations, etc.)

**Background Context**:
- "Do you have any documents to share?" (meeting notes, emails, RFPs)
- "What do you know about their current situation and problems?"

---

## Step 2: Criterion-by-Criterion Evaluation

For each of the 10 criteria, I will:
1. Explain what the criterion measures
2. Ask you targeted questions to gather evidence
3. Assign a score (1-5) based on your responses
4. Document the evidence that supports the score
5. Provide a recommendation for improvement (if score < 4)

Let's walk through each criterion:

---

### Criterion 1: METRICS

**What It Measures**: What quantifiable business outcomes does the customer expect from this initiative?

**Why It Matters**: Without clear metrics, the customer cannot justify the investment, and you cannot build a compelling business case. Metrics create urgency and measurable accountability.

#### Questions I'll Ask You

1. "Has the customer articulated specific, measurable outcomes they expect?" (revenue increase, cost reduction, time savings, etc.)
2. "Have you quantified the impact of their current pain?" (cost of inaction, lost revenue, operational waste)
3. "Are there KPIs or success criteria already defined for this initiative?"
4. "Have you co-developed a business case or ROI analysis with them?"
5. "Can you tie your solution directly to their stated metrics?"

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | Clear, quantified metrics co-developed with customer. Business case validated. | Joint ROI analysis. Customer agrees on specific numbers (e.g., "€2M savings in Year 1"). Metrics tied to executive objectives. |
| **4** | Metrics discussed and broadly agreed. Some quantification done. | Customer mentioned specific outcomes. You've estimated ROI. Not yet formally validated. |
| **3** | General outcomes discussed. No specific quantification. | "They want to reduce costs" but no numbers. Vague success criteria. |
| **2** | Customer hasn't articulated expected outcomes. You're guessing. | You're projecting benefits based on similar customers. No customer validation. |
| **1** | No metrics discussed. No understanding of expected outcomes. | "We haven't talked about ROI." No business case. No quantification. |

#### Example Output

```markdown
## Criterion 1: METRICS
**Score**: 4/5

**Evidence**:
- Customer expects 40% reduction in underwriting processing time (currently 12 days avg)
- CIO mentioned target of €2M annual savings from process automation
- ROI model drafted showing 14-month payback period
- Not yet formally validated with CFO

**Rationale**:
Strong metrics with clear quantification. The CIO has articulated specific outcomes. However, CFO has not yet validated the business case numbers. Score of 4 reflects strong but unvalidated metrics.

**Recommendation**:
Schedule a meeting with CFO to validate the business case. Ask CIO: "Has the CFO seen these projected savings? Would a formal ROI presentation help?"
```

---

### Criterion 2: ECONOMIC BUYER

**What It Measures**: Have you identified and engaged the person with the authority and budget to approve this purchase?

**Why It Matters**: If you're not engaged with the Economic Buyer, someone else is influencing the decision without your input. Deals stall or die when the EB is absent.

#### Questions I'll Ask You

1. "Who has the final authority to approve this purchase and sign the contract?"
2. "Have you met with this person directly?"
3. "Do they understand the value proposition and support this initiative?"
4. "What is their decision-making style?" (data-driven, consensus-builder, gut-feel)
5. "Can your champion get you access to the Economic Buyer?"

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | Economic Buyer identified, engaged, and supportive. Direct relationship. | You've met the EB multiple times. They understand your value. They've indicated support. |
| **4** | Economic Buyer identified. Limited direct engagement. Indirectly supportive. | You know who the EB is. You've met once or your champion confirms their support. |
| **3** | Economic Buyer identified but not engaged. No direct access. | You know the name and title but haven't met. Your contact says "they'll approve if we recommend." |
| **2** | Economic Buyer unclear. Multiple candidates. No access. | "It could be the CIO or the CFO." No one will confirm. You can't get a meeting. |
| **1** | No idea who the Economic Buyer is. Blocked from finding out. | "We're working with procurement only." No visibility into decision authority. |

---

### Criterion 3: DECISION CRITERIA

**What It Measures**: What factors (technical, commercial, strategic) will the customer use to evaluate and compare solutions?

**Why It Matters**: If you don't know the criteria, you can't influence them. If the criteria favor a competitor, you need to reshape them.

#### Questions I'll Ask You

1. "Do you know what criteria they're using to evaluate solutions?" (price, features, references, timeline, risk)
2. "Are these criteria documented?" (RFP, evaluation matrix, scorecard)
3. "Have you helped shape these criteria?" (influenced what's important)
4. "Do the criteria favor us, a competitor, or are they neutral?"
5. "Are there unstated criteria?" (political preferences, incumbent bias, personal relationships)

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | Decision criteria known, documented, and favorable to us. We helped define them. | Formal evaluation matrix. Our strengths align with their top criteria. We influenced what matters. |
| **4** | Decision criteria known. Mostly favorable. Some gaps to address. | Customer shared their priorities. We match well on 70%+ of criteria. Minor adjustments needed. |
| **3** | Some criteria known. Unclear if favorable. Limited influence. | Customer mentioned some factors. No formal matrix. We're guessing on relative weighting. |
| **2** | Decision criteria vague or unknown. No influence. | "We don't know what they're comparing." Customer won't share evaluation approach. |
| **1** | No visibility into decision criteria. Completely blind. | "They said they'd let us know." No transparency. No ability to influence. |

---

### Criterion 4: DECISION PROCESS

**What It Measures**: What are the steps, approvals, and timeline required for them to make a decision?

**Why It Matters**: Deals stall when you don't understand the internal approval process. Knowing the process lets you anticipate delays and prepare for each stage.

#### Questions I'll Ask You

1. "Do you know their evaluation and approval process step by step?" (demo, POC, committee review, board approval, etc.)
2. "What approvals are required and from whom?"
3. "What is their expected timeline from evaluation to decision?"
4. "Have they shared the process explicitly, or are you inferring?"
5. "Are there any unusual steps?" (legal review, union approval, government clearance)

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | Full decision process mapped with dates, stages, and owners. Confirmed by customer. | Step-by-step process documented. Each stage has a date. Customer committed to the process. |
| **4** | Decision process mostly understood. Timeline estimated. Some gaps. | You know the key stages and approximate dates. A few internal steps are unclear. |
| **3** | General understanding of the process. No detailed timeline. | "They'll do an internal review, then go to the board." No specific dates. |
| **2** | Vague process. Customer hasn't shared details. | "They said they'll get back to us." No visibility into internal steps. |
| **1** | No understanding of the decision process. | "We have no idea how or when they'll decide." Completely opaque. |

---

### Criterion 5: PAPER PROCESS

**What It Measures**: What legal, procurement, and administrative steps are required to get the contract signed and executed?

**Why It Matters**: Many deals die in "legal review" or "procurement." Understanding the paper process prevents last-minute surprises and delays.

#### Questions I'll Ask You

1. "Do you know their procurement and legal process for contracts of this size?"
2. "Who needs to sign the contract?" (names, titles)
3. "Are there standard contract terms they insist on?" (payment terms, liability caps, etc.)
4. "Is there a legal review process? How long does it typically take?"
5. "Are there any procurement hurdles?" (preferred vendor list, competitive bidding requirements, etc.)

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | Paper process fully mapped. Legal/procurement engaged. No surprises expected. | You know exactly what happens after the verbal "yes." Legal terms pre-negotiated. Timeline confirmed. |
| **4** | Paper process mostly understood. Some details to clarify. | You know procurement is involved. Estimated 2-4 weeks for legal. Some terms to negotiate. |
| **3** | General awareness of paper process. Limited details. | "They have a standard procurement process." You don't know specifics or timeline. |
| **2** | Paper process unknown. Haven't discussed it. | You haven't asked about contract logistics. Potential for surprises. |
| **1** | No idea about paper process. Could be months of delays. | "We've never discussed how they actually buy." Complete blind spot. |

---

### Criterion 6: IDENTIFY PAIN

**What It Measures**: Have you identified and validated the critical business pain driving this initiative?

**Why It Matters**: Pain creates urgency. Without validated pain, initiatives get deprioritized. The stronger and more personal the pain, the more likely the deal closes.

#### Questions I'll Ask You

1. "What is the primary business pain driving this initiative?"
2. "Who personally feels this pain?" (the individual, their team, the organization)
3. "How long has this pain existed? Why hasn't it been solved before?"
4. "What happens if they don't address it?" (cost of inaction)
5. "Is the pain connected to a strategic priority of the CEO or board?"

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | Critical business pain identified, validated, and quantified. Felt at C-level. | CEO/C-level articulated the pain directly. Cost of inaction quantified. Pain connected to strategic priorities. Regulatory or competitive urgency. |
| **4** | Clear pain identified and validated. Felt at VP level. Some quantification. | VP-level sponsor feels the pain. Business drivers clear. Not yet connected to board-level priorities. |
| **3** | Pain discussed but not deeply validated or quantified. | "They mentioned some challenges." No quantification. Mid-management pain. |
| **2** | Pain inferred by you, not articulated by customer. | You're extrapolating from industry trends. Customer hasn't confirmed. |
| **1** | No pain identified. Exploratory or "nice to have." | "They're just looking." No urgency. No pain articulated. |

#### Example Output

```markdown
## Criterion 6: IDENTIFY PAIN
**Score**: 4/5

**Evidence**:
- CIO stated: "Our legacy systems are costing us €8.5M/year in operational inefficiency"
- Regulatory deadline (compliance required by Q4) creates external pressure
- CEO publicly announced "digital transformation" as top priority in earnings call
- No direct CEO engagement yet on specific pain points

**Rationale**:
Strong, validated pain at C-level. The regulatory driver creates a hard deadline and the CEO has publicly committed to transformation. However, we haven't heard the CEO articulate this specific pain directly. Score of 4 reflects strong but not perfect pain validation.

**Recommendation**:
Request a brief meeting with CEO to validate strategic alignment. Ask CIO: "How would the CEO react if this initiative slipped by 6 months?"
```

---

### Criterion 7: CHAMPION

**What It Measures**: Do you have an internal advocate who has power, influence, and a personal stake in your success?

**Why It Matters**: A Champion sells for you when you're not in the room. Without one, you're navigating politics blind and have no internal advocate.

#### Questions I'll Ask You

1. "Is there someone inside the customer organization who is actively advocating for your solution?"
2. "Do they have power and influence in the organization?" (can they affect the decision?)
3. "Do they have a personal win if you succeed?" (promotion, recognition, solving their problem)
4. "Do they provide insider intelligence?" (competitive info, internal politics, decision dynamics)
5. "Have they been tested?" (Did they deliver on something they promised?)

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | Strong Champion with power, influence, and personal stake. Tested and reliable. | They've warned you about obstacles. They advocate in internal meetings. They have the ear of the Economic Buyer. They've delivered on commitments. |
| **4** | Solid Champion. Helpful and influential, but not fully tested. | They're sharing useful information. They want you to win. They have some influence but haven't been tested in a critical moment. |
| **3** | Friendly contact willing to help, but not a true Champion. | They answer your questions and are positive, but don't proactively guide you or share insider intelligence. Limited influence. |
| **2** | Weak or unreliable contact. No real advocacy. | They're neutral. No personal stake. Transactional relationship. |
| **1** | No Champion. Everyone is neutral or hostile. | You have no allies. All contacts are gatekeepers or skeptics. |

---

### Criterion 8: COMPETITION

**What It Measures**: Are we aware of the competition (including status quo), and do we have a strategy to win?

**Why It Matters**: If you don't know who you're competing against, you can't position effectively. The status quo ("do nothing") is often the strongest competitor.

#### Questions I'll Ask You

1. "Who else is being evaluated?" (competitor names, including "do nothing")
2. "Do you know how they're positioning themselves?"
3. "What are our differentiators vs each competitor?"
4. "Have you built a competitive strategy?"
5. "Is there an incumbent? If so, what's the switching cost?"

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | Full competitive intel. Clear differentiation. Winning strategy. | You know all competitors. You have battlecards. Customer sees your unique value. Status quo cost quantified. |
| **4** | Know main competitors. Solid differentiation. Strategy in progress. | 2-3 competitors identified. You have differentiators. Competitive strategy drafted. |
| **3** | Some competitor awareness. Differentiation unclear. | You know 1-2 competitors. Differentiation is weak or generic ("better service"). |
| **2** | Vague competitor awareness. No strategy. | Customer mentioned "evaluating others." You don't know who. No differentiation. |
| **1** | No competitive intel. Blind. | You have no idea who else is in the mix. Customer won't tell you. |

---

### Criterion 9: RISKS

**What It Measures**: What internal or external risks could derail or delay this opportunity?

**Why It Matters**: Unidentified risks blindside you. Proactively identifying risks allows you to mitigate them before they become deal-killers.

#### Questions I'll Ask You

1. "What could go wrong with this deal?" (internal and external factors)
2. "Are there organizational changes happening?" (restructuring, M&A, leadership changes)
3. "Are there budget risks?" (funding cuts, fiscal year changes, reprioritization)
4. "Are there timing risks?" (competing initiatives, resource constraints, holiday slowdowns)
5. "What's the worst-case scenario, and how likely is it?"

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | All major risks identified and mitigated. Contingency plans in place. | You've proactively addressed risks. Customer has confirmed no major blockers. Mitigation strategies active. |
| **4** | Key risks identified. Some mitigation in progress. | You know the top 2-3 risks. Working on mitigation. No immediate threats. |
| **3** | Some risks identified but not addressed. | You're aware of potential issues but haven't taken action. "We'll cross that bridge when we get there." |
| **2** | Risks not systematically assessed. Hoping for the best. | You haven't thought about what could go wrong. Reactive posture. |
| **1** | Unaware of risks. Significant blind spots. | "What could go wrong?" Major lurking risks you haven't considered. |

---

### Criterion 10: ROADBLOCKS

**What It Measures**: What organizational, political, or technical obstacles stand between you and a closed deal?

**Why It Matters**: Roadblocks are different from risks. They are known obstacles that must be actively removed. Ignoring roadblocks guarantees deal stalls.

#### Questions I'll Ask You

1. "Are there specific people who oppose this initiative?" (skeptics, competitors' allies, change resistors)
2. "Are there technical obstacles?" (integration challenges, legacy systems, security requirements)
3. "Are there political dynamics at play?" (internal rivalries, turf wars, competing projects)
4. "Are there contractual obstacles?" (existing vendor contracts, exclusivity agreements)
5. "What would prevent this deal from closing even if everyone wanted it to?"

#### Scoring Guide

| Score | Definition | Indicators |
|---|---|---|
| **5** | No significant roadblocks. Clear path to close. All obstacles removed. | You've addressed every known obstacle. Stakeholders are aligned. No blockers remain. |
| **4** | Minor roadblocks identified. Manageable with effort. Clear plan to remove. | 1-2 small obstacles. You know how to address them. Executing removal plan. |
| **3** | Moderate roadblocks. Unclear path to removal. | Known obstacles but no clear plan. "We need to figure out how to handle [X]." |
| **2** | Significant roadblocks. No removal strategy. | Major obstacles that could kill the deal. No plan to address them. High uncertainty. |
| **1** | Critical roadblocks. Deal may be impossible. | Insurmountable obstacles (legal prohibitions, incompatible technology, hostile stakeholder with veto power). |

---

## Step 3: Score Calculation and Interpretation

After evaluating all 10 criteria, I will calculate:

### Overall MEDDPICC+RR Score
```
Score = (Sum of 10 scores) / 10
```

### Interpretation

| Score Range | Recommendation | Action |
|---|---|---|
| **4.0 - 5.0** | **GO** | High-quality opportunity. Invest resources confidently. Forecast with high probability. |
| **3.0 - 3.9** | **GO WITH CONDITIONS** | Qualified but risky. Address weak criteria before significant investment. Conditional forecast. |
| **2.0 - 2.9** | **NO-GO or NURTURE** | Low probability. Disqualify or move to long-term nurturing. Do not invest presales resources. |
| **< 2.0** | **DISQUALIFY** | Walk away. Probability of win is <10%. Invest time elsewhere. |

### Red Flag Rule

**If ANY single criterion scores 1, it's a critical red flag.** Even if the overall score is decent, investigate that criterion deeply before proceeding.

---

## Step 4: Strategic Recommendations

For each criterion with a score < 4, I will provide:

### Action Plan
Specific, tactical actions to improve that criterion.

### Owner
Who should do it (you, your manager, presales, executive sponsor).

### Timeline
When it should be done (before next meeting, within 2 weeks, etc.).

### Success Criteria
How you'll know it's improved.

### Example Output

```markdown
## Action Plan for Weak Criteria

### Criterion 6: Identify Pain (Score: 3/5)
**Gap**: Pain discussed but not quantified. No C-level validation.

**Actions**:
1. Request a 30-min meeting with CEO or CFO via CIO sponsor
2. Prepare a 1-page executive brief showing cost of inaction
3. Ask CIO: "If this initiative slipped 6 months, how would the CEO react?"

**Owner**: Account Executive (you) + Sales Director (exec sponsor if needed)
**Timeline**: Within 2 weeks
**Success Criteria**: Direct confirmation from C-level that this is a priority OR explicit urgency driver identified (regulatory deadline, competitive threat, etc.)

---

### Criterion 2: Economic Buyer (Score: 2/5)
**Gap**: Economic Buyer identified but not engaged. No direct access.

**Actions**:
1. Ask Champion: "Can you arrange a meeting with [Economic Buyer name]?"
2. Prepare an executive-level value proposition (not a product pitch)
3. If blocked, consider this a red flag and reassess opportunity

**Owner**: Account Executive
**Timeline**: Next meeting (urgent)
**Success Criteria**: Direct meeting with Economic Buyer scheduled and confirmed. Understanding of their priorities and decision-making style.
```

---

## Step 5: Go/No-Go Decision

Based on the overall score and red flags, I will provide a clear recommendation:

### Example Output

```markdown
# MEDDPICC+RR Analysis: [Company Name] - [Solution Name]
**Date**: [Today's Date]
**Analyst**: [Your Name]
**Overall Score**: 3.5 / 5.0

---

## RECOMMENDATION: **GO WITH CONDITIONS**

### Summary
This opportunity shows **moderate qualification**. There are strong elements (pain, solution fit, metrics), but critical weaknesses in Economic Buyer access and competitive strategy.

### Strengths (Scores 4-5)
- Metrics (4/5): ROI quantified at €2M annual savings, 14-month payback
- Identify Pain (5/5): C-level pain validated with regulatory urgency
- Champion (4/5): CIO is strong advocate with influence and personal stake
- Decision Process (4/5): Clear evaluation process with timeline

### Weaknesses (Scores 1-3)
- Economic Buyer (2/5): CFO identified but not engaged; no direct access
- Competition (3/5): Vague competitive intel; no battlecard strategy
- Roadblocks (2/5): Incumbent vendor has 3-year contract expiring in 6 months; unclear exit process

### Red Flags
- **Critical**: Blocked from Economic Buyer (CFO). If we can't access the CFO within 2 weeks, recommend NO-GO.

### Conditions for GO
1. Gain direct access to CFO through Champion (CIO)
2. Identify the main competitor(s) and build battlecards
3. Clarify incumbent contract exit process and timeline

### Forecast Guidance
- **If conditions met**: 60% win probability, forecast for Q1
- **If conditions NOT met**: 20% win probability, remove from forecast

### Next Steps
1. [Week 1] Request CFO meeting through CIO (Champion)
2. [Week 1] Conduct competitive research (LinkedIn, customer intel)
3. [Week 2] Validate Economic Buyer access or escalate to Sales Director
4. [Week 3] Re-run MEDDPICC+RR to confirm improvement

---

## Detailed Scoring

| # | Criterion | Score | Evidence | Recommendation |
|---|---|---|---|---|
| 1 | Metrics | 4/5 | ROI quantified, 14-month payback | Validate with CFO |
| 2 | Economic Buyer | 2/5 | CFO identified, no access | **URGENT: Get CFO meeting** |
| 3 | Decision Criteria | 3/5 | Some criteria known, not documented | Request evaluation matrix |
| 4 | Decision Process | 4/5 | Process mapped, timeline confirmed | Monitor for changes |
| 5 | Paper Process | 3/5 | Procurement involved, timeline unknown | Clarify legal/procurement steps |
| 6 | Identify Pain | 5/5 | C-level pain, regulatory deadline | No action needed |
| 7 | Champion | 4/5 | CIO advocating, tested once | Continue cultivating |
| 8 | Competition | 3/5 | Vague intel, no strategy | Build competitive strategy |
| 9 | Risks | 3/5 | Budget reallocation risk identified | Develop mitigation plan |
| 10 | Roadblocks | 2/5 | Incumbent contract, no exit plan | **URGENT: Clarify exit process** |

**OVERALL SCORE: 3.5 / 5.0**
```

---

## How to Use MEDDPICC+RR Results

### With Your Manager
- Use MEDDPICC+RR score to justify resource requests
- Show action plan to demonstrate proactivity
- Discuss whether to GO or NO-GO

### With Your Team
- Share analysis with presales/solution architects before investing their time
- Use it to prioritize which opportunities get attention

### With Yourself
- Honest self-assessment tool
- Prevents "happy ears" syndrome (seeing only what you want to see)
- Forces evidence-based decision making

### In CRM
- Log MEDDPICC+RR score as a custom field
- Track over time (did score improve as you took actions?)
- Correlate scores with win rates (validate the methodology)

---

## Updating MEDDPICC+RR Over Time

MEDDPICC+RR is not a one-time analysis. **Update it regularly**:

- **After significant milestones** (new meeting, proposal submitted, competitor identified)
- **If the deal stalls** (re-run analysis to diagnose why)
- **Before major investments** (custom demo, free POC, executive travel)

**Trend is as important as absolute score**: A deal improving from 2.5 to 3.5 is healthy. A deal declining from 4.0 to 3.0 is a red flag.

---

## Common Pitfalls to Avoid

1. **Wishful Scoring**: Don't inflate scores because you want the deal. Be brutally honest.
2. **Ignoring Red Flags**: A single "1" score can kill a deal, even if the overall is decent.
3. **Static Analysis**: MEDDPICC+RR is dynamic. Update it as information changes.
4. **Lone Wolf**: Don't do the analysis alone. Get a second opinion (manager, peer) for objectivity.

---

## Ready to Qualify Your Opportunity?

To begin, tell me:
1. The prospect company name
2. The solution/service you're proposing
3. How far along you are (just started, multiple meetings, proposal stage, etc.)

I'll guide you through the 10 criteria, one at a time, asking targeted questions to gather the evidence needed for a rigorous, objective MEDDPICC+RR analysis.

**Let's find out if this deal is worth chasing.**
