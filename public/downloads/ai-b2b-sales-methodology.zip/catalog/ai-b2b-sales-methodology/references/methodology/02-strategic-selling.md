# Module 2: Strategic Selling - The 7-Phase Enterprise Sales Process

## Table of Contents

1. [Introduction](#introduction)
2. [The 7 Phases of the Strategic Sales Process](#the-7-phases-of-the-strategic-sales-process)
   - [Phase 1: Identification](#phase-1-identification)
   - [Phase 2: Qualification (MEDDPICC+RR)](#phase-2-qualification-meddpiccrr)
   - [Phase 3: Buying Committee Mapping](#phase-3-buying-committee-mapping)
   - [Phase 4: Competitive Strategy](#phase-4-competitive-strategy)
   - [Phase 5: Proposal](#phase-5-proposal)
   - [Phase 6: Decision](#phase-6-decision)
   - [Phase 7: Implementation & Reference Creation](#phase-7-implementation--reference-creation)
3. [Key Tools](#key-tools)
   - [MEDDPICC+RR (10 Criteria)](#meddpiccrr-qualification-framework)
   - [Buying Committee Map](#buying-committee-map)
   - [Competitive Strategies](#5-competitive-strategies)
4. [Metrics and Checkpoints](#metrics-and-checkpoints)
5. [Conclusion](#conclusion)

---

## Introduction

**Strategic Selling** is the framework for navigating complex B2B opportunities that involve:
- Long sales cycles (3-18 months)
- High deal sizes ($100K+)
- Multi-functional buying committees
- Complex decision processes
- Intense competition
- High risk of "no-decision"

The **7-phase process** provides a clear roadmap from identification to close, with rigorous qualification checkpoints and strategic tools at every phase.

---

## The 7 Phases of the Strategic Sales Process

### Process Overview

```
PHASE 1: Identification
   |
PHASE 2: Qualification (MEDDPICC+RR)
   |
PHASE 3: Buying Committee Mapping
   |
PHASE 4: Competitive Strategy
   |
PHASE 5: Proposal
   |
PHASE 6: Decision
   |
PHASE 7: Implementation & Reference Creation
```

**Core Principle**: Every phase has specific **exit criteria**. Do not advance to the next phase without meeting these criteria. It is better to disqualify early than to invest resources on opportunities you cannot win.

---

## Phase 1: Identification

### Objective
Recognize potential opportunities that merit an investment of resources.

### Key Activities

1. **Lead Generation and Prospecting**
   - Inbound: Marketing leads, referrals, events
   - Outbound: Account-based prospecting, nurturing sequences
   - Signal detection: Trigger events (funding, M&A, new executive hires, strategic initiatives)

2. **Rapid Initial Qualification** (Quick Go/No-Go)
   - Is this a target company (industry, size, geography)?
   - Is there potential budget?
   - Is there a problem we know how to solve?
   - Can we access the buying committee?

3. **First Contact Strategy**
   - Identify the entry point (warm intro vs. cold outreach)
   - Prepare initial value proposition
   - Goal: Secure the first discovery meeting

### Phase Output
- **Opportunity created in CRM** with baseline data
- **First meeting scheduled** (or nurturing sequence activated)
- **Initial research brief** on the prospect

### Exit Criteria (Gate 1)
- [ ] We have access to a relevant contact (minimum Director level)
- [ ] There is evidence of a business problem in our sweet spot
- [ ] There are no obvious red flags (company in crisis, outside target profile, etc.)

**If criteria are not met**: Disqualify or place into long-term nurturing.

---

## Phase 2: Qualification (MEDDPICC+RR)

### Objective
Assess the strength of the opportunity across 10 critical dimensions to decide whether to invest significant resources.

### The MEDDPICC+RR Qualification Framework

MEDDPICC+RR is the core of strategic qualification. It evaluates the opportunity on a 1-5 scale across **10 criteria**, providing a rigorous, evidence-based view of deal health.

#### The 10 MEDDPICC+RR Criteria

**1. METRICS (M) -- Quantified Business Impact**
- **Key Question**: Has the prospect quantified the business impact of solving this problem?
- **Score 5**: Clear, prospect-validated metrics tied to revenue, cost, or risk (e.g., "$2M annual savings", "30% faster time-to-market")
- **Score 3**: General awareness of impact, but no hard numbers validated by the prospect
- **Score 1**: No quantified impact; the initiative is a "nice to have" with no measurable urgency
- **How to Assess**: Ask: "What happens to the business if you solve this? What happens if you don't?" Look for hard numbers, board-level KPIs, or P&L impact

**2. ECONOMIC BUYER (E) -- Person with Budget Authority**
- **Key Question**: Have we identified and engaged the person who can approve the budget and sign the deal?
- **Score 5**: We have met with the Economic Buyer; they are engaged, understand the value, and have confirmed budget availability
- **Score 3**: We know who the Economic Buyer is, but we have not had direct access or meaningful engagement
- **Score 1**: We do not know who holds final budget authority, or we are blocked from reaching them
- **How to Assess**: Ask: "Who signs contracts of this size in your organization?" Confirm through your Champion

**3. DECISION CRITERIA (D) -- How They Evaluate Options**
- **Key Question**: Do we know the formal and informal criteria the prospect will use to choose a vendor?
- **Score 5**: Decision criteria are documented, and we have influenced them to favor our strengths
- **Score 3**: We have a general understanding of what matters, but criteria are not formalized or we haven't shaped them
- **Score 1**: We are guessing what the prospect values; no visibility into evaluation criteria
- **How to Assess**: Ask: "What are the top 3 things you'll evaluate vendors on?" Review any RFP/RFI requirements. Use discovery insights from the tactical selling framework (Module 1)

**4. DECISION PROCESS (D) -- Steps and Timeline to Decision**
- **Key Question**: Do we understand every step between now and a signed contract, including who is involved at each stage?
- **Score 5**: We have a documented, prospect-validated decision process with timeline, stages, and stakeholders at each gate
- **Score 3**: We know some steps (e.g., "board approval needed"), but the full process is unclear
- **Score 1**: We have no visibility into how or when the decision will be made
- **How to Assess**: Ask: "Walk me through what happens after you decide you want to move forward. Who approves what, and in what order?"

**5. PAPER PROCESS (P) -- Procurement, Legal, Contracts**
- **Key Question**: Do we understand the procurement, legal, and contract review process, and have we started navigating it?
- **Score 5**: We know the procurement steps, have engaged legal early, and contract terms are pre-aligned or in redline
- **Score 3**: We know procurement is involved, but have not engaged them or reviewed contract templates
- **Score 1**: No visibility into procurement requirements; we will discover blockers late in the cycle
- **How to Assess**: Ask: "What does your procurement process look like for a purchase of this size? Are there standard terms we should review early?"

**6. IDENTIFY PAIN (I) -- Explicit Business Pain**
- **Key Question**: Has the prospect explicitly acknowledged a business pain that our solution addresses, and is it urgent enough to drive action?
- **Score 5**: The pain is explicit, quantified, and felt at the C-level. There is a compelling event or deadline driving urgency
- **Score 3**: Pain is acknowledged at the operational level, but it is not clear whether leadership sees it as a priority
- **Score 1**: No explicit pain identified; we are pushing a solution onto a prospect who does not feel a problem
- **How to Assess**: Use discovery from the 4-phase conversation framework (Module 1). Look for compelling events: regulatory deadlines, competitive threats, board mandates, contract expirations

**7. CHAMPION (C) -- Internal Advocate**
- **Key Question**: Do we have a strong internal Champion who actively sells on our behalf inside the organization?
- **Score 5**: We have a Champion with power, influence, and personal motivation to see our solution win. They proactively share intelligence and coach us
- **Score 3**: We have a friendly contact who is cooperative but does not actively advocate or does not have sufficient influence
- **Score 1**: No internal ally; all contacts are neutral or hostile
- **How to Assess**: A true Champion passes three tests: (1) they have something personal to gain from our success, (2) they have access to the Economic Buyer, (3) they tell us things others won't

**8. COMPETITION (C) -- Who Else Is Competing**
- **Key Question**: Do we know who we are competing against (including the status quo and "do nothing"), and do we have a strategy to win?
- **Score 5**: We know every competitor in play, have a clear differentiator, and have a competitive strategy defined
- **Score 3**: We know who the competitors are, but we have not yet developed a counter-strategy
- **Score 1**: We do not know who we are facing, or we have no way to differentiate
- **How to Assess**: Conduct competitive intelligence. Ask your Champion: "Who else are you evaluating?" Remember: the status quo is always a competitor

**9. RISKS (+R) -- Implementation and Adoption Risks**
- **Key Question**: Have we identified and mitigated the risks that could derail implementation or prevent the prospect from realizing value?
- **Score 5**: We have mapped all major risks (technical, organizational, change management) and have a documented mitigation plan shared with the prospect
- **Score 3**: We are aware of some risks, but have not formally addressed them with the prospect
- **Score 1**: We have not assessed implementation risks; we are assuming everything will go smoothly
- **How to Assess**: Ask: "What could go wrong during implementation? What has failed in past projects like this?" Consider technical integration complexity, data migration, change management readiness, and resource availability

**10. ROADBLOCKS (+R) -- Internal Obstacles to Buying**
- **Key Question**: Are there internal political, organizational, or procedural obstacles that could prevent the deal from closing, and do we have a plan to address them?
- **Score 5**: We have identified all internal roadblocks (competing priorities, political opposition, budget freezes) and have a strategy to navigate each one
- **Score 3**: We suspect there are internal obstacles, but lack concrete intelligence about what they are
- **Score 1**: We are blind to internal dynamics; we may be surprised by a "no-decision" or sudden stall
- **How to Assess**: Ask your Champion: "Is there anything inside the organization that could slow this down or stop it?" Watch for signals: reorganizations, competing initiatives, leadership changes, budget cycles

### Calculating the MEDDPICC+RR Score

```
MEDDPICC+RR Score = (Sum of 10 scores) / 10

Interpretation:
- 4.0 - 5.0 = GO (High-probability opportunity)
- 3.0 - 3.9 = GO WITH CONDITIONS (Requires corrective actions on weak criteria)
- 2.0 - 2.9 = CAUTION (Significant gaps; do not advance without improvement plan)
- 1.0 - 1.9 = NO-GO (Disqualify or place in nurturing)
```

### MEDDPICC+RR Assessment Process

1. **Data Collection**: Use insights from discovery (the 4-phase conversation framework -- Module 1)
2. **Individual Scoring**: Assign a score of 1-5 for each criterion
3. **Evidence-Based**: For every score, document the concrete EVIDENCE supporting it
4. **Action Plan per Criterion**: For any criterion scoring below 4, define specific corrective actions
5. **Go/No-Go Decision**: Calculate the average score and decide

### Phase Output
- **MEDDPICC+RR Analysis Document** including:
  - Score for each criterion with supporting evidence
  - Overall MEDDPICC+RR Score
  - Go/No-Go recommendation
  - Action plan to improve weak criteria
  - Forecast close probability

### Exit Criteria (Gate 2)
- [ ] MEDDPICC+RR Score >= 3.0 (minimum to proceed)
- [ ] No criterion has a score of 1 (a single "1" is a critical red flag)
- [ ] We have a clear plan to bring criteria below 4 to acceptable levels
- [ ] Management has approved the resource investment (if deal size warrants it)

**If criteria are not met**: NO-GO. Disqualify with dignity or place in nurturing until conditions change.

---

## Phase 3: Buying Committee Mapping

### Objective
Identify and map ALL stakeholders who influence or decide the purchase, understand their roles, motivations, and level of support.

### The Buying Committee Model

Every complex opportunity involves 5 archetypes of buying roles. A SINGLE INDIVIDUAL MAY HOLD MULTIPLE ROLES.

#### The 5 Buying Committee Roles

**CHAMPION (Internal Advocate)**
- **Who they are**: The internal sponsor who champions the initiative at the executive level
- **Characteristics**:
  - Has organizational power and influence
  - Has a personal or business interest in the project's success
  - Can allocate resources and remove obstacles
- **Our goal**: Identify them early and build a strong relationship. The Champion is our strongest ally.
- **Questions to identify them**:
  - "Who has the most to gain from this project's success?"
  - "Who sponsored this initiative internally?"

**ECONOMIC BUYER (Final Signing Authority)**
- **Who they are**: The person who has the FINAL authority to sign the contract and approve the budget
- **Characteristics**:
  - Has veto power
  - Typically C-level or VP
  - Can say "NO" even if everyone else says "YES"
- **Our goal**: Direct access. If we never meet the Economic Buyer, the risk of "no-decision" is extremely high.
- **Questions to identify them**:
  - "Who typically signs contracts of this size in your organization?"
  - "Besides you, who else needs to give final approval?"

**TECHNICAL BUYER (Technical Evaluator)**
- **Who they are**: The technical evaluator who verifies the feasibility and fit of the solution
- **Characteristics**:
  - Understands the technical details
  - Prepares recommendations based on objective criteria
  - Can block a solution on technical grounds
- **Our goal**: Convince them of our technical strength. If the Technical Buyer says "NO", it is very difficult to proceed.
- **Questions to identify them**:
  - "Who will evaluate the technical aspects of the solution?"
  - "Is there an IT or architecture team involved?"

**USER (End User)**
- **Who they are**: The people who will use the solution day to day
- **Characteristics**:
  - Understand the concrete operational challenges
  - Can sabotage implementation if not included
  - Often lack formal decision-making power, but their influence is strong
- **Our goal**: Involve them early. If the Users are not on board, implementation will fail.
- **Questions to identify them**:
  - "Who will use this solution on a daily basis?"
  - "Which teams will be impacted by the change?"

**COACH (Internal Ally and Guide)**
- **Who they are**: Our internal ally who guides us and provides intelligence
- **Characteristics**:
  - Tells us the truth, even when it is uncomfortable
  - Has access to information that is not publicly available
  - Helps us navigate internal politics
  - **Critical**: A true Coach acts in both our interest and their own
- **Our goal**: Cultivate at least one strong Coach. Without a Coach, we are navigating blind.
- **Questions to identify them**:
  - "Who is telling me things that others are not?"
  - "Who has warned me about obstacles or competitors?"
  - "Who cares about my success in addition to their own?"

### Buying Committee Map

For every stakeholder identified:

| Name | Buying Role | Org Level | Influence (1-5) | Urgency (1-5) | Stance on Us (Pro / Neutral / Against) | Business Objectives | Personal Objectives | Engagement Strategy |
|---|---|---|---|---|---|---|---|---|
| John Smith | Economic Buyer | CFO | 5 | 4 | Neutral | Reduce IT costs by 20% | Demonstrate ROI for promotion | Quantified business case, focus on ROI and risk mitigation |
| Sarah Chen | Champion | CIO | 5 | 5 | Pro | Modernize infrastructure | Leave a legacy of transformation | Strategic partnership, co-branded success story |
| ... | ... | ... | ... | ... | ... | ... | ... | ... |

### Mapping Process

**Step 1: Initial Identification**
- During discovery (Phase 2), ask: "Who else will be involved in this decision?"
- Draw an org chart of roles (not just names)

**Step 2: Role Classification**
- Assign buying committee roles (one individual may hold multiple roles)
- Identify gaps: roles we have not yet mapped

**Step 3: Deep Analysis**
- For each key stakeholder, research:
  - Background (LinkedIn, articles, company bio)
  - Business objectives (read strategic plans, earnings calls)
  - Personal objectives (career goals, internal politics, KPIs)
  - Stance on us (supporter, neutral, detractor?)

**Step 4: Engagement Strategy**
- For each stakeholder, define:
  - Tailored key messages
  - Engagement channel (who contacts them, how, when)
  - Specific interaction goal
  - Success metrics

**Step 5: Tracking and Updating**
- The Buying Committee Map is a living document
- Update it after every interaction
- Recalibrate strategies based on new information

### Red Flags to Monitor

- **Phantom Economic Buyer**: No one can tell us who makes the final decision -- High risk
- **Hostile Gatekeeper**: A Technical Buyer or User who blocks access -- Find an alternative path
- **Zero Coaches**: No internal ally -- Win probability below 10%
- **Champion without Budget Authority**: Sponsor without real authority -- Find where the real power lies

### Phase Output
- **Complete Buying Committee Map** with all stakeholders identified and classified
- **Engagement Plan** with personalized strategy for each stakeholder
- **Relationship Health Score** (how many supporters vs. detractors vs. neutral)
- **Gap Analysis**: Roles we still need to identify or access

### Exit Criteria (Gate 3)
- [ ] We have identified at least 4 of the 5 buying committee roles
- [ ] We have direct or indirect access to the Economic Buyer
- [ ] We have at least ONE strong Coach
- [ ] We have a plan to neutralize detractors or obstacles

**If criteria are not met**: Do not proceed to proposal. Invest time to complete the map and gain access.

---

## Phase 4: Competitive Strategy

### Objective
Analyze the competitive landscape and choose the optimal strategy to position ourselves and win.

### The 5 Competitive Strategies

Based on your analysis of the situation, choose ONE of the 5 strategies:

#### 1. DIFFERENTIATION STRATEGY
**When to use it**:
- We have a unique and defensible differentiator
- The customer values that differentiator
- We are willing to invest to communicate it

**Tactics**:
- Educate the customer on evaluation criteria that favor our strengths
- Create a comparison matrix that highlights the gap with competitors
- Use case studies that demonstrate the impact of the differentiator

**Example**: "Unlike competitors who use [standard approach], we use [proprietary technology] that delivers [unique benefit]. This is particularly relevant for you because [connection to their pain]."

#### 2. VALUE LEADERSHIP STRATEGY (Value for Money)
**When to use it**:
- We are competitive on price but not the cheapest
- We can demonstrate a better TCO (Total Cost of Ownership)
- The customer is price-sensitive but does not want the cheapest solution

**Tactics**:
- Shift the conversation from "price" to "value"
- Create a TCO model that includes hidden costs (implementation, training, maintenance)
- Use the concept of "cost of inaction"

**Example**: "Our upfront price is $X, but the 3-year TCO is 30% lower because [reason]. The cheapest competitor appears to save $50K upfront but will cost you $200K more over 3 years."

#### 3. NICHE/SPECIALIZATION STRATEGY
**When to use it**:
- We have vertical (industry) or horizontal (technology) specialization
- The customer values domain-specific expertise
- Competitors are generalists

**Tactics**:
- Highlight track record in their industry
- Demonstrate deep knowledge of their specific challenges
- Position competitors as "jack of all trades, master of none"

**Example**: "While competitors offer generic solutions, we work EXCLUSIVELY with banks. We have deployed similar solutions in 15 of the top 20 banks in the region, know every regulatory constraint, every legacy integration. That means time-to-value of 90 days vs. 9 months."

#### 4. INNOVATION STRATEGY (Challenger)
**When to use it**:
- We have an innovative solution that challenges the status quo
- The customer is frustrated with the traditional approach
- We are willing to educate the market

**Tactics**:
- Use the Challenger Sale framework: Teach, Tailor, Take Control
- Provoke the customer with data that challenges their assumptions
- Position competitors as "the old guard"

**Example**: "The traditional way of solving this problem [incumbent approach] made sense 10 years ago. But data shows 70% of those implementations fail. We have rethought the approach entirely: [new vision]. It is a paradigm shift, but the results speak for themselves."

#### 5. INCUMBENT DISPLACEMENT STRATEGY
**When to use it**:
- The customer already has an incumbent vendor
- There is dissatisfaction (even latent)
- We have a bridging strategy to mitigate switching costs

**Tactics**:
- Do not attack the incumbent directly (it creates defensiveness)
- Focus on "where they are going" vs. "where they are today"
- Offer a low-risk transition (pilot, phased approach)

**Example**: "I am not saying [incumbent] is a bad solution. They served you well in the past. But the question is: will this solution get you where you need to be in 3 years? If the answer is 'maybe not,' let us explore a low-risk pilot to validate an alternative approach."

### Competitive Analysis: Tools

#### 1. Competitive Matrix

| Evaluation Criterion | Weight (%) | Us | Competitor A | Competitor B | Strategic Notes |
|---|---|---|---|---|---|
| Industry expertise (banking) | 25% | 9/10 | 6/10 | 5/10 | Our key differentiator |
| Time-to-value | 20% | 8/10 | 7/10 | 9/10 | Competitor B is faster -- use case study to mitigate |
| 3-year TCO | 20% | 8/10 | 9/10 | 6/10 | We are in the middle -- emphasize value vs. cheapest option |
| ... | ... | ... | ... | ... | ... |

**How to use it**:
1. Identify the criteria the customer will use to evaluate (ask them directly or infer)
2. Assign a weight to each criterion (based on customer priorities)
3. Objectively score each vendor
4. Calculate weighted scores
5. Identify gaps to close or criteria to emphasize/de-emphasize

#### 2. Competitive SWOT

For each key competitor:

**Strengths** (theirs)
- What do they do better than us?
- Why might a customer choose them?

**Weaknesses** (theirs)
- Where are they vulnerable?
- What are their weak points to exploit?

**Opportunities** (ours)
- How can we exploit their weaknesses?
- What messages can we use to position ourselves?

**Threats** (ours)
- How might they attack us?
- What are our vulnerabilities to protect?

#### 3. Battlecards

Create a "battlecard" for each competitor:

- **Who they are**: Brief overview
- **Their typical pitch**: How they position themselves
- **Their strengths**: What they do well (be honest)
- **Their weaknesses**: Where they are vulnerable
- **Our counter-positioning**: How to respond without appearing defensive
- **Landmines to plant**: Strategic doubts to seed in the customer's mind
- **Proof points**: Case studies or data that support our position

### Phase Output
- **Competitive Strategy Document** including:
  - Analysis of competitors in play (known and suspected)
  - Selected competitive strategy (1 of the 5)
  - Competitive positioning statement
  - Key messages and narrative
  - Battlecards for key competitors
  - Anticipated objections and responses

### Exit Criteria (Gate 4)
- [ ] We know who the competitors are (at least the major ones)
- [ ] We have chosen a clear competitive strategy
- [ ] We have prepared "landmines" (strategic doubts to plant)
- [ ] We are ready to respond to anticipated attacks

---

## Phase 5: Proposal

### Objective
Create a formal proposal that clearly articulates value, addresses all Buying Committee concerns, and makes it easy to say "YES."

### Structure of a Winning Proposal

An enterprise proposal should include:

**1. Executive Summary (Max 1 page)**
- Summary of the problem (in THEIR words)
- Solution overview
- Expected value (quantified)
- Investment required
- Next steps

**2. Current Situation and Business Challenge**
- Context and background
- Problem analysis (with data)
- Impact on the business (cost of inaction)
- Source: SWOT analysis, MEDDPICC+RR, discovery notes

**3. Proposed Solution**
- Solution overview
- How it works (architecture, approach)
- Why it works (differentiators)
- What changes for the customer (before/after)

**4. Expected Benefits and Value**
- **Quantitative**: ROI, payback period, NPV
- **Operational**: Efficiency, speed, quality
- **Strategic**: Competitive advantage, innovation
- Source: Business Case analysis, Value Chain

**5. Implementation Approach**
- Methodology and phases
- Timeline and milestones
- Team and responsibilities
- Risk management

**6. Investment Required**
- Detailed breakdown (CAPEX vs. OPEX, one-time vs. recurring)
- Pricing options (if applicable)
- Payment terms
- TCO comparison with alternatives

**7. Why Us**
- Track record (specific case studies)
- Dedicated team
- Partnerships and certifications
- Differentiators vs. competition (subtle, not aggressive)

**8. Next Steps and Mutual Action Plan**
- Decision timeline
- Shared milestones
- Requirements to proceed (from both sides)
- Signature and commitment

### Principles of an Effective Proposal

1. **Customer-Centric**: Use "you," not "we." Every section answers "WIIFM?" (What's In It For Me)
2. **Evidence-Based**: Every claim is supported by data, case studies, or discovery findings
3. **Visually Appealing**: Not a 50-page PDF of text. Use charts, diagrams, infographics
4. **Modular**: Adapt the proposal for different buying committee roles (Executive summary for the Economic Buyer, technical appendix for the Technical Buyer)
5. **Actionable**: Clear on next steps; do not leave the customer wondering "now what?"

### Proposal vs. Business Case

- **Business Case**: Focused on quantifying value (ROI, NPV, payback). Used to justify the investment internally.
- **Proposal**: A broader commercial document that includes the business case but also covers the solution, approach, and terms.

**Best Practice**: Create the Business Case BEFORE the proposal, then incorporate it as a section.

### Presentation vs. Document

Often you need to present the proposal (not just send it):

**Presentation Principles**:
- **Story Arc**: Problem > Implications > Solution > Value > Call to Action
- **Rule of 3**: Never more than 3 key messages per slide
- **Visual > Text**: Use images, not bullet points
- **Rehearse**: Practice the presentation with colleagues, anticipate questions
- **Customize for Audience**: Adapt emphasis based on who is in the room (CFO vs. CTO)

### Managing Objections in the Proposal

Anticipate objections and address them PROACTIVELY in the proposal:

| Predictable Objection | Where to Address in the Proposal |
|---|---|
| "It is too expensive" | TCO and ROI section with clear calculations |
| "How long will it take?" | Implementation section with a realistic timeline |
| "How do we know it will work?" | Case Studies section with measured results |
| "What if it fails?" | Risk Mitigation section and guarantees |
| "Competitor X is cheaper" | "Why Us" section with comparison (subtle) |

### Phase Output
- **Formal Proposal** (document + presentation deck)
- **Business Case** integrated or standalone
- **One-Pager Executive Summary** (for fast-tracking with C-level)
- **FAQ Document** (objection anticipation)
- **Presentation Plan**: Who presents, to whom, when, and with what objective

### Exit Criteria (Gate 5)
- [ ] Proposal has been formally presented to the Buying Committee
- [ ] All buying committee roles have received appropriate material
- [ ] We have responded to all initial questions and objections
- [ ] There is commitment to a decision by a specific date

---

## Phase 6: Decision

### Objective
Guide the customer toward a positive decision, manage the inevitable "no-decision" risk, and close the contract.

### The "No-Decision" Problem

**Fact**: The #1 competitor in enterprise sales is not another vendor -- it is **"doing nothing."**

**Causes of No-Decision**:
- Buying committee complexity (too many stakeholders, consensus is difficult)
- Risk aversion (fear of making the wrong choice)
- Shifting priorities (initiatives that lose urgency)
- Analysis paralysis (too much information, no action)

**How to Combat It**:
1. **Create Urgency**: Connect the initiative to critical events, deadlines, and the cost of inaction
2. **Simplify the Decision**: Reduce risk with a pilot, guarantees, or a phased approach
3. **Build Consensus**: Work with the Coach to align stakeholders
4. **Executive Sponsorship**: Ensure the Champion is pushing internally

### Decision Acceleration Techniques

#### 1. Mutual Action Plan (MAP)

Create a shared plan with the customer:

| Date | Milestone | Owner (Customer) | Owner (Vendor) | Status |
|---|---|---|---|---|
| Jan 15 | Complete technical evaluation | CTO | Our Solution Architect | Completed |
| Jan 22 | Present business case to CFO | CFO, CIO | Account Executive | In progress |
| Jan 29 | Approval by Procurement Committee | Procurement | N/A | Pending |
| Feb 05 | Contract signed | CEO | Sales Director | Pending |

**Benefits**:
- Creates mutual commitment
- Makes the process transparent
- Identifies blockers early

#### 2. Risk Reversal

Reduce perceived risk:
- **Pilot Program**: "Let us run a 60-day pilot on a limited use case"
- **Money-Back Guarantee**: "If you do not achieve [metric] within [timeframe], we will refund you"
- **Phased Approach**: "You pay only after validating the results of Phase 1"
- **Reference Calls**: "Speak with 3 of our customers in your industry"

#### 3. Executive Engagement

If the deal is stalled, involve your executives:
- **Executive Sponsor Call**: Your VP/CEO calls their CEO
- **C-level Dinner**: Informal event to build the relationship
- **Strategic Partnership Discussion**: Elevate the conversation from "vendor/customer" to "strategic partner"

#### 4. Legal and Procurement Navigation

Often the final phase is blocked by Legal or Procurement:

**Tactics**:
- **Standard vs. Custom Terms**: Identify early whether there are contract customization requests
- **Procurement Ally**: Find an ally in procurement (it is a buying committee role)
- **Timeline Pressure**: "The implementation team is available starting March. If we miss that window, the next opening is September."
- **Legal Pre-Alignment**: Share the contract template early to avoid surprises

### Red Flags Indicating Risk

- **Radio Silence**: The customer is not responding to emails/calls
  - **Action**: Engage the Coach to understand what is happening
- **Deferred Decision**: "We need another month"
  - **Action**: Ask explicitly: "What needs to happen in that month for you to decide?"
- **New Stakeholders**: New decision makers appear unexpectedly
  - **Action**: Reset discovery, map the new stakeholder into the Buying Committee
- **Surprise Competitor**: "We are also evaluating another vendor"
  - **Action**: Activate competitive strategy, conduct competitive intelligence

### Phase Output
- **Signed Contract** (best case)
- **Verbal Commitment with timeline** (acceptable)
- **Clear No-Go with rationale** (suboptimal but respectable)
- **No-Decision managed** (worst case -- requires nurturing restart)

### Exit Criteria (Gate 6)
- [ ] Contract signed and PO received
- [ ] Kick-off meeting scheduled
- [ ] Transition from Sales to Delivery team completed

---

## Phase 7: Implementation & Reference Creation

### Objective
Ensure a successful implementation, build a lasting relationship, and create a reusable reference for future opportunities.

### Principles of Successful Implementation

1. **Smooth Handoff**: Sales must brief the Delivery team on:
   - Customer expectations (explicit and implicit)
   - Internal politics and sensitive stakeholders
   - Promises made during the sales process (critical!)
   - Agreed-upon success metrics

2. **Customer Success Plan**:
   - Define project KPIs
   - Milestone reviews (30-60-90 days)
   - Clear escalation path
   - Executive Business Reviews (quarterly)

3. **Expectation Management**:
   - Proactive communication (do not wait for the customer to ask)
   - Transparency on risks and issues
   - Quick wins to build momentum

### From Close to Reference

**End Goal**: Every customer should become:
1. **A Reference**: Willing to speak with other prospects
2. **A Case Study**: A documented success story
3. **An Upsell Opportunity**: Expansion into other areas
4. **A Renewal**: Repeat customer (if subscription model)

**How to Achieve It**:

**Step 1: Deliver on Promise**
- Honor the promises made during the sales process (re-read the proposal!)
- Overdeliver where possible (but without creating unsustainable new expectations)

**Step 2: Measure Success**
- Track the metrics agreed upon in the Business Case
- Document results with concrete data
- Celebrate successes with the customer (not just internally)

**Step 3: Create Case Study**
- After 6-12 months, request to document the success
- Format: Challenge > Solution > Results (with numbers!)
- Obtain approval for publication

**Step 4: Enable Reference**
- Ask if they are willing to serve as a reference
- Brief them on what to highlight (align the stories)
- Limit requests (max 2-3 calls/year to avoid overuse)

**Step 5: Identify Upsell**
- During implementation, identify new opportunities
- "Land and expand" strategy
- Do not be too aggressive too early

### Post-Sales Engagement Model

| Timeframe | Activity | Owner | Objective |
|---|---|---|---|
| Week 1 | Kick-off meeting | Delivery Lead | Set expectations, confirm scope |
| Month 1 | Check-in call | Account Manager | Ensure smooth start, address issues |
| Month 3 | First Value Review | Delivery + Sales | Validate early results, identify next phase |
| Month 6 | Executive Business Review | Sales Director + Customer Exec | Strategic relationship, upsell discussion |
| Month 12 | Case Study Creation | Marketing + Sales | Document success, create reference |
| Ongoing | Quarterly Check-ins | Account Manager | Relationship maintenance, renewal prep |

### Measuring Phase 7 Success

**Internal KPIs**:
- Customer Satisfaction Score (CSAT)
- Net Promoter Score (NPS)
- Reference availability (% of customers willing to serve as reference)
- Case studies published
- Upsell/cross-sell revenue
- Renewal rate (for recurring contracts)

**Customer KPIs** (track for case study):
- Business metrics agreed upon in the Business Case
- Actual time-to-value vs. projected
- Solution adoption rate
- Realized ROI vs. projected ROI

### Phase Output
- **Successful Implementation** with documented success metrics
- **Case Study** published (with customer permission)
- **Customer Reference** available for prospects
- **Upsell Opportunities** identified and qualified
- **Lessons Learned** documented to improve the process

---

## Integration Across the 7 Phases

### Decision Gates and Governance

Every phase has "gates" (exit criteria). **Do not skip gates.** It is better to disqualify in Phase 2 than to invest 6 months only to lose in Phase 6.

**Governance Model**:
- **Opportunities $0-100K**: Account Executive has autonomy
- **Opportunities $100K-500K**: Requires Sales Manager approval at Gate 3 (Buying Committee Mapping)
- **Opportunities $500K+**: Requires Sales Director approval at Gate 2 (MEDDPICC+RR) and Gate 5 (Proposal)

### Documentation and CRM Hygiene

Every phase generates documents that must be:
1. **Archived in CRM**: For visibility and audit trail
2. **Shared with the Team**: Weekly deal reviews
3. **Updated Regularly**: The Buying Committee Map is not static

**Key Documents by Phase**:
- Phase 2: MEDDPICC+RR Analysis
- Phase 3: Buying Committee Map
- Phase 4: Competitive Strategy Document
- Phase 5: Proposal + Business Case
- Phase 6: Signed Contract
- Phase 7: Case Study

---

## Conclusion

The **7-Phase Strategic Selling Process** is a rigorous yet flexible roadmap. The keys to success are:

1. **Discipline**: Follow the process; do not skip phases
2. **Adaptation**: Customize for every opportunity
3. **Collaboration**: Involve the team (presales, delivery, management) at the right moment
4. **Learning**: Every deal (won or lost) generates insights for improvement

**Next Steps**:
- Study **Module 3: Negotiation** to close complex deals using If-Then Trading
- Practice with role-play on real opportunities
- Review recent deals: At which phase did they stall? What could you have done differently?
