# Prospect Research Methodology - Anti-Hallucination Protocol

A structured methodology for conducting deep prospect research and generating professional briefs, with rigorous protocols to prevent errors and hallucinations.

---

## Errors to Avoid Absolutely

Before any prospect research activity, be aware of these recurring errors:

| Error Type | Example | Prevention |
|------------|---------|------------|
| **Inference from silence** | "No structured ERP" when no info exists | Never assume absence of info = absence of fact |
| **Hallucinated names/roles** | Board names not found in sources | Verify every name against primary sources |
| **Fabricated figures** | "~$4M/year investments" with no documentation | Only numbers with explicit source |
| **Misattribution** | ROI from Company X attributed to Company Y | Verify who is the subject of every data point |
| **Incorrect roles** | "CTO" when actual title is "System Administrator" | Verify exact roles on LinkedIn |
| **Basic errors** | Wrong year, misspelled company name | Verify spelling and current dates |

**Guiding Principle**: A brief with sections marked "[N/A - to be explored in discovery]" is more useful and professional than a brief with fabricated information that could embarrass the team during a client meeting.

---

## PHASE 1: Deep Research

### When to Use

When you receive information about a prospect (company name, website, contacts, context) and need to conduct thorough research.

### Required Inputs

- **Company**: Name and website
- **Primary Contact**: Name, role, LinkedIn if available
- **Referral Source**: Name of referring salesperson / inbound channel
- **Context**: Any additional information provided

### Areas to Cover (6 Standard Dimensions)

#### 1. COMPANY PROFILE

- Revenue, employees, locations, corporate structure
- Industry, products/services, markets served
- Ownership (family, PE, publicly traded, etc.)
- Competitive positioning and key competitors
- Recent news (M&A, investments, expansions)

#### 2. LEADERSHIP & STAKEHOLDERS

- CEO, CFO, CIO/CTO, CHRO - names and background
- Specific decision-maker provided - detailed profile
- Relevant public statements (interviews, conferences)
- Recent governance changes

#### 3. DIGITAL/AI MATURITY

- Declared or ongoing digital initiatives
- AI/ML projects announced or implemented
- Known technology stack (ERP, CRM, cloud)
- Partnerships with system integrators or tech vendors
- Presence of dedicated roles (CDO, AI Lead, Data Officer)

#### 4. OPPORTUNITY SIGNALS

- Organizational or technological pain points that emerged
- Failed POCs or stalled AI projects
- Statements about AI adoption challenges
- Competitive or board pressure on innovation

#### 5. COMPETITIVE CONTEXT

- How competitors are using AI
- Industry trends in digital transformation
- AI maturity benchmarks in the prospect's sector

#### 6. FIT ASSESSMENT

- Hypothesized prospect archetype (Quick Win / Growth Opportunity / Strategic Play / Long-Term / Not Ready)
- Recommended entry point based on your company's offerings
- Identified conversation hooks
- Red flags or caution elements

### Expected Output

Structured research with **sources cited for every assertion**. Explicitly flag areas where NO information was found with "[N/A - to be explored in discovery]" instead of making inferences.

### Integration with Qualification

For each key qualification dimension (Strategy Clarity, Infrastructure Maturity, Change Capacity, Ecosystem Signals, Regulatory Pressure, Budget Availability, Decision Speed), document:

- Evidence found (with source)
- Hypothesized score (1-5)
- Confidence level (High/Medium/Low)
- Information gaps to fill during discovery

---

## PHASE 2: Client Brief Generation (DOCX)

### When to Use

After completing deep research, when a professional brief needs to be generated for sharing with the team.

### Critical Rules for Generation

1. **VERIFIED DATA ONLY** - Include exclusively information that emerged from research with an identifiable source

2. **NO INFERENCE** - If a data point did not emerge from research, write "[N/A - to be explored in discovery]" instead of hypothesizing

3. **VERIFY NAMES AND ROLES** - Every person mentioned must have a verified source. If the role is uncertain, indicate "[Role to be verified on LinkedIn]"

4. **NO FABRICATED FIGURES** - Only numbers with documented sources. No extrapolation or calculated averages

5. **CAUTIOUS LANGUAGE** - Use:
   - "emerged from research" instead of "it is the case that"
   - "potential interest" instead of "needs"
   - "signals that suggest" instead of "evidently"

### Brief Structure

#### 1. Executive Summary (half page)

- Opportunity summary in 3-4 sentences
- Opportunity score (1-10) with justification
- Critical alerts if present

#### 2. Company Profile (1 page)

- Fundamental data with sources
- Market context
- Documented recent developments

#### 3. Stakeholder Map (half to 1 page)

- Identified contacts with VERIFIED roles
- Flag discrepancies between received information and research findings
- Relevant background of decision-makers

#### 4. AI/Digital Maturity Assessment (1 page)

- Documented initiatives
- Identified gaps (only those evidenced by sources)
- "[To be explored in discovery]" section for areas without information

#### 5. Approach Strategy (half to 1 page)

- Hypothesized archetype and rationale
- Conversation hooks based on public statements
- Recommended entry point
- What NOT to do / alerts

#### 6. Next Steps (bullet list)

- Concrete actions and owners

### Important Notes

- **DOCUMENT DATE**: Verify that the year is current
- **OUTPUT**: Professional Word document ready for sharing with CEO/team

---

## PHASE 3: Anti-Hallucination Quality Check

### When to Use

ALWAYS after generating the brief, before delivering the final document. Can also be explicitly requested.

### Verification Procedure

#### 1. NAMES AND ROLES AUDIT

For every person mentioned in the brief:

- [ ] Was the name found during research? (Source: _______)
- [ ] Is the role verified from a primary source (LinkedIn/company website)?
- [ ] If the role was initially provided, was it confirmed by research?

**Action**: Remove or flag as "[TO BE VERIFIED]" all names/roles without a source

#### 2. NUMERICAL DATA AUDIT

For every figure in the brief (revenue, employees, investments, percentages):

- [ ] Did the figure emerge from research with a specific source?
- [ ] Is the source reliable (financial statement, press release, management interview)?

**Action**: Remove all figures without a source or that were extrapolated

#### 3. IT/AI MATURITY STATEMENTS AUDIT

For every statement about systems, projects, technology gaps:

- [ ] Is the statement supported by a documented source?
- [ ] Is it a fact or an inference from silence?

**Action**: Replace inferences with "[N/A - to be explored in discovery]"

#### 4. ATTRIBUTION AUDIT

- [ ] Is every data point/quote attributed to the correct entity?
- [ ] Are there no confusions between different companies found during research?

**Action**: Verify that third-party data is not attributed to the prospect

#### 5. BASIC ERROR CHECK

- [ ] Correct current year?
- [ ] Company name spelled correctly?
- [ ] Proper names with correct spelling?

### Verification Output Template

```
| Element | In Brief | In Research | Status |
|---------|----------|-------------|--------|
| [Person name 1] | Role X | Source: LinkedIn | Verified / To be verified / Not found |
| [Revenue figure] | $XXM | Source: 2024 Annual Report | Verified |
| [System Y statement] | "They use SAP" | Not found | REMOVE |
```

### Corrective Actions

List all necessary modifications to the brief before final delivery, then regenerate the document with corrections applied.

---

## Recommended Complete Workflow

When asked to support prospect analysis:

1. **Gather inputs** - Ask for: company name, website, primary contact, referral source, context

2. **Execute PHASE 1** - Structured deep research with cited sources

3. **Present research results** - With sources cited for every assertion

4. **Upon brief request** - Execute PHASE 2 with anti-inference rules

5. **ALWAYS execute PHASE 3** - Quality check before delivering the final document

6. **Proactively flag** - Areas where information is insufficient

---

## Pre-Delivery Brief Checklist

Before delivering any client brief, verify:

- [ ] Year is current
- [ ] All proper names have a verified source
- [ ] All roles are confirmed (not inferred)
- [ ] All figures have a documented source
- [ ] Areas without info are flagged with "[N/A - to be explored in discovery]"
- [ ] No inference is presented as fact
- [ ] Company name is spelled correctly throughout
- [ ] No data is incorrectly attributed

---

## Integration with Other Workflows

This methodology integrates with:

- **prospect-intelligence.md**: For prospect scoring and archetype classification
- **analyze-company-ai-opportunities.md**: For use case identification
- **prepare-meeting.md**: For meeting preparation based on a verified brief
- **qualify-opportunity.md**: For MEDDPICC+RR qualification informed by research findings

---

## Usage Notes

**Resist the temptation to "fill in the gaps"** with plausible but unverified information. Professionalism is demonstrated through intellectual honesty, not apparent completeness.

A prospect appreciates a consultant who says "on this point we did not find public information, we will explore it together" far more than one who fabricates data to appear prepared.
