# Framework Dependencies & Integration Map

**Purpose**: This document maps the **dependencies** between frameworks in the Sales Methodology Pro system. It answers: "What must I have BEFORE I can do X?"

---

## Dependency Hierarchy

```
LEVEL 0: RESEARCH (Foundation)
↓
LEVEL 1: ANALYSIS (Understanding)
↓
LEVEL 2: STRATEGY (Planning)
↓
LEVEL 3: EXECUTION (Delivery)
↓
LEVEL 4: CAPTURE (Follow-through)
```

---

## Framework Dependency Matrix

| Framework | Prerequisites (MUST HAVE) | Optional Enhancers | Feeds Into (ENABLES) |
|---|---|---|---|
| **Pre-Research** | - Client name<br>- Basic context | - Previous interactions<br>- Industry knowledge | - All other frameworks<br>- Foundation for everything |
| **C-SWOT Analysis** | - Client context<br>- Company/service info | - Pre-Research<br>- Industry playbook | - Value Areas<br>- Business Case<br>- One-Pager<br>- Discovery Questions |
| **Value Areas** | - C-SWOT Analysis<br>- Solution description | - Pre-Research | - One-Pager<br>- Discovery Questions<br>- Business Case |
| **Value Chain Analysis** | - Solution documentation<br>- Client context | - C-SWOT<br>- Competitive intel | - Business Case (critical)<br>- Pricing strategy<br>- Negotiation variables |
| **Discovery Questions** | - Value Areas OR C-SWOT<br>- Meeting context | - Pre-Research<br>- Buying Committee map | - Battle Plan<br>- Meeting execution |
| **One-Pager** | - Value Areas<br>- C-SWOT | - Business Case<br>- Competitive analysis | - Email outreach<br>- Leave-behind doc |
| **Battle Plan** | - All meeting prep steps<br>- Value Areas<br>- Discovery Questions | - Buying Committee map<br>- MEDDPICC+RR score | - Meeting execution<br>- Team briefing |
| **MEDDPICC+RR Qualification** | - Basic opportunity info<br>- Initial client conversations | - C-SWOT<br>- Buying Committee<br>- Competitive intel | - GO/NO-GO decision<br>- Resource allocation<br>- Buying Committee mapping |
| **Buying Committee Mapping** | - MEDDPICC+RR GO decision<br>- Identified stakeholders | - Pre-Research<br>- Meeting notes | - Stakeholder strategy<br>- Individual value props<br>- Meeting planning |
| **Business Case** | - **Value Chain Analysis** (critical)<br>- C-SWOT<br>- Solution description | - ROI data<br>- Customer financials | - Executive presentation<br>- Investment approval<br>- Negotiation anchor |
| **Presentation** | - At least ONE of:<br>  - C-SWOT<br>  - Value Areas<br>  - Business Case | - All meeting prep<br>- Competitive analysis | - Meeting delivery<br>- Decision committee pitch |
| **Negotiation Prep** | - Proposal submitted<br>- Client interest confirmed<br>- Our alternatives identified | - Business Case<br>- Value Chain<br>- MEDDPICC+RR score | - Negotiation execution<br>- Contract terms<br>- Deal closure |
| **RFQ Analysis** | - RFQ documents<br>- Deadline known | - Capabilities documentation<br>- Competitive intel | - GO/NO-GO decision<br>- Proposal development<br>- Pricing strategy |
| **Post-Meeting Summary** | - Meeting occurred<br>- Notes/transcript | - Meeting prep materials<br>- MEDDPICC+RR/Buying Committee context | - CRM update<br>- Follow-up actions<br>- Relationship continuity |

---

## Critical Dependencies (NEVER SKIP)

### 1. Value Chain Analysis → Business Case

**Why Critical**:
- Business Case "Expected Benefits" section needs quantified value elements
- Without Value Chain, benefits are generic and uncompelling
- Value Chain provides the specific ROI components

**What Happens If Skipped**:
- Generic benefits ("improved efficiency", "better performance")
- No financial quantification
- Weak justification for investment
- Lost deals because ROI is not clear

**Example**:
```
WITHOUT Value Chain:
"Our solution will improve your operations and increase efficiency."

WITH Value Chain:
"Our solution delivers:
1. $480K annual savings from automated reporting (eliminates 40 hrs/month manual work)
2. 50% faster decision-making from real-time dashboards (worth $2M in faster market response)
3. 35% reduction in compliance risk from built-in audit trails (avoids $500K potential fines)"
```

---

### 2. C-SWOT Analysis → Value Areas / One-Pager

**Why Critical**:
- Cannot position value without understanding client's situation
- Value propositions must address specific C-SWOT findings
- One-Pager content must be grounded in client reality

**What Happens If Skipped**:
- Generic value propositions (not client-specific)
- Misalignment with client priorities
- "Solution looking for a problem"

**Example**:
```
WITHOUT C-SWOT:
"We offer best-in-class analytics platform."

WITH C-SWOT (found: Weakness = Manual reporting, Opportunity = Market expansion):
"Your manual reporting process (40 hrs/month) limits your ability to capitalize on the
market expansion opportunity you identified in Q3 strategic plan. Our analytics platform
eliminates manual work while providing the real-time market intelligence needed for rapid
expansion decisions."
```

---

### 3. MEDDPICC+RR Qualification → Buying Committee Mapping

**Why Critical**:
- Do not invest time mapping stakeholders if opportunity is not qualified
- A weak MEDDPICC+RR score means do not proceed (with rare exceptions)
- Resource allocation must follow qualification

**What Happens If Skipped**:
- Wasted effort on unwinnable deals
- Resources diverted from qualified opportunities
- Poor win rate

**Example**:
```
MEDDPICC+RR Score: Weak (critical gaps in 3+ criteria) → NO-GO
→ Do NOT proceed to Buying Committee mapping
→ Decision: Gracefully decline or park opportunity

MEDDPICC+RR Score: Strong (solid across all criteria) → GO
→ Proceed to Buying Committee mapping
→ Invest resources in stakeholder strategy
```

---

### 4. All 3 RFQ Analyses → Holistic Analysis

**Why Critical**:
- Cannot make GO/NO-GO decision without complete picture
- Admin + Technical + Economic must ALL be assessed
- Win themes emerge from synthesis, not single analysis

**What Happens If Skipped**:
- Blind spots (e.g., technical feasible but commercially unviable)
- Wrong GO/NO-GO decision
- Wasted bid costs

**Example**:
```
Admin Analysis: PASS - We qualify (all certifications)
Technical Analysis: PASS - We can deliver (minor gaps)
Economic Analysis: FAIL - Pricing formula means we'd lose money

→ Holistic: NO-GO (even though admin/technical OK, economics don't work)
```

---

## Dependency Chains (Common Paths)

### Path 1: New Opportunity Discovery → Meeting → Deal

```
1. Pre-Research (Who is this client?)
   ↓
2. MEDDPICC+RR Qualification (Is this worth pursuing?)
   ↓ (if GO)
3. C-SWOT Analysis (What are their challenges/opportunities?)
   ↓
4. Value Areas (How do we help them?)
   ↓
5. Discovery Questions (How do we validate assumptions?)
   ↓
6. One-Pager + Email (How do we get the meeting?)
   ↓
7. Battle Plan (How do we execute the meeting?)
   ↓ (meeting happens)
8. Post-Meeting Summary (What did we learn?)
   ↓
9. Buying Committee Mapping (Who influences the decision?)
   ↓
10. Value Chain Analysis (What's the complete value story?)
    ↓
11. Business Case (What's the ROI justification?)
    ↓
12. Presentation (How do we present to decision committee?)
    ↓
13. Negotiation (How do we close the deal?)
```

**Key Dependency**: Each step provides critical input to the next

---

### Path 2: RFQ Response → Proposal → Win

```
1. RFQ Analysis - Admin (Can we bid?)
   ↓
2. RFQ Analysis - Technical (Can we deliver?)
   ↓
3. RFQ Analysis - Economic (Can we win profitably?)
   ↓
4. Holistic Analysis (Should we GO/NO-GO?)
   ↓ (if GO)
5. Clarification Questions (Resolve ambiguities)
   ↓
6. Compliance Checklist (Track requirements)
   ↓
7. Value Chain Analysis (Build benefits section)
   ↓
8. Technical-Economic Response Draft (Structure compliant proposal)
   ↓
9. Proposal Development (Team effort)
   ↓
10. Presentation (if oral defense required)
    ↓
11. Negotiation (if shortlisted)
```

**Key Dependency**: Each analysis phase must complete before next begins

---

### Path 3: Existing Client → Expansion Opportunity

```
1. Pre-Research (Update context - what's changed?)
   ↓
2. C-SWOT Analysis (New challenges? New opportunities?)
   ↓
3. Value Chain Analysis (What value have we delivered? What's next?)
   ↓
4. Business Case (ROI for expansion)
   ↓
5. Presentation (Quarterly Business Review format)
   ↓
6. Negotiation (Expansion terms)
```

**Key Dependency**: Leverage existing relationship but still follow analytical process

---

## Integration Rules

### Rule 1: Analysis Before Strategy
**Never** create strategy (one-pager, business case, proposal) before completing analysis (research, C-SWOT, value chain).

**Why**: Strategy without analysis is guesswork.

---

### Rule 2: Qualification Before Investment
**Never** invest significant resources (Buying Committee mapping, business case, presentation) before MEDDPICC+RR qualification (or RFQ Holistic Analysis) confirms GO.

**Why**: Resources are finite. Invest in winners.

---

### Rule 3: Foundation Before Superstructure
**Never** build advanced deliverables (business case, presentation, negotiation strategy) without foundational documents (C-SWOT, Value Chain).

**Why**: Foundation provides the content and substance.

---

### Rule 4: Sequential Not Parallel (for dependent frameworks)
**Never** run dependent frameworks in parallel. Complete prerequisites first.

**Exception**: Independent frameworks CAN run in parallel:
- C-SWOT + Pre-Research (can run together)
- Buying Committee + Competitive Analysis (independent)
- Business Case + Value Chain (dependent - Value Chain FIRST)

---

## Dependency Validation Checklist

Before starting any framework, validate:

**Starting C-SWOT**:
- [ ] Do we have client context? (company name, industry, basic info)
- [ ] Do we know what solution/service we're positioning?

**Starting Value Areas**:
- [ ] Have we completed C-SWOT? (or equivalent client analysis)
- [ ] Do we have solution description?

**Starting Value Chain**:
- [ ] Do we have detailed solution documentation?
- [ ] Do we have client context (who they are, what they need)?

**Starting Business Case**:
- [ ] **CRITICAL**: Have we completed Value Chain Analysis?
- [ ] Have we completed C-SWOT (or equivalent problem analysis)?
- [ ] Do we have cost/pricing information?

**Starting Buying Committee Mapping**:
- [ ] Have we completed MEDDPICC+RR and received GO decision?
- [ ] Do we have identified stakeholders (names, roles)?

**Starting Negotiation**:
- [ ] Has proposal been submitted?
- [ ] Has client indicated acceptance in principle?
- [ ] Do we know our alternatives (BATNA)?

**Starting Presentation**:
- [ ] Do we have at least ONE of: C-SWOT, Value Areas, Business Case?
- [ ] Do we know audience and objective?

**Starting RFQ Holistic Analysis**:
- [ ] Have we completed ALL 3: Admin, Technical, Economic analyses?

---

## Cross-Reference: Framework → Templates

| Framework | Primary Template(s) | Location |
|---|---|---|
| C-SWOT | `c-swot-analysis-template.md` | assets/templates/ |
| Value Areas | `value-areas-mapping-template.md` | assets/templates/ |
| Value Chain | `value-chain-template.md` | assets/templates/ |
| Business Case | `business-case-template.md` | assets/templates/ |
| MEDDPICC+RR | `meddpicc-rr-template.md` | assets/templates/ |
| Buying Committee | `buying-committee-template.md` | assets/templates/ |
| Discovery Questions | `discovery-questions-template.md` | assets/templates/ |
| One-Pager | `one-pager-template.md` | assets/templates/ |
| Negotiation | `negotiation-zone-template.md` | assets/templates/ |
| Meeting Structure | `first-meeting-structure-template.md` | assets/templates/ |
| Post-Meeting | `meeting-memo-template.md` | assets/templates/ |

---

## Methodology Scripts (Python)

Some frameworks have deterministic calculation scripts:

| Framework | Script | Purpose |
|---|---|---|
| MEDDPICC+RR | `validate_meddpicc.py` | Calculate GO/NO-GO from criteria scores |
| Business Case | `calculate_roi.py` | Calculate ROI, NPV, Payback, TCO |
| Discovery Questions | `generate_spiced_questions.py` | Generate industry-specific SPICED questions |

**Location**: `scripts/`

**When to Use**: Use scripts for calculations, use AI (me) for strategic content.

---

## Common Dependency Violations & Fixes

### Violation 1: "Generate business case" (without Value Chain)

**Problem**: User requests business case without completing Value Chain Analysis first.

**Fix**:
```
"Before we build the business case, we need to complete Value Chain Analysis.
The business case 'Expected Benefits' section requires quantified value elements from the Value Chain.
Without it, we'd have generic benefits instead of compelling, specific ROI.

Shall we do Value Chain Analysis first? It takes 20-30 minutes and will make the business case 3x more effective."
```

---

### Violation 2: "Create one-pager for client" (without C-SWOT)

**Problem**: User requests one-pager without client-specific analysis.

**Fix**:
```
"To create a compelling one-pager, we should first do a C-SWOT analysis of [Client].
This helps us position value in terms of THEIR specific challenges and opportunities,
not just generic capabilities.

Have you already done a C-SWOT for [Client]? If so, please share it.
If not, shall we do that first? It takes 15-20 minutes."
```

---

### Violation 3: "Map decision center" (without MEDDPICC+RR)

**Problem**: User wants to map stakeholders before qualifying opportunity.

**Fix**:
```
"Before investing time in detailed stakeholder mapping (Buying Committee),
we should first qualify this opportunity using MEDDPICC+RR (multi-criteria assessment).

If the MEDDPICC+RR score reveals critical gaps, we shouldn't pursue,
which means Buying Committee mapping would be wasted effort.

Shall we do MEDDPICC+RR first? It takes 10-15 minutes and tells us if this opportunity
is worth the investment."
```

---

### Violation 4: "Start negotiation prep" (no proposal yet)

**Problem**: User wants to prepare for negotiation before proposal stage.

**Fix**:
```
"Negotiation preparation is for the contract discussion phase AFTER proposal acceptance in principle.

Can you confirm:
1. Has your proposal been submitted?
2. Has the client indicated acceptance (verbal or written)?
3. Are you now discussing commercial terms?

If answers are NO, we should focus on:
- Strengthening the proposal (Business Case, Value Chain)
- Preparing presentation for decision committee
- Building relationship with stakeholders (Buying Committee)
```

---

**This dependency map ensures frameworks are used in the correct order with proper prerequisites, maximizing the effectiveness of the Sales Methodology Pro system.**
