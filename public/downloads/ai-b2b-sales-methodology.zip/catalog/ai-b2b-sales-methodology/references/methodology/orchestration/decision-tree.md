# Decision Tree: Intent Classification & Workflow Selection

**Purpose**: This document provides the **decision logic** for classifying user intent and selecting the correct workflow(s) to execute.

---

## How to Use This Decision Tree

1. **Listen to user request**
2. **Classify primary intent** (use decision tree below)
3. **Check prerequisites** (use framework-dependencies.md)
4. **Guide user proactively** (suggest missing prerequisites)
5. **Execute correct workflow(s)** (use workflow-orchestration.md)

---

## Primary Intent Classification

### Intent Category 1: MEETING PREPARATION

**Trigger Phrases**:
- "Prepare for meeting with [Client]"
- "I have a meeting with [Client] on [Date]"
- "Help me get ready for [Client] call"
- "Create pre-meeting materials for [Opportunity]"
- "Build a battle plan for [Client]"

**Decision Logic**:
```
Q1: Is this a NEW client or opportunity?
  └─ YES → Start with Pre-Research + MEDDPICC+RR Qualification
  └─ NO (existing client) → Update context, proceed to C-SWOT

Q2: Have you done C-SWOT for this client?
  └─ NO → DO C-SWOT FIRST (critical prerequisite)
  └─ YES → Proceed to Value Areas

Q3: What's the meeting purpose?
  └─ First discovery call → Full prepare-meeting workflow (Steps 0-6)
  └─ Solution presentation → Prepare-meeting + Presentation Builder
  └─ Contract discussion → Skip to Negotiation workflow
  └─ Follow-up/relationship → Quick prep (C-SWOT refresh + questions)
```

**Workflow Selection**: `prepare-meeting.md` (Steps 0-6 in sequence)

**Proactive Guidance**:
- If NO C-SWOT yet: "Before we prepare the meeting materials, let's do a C-SWOT analysis to understand [Client]'s specific situation. This takes 15-20 minutes and makes everything else much more targeted."
- If NO MEDDPICC+RR yet (and deal >$100K): "Before investing time in detailed prep, should we qualify this opportunity with MEDDPICC+RR to ensure it's worth pursuing?"

---

### Intent Category 2: BUSINESS CASE DEVELOPMENT

**Trigger Phrases**:
- "Build a business case for [Solution/Client]"
- "Create ROI justification for [Opportunity]"
- "Generate executive summary for [Investment]"
- "I need to justify this investment to CFO"
- "Help me build financial justification"

**Decision Logic**:
```
Q1: Have you completed Value Chain Analysis?
  └─ NO → **STOP**: DO VALUE CHAIN FIRST (critical prerequisite)
        "Business Case needs quantified benefits from Value Chain Analysis.
         Shall we do that first? Takes 20-30 minutes."
  └─ YES → Proceed

Q2: Have you done C-SWOT or equivalent client problem analysis?
  └─ NO → Recommend doing C-SWOT first (for problem statement)
  └─ YES → Proceed

Q3: Do you have cost/pricing information?
  └─ NO → Request it before starting
  └─ YES → Execute Business Case workflow
```

**Workflow Selection**:
1. **First**: `value-chain-analysis.md` (if not done)
2. **Then**: `build-business-case.md` (section-by-section generation)

**Proactive Guidance**:
"I notice you want to build a business case. For maximum impact, we should first complete a Value Chain Analysis to identify and quantify ALL value elements (tangible + intangible) your solution provides. This feeds directly into the 'Expected Benefits' section with specific ROI components. Shall we start with Value Chain Analysis?"

---

### Intent Category 3: OPPORTUNITY QUALIFICATION

**Trigger Phrases**:
- "Should we pursue this opportunity?"
- "Qualify this deal"
- "Is this opportunity worth it?"
- "Evaluate this prospect"
- "GO/NO-GO decision for [Opportunity]"
- "MEDDPICC+RR analysis for [Deal]"

**Decision Logic**:
```
Q1: Is this an RFQ/tender or direct opportunity?
  └─ RFQ/Tender → Use analyze-rfq.md workflow (produces own GO/NO-GO)
  └─ Direct opportunity → Use MEDDPICC+RR qualification

Q2: Do you have basic opportunity information?
  └─ NO → Request: Company, solution, estimated value, contact info
  └─ YES → Proceed

Q3: MEDDPICC+RR Qualification Score Result?
  └─ Weak score (critical gaps in 3+ criteria) → NO-GO (recommend decline)
  └─ Moderate score (gaps in 1-2 criteria) → GO WITH CAUTION (address weaknesses)
  └─ Strong score (solid across all criteria) → STRONG GO (proceed with confidence)

Q4: If GO → What's next?
  └─ Map Buying Committee (map-decision-center workflow)
  └─ Prepare first meeting (prepare-meeting workflow)
```

**Workflow Selection**: `qualify-opportunity.md` (MEDDPICC+RR multi-criteria assessment)

**Proactive Guidance**:
- If weak score: "Based on the MEDDPICC+RR qualification, my recommendation is NO-GO. The opportunity has critical gaps in [criteria]. Unless there are strategic factors I'm not aware of, resources would be better allocated to stronger opportunities. Do you want to proceed anyway?"
- If moderate score: "The MEDDPICC+RR score shows GO WITH CAUTION. Key weaknesses: [list]. Shall we develop mitigation plans for these risks before investing further resources?"
- If strong score: "Strong GO! MEDDPICC+RR qualification is solid across all criteria. Next step: Buying Committee Mapping to identify and strategize around key stakeholders. Shall we do that now?"

---

### Intent Category 4: RFQ/TENDER ANALYSIS

**Trigger Phrases**:
- "Analyze this RFQ"
- "We received a tender document"
- "Help me respond to this RFP"
- "Should we bid on this tender?"
- "Evaluate this procurement"

**Decision Logic**:
```
Q1: Do you have the RFQ documents?
  └─ NO → Request upload before starting
  └─ YES → Proceed

Q2: What deliverable(s) do you need?
  └─ "Full analysis" → All 7 deliverables (Phases 1-3)
  └─ "GO/NO-GO only" → Deliverables 1-4 (stop at Holistic)
  └─ "Just admin check" → Deliverable 1 only
  └─ "Proposal outline" → Deliverables 1-7 (full cycle)

Q3: Execute RFQ workflow phases:
  PHASE 1: Administrative + Technical + Economic Analysis
  PHASE 2: Holistic Analysis → GO/NO-GO decision
  PHASE 3: (if GO) Clarification Email + Checklist + Response Draft
```

**Workflow Selection**: `analyze-rfq.md` (7-deliverable multi-phase approach)

**Proactive Guidance**:
"I'll analyze this RFQ in 3 phases:
- **Phase 1**: Administrative, Technical, and Economic analyses (identify gaps/risks)
- **Phase 2**: Holistic analysis with GO/NO-GO recommendation
- **Phase 3**: (if GO) Action deliverables for proposal development

After Phase 2, I'll give you a clear GO/NO-GO recommendation. Sound good?"

---

### Intent Category 5: PRESENTATION CREATION

**Trigger Phrases**:
- "Create a presentation for [Client/Opportunity]"
- "Build a pitch deck"
- "Prepare slides for [Meeting]"
- "Generate PowerPoint for [Audience]"

**Decision Logic**:
```
Q1: What foundational analyses exist?
  └─ NONE → **STOP**: Cannot build presentation without foundation
        "What analyses have been completed? (C-SWOT, Value Areas, Business Case)
         Presentations should be based on prior analysis, not created from scratch."

  └─ At least ONE → Proceed
        "I see you have [analyses]. I'll use those as the foundation."

Q2: Who is the audience?
  └─ C-level → Strategic Partnership structure
  └─ Technical team → Technical Solution structure
  └─ Decision committee → Business Case Presentation structure
  └─ New prospect → Problem-Solution-Value structure

Q3: What's the objective?
  └─ Define clearly before generating outline
```

**Workflow Selection**: `presentation-builder.md` (4-step process)

**Proactive Guidance**:
"Before building the presentation, I need to understand:
1. **Audience**: Who will be in the room? (C-level, technical, mixed?)
2. **Objective**: What decision or action do you want from this presentation?
3. **Foundation**: What analyses do we have? (C-SWOT, Value Chain, Business Case?)

If we don't have sufficient analysis, I recommend completing [missing analysis] first to make the presentation much more compelling."

---

### Intent Category 6: NEGOTIATION PREPARATION

**Trigger Phrases**:
- "Prepare for negotiation with [Client]"
- "They're pushing back on price"
- "Help me negotiate this deal"
- "Contract discussion with [Client]"
- "Pricing negotiation strategy"

**Decision Logic**:
```
Q1: **PREREQUISITE CHECK** - Are you ready for negotiation?
  └─ Has proposal been submitted? (YES required)
  └─ Has client indicated acceptance in principle? (YES required)
  └─ Are you discussing commercial terms? (YES required)

  If ANY answer is NO:
    → **STOP**: "You're not ready for negotiation yet.
                 Focus on: [proposal refinement / presentation / stakeholder engagement]"

Q2: Do you know your alternatives (BATNA)?
  └─ NO → Start with BATNA analysis first
  └─ YES → Proceed

Q3: What's the deal size?
  └─ >$100K → Use full team approach (define roles)
  └─ <$100K → Simplified approach (may skip team roles)

Q4: Execute negotiation workflow (Steps 1-8):
  BATNA → ZOPA → Objectives → Trading Variables → Tactics → Team → Scenarios
```

**Workflow Selection**: `prepare-negotiation.md` (8-step comprehensive prep)

**Proactive Guidance**:
"Before we prepare negotiation strategy, I need to confirm:
1. Has your proposal been submitted and acknowledged?
2. Has the client indicated acceptance in principle (verbal or written)?
3. Are you now entering contract/commercial term discussions?

If answers are NO, we should focus on strengthening your position BEFORE negotiation:
- Improve proposal (Business Case, Value Chain)
- Present to decision committee
- Build stakeholder support (Buying Committee strategy)"

---

### Intent Category 7: STAKEHOLDER MAPPING

**Trigger Phrases**:
- "Map the decision center for [Opportunity]"
- "Who are the key stakeholders?"
- "Buying Committee analysis for [Client]"
- "Identify decision makers"
- "Stakeholder strategy for [Deal]"

**Decision Logic**:
```
Q1: Have you qualified this opportunity with MEDDPICC+RR?
  └─ NO → "Before investing time in stakeholder mapping, should we qualify
           the opportunity first? MEDDPICC+RR takes 10-15 minutes and ensures this
           is worth pursuing."
  └─ YES, weak score → "MEDDPICC+RR score indicates NO-GO. Buying Committee mapping would be wasted effort."
  └─ YES, solid score → Proceed

Q2: Do you have identified stakeholders (names, roles)?
  └─ NO → Guide them to gather names first
  └─ YES → Execute Buying Committee workflow

Q3: Buying Committee Roles:
  - Champion/Sponsor: Executive champion who advocates internally
  - Economic Buyer: Final authority on budget and approval
  - Technical Buyer: Evaluates technical fit and feasibility
  - User: End users who will work with the solution daily
  - Coach: Internal guide who provides intel and navigates politics
```

**Workflow Selection**: `map-decision-center.md` (Buying Committee framework)

**Proactive Guidance**:
"Buying Committee mapping is valuable, but only for qualified opportunities. Have you done MEDDPICC+RR qualification? If the score shows critical gaps, we shouldn't proceed with detailed stakeholder mapping."

---

### Intent Category 8: VALUE MAPPING

**Trigger Phrases**:
- "Map value for this solution"
- "What value do we provide to [Client]?"
- "Value proposition for [Opportunity]"
- "Benefits of [Solution]"
- "Value chain analysis"

**Decision Logic**:
```
Q1: Is this for a specific client/opportunity or generic?
  └─ Specific client → Value Areas OR Value Chain (see Q2)
  └─ Generic → Value Chain (comprehensive capability mapping)

Q2: What's the use case?
  └─ Meeting prep / One-pager → Value Areas (3-5 key propositions)
  └─ Business case prep → Value Chain (comprehensive, quantified)
  └─ Pricing justification → Value Chain (shows full value stack)
  └─ Competitive differentiation → Value Chain (tangible + intangible)

Q3: Have you done C-SWOT?
  └─ NO → Recommend C-SWOT first (provides client context for value mapping)
  └─ YES → Value mapping will be client-specific and targeted
```

**Workflow Selection**:
- `prepare-meeting.md` Step 3 (Value Areas - quick, 3-5 propositions)
- `value-chain-analysis.md` (Comprehensive - all value elements, quantified)

**Proactive Guidance**:
"I see two approaches for value mapping:
1. **Value Areas** (quick, 20 min): 3-5 key value propositions for meeting prep
2. **Value Chain Analysis** (comprehensive, 30 min): Complete value mapping with quantification, cost structure, differentiation - essential for Business Case

Which fits your immediate need? If you're preparing a Business Case, Value Chain is mandatory."

---

### Intent Category 9: POST-MEETING FOLLOW-UP

**Trigger Phrases**:
- "Summarize the meeting with [Client]"
- "Create follow-up email after [Meeting]"
- "Meeting memo for [Opportunity]"
- "Document what we discussed"
- "CRM update from meeting"

**Decision Logic**:
```
Q1: What type of output do you need?
  └─ Client-facing memo → Client Memo mode
  └─ Internal CRM notes → Internal Report mode
  └─ Both → Generate both

Q2: Do you have meeting notes or transcript?
  └─ YES → Upload for analysis
  └─ NO → Guide me through key discussion points

Q3: What are next steps?
  └─ Include Mutual Action Plan with:
     - Specific actions
     - Owners (client + us)
     - Deadlines
```

**Workflow Selection**: `generate-post-meeting-summary.md` (dual-mode output)

**Proactive Guidance**:
"I'll create a professional meeting summary. Should I generate:
1. **Client Memo**: Polished summary you can email to the client
2. **Internal Report**: Detailed notes for CRM with strategy insights
3. **Both**: Complete documentation

Also, I'll include a Mutual Action Plan with specific next steps, owners, and deadlines."

---

### Intent Category 10: GENERAL INQUIRY / UNCLEAR INTENT

**Trigger Phrases**:
- "What should I do for [vague situation]?"
- "Help me with this opportunity"
- "I don't know where to start"

**Decision Logic**:
```
Q1: Ask clarifying questions to understand:
  - What's the current stage? (prospecting, meeting scheduled, proposal submitted, negotiation)
  - What's been done so far? (any analyses, meetings, documents)
  - What's the immediate goal? (qualify, prepare, present, negotiate, close)

Q2: Based on stage, route to appropriate intent category

Q3: Check prerequisites and guide proactively
```

**Response Template**:
"To help you effectively, I need to understand your situation better:

1. **Stage**: Where are you in the sales process?
   - Prospecting / Initial contact
   - Meeting scheduled (when?)
   - Proposal submitted
   - Negotiating terms
   - Other?

2. **What's been done**: Have you completed any analyses?
   - MEDDPICC+RR qualification?
   - C-SWOT analysis?
   - Value Chain or Business Case?
   - Stakeholder mapping?

3. **Immediate goal**: What do you need right now?
   - Qualify the opportunity (GO/NO-GO)?
   - Prepare for a meeting?
   - Build a proposal or business case?
   - Prepare for negotiation?

Once I understand this, I'll guide you through the correct process using the Sales Methodology Pro framework."

---

### Intent Category 11: PROSPECT INTELLIGENCE & RESEARCH

**Trigger Phrases**:
- "Analyze [Company] for prospect intelligence"
- "What do we know about [Company]?"
- "Prepare a sales brief on [Company]"
- "Deep research on [Company] for the sales team"
- "Assess [Company] as a prospect"
- "Prioritize this list of prospects"
- "Sales brief on [Company]"

**Decision Logic**:
```
Q1: Is this a NEW prospect or an existing client?
  └─ NEW prospect → Proceed with Prospect Research
  └─ Existing client → Use other workflows or update existing analysis

Q2: What is the objective?
  └─ Prioritize prospect list → Research for batch comparison
  └─ Prepare for meeting → Prospect Research FIRST, then prepare-meeting
  └─ Brief the sales team → Research with focus on conversation starters

Q3: Do you have basic information about the prospect?
  └─ NO (name only) → Proceed, web research will fill gaps
  └─ YES (industry, size, context) → More accurate output
```

**Workflow Selection**: `prospect-intelligence.md` (30-45 minutes)

**Proactive Guidance**:
"To create an effective prospect intelligence brief, I'll conduct deep research on [Company] and generate:
1. **Prospect Profile** with verified data and source citations
2. **Prospect Archetype** (Quick Win / Growth Opportunity / Strategic Play / Long-Term / Not Ready)
3. **Sales Intelligence Brief** with specific conversation starters
4. **Recommended Approach** with cycle estimate

This will help you prioritize the prospect and prepare the team for engagement.

**Note**: If the goal is to prepare for a specific meeting, after this workflow I recommend proceeding with `prepare-meeting` for a complete preparation."

**Pre-Workflow Checkpoint**:
- [ ] Do I have the full company name?
- [ ] Do I know the industry/sector (or can I infer it)?
- [ ] Do I have access to research sources (web, LinkedIn)?

**Integration**:
- **BEFORE prepare-meeting**: Prospect Research Brief provides foundation for meeting prep
- **COMPLEMENTS analyze-company-ai-opportunities**: Research is more sales-focused; analyze-company is more use-case focused
- **FEEDS INTO qualify-opportunity (MEDDPICC+RR)**: Research informs multiple qualification criteria

---

## Multi-Intent Requests (Complex Scenarios)

### Scenario A: "Prepare for meeting AND create business case"

**Decision Logic**:
```
This is TWO intents: Meeting Prep + Business Case

Correct sequence:
1. Meeting Prep workflow (includes C-SWOT, Value Areas)
2. THEN Value Chain Analysis (adds quantification)
3. THEN Business Case (uses Value Chain output)

Guide user:
"You need both meeting prep and business case. Correct sequence:
- **First**: Prepare meeting (C-SWOT, Value Areas, Discovery Questions, Battle Plan)
- **After meeting**: Value Chain Analysis (quantify value)
- **Then**: Business Case (for decision committee)

Or, if business case is needed BEFORE the meeting:
- **First**: C-SWOT + Value Chain Analysis (builds foundation)
- **Then**: Business Case (for investment approval)
- **Then**: Meeting Prep (to present business case)

Which scenario applies?"
```

---

### Scenario B: "Analyze RFQ AND prepare presentation"

**Decision Logic**:
```
This is SEQUENTIAL: RFQ Analysis → (if GO) → Presentation

Correct sequence:
1. RFQ Analysis (Deliverables 1-4) → GO/NO-GO decision
2. IF GO → RFQ Response Draft (Deliverable 7) provides content
3. IF oral presentation required → Presentation Builder (using RFQ content)

Guide user:
"For RFQ responses, we follow this sequence:
1. **Analyze RFQ** (determine GO/NO-GO) - Do you want me to start here?
2. **If GO**: Build compliant proposal outline
3. **If oral presentation required**: Convert proposal to presentation format

Shall we start with RFQ analysis?"
```

---

### Scenario C: "Negotiate price AND build business case"

**Decision Logic**:
```
This is WRONG ORDER: Business Case BEFORE Negotiation

Correct sequence:
1. Business Case (establish value anchor)
2. THEN Negotiation (defend price with Business Case ROI)

Guide user:
"Business Case should be completed BEFORE negotiation, not during.
The Business Case establishes the value anchor that justifies your pricing.

Current status check:
- Do you already have a Business Case? If YES, proceed to Negotiation.
- If NO, let's build Business Case FIRST, then prepare negotiation strategy.

Which applies?"
```

---

## Proactive Suggestion Framework

### When to Suggest Additional Workflows

**User requests**: "Prepare meeting with Client X"

**Proactive suggestion logic**:
```
Check opportunity size:
  IF deal >$100K:
    → "Before investing in detailed prep, should we qualify with MEDDPICC+RR?
       It ensures this opportunity is worth pursuing and helps prioritize resources."

Check if new prospect:
  IF new client:
    → "Since this is a new prospect, shall we start with MEDDPICC+RR qualification
       to assess fit before investing in full meeting prep?"

Check if client analysis exists:
  IF no C-SWOT yet:
    → "For maximum impact, we should do C-SWOT first to understand their
       specific situation. Then value propositions will be much more targeted."
```

---

## Decision Tree Flowchart (Text Format)

```
USER REQUEST
    |
    ├─ Contains "meeting" → MEETING PREP Intent
    |   └─ Check: C-SWOT done? → NO → Do C-SWOT first
    |   └─ Execute: prepare-meeting.md
    |
    ├─ Contains "business case" OR "ROI" → BUSINESS CASE Intent
    |   └─ Check: Value Chain done? → NO → **STOP, do Value Chain first**
    |   └─ Execute: value-chain-analysis.md → build-business-case.md
    |
    ├─ Contains "qualify" OR "should we pursue" → QUALIFICATION Intent
    |   ├─ Is RFQ? → YES → analyze-rfq.md
    |   └─ Is direct? → YES → qualify-opportunity.md (MEDDPICC+RR)
    |
    ├─ Contains "RFQ" OR "tender" OR "RFP" → RFQ ANALYSIS Intent
    |   └─ Execute: analyze-rfq.md (7 deliverables, 3 phases)
    |
    ├─ Contains "presentation" OR "slides" OR "deck" → PRESENTATION Intent
    |   └─ Check: Analyses exist? → NO → Request analyses first
    |   └─ Execute: presentation-builder.md
    |
    ├─ Contains "negotiate" OR "pricing discussion" → NEGOTIATION Intent
    |   └─ Check: Proposal submitted? → NO → **STOP, not ready**
    |   └─ Execute: prepare-negotiation.md
    |
    ├─ Contains "stakeholders" OR "decision center" OR "buying committee" → STAKEHOLDER Intent
    |   └─ Check: MEDDPICC+RR done and GO? → NO → Suggest qualification first
    |   └─ Execute: map-decision-center.md
    |
    ├─ Contains "value" OR "benefits" → VALUE MAPPING Intent
    |   ├─ For business case? → value-chain-analysis.md (comprehensive)
    |   └─ For meeting prep? → prepare-meeting.md Step 3 (Value Areas)
    |
    ├─ Contains "meeting summary" OR "follow-up" → POST-MEETING Intent
    |   └─ Execute: generate-post-meeting-summary.md
    |
    └─ UNCLEAR → Ask clarifying questions about stage, done-so-far, goal
```

---

## Common User Mistakes & Corrections

### Mistake 1: Jumping to deliverable without foundation
**User**: "Create a one-pager for Client X"
**Correction**: "Have we done C-SWOT for Client X? One-pager should be based on their specific challenges/opportunities, not generic capabilities."

### Mistake 2: Requesting dependent frameworks in wrong order
**User**: "Build business case for Solution Y"
**Correction**: "Before business case, we need Value Chain Analysis to quantify benefits. Business Case without Value Chain has weak, generic benefits. Shall we do Value Chain first?"

### Mistake 3: Skipping qualification
**User**: "Prepare full meeting materials for this $500K opportunity"
**Correction**: "For a $500K deal, should we qualify with MEDDPICC+RR first? It takes 15 min and ensures we're investing resources in a winnable opportunity."

### Mistake 4: Premature negotiation prep
**User**: "Prepare for price negotiation with Client Z"
**Correction**: "Before negotiation prep: Has your proposal been submitted and accepted in principle? Negotiation is for the contract phase AFTER acceptance. If not there yet, let's focus on proposal or presentation."

### Mistake 5: Generic requests without context
**User**: "Help me with this deal"
**Correction**: [Use General Inquiry decision logic - ask stage, what's done, goal]

---

**This decision tree ensures correct workflow selection based on user intent, with proactive guidance to prevent common mistakes and enforce correct methodology sequencing.**
