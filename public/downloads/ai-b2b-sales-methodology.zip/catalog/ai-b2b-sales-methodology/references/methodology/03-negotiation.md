# Module 3: Negotiation - The 5-Phase Process

## Table of Contents

1. [Introduction](#introduction)
2. [Core Principles](#core-principles-of-negotiation)
3. [The 5-Phase Negotiation Process](#the-5-phase-negotiation-process)
   - [Phase 1: Analysis](#phase-1-analysis-pre-negotiation-assessment)
   - [Phase 2: Preparation](#phase-2-preparation-tactical-architecture)
   - [Phase 3: Execution](#phase-3-execution-at-the-table)
   - [Phase 4: Closure](#phase-4-closure-finalizing-the-agreement)
   - [Phase 5: Review](#phase-5-review-post-negotiation-learning)
4. [Key Concepts](#key-concepts)
   - [BATNA (Best Alternative)](#batna-best-alternative-to-a-negotiated-agreement)
   - [ZOPA (Zone of Possible Agreement)](#zopa-zone-of-possible-agreement)
   - [Trading Variables](#trading-variables)
   - [If-Then Trading Principle](#if-then-trading-principle)
5. [Techniques and Tactics](#techniques-and-tactics)
6. [Common Mistakes to Avoid](#common-mistakes-to-avoid)
7. [Conclusion](#conclusion)

---

## Introduction

**Negotiation** is the art of reaching mutually beneficial agreements while maintaining profitable margins and building lasting relationships. It is the final and most delicate phase of the sales process, where the value created in earlier phases can be either captured or lost.

The **5-Phase Framework** transforms negotiation from an emotional, reactive confrontation into a strategic, structured, data-driven process.

---

## Core Principles of Negotiation

### 1. Negotiation Begins Before the Table

The deal is not negotiated when you discuss the contract. **It begins during discovery**. Every piece of information gathered during Strategic Selling (Phases 1-5) is ammunition for the negotiation.

### 2. Negotiating Is Not Selling

- **Selling**: Creating perceived value, building urgency, persuading
- **Negotiating**: Distributing value, managing trade-offs, finding compromises

Confusing the two leads to difficult negotiations. If you are still "convincing," you are not ready to negotiate.

### 3. Not Everything Is Negotiable

Identify in advance what is negotiable and what is not:
- **Negotiable**: Discount, payment terms, additional scope, timeline, SLA
- **Non-Negotiable** (typically): Brand reputation, solution integrity, terms that expose you to legal or financial risk

### 4. Power Is Relative

Power in a negotiation is not absolute. It depends on:
- Who has more to lose if the deal falls through?
- Who has better alternatives?
- Who has more time?
- Who has more information?

**Important**: The client does not always hold the power just because they are "paying." If your solution is unique and they have urgency, the power is yours.

### 5. The Goal Is Not to "Win"

The goal is to reach an agreement that:
- Satisfies the business needs of both parties
- Is sustainable over time (no "buyer's remorse")
- Creates the foundation for a future relationship

**"Win-lose" negotiations are won once. "Win-win" negotiations are won indefinitely.**

---

## The 5-Phase Negotiation Process

```
PHASE 1: Analysis (Pre-Negotiation Assessment)
   ↓
PHASE 2: Preparation (Tactical Architecture)
   ↓
PHASE 3: Execution (At the Table)
   ↓
PHASE 4: Closure (Finalizing the Agreement)
   ↓
PHASE 5: Review (Post-Negotiation Learning)
```

---

## Phase 1: Analysis (Pre-Negotiation Assessment)

### Objective
Analyze the power dynamics, define clear objectives, and build the information foundation for the negotiation.

### Key Analytical Tools

#### 1. BATNA (Best Alternative to a Negotiated Agreement)

**Definition**: Your best option if this negotiation fails. The concept originates from **Fisher & Ury, *Getting to Yes* (1981)**.

**Calculating Your BATNA**:
- If we do not close this deal, what do we do?
  - Option A: Invest resources on another prospect (estimated value: $X)
  - Option B: Walk away and save costs (value: $Y)
  - Option C: Offer worse terms (value: $Z)
- **Your BATNA is the best among these options**

**Estimating Their BATNA**:
- If the client does not buy from us, what do they do?
  - Option A: Buy from a competitor (identify which one and at what terms)
  - Option B: Build in-house (estimate cost and timeline)
  - Option C: Do nothing / status quo (estimate cost of inaction)
- **Their BATNA is the best among these alternatives**

**Key Principle**: **Whoever has the stronger BATNA has more power.**

Example:
- Our BATNA: Sell to another client at a 30% margin (strong)
- Their BATNA: Buy from a competitor at 20% higher cost and 6 months delay (weak)
- **Conclusion**: We have power. We can defend our price.

#### 2. ZOPA (Zone of Possible Agreement)

**Definition**: The zone within which a deal is possible.

```
[Our Minimum Acceptable] <---- ZOPA ----> [Their Maximum Available]
         $80K                                      $120K
```

- **ZOPA Exists**: If our minimum ($80K) < their maximum ($120K) → Deal is possible
- **ZOPA Does Not Exist**: If our minimum ($120K) > their maximum ($100K) → Deal is impossible (unless scope changes)

**How to Determine the ZOPA**:

**Our Minimum**:
- Cost + minimum acceptable margin
- Factor in opportunity cost (BATNA)
- Consider whether the deal is strategic (reference client, gateway account, etc.)

**Their Maximum** (harder to estimate):
- Declared budget (often fictional)
- Value delivered (what we bring to them)
- Cost of alternatives (competitor or build in-house)
- Intelligence from your Coach (from your Buying Committee map)

**Negotiating Within the ZOPA**:
- **Target Price** (ours): $120K (top of the ZOPA)
- **Walk-Away Price** (ours): $80K (bottom of the ZOPA)
- **Objective**: Close as close to our target as possible

#### 3. Power Dynamics Analysis

Assess who holds more power across 7 dimensions:

| Dimension | Us (1-5) | Client (1-5) | Strategic Notes |
|---|---|---|---|
| **BATNA Quality** | 4 | 2 | We have other opportunities; they have few credible alternatives |
| **Time Urgency** | 3 | 5 | They have a Q1 deadline; we can wait |
| **Information** | 4 | 3 | We know them and their competitors; they know little about us |
| **Expertise/Specialization** | 5 | N/A | We are the only ones with this expertise in the banking sector |
| **Budget Availability** | N/A | 3 | They have budget but must justify every dollar to the CFO |
| **Relationship Strength** | 4 | 4 | Strong relationship with CIO (Champion/Sponsor), but CFO is neutral |
| **Risk Tolerance** | 3 | 2 | We can walk away; for them the risk of inaction is high |
| **TOTAL** | 23 | 19 | **Slight advantage to us** |

**Score > 25**: Strong power position → Defend price and conditions aggressively
**Score 15-25**: Balanced position → Negotiate win-win
**Score < 15**: Weak position → Be flexible or consider walking away

#### 4. Stakeholder Identification for Negotiation

Who will be at the table? Use the Buying Committee map to identify:

| Name | Buying Committee Role | Role in Negotiation | Objectives | Levers on Them |
|---|---|---|---|---|
| CFO | Economic Buyer | Final approver on price | Minimize financial risk | ROI, payment terms, guarantees |
| CIO | Champion/Sponsor | Our sponsor | Close quickly, get best solution | Support with strong business case |
| Procurement | Non-Buying Committee | Tactical negotiator | Reduce price, improve terms | Demonstrate TCO, not just price |
| Legal | Non-Buying Committee | Risk manager | Protect from contractual risks | Standard contracts, accept reasonable clauses |

**Strategy**: Negotiate with Procurement, but maintain an escalation path to CFO/CIO if blocked.

---

### Phase 1 Output
- **BATNA Analysis** (ours and theirs)
- **ZOPA Definition** (our minimum, their maximum, target price)
- **Power Dynamics Matrix** with score
- **Stakeholder Mapping** for the negotiation
- **Initial Negotiation Strategy** (aggressive vs. collaborative)

---

## Phase 2: Preparation (Tactical Architecture)

### Objective
Build a complete negotiation architecture: objectives, trading variables, scenarios, tactics.

### Step 1: Define Objectives (At 3 Levels)

#### Target (Optimal)
- Price: $120K
- Payment Terms: 50% upfront, 50% at 60 days
- Scope: Phase 1 + Phase 2
- Timeline: Kick-off in January

#### Acceptable
- Price: $100K
- Payment Terms: 30% upfront, 70% at 90 days
- Scope: Phase 1, Phase 2 optional
- Timeline: Kick-off in February

#### Walk-Away (Minimum)
- Price: $80K
- Payment Terms: 20% upfront, 80% at 120 days
- Scope: Phase 1 reduced
- Timeline: Any

**If we cannot reach at least Walk-Away → Do not do the deal.**

### Step 2: Identify Trading Variables

A negotiation is not just about "price." There are dozens of variables to trade on.

#### Common Trading Variables

| Category | Variables | Value to Client | Cost to Us | Ratio (High = Excellent) |
|---|---|---|---|---|
| **Price** | Discount | High ($$$) | High (margin) | 1:1 |
| **Payment Terms** | 120-day terms | High (cash flow) | Medium (financing cost) | 3:1 |
| **Scope** | Additional features | Medium (nice-to-have) | High (dev cost) | 1:2 |
| **Timeline** | Early delivery | High (urgency) | High (team overtime) | 1:1 |
| **Support** | Premium SLA | Medium | Medium | 1:1 |
| **Training** | Additional training | High (adoption) | Low (if existing) | 5:1 |
| **Warranty** | Extended warranty | Medium (risk mitigation) | Low (if confident) | 3:1 |
| **Volume Commitment** | Multi-year commit | High (predictability) for us | Low (if already intended) | 4:1 |

**Trading Principle**: Give up variables with **High value to them, Low cost to you**. Ask in return for variables with **High value to you, Low cost to them**.

#### Example of a Strategic Trade

**Client requests**: "We need a 15% discount"

**Untraded Response**:
"Ok, here is 15% off" → You lose $18K in margin and get nothing in return

**Traded Response (If-Then)**:
"I understand your budget constraint. We can explore that option. If I offer 15%, then would you be able to:
- Sign by end of month (helps our forecast)
- Commit to a Phase 2 order within 6 months (volume commitment)
- Provide a case study at the end (marketing value for us)
- Accept our standard payment terms (reduces our financing cost)"

**Result**: You concede on price but gain 4 concessions that compensate.

### Step 3: Build the Power Architecture

#### 3 Pillars of Negotiation Power

**1. Information**
- The more you know, the more power you have
- Do you know their real budget? Their constraints? Competitors in play?
- **Source**: Coach (from your Buying Committee map), Procurement intelligence, research

**2. Time**
- Whoever is in a hurry has less power
- If they have a deadline and you do not → Power is yours
- **Tactic**: Never reveal urgency (even if it exists)

**3. Alternatives (BATNA)**
- Whoever has better alternatives has more power
- **Tactic**: Make your BATNA credible ("We have 3 other prospects ready")
- **Tactic**: Weaken their BATNA ("The competitors have a 6-month delay")

#### Concession Architecture

Plan your concessions in advance:

**Pre-Planned Concessions** (in order of "pain"):

1. **Level 1 (Low Cost)**:
   - Additional training
   - Extra documentation
   - Minor customizations

2. **Level 2 (Medium Cost)**:
   - More favorable payment terms
   - Improved SLAs
   - Limited additional scope

3. **Level 3 (High Cost)**:
   - Price discount (5-10%)
   - Extended warranties
   - Accelerated delivery

**Rule**: Start by giving Level 1 concessions. Give Level 2 only if you get something in return. **Never give Level 3 without significant concessions from them.**

### Step 4: Prepare Scenarios and Role-Play

Simulate the negotiation with your team:

#### Scenario 1: Client Aggressive on Price
**Client**: "Your competitor costs 30% less"
**Our Response**: [Prepare 3 counter-arguments]

#### Scenario 2: Request for Additional Scope
**Client**: "Can you include X at no additional cost?"
**Our Response**: [Prepare trade-off]

#### Scenario 3: Walk-Away Threat
**Client**: "If you do not give us this discount, we go with Competitor Y"
**Our Response**: [Prepare reality test + alternatives]

**Best Practice**: Record the role-play, identify weaknesses, refine.

### Step 5: Prepare the Team

**Who will be in the room**:
- **Lead Negotiator**: The speaker (typically Account Executive or Sales Director)
- **Technical Expert**: Answers technical questions, does not negotiate price
- **Executive Sponsor** (optional): For escalation or strategic deals

**Roles and Responsibilities**:
- **Lead Negotiator**: Leads, makes trades, closes
- **Technical Expert**: "Bad cop" on technical topics, can say "not feasible" for impossible requests
- **Executive**: "Good cop" on strategy, resolves impasses

**Team Communication**:
- **Codes**: "Can I consult with my team?" = time-out to realign
- **Body Language**: Never contradict each other in front of the client

---

### Phase 2 Output
- **Negotiation Playbook** containing:
  - Objectives at 3 levels (Target/Acceptable/Walk-Away)
  - Trading variables mapped
  - Trade scenarios planned
  - Responses to predictable objections
  - Concession architecture
- **Team Roles** defined
- **Scenarios** simulated with role-play

---

## Phase 3: Execution (At the Table)

### Objective
Conduct the negotiation with tactical discipline, managing emotions and pressure, to reach a favorable agreement.

### Core Tactical Principles

#### 1. If-Then Trading Principle

**Never concede without getting something in return.**

**Bad**:
- Client: "We need a 10% discount"
- Us: "Ok, here is 10%"

**Good (If-Then Trading)**:
- Client: "We need a 10% discount"
- Us: "I understand. We can explore that option. Under what conditions? If I offer 10%, then could you...?"
  - Sign this week?
  - Commit to Phase 2 as well?
  - Accept faster payment terms?

**Golden Rule**: Every concession you make must be conditional. "I can do X, IF you do Y."

#### 2. Anchoring

**Whoever anchors first has the advantage.**

**Scenario A: We anchor**:
- Us: "The price for this project is $120K"
- Client: "That is too much, can we do $100K?"
- Negotiation: Will gravitate around our anchor ($120K)

**Scenario B: Client anchors**:
- Client: "Our budget is $80K"
- Us: "We are thinking $120K"
- Negotiation: Will gravitate toward their anchor ($80K)

**Tactic**: Try to anchor first with a reasonable but ambitious number.

**Exception**: If the client has done research and knows market prices, anchoring too high will cost you credibility.

#### 3. The Power of Silence

**After making an offer or a request, STOP TALKING.**

- Client: "We need a 15% discount"
- Us: "That would require a commitment from your side on..." [SILENCE]
- Client: (after uncomfortable silence) "Fine, what do you need?"

**Why it works**: Silence creates psychological pressure. Whoever speaks first "loses."

**Best Practice**: Count mentally to 10. It feels like an eternity, but it works.

#### 4. The Flinch

When the client makes a request, **react visibly** (without overdoing it).

- Client: "We want a 20% discount"
- Us: [Slight flinch, light sigh] "20% is... significant. We are talking about $24K. We can discuss it, but we would need to revisit scope or terms."

**Why it works**: It signals that the request is excessive without saying "no" directly.

#### 5. Strategic Escalation

**Use the "higher authority" play when you are stuck.**

- Client: "You must give us 15% off or we go with the competitor"
- Us: "I understand the situation. A 15% discount exceeds my authority. I need to speak with my Sales Director. I will get back to you tomorrow."

**Benefits**:
1. Time to reflect and realign internally
2. Signals the request is serious (you cannot decide alone)
3. Any eventual concession carries more weight ("I had to fight internally for this")

**Caution**: Do not overuse it. If you always say "I need to check with my boss," you lose credibility.

#### 6. Divide and Conquer (Negotiate Variables Separately)

Do not negotiate everything at once. Divide:

1. **First**: Agree on value and scope (they agree the solution meets their needs)
2. **Then**: Discuss terms and conditions (price, payment, timeline)

**Why**: If everything is negotiated together, every concession becomes a complex "package deal."

#### 7. The Power of the "Final Offer"

When you are close to agreement, use the final offer technique:

- "Ok, here is my final offer. $105K, with payment terms 40/60, delivery in February, and training included. If you accept, we close now. Otherwise, I need to move the team to other opportunities."

**Why it works**: It creates urgency and forces a decision.

**Caution**: Only use this if you are GENUINELY prepared to walk away if they say no.

### Defensive Tactics (Against Aggressive Client Techniques)

#### Client Uses: "Good Cop / Bad Cop"

**Scenario**:
- Procurement (Bad Cop): "The price is unacceptable, we need to cut it"
- CIO (Good Cop): "I understand your position, but my Procurement team has constraints..."

**Defense**:
- Acknowledge it: "I understand you have different roles"
- Redirect: "I appreciate the candor. Let us return to the business needs: your goal is [X]. Our price reflects the value to achieve [X]."
- Do not be intimidated by the "bad cop"

#### Client Uses: "Fake Walk-Away"

**Scenario**:
- Client: "If you do not give us 20% off, we go with Competitor X. We already have their quote."

**Defense**:
- **Reality test**: "I understand. May I ask: does Competitor X meet all of your requirements? How do they handle [specific problem we know is critical]?"
- **Challenge their BATNA**: "I appreciate the transparency. Before you proceed with them, make sure you evaluate [risk/gap we know they have]."
- **Be willing to walk away**: If they are bluffing, they will call. If they do not, it was not a winnable deal.

#### Client Uses: "Deadline Pressure"

**Scenario**:
- Client: "We must decide by Friday. If you do not give us the requested terms, we move forward without you."

**Defense**:
- **Verify the deadline**: "May I ask: what happens if you decide Monday instead of Friday? What is the real cost of 48 hours?"
- **Do not cave to pressure**: Artificial deadlines are tactics. If the deadline is real, it will be supported by concrete critical events.
- **Condition your urgency**: "We can accelerate if needed, but we would require [concession from them]."

#### Client Uses: "Nibbling" (Requesting Small Extras After Agreement)

**Scenario**:
- (After agreeing on $100K)
- Client: "Oh, and of course training is included, right?"
- Client: "Can you throw in feature X? It is a small thing."

**Defense**:
- **Acknowledge the request**: "I understand training is important to you."
- **Reframe as a trade**: "That was not in the original scope. We can include it, but we would need to revisit [another variable]."
- **Or simply**: "We can discuss a Phase 2 that includes this."

### Managing Emotions

Negotiation is emotionally intense. **Whoever keeps calm wins.**

#### If the Client Becomes Aggressive or Emotional

**Scenario**: The client raises their voice, becomes accusatory — "You vendors are all the same! You just want to rip us off!"

**Response**:
1. **Do not counter-attack**: "I understand the frustration."
2. **Pause**: "Let us take a moment. Can we take a 10-minute break?"
3. **Reframe in terms of needs**: "Let us get back to the objective. You want [X], and we want to help you achieve it. How can we reach an agreement that works for both of us?"

#### If YOU Become Emotional (Frustration, Anger)

**Self-Regulation**:
- **Acknowledge the emotion**: "I am feeling frustrated"
- **Tactical Pause**: "Can I have 5 minutes to consult with my team?"
- **Breathe**: Literally. 3 deep breaths reduce cortisol
- **Reframe**: "It is not personal. It is business."

---

### Phase 3 Output
- **Agreement Framework** (even if not yet signed)
- **Summary of Terms** agreed upon
- **Open Items** to finalize
- **Next Steps** clearly defined (Legal review, contract drafting, etc.)

---

## Phase 4: Closure (Finalizing the Agreement)

### Objective
Transform the verbal agreement into a signed contract, navigating Legal and Procurement, and ensuring nothing "explodes" at the last minute.

### Step 1: Verbal Agreement Summary

**Immediately after the negotiation**, summarize verbally:

"Ok, to confirm, we have agreed on:
- Price: $105K
- Payment Terms: 40% upfront, 60% at 60 days
- Scope: Full Phase 1, Phase 2 optional with priority
- Delivery: Kick-off February, go-live April
- Training: Included for up to 20 participants
- SLA: Standard

Correct? Anything we need to clarify?"

**Why**: Prevents "memory drift." Written confirmation will follow, but the verbal summary is the first contract.

### Step 2: Follow-Up Email (Within 24 Hours)

Send a formal email with summary:

```
Subject: [Project Name] Agreement - Summary of Terms

Dear [names],

It was a pleasure concluding our discussion yesterday. Below is a summary of the agreed terms:

1. SCOPE: [description]
2. PRICING: $105K
3. PAYMENT TERMS: 40% upon contract signing, 60% at 60 days from kick-off
4. TIMELINE: Kick-off February 1, Go-Live April 15
5. DELIVERABLES: [list]
6. TRAINING: Included for up to 20 participants
7. SLA: Standard (see attachment)

NEXT STEPS:
- [Date]: Send formal contract
- [Date]: Contract review by your team (Legal)
- [Date]: Signature
- [Date]: Kick-off

If anything needs clarification or revision, please reach out by [date].

Best regards,
[Name]
```

**Why**: Creates a reference document. If the client does not object by [date], it is implicitly confirmed.

### Step 3: Contract Drafting

**Options**:
1. **Use your standard template**: Simpler, less customization
2. **Customize**: If required by the client (expect Legal review)

**Critical Contract Elements**:
- **Scope of Work** (detailed)
- **Pricing and Payment Terms**
- **Timeline and Milestones**
- **Deliverables** (what you deliver, in what format)
- **Acceptance Criteria** (how "completed" is measured)
- **Intellectual Property** (who owns what)
- **Confidentiality** (NDA)
- **Liability and Warranties** (limits of liability)
- **Termination Clauses** (what happens if someone wants out)
- **Dispute Resolution** (arbitration vs. court)

**Best Practice**: Involve your Legal team for review before sending.

### Step 4: Legal and Procurement Navigation

**Expect**: The client will want to modify the contract. This is normal.

**Red Flags** (modifications to resist):
- **Unlimited Liability**: "The vendor is responsible for all damages"
  - **Counter**: Limit liability to [X]% of contract value
- **Intellectual Property Ownership**: "All code/IP becomes client property"
  - **Counter**: Distinguish between "generic solution" (yours) and "customizations" (theirs)
- **Right to Audit**: "We can audit your internal processes"
  - **Counter**: Limit to financial audits related to the project, not general operational audits
- **Unilateral Termination**: "We can terminate without cause with 30-day notice"
  - **Counter**: Require a termination fee to cover sunk costs

**Green Lights** (acceptable modifications):
- Stricter confidentiality
- Additional reporting
- Minor scope clarifications

**Process**:
1. Client sends a "redline" (version with highlighted changes)
2. YOU (with Legal) respond with a "redline of the redline"
3. Iterate until convergence
4. **Caution**: If modifications substantially change the economics or risk of the deal, RENEGOTIATE THE PRICE

### Step 5: Signature and PO

**Contract Signature**:
- Both parties sign (digitally or physically)
- Archive in CRM and legal system
- Celebrate (internally)

**Purchase Order (PO)**:
- Request a formal PO (if applicable)
- PO confirms financial commitment
- Without PO, the contract is "paper"

### Step 6: Kick-Off Preparation

There is no magic transition from "Sales" to "Delivery." Manage it proactively:

**Handoff Meeting** (Sales + Delivery + Client):
- Review expectations
- Introduce delivery team
- Confirm scope and milestones
- Identify initial risks
- Schedule formal kick-off

---

### Phase 4 Output
- **Signed Contract**
- **Purchase Order** received
- **Kick-Off Meeting** scheduled
- **Handoff completed** to Delivery team
- **CRM updated** (opportunity → closed-won)

---

## Phase 5: Review (Post-Negotiation Learning)

### Objective
Extract insights from the negotiation to improve future performance.

### Post-Negotiation Debrief

**Within 1 week of closing**, hold a 30-minute session with the team to answer:

#### What Worked?
- Which tactics were successful?
- Which information was decisive?
- Which trade was the most effective?

#### What Did Not Work?
- Where were we surprised?
- Which client tactics put us in difficulty?
- Which information were we missing?

#### What Would We Do Differently?
- How could we have prepared better?
- Were there signals we ignored?
- Where did we concede too much or too little?

#### What Insights for Future Negotiations?
- Patterns identified for this client/industry?
- Tactics to add to the playbook?
- Red flags to monitor in the future?

### Negotiation Metrics

**Track over time**:
- **Average Discount %**: Target <10%
- **Negotiation Duration** (days from proposal to signature): Target <30 days
- **Win Rate Post-Negotiation**: Target >70% (with proper MEDDPICC+RR qualification)
- **Average Margin**: Compare target vs. actual
- **Contract Slippage**: % of contracts that slip from forecast date

**Trend Analysis**:
- Are you conceding too much?
- Are you losing deals by being too rigid?
- Which clients/industries are the most difficult?

### Documentation and Knowledge Sharing

**Create a "Negotiation Story"**:
- Client and context
- Planned strategy
- What actually happened
- Tactics used (ours and theirs)
- Final result
- Lessons learned

**Share with the Team**:
- Deal review meetings
- Internal wiki or knowledge base
- Training for new salespeople

**Continuous Improvement**:
- Update the playbook with new tactics
- Share counterplays to new adversarial tactics
- Celebrate best practices

---

### Phase 5 Output
- **Post-Negotiation Debrief** completed
- **Lessons Learned Document**
- **Negotiation Metrics** tracked
- **Playbook** updated (if necessary)
- **Case Study** (for internal training)

---

## The 12 Deadly Sins of Negotiation

Mistakes to avoid at all costs:

1. **Negotiating with someone who has no decision-making power**
   - Always verify the Buying Committee. If you are negotiating with someone who cannot sign, you are wasting time.

2. **Conceding without getting anything in return**
   - Every concession must be a trade. "I can do X, IF you do Y."

3. **Making the first concession on price**
   - If you cave immediately, you signal weakness. Hold firm, then trade.

4. **Revealing your walk-away point**
   - Never say "The lowest I can go is X." You just lost all leverage above X.

5. **Negotiating under emotional pressure**
   - If you are angry or frustrated, take a break. Emotional decisions are poor decisions.

6. **Ignoring the BATNA (yours and theirs)**
   - If your BATNA is weak and theirs is strong, you are negotiating from a position of weakness. Recognize it and adapt.

7. **Not putting anything in writing**
   - Verbal agreements evaporate. Always confirm via email.

8. **Accepting contract changes without renegotiating**
   - If the client changes scope or terms AFTER the agreement, it is a new negotiation. Reprice.

9. **Forgetting the long-term relationship**
   - A "win-lose" negotiation where you win will come back to haunt you. The client will feel cheated.

10. **Not involving your Legal/Finance team**
    - Contract modifications have legal and financial implications. Do not decide alone.

11. **Being too rigid**
    - If you walk away from every deal that is not "perfect," you will never close. Negotiate.

12. **Being too flexible**
    - If you always cave, clients will learn they can bend you. Defend your boundaries.

---

## Advanced Techniques

### 1. Multi-Level Negotiation

In complex deals, negotiate simultaneously with multiple stakeholders:
- **Tactical**: With Procurement on price and terms
- **Strategic**: With C-level on value and partnership

**Tactic**: If stuck at the tactical level, escalate to the strategic level.

### 2. Cross-Departmental Negotiation

Involve other departments to create leverage:
- **Legal-to-Legal**: Unblock impasses on contractual clauses
- **Tech-to-Tech**: Technical validation that justifies the price
- **Exec-to-Exec**: C-level relationship that bypasses Procurement

### 3. Consultative Negotiation (Win-Win Framework)

Collaborative approach:
- "We are both on the same side of the table. The problem is: how do we create an agreement that works for both of us?"
- Share (selectively) your constraints
- Ask about their constraints
- Co-build the solution

**When to Use**: With strategic clients, long-term relationships, when trust is high.

### 4. Contingent Agreements

If there is disagreement on an assumption (e.g., "How long will it take?"), create a contingent agreement:
- "If we hit X metric within Y timeframe, the price is A. If we do not, the price is B."
- Removes risk from the client, gives you upside if you are confident.

---

## Negotiation Checklist

Before entering a negotiation, make sure you have completed:

### Pre-Negotiation
- [ ] BATNA Analysis (ours and theirs) completed
- [ ] ZOPA defined (our minimum, their maximum)
- [ ] Power dynamics matrix filled out
- [ ] Trading variables identified
- [ ] Objectives at 3 levels defined (Target/Acceptable/Walk-Away)
- [ ] Scenarios simulated with role-play
- [ ] Team briefed on roles
- [ ] Key information validated with Coach (from your Buying Committee map)

### During the Negotiation
- [ ] Anchored with the first offer (if appropriate)
- [ ] Applied If-Then Trading for every concession (no freebies)
- [ ] Used the silence technique after difficult requests
- [ ] Managed emotions (own and client's)
- [ ] Progressively documented agreements
- [ ] Avoided the 12 deadly sins

### Post-Negotiation
- [ ] Verbal agreement summary confirmed
- [ ] Recap email sent within 24 hours
- [ ] Contract prepared and sent
- [ ] Legal review completed (both sides)
- [ ] Contract signed and PO received
- [ ] Handoff to Delivery team completed
- [ ] Post-negotiation debrief scheduled
- [ ] Lessons learned documented

---

## Conclusion

Negotiation is both art and science. **The art** is reading people, managing emotions, finding creative solutions. **The science** is rigorous preparation, data analysis, and the systematic application of proven tactics.

**The best negotiators** are not the most aggressive or the most charismatic. They are the most **prepared**, the most **disciplined**, and the most **patient**.

**Next Steps**:
- Apply this framework to your next negotiation
- Role-play with colleagues on real scenarios
- Document your negotiations and review with a mentor
- Read *Getting to Yes* (Fisher & Ury) and *Never Split the Difference* (Chris Voss) for deeper study

**Remember**: Every negotiation is a learning opportunity. Win or lose, if you learn something, you have won.
