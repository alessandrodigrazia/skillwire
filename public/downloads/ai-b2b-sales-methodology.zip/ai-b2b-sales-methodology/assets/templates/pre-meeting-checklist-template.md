
# TEMPLATE - PRE-MEETING CHECKLIST
*(Strategic Guide to Maximize the Effectiveness of Every Meeting)*

## Reference Information:
- **Sales Rep (Preparation Lead):** ____________________
- **Client/Prospect Company:** ____________________
- **Opportunity/Project Name:** ____________________
- **Meeting Date and Time:** ____/____/____ at ____:____
- **Expected Attendees (Client):**
  - (Name, Role)
  - (Name, Role)
  - (Name, Role)
- **Our Attendees:**
  - (Name, Role)
  - (Name, Role)
- **Meeting Location/Format (e.g., Client Office, Video Conference, etc.):** ____________________

---

## Section 1: MEETING OBJECTIVES (What Do We Want to Achieve?)
*Clearly define what constitutes success for this specific meeting.*

- [ ] **Primary Meeting Objective (SMART: Specific, Measurable, Achievable, Relevant, Time-bound):**
  - Description: ____________________________________________________________
  - How will we measure achievement? ________________________________________

- [ ] **Secondary Objectives** (e.g., gather specific information, identify other stakeholders, obtain commitment for a Mutual Action Plan):
  1. ____________________
  2. ____________________
  3. ____________________

- [ ] **What is the "minimum acceptable outcome" we want from this meeting? (Positive walk-away point):**
  ______________________________________________________________________________

---

## Section 2: CLIENT/CONTEXT RESEARCH AND PREPARATION (What Do We Know?)
*Demonstrating that you have done your homework is fundamental for credibility.*

- [ ] **Client Company Profile updated and analyzed?** (Industry, size, products/services, competitors, recent news, company culture)
  - Notes/Useful Links: ____________________

- [ ] **Client Attendee profiles studied?** (Role, responsibilities, background, interests, possible pain points or personal goals, communication style - e.g., from LinkedIn, company website)
  - For [Attendee Name 1]: ____________________
  - For [Attendee Name 2]: ____________________

- [ ] **Relationship History (if existing):** (Previous interactions, purchases, issues, successes)
  - Notes: ____________________

- [ ] **Client C-SWOT Analysis (or at least key hypotheses) completed?**
  - Key Strengths/Weaknesses/Opportunities/Threats identified: ____________________

- [ ] **Potential Value Areas identified and prioritized?** (Client Problem/Opportunity -> Our Macro Solution -> Target Person -> Hypothesized Benefits)
  1. ____________________
  2. ____________________

- [ ] **Competition: Who are the main competitors for this opportunity? What are their perceived strengths/weaknesses?**
  ______________________________________________________________________________

---

## Section 3: EXPECTED GREEN/RED FLAGS (What Do We Expect to See/Hear?)
*Anticipate client reactions and signals to be ready to manage them.*

- **Green Flags (Expected Positive Signals indicating we are on the right track):**
  - *Example: Client actively confirming hypothesized needs, asking deeper questions about the solution, spontaneous sharing of strategic information, positive involvement of other stakeholders.*
  1. ____________________
  2. ____________________
  3. ____________________

- **Red Flags (Expected Negative Signals/Objections/Issues that may emerge):**
  - *Example: Client minimizing the problem, price/budget objections, positive references to competing solutions, lack of time/attention, internal misalignment among attendees.*
  1. ____________________
  2. ____________________
  3. ____________________
  - (Prepare a mini response strategy for the main red flags)

---

## Section 4: SPECIFIC ACTIONS TO TAKE (What Do We Need to Do Concretely?)
*Preparation translates into concrete actions.*

- [ ] **Meeting agenda defined, clear, and shared (or to be proposed at the start)?** (Attach draft agenda)

- [ ] **Supporting materials prepared and ready?** (e.g., Customized One Pager, focused brief presentation, demo (if planned), relevant case studies, Mutual Action Plan template)
  - Materials List: ____________________

- [ ] **Key Questions to ask (funnel style: Information, Problem, Impact, Benefit) prepared and ordered?**
  - Top 3 "Killer" Questions:
    1. ____________________
    2. ____________________
    3. ____________________

- [ ] **Team roles defined for the meeting (if multiple people attend)?** (Who leads, who takes notes, who manages the demo, etc.)
  - Role Details: ____________________

- [ ] **Internal coordination with other departments completed (if needed, e.g., pre-sales, technical)?**

- [ ] **Logistics confirmed?** (Address, time, video conference link, equipment tested)

- [ ] **Meeting opening strategy defined?** (How to break the ice, how to present the agenda and objectives)

- [ ] **Meeting closing strategy defined?** (How to summarize, how to ask for commitment on next steps/Mutual Action Plan)

- [ ] **Internal pre-meeting with the team for final alignment (if applicable)? Date:** ____________________

---

## Section 5: RECOVERY STRATEGY (Plan B - What Do We Do If...?)
*Be ready for the unexpected or strong negative signals.*

- **Trigger #1 (Potential Negative Situation):** Example: The key contact does not show up or is replaced at the last minute.
  - Immediate Corrective Action: ____________________

- **Trigger #2 (Potential Negative Situation):** Example: The client expresses strong skepticism or total closure on a key value area.
  - Immediate Corrective Action: ____________________

- **Trigger #3 (Potential Negative Situation):** Example: Completely new information emerges that invalidates our preparation.
  - Immediate Corrective Action: ____________________

- **Criteria for deciding to "step back" or reschedule the meeting (if the situation is immediately unrecoverable):**
  ______________________________________________________________________________

---

## Sales Rep's Final Notes / Personal Reminders:
________________________________________________________________________________
