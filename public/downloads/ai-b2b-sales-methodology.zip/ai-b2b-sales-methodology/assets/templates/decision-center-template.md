# TEMPLATE -- BUYING COMMITTEE ROLES

**Quick Reference Guide for Identifying and Managing Stakeholders**

---

## What Is the Buying Committee?

The **Buying Committee** is the group of all people who, in some way, influence or make the purchasing decision in a complex B2B sale.

**Fatal Mistake**: Believing that there is ONE single person who decides. In complex sales, the decision is always **collective**, even if there is formally one final signature.

**Goal of Buying Committee Mapping**: Identify all key roles, understand their motivations, influence, and opinion about us, to build a winning multi-stakeholder sales strategy.

---

## The Buying Committee Model: 5 Key Roles

The **Buying Committee** model identifies 5 fundamental roles that every salesperson must map and manage:

- **Champion**
- **Economic Buyer**
- **Technical Buyer**
- **User**
- **Coach**

**Important Note**: The same person can hold multiple roles simultaneously (e.g., a CIO can be both Economic Buyer and Technical Buyer).

---

## KEY CHARACTERISTICS OF THE 5 ROLES

### CHAMPION

**Who they are**: A person inside the customer's organization who has power, influence, and a personal stake in your solution winning. They actively advocate for you internally.

#### Key Characteristics

- **Actively sells on your behalf** to other stakeholders, including the Economic Buyer

- **Has political capital and credibility** within the organization

- **Stands to gain personally** from the project's success (career, visibility, solving their pain)

- **Provides inside information** about politics, competition, decision criteria, and process

- **Has access to power** -- can open doors to the Economic Buyer and other key stakeholders

#### Questions to Identify Them

- Who stands to benefit the most from this project's success?
- Who is willing to advocate for our solution in internal meetings where we are not present?
- Who provides us with candid feedback and inside information?
- Who has both influence and a personal stake in this decision?

#### Engagement Strategy

**When to engage them**:
- Early in the process -- identify and cultivate as soon as possible
- Continuously throughout the deal -- this is your most important relationship

**How to communicate**:
- **Language**: Open, collaborative, strategic -- treat them as a partner
- **Format**: Regular 1:1s, shared planning, co-creation of the business case
- **Focus**: How to help them win internally, what ammunition they need

**Tools**:
- Business case co-development
- Internal presentation support
- Competitive talking points for them to use
- Mutual Action Plan

---

### ECONOMIC BUYER

**Who they are**: The person with the final authority to approve the purchase. They have the power to say the last word, especially on budget.

#### Key Characteristics

- **Makes the final approval** before the customer can commit

- **Can approve or veto** proposals from subordinates

- **Occupies the highest position** in the customer's hierarchy for this specific deal

- **Can be a single person or a committee** (e.g., Board, Procurement Committee)

- **Has the ability to increase or decrease** the budget allocated to the project

#### Difference with Champion

- **Economic Buyer** says: "Yes, you can spend this money"
- **Champion** says: "This is the right solution and I will fight for it internally"

Often different people. The Champion sells to the Economic Buyer.

#### Questions to Identify Them

- Who has the final word on the budget for this project?
- Who must sign the contract?
- If the Champion says "yes", who still needs to approve?
- Can this person proceed independently or do they need authorization from someone else?

#### Engagement Strategy

**When to engage them**:
- Not too early (risk burning access)
- Not too late (risk that they have already decided)
- **Ideal moment**: When the Champion is already convinced and you have built a solid business case

**How to communicate**:
- **Language**: Business outcomes, ROI, strategic alignment (NO technical details)
- **Format**: 1-page executive summary, concise presentation
- **Focus**: Strategic value, mitigated risk, peer case studies

**Tools**:
- Deal One Pager
- Executive presentation (max 10 slides)

---

### TECHNICAL BUYER (Experts/Evaluators)

**Who they are**: People with specialized expertise who evaluate alternatives and provide technical or functional opinions.

#### Key Characteristics

- **Responsible for evaluating alternative solutions**

- **Express specialized judgment** based on their professional expertise

- **Offer opinions even when not asked** based on personal relationships with the Economic Buyer

- **Can say "no"** (block a solution they consider inadequate)

- **Cannot make the final decision alone** (but strongly influence it)

#### Types of Technical Buyers

- **Technical**: CTO, Architect, IT Manager (evaluate technical feasibility)
- **Functional**: Process Owner, Department Head (evaluate operational fit)
- **Legal/Compliance**: Legal Counsel, GDPR Officer (evaluate compliance)
- **Financial**: Controller, Finance Manager (evaluate ROI and budget)

#### Questions to Identify Them

- Who will evaluate the technical aspects of our solution?
- Who must give the OK from a [technical/legal/security] standpoint?
- Does the Economic Buyer rely on the opinion of any specialist?
- Who has caused solutions to be rejected in the past?

#### Engagement Strategy

**When to engage them**: **Early** -- they can block you if ignored

**How to communicate**:
- **Language**: Technical/specialist, detailed, evidence-based
- **Format**: Technical deep-dives, proof of concept, detailed documentation
- **Focus**: Feasibility, robustness, compliance, best practices

**Objective**: Obtain their **endorsement** or at least neutralize objections

**Risk**: A negative Technical Buyer can kill the deal even if the Champion is favorable

**Tools**:
- Technical documentation
- Proof of Concept (POC)
- Architecture diagrams
- Security & Compliance reports

---

### USER (End Users)

**Who they are**: People who will directly use the solution in their daily activities.

#### Key Characteristics

- **Directly benefit from the solution** offered or suffer its consequences

- **Evaluate the solution from an operational perspective** (usability, practicality)

- **Represent the end users** during the purchasing process

- **Play a fundamental role in the success of the implementation phase**

#### Why They Are Important

- **Adoption**: Without their buy-in, the solution will not be used (risk of project failure)
- **Feedback**: They know the real pain points better than anyone
- **Silent sabotage**: Hostile Users can cause the implementation to fail

**Common Mistake**: Ignoring Users because they "don't decide" -> Result: Project implemented but not adopted

#### Questions to Identify Them

- Who will use this solution daily?
- Which teams will be impacted by the change?
- Is there an end-user representative in the decision-making process?
- Who has complained about the problems our solution addresses?

#### Engagement Strategy

**When to engage them**: **Throughout the entire process** -- especially during discovery and demos

**How to communicate**:
- **Language**: Practical, operational, empathetic
- **Format**: Hands-on demos, interactive workshops, user stories
- **Focus**: Ease of use, concrete benefits in daily work, reduction of frustrations

**Objective**: Turn them into **advocates** for the solution

**Winning Tactic**: Involve them in POCs and collect positive testimonials to bring to the Economic Buyer

**Tools**:
- Interactive demos
- User workshops
- Pilot programs with their involvement
- Training previews

---

### COACH (Guides/Navigators)

**Who they are**: People who help you navigate the organization, give you "inside" information, and actively support you.

#### Key Characteristics

- **Provide important advice and guidance** throughout the sale

- **Help validate your intuitions** about the organization and its dynamics

- **Help you understand and access the Buying Committee** (make introductions, open doors)

- **Provide information about relationships** between key players (internal politics)

- **Respect and trust you**

- **Do not necessarily belong to the customer's organization** (can be consultants, partners, former colleagues)

#### Characteristics of an Effective Coach

**A good Coach**:
- Has **access** to key information
- Has **credibility** within the organization
- Has **interest** in the project's success (or in your relationship)
- Tells you the **truth**, even when it is uncomfortable

**Caution**: Not all Coaches are equal. Evaluate:
- **Real influence**: Do they actually have weight or are they marginal?
- **Reliability**: Is their information accurate?
- **Motivations**: Why are they helping you? (understand the hidden agenda)

#### Questions to Identify Them

- Who introduced me to this opportunity?
- Who in the organization gives me candid information?
- Who warned me about problems or obstacles before they surfaced?
- Who has interest in this project's success beyond the contract?

#### Engagement Strategy

**How to cultivate a Coach**:
1. **Build trust**: Be honest, keep confidences, demonstrate competence
2. **Create value for them**: Help them with their goals, not just yours
3. **Ask for feedback**: "How am I doing?", "What do you advise?"
4. **Maintain regular contact**: Don't disappear, provide updates on progress

**What to ask the Coach**:
- "Who else should I involve?"
- "How is our proposal being perceived internally?"
- "Are there obstacles I'm not aware of?"
- "What would happen if we proposed X instead of Y?"
- "Who is favorable/opposed and why?"

**Objective**: Have **at least one strong Coach** for every important opportunity

**Red Flag**: If you have no Coach, you are "navigating blind" -> Very high risk of negative surprises

---

## QUICK REFERENCE TABLE

| Role | Power | Key Question | Communication Focus | Risk if Ignored |
|------|-------|-------------|---------------------|-----------------|
| **Champion** | Very High | "Who will sell for us internally?" | How to win internally, ammunition, joint plan | No internal advocacy |
| **Economic Buyer** | Maximum | "Who signs the final contract?" | Strategic ROI, vision alignment | Final veto |
| **Technical Buyer** | High | "Who evaluates technically?" | Feasibility, robustness, compliance | Technical block |
| **User** | Medium | "Who will use it every day?" | Usability, operational benefits | Failed adoption |
| **Coach** | Indirect | "Who guides me inside the org?" | Insights, access, strategy | Blind navigation |

---

## MAPPING AND ENGAGEMENT STRATEGIES

### Step 1: Complete Identification

**Objective**: Find ALL Buying Committee roles

**Tactics**:
1. **Ask your first contact**: "Who else should be involved in this evaluation?"
2. **Review org charts**: Identify key figures by title/function
3. **Analyze processes**: Who signs? Who approves? Who implements?
4. **Leverage the Coach**: "Who are we missing in our map?"

**Completeness Checklist**:
- [ ] Economic Buyer identified (and confirmed they have budget authority)
- [ ] Champion identified (and confirmed they will advocate internally)
- [ ] At least 2-3 Technical Buyers identified (technical, functional, compliance)
- [ ] User representatives engaged
- [ ] At least 1 strong Coach cultivated

---

### Step 2: Multi-Dimensional Assessment

For each person identified, evaluate:

1. **Buying Committee Role**: What primary role do they play?
2. **Influence**: High/Medium/Low
3. **Perceived urgency**: How much do they feel the problem as a priority?
4. **Opinion about us**: From Strongly Positive (++) to Strongly Negative (--)
5. **Accessibility**: Do we have direct or indirect access?

**Tool**: Use the `buying-committee-template.md` for detailed individual mapping

---

### Step 3: Multi-Stakeholder Strategy

**Key Principle**: Each Buying Committee role requires:
- **Different** messages
- **Different** tools
- **Different** contact frequency

**Example Orchestration**:

```
WEEKS 1-2: Discovery
|- User -> Operational needs workshop
|- Technical Buyer -> Technical discovery, functional requirements
|- Champion -> Goal alignment, decision criteria

WEEKS 3-4: Solution
|- Technical Buyer -> Technical deep-dive, architecture
|- User -> Hands-on demo, proof of concept
|- Champion -> Business case, preliminary proposal

WEEKS 5-6: Proposal
|- Champion -> Formal proposal, Mutual Action Plan
|- Technical Buyer -> Final technical Q&A, security review
|- Economic Buyer -> Executive summary, ROI presentation

WEEKS 7-8: Close
|- Economic Buyer + Champion -> Final negotiation, contract
```

---

### Step 4: Monitoring and Adaptation

The Buying Committee map is **dynamic**, not static.

**Update when**:
- A new stakeholder emerges
- Someone's opinion changes (from neutral to positive, or vice versa)
- Roles or responsibilities change within the organization
- You obtain new information from the Coach

**Red Flags to Monitor**:
- Economic Buyer or Champion inaccessible (very high risk)
- Key Technical Buyer strongly negative (can block the deal)
- Users not involved (adoption risk)
- No Coach (blind navigation)
- New stakeholder emerges late in the process (can destabilize)

---

## COMMON MISTAKES AND HOW TO AVOID THEM

### Mistake #1: Single-Threading

**Problem**: Talking to only one person (typically whoever contacted us)

**Risk**:
- That person may NOT be the Economic Buyer
- You don't know the internal dynamics
- Vulnerable if that person leaves or loses influence

**Solution**: **Multi-threading** -- build relationships with at least 3-4 key stakeholders

---

### Mistake #2: Confusing Title with Buying Committee Role

**Problem**: Assuming the VP is the Economic Buyer because they have a senior title

**Reality**: Title does not always correspond to the Buying Committee role for that specific project

**Example**:
- A CIO can be the Economic Buyer for projects >$500K
- But for a $50K project, the real Economic Buyer may be an IT Manager

**Solution**: **Always qualify** the real role by asking specific questions about the decision process

---

### Mistake #3: Ignoring the Users

**Problem**: Focusing only on the Economic Buyer and Champion

**Risk**: Project approved but never adopted (silent failure)

**Solution**: **Always** involve User representatives in demos, POCs, workshops

---

### Mistake #4: Not Having a Coach

**Problem**: Trying to navigate the organization without an internal guide

**Risk**: Negative surprises, invisible obstacles, wrong strategy

**Solution**: **Actively cultivate** at least one Coach through trust, value, and relationship

---

### Mistake #5: Late Access to the Economic Buyer

**Problem**: Waiting too long to engage the Economic Buyer

**Risk**: Economic Buyer has already decided or has other priorities

**Solution**: **Progressive escalation plan** -- engage the Economic Buyer at the right moment (not too early, not too late)

---

## INTEGRATION WITH OTHER TOOLS

### Buying Committee + MEDDPICC+RR (Opportunity Qualification)

**MEDDPICC+RR Criteria 2, 3, 4, and 7** are directly informed by the completeness of your Buying Committee map.

**Scoring**:
- Green (5/5): All Buying Committee roles identified, direct access to Economic Buyer + Champion
- Yellow (3/5): Some roles not identified or access only indirect
- Red (1/5): Economic Buyer or Champion not identified, or no access

---

### Buying Committee + Business Case

Each Buying Committee role has **different decision criteria** -> The Business Case must be **multi-audience**.

**Business Case Sections by Role**:
- **For Economic Buyer**: Executive Summary with strategic ROI
- **For Champion**: Detailed Business Case with quantified benefits
- **For Technical Buyers**: Technical Appendix with architecture and specs
- **For Users**: User Stories and training plan

---

### Buying Committee + Commercial Proposal

Personalize your proposal based on who will read it:

```
Complete Proposal (for Champion / Economic Buyer)
|- Executive Summary (1 page) -> for Economic Buyer
|- Solution Overview (5-10 pages) -> for Champion
|- Technical Architecture (appendix) -> for Technical Buyers
|- Implementation & Training Plan -> for Users
```

---

### Buying Committee + Presentations

**Golden Rule**: Personalize the presentation based on the Buying Committee audience

| Audience | Total Slides | Focus | No-Go Topics |
|----------|-------------|-------|--------------|
| Economic Buyer | Max 10 | ROI, Strategy, Risk | NO technical details |
| Champion | 15-20 | Solution, Benefits, Timeline | Balanced |
| Technical Buyers | 20-30+ | Architecture, Integrations, Specs | NO marketing fluff |
| Users | 10-15 | Live demo, Usability, Training | NO strategy talk |

---

## RELATED RESOURCES

### Templates to Use

- **`buying-committee-template.md`**: Detailed individual mapping for each stakeholder
- **`meddpicc-rr-template.md`**: Includes Buying Committee access evaluation (Criteria 2, 3, 4, 7)
- **`account-plan-template.md`**: Includes Buying Committee summary section
- **`discovery-questions-template.md`**: Questions to uncover the Buying Committee

### Related Workflows

- **Mapping the Buying Committee**: Guided process for stakeholder mapping
- **Qualifying an Opportunity**: Includes stakeholder access qualification
- **Creating a Business Case**: Includes multi-audience personalization
