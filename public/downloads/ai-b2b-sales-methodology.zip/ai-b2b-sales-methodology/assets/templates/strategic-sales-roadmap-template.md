# TEMPLATE - STRATEGIC SALES ROADMAP

**Visual Planning Tool for Complex Opportunities**

---

## Opportunity Information

- **Date Created/Updated**: ____/____/________
- **Client / Prospect Name**: ________________________________
- **Account Manager**: ________________________________
- **Project**: ________________________________

---

## OPPORTUNITY DESCRIPTION

### General Information

**Opportunity History**:
```
[Insert the history of this opportunity: How did it start? Who generated it?
What is the context of the first contact?]
```

**Client's Objectives with This Project**:
```
[What does the client want to achieve? What are their business objectives?]
```

**Our Sales Objective / Proposed Solution**:
```
[What is our objective? What do we want to sell? What solution are we proposing?]
```

---

### Key Opportunity Data

| Parameter | Value |
|-----------|-------|
| **Initial Order Value** | EUR ________________ |
| **Win Probability** | ___% |
| **Client Budget** | EUR ________________ |
| **Pre-Sales Cost** | EUR ________________ |
| **Future Potential** (LTV) | EUR ________________ |
| **Expected Close Date** | ____/____/________ |

### Position in the Sales Cycle

_Indicate the current phase:_

- [ ] **Identification**: First contact, initial information gathering
- [ ] **Qualification**: MEDDPICC+RR assessment, stakeholder identification
- [ ] **Buying Committee Mapping**: Complete Buying Committee mapping
- [ ] **Proposal**: Solution presentation and commercial proposal
- [ ] **Decision**: Final negotiation and close

**Current Phase**: ________________________________

---

### Sales Team Members

| Name | Role | Responsibility |
|------|------|----------------|
| | | |
| | | |
| | | |

---

## MEDDPICC+RR QUALIFICATION COMPARISON

_Insert the MEDDPICC+RR criteria and the corresponding assessment (traffic light + score 1-5)_

| # | MEDDPICC+RR Criterion | Traffic Light | Score (1-5) | Notes |
|---|----------------------|---------------|-------------|-------|
| 1 | Metrics | green/yellow/red | ___ | |
| 2 | Economic Buyer | green/yellow/red | ___ | |
| 3 | Decision Criteria | green/yellow/red | ___ | |
| 4 | Decision Process | green/yellow/red | ___ | |
| 5 | Paper Process | green/yellow/red | ___ | |
| 6 | Implicate the Pain | green/yellow/red | ___ | |
| 7 | Champion | green/yellow/red | ___ | |
| 8 | Competition | green/yellow/red | ___ | |
| 9 | Relative Priority | green/yellow/red | ___ | |
| 10 | Risk Factors | green/yellow/red | ___ | |

**Average MEDDPICC+RR Score**: ___/5

**Strategic Decision**:
- [ ] GO (Continue to invest)
- [ ] GO WITH CONDITIONS (Resolve specific gaps)
- [ ] NO-GO (Disinvest)

---

## COMPETITIVE ANALYSIS

### Competitor #1: ________________________________

**Our Strengths Over This Competitor**:
```
[What do we do better than them? What are our specific competitive advantages?]
```

**This Competitor's Strengths Over Us**:
```
[Where are they stronger? What are their winning cards?]
```

**Their Strategy**:
```
[How are they approaching this deal? What do we know about their strategy?]
```

**Our Strategy to Win**:
```
[What competitive strategy do we adopt? (Direct/Change the Game/Partition)]
```

---

### Competitor #2: ________________________________

**Our Strengths Over This Competitor**:
```
[Insert analysis]
```

**This Competitor's Strengths Over Us**:
```
[Insert analysis]
```

**Their Strategy**:
```
[Insert analysis]
```

**Our Strategy to Win**:
```
[Insert strategy]
```

---

### Competitor #3: ________________________________

**Our Strengths Over This Competitor**:
```
[Insert analysis]
```

**This Competitor's Strengths Over Us**:
```
[Insert analysis]
```

**Their Strategy**:
```
[Insert analysis]
```

**Our Strategy to Win**:
```
[Insert strategy]
```

---

## BUYING COMMITTEE ANALYSIS

_For each member of the Buying Committee, complete the mapping:_

### Stakeholder #1: ________________________________

| Attribute | Assessment |
|-----------|------------|
| **Full Name** | ________________________________ |
| **Role in Organization** | ________________________________ |
| **Buying Committee Role** | [ ] Champion  [ ] Economic Buyer  [ ] Technical Buyer  [ ] User  [ ] Coach |
| **Degree of Influence** | [ ] High  [ ] Medium  [ ] Low |
| **Perceived Urgency** | [ ] Compelling  [ ] Significant  [ ] Low  [ ] None |
| **Opinion of Us** | [ ] ++ Enthusiastic  [ ] + Positive  [ ] 0 Neutral  [ ] - Negative  [ ] -- Hostile |

**Business Objectives**:
```
[What must they achieve for the company?]
```

**Personal Objectives**:
```
[What motivates them personally? Career, recognition, risk reduction?]
```

**Decision Criteria**:
```
[What will they base their decision on?]
```

**Strategic Notes**:
```
[Engagement strategy, contact frequency, key messages]
```

---

### Stakeholder #2: ________________________________

_[Repeat the same structure for each stakeholder]_

---

## PERSONALIZED VALUE PROPOSITION

_Build the value proposition specific to this opportunity_

### Summary of Business Objectives (and Urgency)

**From our conversations we understand that you would like to**:
```
[Summarize the key objectives that emerged from conversations with the client]

Example:
- Reduce operational costs by 15% by year-end
- Improve time-to-market for new products
- Increase sales team productivity by 20%
```

---

### Key Decision Criteria (and Budget)

**The solution you choose will need to**:
```
[List the decision criteria that emerged]

Example:
- Be implementable within 6 months
- Integrate with existing systems
- Have a demonstrable ROI within 12 months
- Include ongoing post-implementation support
```

**Discussed Budget Range**: EUR ________________

---

### Solution Description

**The proposal designed to meet your needs includes**:
```
[Describe the proposed solution in business language, not technical]

Example:
- Cloud-based platform for process automation
- Modules for workflow management and advanced reporting
- Integration with existing CRM and ERP
- Training for 50+ users
- Dedicated support for 24 months
```

---

### Solution Benefits

**Based on our experience in your industry, our solution will help you achieve**:
```
[List the quantified benefits]

Example:
- 40% reduction in time spent on manual tasks
- Estimated savings of EUR 250K annually in operational costs
- 25% productivity increase
- 60% error reduction
- Time-to-market reduced from 8 weeks to 3 weeks
```

---

### Differentiation Factors

**The strengths of our solution are based on**:
```
[Highlight unique differentiators]

Example:
- 15+ years of experience in the financial sector
- 50+ successful implementations
- Proven proprietary methodology
- Dedicated team with specific certifications
- Strategic partnership with [main vendor]
- Track record of on-time and on-budget implementations (95%)
```

---

## SUMMARY OF OUR CURRENT POSITION

### Strengths

_Rating from +1 to +5_

| Strength | Rating (+1 to +5) | Notes |
|----------|-------------------|-------|
| | | |
| | | |
| | | |

**Example Strengths**:
- Strong relationship with the CIO (Economic Buyer)
- Solution perfectly aligned with needs
- Budget confirmed and available
- No active competitors
- Highly influential internal Champion

---

### Weaknesses

_Rating from -1 to -5_

| Weakness | Rating (-1 to -5) | Notes |
|----------|-------------------|-------|
| | | |
| | | |

**Example Weaknesses**:
- Limited access to the CFO (Final Decision Maker)
- Aggressive timeline putting pressure
- Competitor with historical relationship
- Budget not yet formally approved
- Lack of case studies in the specific industry

---

## ACTION PLAN

_Who will do what and by when to advance the opportunity_

| # | What needs to be done | Who will do it | By when | Completion date | Result of the Action |
|---|----------------------|----------------|---------|-----------------|----------------------|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |

**Priority Actions**:
1. ________________________________
2. ________________________________
3. ________________________________

---

## PROGRESS CHECK

### Next Deal Review

- **Date for Progress Check**: ____/____/________
- **Participants**: ________________________________

### Critical Milestones

| Milestone | Target Date | Status |
|-----------|-------------|--------|
| | | [ ] Completed  [ ] In Progress  [ ] Pending |
| | | [ ] Completed  [ ] In Progress  [ ] Pending |
| | | [ ] Completed  [ ] In Progress  [ ] Pending |

---

## Best Practices for Using the Roadmap

### When to Use This Template

- **Complex opportunities** with long sales cycles (>3 months)
- **High-value deals** (>EUR 100K)
- **Multiple stakeholders** involved in the decision process
- **Active competitors** present
- **Periodic reviews** with management

### Update Frequency

- **Weekly** for opportunities >EUR 100K
- **Bi-weekly** for opportunities EUR 50K-100K
- **After every significant interaction** with key stakeholders
- **Before deal reviews** with the manager

### Best Practices

1. **Visualization**: Use this roadmap as a "live" document to keep open during meetings
2. **Sharing**: Share with the sales team for alignment
3. **Continuous updating**: Don't wait until end of week, update in real-time
4. **Honesty**: Be brutally honest in evaluating strengths/weaknesses
5. **Action-oriented**: Every weakness must have a corrective action in the Action Plan

---

## Integration with Other Tools

### With Buying Committee Detailed Template
The "Buying Committee Analysis" section of this roadmap is a summary. For each key stakeholder, also complete the **individual Buying Committee sheet** (`buying-committee-template.md`).

### With MEDDPICC+RR
The "MEDDPICC+RR Comparison" section is a summary. The **full MEDDPICC+RR** (`meddpicc-rr-template.md`) contains the detailed qualification analysis.

### With Meeting Memo
After every meeting with stakeholders, send the **Meeting Memo** (`meeting-memo-template.md`) and update the roadmap with the newly gathered information.

### With MAP (Mutual Action Plan)
The "Action Plan" of the roadmap includes both internal actions and actions shared with the client. Shared actions should be formalized in the **MAP** (`mutual-action-plan-template.md`).

---

## Common Mistakes to Avoid

**Static roadmap** (bad): Fill it in once and forget about it
**Living roadmap** (good): Continuously update with new information

**Excessive optimism** (bad): Painting everything rosy ignoring red flags
**Brutal realism** (good): Honestly document weaknesses and risks

**Superficial competitive analysis** (bad): "There are no competitors"
**Competitive intelligence** (good): Assume there is always competition (including status quo)

**Generic action plan** (bad): "Do follow-up"
**Specific actions** (good): "John calls the CFO by Friday to schedule a technical demo meeting"

**Only quantitative data** (bad): Numbers without context
**Qualitative + Quantitative** (good): Numbers with insights on relational dynamics and politics

---

## Completeness Checklist

Before presenting this roadmap in a deal review, verify:

- [ ] All reference data is complete and up-to-date
- [ ] MEDDPICC+RR completed with honest (not optimistic) assessments
- [ ] All known competitors mapped with defined strategy
- [ ] At least 3-5 key stakeholders mapped with Buying Committee roles
- [ ] Value proposition personalized and specific for this client
- [ ] Strengths and weaknesses identified with realistic assessments
- [ ] Action plan has owner and dates for every action
- [ ] Next deal review scheduled with defined participants
- [ ] Document shared with the manager and the team
