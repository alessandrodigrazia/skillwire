# Module 1: Tactical Selling - The 4-Phase Sales Conversation Framework

## Table of Contents

1. [Introduction](#introduction)
2. [The 4-Phase Sales Conversation Framework](#the-4-phase-sales-conversation-framework)
   - [Phase 1: Trust Building](#phase-1-trust-building)
     - [The Trust Equation](#the-trust-equation)
     - [Practical Trust-Building Techniques](#practical-trust-building-techniques)
   - [Phase 2: Discovery](#phase-2-discovery)
     - [The 7 Strategic Discovery Areas](#the-7-strategic-discovery-areas)
     - [The SPICED Framework for Discovery Questions](#the-spiced-framework-for-discovery-questions)
     - [Advanced Questioning Techniques](#advanced-questioning-techniques)
   - [Phase 3: Solution Design](#phase-3-solution-design)
     - [The FAB Model (Features, Advantages, Benefits)](#the-fab-model-features-advantages-benefits)
     - [Effective Presentation Techniques](#effective-presentation-techniques)
     - [The Perfect One-Pager](#the-perfect-one-pager)
   - [Phase 4: Closing](#phase-4-closing)
     - [Types of Close](#types-of-close)
     - [The Strategic Closing Action](#the-strategic-closing-action)
     - [Handling Objections](#handling-objections)
     - [Acceleration Techniques](#acceleration-techniques-without-being-aggressive)
3. [Integrating the 4 Phases with Other Frameworks](#integrating-the-4-phases-with-other-frameworks)
4. [4-Phase Post-Meeting Checklist](#4-phase-post-meeting-checklist)
5. [Common Mistakes to Avoid](#common-mistakes-to-avoid)
6. [Success Metrics for the 4-Phase Framework](#success-metrics-for-the-4-phase-framework)
7. [Additional Resources](#additional-resources)
8. [Conclusion](#conclusion)

---

## Introduction

**Tactical Selling** is the foundation of every successful sales interaction. The **4-Phase Sales Conversation Framework** — Trust Building, Discovery, Solution Design, and Closing — provides a repeatable structure for leading effective sales conversations, building trust, uncovering real needs, and guiding buyers toward informed decisions.

---

## The 4-Phase Sales Conversation Framework

### Phase 1: Trust Building

Trust is the fundamental prerequisite for any complex sale. Without trust, even the perfect solution will not be purchased.

#### The Trust Equation

Developed by **David Maister and Charles Green** in *The Trusted Advisor*, the Trust Equation provides a practical model for understanding and building trust:

```
T = (C + R + I) / S

Where:
- T = Trust
- C = Credibility
- R = Reliability
- I = Intimacy
- S = Self-Orientation
```

**Components to Maximize:**

1. **Credibility (C)**:
   - Technical and domain expertise
   - Relevant references and case studies
   - Ability to speak the client's language
   - **Action**: Demonstrate expertise with concrete examples, not generic claims

2. **Reliability (R)**:
   - Always deliver on promises
   - Punctuality and systematic follow-up
   - Consistency in behavior over time
   - **Action**: Do what you say you will do, every time. Small promises kept build lasting trust

3. **Intimacy (I)**:
   - Active and empathetic listening
   - Understanding the personal context, not just the business context
   - Ability to create genuine human connection
   - **Action**: Show authentic interest in the client as a person, not just as a "target"

**Component to Minimize:**

4. **Self-Orientation (S)**:
   - Focus on the client, not on yourself or your quota
   - Avoid language centered on "we", "our solution"
   - Do not push toward the sale prematurely
   - **Action**: Replace phrases like "We want to sell you..." with "Your goal is..."

#### Practical Trust-Building Techniques

- **Preparation**: Deep research before the meeting (industry trends, company news, stakeholder profiles)
- **Active Listening**: Maintain a 70% listening / 30% speaking ratio
- **Vulnerability**: Acknowledge when you do not have an answer — then follow up
- **Client Language**: Use the client's jargon, metrics, and internal terminology
- **Bring Value**: Every interaction must leave the client with new insights or perspectives they did not have before

---

### Phase 2: Discovery

Discovery is not an interrogation. It is an exploratory conversation that surfaces latent needs and hidden urgencies.

#### The 7 Strategic Discovery Areas

Every complex opportunity requires systematic exploration of these 7 dimensions:

1. **Current Situation**
   - "Can you describe the current environment you are operating in?"
   - "How does process X work today?"
   - Objective: Establish an objective baseline

2. **Pain Points & Challenges**
   - "What are the main challenges you are facing?"
   - "What is not working as you would like?"
   - Objective: Identify perceived problems

3. **Business Impact**
   - "How does this challenge impact your business objectives?"
   - "Can you quantify the impact in terms of cost, revenue, or time?"
   - Objective: Quantify the cost of inaction

4. **Urgency and Priority**
   - "Why now? Why not six months from now?"
   - "Are there critical events or deadlines that make action urgent?"
   - Objective: Understand timing and create urgency

5. **Future State Vision**
   - "What would the ideal situation look like?"
   - "What changes when this problem is solved?"
   - Objective: Co-create an aspirational vision

6. **Decision-Making Process**
   - "How do you typically make decisions of this type?"
   - "Who else is involved beyond yourself?"
   - Objective: Map the Buying Committee (Champion, Economic Buyer, Technical Buyer, User, Coach)

7. **Success Criteria**
   - "How will we measure the success of this initiative?"
   - "What are the must-haves versus nice-to-haves?"
   - Objective: Define evaluation criteria

#### The SPICED Framework for Discovery Questions

Developed by **Jacco van der Kooij** at **Winning by Design**, the SPICED framework provides a structured method for building effective discovery questions:

- **S (Situation)**: Context and baseline
  - "What is your current situation regarding X?"

- **P (Pain)**: Problems and challenges
  - "What obstacles are you encountering?"

- **I (Impact)**: Business impact
  - "How does this problem impact [critical metric]?"

- **CE (Critical Event)**: Critical events, urgency, and timing
  - "Is there an event or deadline that makes this critical?"
  - "Why now? What has changed that makes it urgent to address this?"

- **D (Decision)**: Decision-making process
  - "How will you typically proceed after this exploratory phase?"

#### Advanced Questioning Techniques

1. **Reframe Questions**: Challenge implicit assumptions
   - "Have you considered that the problem might not be X, but Y?"

2. **Provocative Questions** (Challenger Sale approach)
   - "What if I told you that your competitors are already addressing this in a fundamentally different way?"

3. **Deepening Questions**:
   - "Can you elaborate on what you mean by...?"
   - "Can you give me a concrete example?"

4. **Hypothetical Questions**:
   - "If you had a magic wand, what would you change?"

5. **Silence as a Tool**: After a powerful question, wait. Silence generates reflection and often surfaces the most honest answers.

---

### Phase 3: Solution Design

Never present the solution before completing a thorough discovery. The solution must be the logical response to the needs that emerged.

#### The FAB Model (Features, Advantages, Benefits)

Many salespeople stop at Features. The best translate everything into Benefits.

**FAB Structure:**

1. **Feature (F)**: What the product/service does
   - Objective description of the functionality
   - Technical language when appropriate
   - Example: "Our platform uses ML for predictive analytics"

2. **Advantage (A)**: How it works in practice
   - Connection between feature and real-world application
   - Translation into operational context
   - Example: "This means you can predict equipment failures before they happen"

3. **Benefit (B)**: Why it matters to THIS CLIENT
   - Impact on the client's KPIs and business objectives
   - Quantified value whenever possible
   - Direct connection to pain points uncovered during discovery
   - Example: "In your case, where machine downtime costs $50K/hour, this translates to an estimated annual savings of $2M"

**FAB Translation Table:**

| Feature | Advantage | Benefit (Client-Specific) |
|---|---|---|
| Real-time dashboard | Instant visibility into critical KPIs | Faster decisions, reducing time-to-market by 30% |
| API integration with SAP | Automatic data synchronization | Elimination of manual errors, saving 200 hours/month |
| AI-powered chatbot | 24/7 customer support | 25% increase in customer satisfaction + reduced contact center costs |

#### Effective Presentation Techniques

1. **Storytelling**: Use narrative case studies, not bullet points
   - "A client in your industry had exactly the same challenge..."

2. **Visualization**: Show, do not tell
   - Live demos, prototypes, mockups
   - "Before/After" scenarios

3. **Social Proof**: Leverage credible references
   - "We have worked with 15 of the top 20 companies in your sector..."

4. **Quantification**: Use concrete numbers
   - "Average ROI of 240% in 18 months"
   - "Time-to-value of 90 days"

5. **Customization**: Tailor the presentation to the stakeholder's role
   - CFO: Focus on costs, ROI, financial risk
   - CTO: Focus on architecture, scalability, security
   - CEO: Focus on strategy, competitive advantage, transformation

#### The Perfect One-Pager

After every meeting, leave a one-page document that summarizes:
- **Their problem** (in their own words)
- **Your proposed solution** (specific to their context)
- **Expected value** (quantified)
- **Next steps** (clear action items)

---

### Phase 4: Closing

"Closing" does not mean forcing a signature. It means obtaining a **concrete, measurable commitment** to advance in the process.

#### Types of Close

1. **Hard Close**: Direct request for signature/order
   - "Are you ready to proceed with the order?"
   - Use only when all criteria are satisfied

2. **Soft Close**: Incremental next step
   - "Can we schedule a technical workshop with your team?"
   - "Can I prepare a formal proposal by Friday?"

3. **Trial Close**: Temperature check
   - "How does what we have discussed so far sound to you?"
   - "Are there aspects you would like to explore further?"

#### The Strategic Closing Action

A strong closing action must be:

- **Specific**: Not "let's stay in touch", but "let's schedule a meeting with the CFO for March 15"
- **Value-based**: What does the client gain by investing more time?
  - "In the next meeting, I will present a quantified business case based on your data"
- **Mutually committed**: Not one-sided
  - "You prepare the current cost data, I will prepare the comparative analysis"
- **Time-bound**: With a clear deadline
  - "I will send the document by Friday. Can we reconvene next Tuesday?"

#### Handling Objections

Objections are not rejections. They are requests for more information or reassurance.

**Objection Handling Framework:**

1. **Listen fully**: Do not interrupt
2. **Validate the objection**: "I understand your concern..."
3. **Clarify**: "Can you elaborate on what you mean by...?"
4. **Reframe**: Reposition in terms of opportunity
5. **Respond with evidence**: Case studies, data, references
6. **Confirm resolution**: "Does this address your concern?"

**Common Objections and Strategic Responses:**

| Objection | Strategic Reframe |
|---|---|
| "It's too expensive" | "I understand. Let's compare the cost of the investment with the cost of inaction. In your case, we estimate the current problem costs $X/year..." |
| "Now is not the right time" | "I appreciate the transparency. May I ask: what needs to happen for it to become the right time? And what is the cost of waiting?" |
| "We need to think about it" | "Absolutely. To help you reflect in a structured way, what are the 2-3 key factors you will be evaluating?" |
| "We already have a vendor" | "That is positive — you have an existing relationship. May I ask: how satisfied are you on a scale of 1-10? What would need to improve to reach a 10?" |

#### Acceleration Techniques (Without Being Aggressive)

1. **Urgency Creation**: Connect to critical events
   - "Your CEO stated that digital transformation is a top priority for this fiscal year. How does this initiative fit in?"

2. **FOMO (Fear of Missing Out)**: Opportunity cost
   - "Your competitors are already implementing similar solutions..."

3. **Limited Availability**: Genuine scarcity
   - "Our implementation team is available starting in April. If we wait, the next window is September"

4. **Time-Bound Incentives**: Offers with a deadline
   - "If we proceed by end of Q1, we can include X in the scope at no additional cost"

---

## Integrating the 4 Phases with Other Frameworks

### 4-Phase Framework + MEDDPICC+RR
Use the 4-phase framework in your initial interactions to qualify the opportunity against MEDDPICC+RR criteria. The Discovery phase questions directly feed into Metrics, Economic Buyer, Decision Criteria, Decision Process, Paper Process, Identified Pain, Champion, Competition, Relative Priority, and Risk Factors.

### 4-Phase Framework + Buying Committee
During Discovery, map the Buying Committee roles: Champion, Economic Buyer, Technical Buyer, User, and Coach. Adapt your Solution Design and Closing approach based on which role you are engaging with.

### 4-Phase Framework + Negotiation
The information gathered during Discovery defines your BATNA and ZOPA. The Closing phase can be the starting point for formal negotiation (see Module 3: Negotiation).

---

## 4-Phase Post-Meeting Checklist

After every meeting, evaluate your performance:

**Phase 1 — Trust Building:**
- [ ] Did I demonstrate industry-specific expertise?
- [ ] Did I deliver on all promises (even small ones)?
- [ ] Did I listen more than I spoke?
- [ ] Did I minimize self-centered language?

**Phase 2 — Discovery:**
- [ ] Did I explore all 7 strategic discovery areas?
- [ ] Did I quantify the impact of their problems?
- [ ] Did I identify critical events that create urgency?
- [ ] Did I at least partially map the Buying Committee?

**Phase 3 — Solution Design:**
- [ ] Did I connect every feature to specific benefits for them?
- [ ] Did I use relevant case studies and examples?
- [ ] Did I customize the presentation for the stakeholder's role?
- [ ] Did I leave a one-pager or summary document?

**Phase 4 — Closing:**
- [ ] Did I obtain a concrete, scheduled next step?
- [ ] Does the next step deliver clear value for the client?
- [ ] Did I handle objections using the Listen-Validate-Reframe framework?
- [ ] Am I clear on the qualification level of this opportunity?

---

## Common Mistakes to Avoid

1. **Presenting too early**: Do not skip discovery to get to the demo
2. **Feature dumping**: Do not list every feature — focus on benefits relevant to this client
3. **Ignoring signals**: Active listening includes body language and tone of voice
4. **Aggressive closing**: Pushing before the client is ready destroys trust
5. **Missed follow-up**: Failing to deliver on commitments is fatal to the relationship
6. **Forgetting WIIFM**: "What's In It For Me" — always view the conversation from the client's perspective

---

## Success Metrics for the 4-Phase Framework

**Tactical Indicators (per meeting):**
- Self-assessed Trust Score (1-10)
- Number of open-ended questions asked
- Listening/speaking ratio (target: 70/30)
- Next step secured (Yes/No)
- Seniority level of stakeholders engaged

**Strategic Indicators (per opportunity):**
- Velocity of progression through sales stages
- Number of stakeholders engaged
- Quality of information obtained (MEDDPICC+RR completeness)
- Win rate on qualified opportunities

---

## Additional Resources

- **SPICED Playbook** (Winning by Design): Library of 100+ discovery questions by industry
- **FAB Template**: Worksheet for translating features into client-specific benefits
- **Trust Equation Calculator** (Maister/Green): Tool for assessing your trust level with each stakeholder
- **One-Pager Templates**: Templates for 10 common sales scenarios

---

## Conclusion

The 4-Phase Sales Conversation Framework — Trust Building, Discovery, Solution Design, Closing — is simple to remember but requires practice to master. The difference between an average salesperson and an elite one is not knowledge of the framework, but the discipline to apply it **systematically, in every interaction**.

**Next Steps:**
- Study **Module 2: Strategic Selling** to apply this framework to complex multi-stakeholder opportunities
- Practice with internal role-plays using this structure
- Record your calls (with permission) and analyze them against the 4-phase framework
