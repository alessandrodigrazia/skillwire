# Workflow: Create C-SWOT Analysis

**Purpose**: Analyze the customer's strategic position to identify leverage points for your value proposition.

**Duration**: 15-20 minutes
**Output**: 4-quadrant C-SWOT matrix with strategic implications

---

## When to Use

- Early in opportunity (pre-proposal)
- Before creating value propositions or business case
- When you need to understand customer's competitive position
- As input to meeting preparation workflow

---

## What Is C-SWOT?

**C-SWOT** = Customer SWOT. Analyze the prospect from THEIR perspective:
- **Strengths**: What competitive advantages do they have?
- **Weaknesses**: Where are they vulnerable?
- **Opportunities**: What market opportunities could they capture?
- **Threats**: What external factors threaten them?

**This is NOT about YOU. It's about understanding THEM deeply.**

---

## The Process

### Step 1: Information Gathering

**Questions I'll Ask**:
1. "What's the customer's industry and business model?"
2. "Who are their competitors?"
3. "What are they known for? (brand, market position)"
4. "What challenges have they mentioned?"
5. "Any documents to analyze?" (website, annual reports, news)

### Step 2: SWOT Analysis

For each quadrant, I'll help you identify 3-5 elements with strategic implications.

#### Output Structure

```markdown
# C-SWOT Analysis: [Company Name]

## STRENGTHS (Internal Advantages)

### 1. [Strength Title]
- **Description**: What they do well
- **Impact**: HIGH/MEDIUM/LOW
- **Implication for Us**: How we position relative to this

[Example]
### 1. Strong Brand Legacy
- **Description**: 80 years in market, trusted by fortune 500
- **Impact**: HIGH
- **Implication**: Position as "partner that protects legacy while enabling innovation"

## WEAKNESSES (Internal Vulnerabilities)

### 1. [Weakness Title]
- **Description**: Where they struggle
- **Impact**: CRITICAL/HIGH/MEDIUM
- **Implication for Us**: This is a pain point we can solve

[Example]
### 1. Legacy Technology Stack
- **Description**: 25-year-old mainframe, slow to change
- **Impact**: CRITICAL
- **Implication**: PRIMARY VALUE DRIVER - our modernization story is core

## OPPORTUNITIES (External Potential)

### 1. [Opportunity Title]
- **Description**: Market opportunity they could capture
- **Impact**: HIGH/MEDIUM/LOW
- **Implication for Us**: How we enable them to capture this

[Example]
### 1. Digital-Native Customer Segment
- **Description**: Millennials/Gen-Z underserved by their current offering
- **Impact**: HIGH (€30M addressable market)
- **Implication**: Our omnichannel platform unlocks this segment

## THREATS (External Risks)

### 1. [Threat Title]
- **Description**: External factor threatening their business
- **Impact**: CRITICAL/HIGH/MEDIUM
- **Implication for Us**: How we mitigate this threat

[Example]
### 1. Insurtech Disruption
- **Description**: 5 digital-first competitors entered market in 2 years
- **Impact**: CRITICAL (losing 18% market share in under-35 segment)
- **Implication**: Urgency driver - must modernize to compete

---

## STRATEGIC SYNTHESIS

**Primary Value Angle**: [Based on most critical weakness + highest opportunity]

**Urgency Drivers**: [Threats that create "why now"]

**Differentiation**: [How we leverage their strengths while addressing weaknesses]

**Risk to Address**: [Concerns they'll have based on SWOT]
```

---

## Using C-SWOT Results

### → Feed into Value Areas
Weaknesses + Opportunities = Your value propositions

### → Feed into Business Case
Quantify the cost of weaknesses + value of opportunities

### → Feed into Discovery Questions
Validate your SWOT hypotheses in meetings

### → Feed into Competitive Strategy
Understand how competitors might position against their weaknesses

---

## Getting Started

Tell me:
1. Customer name and industry
2. What you know about their business
3. Any research materials (optional)

I'll guide you through building a strategic C-SWOT analysis.

**Ready? Let's analyze your customer's strategic position.**
