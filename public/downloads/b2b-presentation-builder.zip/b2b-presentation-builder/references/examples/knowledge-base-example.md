# Example Knowledge Base

This is an example showing how to structure a company knowledge base for use with the B2B Presentation Builder skill. Replace all content below with your own company information.

## Company Overview

**[Your Company]** is the [practice/division] of **[Parent Company]** focused on [domain]. We help organizations [primary value proposition].

**Parent Company:** [Parent Company Name] ([size], [geographic presence])
**Focus:** [Your domain/specialty]
**Positioning:** [Your positioning statement]
**Target:** [Your ideal customer profile]

## Core Positioning

### Motto
**"[Your Motto]"**

### Tagline
**"[Your Tagline - one sentence that captures your unique approach]"**

### Elevator Pitch
> "[Your Company] helps organizations [solve what problem]. We apply [your unique framework/method]. We're [positioning]: we don't just [commodity alternative], we [differentiated value]."

### Value Promise
**"[Your promise in 5-7 words]"**

## Core Differentiator (Your Framework)

### The [Framework Name]
Describe your unique methodology or framework here. Example structure:

**[X]% -- Visible Part**
- What clients see and expect

**[Y]% -- Invisible Part**
- What actually determines success
- The foundations most competitors ignore

### Why It Matters
Explain why your framework matters and what happens without it.

## Your Method: [N] Phases

| Phase | Name | What We Do |
|-------|------|------------|
| 1 | **[Phase 1]** | [Description] |
| 2 | **[Phase 2]** | [Description] |
| 3 | **[Phase 3]** | [Description] |
| 4 | **[Phase 4]** | [Description] |
| 5 | **[Phase 5]** | [Description] |

## Commercial Modules (Entry Points)

### Module 1: [Name]
**Investment:** [Range]
**What it delivers:** [Output]

### Module 2: [Name]
**Investment:** [Range]
**What it delivers:** [Output]

### Module 3: [Name]
**Investment:** [Range]
**What it delivers:** [Output]

## Key Differentiators

### vs [Competitor Type 1]
**Their strength:** [What they do well]
**Their weakness:** [Where they fall short]
**Your counter:** [Your differentiated response]

### vs [Competitor Type 2]
**Their strength:** [What they do well]
**Their weakness:** [Where they fall short]
**Your counter:** [Your differentiated response]

### vs "Wait and See"
**Your counter:** [Why acting now matters]

## Value Proposition Templates

### For CFO:
> [ROI-focused value proposition]

### For CIO/CTO:
> [Technical value proposition]

### For CEO:
> [Strategic value proposition]

## Key Messaging Principles

### Lead with Problem, Not Solution
### Quantify Everything
### Use "You" Language
### Create Urgency Without Fear
### Be Specific About Investment
### Be Honest About Outcomes

## Common Objections and Responses

### "[Objection 1]"
> [Your response]

### "[Objection 2]"
> [Your response]

## Contact Information

**[Your Name]**
[Your Role], [Your Company]
Email: [your.email@company.com]
Phone: [+XX XXX XXX XXXX]
Website: [www.yourcompany.com]
