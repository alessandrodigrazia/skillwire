# Narrative Frameworks

Framework narrativi evidence-based per sales deck B2B ad alta conversione. Questi framework sostituiscono la generica struttura "3-act" con sequenze operative validate da casi reali.

## Framework Selection

| Framework | Quando usare | Forza principale |
|-----------|--------------|------------------|
| Raskin 5-Step | Mercati in disruption, nuova categoria | Crea urgenza attraverso "Big Shift" |
| Dunford 8-Step | Mercati con alto "no decision" (40-60%) | Gestisce paura di sbagliare |
| Challenger 6-Step | Pitch educational, reframe di assunzioni | Forza cambio prospettiva |

---

## Raskin 5-Step Framework (The Greatest Sales Deck)

Validato dal deck Zuora, definito da Andy Raskin "il miglior sales deck mai visto". Struttura usata da Zuora, Salesforce, Drift.

### Principio fondamentale

**Non si inizia MAI con il prodotto.** Si inizia con un cambiamento nel mondo che crea urgenza. Il prodotto è lo strumento che permette di sopravvivere/vincere nel nuovo mondo.

### I 5 Step

#### Step 1: Name a Big, Relevant Shift in the World

**Scopo:** Creare contesto e urgenza senza parlare di te.

**Pattern:** "[Affermazione su come il mondo è cambiato]"

**Esempio Zuora:**
> "We live in a Subscription Economy" #shifthappens

**Esempio Salesforce:**
> "We're in the Fourth Wave of Computing" (Mainframes → Client-Server → Web → Cloud)

**Esempio Drift:**
> [Immagine persona che dorme col telefono] "She practically sleeps with her phone"

**Regole:**
- Nessuna menzione del prodotto
- Nessuna storia aziendale
- Nessun "siamo leader di mercato"
- Solo un'affermazione sul MONDO, non su di te

#### Step 2: Show There Will Be Winners and Losers

**Scopo:** Creare stakes attraverso loss aversion (2-3x più potente del gain seeking).

**Pattern:** "Chi abbraccia [shift] prospera. Chi lo ignora scompare."

**Esempio Zuora:**
> "In the last 15 years, 52% of Fortune 500 companies have disappeared"
> [Visual: foto Blockbuster chiuso]

**Esempio Drift:**
> "Email isn't real-time. Email gets abused. Email is not smart."
> [Tre slide consecutive che demoliscono il vecchio paradigma]

**Regole:**
- Mostra aziende che hanno fallito ignorando il shift
- Mostra aziende che hanno vinto abbracciandolo
- Domanda implicita: "Sarai un winner o un loser?"

#### Step 3: Tease the Promised Land

**Scopo:** Definire la destinazione desiderabile (NON il tuo prodotto).

**Pattern:** "Per vincere nel [nuovo mondo], devi diventare [tipo di azienda con caratteristiche X, Y, Z]"

**Esempio Zuora:**
> "Winners will be: RELATIONSHIP business (customer, not product centric), OUTCOMES business (usage drives value), RECURRING revenue business"

**Critico:** La Promised Land NON è "avere il tuo prodotto". È come sarà la VITA del prospect grazie al tuo prodotto. Questo permette al champion interno di pitchare con una visione, non una lista di feature.

#### Step 4: Introduce Features as "Magic Gifts"

**Scopo:** Posizionare le feature come strumenti per raggiungere la Promised Land.

**Pattern:** "Per diventare [tipo di azienda vincente], hai bisogno di [capability 1], [capability 2], [capability 3]"

**Analogia:** Tu sei Obi-Wan che dà la spada laser a Luke. Luke è l'eroe, non tu. Le feature sono "magic gifts" per il viaggio dell'eroe.

**Esempio Zuora:**
> Per ogni capability, mostrano confronto "Old World" vs "New World"
> - Old: Product-centric → New: Customer-centric
> - Old: One-time sale → New: Ongoing relationship

**Regole:**
- Max 3-5 capability
- Ogni capability collegata a un aspetto della Promised Land
- Visual che contrasta vecchio vs nuovo paradigma

#### Step 5: Present Evidence You Can Make the Story Come True

**Scopo:** Provare che puoi effettivamente portarli alla Promised Land.

**Pattern:** Testimonial che parla della TRASFORMAZIONE, non delle feature.

**Esempio Zuora (quote NCR):**
> "Our transformation wouldn't have happened without Zuora"

**Regole:**
- Le prove parlano della Promised Land raggiunta
- Non "il prodotto funziona bene"
- Ma "siamo diventati l'azienda che volevamo essere"

### Struttura Slide Raskin

| # | Tipo | Contenuto |
|---|------|-----------|
| 1-3 | Big Shift | Il mondo è cambiato. Ecco come. |
| 4-6 | Winners/Losers | Chi ha abbracciato il cambiamento prospera. Chi no, scompare. |
| 7-8 | Promised Land | Per vincere, devi diventare questo tipo di azienda. |
| 9-12 | Magic Gifts | Ecco le capability che ti servono per arrivarci. |
| 13-15 | Evidence | Ecco chi ci è già arrivato con noi. |

---

## April Dunford 8-Step Framework

Ottimizzato per mercati dove **40-60% dei deal finiscono in "no decision"**. I buyer temono di sbagliare più di perdere l'opportunità.

### Principio fondamentale

**Vendi "Why Change" PRIMA di "Why Us".** Il competitor principale non è un'altra azienda—è lo status quo.

### Gli 8 Step

#### Setup Phase (Step 1-3)

**Step 1: Insight**
Cosa devono sapere per capire il tuo valore differenziato?

Pattern: "Molti [audience] credono [assunzione comune]. In realtà, [insight controintuitivo]."

**Step 2: Alternative Approaches**
Pro/contro di ogni opzione, incluso "non fare nulla".

Pattern: "Puoi fare X, ma [limitazione]. Puoi fare Y, ma [limitazione]. Puoi non fare nulla, ma [costo dell'inazione]."

**Step 3: The Perfect World**
Definisci l'ideale PRIMA di mostrare il prodotto.

Pattern: "L'approccio ideale dovrebbe [criterio 1], [criterio 2], [criterio 3]."

#### Follow-through Phase (Step 4-8)

**Step 4: Introduce Your Company/Solution**
Solo ORA parli di te.

**Step 5: Differentiated Value**
Cosa puoi offrire che SOLO tu puoi offrire?

**Step 6: Enabling Features**
Le feature che rendono possibile il valore differenziato.

**Step 7: Proof**
Evidence che il valore differenziato è reale.

**Step 8: The Ask**
CTA chiara e specifica.

### Struttura Slide Dunford

| # | Step | Focus |
|---|------|-------|
| 1 | Title | Positioning statement |
| 2-3 | Insight | Il mercato crede X. La realtà è Y. |
| 4-5 | Alternatives | Opzioni disponibili e loro limiti |
| 6 | Perfect World | Criteri dell'approccio ideale |
| 7-8 | Solution | Come tu soddisfi quei criteri |
| 9 | Differentiated Value | Cosa solo tu puoi offrire |
| 10 | Features | Come lo rendi possibile |
| 11-12 | Proof | Case study focalizzati sul valore differenziato |
| 13 | Ask | Next step specifico |

---

## Challenger 6-Step Choreography

Per pitch educational dove devi sfidare le assunzioni del prospect. Basato su ricerca CEB: Challenger rappresentano >50% dei top performer.

### I 6 Step

| Step | Nome | Scopo |
|------|------|-------|
| 1 | Warmer | Dimostra comprensione del loro mondo |
| 2 | Reframe | Sfida un'assunzione che hanno sul loro business |
| 3 | Rational Drowning | Quantifica il problema in modo schiacciante |
| 4 | Emotional Impact | Connetti i numeri a conseguenze personali |
| 5 | New Way | Presenta un approccio alternativo |
| 6 | Your Solution | Solo ora, come TU abiliti quel nuovo approccio |

### Applicazione pratica

**Step 2 (Reframe) - Esempio:**
> "Molti CFO misurano il successo AI guardando ai pilot completati. Ma il 75% dei pilot che 'funzionano' non scala mai in produzione. Il vero KPI è pilot-to-production rate."

**Step 3 (Rational Drowning) - Esempio:**
> "Con un pilot-to-production rate del 25%, state investendo €400K/anno in AI per ottenere €100K di valore. Il restante €300K è puro spreco."

**Step 4 (Emotional Impact) - Esempio:**
> "Ogni pilot fallito significa un team che perde fiducia nell'AI, un budget che non verrà rinnovato, e 18 mesi di vantaggio competitivo regalato ai competitor."

---

## Regole Quantificate (Evidence-Based)

Dati empirici da Gong Labs (67.149+ presentazioni analizzate).

### La Regola dei 9 Minuti

**Dato:** Ogni deal chiuso ha coinvolto presentazioni ≤9 minuti. I deal persi avevano presentazioni medie di 11.4 minuti.

**Applicazione:** 
- Introdurre un "brain-perking change of pace" dopo 9 minuti
- Non parlare per più di 9 minuti consecutivi senza interazione
- Se il deck richiede più tempo, inserire break naturali (domande, demo, discussione)

### La Regola dei 2 Minuti sulla Company Intro

**Dato:** Presentazioni con >2 minuti di company intro hanno close rate significativamente inferiore.

**Applicazione:**
- Company intro ≤2 minuti (1-2 slide max)
- Mai iniziare con storia aziendale, fondatori, mission statement
- Le credenziali vengono DOPO il valore, non prima

### Timing del Social Proof

**Dato:** Social proof introdotto troppo presto riduce close rate del 47%.

**Applicazione:**
- Mai aprire con loghi clienti o testimonial
- Proof viene DOPO aver stabilito il problema e la soluzione
- Sequenza: Problem → Solution → THEN Proof
- Proof parla della Promised Land raggiunta, non delle feature

### Il "No Decision" come Competitor #1

**Dato:** 40-60% dei processi B2B finisce in "no decision" (status quo vince).

**Applicazione:**
- Vendere "Why Change" prima di "Why Us"
- Quantificare il costo dell'inazione
- Loss aversion: 2-3x più potente di gain seeking
- Frame: "Ogni [periodo] senza [soluzione] costa [amount] in [conseguenza]"

---

## Opening Anti-Pattern

Frasi da NON usare mai nelle prime slide:

| ❌ Da evitare | ✅ Alternativa |
|--------------|----------------|
| "Grazie per avermi invitato" | [Vai dritto al Big Shift] |
| "Vi parlerò di..." | [Mostra il cambiamento nel mondo] |
| "Prima di iniziare, una breve intro su di noi" | [La tua intro viene dopo il valore] |
| "Siamo leader di mercato in..." | [Dimostralo con risultati, non dichiararlo] |
| "Fondata nel [anno]..." | [Nessuno si interessa della tua storia] |

### Pattern Interrupt per Opening

Se devi catturare attenzione in 7 secondi (dato Harvard):

**Action Title (McKinsey style):**
- ❌ "Analisi di Mercato Q3"
- ✅ "Tre mercati inesplorati potrebbero guidare il 40% della crescita ricavi"

**Statistica Controintuitiva:**
- "Il 52% delle Fortune 500 del 2000 non esiste più."

**Domanda Provocatoria:**
- "Cosa succederebbe se i vostri competitor avessero un vantaggio di 18 mesi che non potete più recuperare?"

---

## Framework Comparison Matrix

| Criterio | Raskin 5-Step | Dunford 8-Step | Challenger 6-Step |
|----------|---------------|----------------|-------------------|
| Mercato ideale | Disruption, nuova categoria | Alto "no decision", paura | Educational, reframe necessario |
| Opening | Big Shift nel mondo | Insight controintuitivo | Warmer + comprensione |
| Gestione competitor | Winners vs Losers | Alternative approaches | N/A (focus su status quo) |
| Momento prodotto | Step 4 (Magic Gifts) | Step 4 (dopo Perfect World) | Step 6 (fine) |
| Forza emotiva | Loss aversion (scomparire) | Paura di sbagliare | Rational + Emotional drowning |
| Proof focus | Trasformazione raggiunta | Valore differenziato | Credibilità del reframe |

---

## Checklist Pre-Pitch

Prima di presentare, verifica:

- [ ] Apro con un Big Shift/Insight, NON con chi siamo?
- [ ] La company intro è ≤2 minuti?
- [ ] Ho quantificato il costo dell'inazione?
- [ ] Il social proof viene DOPO problem+solution?
- [ ] Ogni monologue è ≤9 minuti?
- [ ] Ho "brain breaks" (domande, demo) se supero 9 min?
- [ ] La Promised Land è la VITA del prospect, non il mio prodotto?
- [ ] Le feature sono "magic gifts" per il viaggio, non il protagonista?
- [ ] Il CTA è specifico e time-bound?
- [ ] Il prospect può ri-pitchare internamente con la mia narrativa?
