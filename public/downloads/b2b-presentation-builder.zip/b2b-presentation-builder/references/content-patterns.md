# Content Patterns

Proven messaging patterns and content templates for high-converting B2B presentations.

## Template Pattern

Use templates to maintain consistency while allowing customization. Templates define placeholders for context-specific content.

### Problem Statement Template

```
[Target audience] struggle with [specific challenge] because [root cause].

This costs them [quantified impact] in [timeframe], leaving [opportunity cost] on the table.

The window to act is [urgency factor].
```

**Example:**
> Mid-market CFOs struggle with GenAI ROI measurement because existing finance systems lack integration with AI tools.
>
> This costs them 200+ hours/year in manual tracking, leaving strategic planning time on the table.
>
> The window to act is narrowing as early adopters build 12-18 month leads.

### Solution Positioning Template

```
Unlike [alternative approach], we [unique method] by [key differentiator].

This means [audience] can [primary benefit] while avoiding [common pitfall].
```

**Example:**
> Unlike tech-first AI consultancies, we integrate technology with organizational readiness by applying our 30-70 rule (30% tech, 70% people+process).
>
> This means CIOs can achieve production-scale impact while avoiding the "pilot purgatory" trap.

### Case Study Template

```
[Company type/size] in [industry] faced [specific problem].

Using [your approach], they achieved:
- [Metric 1]: [X%] improvement in [Y timeframe]
- [Metric 2]: [reduction/increase] from [before] to [after]
- [Metric 3]: [strategic outcome]

Key success factor: [one critical element]
```

**Example:**
> A €500M manufacturing company faced 60% failure rate in scaling AI pilots.
>
> Using our AI Readiness Framework, they achieved:
> - Pilot-to-production rate: 75% (from 40%) in 6 months
> - Time-to-value: 40% reduction from 9 to 5.4 months
> - Employee AI adoption: 80% vs 35% industry benchmark
>
> Key success factor: Executive sponsorship combined with bottom-up change agents program.

### ROI Framing Template

```
Investment: [range or specific]
Typical payback: [timeframe]

Value drivers:
1. [Direct cost savings]: [amount/percentage]
2. [Efficiency gain]: [time/resource saved]
3. [Revenue opportunity]: [growth potential]
4. [Strategic value]: [competitive advantage]
```

**Example:**
> Investment: €50-80K for Phase 1 (AI Strategy Plan)
> Typical payback: 4-6 months
>
> Value drivers:
> 1. Failed pilot cost avoidance: €200-400K/year
> 2. Time to production: 40% faster (5.4 vs 9 months)
> 3. Revenue from new AI capabilities: 5-15% growth in target segments
> 4. Competitive moat: 12-18 month lead vs followers

---

## Slide Copy Templates (Operativi)

Template pronti per copia-incolla con placeholder specifici.

### Problem Slide Copy

**Template 1 - The Uncomfortable Truth:**
```
[X%] of [target audience] are [doing something inefficiently], 
costing them [specific consequence].

Meanwhile, [competitor type] are [doing the opposite] and 
[achieving result].
```

**Esempio reale (ChartMogul):**
> "Accurately calculating SaaS metrics is hard. Harnessing subscription data to inform decisions that lead to faster growth is even harder."

**Esempio reale (ProdPad):**
> "Spreadsheets are the place where good ideas go to die."

**Template 2 - Cost of Inaction:**
```
Every [time period] without [solution] costs you:
• €[X] in [direct cost]
• [Y] hours in [wasted effort]
• [Z]% [missed opportunity]
```

### Solution Slide Copy

**Template - The Bridge Statement:**
```
That's why we built [Product]. 

[Single biggest promise in una frase].

This means [audience] can [primary benefit] 
while avoiding [common pitfall they fear].
```

**Transizione dal problem:**
- "There's a better way..."
- "What if you could [solve problem] while also [getting benefit]?"
- "Imagine if [pain] simply... disappeared."

**Esempio Gong:**
> "Get powerful visibility into your customer interactions with revenue intelligence."

### Why Now Slide Copy

**Template - Market Shift:**
```
In [year], [old reality].
Today, [new reality].
By [future year], [projection].

The window to act: [specific urgency factor].
```

**Template - Cost of Waiting:**
```
Every [time period] you wait:
• Competitors gain [specific advantage]
• You lose €[X] in [quantified cost]
• The gap becomes [harder/impossible] to close
```

**Test di validità:** Se questa slide sarebbe stata rilevante 5 anni fa, riscrivila. Deve creare urgenza per OGGI.

### Competitive Positioning Slide Copy

**Template - Category Creation:**
```
There are [N] ways to approach [problem]:

1. [Approach A] - Good for [use case], but [limitation]
2. [Approach B] - Good for [use case], but [limitation]  
3. [Our approach] - Combines [benefit A] + [benefit B] for [specific audience]
```

**Template - Positioning Without Bashing:**
```
While [competitor/alternative] focuses on [X], 
we specialize in [Y] for [specific audience].

This means [unique outcome they can't get elsewhere].
```

**Anti-pattern:** Mai dire "siamo uguali ma migliori". Crea una categoria che definisci tu.

### Case Study Slide Copy

**Struttura obbligatoria:**
```
# How [Company] Achieved [Specific Result]

**Challenge:** [Una frase sul problema]
**Solution:** [Una frase sull'approccio]
**Result:** [3 metriche in callout]

"[Quote del cliente - max 2 righe]"
— [Nome], [Ruolo], [Company]
```

**Formula Three-Part Result:**
```
[Metric 1] + [Metric 2] + [Metric 3] 
achieved in [timeframe]
```

**Regole:**
- Il cliente è l'eroe, non tu
- Case study simile al prospect (industry, size, challenge)
- Quote che parla di TRASFORMAZIONE, non di feature

### Pricing Slide Copy

**Template Enterprise - Value-Based:**
```
# Investment

Starting from €[X]/[period] per [unit]

Includes:
✓ [Key deliverable 1]
✓ [Key deliverable 2]
✓ [Key deliverable 3]

Typical ROI: [X]x within [timeframe]
```

**Template Enterprise - Custom:**
```
# Pricing Built Around Your Needs

Enterprise includes:
• Dedicated onboarding
• SLA guarantees
• Custom integrations
• Named account management

Let's discuss your specific requirements.
```

**Regola:** Mai mostrare pricing prima di aver stabilito il valore. Pricing viene DOPO ROI e case study.

### CTA/Next Steps Slide Copy

**Copy debole da evitare:**
- ❌ "Let's connect"
- ❌ "Learn more"
- ❌ "Thank you" (MAI finire così)
- ❌ "Any questions?"

**Copy forte:**
```
# Next Steps

**This week:** [Azione specifica]
**Next 2 weeks:** [Milestone]
**By [date]:** [Decision point]

[Button/Link] Schedule your [specific meeting type]
```

**Formula CTA:** [Action verb] + [Timeframe] + [Benefit]

**Esempi:**
- "Schedule a 30-minute call this week to see your custom ROI projection"
- "Book a technical deep-dive with our team entro venerdì"
- "Join 500+ businesses that have cut costs by 30%. Let's get you started."

---

## Action Titles (McKinsey Pattern)

Trasforma titoli descrittivi in titoli che comunicano l'insight.

### Principio

Il titolo di ogni slide dovrebbe comunicare il SO WHAT, non il WHAT.

### Esempi

| ❌ Titolo Descrittivo | ✅ Action Title |
|----------------------|-----------------|
| "Analisi di Mercato" | "Tre mercati inesplorati potrebbero guidare 40% della crescita" |
| "Overview Prodotto" | "Una piattaforma per eliminare il 75% dei pilot falliti" |
| "Team" | "30+ anni di esperienza combinata in AI transformation" |
| "Pricing" | "ROI positivo entro 6 mesi, garantito" |
| "Case Study Acme Corp" | "Acme ha ridotto i costi del 40% in 90 giorni" |
| "Il Problema" | "€2M/anno persi in inefficienze che nessuno vede" |
| "La Soluzione" | "Visibilità completa su ogni euro speso in AI" |

### Formula

```
[Quantificazione] + [Outcome] + [Timeframe/Condizione]
```

### Applicazione

- Scrivi prima il contenuto della slide
- Chiediti: "Qual è l'unica cosa che il prospect deve ricordare?"
- Trasforma quella cosa nel titolo
- Il titolo deve funzionare anche da solo (senza leggere il resto)

Provide specific, concrete examples that the audience can relate to. Use industry-specific terminology and scenarios.

### Vertical-Specific Examples

**Manufacturing:**
- "Predictive maintenance AI reducing downtime by 30%"
- "Supply chain optimization saving €2M annually"
- "Quality control AI catching defects 40% earlier"

**Financial Services:**
- "Fraud detection improving precision by 25% while reducing false positives"
- "Customer churn prediction enabling proactive retention saving €5M"
- "Loan underwriting acceleration from 5 days to 2 hours"

**Retail:**
- "Demand forecasting reducing stockouts by 35%"
- "Personalization engine driving 12% basket size increase"
- "Price optimization improving margins by 2.3 percentage points"

**Professional Services:**
- "Document analysis reducing legal review time by 60%"
- "Proposal generation cutting response time from 5 days to 8 hours"
- "Knowledge management improving consultant utilization by 15%"

### Size-Specific Examples

**Enterprise (>1000 employees):**
- Focus on scale challenges, integration complexity, governance
- ROI in millions
- Multi-year transformation journeys

**Mid-Market (100-1000 employees):**
- Focus on resource constraints, agility advantages, quick wins
- ROI in hundreds of thousands
- 6-12 month implementation cycles

**SMB (<100 employees):**
- Focus on competitive disadvantage, access to enterprise capabilities
- ROI in tens of thousands
- 3-6 month fast tracks

## Conditional Workflow Pattern

Adapt content based on context discovered in Phase 1. Use conditional logic to select appropriate messaging.

### IF audience = CFO THEN emphasize:
- P&L impact and financial metrics
- Payback period and NPV
- Budget allocation and cost control
- Risk mitigation and governance
- Benchmarking vs industry standards

### IF audience = CIO/CTO THEN emphasize:
- Technical architecture and integration
- Scalability and security
- Team skills and training needs
- Vendor management
- Technical debt and modernization

### IF audience = CEO THEN emphasize:
- Strategic positioning and competitive advantage
- Market trends and disruption threats
- Organizational transformation
- Stakeholder impact (customers, employees, investors)
- Vision and long-term trajectory

### IF context = first_meeting THEN:
- Keep it high-level and strategic
- Focus on problem-solution fit
- Minimal technical detail
- Broad proof points
- Soft CTA (next conversation, not commitment)

### IF context = evaluation_stage THEN:
- Add technical depth
- Provide detailed case studies
- Include implementation roadmap
- Show team credentials
- Specific pricing and timelines

### IF context = final_decision THEN:
- Address remaining objections head-on
- Provide detailed business case
- Include risk mitigation plan
- Show governance framework
- Clear CTA with urgency

---

## C-Level Copy Patterns (Frasi Operative)

Linguaggio specifico che risuona con diversi executive.

### CFO Language (ROI, Risk, Efficiency)

**Frasi che funzionano:**
- "I expect the investment to build €[X]M in additional revenues, a [Y]x ROI, within [timeframe]."
- "[Solution] more than pays for itself within [timeframe]."
- "By improving [process], we expect to convert [X]% more [metric], generating €[Y] additional revenue."
- "The investment de-risks €[X] in current exposure to [risk factor]."

**Domande che il CFO si pone (rispondi proattivamente):**
- Quanto chiedi esattamente?
- Quando recupero l'investimento?
- Qual è l'ROI atteso con assumption conservative?
- Come mitighiamo il rischio se non funziona?
- Quali costi nascosti ci sono?

**Framework risposta CFO:**
```
Investment: €[X]
Payback: [N] months
Conservative ROI: [Y]x
Risk mitigation: [Specific mechanism]
Hidden costs: [None / These are included]
```

### CIO/CTO Language (Integration, Security, Scalability)

**Frasi che funzionano:**
- "The solution integrates with your existing [system] through [standard protocol/API]."
- "Our old technology can crash at any time, putting €[X] in revenues at risk."
- "Implementation follows [standard methodology] with [governance framework]."
- "Security posture: [certification], [compliance], [audit trail]."

**Regola Work-Bench:** In un meeting di 30 minuti con CIO, hai 15 minuti effettivi:
- 5 min: ritardi e setup
- 5 min: intro e rapport
- 15 min: contenuto reale
- 5 min: next steps

Non restare intrappolato nelle slide. Prepara risposte per:
- "Come funziona con [nostro sistema specifico]?"
- "Chi ha ownership del dato?"
- "Cosa succede se [failure scenario]?"

### CEO Language (Vision, Growth, Competitive Advantage)

**Frasi che funzionano:**
- "This is the story we're going to tell—everywhere—for the next 3 to 5 years."
- "It removes [competitor/threat], making it easier to [strategic outcome]."
- "It will help accelerate revenue growth by [mechanism]."
- "This positions us as [category leader/first mover] before [competitor] can react."

**CEO focus areas:**
- Market positioning e competitive moat
- Transformational outcomes (non incrementali)
- Alignment con strategia già dichiarata
- Impatto su stakeholder (board, investors, customers)

**Pattern per CEO pitch:**
```
Strategic imperative: [In una frase]
Competitive impact: [Come cambia il gioco]
Timeline to advantage: [Quando vediamo risultati]
Board story: [Come lo raccontiamo agli investitori]
```

### Buyer Committee Dynamics

**Dato Gartner:** Buying committee = 6-14+ stakeholder. 74% hanno "conflitto non sano".

**Sequenza raccomandata per multi-stakeholder:**
1. **Champion** (primo contatto): Educational content, build vision
2. **Economic buyer** (CFO): Business case, ROI
3. **Technical buyer** (CIO): Feasibility, integration
4. **User buyer**: Usability, adoption
5. **Executive sponsor** (CEO): Strategic alignment

**Contenuto da preparare per ogni persona:**
| Stakeholder | Contenuto chiave | Formato |
|-------------|------------------|---------|
| Champion | Vision deck + internal pitch kit | PDF condivisibile |
| CFO | Business case spreadsheet | Excel con sensitivity |
| CIO | Technical architecture + security doc | Detailed PDF |
| CEO | Executive summary (5-7 slide) | Concise PDF |

---

## Strategic Framing Patterns

Reframe concepts to shift perception and increase receptiveness.

### From Problem to Opportunity
❌ "You have a problem with AI adoption"  
✅ "You have an opportunity to build 12-18 month competitive lead while others struggle"

### From Cost to Investment
❌ "This will cost €80K"  
✅ "€80K investment typically returns 4-6x in first year through avoided failed pilots and faster time-to-value"

### From Risk to De-Risked Path
❌ "AI transformation is risky"  
✅ "Our phased approach eliminates 80% of typical AI transformation risks through proven frameworks"

### From Feature to Outcome
❌ "We provide AI readiness assessment"  
✅ "You'll know exactly which AI initiatives will succeed and which will fail before spending a euro"

### From Vendor to Partner
❌ "We deliver AI consulting services"  
✅ "We become your AI transformation co-pilot, invested in your long-term success"

## Proof Social Patterns

### Authority Signals
- Industry recognition: "Recognized by [authority] for [achievement]"
- Credentials: "Our team includes former [prestigious company/role]"
- Partnerships: "Official partners with [Microsoft/AWS/Google]"
- Track record: "Successfully delivered [N] transformations in [timeframe]"

### Social Proof
- Client logos (if permission granted)
- Category references: "[N] Fortune 500 companies"
- Vertical proof: "Trusted by [N] leading [industry] organizations"
- Scale indicators: "Processed [large number] in [domain]"

### Testimonial Patterns
Format: [Role] at [Company Type] + [Specific Outcome] + [Emotional Resonance]

**Strong example:**
> "As CFO of a mid-market manufacturer, I was skeptical about AI ROI. The structured approach gave us confidence to invest €150K, and we've already seen €600K in measurable returns within 9 months. More importantly, we now have a scalable playbook."  
> — CFO, €450M Manufacturing Company

**Weak example:**
> "Great partner, highly recommend!"  
> — CIO, Tech Company

### Quantified Results Pattern
Always use: [Metric] improved by [%] from [before] to [after] in [timeframe]

**Good:** "Customer satisfaction improved by 23% from 67% to 82% in 6 months"
**Bad:** "Significantly improved customer satisfaction"

## Objection Handling Patterns

### Preemptive Objection Handling
Address common objections before they're raised, in a "Why not [alternative]?" format.

**Why not Big4 consulting?**
> Big4 excel at strategy but often lack hands-on AI implementation depth. We combine strategic vision with technical execution, ensuring your strategy actually gets implemented—not just documented in a slide deck that sits on a shelf.

**Why not build in-house?**
> In-house development works if you have 18-24 months to learn through trial and error. We compress that learning curve to 3-6 months by applying patterns we've proven across [N] implementations, letting your team focus on your unique competitive advantage.

**Why not hyperscaler professional services?**
> AWS/Azure/Google are excellent for infrastructure but naturally push their specific platforms. We're platform-agnostic and focus on organizational readiness—the 70% that determines whether technology succeeds or fails.

**Why not wait?**
> Early movers are building 12-18 month competitive leads right now. The cost of waiting isn't just delayed benefits—it's watching competitors pull ahead irreversibly. The "wait and see" companies in every disruption wave never caught up.

### Direct Objection Response Pattern

When objection is raised:

1. **Validate**: "That's a legitimate concern..."
2. **Reframe**: "What we've found is..."
3. **Prove**: "For example, [case study/data]..."
4. **Ask**: "Does that address your concern, or should we explore it further?"

## Cognitive Density Guidelines

### Executive Audience (30-50 words/slide)
- One clear message per slide
- Bullet points maximum 3
- Each bullet maximum 10 words
- Prefer visual storytelling over text

### Operational Audience (50-80 words/slide)
- Can handle more detail
- Bullet points maximum 5
- Technical terminology acceptable
- Balance text and visuals

### Sales Conversation (varies)
- Hub slides: minimal text (30 words)
- Deep-dive slides: more detail acceptable (100 words)
- Use visuals to reduce text load

## Language Precision

### Use Active Voice
❌ "The project was completed by our team"  
✅ "Our team completed the project in 6 weeks"

### Use Specific Numbers
❌ "Significant improvement"  
✅ "43% improvement from 2.3M to 1.3M"

### Use Concrete Verbs
❌ "Achieve optimization of processes"  
✅ "Reduce process time by 40%"

### Avoid Jargon (Unless Audience-Appropriate)
❌ "Leverage synergistic paradigms to optimize value streams"  
✅ "Combine AI with process redesign to cut costs by 30%"

### Use "You" Language
❌ "Companies can benefit from"  
✅ "You'll gain"

## Storytelling Arc for Presentations

### ACT 1: Setup (Slides 1-3)
- Establish status quo
- Introduce tension/problem
- Create urgency

### ACT 2: Confrontation (Slides 4-6)
- Present solution/approach
- Show how it addresses problem
- Validate with proof

### ACT 3: Resolution (Slides 7-10)
- Map clear path forward
- De-risk the journey
- Call to action

This three-act structure keeps audience engaged and builds toward decision.

## Personalization Checklist

Before finalizing content:
- [ ] Replace generic examples with industry-specific ones
- [ ] Adjust metrics to audience's scale (€M for enterprise, €K for SMB)
- [ ] Use audience's terminology (CFO: P&L impact; CTO: technical debt)
- [ ] Reference audience's known pain points from discovery
- [ ] Include case studies from similar companies
- [ ] Adjust ROI timeframe to audience's planning horizon
- [ ] Frame competitive context relevant to audience's market
