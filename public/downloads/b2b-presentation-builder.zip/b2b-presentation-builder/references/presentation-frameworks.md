# Presentation Frameworks

Proven narrative structures for different B2B contexts and audiences.

## Framework Selection Matrix

| Audience | Context | Deck Type | Slide Count | Duration |
|----------|---------|-----------|-------------|----------|
| CEO/Board | Strategic decision | Executive | 8-10 | 15-20 min |
| CFO | Budget approval | Executive (ROI-focused) | 8-10 | 15-20 min |
| CIO/CTO | Technical evaluation | Operational | 12-15 | 30-40 min |
| Cross-functional | Discovery/workshop | Sales Conversation | 20-25 | 60+ min (non-linear) |

## Executive Deck (8-10 slides)

**Purpose:** Secure strategic buy-in from C-level for high-stakes decisions  
**Cognitive density:** 30-50 words/slide (except opening/closing)  
**Proof depth:** High-level metrics, 1-2 case studies max

### Standard Structure

**Slide 1: Title + Positioning**
- Company/offering name
- Tagline/positioning statement
- Date and presenter info
- Visual: Brand-aligned hero image or logo

**Slide 2: Problem Diagnostic**
- The strategic challenge they face
- Cost of inaction (quantified)
- Why now? (urgency/market shift)
- Visual: Data visualization showing problem magnitude

**Slide 3: Market Context**
- Industry trends validating the problem
- Competitive landscape shift
- Window of opportunity
- Visual: Market diagram or trend chart

**Slide 4: Solution Overview**
- Your unique approach (not features, but philosophy/method)
- 2-3 core differentiators
- Why this solves the diagnosed problem
- Visual: Simple conceptual diagram

**Slide 5: How It Works**
- High-level process (3-5 steps max)
- Key enablers or components
- What makes it different from alternatives
- Visual: Process flow or journey map

**Slide 6: Proof**
- 1-2 case studies with quantified results
- Pattern: "Company X achieved Y% improvement in Z metric within N months"
- Logos of notable clients (if applicable)
- Visual: Results comparison or testimonial

**Slide 7: ROI & Business Case**
- Investment range (if appropriate at this stage)
- Payback period indication
- Value creation beyond cost savings
- Visual: ROI calculation or value breakdown

**Slide 8: The Journey**
- 3-4 phase roadmap
- Timeline indication
- De-risking elements
- Visual: Timeline with milestones

**Slide 9: Why Us**
- Team credentials
- Track record
- Partnerships/certifications
- Visual: Team photos or partner logos

**Slide 10: Next Steps (CTA)**
- Concrete action with timeline
- What happens in next 7/14/30 days
- Investment/commitment level
- Visual: Next steps timeline

### CFO-Specific Variant

Emphasize slides 2, 7, 8:
- **Slide 2:** Quantify problem in P&L impact terms
- **Slide 7:** Expand to full business case with sensitivity analysis
- **Slide 8:** Add risk mitigation and governance framework

### CEO-Specific Variant

Emphasize slides 3, 4, 6:
- **Slide 3:** Market positioning and competitive moat
- **Slide 4:** Strategic differentiation and vision alignment
- **Slide 6:** Transformational outcomes, not just operational gains

## Operational Deck (12-15 slides)

**Purpose:** Convince CIO/CTO/operations leaders with implementation credibility  
**Cognitive density:** 50-80 words/slide  
**Proof depth:** Technical detail, architecture, multiple case studies

### Standard Structure

**Slides 1-3:** Same as Executive (Title, Problem, Context)

**Slide 4: Solution Architecture**
- System diagram or tech stack
- Integration points with existing infrastructure
- Scalability considerations
- Visual: Technical architecture diagram

**Slide 5: Implementation Methodology**
- Detailed phase breakdown
- Roles and responsibilities
- Success criteria per phase
- Visual: Gantt chart or phase detail

**Slide 6-7: Case Studies (2 slides)**
- Deep dive on 2-3 relevant implementations
- Before/after metrics
- Technical challenges overcome
- Visual: Results dashboard or comparison

**Slide 8: Technology & Tools**
- Core technologies used
- Vendor partnerships
- Compliance/security posture
- Visual: Tech stack diagram

**Slide 9: Team & Expertise**
- Technical credentials
- Certifications
- Past projects
- Visual: Team structure or credentials

**Slide 10: Governance & Risk Management**
- Change management approach
- Risk mitigation strategies
- Quality assurance process
- Visual: Governance framework

**Slide 11: ROI Model**
- Detailed cost breakdown
- Quantified benefits by category
- Payback calculation
- Visual: Financial model or ROI curve

**Slide 12: Integration Plan**
- Systems affected
- Data migration approach
- Training plan
- Visual: Integration roadmap

**Slide 13-14: FAQ / Objections Handled**
- Anticipate top 3-5 concerns
- Direct answers with proof
- Visual: Q&A format or myth-busting

**Slide 15: Next Steps**
- Detailed next steps
- Timeline and milestones
- Required commitments
- Visual: Action plan timeline

## Sales Conversation Deck (20-25 slides)

**Purpose:** Flexible, modular deck for iterative discovery and objection handling  
**Cognitive density:** Varies by slide type  
**Proof depth:** Comprehensive library of case studies and proof points

### Modular Structure

**Core Narrative (Slides 1-10):** Same as Executive Deck

**Addendum Sections (Slides 11-25):** Organized by topic, used selectively

**Section A: Deep Dive on Problem**
- A1: Industry pain points by vertical
- A2: Quantified cost of inaction
- A3: Failed approaches and why

**Section B: Solution Deep Dive**
- B1: Feature-by-feature breakdown
- B2: Technical architecture
- B3: Integration scenarios

**Section C: Proof Library**
- C1: Case study - Industry X
- C2: Case study - Industry Y
- C3: Case study - Company size Z
- C4: Testimonials compilation

**Section D: ROI & Business Case**
- D1: Cost-benefit calculator
- D2: Payback scenarios
- D3: Total cost of ownership

**Section E: Implementation**
- E1: Detailed roadmap
- E2: Team structure
- E3: Change management
- E4: Training program

**Section F: Competitive Positioning**
- F1: Why not Big4?
- F2: Why not in-house?
- F3: Why not other vendors?

**Section G: Risk & Governance**
- G1: Risk mitigation
- G2: Security & compliance
- G3: Success metrics

### Navigation Strategy

Use core narrative (1-10) for first presentation. Based on questions/objections, navigate to relevant addendum sections. Mark sections as:
- **[ADDENDUM A1]** at top of slide for easy reference
- Build table of contents slide (Slide 11) that lists all addendum sections

## Deck Format Variants

Stesso contenuto, formati diversi per contesti diversi.

### Live Presentation Deck

**Scopo:** Guidare una conversazione dal vivo
**Caratteristiche:**
- Testo minimo (tu spieghi a voce)
- Visual-heavy
- 10-15 slide
- Speaker notes dettagliate

**Regole:**
- Max 30-50 parole/slide (il resto lo dici tu)
- Ogni slide = 1 messaggio chiave
- Visual > Testo
- Domande integrate ("Questo risuona con la vostra esperienza?")

### Send-Ahead Deck

**Scopo:** Ottenere il meeting (il prospect lo legge da solo)
**Caratteristiche:**
- Più testo (deve funzionare standalone)
- 8-12 slide
- Self-explanatory
- Teaser, non racconto completo

**Regole:**
- Ogni slide deve essere comprensibile senza spiegazione
- Include "hook" per generare curiosità
- CTA chiara: "Parliamone in un call di 30 minuti"
- NON rivelare tutto—lascia valore per il meeting

### Leave-Behind Deck

**Scopo:** Abilitare il champion a vendere internamente
**Caratteristiche:**
- Completo (deve rispondere a domande emerse nel meeting)
- 10-12 slide
- Include FAQ/Objections handling
- Personalizzato post-meeting

**Regole:**
- Incorpora risposte alle domande specifiche emerse
- Include sezione "Why Now" rafforzata
- Aggiungi competitive positioning se discusso
- Summary slide con 3 key takeaways

### Confronto Formati

| Aspetto | Live | Send-Ahead | Leave-Behind |
|---------|------|------------|--------------|
| Testo/slide | 30-50 parole | 60-80 parole | 80-100 parole |
| Slide count | 10-15 | 8-12 | 10-12 |
| Standalone | No | Sì | Sì |
| Visual focus | Alto | Medio | Medio |
| CTA | Soft (next conversation) | Get the meeting | Enable decision |
| Formato | Keynote/PPT | PDF | PDF |

---

## Executive Summary Deck (5-7 slides)

Per C-Suite con tempo limitato. Struttura BLUF (Bottom Line Up Front).

### Principio McKinsey

Il 90% delle decisioni del top management deriva da executive summary concisi. Porta la conclusione IN CIMA, poi supportala.

### Struttura SCQA

| # | Sezione | Contenuto | Tempo |
|---|---------|-----------|-------|
| 1 | BLUF | Bottom Line Up Front: cosa proponi, raccomandazione, perché importa | 30 sec |
| 2 | Situation | Contesto breve, stato attuale | 1 min |
| 3 | Complication | Il problema che richiede azione ORA | 1 min |
| 4 | Resolution | La tua raccomandazione con benefici chiave | 2 min |
| 5 | Evidence | "Money slide" con proof point irrefutabile | 1 min |
| 6 | Next Steps | Ask specifica con timeline | 30 sec |

### Template Slide Executive Summary

**Slide 1 - BLUF:**
```
# [Raccomandazione in 10 parole]

Investimento: €[X]K | Payback: [N] mesi | ROI: [X]x

**Perché ora:** [Una frase sull'urgenza]
```

**Slide 2 - Situation:**
```
# [Titolo situazione attuale]

[2-3 bullet che descrivono lo stato corrente]
- [Fatto 1 con numero]
- [Fatto 2 con numero]
- [Contesto di mercato]
```

**Slide 3 - Complication:**
```
# [Il problema in forma di domanda o statement]

[Quantificazione del problema]
- Costo attuale: €[X]/anno
- Rischio: [conseguenza se non si agisce]
- Window: [urgency factor]
```

**Slide 4 - Resolution:**
```
# [La soluzione in una frase]

**Approccio:**
1. [Step 1] → [Outcome 1]
2. [Step 2] → [Outcome 2]
3. [Step 3] → [Outcome 3]

**Risultato atteso:** [Metrica chiave]
```

**Slide 5 - Evidence:**
```
# [Company simile] ha raggiunto [risultato]

[Case study compresso]
- Challenge: [problema simile]
- Soluzione: [approccio usato]
- Risultato: [3 metriche]

[Logo + Quote breve]
```

**Slide 6 - Next Steps:**
```
# Prossimi step

**Questa settimana:** [Azione immediata]
**Prossime 2 settimane:** [Milestone 1]
**Entro [data]:** [Decision point]

Investment ask: €[X]K | Decision needed by: [data]
```

---

## 12-Slide Optimal Structure

Struttura validata per sales deck standard. Ogni slide ha una risposta psicologica target.

| # | Tipo | Contenuto | Risposta target |
|---|------|-----------|-----------------|
| 1 | Cover | Nome + one-liner positioning | "Sembra interessante..." |
| 2 | Big Shift | Cambiamento nel mercato/mondo | "Questo è importante..." |
| 3 | Problem | Pain point specifico quantificato | "Ho questo problema..." |
| 4 | Status Quo | La situazione attuale frustrante | "Quello sono io..." |
| 5 | Solution | Descrizione high-level (NON feature) | "Capisco cosa fanno..." |
| 6 | How It Works | Top 3 capability/differentiatori | "Capisco come funziona" |
| 7 | Demo/Visual | Screenshot o walkthrough | "Posso vedermi usarlo" |
| 8 | Benefits | Max 3-4 outcome | "Voglio quei risultati" |
| 9 | Social Proof | Case study + loghi | "Altri simili a me ci sono riusciti" |
| 10 | Pricing | Piani e per chi sono | "Il piano X è giusto per noi" |
| 11 | FAQs/Objections | Top 3 preoccupazioni | "Hanno anticipato i miei dubbi" |
| 12 | Next Steps | CTA specifica + timeline | "So esattamente cosa fare" |

### Timing Guidelines

- **2 min/slide** come regola generale
- **Max 9 minuti** di monologue continuo (poi break/domanda)
- **Slide 1-4:** 6-8 minuti (setup)
- **Slide 5-8:** 10-12 minuti (solution)
- **Slide 9-12:** 6-8 minuti (proof + close)
- **Totale:** 22-28 minuti + Q&A

---

## Stakeholder Behavioral Types

Oltre a CFO/CIO/CEO (ruoli), considera i tipi comportamentali (come decidono).

### Mobilizers (Da targettare prioritariamente)

Stakeholder che effettivamente fanno succedere i deal.

| Tipo | Caratteristica | Come riconoscerli | Come ingaggiarli |
|------|----------------|-------------------|------------------|
| **Go-Getter** | Orientati all'azione, miglioramento continuo | "Cosa possiamo fare per migliorare?" | Dai loro azioni concrete da compiere |
| **Teacher** | Condividono insight, educano colleghi | Fanno domande per capire profondamente | Fornisci contenuti da condividere internamente |
| **Skeptic** | Sfidano idee, stress-test | "Ma cosa succede se...?" | Anticipa obiezioni, fornisci dati solidi |

### Talkers (Da gestire, non over-investire)

Sembrano influenti ma non muovono deal.

| Tipo | Caratteristica | Come riconoscerli | Come gestirli |
|------|----------------|-------------------|---------------|
| **Guide** | Amichevoli, accessibili | Ti danno molte info, poco commitment | Usa per intel, non aspettarti azione |
| **Friend** | Vogliono aiutarti | "Ti metto in contatto con..." | Ringrazia, ma cerca il vero decisore |
| **Climber** | Focalizzati su carriera | Parlano di come li farà apparire | Utili se allineato con loro interesse |
| **Blocker** | Resistono al cambiamento | "Non è il momento", "Abbiamo provato" | Identifica e neutralizza/bypassa |

### Applicazione pratica

**Fase Discovery:** Identifica chi è Mobilizer vs Talker
**Fase Pitch:** Personalizza messaggio per Mobilizers presenti
**Fase Follow-up:** Attiva Mobilizers come champion interni

**Dato Gartner:** Gruppi con consenso sono 2.5x più propensi a deal di alta qualità. Il conflitto nel buying committee picca al 37% del processo (fase identificazione soluzione).

---

## Slide Archetypes

### Opening Slide
- **Purpose:** Set tone and positioning
- **Elements:** Logo, tagline, visual hero
- **Words:** <20

### Problem Diagnostic Slide
- **Purpose:** Create urgency and align on challenge
- **Elements:** Problem statement, quantified cost, "why now"
- **Words:** 40-60
- **Visual:** Data chart or comparison

### Solution Overview Slide
- **Purpose:** Present unique approach
- **Elements:** 2-3 differentiators, philosophy/method
- **Words:** 50-70
- **Visual:** Conceptual diagram

### Process/How It Works Slide
- **Purpose:** Build confidence in execution
- **Elements:** 3-5 step process, key components
- **Words:** 50-80
- **Visual:** Flow diagram or journey map

### Proof/Case Study Slide
- **Purpose:** Validate with evidence
- **Elements:** Company name (or anonymized), metrics, timeframe
- **Words:** 60-80
- **Visual:** Results comparison or testimonial quote

### ROI/Business Case Slide
- **Purpose:** Justify investment
- **Elements:** Investment range, payback, value breakdown
- **Words:** 40-60
- **Visual:** Financial model or value pyramid

### Next Steps/CTA Slide
- **Purpose:** Drive to action
- **Elements:** Concrete next action, timeline, commitment level
- **Words:** 30-50
- **Visual:** Timeline or checklist

## Narrative Flow Principles

**Problem-Solution-Proof-Path**
1. Establish the problem with urgency
2. Present differentiated solution
3. Validate with proof
4. Show clear path forward

**Tension-Release Pattern**
- Build tension with problem/cost of inaction (Slides 2-3)
- Release with solution/approach (Slides 4-5)
- Reinforce with proof (Slide 6)
- De-risk with process (Slides 7-8)
- Call to action (Slide 10)

**Specificity Gradient**
- Start strategic/high-level
- Add detail progressively
- End with concrete next steps

**One Message Per Slide**
- Each slide should answer one question
- Supporting details reinforce that message
- Visual amplifies the core message

## Adaptation Checklist

Before using a framework, validate:
- [ ] Audience seniority matches cognitive density
- [ ] Proof depth matches decision stage (awareness vs evaluation vs decision)
- [ ] Time allocation matches slide count (2 min/slide guideline)
- [ ] Industry context reflected in examples
- [ ] Company size affects case study selection
- [ ] Geographic/cultural factors considered
