# Design Principles

Visual design guidelines for creating professional, high-impact B2B presentations.

## Core Visual Principles

### 1. Minimalismo Tattico
**Philosophy:** Use minimum formatting needed for clarity—no more, no less.

**Apply:**
- Remove all decorative elements that don't serve communication
- Use white space as active design element, not void to fill
- Let content breathe
- One focal point per slide

**Avoid:**
- Cluttered slides with multiple competing elements
- Decorative borders, shadows, or gradients
- Bullet points with sub-bullets with sub-sub-bullets
- Stock photos that add no meaning

### 2. Visual Hierarchy
**Philosophy:** Guide the eye deliberately through information.

**Hierarchy levels:**
1. **Title** (largest, boldest) - What is this slide about?
2. **Key message** (prominent) - What's the one thing to remember?
3. **Supporting details** (smaller, lighter) - What proves/explains the key message?
4. **Visual suggestions** (descriptive) - What imagery would amplify this?

**Typography scale:**
- Title: Bold, 32-40pt
- Subtitle: Medium, 20-24pt
- Body: Regular, 16-18pt
- Caption: Light, 12-14pt

### 3. Contrast for Emphasis
**Philosophy:** High contrast = high attention; low contrast = supporting role.

**Use contrast for:**
- Key numbers that matter (bold, large, colored)
- Main call-to-action
- Critical differentiators
- Problem→Solution transitions

**Example:**
```
Revenue growth: 23%
Operating costs: ↓ 15%
[BOLD, LARGE] Net margin improvement: +5.2 percentage points
```

### 4. Consistency Creates Trust
**Philosophy:** Visual consistency signals professionalism and reduces cognitive load.

**Maintain consistency in:**
- Color palette (3-4 colors max)
- Typography (2 font families max)
- Icon style (all outlined OR all filled, never mixed)
- Chart style across all data visualizations
- Spacing and alignment

## Cognitive Density by Audience

### Executive Audiences (CEO/CFO/Board)
**Maximum cognitive load:** LOW

**Guidelines:**
- 30-50 words per slide (except title and closing)
- Maximum 3 bullet points
- Each bullet maximum 10 words
- Prefer large visuals over dense text
- One data visualization per slide maximum
- Ample white space (40-50% of slide)

**Example layout:**
```
[TITLE - 1 line]

[ONE KEY VISUAL - 50% of slide]

[3 SHORT BULLETS - 30 words total]
```

### Operational Audiences (CIO/CTO/Operations)
**Maximum cognitive load:** MEDIUM

**Guidelines:**
- 50-80 words per slide
- Maximum 5 bullet points
- Technical diagrams acceptable
- Can show 2 related data points per slide
- White space 30-40% of slide

**Example layout:**
```
[TITLE + SUBTITLE - 2 lines]

[DIAGRAM or CHART - 40% of slide]

[5 BULLETS with details - 60-70 words total]
```

### Sales Conversation (Variable)
**Maximum cognitive load:** FLEXIBLE

**Guidelines:**
- Hub slides: Minimal (30 words)
- Deep-dive slides: Detailed acceptable (100 words)
- Use progressive disclosure
- Support non-linear navigation

## Data Visualization Principles

### Chart Type Selection

**Comparison (X vs Y):** Bar chart
- Horizontal bars for many categories (>5)
- Vertical bars for time series or <5 categories
- Avoid 3D effects

**Composition (Parts of whole):** Pie chart or stacked bar
- Pie only if ≤5 segments
- Stacked bar if showing composition over time
- Always label percentages directly

**Distribution:** Histogram or scatter plot
- Show the data shape
- Mark mean/median clearly
- Use for analyzing patterns

**Trend over time:** Line chart
- Use for continuous data
- Multiple lines okay if <4 series
- Highlight the insight (arrow/annotation)

**Relationship:** Scatter plot
- Show correlation
- Add trendline if relevant
- Label outliers

### Chart Design Rules

**Simplify ruthlessly:**
- Remove gridlines unless essential
- Remove chart borders
- Use direct labels instead of legends when possible
- Limit colors (2-3 max per chart)

**Highlight the insight:**
- Use color to emphasize the key data point
- Add annotation explaining "so what?"
- Show before/after or comparison clearly

**Example - Good vs Bad:**

**Bad:** Generic bar chart with 7 colors, gridlines, legend, no annotation  
**Good:** Bar chart with one color (gray) except the key bar (brand color), direct labels, annotation: "40% faster than industry average"

### Data Tables

**When to use:** When precision matters more than pattern recognition

**Design rules:**
- Zebra striping for readability (alternating row colors)
- Align numbers right, text left
- Bold or color the key row/column
- Maximum 7 rows visible (scroll if needed)
- Include units in column headers

## Color Strategy

### Functional Color Palette

**Primary brand color:** Main CTAs, key messages, brand elements  
**Secondary color:** Supporting information, accents  
**Neutral colors:** Body text (dark gray, not pure black), backgrounds (off-white)  
**Status colors:** Green (success/positive), Red (alert/negative), Yellow (warning/caution)

**Example palette:**
- Primary: #0052CC (blue)
- Secondary: #00B8D9 (teal)
- Success: #36B37E (green)
- Warning: #FFAB00 (amber)
- Error: #DE350B (red)
- Text: #172B4D (dark blue-gray)
- Background: #F4F5F7 (light gray)

### Color Accessibility

**Ensure sufficient contrast:**
- Text on background: minimum 4.5:1 ratio
- Large text (>18pt): minimum 3:1 ratio
- Use online contrast checkers

**Don't rely on color alone:**
- Add icons or labels
- Use patterns in addition to colors
- Consider colorblind-friendly palettes

## Image and Icon Guidelines

### Photography

**Use when:**
- Showing real people/products/results
- Building emotional connection
- Demonstrating scale or context

**Avoid:**
- Generic stock photos (handshake, diverse team in meeting)
- Images that don't add meaning
- Low-quality or pixelated images

**Best practices:**
- High resolution (min 1920x1080 for full-slide)
- Authentic over polished
- Add subtle overlay if placing text on image
- Crop/frame intentionally

### Icons

**Use when:**
- Representing abstract concepts
- Creating visual scannable lists
- Building process diagrams
- Reducing text density

**Style consistency:**
- Use ONE icon family throughout (all outlined OR all filled)
- Similar stroke weight across all icons
- Consistent sizing
- Monochrome or limited color palette

**Common icon sources:**
- Phosphor Icons (outlined, clean)
- Heroicons (solid and outline versions)
- Feather Icons (minimal, consistent)

### Diagrams

**Process flows:**
- Left-to-right or top-to-bottom progression
- Use arrows to show direction
- Number steps clearly
- Keep to 3-5 steps per slide

**Conceptual diagrams:**
- Show relationships visually
- Use spatial positioning meaningfully
- Limit to 5-7 elements
- Label clearly

**Architecture diagrams:**
- Group related components
- Show data flow with arrows
- Use consistent shapes for similar elements
- Include legend if needed

## Layout Patterns

### Title + Visual + 3 Bullets (Executive)
```
┌─────────────────────────────────┐
│ [TITLE]                         │
│                                 │
│  ┌─────────────────┐           │
│  │                 │           │
│  │     VISUAL      │           │
│  │                 │           │
│  └─────────────────┘           │
│                                 │
│  • Bullet point one             │
│  • Bullet point two             │
│  • Bullet point three           │
└─────────────────────────────────┘
```

### Split Screen (Comparison)
```
┌─────────────────────────────────┐
│ [TITLE]                         │
│                                 │
│  BEFORE       │     AFTER       │
│  ────────────────────────────   │
│  Problem      │   Solution      │
│  Issue X      │   Result Y      │
│  Pain point   │   Benefit       │
│               │                 │
│  [Chart]      │   [Chart]       │
└─────────────────────────────────┘
```

### Hero Visual (Opening/Closing)
```
┌─────────────────────────────────┐
│                                 │
│        [LARGE VISUAL]           │
│                                 │
│                                 │
│       [CENTERED TEXT]           │
│       Short impactful           │
│       message here              │
│                                 │
└─────────────────────────────────┘
```

### Data Story
```
┌─────────────────────────────────┐
│ [TITLE]                         │
│                                 │
│  ┌────────────────────────┐    │
│  │                        │    │
│  │    [LARGE CHART]       │    │
│  │                        │    │
│  └────────────────────────┘    │
│                                 │
│  [ANNOTATION] →                 │
│  "This spike represents..."     │
└─────────────────────────────────┘
```

## Gamma.app Specific Formatting

When generating Gamma.app markdown, provide clear visual suggestions that Gamma can interpret:

### Visual Suggestion Format

```
**Visual suggestions:** 
- Chart type: [Horizontal bar chart]
- Data points: [Show 5 categories with percentages]
- Emphasis: [Highlight the top bar in brand color]
- Style: [Minimal, direct labels, no gridlines]
```

or

```
**Visual suggestions:**
- Image: [Modern office environment with diverse team collaborating]
- Style: [Bright, natural lighting, authentic not staged]
- Crop: [Wide shot showing context]
- Overlay: [None or subtle dark gradient if text overlay needed]
```

or

```
**Visual suggestions:**
- Icon: [Simple outlined icon representing "growth" or "upward trend"]
- Position: [Left of each bullet point]
- Color: [Monochrome or brand color]
- Size: [24x24px, consistent with other icons]
```

### Markdown-Specific Best Practices

**Use semantic formatting:**
- `# Title` for slide titles
- `## Subtitle` for supporting taglines
- `**bold**` for emphasis sparingly
- Bullet points with `-` not `•`

**Keep it readable:**
- One blank line between sections
- Avoid nested bullets (flatten hierarchy)
- Use numbered lists only for sequential steps

**Leverage Gamma's auto-layout:**
- Provide clear content structure
- Let Gamma handle visual placement
- Override only when specific layout critical

## Multi-Format Export Considerations

### PowerPoint (.pptx)
**Strengths:** Full design control, animations, offline editing  
**Weaknesses:** Requires manual design work, platform-specific

**Optimize for:**
- Standard 16:9 aspect ratio
- System-safe fonts (Arial, Calibri as fallback)
- Self-contained (embed images)
- Version compatibility (Office 2016+)

### PDF
**Strengths:** Universal compatibility, preserves design, print-ready  
**Weaknesses:** No interactivity, fixed layout

**Optimize for:**
- High-resolution images (300 DPI for print)
- Embedded fonts
- Reasonable file size (<10MB)
- Accessibility (tagged PDF if possible)

### Gamma.app (Web)
**Strengths:** Modern design, responsive, easy sharing, analytics  
**Weaknesses:** Requires internet, limited offline access

**Optimize for:**
- Clear markdown structure
- Descriptive visual suggestions
- Mobile-responsive content
- Fast loading (optimize images)

### Google Slides
**Strengths:** Collaboration, cloud-based, free  
**Weaknesses:** Limited design features, requires Google account

**Optimize for:**
- Web fonts available in Google Fonts
- Simple layouts (complex designs may break)
- Collaborative comments/suggestions

## Accessibility Guidelines

**Text readability:**
- Minimum 16pt for body text
- High contrast (4.5:1 minimum)
- Sans-serif fonts for digital presentations
- Line height 1.4-1.6x font size

**Color blindness:**
- Don't use red/green alone for differentiation
- Add patterns or icons
- Test with colorblind simulators

**Alternative text:**
- Describe charts and diagrams in notes
- Provide transcripts for important visual info
- Use descriptive link text

## Design Checklist

Before finalizing presentation design:
- [ ] Consistent color palette (≤4 colors)
- [ ] Consistent typography (≤2 font families)
- [ ] Appropriate cognitive density for audience
- [ ] All charts have clear insights annotated
- [ ] Images are high-resolution and meaningful
- [ ] White space ≥30% of each slide
- [ ] Text contrast meets accessibility standards
- [ ] Icon style consistent throughout
- [ ] Visual hierarchy guides eye naturally
- [ ] No orphaned bullets or widows
- [ ] All data visualizations have sources cited
- [ ] Format compatible with delivery method
