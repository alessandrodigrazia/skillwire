#!/usr/bin/env python3
"""
Convert Gamma.app markdown format to PowerPoint presentation.

This script converts the Gamma.app markdown format (---CARD N--- delimited)
into a basic PowerPoint (.pptx) file with structured slides.

Usage:
    python convert_to_pptx.py input.md output.pptx
    python convert_to_pptx.py input.md  # Auto-generates output filename

Dependencies:
    python-pptx: pip install python-pptx --break-system-packages

Author: B2B Presentation Builder Skill
Version: 1.0
"""

import re
import sys
from pathlib import Path

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN, MSO_AUTO_SIZE
    from pptx.dml.color import RGBColor
except ImportError:
    print("Error: python-pptx not installed")
    print("Install with: pip install python-pptx --break-system-packages")
    sys.exit(1)


class GammaMarkdownParser:
    """Parse Gamma.app markdown format into structured slides."""
    
    CARD_DELIMITER = r'^---CARD\s+(\d+)---$'
    
    def __init__(self, markdown_text):
        self.markdown = markdown_text
        self.slides = []
    
    def parse(self):
        """Parse markdown into slide objects."""
        # Split by card delimiters
        card_pattern = re.compile(self.CARD_DELIMITER, re.MULTILINE)
        cards = card_pattern.split(self.markdown)
        
        # First element is content before first card (ignore if empty)
        cards = cards[1:]  # Skip intro content
        
        # Process pairs of (card_number, card_content)
        for i in range(0, len(cards), 2):
            if i + 1 < len(cards):
                card_num = cards[i]
                card_content = cards[i + 1].strip()
                
                slide_data = self._parse_slide_content(card_content)
                slide_data['number'] = int(card_num)
                self.slides.append(slide_data)
        
        return self.slides
    
    def _parse_slide_content(self, content):
        """Parse individual slide content into title, subtitle, body, visual suggestions."""
        lines = content.split('\n')
        
        slide = {
            'title': '',
            'subtitle': '',
            'body': [],
            'visual_suggestions': ''
        }
        
        current_section = 'body'
        
        for line in lines:
            line = line.strip()
            
            if not line:
                continue
            
            # Title (# Heading)
            if line.startswith('# '):
                slide['title'] = line[2:].strip()
            
            # Subtitle (## Heading)
            elif line.startswith('## '):
                slide['subtitle'] = line[3:].strip()
            
            # Visual suggestions marker
            elif line.startswith('**Visual suggestions:**') or line.startswith('**Visual:**'):
                current_section = 'visual'
                # Extract text after the marker
                visual_text = re.sub(r'\*\*Visual.*?:\*\*\s*', '', line)
                if visual_text:
                    slide['visual_suggestions'] = visual_text
            
            # Body content
            else:
                if current_section == 'visual':
                    slide['visual_suggestions'] += ' ' + line
                else:
                    # Clean markdown formatting
                    clean_line = self._clean_markdown(line)
                    if clean_line:
                        slide['body'].append(clean_line)
        
        return slide
    
    def _clean_markdown(self, text):
        """Remove markdown formatting."""
        # Remove bold
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)
        # Remove italic
        text = re.sub(r'\*(.*?)\*', r'\1', text)
        # Remove bullet markers
        text = re.sub(r'^[-*]\s+', '', text)
        return text.strip()


class PowerPointBuilder:
    """Build PowerPoint presentation from parsed slides."""
    
    # Color scheme (can be customized)
    PRIMARY_COLOR = RGBColor(0, 82, 204)  # Blue
    TEXT_COLOR = RGBColor(23, 43, 77)     # Dark blue-gray
    SUBTITLE_COLOR = RGBColor(107, 119, 140)  # Gray
    
    def __init__(self):
        self.prs = Presentation()
        self.prs.slide_width = Inches(10)
        self.prs.slide_height = Inches(7.5)
    
    def add_slide(self, slide_data):
        """Add a slide to the presentation."""
        # Use blank layout
        blank_slide_layout = self.prs.slide_layouts[6]
        slide = self.prs.slides.add_slide(blank_slide_layout)
        
        # Add title
        if slide_data.get('title'):
            title_box = slide.shapes.add_textbox(
                Inches(0.5), Inches(0.5),
                Inches(9), Inches(1)
            )
            title_frame = title_box.text_frame
            title_frame.text = slide_data['title']
            
            # Format title
            for paragraph in title_frame.paragraphs:
                paragraph.font.size = Pt(36)
                paragraph.font.bold = True
                paragraph.font.color.rgb = self.PRIMARY_COLOR
        
        # Add subtitle
        if slide_data.get('subtitle'):
            subtitle_box = slide.shapes.add_textbox(
                Inches(0.5), Inches(1.5),
                Inches(9), Inches(0.5)
            )
            subtitle_frame = subtitle_box.text_frame
            subtitle_frame.text = slide_data['subtitle']
            
            # Format subtitle
            for paragraph in subtitle_frame.paragraphs:
                paragraph.font.size = Pt(20)
                paragraph.font.color.rgb = self.SUBTITLE_COLOR
        
        # Add body content
        if slide_data.get('body'):
            body_top = Inches(2.5) if slide_data.get('subtitle') else Inches(1.8)
            body_box = slide.shapes.add_textbox(
                Inches(0.5), body_top,
                Inches(9), Inches(4)
            )
            body_frame = body_box.text_frame
            body_frame.word_wrap = True
            
            for item in slide_data['body']:
                p = body_frame.add_paragraph()
                p.text = item
                p.font.size = Pt(16)
                p.font.color.rgb = self.TEXT_COLOR
                p.space_before = Pt(6)
                p.level = 0
        
        # Add visual suggestions as footer note
        if slide_data.get('visual_suggestions'):
            notes_slide = slide.notes_slide
            text_frame = notes_slide.notes_text_frame
            text_frame.text = f"Visual suggestions: {slide_data['visual_suggestions']}"
    
    def save(self, output_path):
        """Save presentation to file."""
        self.prs.save(output_path)


def convert_gamma_to_pptx(input_file, output_file=None):
    """
    Convert Gamma.app markdown to PowerPoint.
    
    Args:
        input_file: Path to input markdown file
        output_file: Path to output .pptx file (auto-generated if None)
    
    Returns:
        Path to output file
    """
    input_path = Path(input_file)
    
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_file}")
    
    # Auto-generate output filename if not provided
    if output_file is None:
        output_file = input_path.with_suffix('.pptx')
    else:
        output_file = Path(output_file)
    
    # Read markdown
    with open(input_path, 'r', encoding='utf-8') as f:
        markdown_text = f.read()
    
    # Parse markdown
    parser = GammaMarkdownParser(markdown_text)
    slides = parser.parse()
    
    if not slides:
        raise ValueError("No slides found in markdown file")
    
    # Build PowerPoint
    builder = PowerPointBuilder()
    for slide_data in slides:
        builder.add_slide(slide_data)
    
    # Save
    builder.save(output_file)
    
    return output_file


def main():
    """Command-line interface."""
    if len(sys.argv) < 2:
        print("Usage: python convert_to_pptx.py input.md [output.pptx]")
        print("\nExample:")
        print("  python convert_to_pptx.py presentation.md")
        print("  python convert_to_pptx.py presentation.md output.pptx")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    try:
        output_path = convert_gamma_to_pptx(input_file, output_file)
        print(f"✅ Success! PowerPoint created: {output_path}")
        print(f"   {len(GammaMarkdownParser(open(input_file).read()).parse())} slides converted")
        print("\n📝 Note: This is a basic structure. Visual design requires manual refinement.")
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
