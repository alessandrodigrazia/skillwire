---
name: b2b-presentation-builder
description: |
  B2B presentations for C-level with enterprise frameworks. Multi-persona (CFO/CIO/CEO), ROI focus, QA workflow.
  This skill should be used when creating sales decks, preparing investor pitches, building C-level presentations,
  or designing proposal documents for enterprise clients.
---

# B2B Presentation Builder

Create high-converting B2B presentations using proven enterprise sales frameworks, with built-in self-optimization and multi-persona targeting.

## Core Workflow

Follow this 5-phase process for every presentation:

### Phase 1: Discovery & Context Gathering

Ask the user strategic questions to understand:
- **Target audience** (CFO/CIO/CEO/Board - affects structure and content density)
- **Presentation goal** (awareness/consideration/decision - affects CTA)
- **Context** (first meeting/follow-up/tender response - affects proof depth)
- **Company/offering** (the user's company, product, or service to present)
- **Constraints** (time limit, slide count, existing materials)
- **Desired output formats** (default: Gamma.app markdown; optional: PPTX, PDF)

### Phase 2: Structure Selection

Based on discovery, select appropriate framework from `references/presentation-frameworks.md`:
- **Executive Deck** (8-10 slides, strategic focus, <20 min presentation)
- **Operational Deck** (12-15 slides, balanced strategy+implementation)
- **Sales Conversation Deck** (20-25 modular slides, non-linear navigation)
- **Executive Summary** (5-7 slides, BLUF for C-Suite with limited time)

**For narrative structure**, also read `references/narrative-frameworks.md` to select:
- **Raskin 5-Step** - For markets in disruption, category creation
- **Dunford 8-Step** - For high "no decision" markets (40-60% deals)
- **Challenger 6-Step** - For educational pitches requiring reframe

Route to framework details: Read `references/presentation-frameworks.md` for structure templates.
Route to narrative guidance: Read `references/narrative-frameworks.md` for storytelling frameworks.

### Phase 3: Content Generation

Generate slide content following patterns from `references/content-patterns.md`:
- Apply template patterns for consistency
- Use examples patterns for social proof
- Implement conditional workflow for personalization
- Apply strategic framing (problem->opportunity, cost->investment)

**Default output format: Gamma.app markdown**

Structure each slide as:
```
---CARD [number]---
# [Title]
## [Subtitle/Tagline - optional]

[Body content - clear, scannable, 30-80 words depending on slide type]

**Visual suggestions:** [Describe recommended visual elements: charts, icons, imagery style]
```

Route to content guidance: Read `references/content-patterns.md` for messaging frameworks.

### Phase 4: Design Principles Application

Apply visual best practices from `references/design-principles.md`:
- Respect cognitive density limits per audience type
- Suggest effective data visualizations where relevant
- Maintain visual hierarchy and tactical minimalism
- Provide guidance for multi-format export

Route to design guidance: Read `references/design-principles.md` for visual standards.

### Phase 5: Self-Optimization (User-Selectable)

**CRITICAL: Always ask the user which level of review they want:**

> "I've generated the presentation structure and content. How deeply should I review and optimize it?
>
> - **Light** (5 min) - Quick sanity check for obvious issues
> - **Standard** (10 min) - Multi-perspective analysis + anti-pattern detection
> - **Deep** (15 min) - Full Socratic review + A/B variant generation for key slides
>
> Choose your preferred level, or select 'Skip' if you want to iterate manually."

Based on user selection, apply the appropriate optimization level from `references/optimization-framework.md`.

Route to optimization: Read `references/optimization-framework.md` and apply the selected review level.

## Customizing with Your Own Knowledge Base

This skill works with any B2B company. To get the best results, provide context about your company during Phase 1, or create a `references/examples/` directory with:

- `knowledge-base.md` - Your company positioning, method, ecosystem, messaging
- `case-studies.md` - Your anonymized case studies with proof points
- `brand-guidelines.md` - Your tone, voice, visual identity, key phrases

An example knowledge base structure is included in `references/examples/` to show how to format these files.

### Presentation Patterns

**Opening Slide Pattern:**
- Lead with your core positioning or tagline
- Promise the value proposition clearly
- Keep it to one impactful statement

**Discovery Slide Pattern (for sales meetings):**
Three diagnostic questions:
1. In the last 12-24 months, have you launched initiatives in [your domain]?
2. If yes: how many are in production with measurable P&L impact?
3. If no: what stopped you?

**Problem Slide Pattern:**
Frame with a divide or paradox in your industry - three patterns:
1. Many pilots, few results
2. Marginal efficiency (micro-tasks, not real processes)
3. Organizational debt (undefined processes, misaligned data)

**Solution Slide Pattern:**
Use a visual metaphor (e.g., iceberg, bridge, pyramid) to show:
- The visible part (technology, features)
- The invisible part (people, processes, data, governance)

**Proof Slide Pattern:**
Include case studies that show:
- **Type A** - When you recommended NOT proceeding (builds trust)
- **Type B** - When foundations enabled a clear roadmap (builds confidence)

**CTA Slide Pattern:**
Offer a specific, time-bound next step:
- Define the meeting type and duration
- Set expectations for what will be covered
- Make the commitment level appropriate for the stage

Contact details should use this placeholder format:
```
[Your Name]
[Your Role], [Your Company]
[your.email@company.com] | [+XX XXX XXX XXXX]
```

## Output Formats

**Primary format:** Gamma.app markdown (as shown in Phase 3)

**Additional formats** (if requested):
- PowerPoint (.pptx) - Use `scripts/convert_to_pptx.py` for basic conversion
- PDF - Export from Gamma or use system PDF generation
- Google Slides - Manual export recommendation (no direct conversion)

Note: The conversion script provides basic structure only. Visual refinement requires manual editing.

## Reference Files Navigation

Load references progressively based on workflow phase:

| Phase | Read This Reference |
|-------|---------------------|
| Structure selection | `references/presentation-frameworks.md` |
| Narrative framework | `references/narrative-frameworks.md` |
| Content generation | `references/content-patterns.md` |
| Visual guidance | `references/design-principles.md` |
| Self-optimization | `references/optimization-framework.md` |
| Company-specific | `references/examples/*.md` (user-provided) |

## Quick Start Examples

### Example 1: CFO Pitch
**User:** "Create an executive presentation to pitch a CFO on our AI consulting services"

**Claude workflow:**
1. Ask 3-4 clarifying questions (company size, pain point, timeline)
2. Read `references/presentation-frameworks.md` -> Select "Executive Deck CFO-focused"
3. Use company context provided by user for content
4. Lead with value positioning, emphasize investment protection
5. Include a case study showing ROI (ideally from user's examples)
6. Generate 10 slides in Gamma.app format
7. Ask: "Light/Standard/Deep review?"
8. Deliver optimized presentation

### Example 2: First Meeting Deck
**User:** "Create a first meeting presentation for our consulting firm"

**Claude workflow:**
1. Ask about company positioning, target audience, key differentiators
2. Open with a provocative insight about the industry
3. Include three diagnostic questions
4. Present the problem/divide in the market
5. Show your unique methodology
6. Present proof points and case studies
7. Include both "we said no" and "we delivered results" stories
8. CTA: Strategic conversation with specific duration and agenda

## Common Patterns to Avoid

**Structural rules:**
- **Never** generate more than 12 slides for Executive decks (attention span limit)
- **Never** include claims without proof within 2 slides
- **Never** use >80 words per slide for Executive audience (except opening/closing)
- **Always** include at least one quantified outcome in B2B sales context
- **Always** provide concrete CTAs with timeline/investment indication

**Evidence-based rules (from Gong Labs 67K+ presentations):**
- **Never** spend >2 minutes on company intro (kills close rate)
- **Never** monologue for >9 minutes without break (insert brain-perking pause)
- **Never** show social proof before establishing problem+solution (-47% close rate if early)
- **Never** start with "About Us", history, or "we are leaders" (prospect doesn't care)
- **Always** use Action Titles that communicate the SO WHAT, not just WHAT
- **Always** address "Why Change" before "Why Us" (40-60% deals end in "no decision")

**Best practices for your own company content:**
- **Always** lead with your core positioning, never with technology alone
- **Always** include at least one "we recommended NOT proceeding" story (builds trust)
- **Always** show modular pricing with clear entry points
- **Never** promise quick fixes -- emphasize foundations first
- **Never** hide pricing ranges -- transparency builds trust

## Scripts

- `scripts/convert_to_pptx.py` - Convert Gamma markdown to basic PowerPoint structure

## Memory Integration

This skill supports persistent cross-session memory for tracking presentations in progress.

### Storage
- Path: `.claude/skills/b2b-presentation-builder/memory/`
- Types: `projects/` (presentations by client)

### Auto-Load (Skill Start)
When a client or presentation is mentioned:
1. Search in `memory/_index.json`
2. Load `projects/{client-slug}.json` if it exists
3. Use context (target persona, chosen framework, approved messaging) for continuity

### Auto-Save (via session-closer)
At session close, propose saving:
- **Presentation facts**: client, target persona (CFO/CIO/CEO), framework used
- **Messaging**: approved value proposition, handled objections, proof points used
- **Feedback**: iterations made, style preferences, elements to keep/avoid

### Manual Recall
To retrieve specific memory: `/memory recall {client}`
