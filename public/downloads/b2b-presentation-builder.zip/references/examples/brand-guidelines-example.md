# Example Brand Guidelines

This file shows how to structure brand guidelines for use with the B2B Presentation Builder skill. Replace with your own brand voice, visual identity, and communication standards.

## Brand Essence

**What we are:**
[Your core identity in one sentence]

**What we're not:**
- [Anti-positioning 1]
- [Anti-positioning 2]
- [Anti-positioning 3]

**Our promise:**
[Your brand promise]

---

## Core Positioning

### Motto
**"[Your Motto]"**

### Primary Tagline
**"[Your Primary Tagline]"**

### Supporting Tagline
**"[Your Supporting Tagline]"**

---

## Tone of Voice

### Core Attributes

**1. [Attribute 1 - e.g., Professional but Pragmatic]**
- [Description and examples]

**2. [Attribute 2 - e.g., Challenging but Respectful]**
- [Description and examples]

**3. [Attribute 3 - e.g., Confident but Humble]**
- [Description and examples]

**4. [Attribute 4 - e.g., Data-Driven but Human-Centered]**
- [Description and examples]

---

## Language Guidelines

### Words to Use Often
- [Word/phrase 1]
- [Word/phrase 2]
- [Word/phrase 3]

### Words to Avoid
- [Buzzword 1]
- [Buzzword 2]
- [Buzzword 3]

### Phrases That Work

**Core Framework:**
- "[Your framework phrase 1]"
- "[Your framework phrase 2]"

**Problem Naming:**
- "[Problem name 1]"
- "[Problem name 2]"

**Trust Builders:**
- "[Trust phrase 1]"
- "[Trust phrase 2]"

---

## Visual Identity

### Color Philosophy

**Primary Palette:**
- Primary: #[XXXXXX] ([color name])
- Secondary: #[XXXXXX] ([color name])
- Text: #[XXXXXX] ([color name])
- Background: #[XXXXXX] ([color name])

### Typography

**Headlines:** [Font name] (bold)
**Body:** [Font name] (regular/medium)

### Visual Style

**Core visual metaphor:** [Your metaphor, e.g., iceberg, bridge, pyramid]

**Photography (when used):**
- Authentic over stock
- Real work environments
- Diverse, relatable people

---

## Key Messages by Context

### For Problem Awareness
> "[Message 1]"
> "[Message 2]"

### For Differentiation
> "[Message 1]"
> "[Message 2]"

### For Trust
> "[Message 1]"
> "[Message 2]"

### For Urgency
> "[Message 1]"
> "[Message 2]"

---

## Adapting Tone by Audience

### CFO
- **More:** ROI metrics, risk protection, modular investment, governance
- **Less:** Technical jargon, implementation details

### CIO/CTO
- **More:** Architecture decisions, data foundation, integration patterns
- **Less:** High-level strategy only, vague promises

### CEO
- **More:** Competitive positioning, strategic clarity, board-ready plans
- **Less:** Tactical details, technology specifics

---

## Contact Signature

Standard format for all communications:

```
[Your Name]
[Your Role]
[Your Company]

[your.email@company.com]
[+XX XXX XXX XXXX]
[www.yourcompany.com]

"[Your tagline]"
```
