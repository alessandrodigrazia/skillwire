# Example Case Studies

This file shows how to structure case studies for use with the B2B Presentation Builder skill. Replace with your own anonymized case studies.

---

## Case Study Structure

Each case follows a B2B-optimized structure designed for maximum impact in presentations:

1. **Context** -- Who they are (sector, scale, employees)
2. **Challenge** -- What they were looking for
3. **Approach** -- What we did (interviews, scope)
4. **Findings** -- What we discovered (pain points, insights)
5. **Outcome** -- The decision and its value
6. **Key Insight** -- The lesson that applies to your situation

---

## Case Studies by Outcome Type

### Type A: "Foundation First"
Cases where your analysis identified missing prerequisites. The right answer was NOT to proceed immediately.

### Type B: "Validate & Scale"
Cases where foundations were solid and you could proceed with an implementation roadmap.

---

## TYPE A: Foundation First

### Case 1: [Industry] Company
**When saying NO was the right answer**

| Attribute | Detail |
|-----------|--------|
| **Sector** | [Industry vertical] |
| **Revenue** | [Approximate range] |
| **Employees** | [Range] |

**Challenge:**
[What the client initially requested]

**Approach:**
- [N] interviews involving [N]+ people
- Coverage: [departments/functions covered]
- Deep analysis of [specific areas]

**Findings:**
- [N]+ pain points identified and categorized
- [Key finding 1]
- [Key finding 2]
- [Key finding 3]

**Outcome:**
[What you recommended and why]

**Value Generated:**
- [Value 1]
- [Value 2]
- [Value 3]

**Key Insight:**
> "[Quotable insight that captures the lesson]"

---

## TYPE B: Ready to Proceed

### Case 2: [Industry] Company
**When foundations enabled a clear roadmap**

| Attribute | Detail |
|-----------|--------|
| **Sector** | [Industry vertical] |
| **Revenue** | [Approximate range] |
| **Employees** | [Range] |

**Challenge:**
[What the client needed]

**Approach:**
- [N] interviews involving [N]+ people
- Coverage: [departments/functions covered]

**Findings:**
- [N] pain points identified and categorized
- [Key finding that enabled proceeding]

**Outcome:**
[Clear roadmap delivered with timelines and costs]

**Value Generated:**
- [Value 1]
- [Value 2]
- [Value 3]

**Key Insight:**
> "[Quotable insight]"

---

## Proof Points Summary

### Engagement Metrics Across Cases

| Metric | Range | Average |
|--------|-------|---------|
| Interviews per engagement | [range] | [avg] |
| People involved | [range] | [avg] |
| Pain points identified | [range] | [avg] |

### Outcome Distribution
- **[X]% "Foundation First"** -- Recommended fixing prerequisites before proceeding
- **[X]% "Ready to Proceed"** -- Clear roadmap with timelines and costs produced

---

## How to Use These Case Studies

### In First Meetings
Use a "Foundation First" case to establish credibility and honesty.

### When Facing Skeptics
Use a pragmatic case that shows you recommend alternatives when appropriate.

### When Building Urgency
Use a "Ready to Proceed" case to show what's possible when conditions are right.

### When Discussing Complexity
Use a case with many pain points to show your analytical depth.

---

## Contact

**[Your Name]**
[Your Role], [Your Company]
Email: [your.email@company.com]
Phone: [+XX XXX XXX XXXX]
