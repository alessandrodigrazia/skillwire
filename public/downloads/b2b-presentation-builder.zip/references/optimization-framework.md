# Optimization Framework

Self-review system for improving presentation quality through structured analysis.

## User Selection Prompt

**ALWAYS ask the user this question after generating initial content:**

> I've generated the presentation structure and content. How deeply should I review and optimize it?
> 
> - **Light** (5 min) - Quick sanity check for obvious issues
> - **Standard** (10 min) - Multi-perspective analysis + anti-pattern detection  
> - **Deep** (15 min) - Full Socratic review + A/B variant generation for key slides
> 
> Choose your preferred level, or select **'Skip'** if you want to iterate manually.

Then apply the selected optimization level below.

---

## LIGHT Review (5 minutes)

Quick quality check focused on critical flaws that would undermine credibility.

### Checklist (5 items)

1. **Message-Proof Gap Check**
   - Question: "Is every claim backed by proof within 2 slides?"
   - Action: Flag any unsupported claims

2. **Cognitive Overload Check**
   - Question: "Are any Executive slides >60 words or >3 bullets?"
   - Action: Flag and suggest condensing

3. **CTA Clarity Check**
   - Question: "Does the closing slide have a concrete, time-bound next step?"
   - Action: If vague, provide specific alternative

4. **Visual Suggestion Quality**
   - Question: "Is every visual suggestion specific enough to execute?"
   - Action: Flag generic suggestions ("add image") and make specific

5. **Slide Count vs Audience**
   - Question: "Does slide count match audience type?"
   - Executive: ≤10 slides
   - Operational: ≤15 slides
   - Action: Flag if exceeds and suggest cuts

### Output Format

```
🔍 LIGHT REVIEW COMPLETED

Issues found: [N]

1. [Issue type] - Slide X: [Problem]
   → Suggested fix: [Specific action]

2. [Issue type] - Slide Y: [Problem]
   → Suggested fix: [Specific action]

✅ All other criteria passed.

Would you like me to implement these fixes automatically?
```

---

## STANDARD Review (10 minutes)

Comprehensive analysis from multiple buyer perspectives plus anti-pattern detection.

### Step 1: Multi-Perspective Analysis

Analyze the presentation through three buyer lenses:

#### CFO Lens
**Questions to ask:**
- "Where's the quantified business case? Is payback period mentioned?"
- "Are costs transparent or vague?"
- "Is risk mitigation addressed?"
- "Do the metrics matter to P&L?"
- "Is there benchmark data to validate claims?"

**Output:**
```
💰 CFO PERSPECTIVE

Strengths:
- [What a CFO would like]

Gaps:
- [What would make a CFO hesitate]
- [Missing financial proof points]

Recommendations:
- Slide X: Add [specific financial metric]
- Slide Y: Include [risk mitigation element]
```

#### CIO/CTO Lens
**Questions to ask:**
- "Is technical feasibility credible?"
- "Are integration points with existing systems addressed?"
- "Is the implementation roadmap realistic?"
- "Are there enough technical details without overwhelming?"
- "Is vendor lock-in risk addressed?"

**Output:**
```
⚙️ CIO/CTO PERSPECTIVE

Strengths:
- [What technical buyer would value]

Gaps:
- [Technical credibility concerns]
- [Implementation questions unanswered]

Recommendations:
- Slide X: Add [technical architecture element]
- Slide Y: Address [integration concern]
```

#### CEO Lens
**Questions to ask:**
- "Does this feel strategic or tactical?"
- "Is competitive positioning clear?"
- "Is there a compelling vision?"
- "Does this align with typical CEO priorities (growth, market position, transformation)?"
- "Is there urgency or can this wait?"

**Output:**
```
🎯 CEO PERSPECTIVE

Strengths:
- [Strategic elements that resonate]

Gaps:
- [Lacks strategic punch]
- [Missing competitive context]

Recommendations:
- Slide X: Elevate from tactical to strategic by [action]
- Slide Y: Add competitive urgency with [element]
```

### Step 2: Anti-Pattern Detection

Scan for common B2B presentation anti-patterns:

**Pattern 1: Vague Value Props**
- ❌ "Increase efficiency"
- ✅ "Reduce process time by 40% (from 10 days to 6 days)"
- Action: Flag and quantify

**Pattern 2: Feature Dumping**
- ❌ Listing 10 features without context
- ✅ 3 capabilities tied to specific outcomes
- Action: Reduce and connect to outcomes

**Pattern 3: Proof Deserts**
- ❌ 5+ slides of claims with no case studies
- ✅ Claim → Proof within 2 slides
- Action: Insert proof or cut claims

**Pattern 4: The Generic CTA**
- ❌ "Let's discuss next steps"
- ✅ "Schedule 60-min workshop within 7 days to map your top 3 AI opportunities"
- Action: Make specific and time-bound

**Pattern 5: Death by Bullets**
- ❌ Slides with 6+ bullets or nested bullets
- ✅ Maximum 3-5 bullets, single level
- Action: Consolidate or split slide

**Pattern 6: Chart Chartjunk**
- ❌ 3D charts, excessive gridlines, no annotation
- ✅ Flat charts with clear insight highlighted
- Action: Simplify and annotate

**Pattern 7: The Credibility Gap**
- ❌ No team credentials, client proof, or track record
- ✅ Explicit "Why Us" with evidence
- Action: Add credibility elements

**Pattern 8: ROI Hand-Waving**
- ❌ "Significant ROI" or "Positive payback"
- ✅ "Typical payback: 4-6 months, 4-6x return in year 1"
- Action: Quantify with ranges

### Quantified Anti-Patterns (Evidence-Based)

Rules derived from Gong Labs analysis of 67,149+ presentations.

**Pattern 9: Company Intro Overload**
- **Data:** Presentations with >2 minutes of company intro have significantly lower close rates
- ❌ Starting with company history, founders, mission, "we are market leaders"
- ✅ Company intro ≤2 minutes (1-2 slides max), credentials AFTER value
- **Detection:** Count words/time in first 2 slides talking about "us"
- **Action:** Move credentials after Solution, reduce to max 60 words

**Pattern 10: The 9-Minute Violation**
- **Data:** Every closed deal had pitches ≤9 mins. Lost deals averaged 11.4 mins
- ❌ Continuous monologue >9 mins
- ✅ "Brain-perking change of pace" after 9 mins (question, demo, discussion)
- **Detection:** Estimated time per section (2 min/slide baseline)
- **Action:** Insert natural breaks, segment into blocks ≤9 min

**Pattern 11: Premature Social Proof**
- **Data:** Social proof introduced too early reduces close rate by 47%
- ❌ Opening with client logos, testimonials in first half
- ✅ Proof comes AFTER problem + solution (sequence: Problem → Solution → THEN Proof)
- **Detection:** Check position of case study and logos
- **Action:** Move proof after slide 6-7, never before slide 4

**Pattern 12: The "About Us" Trap**
- **Data:** Prospects don't care about your story (only their problems)
- ❌ "Founded in [year]...", list of names and titles without context
- ✅ Team slide answering: "Why is THIS team perfect for THIS problem?"
- **Detection:** Look for company history, founding, generic growth phrases
- **Action:** Transform into "strategic assets for your specific case"

**Pattern 13: Slide Title Fail**
- **Data:** Descriptive titles don't communicate value (McKinsey Action Title principle)
- ❌ "Market Analysis", "Product Overview", "Team"
- ✅ "Three untapped markets drive 40% of growth", "30+ years of AI transformation"
- **Detection:** Check if every title communicates the SO WHAT
- **Action:** Rewrite titles with formula [Quantification] + [Outcome]

**Pattern 14: No Decision Blindness**
- **Data:** 40-60% of B2B deals end in "no decision" (status quo wins)
- ❌ Ignoring status quo as a competitor
- ✅ Sell "Why Change" BEFORE "Why Us", quantify cost of inaction
- **Detection:** Check if there's a slide addressing "why not wait?"
- **Action:** Add "Cost of Inaction" slide with loss aversion framing

### Step 3: Synthesis and Prioritization

Combine findings and prioritize:

**Output:**
```
📊 STANDARD REVIEW COMPLETED

Multi-Perspective Findings:
- CFO concerns: [Top 2]
- CIO concerns: [Top 2]
- CEO concerns: [Top 2]

Anti-Patterns Detected:
1. [Pattern name] - Slides X, Y, Z
2. [Pattern name] - Slides A, B

Priority Fixes (High Impact):
1. [Most critical issue with highest ROI fix]
2. [Second most critical]
3. [Third most critical]

Quick Wins (Easy Fixes):
1. [Low effort, visible improvement]
2. [Low effort, visible improvement]

Would you like me to implement all fixes, just priority fixes, or iterate together?
```

---

## DEEP Review (15 minutes)

Socratic dialogue, rigorous stress-testing, and A/B variant generation for critical slides.

### Step 1: Apply Light + Standard Reviews

Start with Light and Standard review processes (summarized).

### Step 2: Socratic Questioning

Ask tough questions that force critical thinking:

**About Problem Diagnosis (Slide 2-3):**
- "What if the prospect says this isn't actually their problem?"
- "Is this problem urgent enough to justify action NOW vs next quarter?"
- "What's the strongest counterargument to this being a priority?"
- "Could they solve this in-house cheaper/faster?"

**About Solution (Slide 4-5):**
- "What's the most fragile assumption in our approach?"
- "If a competitor saw this, what would they attack first?"
- "What's NOT included that might cause surprise later?"
- "Is there a simpler alternative we're not acknowledging?"

**About Proof (Slide 6-7):**
- "Would a skeptical CFO find these case studies convincing?"
- "What data is missing that would make this irrefutable?"
- "Are we cherry-picking results?"
- "How recent and relevant are these examples?"

**About ROI/Business Case (Slide 7-8):**
- "What assumptions drive this ROI that could be wrong?"
- "What's the worst-case scenario with conservative assumptions?"
- "Is payback period realistic or optimistic?"
- "What hidden costs aren't accounted for?"

**About Next Steps (Slide 10):**
- "What would make someone NOT take this next step?"
- "Is the commitment level appropriate for this stage?"
- "What information gap might prevent action?"

**Output:**
```
❓ SOCRATIC ANALYSIS

Critical Questions Raised:
1. [Question about Slide X]
   → Current answer strength: [Weak/Medium/Strong]
   → Suggested reinforcement: [How to strengthen]

2. [Question about Slide Y]
   → Current answer strength: [Weak/Medium/Strong]
   → Suggested reinforcement: [How to strengthen]

[Continue for 5-7 critical questions]
```

### Step 3: Devil's Advocate Role-Play

Argue AGAINST the presentation from competitor perspectives:

**Big4 Consulting Competitor:**
> "This boutique firm lacks our global scale, proven frameworks, and Fortune 500 relationships. They'll learn on your dime while we bring battle-tested methodologies from 1000+ transformations."

**Your counter:**
[Develop strong counter-argument]

**Hyperscaler (AWS/Azure/Google) Competitor:**
> "We offer similar consulting plus seamless integration with our platform, all backed by [$B] R&D investment. Why work with a middleman?"

**Your counter:**
[Develop strong counter-argument]

**In-House Team:**
> "We know our business better than any consultant. Give us 6 months and the budget, we'll figure it out. No premium consultancy fees."

**Your counter:**
[Develop strong counter-argument]

**Status Quo (Do Nothing):**
> "This feels like a 'nice to have,' not a 'must have.' We have 10 other priorities ahead of AI transformation. Let's revisit next fiscal year."

**Your counter:**
[Develop strong counter-argument]

**Output:**
```
👿 DEVIL'S ADVOCATE STRESS TEST

Competitor Attack Vectors:
1. [Attack angle]
   Current defense: [How presentation addresses this]
   Gap: [What's missing]
   Recommendation: [How to strengthen defense on Slide X]

2. [Attack angle]
   Current defense: [...]
   Gap: [...]
   Recommendation: [...]

Hardening Strategy:
- Add to Slide X: [Preemptive response to attack 1]
- Add to Slide Y: [Preemptive response to attack 2]
```

### Step 4: A/B Variant Generation

For 2-3 critical slides, generate alternative versions:

**Slide 2 (Problem Diagnostic) - A/B Test:**

**Version A (Current):** [Show current approach]

**Version B (Alternative):** [Generate alternative that:]
- Uses different framing (opportunity vs problem)
- Different data/proof point
- Different emotional appeal

**Comparison:**
- Version A strength: [When this works better]
- Version B strength: [When this works better]
- Recommendation: [Which to use when]

**Slide 7 (ROI/Business Case) - A/B Test:**

**Version A (Current):** [Show current approach]

**Version B (Alternative):** [Generate alternative that:]
- Uses different metric (NPV vs payback vs IRR)
- Different timeframe (6 month vs 3 year)
- Different framing (cost avoidance vs revenue gain)

**Comparison:**
- Version A strength: [When this resonates]
- Version B strength: [When this resonates]
- Recommendation: [Audience-based selection]

**Output:**
```
🔄 A/B VARIANT ANALYSIS

Slide X - [Slide name]

VERSION A (Current):
[Summary of current approach]

VERSION B (Alternative):
[Summary of alternative approach]

Testing Recommendation:
- Use Version A when: [Context 1]
- Use Version B when: [Context 2]
- Winning variant: [If one is clearly stronger]

[Repeat for 2-3 critical slides]
```

### Step 5: Final Synthesis

Comprehensive summary and action plan:

**Output:**
```
🎯 DEEP REVIEW COMPLETED

CRITICAL FINDINGS (Fix These):
1. [Highest priority issue]
   - Impact: [Why this matters]
   - Fix: [Specific action on Slide X]

2. [Second highest]
   - Impact: [...]
   - Fix: [...]

3. [Third highest]
   - Impact: [...]
   - Fix: [...]

STRATEGIC ENHANCEMENTS (Consider These):
1. [Enhancement that would elevate quality]
2. [Enhancement that would strengthen positioning]
3. [Enhancement that would improve conversion]

VARIANT RECOMMENDATIONS:
- Slide X: Use Version [A/B] for [audience type]
- Slide Y: Use Version [A/B] for [context]

STRESS TEST RESULTS:
- Competitor defensibility: [Score 1-10]
- Objection handling: [Score 1-10]
- Proof strength: [Score 1-10]

NEXT STEPS:
[ ] Implement critical findings
[ ] Consider strategic enhancements
[ ] Prepare A/B variants for key audiences
[ ] Add preemptive objection handling

Would you like me to:
1. Implement all critical findings automatically
2. Implement selectively (you choose which)
3. Provide the revised presentation with changes tracked
```

---

## Implementation Workflow

After user selects optimization level and reviews findings:

### Option 1: Automatic Implementation
Claude makes all recommended changes and presents updated Gamma.app markdown with:
- 📝 Change log showing what was modified
- 🎯 Key improvements highlighted
- ✅ Issues resolved checklist

### Option 2: Selective Implementation
User selects which fixes to apply:
- Claude implements only chosen fixes
- Provides updated version
- Leaves other issues flagged for later

### Option 3: Collaborative Iteration
Claude explains each issue:
- User provides guidance on preference
- Claude implements with user direction
- Iterates until user satisfied

---

## Optimization Metrics

Track improvement through optimization:

**Before → After:**
- Claims without proof: X → 0
- Slides over word limit: X → 0
- Vague CTAs: X → 0
- Anti-patterns detected: X → 0
- Buyer perspective gaps: X → 0

**Quality Score:**
- Message clarity: [1-10]
- Proof strength: [1-10]
- Visual quality: [1-10]
- Audience appropriateness: [1-10]
- Overall conversion potential: [1-10]

---

## When to Skip Optimization

Skip optimization if:
- User explicitly prefers to iterate manually
- Time-sensitive delivery requires immediate output
- Presentation is for brainstorming, not pitching
- User will heavily customize anyway
- Draft stage where structure more important than polish

Otherwise, **always offer optimization** as it significantly improves conversion rates.
