# Presentation Frameworks

Proven narrative structures for different B2B contexts and audiences.

## Framework Selection Matrix

| Audience | Context | Deck Type | Slide Count | Duration |
|----------|---------|-----------|-------------|----------|
| CEO/Board | Strategic decision | Executive | 8-10 | 15-20 min |
| CFO | Budget approval | Executive (ROI-focused) | 8-10 | 15-20 min |
| CIO/CTO | Technical evaluation | Operational | 12-15 | 30-40 min |
| Cross-functional | Discovery/workshop | Sales Conversation | 20-25 | 60+ min (non-linear) |

## Executive Deck (8-10 slides)

**Purpose:** Secure strategic buy-in from C-level for high-stakes decisions
**Cognitive density:** 30-50 words/slide (except opening/closing)
**Proof depth:** High-level metrics, 1-2 case studies max

### Standard Structure

**Slide 1: Title + Positioning**
- Company/offering name
- Tagline/positioning statement
- Date and presenter info
- Visual: Brand-aligned hero image or logo

**Slide 2: Problem Diagnostic**
- The strategic challenge they face
- Cost of inaction (quantified)
- Why now? (urgency/market shift)
- Visual: Data visualization showing problem magnitude

**Slide 3: Market Context**
- Industry trends validating the problem
- Competitive landscape shift
- Window of opportunity
- Visual: Market diagram or trend chart

**Slide 4: Solution Overview**
- Your unique approach (not features, but philosophy/method)
- 2-3 core differentiators
- Why this solves the diagnosed problem
- Visual: Simple conceptual diagram

**Slide 5: How It Works**
- High-level process (3-5 steps max)
- Key enablers or components
- What makes it different from alternatives
- Visual: Process flow or journey map

**Slide 6: Proof**
- 1-2 case studies with quantified results
- Pattern: "Company X achieved Y% improvement in Z metric within N months"
- Logos of notable clients (if applicable)
- Visual: Results comparison or testimonial

**Slide 7: ROI & Business Case**
- Investment range (if appropriate at this stage)
- Payback period indication
- Value creation beyond cost savings
- Visual: ROI calculation or value breakdown

**Slide 8: The Journey**
- 3-4 phase roadmap
- Timeline indication
- De-risking elements
- Visual: Timeline with milestones

**Slide 9: Why Us**
- Team credentials
- Track record
- Partnerships/certifications
- Visual: Team photos or partner logos

**Slide 10: Next Steps (CTA)**
- Concrete action with timeline
- What happens in next 7/14/30 days
- Investment/commitment level
- Visual: Next steps timeline

### CFO-Specific Variant

Emphasize slides 2, 7, 8:
- **Slide 2:** Quantify problem in P&L impact terms
- **Slide 7:** Expand to full business case with sensitivity analysis
- **Slide 8:** Add risk mitigation and governance framework

### CEO-Specific Variant

Emphasize slides 3, 4, 6:
- **Slide 3:** Market positioning and competitive moat
- **Slide 4:** Strategic differentiation and vision alignment
- **Slide 6:** Transformational outcomes, not just operational gains

## Operational Deck (12-15 slides)

**Purpose:** Convince CIO/CTO/operations leaders with implementation credibility
**Cognitive density:** 50-80 words/slide
**Proof depth:** Technical detail, architecture, multiple case studies

### Standard Structure

**Slides 1-3:** Same as Executive (Title, Problem, Context)

**Slide 4: Solution Architecture**
- System diagram or tech stack
- Integration points with existing infrastructure
- Scalability considerations
- Visual: Technical architecture diagram

**Slide 5: Implementation Methodology**
- Detailed phase breakdown
- Roles and responsibilities
- Success criteria per phase
- Visual: Gantt chart or phase detail

**Slide 6-7: Case Studies (2 slides)**
- Deep dive on 2-3 relevant implementations
- Before/after metrics
- Technical challenges overcome
- Visual: Results dashboard or comparison

**Slide 8: Technology & Tools**
- Core technologies used
- Vendor partnerships
- Compliance/security posture
- Visual: Tech stack diagram

**Slide 9: Team & Expertise**
- Technical credentials
- Certifications
- Past projects
- Visual: Team structure or credentials

**Slide 10: Governance & Risk Management**
- Change management approach
- Risk mitigation strategies
- Quality assurance process
- Visual: Governance framework

**Slide 11: ROI Model**
- Detailed cost breakdown
- Quantified benefits by category
- Payback calculation
- Visual: Financial model or ROI curve

**Slide 12: Integration Plan**
- Systems affected
- Data migration approach
- Training plan
- Visual: Integration roadmap

**Slide 13-14: FAQ / Objections Handled**
- Anticipate top 3-5 concerns
- Direct answers with proof
- Visual: Q&A format or myth-busting

**Slide 15: Next Steps**
- Detailed next steps
- Timeline and milestones
- Required commitments
- Visual: Action plan timeline

## Sales Conversation Deck (20-25 slides)

**Purpose:** Flexible, modular deck for iterative discovery and objection handling
**Cognitive density:** Varies by slide type
**Proof depth:** Comprehensive library of case studies and proof points

### Modular Structure

**Core Narrative (Slides 1-10):** Same as Executive Deck

**Addendum Sections (Slides 11-25):** Organized by topic, used selectively

**Section A: Deep Dive on Problem**
- A1: Industry pain points by vertical
- A2: Quantified cost of inaction
- A3: Failed approaches and why

**Section B: Solution Deep Dive**
- B1: Feature-by-feature breakdown
- B2: Technical architecture
- B3: Integration scenarios

**Section C: Proof Library**
- C1: Case study - Industry X
- C2: Case study - Industry Y
- C3: Case study - Company size Z
- C4: Testimonials compilation

**Section D: ROI & Business Case**
- D1: Cost-benefit calculator
- D2: Payback scenarios
- D3: Total cost of ownership

**Section E: Implementation**
- E1: Detailed roadmap
- E2: Team structure
- E3: Change management
- E4: Training program

**Section F: Competitive Positioning**
- F1: Why not Big4?
- F2: Why not in-house?
- F3: Why not other vendors?

**Section G: Risk & Governance**
- G1: Risk mitigation
- G2: Security & compliance
- G3: Success metrics

### Navigation Strategy

Use core narrative (1-10) for first presentation. Based on questions/objections, navigate to relevant addendum sections. Mark sections as:
- **[ADDENDUM A1]** at top of slide for easy reference
- Build table of contents slide (Slide 11) that lists all addendum sections

## Deck Format Variants

Same content, different formats for different contexts.

### Live Presentation Deck

**Purpose:** Guide a live conversation
**Characteristics:**
- Minimal text (you explain verbally)
- Visual-heavy
- 10-15 slides
- Detailed speaker notes

**Rules:**
- Max 30-50 words/slide (you say the rest)
- Each slide = 1 key message
- Visual > Text
- Integrated questions ("Does this resonate with your experience?")

### Send-Ahead Deck

**Purpose:** Get the meeting (the prospect reads it on their own)
**Characteristics:**
- More text (must work standalone)
- 8-12 slides
- Self-explanatory
- Teaser, not the full story

**Rules:**
- Each slide must be understandable without explanation
- Include "hook" to generate curiosity
- Clear CTA: "Let's discuss in a 30-minute call"
- Do NOT reveal everything -- leave value for the meeting

### Leave-Behind Deck

**Purpose:** Enable the champion to sell internally
**Characteristics:**
- Complete (must answer questions that came up in the meeting)
- 10-12 slides
- Includes FAQ/Objections handling
- Personalized post-meeting

**Rules:**
- Incorporate answers to specific questions that came up
- Include reinforced "Why Now" section
- Add competitive positioning if discussed
- Summary slide with 3 key takeaways

### Format Comparison

| Aspect | Live | Send-Ahead | Leave-Behind |
|--------|------|------------|--------------|
| Words/slide | 30-50 words | 60-80 words | 80-100 words |
| Slide count | 10-15 | 8-12 | 10-12 |
| Standalone | No | Yes | Yes |
| Visual focus | High | Medium | Medium |
| CTA | Soft (next conversation) | Get the meeting | Enable decision |
| Format | Keynote/PPT | PDF | PDF |

---

## Executive Summary Deck (5-7 slides)

For C-Suite with limited time. BLUF (Bottom Line Up Front) structure.

### McKinsey Principle

90% of top management decisions come from concise executive summaries. Bring the conclusion to the TOP, then support it.

### SCQA Structure

| # | Section | Content | Time |
|---|---------|---------|------|
| 1 | BLUF | Bottom Line Up Front: what you propose, recommendation, why it matters | 30 sec |
| 2 | Situation | Brief context, current state | 1 min |
| 3 | Complication | The problem that requires action NOW | 1 min |
| 4 | Resolution | Your recommendation with key benefits | 2 min |
| 5 | Evidence | "Money slide" with irrefutable proof point | 1 min |
| 6 | Next Steps | Specific ask with timeline | 30 sec |

### Executive Summary Slide Template

**Slide 1 - BLUF:**
```
# [Recommendation in 10 words]

Investment: $[X]K | Payback: [N] months | ROI: [X]x

**Why now:** [One sentence on urgency]
```

**Slide 2 - Situation:**
```
# [Current situation title]

[2-3 bullets describing the current state]
- [Fact 1 with number]
- [Fact 2 with number]
- [Market context]
```

**Slide 3 - Complication:**
```
# [The problem as a question or statement]

[Quantification of the problem]
- Current cost: $[X]/year
- Risk: [consequence if no action is taken]
- Window: [urgency factor]
```

**Slide 4 - Resolution:**
```
# [The solution in one sentence]

**Approach:**
1. [Step 1] → [Outcome 1]
2. [Step 2] → [Outcome 2]
3. [Step 3] → [Outcome 3]

**Expected result:** [Key metric]
```

**Slide 5 - Evidence:**
```
# [Similar company] achieved [result]

[Compressed case study]
- Challenge: [similar problem]
- Solution: [approach used]
- Result: [3 metrics]

[Logo + Brief quote]
```

**Slide 6 - Next Steps:**
```
# Next steps

**This week:** [Immediate action]
**Next 2 weeks:** [Milestone 1]
**By [date]:** [Decision point]

Investment ask: $[X]K | Decision needed by: [date]
```

---

## 12-Slide Optimal Structure

Validated structure for standard sales decks. Each slide has a target psychological response.

| # | Type | Content | Target response |
|---|------|---------|-----------------|
| 1 | Cover | Name + one-liner positioning | "Looks interesting..." |
| 2 | Big Shift | Change in the market/world | "This is important..." |
| 3 | Problem | Specific quantified pain point | "I have this problem..." |
| 4 | Status Quo | The current frustrating situation | "That's me..." |
| 5 | Solution | High-level description (NOT features) | "I get what they do..." |
| 6 | How It Works | Top 3 capabilities/differentiators | "I understand how it works" |
| 7 | Demo/Visual | Screenshot or walkthrough | "I can see myself using it" |
| 8 | Benefits | Max 3-4 outcomes | "I want those results" |
| 9 | Social Proof | Case study + logos | "Others like me have succeeded" |
| 10 | Pricing | Plans and who they're for | "Plan X is right for us" |
| 11 | FAQs/Objections | Top 3 concerns | "They anticipated my doubts" |
| 12 | Next Steps | Specific CTA + timeline | "I know exactly what to do" |

### Timing Guidelines

- **2 min/slide** as a general rule
- **Max 9 minutes** of continuous monologue (then break/question)
- **Slides 1-4:** 6-8 minutes (setup)
- **Slides 5-8:** 10-12 minutes (solution)
- **Slides 9-12:** 6-8 minutes (proof + close)
- **Total:** 22-28 minutes + Q&A

---

## Stakeholder Behavioral Types

Beyond CFO/CIO/CEO (roles), consider behavioral types (how they decide).

### Mobilizers (Prioritize targeting these)

Stakeholders who actually make deals happen.

| Type | Characteristic | How to recognize them | How to engage them |
|------|----------------|----------------------|-------------------|
| **Go-Getter** | Action-oriented, continuous improvement | "What can we do to improve?" | Give them concrete actions to take |
| **Teacher** | Share insights, educate colleagues | Ask questions to understand deeply | Provide content to share internally |
| **Skeptic** | Challenge ideas, stress-test | "But what happens if...?" | Anticipate objections, provide solid data |

### Talkers (Manage, don't over-invest)

They seem influential but don't move deals.

| Type | Characteristic | How to recognize them | How to manage them |
|------|----------------|----------------------|-------------------|
| **Guide** | Friendly, accessible | Give you lots of info, little commitment | Use for intel, don't expect action |
| **Friend** | Want to help you | "I'll put you in touch with..." | Thank them, but find the real decision-maker |
| **Climber** | Career-focused | Talk about how it will make them look | Useful if aligned with their interest |
| **Blocker** | Resist change | "It's not the right time", "We've tried" | Identify and neutralize/bypass |

### Practical Application

**Discovery Phase:** Identify who is a Mobilizer vs Talker
**Pitch Phase:** Customize the message for Mobilizers present
**Follow-up Phase:** Activate Mobilizers as internal champions

**Gartner Data:** Groups with consensus are 2.5x more likely to produce high-quality deals. Conflict in the buying committee peaks at 37% of the process (solution identification phase).

---

## Slide Archetypes

### Opening Slide
- **Purpose:** Set tone and positioning
- **Elements:** Logo, tagline, visual hero
- **Words:** <20

### Problem Diagnostic Slide
- **Purpose:** Create urgency and align on challenge
- **Elements:** Problem statement, quantified cost, "why now"
- **Words:** 40-60
- **Visual:** Data chart or comparison

### Solution Overview Slide
- **Purpose:** Present unique approach
- **Elements:** 2-3 differentiators, philosophy/method
- **Words:** 50-70
- **Visual:** Conceptual diagram

### Process/How It Works Slide
- **Purpose:** Build confidence in execution
- **Elements:** 3-5 step process, key components
- **Words:** 50-80
- **Visual:** Flow diagram or journey map

### Proof/Case Study Slide
- **Purpose:** Validate with evidence
- **Elements:** Company name (or anonymized), metrics, timeframe
- **Words:** 60-80
- **Visual:** Results comparison or testimonial quote

### ROI/Business Case Slide
- **Purpose:** Justify investment
- **Elements:** Investment range, payback, value breakdown
- **Words:** 40-60
- **Visual:** Financial model or value pyramid

### Next Steps/CTA Slide
- **Purpose:** Drive to action
- **Elements:** Concrete next action, timeline, commitment level
- **Words:** 30-50
- **Visual:** Timeline or checklist

## Narrative Flow Principles

**Problem-Solution-Proof-Path**
1. Establish the problem with urgency
2. Present differentiated solution
3. Validate with proof
4. Show clear path forward

**Tension-Release Pattern**
- Build tension with problem/cost of inaction (Slides 2-3)
- Release with solution/approach (Slides 4-5)
- Reinforce with proof (Slide 6)
- De-risk with process (Slides 7-8)
- Call to action (Slide 10)

**Specificity Gradient**
- Start strategic/high-level
- Add detail progressively
- End with concrete next steps

**One Message Per Slide**
- Each slide should answer one question
- Supporting details reinforce that message
- Visual amplifies the core message

## Adaptation Checklist

Before using a framework, validate:
- [ ] Audience seniority matches cognitive density
- [ ] Proof depth matches decision stage (awareness vs evaluation vs decision)
- [ ] Time allocation matches slide count (2 min/slide guideline)
- [ ] Industry context reflected in examples
- [ ] Company size affects case study selection
- [ ] Geographic/cultural factors considered
