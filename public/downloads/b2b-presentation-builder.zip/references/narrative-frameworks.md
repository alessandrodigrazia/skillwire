# Narrative Frameworks

Evidence-based narrative frameworks for high-conversion B2B sales decks. These frameworks replace the generic "3-act" structure with operational sequences validated by real-world cases.

## Framework Selection

| Framework | When to use | Main strength |
|-----------|-------------|---------------|
| Raskin 5-Step | Markets in disruption, new category | Creates urgency through "Big Shift" |
| Dunford 8-Step | Markets with high "no decision" (40-60%) | Manages fear of making mistakes |
| Challenger 6-Step | Educational pitch, reframing assumptions | Forces a change of perspective |

---

## Raskin 5-Step Framework (The Greatest Sales Deck)

Validated by the Zuora deck, defined by Andy Raskin as "the greatest sales deck ever seen". Structure used by Zuora, Salesforce, Drift.

### Core Principle

**You NEVER start with the product.** You start with a change in the world that creates urgency. The product is the tool that enables survival/victory in the new world.

### The 5 Steps

#### Step 1: Name a Big, Relevant Shift in the World

**Purpose:** Create context and urgency without talking about yourself.

**Pattern:** "[Statement about how the world has changed]"

**Zuora Example:**
> "We live in a Subscription Economy" #shifthappens

**Salesforce Example:**
> "We're in the Fourth Wave of Computing" (Mainframes → Client-Server → Web → Cloud)

**Drift Example:**
> [Image of person sleeping with phone] "She practically sleeps with her phone"

**Rules:**
- No mention of the product
- No company history
- No "we are market leaders"
- Only a statement about the WORLD, not about you

#### Step 2: Show There Will Be Winners and Losers

**Purpose:** Create stakes through loss aversion (2-3x more powerful than gain seeking).

**Pattern:** "Those who embrace [shift] thrive. Those who ignore it disappear."

**Zuora Example:**
> "In the last 15 years, 52% of Fortune 500 companies have disappeared"
> [Visual: photo of closed Blockbuster]

**Drift Example:**
> "Email isn't real-time. Email gets abused. Email is not smart."
> [Three consecutive slides dismantling the old paradigm]

**Rules:**
- Show companies that failed by ignoring the shift
- Show companies that won by embracing it
- Implicit question: "Will you be a winner or a loser?"

#### Step 3: Tease the Promised Land

**Purpose:** Define the desirable destination (NOT your product).

**Pattern:** "To win in the [new world], you need to become [type of company with characteristics X, Y, Z]"

**Zuora Example:**
> "Winners will be: RELATIONSHIP business (customer, not product centric), OUTCOMES business (usage drives value), RECURRING revenue business"

**Critical:** The Promised Land is NOT "having your product". It is what the prospect's LIFE will look like thanks to your product. This allows the internal champion to pitch with a vision, not a feature list.

#### Step 4: Introduce Features as "Magic Gifts"

**Purpose:** Position features as tools to reach the Promised Land.

**Pattern:** "To become [type of winning company], you need [capability 1], [capability 2], [capability 3]"

**Analogy:** You are Obi-Wan giving Luke the lightsaber. Luke is the hero, not you. Features are "magic gifts" for the hero's journey.

**Zuora Example:**
> For each capability, they show an "Old World" vs "New World" comparison
> - Old: Product-centric → New: Customer-centric
> - Old: One-time sale → New: Ongoing relationship

**Rules:**
- Max 3-5 capabilities
- Each capability linked to an aspect of the Promised Land
- Visual contrasting old vs new paradigm

#### Step 5: Present Evidence You Can Make the Story Come True

**Purpose:** Prove that you can actually take them to the Promised Land.

**Pattern:** Testimonial that speaks about the TRANSFORMATION, not the features.

**Zuora Example (NCR quote):**
> "Our transformation wouldn't have happened without Zuora"

**Rules:**
- The proof speaks about the Promised Land achieved
- Not "the product works well"
- But "we became the company we wanted to be"

### Raskin Slide Structure

| # | Type | Content |
|---|------|---------|
| 1-3 | Big Shift | The world has changed. Here's how. |
| 4-6 | Winners/Losers | Those who embraced the change thrive. Those who didn't, disappear. |
| 7-8 | Promised Land | To win, you need to become this type of company. |
| 9-12 | Magic Gifts | Here are the capabilities you need to get there. |
| 13-15 | Evidence | Here's who already got there with us. |

---

## April Dunford 8-Step Framework

Optimized for markets where **40-60% of deals end in "no decision"**. Buyers fear making mistakes more than losing the opportunity.

### Core Principle

**Sell "Why Change" BEFORE "Why Us".** The main competitor is not another company -- it is the status quo.

### The 8 Steps

#### Setup Phase (Step 1-3)

**Step 1: Insight**
What do they need to know to understand your differentiated value?

Pattern: "Many [audience] believe [common assumption]. In reality, [counterintuitive insight]."

**Step 2: Alternative Approaches**
Pros/cons of each option, including "do nothing".

Pattern: "You can do X, but [limitation]. You can do Y, but [limitation]. You can do nothing, but [cost of inaction]."

**Step 3: The Perfect World**
Define the ideal BEFORE showing the product.

Pattern: "The ideal approach should [criterion 1], [criterion 2], [criterion 3]."

#### Follow-through Phase (Step 4-8)

**Step 4: Introduce Your Company/Solution**
Only NOW do you talk about yourself.

**Step 5: Differentiated Value**
What can you offer that ONLY you can offer?

**Step 6: Enabling Features**
The features that make the differentiated value possible.

**Step 7: Proof**
Evidence that the differentiated value is real.

**Step 8: The Ask**
Clear and specific CTA.

### Dunford Slide Structure

| # | Step | Focus |
|---|------|-------|
| 1 | Title | Positioning statement |
| 2-3 | Insight | The market believes X. The reality is Y. |
| 4-5 | Alternatives | Available options and their limitations |
| 6 | Perfect World | Criteria for the ideal approach |
| 7-8 | Solution | How you meet those criteria |
| 9 | Differentiated Value | What only you can offer |
| 10 | Features | How you make it possible |
| 11-12 | Proof | Case studies focused on the differentiated value |
| 13 | Ask | Specific next step |

---

## Challenger 6-Step Choreography

For educational pitches where you need to challenge the prospect's assumptions. Based on CEB research: Challengers represent >50% of top performers.

### The 6 Steps

| Step | Name | Purpose |
|------|------|---------|
| 1 | Warmer | Demonstrate understanding of their world |
| 2 | Reframe | Challenge an assumption they have about their business |
| 3 | Rational Drowning | Quantify the problem overwhelmingly |
| 4 | Emotional Impact | Connect the numbers to personal consequences |
| 5 | New Way | Present an alternative approach |
| 6 | Your Solution | Only now, how YOU enable that new approach |

### Practical Application

**Step 2 (Reframe) - Example:**
> "Many CFOs measure AI success by looking at completed pilots. But 75% of pilots that 'work' never scale to production. The real KPI is pilot-to-production rate."

**Step 3 (Rational Drowning) - Example:**
> "With a pilot-to-production rate of 25%, you're investing $400K/year in AI to get $100K of value. The remaining $300K is pure waste."

**Step 4 (Emotional Impact) - Example:**
> "Every failed pilot means a team that loses confidence in AI, a budget that won't be renewed, and 18 months of competitive advantage handed to competitors."

---

## Quantified Rules (Evidence-Based)

Empirical data from Gong Labs (67,149+ presentations analyzed).

### The 9-Minute Rule

**Data:** Every closed deal involved presentations of 9 minutes or less. Lost deals had average presentations of 11.4 minutes.

**Application:**
- Introduce a "brain-perking change of pace" after 9 minutes
- Don't speak for more than 9 consecutive minutes without interaction
- If the deck requires more time, insert natural breaks (questions, demo, discussion)

### The 2-Minute Company Intro Rule

**Data:** Presentations with >2 minutes of company intro have significantly lower close rates.

**Application:**
- Company intro of 2 minutes or less (1-2 slides max)
- Never start with company history, founders, mission statement
- Credentials come AFTER value, not before

### Social Proof Timing

**Data:** Social proof introduced too early reduces close rate by 47%.

**Application:**
- Never open with client logos or testimonials
- Proof comes AFTER establishing the problem and the solution
- Sequence: Problem → Solution → THEN Proof
- Proof speaks about the Promised Land achieved, not features

### "No Decision" as Competitor #1

**Data:** 40-60% of B2B processes end in "no decision" (status quo wins).

**Application:**
- Sell "Why Change" before "Why Us"
- Quantify the cost of inaction
- Loss aversion: 2-3x more powerful than gain seeking
- Frame: "Every [period] without [solution] costs [amount] in [consequence]"

---

## Opening Anti-Pattern

Phrases to NEVER use in the first slides:

| Do not use | Alternative |
|------------|-------------|
| "Thank you for inviting me" | [Go straight to the Big Shift] |
| "I'll talk to you about..." | [Show the change in the world] |
| "Before we begin, a brief intro about us" | [Your intro comes after the value] |
| "We are market leaders in..." | [Prove it with results, don't declare it] |
| "Founded in [year]..." | [Nobody cares about your history] |

### Pattern Interrupt for Opening

If you need to capture attention in 7 seconds (Harvard data):

**Action Title (McKinsey style):**
- Don't: "Q3 Market Analysis"
- Do: "Three untapped markets could drive 40% of revenue growth"

**Counterintuitive Statistic:**
- "52% of the Fortune 500 from 2000 no longer exist."

**Provocative Question:**
- "What would happen if your competitors had an 18-month advantage you can no longer recover?"

---

## Framework Comparison Matrix

| Criterion | Raskin 5-Step | Dunford 8-Step | Challenger 6-Step |
|-----------|---------------|----------------|-------------------|
| Ideal market | Disruption, new category | High "no decision", fear | Educational, reframe needed |
| Opening | Big Shift in the world | Counterintuitive insight | Warmer + understanding |
| Competitor handling | Winners vs Losers | Alternative approaches | N/A (focus on status quo) |
| Product moment | Step 4 (Magic Gifts) | Step 4 (after Perfect World) | Step 6 (end) |
| Emotional strength | Loss aversion (disappearing) | Fear of making mistakes | Rational + Emotional drowning |
| Proof focus | Transformation achieved | Differentiated value | Credibility of the reframe |

---

## Pre-Pitch Checklist

Before presenting, verify:

- [ ] Do I open with a Big Shift/Insight, NOT with who we are?
- [ ] Is the company intro 2 minutes or less?
- [ ] Have I quantified the cost of inaction?
- [ ] Does social proof come AFTER problem+solution?
- [ ] Is every monologue 9 minutes or less?
- [ ] Do I have "brain breaks" (questions, demo) if I exceed 9 min?
- [ ] Is the Promised Land the prospect's LIFE, not my product?
- [ ] Are features "magic gifts" for the journey, not the protagonist?
- [ ] Is the CTA specific and time-bound?
- [ ] Can the prospect re-pitch internally using my narrative?
