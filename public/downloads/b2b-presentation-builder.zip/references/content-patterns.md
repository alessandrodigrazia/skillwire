# Content Patterns

Proven messaging patterns and content templates for high-converting B2B presentations.

## Template Pattern

Use templates to maintain consistency while allowing customization. Templates define placeholders for context-specific content.

### Problem Statement Template

```
[Target audience] struggle with [specific challenge] because [root cause].

This costs them [quantified impact] in [timeframe], leaving [opportunity cost] on the table.

The window to act is [urgency factor].
```

**Example:**
> Mid-market CFOs struggle with GenAI ROI measurement because existing finance systems lack integration with AI tools.
>
> This costs them 200+ hours/year in manual tracking, leaving strategic planning time on the table.
>
> The window to act is narrowing as early adopters build 12-18 month leads.

### Solution Positioning Template

```
Unlike [alternative approach], we [unique method] by [key differentiator].

This means [audience] can [primary benefit] while avoiding [common pitfall].
```

**Example:**
> Unlike tech-first AI consultancies, we integrate technology with organizational readiness by applying our 30-70 rule (30% tech, 70% people+process).
>
> This means CIOs can achieve production-scale impact while avoiding the "pilot purgatory" trap.

### Case Study Template

```
[Company type/size] in [industry] faced [specific problem].

Using [your approach], they achieved:
- [Metric 1]: [X%] improvement in [Y timeframe]
- [Metric 2]: [reduction/increase] from [before] to [after]
- [Metric 3]: [strategic outcome]

Key success factor: [one critical element]
```

**Example:**
> A €500M manufacturing company faced 60% failure rate in scaling AI pilots.
>
> Using our AI Readiness Framework, they achieved:
> - Pilot-to-production rate: 75% (from 40%) in 6 months
> - Time-to-value: 40% reduction from 9 to 5.4 months
> - Employee AI adoption: 80% vs 35% industry benchmark
>
> Key success factor: Executive sponsorship combined with bottom-up change agents program.

### ROI Framing Template

```
Investment: [range or specific]
Typical payback: [timeframe]

Value drivers:
1. [Direct cost savings]: [amount/percentage]
2. [Efficiency gain]: [time/resource saved]
3. [Revenue opportunity]: [growth potential]
4. [Strategic value]: [competitive advantage]
```

**Example:**
> Investment: €50-80K for Phase 1 (AI Strategy Plan)
> Typical payback: 4-6 months
>
> Value drivers:
> 1. Failed pilot cost avoidance: €200-400K/year
> 2. Time to production: 40% faster (5.4 vs 9 months)
> 3. Revenue from new AI capabilities: 5-15% growth in target segments
> 4. Competitive moat: 12-18 month lead vs followers

---

## Slide Copy Templates (Operational)

Copy-paste ready templates with specific placeholders.

### Problem Slide Copy

**Template 1 - The Uncomfortable Truth:**
```
[X%] of [target audience] are [doing something inefficiently], 
costing them [specific consequence].

Meanwhile, [competitor type] are [doing the opposite] and 
[achieving result].
```

**Real Example (ChartMogul):**
> "Accurately calculating SaaS metrics is hard. Harnessing subscription data to inform decisions that lead to faster growth is even harder."

**Real Example (ProdPad):**
> "Spreadsheets are the place where good ideas go to die."

**Template 2 - Cost of Inaction:**
```
Every [time period] without [solution] costs you:
• €[X] in [direct cost]
• [Y] hours in [wasted effort]
• [Z]% [missed opportunity]
```

### Solution Slide Copy

**Template - The Bridge Statement:**
```
That's why we built [Product]. 

[Single biggest promise in one sentence].

This means [audience] can [primary benefit] 
while avoiding [common pitfall they fear].
```

**Transition from problem:**
- "There's a better way..."
- "What if you could [solve problem] while also [getting benefit]?"
- "Imagine if [pain] simply... disappeared."

**Gong Example:**
> "Get powerful visibility into your customer interactions with revenue intelligence."

### Why Now Slide Copy

**Template - Market Shift:**
```
In [year], [old reality].
Today, [new reality].
By [future year], [projection].

The window to act: [specific urgency factor].
```

**Template - Cost of Waiting:**
```
Every [time period] you wait:
• Competitors gain [specific advantage]
• You lose €[X] in [quantified cost]
• The gap becomes [harder/impossible] to close
```

**Validity Test:** If this slide would have been relevant 5 years ago, rewrite it. It must create urgency for TODAY.

### Competitive Positioning Slide Copy

**Template - Category Creation:**
```
There are [N] ways to approach [problem]:

1. [Approach A] - Good for [use case], but [limitation]
2. [Approach B] - Good for [use case], but [limitation]  
3. [Our approach] - Combines [benefit A] + [benefit B] for [specific audience]
```

**Template - Positioning Without Bashing:**
```
While [competitor/alternative] focuses on [X], 
we specialize in [Y] for [specific audience].

This means [unique outcome they can't get elsewhere].
```

**Anti-pattern:** Never say "we are the same but better". Create a category that you define.

### Case Study Slide Copy

**Mandatory Structure:**
```
# How [Company] Achieved [Specific Result]

**Challenge:** [One sentence on the problem]
**Solution:** [One sentence on the approach]
**Result:** [3 metrics in callout]

"[Customer quote - max 2 lines]"
— [Name], [Role], [Company]
```

**Formula Three-Part Result:**
```
[Metric 1] + [Metric 2] + [Metric 3] 
achieved in [timeframe]
```

**Rules:**
- The customer is the hero, not you
- Case study similar to the prospect (industry, size, challenge)
- Quote talks about TRANSFORMATION, not features

### Pricing Slide Copy

**Template Enterprise - Value-Based:**
```
# Investment

Starting from €[X]/[period] per [unit]

Includes:
✓ [Key deliverable 1]
✓ [Key deliverable 2]
✓ [Key deliverable 3]

Typical ROI: [X]x within [timeframe]
```

**Template Enterprise - Custom:**
```
# Pricing Built Around Your Needs

Enterprise includes:
• Dedicated onboarding
• SLA guarantees
• Custom integrations
• Named account management

Let's discuss your specific requirements.
```

**Rule:** Never show pricing before establishing value. Pricing comes AFTER ROI and case study.

### CTA/Next Steps Slide Copy

**Weak copy to avoid:**
- ❌ "Let's connect"
- ❌ "Learn more"
- ❌ "Thank you" (NEVER end like this)
- ❌ "Any questions?"

**Strong copy:**
```
# Next Steps

**This week:** [Specific action]
**Next 2 weeks:** [Milestone]
**By [date]:** [Decision point]

[Button/Link] Schedule your [specific meeting type]
```

**CTA Formula:** [Action verb] + [Timeframe] + [Benefit]

**Examples:**
- "Schedule a 30-minute call this week to see your custom ROI projection"
- "Book a technical deep-dive with our team by Friday"
- "Join 500+ businesses that have cut costs by 30%. Let's get you started."

---

## Action Titles (McKinsey Pattern)

Transform descriptive titles into titles that communicate the insight.

### Principle

The title of every slide should communicate the SO WHAT, not the WHAT.

### Examples

| ❌ Descriptive Title | ✅ Action Title |
|----------------------|-----------------|
| "Market Analysis" | "Three untapped markets could drive 40% of growth" |
| "Product Overview" | "A platform to eliminate 75% of failed pilots" |
| "Team" | "30+ years of combined experience in AI transformation" |
| "Pricing" | "Positive ROI within 6 months, guaranteed" |
| "Acme Corp Case Study" | "Acme reduced costs by 40% in 90 days" |
| "The Problem" | "€2M/year lost in invisible inefficiencies" |
| "The Solution" | "Complete visibility on every euro spent on AI" |

### Formula

```
[Quantification] + [Outcome] + [Timeframe/Condition]
```

### Application

- Write slide content first
- Ask: "What is the ONE thing the prospect must remember?"
- Transform that thing into the title
- The title must work even alone (without reading the rest)

Provide specific, concrete examples that the audience can relate to. Use industry-specific terminology and scenarios.

### Vertical-Specific Examples

**Manufacturing:**
- "Predictive maintenance AI reducing downtime by 30%"
- "Supply chain optimization saving €2M annually"
- "Quality control AI catching defects 40% earlier"

**Financial Services:**
- "Fraud detection improving precision by 25% while reducing false positives"
- "Customer churn prediction enabling proactive retention saving €5M"
- "Loan underwriting acceleration from 5 days to 2 hours"

**Retail:**
- "Demand forecasting reducing stockouts by 35%"
- "Personalization engine driving 12% basket size increase"
- "Price optimization improving margins by 2.3 percentage points"

**Professional Services:**
- "Document analysis reducing legal review time by 60%"
- "Proposal generation cutting response time from 5 days to 8 hours"
- "Knowledge management improving consultant utilization by 15%"

### Size-Specific Examples

**Enterprise (>1000 employees):**
- Focus on scale challenges, integration complexity, governance
- ROI in millions
- Multi-year transformation journeys

**Mid-Market (100-1000 employees):**
- Focus on resource constraints, agility advantages, quick wins
- ROI in hundreds of thousands
- 6-12 month implementation cycles

**SMB (<100 employees):**
- Focus on competitive disadvantage, access to enterprise capabilities
- ROI in tens of thousands
- 3-6 month fast tracks

## Conditional Workflow Pattern

Adapt content based on context discovered in Phase 1. Use conditional logic to select appropriate messaging.

### IF audience = CFO THEN emphasize:
- P&L impact and financial metrics
- Payback period and NPV
- Budget allocation and cost control
- Risk mitigation and governance
- Benchmarking vs industry standards

### IF audience = CIO/CTO THEN emphasize:
- Technical architecture and integration
- Scalability and security
- Team skills and training needs
- Vendor management
- Technical debt and modernization

### IF audience = CEO THEN emphasize:
- Strategic positioning and competitive advantage
- Market trends and disruption threats
- Organizational transformation
- Stakeholder impact (customers, employees, investors)
- Vision and long-term trajectory

### IF context = first_meeting THEN:
- Keep it high-level and strategic
- Focus on problem-solution fit
- Minimal technical detail
- Broad proof points
- Soft CTA (next conversation, not commitment)

### IF context = evaluation_stage THEN:
- Add technical depth
- Provide detailed case studies
- Include implementation roadmap
- Show team credentials
- Specific pricing and timelines

### IF context = final_decision THEN:
- Address remaining objections head-on
- Provide detailed business case
- Include risk mitigation plan
- Show governance framework
- Clear CTA with urgency

---

## C-Level Copy Patterns (Operational Phrases)

Specific language that resonates with different executives.

### CFO Language (ROI, Risk, Efficiency)

**Phrases that work:**
- "I expect the investment to build €[X]M in additional revenues, a [Y]x ROI, within [timeframe]."
- "[Solution] more than pays for itself within [timeframe]."
- "By improving [process], we expect to convert [X]% more [metric], generating €[Y] additional revenue."
- "The investment de-risks €[X] in current exposure to [risk factor]."

**Questions the CFO asks (answer proactively):**
- How much are you asking exactly?
- When do I recover the investment?
- What is the expected ROI with conservative assumptions?
- How do we mitigate risk if it doesn't work?
- What hidden costs are there?

**CFO Response Framework:**
```
Investment: €[X]
Payback: [N] months
Conservative ROI: [Y]x
Risk mitigation: [Specific mechanism]
Hidden costs: [None / These are included]
```

### CIO/CTO Language (Integration, Security, Scalability)

**Phrases that work:**
- "The solution integrates with your existing [system] through [standard protocol/API]."
- "Our old technology can crash at any time, putting €[X] in revenues at risk."
- "Implementation follows [standard methodology] with [governance framework]."
- "Security posture: [certification], [compliance], [audit trail]."

**Work-Bench Rule:** In a 30-minute meeting with a CIO, you have 15 effective minutes:
- 5 min: delays and setup
- 5 min: intro and rapport
- 15 min: real content
- 5 min: next steps

Don't get trapped in slides. Prepare answers for:
- "How does it work with [our specific system]?"
- "Who owns the data?"
- "What happens if [failure scenario]?"

### CEO Language (Vision, Growth, Competitive Advantage)

**Phrases that work:**
- "This is the story we're going to tell—everywhere—for the next 3 to 5 years."
- "It removes [competitor/threat], making it easier to [strategic outcome]."
- "It will help accelerate revenue growth by [mechanism]."
- "This positions us as [category leader/first mover] before [competitor] can react."

**CEO focus areas:**
- Market positioning and competitive moat
- Transformational outcomes (not incremental)
- Alignment with declared strategy
- Impact on stakeholders (board, investors, customers)

**CEO Pitch Pattern:**
```
Strategic imperative: [In one sentence]
Competitive impact: [How it changes the game]
Timeline to advantage: [When we see results]
Board story: [How we tell this to investors]
```

### Buyer Committee Dynamics

**Gartner Data:** Buying committee = 6-14+ stakeholders. 74% have "unhealthy conflict".

**Recommended sequence for multi-stakeholder:**
1. **Champion** (first contact): Educational content, build vision
2. **Economic buyer** (CFO): Business case, ROI
3. **Technical buyer** (CIO): Feasibility, integration
4. **User buyer**: Usability, adoption
5. **Executive sponsor** (CEO): Strategic alignment

**Content to prepare for each persona:**
| Stakeholder | Key Content | Format |
|-------------|------------------|---------|
| Champion | Vision deck + internal pitch kit | Shareable PDF |
| CFO | Business case spreadsheet | Excel with sensitivity |
| CIO | Technical architecture + security doc | Detailed PDF |
| CEO | Executive summary (5-7 slides) | Concise PDF |

---

## Strategic Framing Patterns

Reframe concepts to shift perception and increase receptiveness.

### From Problem to Opportunity
❌ "You have a problem with AI adoption"  
✅ "You have an opportunity to build 12-18 month competitive lead while others struggle"

### From Cost to Investment
❌ "This will cost €80K"  
✅ "€80K investment typically returns 4-6x in first year through avoided failed pilots and faster time-to-value"

### From Risk to De-Risked Path
❌ "AI transformation is risky"  
✅ "Our phased approach eliminates 80% of typical AI transformation risks through proven frameworks"

### From Feature to Outcome
❌ "We provide AI readiness assessment"  
✅ "You'll know exactly which AI initiatives will succeed and which will fail before spending a euro"

### From Vendor to Partner
❌ "We deliver AI consulting services"  
✅ "We become your AI transformation co-pilot, invested in your long-term success"

## Proof Social Patterns

### Authority Signals
- Industry recognition: "Recognized by [authority] for [achievement]"
- Credentials: "Our team includes former [prestigious company/role]"
- Partnerships: "Official partners with [Microsoft/AWS/Google]"
- Track record: "Successfully delivered [N] transformations in [timeframe]"

### Social Proof
- Client logos (if permission granted)
- Category references: "[N] Fortune 500 companies"
- Vertical proof: "Trusted by [N] leading [industry] organizations"
- Scale indicators: "Processed [large number] in [domain]"

### Testimonial Patterns
Format: [Role] at [Company Type] + [Specific Outcome] + [Emotional Resonance]

**Strong example:**
> "As CFO of a mid-market manufacturer, I was skeptical about AI ROI. The structured approach gave us confidence to invest €150K, and we've already seen €600K in measurable returns within 9 months. More importantly, we now have a scalable playbook."  
> — CFO, €450M Manufacturing Company

**Weak example:**
> "Great partner, highly recommend!"  
> — CIO, Tech Company

### Quantified Results Pattern
Always use: [Metric] improved by [%] from [before] to [after] in [timeframe]

**Good:** "Customer satisfaction improved by 23% from 67% to 82% in 6 months"
**Bad:** "Significantly improved customer satisfaction"

## Objection Handling Patterns

### Preemptive Objection Handling
Address common objections before they're raised, in a "Why not [alternative]?" format.

**Why not Big4 consulting?**
> Big4 excel at strategy but often lack hands-on AI implementation depth. We combine strategic vision with technical execution, ensuring your strategy actually gets implemented—not just documented in a slide deck that sits on a shelf.

**Why not build in-house?**
> In-house development works if you have 18-24 months to learn through trial and error. We compress that learning curve to 3-6 months by applying patterns we've proven across [N] implementations, letting your team focus on your unique competitive advantage.

**Why not hyperscaler professional services?**
> AWS/Azure/Google are excellent for infrastructure but naturally push their specific platforms. We're platform-agnostic and focus on organizational readiness—the 70% that determines whether technology succeeds or fails.

**Why not wait?**
> Early movers are building 12-18 month competitive leads right now. The cost of waiting isn't just delayed benefits—it's watching competitors pull ahead irreversibly. The "wait and see" companies in every disruption wave never caught up.

### Direct Objection Response Pattern

When objection is raised:

1. **Validate**: "That's a legitimate concern..."
2. **Reframe**: "What we've found is..."
3. **Prove**: "For example, [case study/data]..."
4. **Ask**: "Does that address your concern, or should we explore it further?"

## Cognitive Density Guidelines

### Executive Audience (30-50 words/slide)
- One clear message per slide
- Bullet points maximum 3
- Each bullet maximum 10 words
- Prefer visual storytelling over text

### Operational Audience (50-80 words/slide)
- Can handle more detail
- Bullet points maximum 5
- Technical terminology acceptable
- Balance text and visuals

### Sales Conversation (varies)
- Hub slides: minimal text (30 words)
- Deep-dive slides: more detail acceptable (100 words)
- Use visuals to reduce text load

## Language Precision

### Use Active Voice
❌ "The project was completed by our team"  
✅ "Our team completed the project in 6 weeks"

### Use Specific Numbers
❌ "Significant improvement"  
✅ "43% improvement from 2.3M to 1.3M"

### Use Concrete Verbs
❌ "Achieve optimization of processes"  
✅ "Reduce process time by 40%"

### Avoid Jargon (Unless Audience-Appropriate)
❌ "Leverage synergistic paradigms to optimize value streams"  
✅ "Combine AI with process redesign to cut costs by 30%"

### Use "You" Language
❌ "Companies can benefit from"  
✅ "You'll gain"

## Storytelling Arc for Presentations

### ACT 1: Setup (Slides 1-3)
- Establish status quo
- Introduce tension/problem
- Create urgency

### ACT 2: Confrontation (Slides 4-6)
- Present solution/approach
- Show how it addresses problem
- Validate with proof

### ACT 3: Resolution (Slides 7-10)
- Map clear path forward
- De-risk the journey
- Call to action

This three-act structure keeps audience engaged and builds toward decision.

## Personalization Checklist

Before finalizing content:
- [ ] Replace generic examples with industry-specific ones
- [ ] Adjust metrics to audience's scale (€M for enterprise, €K for SMB)
- [ ] Use audience's terminology (CFO: P&L impact; CTO: technical debt)
- [ ] Reference audience's known pain points from discovery
- [ ] Include case studies from similar companies
- [ ] Adjust ROI timeframe to audience's planning horizon
- [ ] Frame competitive context relevant to audience's market
