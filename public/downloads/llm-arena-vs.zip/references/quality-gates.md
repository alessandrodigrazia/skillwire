# Quality Gates (VS Code)

Checklist to verify before completing an arena session in VS Code.

## Pre-Output Checklist

### 1. Claude Analysis (in CLAUDE ANALYSIS)
- [ ] Claude wrote its OWN analysis (not a placeholder)
- [ ] The analysis is complete and structured
- [ ] "Aspects Requiring Support" is filled in with reasons

### 2. Peer Requests (in SUPPORT REQUESTS)
- [ ] Requests are SPECIFIC (not "what do you think?")
- [ ] Suggested subagent is indicated
- [ ] Sufficient context is provided

### 3. Peer Contributions (in PEER CONTRIBUTIONS)
- [ ] Marker ---END CONTRIBUTION--- present for each peer
- [ ] Contributions are relevant to the request
- [ ] No empty sections if a peer was expected

### 4. Integration (in INTEGRATED OUTPUT)
- [ ] Output is BY CLAUDE (not a copy from a peer)
- [ ] Peer contributions have been integrated
- [ ] Divergences explained in "Notes on Divergences"
- [ ] Recommendations are actionable

### 5. Workspace File
- [ ] SESSION INFO complete
- [ ] TASK well defined
- [ ] All sections filled in
- [ ] No [placeholder] remaining

## Red Flags (Block)

- Claude only orchestrated without its own analysis
- Output is copy-paste from a peer
- Requests to peers too generic
- PEER CONTRIBUTIONS sections empty (if a peer was expected)
- End markers missing

## Quality Score

| Criterion | Weight | Score (1-5) |
|-----------|--------|-------------|
| Completeness of CLAUDE ANALYSIS | 25% | |
| Specificity of SUPPORT REQUESTS | 15% | |
| Quality of INTEGRATED OUTPUT | 25% | |
| Divergence handling | 15% | |
| File completeness | 20% | |

**Target**: Average score >= 4

## DECISION LOG Checklist

The user fills in:
```markdown
## DECISION LOG

### User Validations
- [ ] Output addresses the original task
- [ ] Peer contributions were considered
- [ ] Output is Claude's own (not a copy of a peer's)
- [ ] Quality is satisfactory
- [ ] Workspace file is complete

### Status
- [x] Approved
```

## Validation Workflow

1. **Claude completes** INTEGRATED OUTPUT
2. **Claude verifies** this checklist
3. **Claude signals** to the user: "Output ready for validation"
4. **The user** fills in DECISION LOG
5. **If approved**: Session concluded
6. **If needs revision**: Max 2 rounds

## Notification Template

When Claude has finished:
```
I have completed the output in ARENA_WORKSPACE.md.

Summary:
- Task: [brief description]
- Peers involved: [ChatGPT/Gemini/both]
- Divergences: [yes/no - if yes, which ones]

The file is ready for your validation in the DECISION LOG.
```

## Post-Session

After approval:
1. Workspace file remains as documentation
2. Session IDs noted for potential resumption
3. Lessons learned (optional) for improvement
