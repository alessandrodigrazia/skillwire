# Disagreement Protocol (VS Code)

How to handle divergences between Claude and peers in the VS Code environment.

## Principles

1. **Claude has the final word** (as the lead analyst)
2. **Disagreements are valuable** (they bring insight)
3. **Transparency in the file** (everything is documented in ARENA_WORKSPACE.md)
4. **The user decides** in case of critical doubt

## Types of Divergence

### Type 1: Factual Disagreement
One AI states X, the other states Y.

**Resolution:**
1. If Gemini performed web research -> more reliable on recent facts
2. If ChatGPT reasoned logically -> more reliable on deductions
3. Document in the file under "Notes on Divergences"

### Type 2: Interpretive Disagreement
Same facts, different conclusions.

**Resolution:**
1. Claude evaluates the arguments in the file
2. Chooses the most coherent interpretation
3. Explains WHY in INTEGRATED OUTPUT
4. Mentions the discarded alternative

### Type 3: Recommendation Disagreement
All agree on the analysis, different suggestions.

**Resolution:**
1. List all recommendations in INTEGRATED OUTPUT
2. Evaluate pros/cons
3. Propose a synthesis
4. The user decides in DECISION LOG

## Template in the File

In INTEGRATED OUTPUT, section "Notes on Divergences":

```markdown
### Notes on Divergences

**Divergence 1: [Title]**
- Claude: [position]
- ChatGPT: [position]
- Gemini: [position]

**Resolution**: [How I resolved it and why]

**For the user**: [If an explicit decision is needed]
```

## Handling via Subagents

If using the CLI workflow and there is a divergence:

1. Claude reads the contributions in the file
2. If there is a critical divergence, Claude can:
   - Invoke the subagent again with a clarification question
   - Ask another subagent to act as an "arbiter"
   - Escalate to the user

### Example: Second Round
```
Task tool: gemini-flash
prompt: "In ARENA_WORKSPACE.md there is a divergence between my analysis
        and ChatGPT's on [point]. Who is correct?
        Justify your answer."
```

## Escalation to the User

Mark in the DECISION LOG:
```markdown
### User Decision Request

**Critical divergence on**: [description]
**Positions**:
- Claude: X
- ChatGPT: Y
- Gemini: Z

**Impact**: [why it is critical]
**Options**:
1. [Option 1]
2. [Option 2]

**Claude's recommendation**: [if you have a preference]
```

## Limits

- **Max 2 rounds** of follow-up per divergence
- **No infinite ping-pong**: Decide and move on
- **Always document**: Everything in the file for transparency

## Anti-Patterns

- Ignoring divergences
- Always deferring to peers
- Hiding disagreements
- Becoming paralyzed without deciding
