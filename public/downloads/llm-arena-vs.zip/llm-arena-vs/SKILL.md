---
name: llm-arena-vs
description: Multi-AI orchestration (Claude + ChatGPT + Gemini) for Claude Code in VS Code. Automated CLI workflow with persistent sessions. Claude is the lead analyst. Use for "AI arena", "collaborative peer review", "multi-model analysis".
---

# LLM-ARENA-VS - Multi-AI Orchestration (VS Code)

Skill for orchestrating multi-AI collaborations in **Claude Code (VS Code)** with:
- Shared file ARENA_WORKSPACE.md
- CLI subagents (Codex, Gemini)
- Persistent sessions

> **Note**: This version is for Claude Code in VS Code.
> For Claude Desktop, use `llm-arena`.

## Key Principle

```
CLAUDE = Lead analyst (produces the analysis)
              |
              v
    Identifies where support is needed
              |
              v
    Calls subagents: chatgpt-codex, chatgpt, gemini-pro, gemini-flash
              |
              v
CLAUDE = Integrates and produces final output
```

## Quick Start

1. **SETUP**: Create ARENA_WORKSPACE.md with the task
2. **ANALYSIS**: Claude produces its analysis in the file
3. **SUPPORT**: Claude writes specific requests in the file
4. **SUBAGENTS**: The user notifies peers ("your turn")
5. **INTEGRATE**: Claude integrates contributions
6. **VALIDATE**: The user approves

## Available Subagents

| Subagent | Model | When |
|----------|-------|------|
| `chatgpt-codex` | gpt-5.2-codex | Complex coding (+12% SWE-bench) |
| `chatgpt` | gpt-5.2 | Abstract reasoning (2x ARC-AGI-2) |
| `gemini-pro` | gemini-3-pro | Multimodal, deep reasoning |
| `gemini-flash` | gemini-3-flash | Fast tasks (3x speed, 1/4 cost) |

See [subagent-selector.md](references/subagent-selector.md) for the selection logic.

## Operating Modes

### Mode 1: Shared File (Recommended)
All AIs read/write to ARENA_WORKSPACE.md.

```
Claude writes analysis + requests in the file
           |
           v
User: "ChatGPT, read the file, your turn"
           |
           v
ChatGPT writes contribution in the file
           |
           v
Claude integrates and produces output
```

**Pros**: Shared context, less copy-paste
**User effort**: "your turn" per peer

### Mode 2: Automated CLI
Claude calls subagents directly via CLI.

```
Claude calls: chatgpt-codex (Task tool)
           |
           v
Subagent executes codex with prompt
           |
           v
Claude receives response and integrates
```

**Pros**: Zero user intervention
**Cons**: Each CLI call is stateless (but persistent sessions help)

> **CRITICAL**: When using the Task tool to invoke a subagent, the prompt MUST include
> the exact Bash command to execute. The subprocess Claude might "interpret" instead
> of executing. See [workflow-cli.md](references/workflow-cli.md) for mandatory commands.

**Bash Commands for Subagents:**

| Subagent | Command |
| -------- | ------- |
| `chatgpt` | `codex exec --skip-git-repo-check -m gpt-5.2 "prompt"` |
| `chatgpt-codex` | `codex exec --skip-git-repo-check "prompt"` |
| `gemini-pro` | `gemini -m gemini-3-pro-preview "prompt"` |
| `gemini-flash` | `gemini -m gemini-3-flash-preview "prompt"` |

## Session Management

### Initialization (once per arena)

**Gemini:**
```bash
gemini
/model gemini-3-pro-preview  # or flash
/chat save arena-[task-id]
```

**Codex:**
```bash
codex
# Session auto-saved in ~/.codex/sessions/
```

### Resumption (subsequent calls)

**Gemini:**
```bash
gemini --resume arena-[task-id]
```

**Codex:**
```bash
codex resume --last
# or
codex resume <SESSION_ID>
```

## Detailed Workflow

### Phase 1: Setup
Claude asks:
1. What is the task?
2. How many peers? (1 or 2)
3. Which mode? (shared file / CLI)

Claude creates `ARENA_WORKSPACE.md` using the template.

### Phase 2: Claude Analysis
Claude writes in the file:
- SESSION INFO
- TASK
- CLAUDE ANALYSIS (complete)
- ASPECTS REQUIRING SUPPORT

### Phase 3: Support Request
Claude decides BASED ON THE TASK:
- Evaluates benchmarks and specializations
- Writes SPECIFIC requests in SUPPORT REQUESTS

See [subagent-selector.md](references/subagent-selector.md).

### Phase 4: Peer Contributions
**If shared file:**
The user notifies peers to read the file and write.

**If CLI:**
Claude uses the Task tool to launch subagents.
> **IMPORTANT**: The Task prompt MUST specify the exact Bash command
> (e.g., `codex exec --skip-git-repo-check -m gpt-5.2 "..."`).

### Phase 5: Integration
Claude:
1. Reads PEER CONTRIBUTIONS
2. Integrates into the analysis
3. Writes INTEGRATED OUTPUT
4. Handles divergences

### Phase 6: Validation
The user validates the DECISION LOG.

## Anti-Patterns

- Claude must NEVER just orchestrate without contributing
- Requests to peers must be SPECIFIC
- Do not ignore peer contributions
- Do not use Pro when Flash is sufficient

## References

- [ARENA_WORKSPACE.md](assets/templates/ARENA_WORKSPACE.md) - Shared file template
- [subagent-selector.md](references/subagent-selector.md) - Subagent selection logic
- [workflow-cli.md](references/workflow-cli.md) - CLI workflow
- [workflow-file.md](references/workflow-file.md) - Shared file workflow
- [peer-capabilities.md](references/peer-capabilities.md) - Benchmarks and capabilities
- [disagreement-protocol.md](references/disagreement-protocol.md) - Divergence handling
- [quality-gates.md](references/quality-gates.md) - Quality checklist
