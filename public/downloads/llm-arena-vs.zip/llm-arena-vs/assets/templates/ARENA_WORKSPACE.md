# ARENA WORKSPACE

Template for multi-AI collaboration. All AIs read and write in this file.

---

## SESSION INFO

| Field | Value |
|-------|-------|
| Date | [DATE] |
| Task ID | arena-[ID] |
| Lead Analyst | Claude |
| Peers Involved | [ChatGPT / Gemini / Both] |
| Mode | [Shared File / CLI] |

### Session IDs (for context resumption)
- Gemini Tag: `arena-[task-id]`
- Codex Session: `[SESSION_ID from ~/.codex/sessions/]`

---

## TASK

### Objective
[Clear description of the objective]

### Context
[Necessary background information]

### Constraints/Requirements
[Any specific constraints or requirements]

### Expected Output
[What is expected as a deliverable]

---

## CLAUDE ANALYSIS

### Problem Understanding
[Claude rephrases the problem to verify understanding]

### Structured Analysis
[Body of Claude's analysis - MUST be complete, not a placeholder]

### Preliminary Conclusions
[Claude's initial conclusions]

### Aspects Requiring Support
- **[Aspect 1]**: Asking [AI] because [specific reason]
- **[Aspect 2]**: Asking [AI] because [specific reason]

---

## SUPPORT REQUESTS

### For ChatGPT
**Suggested subagent**: `chatgpt` / `chatgpt-codex`

[SPECIFIC request - not generic!]

Example:
- "Verify if the 100k budget is realistic for these 4 components"
- "Stress-test this logic and find weak points"

### For Gemini
**Suggested subagent**: `gemini-pro` / `gemini-flash`

[SPECIFIC request - not generic!]

Example:
- "Validate these numbers with web research"
- "Analyze this diagram and identify issues"

---

## PEER CONTRIBUTIONS

### ChatGPT
[ChatGPT writes its contribution here]

[Analysis/response to the request]

[Points of agreement/disagreement with Claude]

[Recommendations]

---END CHATGPT CONTRIBUTION---

### Gemini
[Gemini writes its contribution here]

[Analysis/response to the request]

[Points of agreement/disagreement with Claude]

[Recommendations]

---END GEMINI CONTRIBUTION---

---

## INTEGRATED OUTPUT

### Executive Summary
[2-3 key sentences - written by Claude]

### Integrated Analysis
[Claude integrates its analysis with peer contributions]

### Final Conclusions
[Claude's conclusions, enriched by contributions]

### Recommendations
1. [First recommendation]
2. [Second recommendation]
3. [...]

### Notes on Divergences
[If there were divergences, how Claude resolved them]

### Next Steps
[Suggested actions]

---

## DECISION LOG

### User Validations
- [ ] Output addresses the original task
- [ ] Peer contributions were considered
- [ ] Output is Claude's own (not a copy of a peer's)
- [ ] Quality is satisfactory

### Notes
[Any notes or decisions from the user]

### Status
- [ ] In Progress
- [ ] Pending Review
- [ ] Approved
- [ ] Needs Revision

---
*Workspace created: [TIMESTAMP]*
*Last updated: [TIMESTAMP]*
