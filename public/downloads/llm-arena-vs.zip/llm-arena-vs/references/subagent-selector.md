# Subagent Selector - Dynamic Selection Logic

Guide for Claude on which subagent to invoke based on the specific task.

## Available Subagents

| Subagent | Model | CLI | Primary Strength |
|----------|-------|-----|------------------|
| `chatgpt-codex` | gpt-5.2-codex | `codex` | Coding (+12% SWE-bench) |
| `chatgpt` | gpt-5.2 | `codex /model gpt-5.2` | Abstract reasoning (2x) |
| `gemini-pro` | gemini-3-pro | `gemini /model gemini-3-pro-preview` | Multimodal, reasoning |
| `gemini-flash` | gemini-3-flash | `gemini /model gemini-3-flash-preview` | Speed (3x), cost (1/4) |

## Decision Tree

```
START: What is the task type?
|
|-- CODING
|   |-- Complex (refactoring, architecture) -> chatgpt-codex
|   +-- Simple/fast -> gemini-flash
|
|-- ANALYSIS/REASONING
|   |-- Abstract reasoning -> chatgpt
|   |-- Multimodal (images) -> gemini-pro
|   |-- Deep reasoning -> gemini-pro
|   +-- Quick check -> gemini-flash
|
|-- VALIDATION
|   |-- Numbers/metrics -> gemini-pro or gemini-flash
|   |-- Logic/consistency -> chatgpt
|   +-- Web fact-checking -> gemini-flash
|
+-- DEFAULT -> gemini-flash (fast, affordable)
```

## Benchmark Reference (December 2025)

### Coding
| Benchmark | GPT-5.2-Codex | GPT-5.2 | Gemini Pro | Gemini Flash |
|-----------|---------------|---------|------------|--------------|
| SWE-bench Pro | **56.4%** | 55.6% | 43.3% | - |
| SWE-bench Verified | **80%** | - | 76.2% | **78%** |

**Insight**: For complex coding use Codex. For fast coding, Flash surprises (78%!).

### Reasoning
| Benchmark | GPT-5.2 | Gemini Pro |
|-----------|---------|------------|
| ARC-AGI-2 | **52.9%** | 31.1% |
| Humanity's Last Exam | 34.5% | **37.5%** |
| LMArena Elo | - | **1501** |

**Insight**: Abstract reasoning = ChatGPT. Pure reasoning = Gemini Pro.

### Multimodal
| Benchmark | GPT-5.2 | Gemini Pro |
|-----------|---------|------------|
| MMMLU | 89.6% | **91.8%** |

**Insight**: For images/diagrams, Gemini Pro is better.

### Speed and Cost
| Model | Speed | Input Cost |
|-------|-------|------------|
| gemini-flash | **3x** | $0.50/1M |
| gemini-pro | 1x | $2/1M |

**Insight**: Flash costs 1/4 of Pro. Use Flash as the default.

## Selection Examples

### Example 1: Code Review
```
Task: Review this PR for security and performance
Analysis: Complex coding task
Selection: chatgpt-codex
Reason: SWE-bench +12%, specialized in code review
```

### Example 2: Business Plan Validation
```
Task: Verify if the numbers in this business plan are realistic
Analysis: Numeric validation, possible web research
Selection: gemini-flash
Reason: Has web access for fact-checking, fast, affordable
```

### Example 3: Architecture Diagram Analysis
```
Task: Analyze this diagram and identify bottlenecks
Analysis: Multimodal task (image)
Selection: gemini-pro
Reason: MMMLU +2%, specialized in multimodal
```

### Example 4: Strategic Brainstorming
```
Task: Generate alternatives for this complex problem
Analysis: Abstract reasoning, problem solving
Selection: chatgpt
Reason: ARC-AGI-2 nearly 2x compared to Gemini
```

## Suggested Combinations

### For Complete Analysis
1. `chatgpt` for reasoning and brainstorming
2. `gemini-flash` for quick validation

### For Code Review + Business
1. `chatgpt-codex` for technical aspects
2. `gemini-pro` for business impact

### For Multi-Angle Validation
1. `chatgpt` for logical stress-testing
2. `gemini-flash` for web fact-checking

## Notes

1. **Default to Flash**: When in doubt, start with gemini-flash
2. **Don't duplicate**: If one AI is enough, don't involve both
3. **Consider cost**: Pro costs 4x Flash
4. **Claude decides**: These are guidelines, not rigid rules
