# Automated CLI Workflow

Workflow for when Claude calls subagents directly via CLI.

## MANDATORY BASH COMMANDS

When invoking a subagent, the prompt MUST include the exact Bash command:

| Subagent | Bash Command |
|----------|--------------|
| `chatgpt` | `codex exec --skip-git-repo-check -m gpt-5.2 "prompt"` |
| `chatgpt-codex` | `codex exec --skip-git-repo-check "prompt"` |
| `gemini-flash` | `gemini -m gemini-3-flash-preview "prompt"` |
| `gemini-pro` | `gemini -m gemini-3-pro-preview "prompt"` |

**RULE**: The subprocess MUST use the Bash tool to execute these commands.

---

## Overview

```
Claude produces analysis
        |
        v
Claude decides which subagents are needed
        |
        v
Claude launches subagents via Task tool
        |
        v
Subagents execute CLI (codex/gemini)
        |
        v
Claude receives responses and integrates
```

## How It Works

### 1. Claude Prepares the Context
Claude writes the analysis and requests in ARENA_WORKSPACE.md.

### 2. Claude Invokes Subagent
Using the Task tool with EXPLICIT instructions for Bash execution:

```
Task tool:
  subagent_type: chatgpt
  prompt: "OPERATIONAL INSTRUCTIONS:
           1. Use the Bash tool to execute this command:
              codex exec --skip-git-repo-check -m gpt-5.2 \"[YOUR PROMPT]\"
           2. The prompt must contain the request found in ARENA_WORKSPACE.md
           3. Write the output to PEER CONTRIBUTIONS > ChatGPT

           TASK: Read ARENA_WORKSPACE.md, find the request for ChatGPT
           in SUPPORT REQUESTS, perform the requested analysis."
```

**IMPORTANT**: The prompt MUST include the exact Bash command to execute.

### 3. Subagent Executes
The subagent:
1. Reads the workspace file
2. Finds its request
3. **USES THE BASH TOOL** to execute the CLI (codex/gemini)
4. Writes the contribution in the file

### 4. Claude Integrates
Claude reads the contributions and produces the final output.

## Session Management

### First Call (New Arena)
The subagent creates a new session:
```bash
# Gemini
gemini
/model gemini-3-pro-preview
[executes task]
/chat save arena-[task-id]

# Codex
codex
[executes task]
# session auto-saved
```

### Subsequent Calls (Same Arena)
The subagent resumes the session:
```bash
# Gemini
gemini --resume arena-[task-id]

# Codex
codex resume --last
```

**Advantage**: Context from previous interactions is preserved.

## Complete Example

### Step 1: Claude Analyzes
```markdown
## CLAUDE ANALYSIS
I analyzed the business plan. Key points:
- Revenue projection: 500k year 1
- Team: 5 people
- Burn rate: 50k/month

### Aspects Requiring Support
- Number validation with web research (Gemini)
- Revenue model stress-test (ChatGPT)
```

### Step 2: Claude Writes Requests
```markdown
## SUPPORT REQUESTS

### For ChatGPT
Subagent: chatgpt

Analyze the proposed revenue model:
- 500k year 1 with 5 people
- Average deal size: 50k
- Sales cycle: 3 months
Is this realistic? What are the weak points?

### For Gemini
Subagent: gemini-flash

Verify with web research:
1. Revenue benchmark per AI consultant
2. Average deal size for enterprise AI projects
3. Typical B2B enterprise sales cycle
```

### Step 3: Claude Invokes Subagents

**For ChatGPT (GPT-5.2):**
```
Task tool:
  subagent_type: chatgpt
  prompt: "MANDATORY BASH EXECUTION:
           Use the Bash tool to execute:
           codex exec --skip-git-repo-check -m gpt-5.2 \"Analyze the revenue model: 500k year 1, 5 people, deal size 50k, sales cycle 3 months. Is this realistic? Weak points?\"

           After execution, write the output to PEER CONTRIBUTIONS > ChatGPT.
           End with ---END CHATGPT CONTRIBUTION---"
```

**For Gemini Flash:**
```
Task tool:
  subagent_type: gemini-flash
  prompt: "MANDATORY BASH EXECUTION:
           Use the Bash tool to execute:
           gemini -m gemini-3-flash-preview \"Search for revenue benchmarks per AI consultant, average deal size for enterprise AI projects, typical B2B enterprise sales cycle\"

           After execution, write the output to PEER CONTRIBUTIONS > Gemini.
           End with ---END GEMINI CONTRIBUTION---"
```

**For Gemini Pro (complex tasks):**
```
Task tool:
  subagent_type: gemini-pro
  prompt: "MANDATORY BASH EXECUTION:
           Use the Bash tool to execute:
           gemini -m gemini-3-pro-preview \"[COMPLEX PROMPT HERE]\"

           After execution, write the output to PEER CONTRIBUTIONS > Gemini.
           End with ---END GEMINI CONTRIBUTION---"
```

**For ChatGPT-Codex (coding):**
```
Task tool:
  subagent_type: chatgpt-codex
  prompt: "MANDATORY BASH EXECUTION:
           Use the Bash tool to execute:
           codex exec --skip-git-repo-check \"[CODING PROMPT HERE]\"

           After execution, write the output to PEER CONTRIBUTIONS > ChatGPT.
           End with ---END CHATGPT CONTRIBUTION---"
```

### Step 4: Claude Integrates
After the subagents have written, Claude reads and integrates.

## CLI Automated Advantages

| Aspect | CLI | Shared File |
|--------|-----|-------------|
| User intervention | Zero | "Your turn" per peer |
| Speed | Faster | Depends on user |
| Context | Via sessions | In the file |
| Complexity | Higher | Lower |

## When to Use CLI

- Repetitive tasks where automation is desired
- The user is not available to mediate
- Maximum speed is needed
- Requests to peers are well-defined

## When to Prefer Shared File

- Complex tasks that require interaction
- The user wants to control the flow
- Peers might have clarification questions
- Maximum transparency is desired
