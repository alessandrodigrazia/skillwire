# Peer Capabilities - Selection Guide (VS Code)

Guide for Claude on WHEN to request support from whom, based on December 2025 benchmarks.

## Quick Reference

| Task Type | Subagent | Reason |
|-----------|----------|--------|
| Complex coding | `chatgpt-codex` | SWE-bench +12% |
| Fast coding | `gemini-flash` | SWE-bench 78%, 3x faster |
| Abstract reasoning | `chatgpt` | ARC-AGI-2 nearly 2x |
| Multimodal | `gemini-pro` | MMMLU +2% |
| Deep reasoning | `gemini-pro` | Humanity's Last Exam +3% |
| Fast tasks | `gemini-flash` | 3x faster, 1/4 cost |
| Web fact-checking | `gemini-flash` | Has web access |

## Cross-Platform Benchmarks (December 2025)

| Benchmark | GPT-5.2 | Gemini 3 Pro | Winner |
|-----------|---------|--------------|--------|
| GPQA Diamond | 93.2% | 93.8% | Tie |
| MMLU-Pro | 94.2% | - | GPT-5.2 |
| MMMLU (multimodal) | 89.6% | 91.8% | Gemini |
| SWE-bench Pro | 55.6% | 43.3% | GPT-5.2 (+12%) |
| ARC-AGI-2 (abstract) | 52.9% | 31.1% | GPT-5.2 (2x) |
| Humanity's Last Exam | 34.5% | 37.5% | Gemini |

### Variants
- **GPT-5.2-Codex**: +2% on SWE-bench vs base GPT-5.2
- **Gemini Flash**: SWE-bench 78% (beats Pro!), 3x faster, 1/4 price

## Decision Tree for Subagents

```
CODING?
|-- YES, complex -> chatgpt-codex
|-- YES, fast -> gemini-flash
+-- NO
    |
    MULTIMODAL (images)?
    |-- YES -> gemini-pro
    +-- NO
        |
        DEEP REASONING?
        |-- YES -> gemini-pro
        +-- NO
            |
            ABSTRACT REASONING?
            |-- YES -> chatgpt
            +-- NO -> gemini-flash (default)
```

## Specializations per Subagent

### chatgpt-codex (gpt-5.2-codex)
- Complex refactoring
- Advanced debugging
- Security/performance code review
- Architectural migrations
- Design patterns

### chatgpt (gpt-5.2)
- Abstract reasoning
- Strategic brainstorming
- Logical stress-testing
- Non-verbal problem solving
- Consistency analysis

### gemini-pro (gemini-3.1-pro-preview)
- Image and diagram analysis
- Deep multi-step reasoning
- Complex validation
- Tasks requiring highest quality

### gemini-flash (gemini-3-flash-preview)
- Fast tasks (3x)
- Web fact-checking
- Quick validations
- High-volume requests
- Default when in doubt

## Cost

| Subagent | Relative Cost |
|----------|---------------|
| gemini-flash | 1x (baseline) |
| chatgpt | ~2x |
| chatgpt-codex | ~2x |
| gemini-pro | 4x |

**Rule**: Use Flash as the default, scale up only when necessary.

## Notes

1. **Claude decides dynamically**: These are guidelines
2. **Flash first**: When in doubt, start with gemini-flash
3. **Don't duplicate**: If one AI is enough, don't involve others
4. **Consider the task**: Selection depends on the specific case
