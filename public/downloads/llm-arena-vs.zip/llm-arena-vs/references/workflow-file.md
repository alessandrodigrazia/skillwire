# Shared File Workflow

Workflow for when all AIs read/write to ARENA_WORKSPACE.md.

## Overview

```
Claude creates ARENA_WORKSPACE.md
        |
        v
Claude writes analysis + requests
        |
        v
User: "ChatGPT, read the file"
        |
        v
ChatGPT writes contribution in the file
        |
        v
User: "Gemini, your turn"
        |
        v
Gemini writes contribution in the file
        |
        v
User: "Claude, integrate"
        |
        v
Claude reads contributions and produces output
```

## Prerequisites

- VS Code open with 3 panels: Claude Code, Codex, Gemini
- All 3 have access to the same folder
- ARENA_WORKSPACE.md created in the working folder

## Step-by-Step

### Step 1: Claude Creates Workspace (2 min)
Claude:
1. Copies the template from `assets/templates/ARENA_WORKSPACE.md`
2. Fills in SESSION INFO
3. Writes TASK
4. Saves the file in the working folder

### Step 2: Claude Analyzes (5-15 min)
Claude writes in the file:
1. **CLAUDE ANALYSIS**: Complete analysis (not a placeholder!)
2. **Aspects Requiring Support**: List with reasons
3. **SUPPORT REQUESTS**: SPECIFIC requests for each peer

### Step 3: Notify ChatGPT (User)
The user tells ChatGPT (in VS Code):
```
Read the file ARENA_WORKSPACE.md in this folder.
Find your request in SUPPORT REQUESTS > For ChatGPT.
Write your contribution in PEER CONTRIBUTIONS > ChatGPT.
End with ---END CHATGPT CONTRIBUTION---
```

### Step 4: ChatGPT Contributes (5-10 min)
ChatGPT:
1. Reads the file
2. Finds its request
3. Writes the contribution in its section
4. Adds the end marker

### Step 5: Notify Gemini (User)
The user tells Gemini (in the terminal or extension):
```
Read the file ARENA_WORKSPACE.md in this folder.
Find your request in SUPPORT REQUESTS > For Gemini.
Write your contribution in PEER CONTRIBUTIONS > Gemini.
End with ---END GEMINI CONTRIBUTION---
```

### Step 6: Gemini Contributes (5-10 min)
Gemini:
1. Reads the file
2. Finds its request
3. Writes the contribution in its section
4. Adds the end marker

### Step 7: Notify Claude (User)
The user tells Claude:
```
Peers have written their contributions in ARENA_WORKSPACE.md.
Read PEER CONTRIBUTIONS, integrate the contributions with your analysis,
and write the final output in INTEGRATED OUTPUT.
```

### Step 8: Claude Integrates (5-10 min)
Claude:
1. Reads peer contributions
2. Evaluates agreements/disagreements
3. Integrates into its reasoning
4. Writes INTEGRATED OUTPUT
5. Handles divergences (if any)

### Step 9: Validation (User)
The user fills in DECISION LOG:
- [ ] Output addresses the task
- [ ] Contributions considered
- [ ] Quality OK

## Total Time

| Scenario | Time |
|----------|------|
| Claude + 1 peer | 15-25 min |
| Claude + 2 peers | 25-40 min |

## Tips

### For the User
1. **Open everything first**: 3 panels in VS Code ready
2. **Brief notifications**: Just say "read the file, your turn"
3. **Don't edit**: Let the AIs write directly
4. **Monitor**: Check that end markers are present

### For Claude
1. **Specific requests**: Never "what do you think?"
2. **Context in the file**: Don't repeat, it's already there
3. **Truly integrate**: Don't ignore contributions
4. **Explain divergences**: Total transparency

### For Peers
1. **Read the entire file**: Not just your request
2. **Respect the format**: Write in the correct section
3. **End marker**: Always include ---END CONTRIBUTION---
4. **Don't modify elsewhere**: Only your section

## Advantages

- **Shared context**: Everyone sees everything
- **Transparency**: Complete history in the file
- **Control**: The user mediates the flow
- **Simplicity**: No CLI, no sessions to manage
