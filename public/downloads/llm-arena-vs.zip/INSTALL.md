# LLM Arena VS — Installation Prerequisites

This skill orchestrates **Claude + ChatGPT + Gemini** simultaneously from Claude Code CLI.
Before using it, install and authenticate the two companion CLI tools below.

---

## Required Tools

### 1. OpenAI Codex CLI

```bash
npm install -g @openai/codex
codex login
```

**Account required**: ChatGPT Plus, Pro, Team, or Enterprise — or an OpenAI API key.
After login, verify with:
```bash
codex --version
```

### 2. Google Gemini CLI

```bash
npm install -g @google/gemini-cli
gemini
```

**Account required**: Any Google account (free tier available with usage limits).
The first run will prompt you to authenticate via browser.
After setup, verify with:
```bash
gemini --version
```

---

## Cost Notes

| Tool | Plan | Cost |
|------|------|------|
| OpenAI Codex CLI | ChatGPT Plus | ~$20/month |
| OpenAI Codex CLI | API key | Pay per use |
| Google Gemini CLI | Google account (free tier) | Free (limited quota) |
| Google Gemini CLI | Gemini Advanced | ~$20/month (higher quota) |

---

## Verification

Once both tools are installed and authenticated:

```bash
# Test Codex
codex exec "Say hello in one word"

# Test Gemini
gemini -m gemini-3-flash-preview "Say hello in one word"
```

Both should return a response without errors. You are now ready to use **LLM Arena VS**.
