---
name: nano-banana-guru
description: Proactive prompt engineering consultant for Google's Nano Banana Pro visual reasoning model. This skill should be used when crafting prompts for Nano Banana Pro image generation, creating visual artifacts (dashboards, infographics, thumbnails, comics, diagrams, storyboards), or when the user discusses visual content creation. The skill actively suggests relevant capabilities based on conversation context, drawing from a comprehensive library of 26+ production-ready examples covering text rendering, character consistency, identity locking, dimensional translation, advanced editing, and structural control.
---

# Nano Banana Pro Prompt Engineering

## Overview

This skill provides structured guidance AND proactive consultation for creating effective prompts for Nano Banana Pro, Google's visual reasoning model. Unlike traditional image generators, Nano Banana Pro is a "Thinking" model that understands intent, physics, and composition.

**Key Shift**: Stop using "tag soups" (e.g., `dog, park, 4k, realistic`) and start acting like a **Creative Director** briefing a human artist.

## The Golden Rules of Prompting

Before ANY prompt construction, apply these foundational principles:

### Rule 1: Edit, Don't Re-roll

The model excels at understanding conversational edits. If an image is 80% correct, **DO NOT generate from scratch**. Instead, ask for the specific change needed.

**Example**: "That's great, but change the lighting to sunset and make the text neon blue."

### Rule 2: Use Natural Language & Full Sentences

Talk to the model as if briefing a human artist. Use proper grammar and descriptive adjectives.

- ❌ Bad: `"Cool car, neon, city, night, 8k."`
- ✅ Good: `"A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. The neon signs reflect off the wet pavement and the car's metallic chassis."`

### Rule 3: Be Specific About Materiality

Vague prompts yield generic results. Define textures explicitly:
- "Matte finish"
- "Brushed steel"
- "Soft velvet"
- "Crumpled paper"
- "Glistening melt"

### Rule 4: Provide Context (The "Why" and "For Whom")

Because the model "thinks," giving context helps it make logical artistic decisions.

**Example**: "Create an image of a sandwich for a Brazilian high-end gourmet cookbook."
→ The model infers: professional plating, shallow depth of field, perfect lighting.

## The Seven Visual Reasoning Engines

Nano Banana Pro operates on seven distinct engines:

1. **Layout Engine**: Coherent spatial structures, grids, columns, visual hierarchies
2. **Diagram Engine**: Translates structured text into diagrams with nodes, connections, labels
3. **Typography Engine**: Text as design element—sharp, readable at small sizes, respected hierarchies
4. **Data Visualization Engine**: Numbers → compelling visualizations (charts, KPIs, indicators)
5. **Style Universe Engine**: Aesthetic consistency (palette, lighting, linework)
6. **Brand & Identity Engine**: Recognizes and applies brand elements precisely
7. **Representation Transformer Engine**: Switches visual surface while preserving content relationships

**Additional Capabilities** (from latest model updates):
- **Physics Understanding**: Complex changes like "fill this glass with liquid"
- **Search Grounding**: Real-time data visualization via Google Search
- **Identity Locking**: Up to 14 reference images (6 with high fidelity) for character consistency

## Proactive Suggestion System

**CRITICAL BEHAVIOR**: This skill should ACTIVELY suggest capabilities based on conversation context. When engaged in discussion about visual content, monitor for trigger patterns and propose relevant Nano Banana Pro capabilities.

### Trigger Detection Matrix

| User Context | Trigger Keywords | Proactive Suggestion | Reference File |
|--------------|------------------|----------------------|----------------|
| Image almost right | "almost", "80%", "just change", "almost perfect" | → Edit, Don't Re-roll | `prompt_examples_library.md#golden-rules` |
| Series/sequences | "series", "carousel", "storyboard", "episodes", "multiple scenes" | → Identity Locking + Character Consistency | `prompt_examples_library.md#character-consistency` |
| Data/numbers | "data", "statistics", "report", "earnings", "infographic" | → Data Visualization + Search Grounding | `prompt_examples_library.md#text-rendering-infographics` |
| Sketch/wireframe input | "draft", "sketch", "wireframe", "hand drawing" | → Structural Control (Sketch to Final) | `prompt_examples_library.md#structural-control` |
| Thumbnail/viral | "thumbnail", "YouTube", "viral", "click", "social" | → Viral Thumbnail template | `prompt_examples_library.md#viral-thumbnails` |
| Translation/markets | "localize", "translate", "japanese market", "adapt for" | → Localization technique | `prompt_examples_library.md#advanced-editing` |
| Old/damaged photos | "old photo", "restore", "colorize", "black and white" | → Restoration/Colorization | `prompt_examples_library.md#advanced-editing` |
| 2D/3D conversion | "floor plan", "blueprint", "3D", "render", "interior" | → Dimensional Translation | `prompt_examples_library.md#dimensional-translation` |
| Textures/wallpaper | "texture", "wallpaper", "4K", "high resolution", "detail" | → High-Resolution techniques | `prompt_examples_library.md#high-resolution-textures` |
| Sprites/animation | "sprite", "animation", "frame", "gif", "game asset" | → Sprite Sheet template | `prompt_examples_library.md#structural-control` |
| Problem-solving visual | "solve", "analyze", "before/after", "reasoning" | → Thinking & Reasoning | `prompt_examples_library.md#thinking-reasoning` |
| Brand asset production | "brand", "fashion", "editorial", "product shots" | → Brand Asset Generation | `prompt_examples_library.md#character-consistency` |

### Proactive Response Pattern

When a trigger is detected:

1. **Acknowledge** the user's intent
2. **Propose** the relevant capability with a concrete example from the library
3. **Offer** choices: build prompt together OR provide ready template

**Response Template**:
```
"I see you are working on [context]. Nano Banana Pro has a specific capability for this: **[capability name]**.

For example, you could achieve [specific outcome] with an approach like:
'[brief natural language example from library]'

Do you want to:
(A) Build the full JSON prompt together using the 8-area canvas?
(B) See a ready-to-customize JSON template?
(C) Review best practices for this type of output first?"
```

## Quick Mode: Video to Carousel

Quick mode to transform YouTube videos into visual carousels (cover + concept cards).

### Workflow

```
YOUTUBE VIDEO → [Step 1: Gemini] → CONCEPTS → [Step 2: Nano Banana Pro] → CAROUSEL
```

### Trigger Keywords

`"YouTube video"`, `"carousel from video"`, `"extract concepts"`, `"video to carousel"`

### How It Works

1. **Step 1**: Concept extraction with Gemini (subagent or manual prompt)
2. **Interactive questions**: Palette + Branding
3. **Step 2A**: Cover Image Generation
4. **Step 2B**: Concept Cards Generation (max 10)

### Mandatory Constraint

**NEVER** include references to the original YouTube author/channel in the images, unless explicitly requested by the user.

### Full Details

See: `references/video_to_carousel_workflow.md`

## The 8-Area Prompt Canvas

For structured prompt construction, follow these 8 areas in order:

1. **Intent & Goal**: Purpose and audience
2. **Subject & Content**: Specific content to depict
3. **Work Surface**: Type of artifact (dashboard, comic, blueprint, thumbnail)
4. **Layout & Structure**: Spatial organization
5. **Style & Aesthetics**: Visual style, palette, mood
6. **Components & Details**: Specific elements that must appear
7. **Constraints**: Rules to follow (and what NOT to do)
8. **Context/Source Material**: Reference material, data, narrative

## Output Format: JSON

All prompts for Nano Banana Pro should be generated in structured JSON format for precision. See `references/work_surface_templates.md` for complete templates.

**Core JSON Structure**:
```json
{
  "image_request": {
    "title": "descriptive title",
    "purpose": "what this accomplishes",
    "format": { "platform", "aspect_ratio", "resolution_px", "orientation" },
    "brand_context": { "brand_name", "tone_of_voice", "consistency_notes" },
    "layout": { "overall_structure", "zones", "visual_hierarchy" },
    "content": { "language", "word_limit", "text_elements", "constraints" },
    "visual_style": { "design_language", "background", "color_palette", "typography" },
    "iconography_and_visual_elements": { ... },
    "tone_and_message_intent": { ... },
    "constraints_and_avoidances": { ... },
    "rendering_guidance": { "priority_order", "style_keywords_for_model" }
  }
}
```

## Quick Reference for Examples

The skill includes a comprehensive library of 26 production-ready examples. To find relevant examples:

**For Text & Infographics** → search "infographic", "text rendering", "whiteboard", "diagram"
**For Character/Identity** → search "identity locking", "thumbnail", "fluffy friends", "fashion"
**For Data Visualization** → search "earnings", "national parks", "grounding"
**For Editing** → search "removal", "colorization", "localization", "seasonal"
**For 2D↔3D** → search "floor plan", "interior", "meme 3D"
**For High-Res** → search "4K", "texture", "cheeseburger"
**For Reasoning** → search "equation", "whiteboard", "construction"
**For Storyboards** → search "luggage", "9-part", "storyboard"
**For Structural Control** → search "sketch", "wireframe", "sprite", "pixel art"

See: `references/prompt_examples_library.md`

## Interactive Mode

When helping users build prompts interactively, use the Nano Banana Architect protocol in `references/nano_banana_architect.md`. Ask ONE question at a time following the 8-area sequence.

## Best Practices Summary

1. **Be explicit about spatial relationships**: Use ratios (0.25, 0.35, 0.40) and precise positions
2. **Specify all colors as hex codes**: Never use color names alone
3. **Include negative constraints**: What should NOT happen is critical
4. **Use arrays for multiple items**: Lists of tones, constraints, elements
5. **Maintain consistency fields**: For sequences, include `consistency_notes`
6. **Specify typography hierarchy**: Define relative sizing/weight for each text element
7. **Edit conversationally**: Don't regenerate when a simple edit will work
8. **Provide context**: The "why" helps the model make better artistic decisions
