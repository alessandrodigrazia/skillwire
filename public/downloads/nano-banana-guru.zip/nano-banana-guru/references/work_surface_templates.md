# Work Surface Templates (JSON Format)

This reference contains ready-to-use JSON templates for common visual artifact types. Each template provides a starting structure that can be customized.

**Usage:** Copy the relevant template, then customize all bracketed `[placeholder]` values.

## Contents

- [LinkedIn Carousel Slide](#linkedin-carousel-slide)
- [Comic/Sequential Art](#comicsequential-art)
- [Dashboard](#dashboard)
- [Infographic](#infographic)
- [Diagram/Flowchart](#diagramflowchart)
- [Viral Thumbnail](#viral-thumbnail) *(NEW)*
- [Sprite Sheet](#sprite-sheet) *(NEW)*
- [Storyboard Commercial](#storyboard-commercial) *(NEW)*
- [Technical Blueprint](#technical-blueprint) *(NEW)*
- [Interior Design Board](#interior-design-board) *(NEW)*

---

## LinkedIn Carousel Slide

```json
{
  "image_request": {
    "title": "[Descriptive title for this slide]",
    "purpose": "[What this slide should accomplish]",
    
    "format": {
      "platform": "LinkedIn carousel",
      "aspect_ratio": "1:1",
      "resolution_px": [1080, 1080],
      "orientation": "square",
      "slide_index": "[number]",
      "series_role": "[intro|content|transition|cta|conclusion]"
    },
    
    "brand_context": {
      "brand_name": "[Brand]",
      "tone_of_voice": ["[tone1]", "[tone2]", "[tone3]"],
      "positioning_message": "[Core brand message]",
      "consistency_notes": [
        "Maintain continuity with previous slides",
        "[Additional consistency requirement]"
      ]
    },
    
    "layout": {
      "overall_structure": "[High-level layout description]",
      "zones": {
        "header": {
          "role": "[zone purpose]",
          "vertical_span_ratio": 0.20,
          "alignment": "left",
          "elements": ["[element1]", "[element2]"]
        },
        "main_content": {
          "role": "[zone purpose]",
          "vertical_span_ratio": 0.55,
          "alignment": "[left|center|right]",
          "elements": ["[element1]", "[element2]"]
        },
        "footer": {
          "role": "[zone purpose]",
          "vertical_span_ratio": 0.25,
          "alignment": "[left|center|right]",
          "elements": ["logo", "[other elements]"]
        }
      },
      "visual_hierarchy": [
        "[Most prominent element]",
        "[Second most prominent]",
        "[Third]",
        "[Least prominent]"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "word_limit": {
        "max_visible_words": "[number]",
        "note": "[Additional guidance]"
      },
      "text_elements": {
        "headline": {
          "text": "[Exact headline text]",
          "role": "[purpose of this text]",
          "approx_word_count": "[number]"
        },
        "body": {
          "text": "[Body text if any]",
          "role": "[purpose]",
          "approx_word_count": "[number]"
        }
      },
      "constraints": [
        "[Text constraint 1]",
        "[Text constraint 2]"
      ]
    },
    
    "visual_style": {
      "design_language": ["minimalist", "clean B2B", "[other descriptors]"],
      "background": {
        "color": "#[hexcode]",
        "treatment": "[gradient|solid|texture description]",
        "texture": "[description or 'none']"
      },
      "color_palette": {
        "primary": [
          {"name": "[name]", "hex": "#[hexcode]", "usage": "background"},
          {"name": "[name]", "hex": "#[hexcode]", "usage": "text"}
        ],
        "accent": [
          {"name": "[name]", "hex": "#[hexcode]", "usage": "[usage]"}
        ],
        "contrast_notes": [
          "[Accessibility requirement]"
        ]
      },
      "typography": {
        "font_family_style": "[font category]",
        "examples": ["[Font1]", "[Font2]"],
        "hierarchy": {
          "headline": {
            "weight": "[bold|semibold|regular]",
            "color": "#[hexcode]",
            "size_relationship": "largest"
          },
          "body": {
            "weight": "regular",
            "color": "#[hexcode]",
            "size_relationship": "medium"
          }
        }
      }
    },
    
    "iconography_and_visual_elements": {
      "logo": {
        "status": "required",
        "placement": "bottom-right",
        "size_relationship": "[relative size]"
      },
      "[other_element]": {
        "status": "[required|optional]",
        "description": "[what it is]",
        "placement": "[where]",
        "style": "[visual treatment]"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": ["[emotion1]", "[emotion2]"],
      "narrative_position": "[Where this fits in the story]",
      "copy_tone": ["[tone1]", "[tone2]"],
      "implicit_message": "[What viewer should understand]"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": ["[constraint1]"],
      "visual_constraints": [
        "No complex illustrations",
        "No stock photos",
        "[other constraints]"
      ],
      "brand_constraints": ["[brand requirement]"],
      "interaction_intent": "[Desired viewer action]"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Text clarity",
        "Visual hierarchy",
        "Brand consistency"
      ],
      "style_keywords_for_model": [
        "minimalist UI",
        "LinkedIn carousel",
        "professional",
        "[other keywords]"
      ],
      "export_notes": [
        "1080x1080px",
        "No watermarks"
      ]
    }
  }
}
```

---

## Comic/Sequential Art

### Work Surface Variations
- Single panel illustration
- 3-panel horizontal strip
- 4-panel (2×2) grid
- 6-panel full page
- Splash page with insets

### Template: 4-Panel Comic Page

```json
{
  "image_request": {
    "title": "[Comic title - scene description]",
    "purpose": "[What this page should accomplish narratively]",
    
    "format": {
      "platform": "print_comic",
      "aspect_ratio": "2:3",
      "resolution_px": [2400, 3600],
      "orientation": "portrait",
      "page_number": "[number]",
      "series_role": "narrative_page"
    },
    
    "brand_context": {
      "brand_name": "[Comic/story title]",
      "tone_of_voice": ["[genre tone]", "[mood]", "[era]"],
      "positioning_message": "[Story premise]",
      "consistency_notes": [
        "Maintain character design from previous pages",
        "Consistent architectural/environmental style",
        "Shadow direction from [direction]"
      ]
    },
    
    "layout": {
      "overall_structure": "4-panel grid (2x2) with consistent gutters",
      "zones": {
        "panel_1": {
          "role": "[establishing|action|dialogue|reaction]",
          "position": "top-left",
          "vertical_span_ratio": 0.48,
          "horizontal_span_ratio": 0.48,
          "shot_type": "[wide|medium|close-up|extreme_close-up]",
          "elements": ["[element1]", "[element2]", "caption_box"]
        },
        "panel_2": {
          "role": "[role]",
          "position": "top-right",
          "vertical_span_ratio": 0.48,
          "horizontal_span_ratio": 0.48,
          "shot_type": "[shot type]",
          "elements": ["[elements]"]
        },
        "panel_3": {
          "role": "[role]",
          "position": "bottom-left",
          "vertical_span_ratio": 0.48,
          "horizontal_span_ratio": 0.48,
          "shot_type": "[shot type]",
          "elements": ["[elements]"]
        },
        "panel_4": {
          "role": "[role]",
          "position": "bottom-right",
          "vertical_span_ratio": 0.48,
          "horizontal_span_ratio": 0.48,
          "shot_type": "[shot type]",
          "elements": ["[elements]"]
        },
        "gutters": {
          "width_ratio": 0.02,
          "color": "#FFFFFF"
        }
      },
      "visual_hierarchy": [
        "Panel narrative flow (1→2→3→4)",
        "Character figures",
        "Speech/caption text",
        "Environmental details"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "word_limit": {
        "max_visible_words": "[number]",
        "note": "[Captions only / Dialogue heavy / etc.]"
      },
      "text_elements": {
        "panel_1_text": {
          "text": "[Caption or dialogue]",
          "role": "[caption|dialogue|sfx]",
          "placement": "[position in panel]"
        },
        "panel_2_text": {
          "text": "[text]",
          "role": "[role]",
          "placement": "[position]"
        },
        "panel_3_text": {
          "text": "[text]",
          "role": "[role]",
          "placement": "[position]"
        },
        "panel_4_text": {
          "text": "[text]",
          "role": "[role]",
          "placement": "[position]"
        }
      },
      "constraints": [
        "Text must not obscure key visual elements",
        "Speech balloons point to speakers"
      ]
    },
    
    "visual_style": {
      "design_language": ["[art style]", "[era]", "[technique]"],
      "background": {
        "color": "#FFFFFF",
        "treatment": "[page treatment]"
      },
      "color_palette": {
        "primary": [
          {"name": "ink", "hex": "#1A1A1A", "usage": "linework"},
          {"name": "paper", "hex": "#FFFFFF", "usage": "background"}
        ],
        "accent": [
          {"name": "[accent]", "hex": "#[hex]", "usage": "[usage]"}
        ],
        "contrast_notes": [
          "[Contrast/shading approach]"
        ]
      },
      "typography": {
        "font_family_style": "comic lettering",
        "examples": ["CC Wild Words", "Anime Ace"],
        "hierarchy": {
          "captions": {
            "weight": "regular",
            "color": "#1A1A1A",
            "box_style": "rectangular thin border"
          },
          "dialogue": {
            "weight": "regular",
            "color": "#1A1A1A",
            "balloon_style": "[rounded|cloud|jagged]"
          },
          "sfx": {
            "weight": "bold",
            "style": "hand-drawn integrated"
          }
        }
      }
    },
    
    "iconography_and_visual_elements": {
      "protagonist": {
        "status": "required",
        "description": "[Physical description]",
        "constraint": "Must remain identical across all panels"
      },
      "environment": {
        "status": "required",
        "description": "[Setting description]",
        "style": "[Architectural/environmental style]"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": ["[emotion1]", "[emotion2]"],
      "narrative_position": "[Where in the story]",
      "copy_tone": ["[tone]"],
      "implicit_message": "[What reader should feel]"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": [
        "[Text constraint]"
      ],
      "visual_constraints": [
        "Consistent shadow direction",
        "Character model consistency",
        "[Period/style accuracy]"
      ],
      "brand_constraints": [
        "Match established visual language"
      ],
      "interaction_intent": "[Reader engagement goal]"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Character consistency",
        "Narrative clarity",
        "Style accuracy",
        "Atmospheric mood"
      ],
      "style_keywords_for_model": [
        "[art style]",
        "sequential art",
        "[technique]",
        "[mood]"
      ],
      "export_notes": [
        "High resolution for print",
        "Sharp linework"
      ]
    }
  }
}
```

---

## Dashboard

### Work Surface Variations
- Executive summary (4-6 KPIs)
- Operational dashboard (real-time metrics)
- Analytics dashboard (trends and comparisons)
- Financial dashboard (revenue, costs, margins)

### Template: Analytics Dashboard

```json
{
  "image_request": {
    "title": "[Dashboard title]",
    "purpose": "[What decisions this dashboard supports]",
    
    "format": {
      "platform": "[web|presentation|print]",
      "aspect_ratio": "16:9",
      "resolution_px": [1920, 1080],
      "orientation": "landscape"
    },
    
    "brand_context": {
      "brand_name": "[Company]",
      "tone_of_voice": ["professional", "data-driven", "clear"],
      "positioning_message": "[Dashboard purpose]",
      "consistency_notes": [
        "Match corporate visual identity",
        "Use approved chart styles"
      ]
    },
    
    "layout": {
      "overall_structure": "Header bar + 3-column main grid + footer",
      "zones": {
        "header": {
          "role": "branding_and_filters",
          "vertical_span_ratio": 0.08,
          "elements": ["logo", "title", "date_range_selector", "filters"]
        },
        "left_column": {
          "role": "kpi_cards",
          "vertical_span_ratio": 0.84,
          "horizontal_span_ratio": 0.25,
          "elements": ["kpi_card_1", "kpi_card_2", "kpi_card_3", "kpi_card_4"]
        },
        "center_column": {
          "role": "primary_visualization",
          "vertical_span_ratio": 0.84,
          "horizontal_span_ratio": 0.50,
          "elements": ["main_chart", "chart_legend"]
        },
        "right_column": {
          "role": "secondary_visualizations",
          "vertical_span_ratio": 0.84,
          "horizontal_span_ratio": 0.25,
          "elements": ["pie_chart", "data_table"]
        },
        "footer": {
          "role": "metadata",
          "vertical_span_ratio": 0.08,
          "elements": ["last_updated", "export_options"]
        }
      },
      "visual_hierarchy": [
        "KPI values (largest numbers)",
        "Main chart trend",
        "Secondary charts",
        "Supporting text and labels"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "word_limit": {
        "max_visible_words": 100,
        "note": "Labels and values only, no prose"
      },
      "text_elements": {
        "dashboard_title": {
          "text": "[Dashboard Title]",
          "role": "identification"
        },
        "kpi_1": {
          "label": "[Metric name]",
          "value": "[Value with unit]",
          "trend": "[↑X% | ↓X% | →]"
        },
        "kpi_2": {
          "label": "[Metric name]",
          "value": "[Value]",
          "trend": "[trend]"
        },
        "kpi_3": {
          "label": "[Metric name]",
          "value": "[Value]",
          "trend": "[trend]"
        },
        "kpi_4": {
          "label": "[Metric name]",
          "value": "[Value]",
          "trend": "[trend]"
        }
      },
      "constraints": [
        "All numbers must have units",
        "Trends must show comparison period"
      ]
    },
    
    "visual_style": {
      "design_language": ["clean", "corporate", "data-focused", "minimal"],
      "background": {
        "color": "#F5F7FA",
        "treatment": "solid light gray",
        "texture": "none"
      },
      "color_palette": {
        "primary": [
          {"name": "background", "hex": "#F5F7FA", "usage": "page background"},
          {"name": "card_bg", "hex": "#FFFFFF", "usage": "card backgrounds"},
          {"name": "text_dark", "hex": "#1A1A2E", "usage": "primary text"}
        ],
        "accent": [
          {"name": "primary_blue", "hex": "#2563EB", "usage": "primary data series"},
          {"name": "positive_green", "hex": "#10B981", "usage": "positive trends"},
          {"name": "negative_red", "hex": "#EF4444", "usage": "negative trends"}
        ],
        "secondary": [
          {"name": "secondary_data", "hex": "#8B5CF6", "usage": "secondary series"},
          {"name": "tertiary_data", "hex": "#F59E0B", "usage": "tertiary series"}
        ],
        "contrast_notes": [
          "Data colors must be distinguishable for colorblind users",
          "Text must have 4.5:1 contrast ratio minimum"
        ]
      },
      "typography": {
        "font_family_style": "clean sans-serif",
        "examples": ["Inter", "Roboto", "SF Pro"],
        "hierarchy": {
          "dashboard_title": {
            "weight": "semibold",
            "color": "#1A1A2E",
            "size_relationship": "largest text"
          },
          "kpi_value": {
            "weight": "bold",
            "color": "#1A1A2E",
            "size_relationship": "prominent numbers"
          },
          "kpi_label": {
            "weight": "regular",
            "color": "#6B7280",
            "size_relationship": "small supporting"
          },
          "axis_labels": {
            "weight": "regular",
            "color": "#6B7280",
            "size_relationship": "smallest"
          }
        }
      }
    },
    
    "iconography_and_visual_elements": {
      "kpi_cards": {
        "status": "required",
        "description": "Rounded rectangle cards with shadow",
        "style": "subtle drop shadow, rounded corners",
        "content": "Label, value, trend indicator, sparkline optional"
      },
      "main_chart": {
        "status": "required",
        "chart_type": "[line|bar|area]",
        "description": "[What the chart shows]",
        "elements": ["axis_labels", "gridlines", "data_series", "legend"]
      },
      "trend_indicators": {
        "status": "required",
        "positive": "↑ in green",
        "negative": "↓ in red",
        "neutral": "→ in gray"
      },
      "logo": {
        "status": "required",
        "placement": "header-left",
        "size_relationship": "small, non-dominant"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": [
        "confidence in data accuracy",
        "quick comprehension",
        "actionable insights"
      ],
      "narrative_position": "[What story the data tells]",
      "copy_tone": ["objective", "precise", "professional"],
      "implicit_message": "[Key takeaway]"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": [
        "No overlapping labels",
        "All axes clearly labeled with units"
      ],
      "visual_constraints": [
        "No 3D chart effects",
        "No decorative elements",
        "Maximum 7 colors in any chart",
        "Y-axis starts at zero for bar charts",
        "Consistent decimal precision"
      ],
      "brand_constraints": [
        "Use approved color palette only",
        "Logo placement per brand guidelines"
      ],
      "interaction_intent": "Enable quick data comprehension and decision-making"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Data legibility",
        "Visual hierarchy",
        "Aesthetic consistency",
        "Brand alignment"
      ],
      "style_keywords_for_model": [
        "clean dashboard UI",
        "data visualization",
        "business intelligence",
        "flat design",
        "minimal chart design"
      ],
      "export_notes": [
        "Crisp at target resolution",
        "All text anti-aliased"
      ]
    }
  }
}
```

---

## Infographic

### Work Surface Variations
- Vertical scrolling infographic
- Horizontal timeline
- Comparison infographic (A vs B)
- Process/how-to infographic
- Statistical infographic

### Template: Vertical Infographic

```json
{
  "image_request": {
    "title": "[Infographic title]",
    "purpose": "[What information this infographic conveys]",
    
    "format": {
      "platform": "[social_media|blog|print]",
      "aspect_ratio": "1:3",
      "resolution_px": [1080, 3240],
      "orientation": "portrait_tall"
    },
    
    "brand_context": {
      "brand_name": "[Brand]",
      "tone_of_voice": ["informative", "engaging", "authoritative"],
      "positioning_message": "[Key message]",
      "consistency_notes": [
        "Use brand colors",
        "Include logo and URL"
      ]
    },
    
    "layout": {
      "overall_structure": "Vertical scroll: header → sections → footer",
      "zones": {
        "header": {
          "role": "title_and_hook",
          "vertical_span_ratio": 0.15,
          "elements": ["headline", "subheadline", "hero_stat"]
        },
        "section_1": {
          "role": "key_point_1",
          "vertical_span_ratio": 0.20,
          "elements": ["icon", "headline", "explanation", "data_point"]
        },
        "section_2": {
          "role": "key_point_2",
          "vertical_span_ratio": 0.20,
          "elements": ["icon", "headline", "explanation", "data_point"]
        },
        "section_3": {
          "role": "key_point_3",
          "vertical_span_ratio": 0.20,
          "elements": ["icon", "headline", "explanation", "data_point"]
        },
        "visualization": {
          "role": "central_data_viz",
          "vertical_span_ratio": 0.15,
          "elements": ["chart_or_diagram"]
        },
        "footer": {
          "role": "cta_and_sources",
          "vertical_span_ratio": 0.10,
          "elements": ["cta", "sources", "logo", "url"]
        }
      },
      "visual_hierarchy": [
        "Main headline",
        "Section headlines",
        "Data points/numbers",
        "Explanatory text",
        "Icons and visuals"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "word_limit": {
        "max_visible_words": 150,
        "note": "Scannable in under 60 seconds"
      },
      "text_elements": {
        "main_headline": {
          "text": "[8-10 word headline]",
          "role": "attention_grabber"
        },
        "subheadline": {
          "text": "[Value proposition]",
          "role": "context_setter"
        },
        "section_headlines": {
          "text": ["[Point 1]", "[Point 2]", "[Point 3]"],
          "role": "key_takeaways"
        },
        "data_points": {
          "values": ["[Stat 1]", "[Stat 2]", "[Stat 3]"],
          "role": "credibility_and_impact"
        }
      },
      "constraints": [
        "Each section scannable in 2 seconds",
        "No paragraph longer than 2 sentences"
      ]
    },
    
    "visual_style": {
      "design_language": ["bold", "shareable", "data-driven"],
      "background": {
        "color": "#[primary_bg]",
        "treatment": "[solid|gradient|sectioned]"
      },
      "color_palette": {
        "primary": [
          {"name": "background", "hex": "#[hex]", "usage": "main background"},
          {"name": "text", "hex": "#[hex]", "usage": "headlines and body"}
        ],
        "accent": [
          {"name": "highlight", "hex": "#[hex]", "usage": "key numbers, icons"},
          {"name": "secondary", "hex": "#[hex]", "usage": "secondary elements"}
        ],
        "contrast_notes": [
          "High contrast for mobile readability",
          "Limited palette (3-4 colors max)"
        ]
      },
      "typography": {
        "font_family_style": "bold sans-serif for headlines, clean for body",
        "examples": ["Oswald", "Montserrat", "Lato"],
        "hierarchy": {
          "main_headline": {
            "weight": "bold",
            "size_relationship": "largest, dominates header"
          },
          "section_headline": {
            "weight": "semibold",
            "size_relationship": "medium prominence"
          },
          "data_numbers": {
            "weight": "bold",
            "size_relationship": "large, attention-grabbing"
          },
          "body_text": {
            "weight": "regular",
            "size_relationship": "readable but not dominant"
          }
        }
      }
    },
    
    "iconography_and_visual_elements": {
      "section_icons": {
        "status": "required",
        "description": "Simple icons for each key point",
        "style": "flat, consistent weight, single color",
        "constraint": "All icons same style family"
      },
      "data_visualization": {
        "status": "required",
        "type": "[chart|diagram|illustration]",
        "style": "simplified, no chart junk"
      },
      "logo": {
        "status": "required",
        "placement": "footer",
        "size_relationship": "small, credibility marker"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": [
        "surprise or intrigue",
        "quick understanding",
        "share-worthy"
      ],
      "narrative_position": "[What story the data tells]",
      "copy_tone": ["punchy", "factual", "engaging"],
      "implicit_message": "[Key takeaway]"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": [
        "No more than 150 words total",
        "Headlines under 10 words"
      ],
      "visual_constraints": [
        "No clutter",
        "Clear section separation",
        "Mobile-readable text sizes",
        "No decorative elements that don't inform"
      ],
      "brand_constraints": [
        "Include source citations",
        "Brand logo required"
      ],
      "interaction_intent": "Encourage social sharing and quick comprehension"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Shareability (visual impact)",
        "Scannability",
        "Data accuracy representation",
        "Brand alignment"
      ],
      "style_keywords_for_model": [
        "social media infographic",
        "data visualization",
        "flat design",
        "bold typography",
        "vertical scroll"
      ],
      "export_notes": [
        "Optimize for mobile viewing",
        "Crisp text at all sizes"
      ]
    }
  }
}
```

---

## Diagram/Flowchart

### Work Surface Variations
- Process flowchart
- Organizational chart
- System architecture diagram
- Mind map
- Decision tree
- Network diagram

### Template: Process Flowchart

```json
{
  "image_request": {
    "title": "[Process name] flowchart",
    "purpose": "[What process this diagram explains]",
    
    "format": {
      "platform": "[documentation|presentation|print]",
      "aspect_ratio": "16:9",
      "resolution_px": [1920, 1080],
      "orientation": "landscape"
    },
    
    "brand_context": {
      "brand_name": "[Company/project]",
      "tone_of_voice": ["technical", "clear", "professional"],
      "positioning_message": "[Process purpose]",
      "consistency_notes": [
        "Use standard flowchart symbols",
        "Match documentation style guide"
      ]
    },
    
    "layout": {
      "overall_structure": "Flow diagram with clear start/end points",
      "flow_direction": "[top_to_bottom|left_to_right]",
      "zones": {
        "title_area": {
          "role": "diagram_identification",
          "position": "top-left",
          "elements": ["title", "version", "date"]
        },
        "flow_area": {
          "role": "main_diagram",
          "span_ratio": 0.85,
          "elements": ["nodes", "connectors", "labels"]
        },
        "legend": {
          "role": "symbol_key",
          "position": "bottom-right",
          "elements": ["shape_meanings"]
        }
      },
      "visual_hierarchy": [
        "Start/End nodes",
        "Decision points",
        "Process steps",
        "Connectors",
        "Labels"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "word_limit": {
        "max_visible_words": 100,
        "note": "Labels only, minimal text per node"
      },
      "text_elements": {
        "diagram_title": {
          "text": "[Process Name]",
          "role": "identification"
        },
        "node_labels": {
          "format": "action verb + object (e.g., 'Submit form')",
          "max_words_per_node": 5
        },
        "decision_labels": {
          "format": "yes/no question",
          "branch_labels": ["Yes", "No"]
        }
      },
      "constraints": [
        "All labels inside shapes",
        "Decision branches clearly labeled"
      ]
    },
    
    "visual_style": {
      "design_language": ["technical", "clean", "standardized"],
      "background": {
        "color": "#FFFFFF",
        "treatment": "solid white",
        "grid": "optional light gray alignment grid"
      },
      "color_palette": {
        "primary": [
          {"name": "background", "hex": "#FFFFFF", "usage": "page"},
          {"name": "lines", "hex": "#374151", "usage": "connectors, borders"}
        ],
        "accent": [
          {"name": "start_end", "hex": "#10B981", "usage": "start/end nodes"},
          {"name": "decision", "hex": "#F59E0B", "usage": "decision diamonds"},
          {"name": "process", "hex": "#3B82F6", "usage": "process rectangles"}
        ],
        "contrast_notes": [
          "High contrast for print",
          "Colorblind-safe palette"
        ]
      },
      "typography": {
        "font_family_style": "clean sans-serif",
        "examples": ["Arial", "Helvetica", "Roboto"],
        "hierarchy": {
          "title": {
            "weight": "bold",
            "size_relationship": "largest"
          },
          "node_labels": {
            "weight": "regular",
            "size_relationship": "consistent across all nodes"
          },
          "branch_labels": {
            "weight": "regular",
            "size_relationship": "smaller than node labels"
          }
        }
      }
    },
    
    "iconography_and_visual_elements": {
      "start_end_nodes": {
        "shape": "rounded_rectangle_or_oval",
        "fill": "#10B981",
        "text_color": "#FFFFFF"
      },
      "process_nodes": {
        "shape": "rectangle",
        "fill": "#3B82F6",
        "text_color": "#FFFFFF"
      },
      "decision_nodes": {
        "shape": "diamond",
        "fill": "#F59E0B",
        "text_color": "#1A1A1A"
      },
      "connectors": {
        "style": "solid arrows",
        "color": "#374151",
        "weight": "consistent throughout"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": [
        "clarity of process",
        "confidence in following steps"
      ],
      "narrative_position": "[Documentation context]",
      "copy_tone": ["precise", "unambiguous"],
      "implicit_message": "This process is clear and followable"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": [
        "All text horizontal",
        "Labels inside shapes, not external"
      ],
      "visual_constraints": [
        "No crossing lines without bridges",
        "Uniform node spacing",
        "Consistent node sizes per type",
        "Alignment grid maintained"
      ],
      "brand_constraints": [
        "Standard flowchart notation"
      ],
      "interaction_intent": "Enable process understanding and execution"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Process clarity",
        "Standard notation",
        "Visual consistency",
        "Print readability"
      ],
      "style_keywords_for_model": [
        "flowchart",
        "process diagram",
        "technical documentation",
        "clean lines",
        "standard symbols"
      ],
      "export_notes": [
        "Vector-quality lines",
        "Print-ready resolution"
      ]
    }
  }
}
```

---

## Viral Thumbnail

### Work Surface Variations
- YouTube video thumbnail
- Instagram Reel cover
- TikTok preview
- Podcast episode art
- Course/webinar promotion

### Template: YouTube Viral Thumbnail

```json
{
  "image_request": {
    "title": "[Video title] - Viral Thumbnail",
    "purpose": "Create a high-CTR thumbnail that drives clicks and communicates video value instantly",
    
    "format": {
      "platform": "YouTube",
      "aspect_ratio": "16:9",
      "resolution_px": [1280, 720],
      "orientation": "landscape"
    },
    
    "brand_context": {
      "brand_name": "[Channel/Creator name]",
      "tone_of_voice": ["energetic", "curiosity-inducing", "accessible"],
      "positioning_message": "[Channel value proposition]",
      "consistency_notes": [
        "Match channel visual identity",
        "Use recognizable creator face if applicable"
      ]
    },
    
    "identity_locking": {
      "status": "required",
      "reference_image": "[Image 1 - creator/subject photo]",
      "locked_features": ["facial features", "hair", "distinctive characteristics"],
      "allowed_changes": ["expression", "pose", "angle", "clothing"],
      "expression_target": "[excited|surprised|curious|confident]"
    },
    
    "layout": {
      "overall_structure": "Subject on one side, object/text on other, with connecting graphic element",
      "zones": {
        "subject_zone": {
          "role": "human_connection",
          "horizontal_span_ratio": 0.45,
          "position": "[left|right]",
          "elements": ["person_cutout", "expression"]
        },
        "object_zone": {
          "role": "topic_visualization",
          "horizontal_span_ratio": 0.35,
          "position": "[opposite of subject]",
          "elements": ["topic_object", "visual_representation"]
        },
        "text_overlay": {
          "role": "value_proposition",
          "position": "center_or_top",
          "elements": ["hook_text", "optional_subtext"]
        },
        "connector": {
          "role": "visual_flow",
          "elements": ["arrow", "line", "gesture_direction"]
        }
      },
      "visual_hierarchy": [
        "Human face/expression (first eye contact)",
        "Bold text hook",
        "Topic object/visual",
        "Connecting graphic",
        "Background"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "word_limit": {
        "max_visible_words": 6,
        "note": "3-5 words is optimal for thumbnails"
      },
      "text_elements": {
        "hook_text": {
          "text": "[3-5 word hook]",
          "role": "scroll_stopper",
          "examples": ["DON'T DO THIS!", "I Was WRONG", "The SECRET Is..."]
        },
        "subtext": {
          "text": "[optional 1-2 words]",
          "role": "context_add",
          "status": "optional"
        }
      },
      "constraints": [
        "Text must be readable at thumbnail size (120px height)",
        "No more than 2 text elements"
      ]
    },
    
    "visual_style": {
      "design_language": ["high-contrast", "pop-style", "attention-grabbing"],
      "background": {
        "color": "[bright solid or gradient]",
        "treatment": "blurred environment OR solid color",
        "saturation": "high"
      },
      "color_palette": {
        "primary": [
          {"name": "background", "hex": "#[bright hex]", "usage": "background"},
          {"name": "text", "hex": "#FFFFFF", "usage": "main text"}
        ],
        "accent": [
          {"name": "text_outline", "hex": "#000000", "usage": "text stroke"},
          {"name": "highlight", "hex": "#FFFF00", "usage": "arrows, emphasis"}
        ],
        "contrast_notes": [
          "Maximum contrast between text and background",
          "Text visible even at 100px width"
        ]
      },
      "typography": {
        "font_family_style": "bold impact sans-serif",
        "examples": ["Impact", "Anton", "Bebas Neue", "Oswald Black"],
        "hierarchy": {
          "hook_text": {
            "weight": "black/bold",
            "color": "#FFFFFF",
            "stroke": "thick black outline (3-5px)",
            "shadow": "drop shadow for depth",
            "size_relationship": "dominant, ~20% of image height"
          }
        }
      }
    },
    
    "iconography_and_visual_elements": {
      "subject_treatment": {
        "status": "required",
        "description": "Person cutout with slight glow/outline",
        "expression": "[exaggerated for thumbnail visibility]",
        "pose": "pointing, gesturing, or reacting",
        "constraint": "Must maintain identity from reference image"
      },
      "connector_arrow": {
        "status": "recommended",
        "description": "Bold arrow or graphic connecting subject to object",
        "color": "#FFFF00 or brand accent",
        "style": "thick, hand-drawn feel or clean geometric"
      },
      "topic_object": {
        "status": "required",
        "description": "[Object representing video topic]",
        "style": "high quality, clear, recognizable at small size"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": [
        "immediate curiosity",
        "FOMO (fear of missing out)",
        "promise of value"
      ],
      "narrative_position": "Pre-click hook - promise without spoiling",
      "copy_tone": ["urgent", "exciting", "accessible"],
      "implicit_message": "You NEED to click this to find out"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": [
        "Maximum 6 words total",
        "All caps for hook text",
        "No small text that disappears at thumbnail size"
      ],
      "visual_constraints": [
        "No clutter - 3 elements max",
        "No text in corners (platform UI overlap)",
        "No low-contrast combinations",
        "No generic stock photo expressions"
      ],
      "brand_constraints": [
        "Creator face must be recognizable",
        "Match channel's established thumbnail style"
      ],
      "interaction_intent": "Maximize click-through rate"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Face visibility and expression",
        "Text legibility at 100px width",
        "Color contrast and saturation",
        "Topic clarity"
      ],
      "style_keywords_for_model": [
        "YouTube thumbnail",
        "viral",
        "high contrast",
        "pop style",
        "attention grabbing",
        "MrBeast style",
        "bold text overlay"
      ],
      "export_notes": [
        "Test at 120x68px (search result size)",
        "Verify text readability when scaled down"
      ]
    }
  }
}
```

---

## Sprite Sheet

### Work Surface Variations
- Character animation cycle (walk, run, idle)
- Effect animation (explosion, sparkle, smoke)
- UI element states
- Game asset sheet
- Emoji/sticker variations

### Template: Animation Sprite Sheet

```json
{
  "image_request": {
    "title": "[Character/Object] [Action] Sprite Sheet",
    "purpose": "Create a frame-by-frame animation sequence for game/motion use",
    
    "format": {
      "platform": "game_asset",
      "aspect_ratio": "1:1",
      "resolution_px": [1024, 1024],
      "orientation": "square",
      "grid_structure": "[3x3|4x4|2x4|8x1]"
    },
    
    "brand_context": {
      "brand_name": "[Game/Project name]",
      "tone_of_voice": ["[art style tone]"],
      "positioning_message": "[Game genre/aesthetic]",
      "consistency_notes": [
        "Character must remain identical across all frames",
        "Proportions locked throughout animation",
        "Color palette consistent"
      ]
    },
    
    "layout": {
      "overall_structure": "Grid of equal cells, each containing one animation frame",
      "grid_specification": {
        "columns": "[number]",
        "rows": "[number]",
        "cell_size": "equal",
        "gutter": "none or minimal (2px)",
        "frame_order": "left-to-right, top-to-bottom"
      },
      "zones": {
        "each_cell": {
          "role": "single_animation_frame",
          "content": "character in specific pose",
          "background": "transparent or solid color"
        }
      },
      "visual_hierarchy": [
        "Character silhouette clarity",
        "Motion arc visibility",
        "Detail consistency"
      ]
    },
    
    "content": {
      "language": "N/A",
      "animation_specification": {
        "action": "[walk cycle|run cycle|attack|jump|idle|death|etc]",
        "frame_count": "[number of frames]",
        "frame_sequence": [
          "Frame 1: [pose description]",
          "Frame 2: [pose description]",
          "Frame 3: [pose description]"
        ],
        "loop_type": "[seamless_loop|one_shot|ping_pong]"
      },
      "constraints": [
        "Character centered in each cell",
        "Consistent ground line across frames"
      ]
    },
    
    "visual_style": {
      "design_language": ["[pixel_art|vector|hand_drawn|3D_render]", "[art style]"],
      "background": {
        "color": "#00FF00",
        "treatment": "solid color for easy removal (green screen)",
        "alternative": "transparent (if supported)"
      },
      "color_palette": {
        "primary": [
          {"name": "background", "hex": "#00FF00", "usage": "chroma key background"},
          {"name": "character_main", "hex": "#[hex]", "usage": "primary character color"}
        ],
        "accent": [
          {"name": "highlight", "hex": "#[hex]", "usage": "character highlights"},
          {"name": "shadow", "hex": "#[hex]", "usage": "character shadows"}
        ],
        "contrast_notes": [
          "Character colors must NOT include background green",
          "High contrast for sprite visibility"
        ]
      },
      "typography": "N/A"
    },
    
    "iconography_and_visual_elements": {
      "character": {
        "status": "required",
        "description": "[Full character description]",
        "proportions": "[pixel height, head-to-body ratio]",
        "constraint": "MUST remain identical in all frames - same colors, same details, same scale"
      },
      "motion_elements": {
        "status": "optional",
        "description": "Motion blur, dust clouds, energy effects",
        "style": "[style matching character]"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": [
        "clear readable motion",
        "character personality through movement"
      ],
      "narrative_position": "Gameplay animation asset",
      "copy_tone": ["N/A"],
      "implicit_message": "Smooth, professional animation quality"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": ["No text in sprite sheet"],
      "visual_constraints": [
        "No variation in character design between frames",
        "No scale changes (unless part of animation)",
        "Consistent lighting direction",
        "Clean edges for easy extraction",
        "No frame bleeding into adjacent cells"
      ],
      "brand_constraints": [
        "Match game's established art style"
      ],
      "interaction_intent": "Enable smooth in-game animation"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Character consistency",
        "Motion clarity",
        "Clean cell boundaries",
        "Easy background removal"
      ],
      "style_keywords_for_model": [
        "sprite sheet",
        "animation frames",
        "game asset",
        "[art style]",
        "frame by frame",
        "character animation"
      ],
      "export_notes": [
        "PNG with transparency preferred",
        "Each cell must be extractable",
        "Test animation by flipping through frames"
      ]
    }
  }
}
```

---

## Storyboard Commercial

### Work Surface Variations
- TV commercial storyboard
- Social media ad sequence
- Product launch video concept
- Brand film pitch
- Explainer video frames

### Template: 9-Part Commercial Storyboard

```json
{
  "image_request": {
    "title": "[Brand/Product] Commercial Storyboard",
    "purpose": "Visualize a complete commercial narrative for pitch/pre-production",
    
    "format": {
      "platform": "presentation",
      "aspect_ratio": "16:9",
      "resolution_px": [1920, 1080],
      "orientation": "landscape",
      "frame_count": 9,
      "series_role": "complete_narrative_arc"
    },
    
    "brand_context": {
      "brand_name": "[Brand]",
      "tone_of_voice": ["[brand tone 1]", "[brand tone 2]", "aspirational"],
      "positioning_message": "[Brand promise/tagline]",
      "consistency_notes": [
        "Character identity MUST remain consistent across all 9 frames",
        "Attire remains the same throughout",
        "Product appearance consistent",
        "Lighting style cohesive across sequence"
      ]
    },
    
    "identity_locking": {
      "status": "required",
      "characters": [
        {
          "role": "[protagonist|supporting]",
          "description": "[character description]",
          "locked_features": ["face", "body type", "attire", "distinctive features"],
          "allowed_changes": ["expression", "pose", "angle", "distance from camera"]
        }
      ],
      "product": {
        "description": "[product description]",
        "locked_features": ["design", "color", "proportions"],
        "placement": "Prominent in frames [X, Y, Z]"
      }
    },
    
    "layout": {
      "overall_structure": "3x3 grid of frames OR 9 sequential panels",
      "narrative_arc": {
        "frames_1_3": "Setup - establish characters, context, initial situation",
        "frames_4_6": "Development - conflict, discovery, product interaction",
        "frames_7_9": "Resolution - transformation, satisfaction, brand moment"
      },
      "zones": {
        "frame_1": {
          "role": "opening_hook",
          "shot_type": "[establishing|close_up|action]",
          "description": "[scene description]"
        },
        "frame_9": {
          "role": "brand_close",
          "shot_type": "product_hero_or_logo",
          "description": "[final frame description with brand/product prominence]"
        }
      },
      "visual_hierarchy": [
        "Character emotion/action",
        "Product visibility",
        "Environment context",
        "Brand elements"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "frame_descriptions": [
        {"frame": 1, "action": "[description]", "dialogue_hint": "[optional]"},
        {"frame": 2, "action": "[description]", "dialogue_hint": "[optional]"},
        {"frame": 3, "action": "[description]", "dialogue_hint": "[optional]"},
        {"frame": 4, "action": "[description]", "dialogue_hint": "[optional]"},
        {"frame": 5, "action": "[description]", "dialogue_hint": "[optional]"},
        {"frame": 6, "action": "[description]", "dialogue_hint": "[optional]"},
        {"frame": 7, "action": "[description]", "dialogue_hint": "[optional]"},
        {"frame": 8, "action": "[description]", "dialogue_hint": "[optional]"},
        {"frame": 9, "action": "[description]", "dialogue_hint": "[optional]"}
      ],
      "constraints": [
        "Each frame must advance the narrative",
        "Emotional journey: [starting emotion] → [ending emotion]"
      ]
    },
    
    "visual_style": {
      "design_language": ["cinematic", "aspirational", "[brand aesthetic]"],
      "background": {
        "environment": "[location/setting]",
        "lighting_mood": "[warm|cool|dramatic|natural]",
        "time_of_day": "[if relevant]"
      },
      "color_palette": {
        "primary": [
          {"name": "environment_base", "hex": "#[hex]", "usage": "backgrounds"},
          {"name": "skin_tone", "hex": "#[hex]", "usage": "character consistency"}
        ],
        "accent": [
          {"name": "product_color", "hex": "#[hex]", "usage": "product emphasis"},
          {"name": "brand_color", "hex": "#[hex]", "usage": "brand moments"}
        ],
        "contrast_notes": [
          "Product should stand out in every frame where it appears"
        ]
      },
      "cinematography": {
        "shot_variety": ["wide", "medium", "close-up", "detail"],
        "camera_movement_implied": "[static|tracking|zoom]",
        "depth_of_field": "[shallow for focus|deep for context]"
      }
    },
    
    "iconography_and_visual_elements": {
      "protagonist": {
        "status": "required",
        "description": "[full description]",
        "constraint": "Face and attire IDENTICAL in all frames"
      },
      "product": {
        "status": "required",
        "description": "[product description]",
        "hero_frames": "[frame numbers where product is featured]"
      },
      "logo": {
        "status": "required",
        "placement": "Frame 9 - prominent brand close",
        "style": "[logo treatment]"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": [
        "[opening emotion]",
        "[journey emotion]",
        "[closing emotion]"
      ],
      "narrative_position": "Complete story arc: beginning, middle, end",
      "copy_tone": ["[brand voice]"],
      "implicit_message": "[What viewer should feel about brand after viewing]"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": [
        "No on-screen text except final logo/tagline",
        "Story told visually"
      ],
      "visual_constraints": [
        "No jarring style shifts between frames",
        "Character consistency non-negotiable",
        "Product always shown positively",
        "No competitor references"
      ],
      "brand_constraints": [
        "Align with brand guidelines",
        "Final frame must include brand elements"
      ],
      "interaction_intent": "Pitch-ready visualization that sells the concept"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Character identity consistency",
        "Narrative clarity",
        "Emotional journey",
        "Product visibility",
        "Cinematic quality"
      ],
      "style_keywords_for_model": [
        "commercial storyboard",
        "cinematic",
        "advertising",
        "[brand style]",
        "sequential narrative",
        "professional production"
      ],
      "export_notes": [
        "Generate one frame at a time for quality control",
        "Verify character consistency before proceeding"
      ]
    }
  }
}
```

---

## Technical Blueprint

### Work Surface Variations
- Architectural blueprint (plan, elevation, section)
- Engineering diagram
- Product schematic
- Assembly instructions
- Technical documentation illustration

### Template: Architectural Blueprint

```json
{
  "image_request": {
    "title": "[Building/Space Name] Technical Blueprint",
    "purpose": "Create professional architectural documentation with multiple views",
    
    "format": {
      "platform": "technical_documentation",
      "aspect_ratio": "16:9",
      "resolution_px": [2400, 1350],
      "orientation": "landscape"
    },
    
    "brand_context": {
      "brand_name": "[Architecture firm/Project name]",
      "tone_of_voice": ["technical", "precise", "professional"],
      "positioning_message": "[Project description]",
      "consistency_notes": [
        "Standard architectural notation",
        "Consistent line weights throughout",
        "Scale indicators accurate"
      ]
    },
    
    "layout": {
      "overall_structure": "Multi-view technical drawing with title block",
      "zones": {
        "title_block": {
          "role": "identification",
          "position": "bottom-right",
          "vertical_span_ratio": 0.12,
          "elements": ["project_name", "drawing_title", "scale", "date", "revision"]
        },
        "plan_view": {
          "role": "floor_plan",
          "position": "left",
          "horizontal_span_ratio": 0.45,
          "view_type": "top-down orthographic"
        },
        "elevation_view": {
          "role": "front_elevation",
          "position": "top-right",
          "horizontal_span_ratio": 0.50,
          "view_type": "front orthographic"
        },
        "section_view": {
          "role": "cross_section",
          "position": "bottom-center",
          "view_type": "sectional cut"
        }
      },
      "visual_hierarchy": [
        "Primary view (plan)",
        "Supporting views (elevation, section)",
        "Labels and dimensions",
        "Title block"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "word_limit": {
        "max_visible_words": 50,
        "note": "Labels and technical annotations only"
      },
      "text_elements": {
        "drawing_title": {
          "text": "[Drawing Title]",
          "position": "title_block"
        },
        "view_labels": {
          "plan": "FLOOR PLAN",
          "elevation": "[NORTH|SOUTH|EAST|WEST] ELEVATION",
          "section": "SECTION A-A"
        },
        "room_labels": {
          "format": "Room name + area (optional)",
          "examples": ["Living Room", "Kitchen 15m²", "Master Bedroom"]
        },
        "dimensions": {
          "format": "metric or imperial with unit markers",
          "style": "standard architectural dimension lines"
        }
      },
      "constraints": [
        "All text horizontal or aligned with drawing conventions",
        "Dimensions clearly readable",
        "Room labels centered in spaces"
      ]
    },
    
    "visual_style": {
      "design_language": ["technical", "precise", "architectural standard"],
      "background": {
        "color": "#FFFFFF",
        "treatment": "clean white (blueprint) OR traditional blue (#1E3A5F for cyanotype style)"
      },
      "color_palette": {
        "traditional_blueprint": [
          {"name": "background", "hex": "#1E3A5F", "usage": "background"},
          {"name": "lines", "hex": "#FFFFFF", "usage": "all linework"}
        ],
        "modern_technical": [
          {"name": "background", "hex": "#FFFFFF", "usage": "background"},
          {"name": "structure", "hex": "#000000", "usage": "walls, structure"},
          {"name": "dimensions", "hex": "#1E3A5F", "usage": "dimension lines"},
          {"name": "section_cut", "hex": "#CC0000", "usage": "section cut indicators"}
        ],
        "contrast_notes": [
          "Line weights must differentiate: walls (thick) vs. details (thin)",
          "Dimensions subordinate to geometry"
        ]
      },
      "typography": {
        "font_family_style": "technical architectural",
        "examples": ["Tekton Pro", "Architect's Daughter", "ISOCPEUR", "Arial Narrow"],
        "hierarchy": {
          "drawing_title": {
            "weight": "bold",
            "case": "uppercase",
            "size_relationship": "largest in title block"
          },
          "view_labels": {
            "weight": "bold",
            "case": "uppercase",
            "size_relationship": "prominent above each view"
          },
          "room_labels": {
            "weight": "regular",
            "case": "title_case",
            "size_relationship": "medium"
          },
          "dimensions": {
            "weight": "regular",
            "size_relationship": "small, readable"
          }
        }
      }
    },
    
    "iconography_and_visual_elements": {
      "north_arrow": {
        "status": "required",
        "placement": "top-left or near plan view",
        "style": "standard architectural symbol"
      },
      "scale_bar": {
        "status": "required",
        "placement": "below plan view",
        "format": "[graphic scale + ratio e.g., 1:100]"
      },
      "section_markers": {
        "status": "if_section_shown",
        "style": "circle with letter + arrow indicating view direction"
      },
      "door_windows": {
        "status": "required",
        "style": "standard architectural symbols",
        "constraint": "Consistent symbol usage throughout"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": [
        "professional credibility",
        "technical precision",
        "clear communication"
      ],
      "narrative_position": "Technical documentation for construction/approval",
      "copy_tone": ["precise", "standard", "unambiguous"],
      "implicit_message": "This is professionally documented and buildable"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": [
        "Technical annotations only",
        "No marketing language",
        "Standard architectural abbreviations"
      ],
      "visual_constraints": [
        "No perspective views (orthographic only)",
        "No artistic rendering (technical line drawing)",
        "Consistent scale across all views",
        "No decorative elements",
        "Line weights must follow convention"
      ],
      "brand_constraints": [
        "Standard architectural notation",
        "Industry-standard symbols"
      ],
      "interaction_intent": "Enable accurate construction understanding"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Technical accuracy",
        "Clarity of views",
        "Label legibility",
        "Standard compliance"
      ],
      "style_keywords_for_model": [
        "architectural blueprint",
        "technical drawing",
        "orthographic projection",
        "floor plan",
        "elevation",
        "section",
        "CAD style",
        "construction documents"
      ],
      "export_notes": [
        "High resolution for print",
        "Vector-quality lines if possible"
      ]
    }
  }
}
```

---

## Interior Design Board

### Work Surface Variations
- Mood board / concept board
- Client presentation board
- Material palette board
- Room visualization collage
- Furniture layout with perspectives

### Template: Interior Design Presentation Board

```json
{
  "image_request": {
    "title": "[Room/Space] Interior Design Board",
    "purpose": "Present a complete interior design concept with multiple views and material details",
    
    "format": {
      "platform": "presentation",
      "aspect_ratio": "3:4",
      "resolution_px": [2400, 3200],
      "orientation": "portrait"
    },
    
    "brand_context": {
      "brand_name": "[Design firm/Designer name]",
      "tone_of_voice": ["aspirational", "professional", "refined"],
      "positioning_message": "[Design concept statement]",
      "consistency_notes": [
        "Color palette consistent across all elements",
        "Material finishes match between views",
        "Style cohesive throughout"
      ]
    },
    
    "source_input": {
      "status": "[required if 2D to 3D]",
      "type": "2D floor plan",
      "description": "[Upload floor plan to translate to 3D views]"
    },
    
    "layout": {
      "overall_structure": "Collage with hero image + supporting views + material swatches",
      "zones": {
        "hero_image": {
          "role": "primary_room_view",
          "position": "top",
          "vertical_span_ratio": 0.45,
          "view_type": "wide-angle perspective of main space",
          "rendering": "photorealistic"
        },
        "secondary_views": {
          "role": "supporting_perspectives",
          "position": "middle",
          "vertical_span_ratio": 0.25,
          "layout": "3 smaller images side by side",
          "content": ["different angle", "detail shot", "3D floor plan OR another room"]
        },
        "material_palette": {
          "role": "finish_specification",
          "position": "bottom-left",
          "vertical_span_ratio": 0.20,
          "elements": ["flooring sample", "wall color", "fabric swatch", "metal finish"]
        },
        "text_area": {
          "role": "project_info",
          "position": "bottom-right",
          "elements": ["room name", "style name", "designer/firm logo"]
        }
      },
      "visual_hierarchy": [
        "Hero room render",
        "Secondary views",
        "Material swatches",
        "Project information"
      ]
    },
    
    "content": {
      "language": "[Language]",
      "word_limit": {
        "max_visible_words": 20,
        "note": "Labels and title only - visuals speak"
      },
      "text_elements": {
        "project_title": {
          "text": "[Space Name] | [Style Name]",
          "role": "identification"
        },
        "material_labels": {
          "format": "material name + finish",
          "examples": ["Warm Oak | Matte", "Bouclé | Ivory", "Brushed Brass"]
        }
      },
      "constraints": [
        "Minimal text - design speaks for itself",
        "Material labels small and elegant"
      ]
    },
    
    "visual_style": {
      "design_language": ["[design style]", "photorealistic", "editorial"],
      "interior_style": "[Modern Minimalist|Scandinavian|Mid-Century|Industrial|Japandi|etc]",
      "background": {
        "color": "#F5F5F0",
        "treatment": "subtle off-white or warm gray frame"
      },
      "color_palette": {
        "room_palette": [
          {"name": "[primary]", "hex": "#[hex]", "usage": "walls/dominant"},
          {"name": "[secondary]", "hex": "#[hex]", "usage": "furniture/accents"},
          {"name": "[accent]", "hex": "#[hex]", "usage": "details/accessories"}
        ],
        "materials": [
          {"name": "[flooring]", "description": "[wood type, tile, etc]"},
          {"name": "[textiles]", "description": "[fabric types]"},
          {"name": "[metals]", "description": "[finish types]"}
        ],
        "contrast_notes": [
          "Materials shown must match what's rendered in room views"
        ]
      },
      "lighting": {
        "type": "soft natural + designed artificial",
        "mood": "[warm|cool|neutral]",
        "time_of_day": "[afternoon golden hour|overcast soft|evening ambient]"
      },
      "typography": {
        "font_family_style": "elegant sans-serif or refined serif",
        "examples": ["Playfair Display", "Cormorant", "Montserrat Light"],
        "hierarchy": {
          "project_title": {
            "weight": "light or regular",
            "style": "elegant spacing",
            "size_relationship": "subtle prominence"
          },
          "material_labels": {
            "weight": "regular",
            "size_relationship": "small, refined"
          }
        }
      }
    },
    
    "iconography_and_visual_elements": {
      "hero_render": {
        "status": "required",
        "description": "Photorealistic render of main living space",
        "viewpoint": "eye-level perspective from entry or key angle",
        "quality": "architectural visualization quality",
        "constraint": "Must show key furniture and design elements"
      },
      "material_swatches": {
        "status": "required",
        "presentation": "clean squares or circles with subtle shadows",
        "size": "consistent across all swatches"
      },
      "logo": {
        "status": "optional",
        "placement": "bottom-right, subtle",
        "size_relationship": "small, professional"
      }
    },
    
    "tone_and_message_intent": {
      "emotional_goal": [
        "aspiration to live in this space",
        "confidence in design expertise",
        "excitement about transformation"
      ],
      "narrative_position": "Client presentation / portfolio piece",
      "copy_tone": ["refined", "confident", "minimal"],
      "implicit_message": "This is the beautiful, livable space we will create for you"
    },
    
    "constraints_and_avoidances": {
      "text_constraints": [
        "No lengthy descriptions",
        "Visuals tell the story"
      ],
      "visual_constraints": [
        "No cluttered compositions",
        "Materials in swatches must match renders exactly",
        "No stock photography feel - custom, designed aesthetic",
        "Consistent style across all views"
      ],
      "brand_constraints": [
        "Match designer's portfolio aesthetic",
        "Professional presentation quality"
      ],
      "interaction_intent": "Win client approval / showcase portfolio piece"
    },
    
    "rendering_guidance": {
      "priority_order": [
        "Hero image quality",
        "Material accuracy",
        "Style consistency",
        "Professional presentation"
      ],
      "style_keywords_for_model": [
        "interior design board",
        "photorealistic render",
        "[interior style]",
        "architectural visualization",
        "mood board",
        "client presentation",
        "design collage"
      ],
      "export_notes": [
        "High resolution for print and screen",
        "Color accuracy critical for material matching"
      ]
    }
  }
}
```

---

## Quick Reference: JSON Field Checklist

When building any prompt, ensure these critical fields are populated:

**Required fields:**
- [ ] `image_request.title` - Clear, descriptive
- [ ] `image_request.purpose` - What it accomplishes
- [ ] `format.resolution_px` - Exact pixel dimensions
- [ ] `format.aspect_ratio` - Ratio as string
- [ ] `layout.zones` - At least one zone defined
- [ ] `visual_style.color_palette.primary` - At least background and text colors
- [ ] `constraints_and_avoidances.visual_constraints` - At least 2-3 constraints

**High-impact fields:**
- [ ] `layout.visual_hierarchy` - Ordered prominence list
- [ ] `typography.hierarchy` - Size/weight relationships
- [ ] `constraints_and_avoidances` - Negative constraints (what NOT to do)
- [ ] `rendering_guidance.style_keywords_for_model` - Direct model guidance

**Consistency fields (for series):**
- [ ] `brand_context.consistency_notes`
- [ ] `format.series_role`
- [ ] `iconography_and_visual_elements.[character/element].constraint`
