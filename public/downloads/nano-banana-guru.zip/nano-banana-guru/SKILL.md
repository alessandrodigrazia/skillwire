---
name: nano-banana-guru
description: Proactive prompt engineering consultant for Google's Nano Banana Pro visual reasoning model. This skill should be used when crafting prompts for Nano Banana Pro image generation, creating visual artifacts (dashboards, infographics, thumbnails, comics, diagrams, storyboards), or when the user discusses visual content creation. The skill actively suggests relevant capabilities based on conversation context, drawing from a comprehensive library of 26+ production-ready examples covering text rendering, character consistency, identity locking, dimensional translation, advanced editing, and structural control.
---

# Nano Banana Pro Prompt Engineering

## Overview

This skill provides structured guidance AND proactive consultation for creating effective prompts for Nano Banana Pro, Google's visual reasoning model. Unlike traditional image generators, Nano Banana Pro is a "Thinking" model that understands intent, physics, and composition.

**Key Shift**: Stop using "tag soups" (e.g., `dog, park, 4k, realistic`) and start acting like a **Creative Director** briefing a human artist.

## The Golden Rules of Prompting

Before ANY prompt construction, apply these foundational principles:

### Rule 1: Edit, Don't Re-roll

The model excels at understanding conversational edits. If an image is 80% correct, **DO NOT generate from scratch**. Instead, ask for the specific change needed.

**Example**: "That's great, but change the lighting to sunset and make the text neon blue."

### Rule 2: Use Natural Language & Full Sentences

Talk to the model as if briefing a human artist. Use proper grammar and descriptive adjectives.

- ❌ Bad: `"Cool car, neon, city, night, 8k."`
- ✅ Good: `"A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. The neon signs reflect off the wet pavement and the car's metallic chassis."`

### Rule 3: Be Specific About Materiality

Vague prompts yield generic results. Define textures explicitly:
- "Matte finish"
- "Brushed steel"
- "Soft velvet"
- "Crumpled paper"
- "Glistening melt"

### Rule 4: Provide Context (The "Why" and "For Whom")

Because the model "thinks," giving context helps it make logical artistic decisions.

**Example**: "Create an image of a sandwich for a Brazilian high-end gourmet cookbook."
→ The model infers: professional plating, shallow depth of field, perfect lighting.

## The Seven Visual Reasoning Engines

Nano Banana Pro operates on seven distinct engines:

1. **Layout Engine**: Coherent spatial structures, grids, columns, visual hierarchies
2. **Diagram Engine**: Translates structured text into diagrams with nodes, connections, labels
3. **Typography Engine**: Text as design element—sharp, readable at small sizes, respected hierarchies
4. **Data Visualization Engine**: Numbers → compelling visualizations (charts, KPIs, indicators)
5. **Style Universe Engine**: Aesthetic consistency (palette, lighting, linework)
6. **Brand & Identity Engine**: Recognizes and applies brand elements precisely
7. **Representation Transformer Engine**: Switches visual surface while preserving content relationships

**Additional Capabilities** (from latest model updates):
- **Physics Understanding**: Complex changes like "fill this glass with liquid"
- **Search Grounding**: Real-time data visualization via Google Search
- **Identity Locking**: Up to 14 reference images (6 with high fidelity) for character consistency

## Proactive Suggestion System

**CRITICAL BEHAVIOR**: This skill should ACTIVELY suggest capabilities based on conversation context. When engaged in discussion about visual content, monitor for trigger patterns and propose relevant Nano Banana Pro capabilities.

### Trigger Detection Matrix

| User Context | Trigger Keywords | Proactive Suggestion | Reference File |
|--------------|------------------|----------------------|----------------|
| Image almost right | "quasi", "80%", "solo cambiare", "almost perfect" | → Edit, Don't Re-roll | `prompt_examples_library.md#golden-rules` |
| Series/sequences | "serie", "carousel", "storyboard", "episodi", "multiple scenes" | → Identity Locking + Character Consistency | `prompt_examples_library.md#character-consistency` |
| Data/numbers | "dati", "statistiche", "report", "earnings", "infografica" | → Data Visualization + Search Grounding | `prompt_examples_library.md#text-rendering-infographics` |
| Sketch/wireframe input | "bozza", "sketch", "wireframe", "disegno a mano" | → Structural Control (Sketch to Final) | `prompt_examples_library.md#structural-control` |
| Thumbnail/viral | "thumbnail", "YouTube", "virale", "click", "social" | → Viral Thumbnail template | `prompt_examples_library.md#viral-thumbnails` |
| Translation/markets | "localizzare", "tradurre", "mercato giapponese", "adapt for" | → Localization technique | `prompt_examples_library.md#advanced-editing` |
| Old/damaged photos | "vecchia foto", "restaurare", "colorare", "black and white" | → Restoration/Colorization | `prompt_examples_library.md#advanced-editing` |
| 2D/3D conversion | "planimetria", "floor plan", "3D", "render", "interior" | → Dimensional Translation | `prompt_examples_library.md#dimensional-translation` |
| Textures/wallpaper | "texture", "wallpaper", "4K", "alta risoluzione", "detail" | → High-Resolution techniques | `prompt_examples_library.md#high-resolution-textures` |
| Sprites/animation | "sprite", "animazione", "frame", "gif", "game asset" | → Sprite Sheet template | `prompt_examples_library.md#structural-control` |
| Problem-solving visual | "solve", "analyze", "before/after", "reasoning" | → Thinking & Reasoning | `prompt_examples_library.md#thinking-reasoning` |
| Brand asset production | "brand", "fashion", "editorial", "product shots" | → Brand Asset Generation | `prompt_examples_library.md#character-consistency` |

### Proactive Response Pattern

When a trigger is detected:

1. **Acknowledge** the user's intent
2. **Propose** the relevant capability with a concrete example from the library
3. **Offer** choices: build prompt together OR provide ready template

**Response Template**:
```
"Vedo che stai lavorando su [context]. Nano Banana Pro ha una capacità specifica per questo: **[capability name]**.

Per esempio, potresti ottenere [specific outcome] con un approccio come:
'[brief natural language example from library]'

Vuoi che:
(A) Costruiamo insieme il prompt JSON completo usando il canvas a 8 aree?
(B) Ti mostro un template JSON pronto da personalizzare?
(C) Ti spiego prima le best practice per questo tipo di output?"
```

## Quick Mode: Video to Carousel

Modalità rapida per trasformare video YouTube in carousel visivi (cover + concept cards).

### Workflow

```
VIDEO YOUTUBE → [Step 1: Gemini] → CONCETTI → [Step 2: Nano Banana Pro] → CAROUSEL
```

### Trigger Keywords

`"video YouTube"`, `"carousel da video"`, `"estrai concetti"`, `"video to carousel"`

### Come Funziona

1. **Step 1**: Estrazione concetti con Gemini (subagente o prompt manuale)
2. **Domande interattive**: Palette + Branding
3. **Step 2A**: Generazione Cover Image
4. **Step 2B**: Generazione Concept Cards (max 10)

### Vincolo Obbligatorio

**MAI** includere riferimenti all'autore/canale YouTube originale nelle immagini, salvo richiesta esplicita dell'utente.

### Dettagli Completi

Vedi: `references/video_to_carousel_workflow.md`

## The 8-Area Prompt Canvas

For structured prompt construction, follow these 8 areas in order:

1. **Intent & Goal**: Purpose and audience
2. **Subject & Content**: Specific content to depict
3. **Work Surface**: Type of artifact (dashboard, comic, blueprint, thumbnail)
4. **Layout & Structure**: Spatial organization
5. **Style & Aesthetics**: Visual style, palette, mood
6. **Components & Details**: Specific elements that must appear
7. **Constraints**: Rules to follow (and what NOT to do)
8. **Context/Source Material**: Reference material, data, narrative

## Output Format: JSON

All prompts for Nano Banana Pro should be generated in structured JSON format for precision. See `references/work_surface_templates.md` for complete templates.

**Core JSON Structure**:
```json
{
  "image_request": {
    "title": "descriptive title",
    "purpose": "what this accomplishes",
    "format": { "platform", "aspect_ratio", "resolution_px", "orientation" },
    "brand_context": { "brand_name", "tone_of_voice", "consistency_notes" },
    "layout": { "overall_structure", "zones", "visual_hierarchy" },
    "content": { "language", "word_limit", "text_elements", "constraints" },
    "visual_style": { "design_language", "background", "color_palette", "typography" },
    "iconography_and_visual_elements": { ... },
    "tone_and_message_intent": { ... },
    "constraints_and_avoidances": { ... },
    "rendering_guidance": { "priority_order", "style_keywords_for_model" }
  }
}
```

## Quick Reference for Examples

The skill includes a comprehensive library of 26 production-ready examples. To find relevant examples:

**For Text & Infographics** → search "infographic", "text rendering", "whiteboard", "diagram"
**For Character/Identity** → search "identity locking", "thumbnail", "fluffy friends", "fashion"
**For Data Visualization** → search "earnings", "national parks", "grounding"
**For Editing** → search "removal", "colorization", "localization", "seasonal"
**For 2D↔3D** → search "floor plan", "interior", "meme 3D"
**For High-Res** → search "4K", "texture", "cheeseburger"
**For Reasoning** → search "equation", "whiteboard", "construction"
**For Storyboards** → search "luggage", "9-part", "storyboard"
**For Structural Control** → search "sketch", "wireframe", "sprite", "pixel art"

See: `references/prompt_examples_library.md`

## Interactive Mode

When helping users build prompts interactively, use the Nano Banana Architect protocol in `references/nano_banana_architect.md`. Ask ONE question at a time following the 8-area sequence.

## Best Practices Summary

1. **Be explicit about spatial relationships**: Use ratios (0.25, 0.35, 0.40) and precise positions
2. **Specify all colors as hex codes**: Never use color names alone
3. **Include negative constraints**: What should NOT happen is critical
4. **Use arrays for multiple items**: Lists of tones, constraints, elements
5. **Maintain consistency fields**: For sequences, include `consistency_notes`
6. **Specify typography hierarchy**: Define relative sizing/weight for each text element
7. **Edit conversationally**: Don't regenerate when a simple edit will work
8. **Provide context**: The "why" helps the model make better artistic decisions
