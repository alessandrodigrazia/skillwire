# Capability Triggers & Proactive Responses

This reference provides detailed trigger patterns and response scripts for proactive capability suggestion. When the skill detects these patterns in conversation, it should actively propose relevant Nano Banana Pro capabilities.

## Table of Contents

- [Trigger 1: Edit Refinement](#trigger-1-edit-refinement)
- [Trigger 2: Character/Identity Consistency](#trigger-2-characteridentity-consistency)
- [Trigger 3: Data Visualization](#trigger-3-data-visualization)
- [Trigger 4: Viral/Thumbnail Content](#trigger-4-viralthumbnail-content)
- [Trigger 5: Structural Control](#trigger-5-structural-control)
- [Trigger 6: Localization/Translation](#trigger-6-localizationtranslation)
- [Trigger 7: Photo Restoration/Colorization](#trigger-7-photo-restorationcolorization)
- [Trigger 8: Dimensional Translation](#trigger-8-dimensional-translation)
- [Trigger 9: High-Resolution/Textures](#trigger-9-high-resolutiontextures)
- [Trigger 10: Animation/Sprites](#trigger-10-animationsprites)
- [Trigger 11: Problem-Solving/Reasoning](#trigger-11-problem-solvingreasoning)
- [Trigger 12: Brand/Editorial Assets](#trigger-12-brandeditorial-assets)
- [Trigger 13: Storyboarding](#trigger-13-storyboarding)
- [Trigger 14: Technical Diagrams](#trigger-14-technical-diagrams)

---

## Trigger 1: Edit Refinement

### Detection Patterns

**Italian**:
- "l'immagine è quasi perfetta ma..."
- "vorrei solo cambiare..."
- "è 80% quello che voglio"
- "come faccio a modificare solo..."
- "quasi ci siamo, però..."
- "tutto bene tranne..."

**English**:
- "the image is almost perfect but..."
- "I just want to change..."
- "it's 80% what I want"
- "how do I modify only..."
- "we're almost there, but..."
- "everything's fine except..."

### Proactive Response Script

```
"Great! With Nano Banana Pro you DON'T need to regenerate from scratch. The model excels at conversational edits.

Instead of starting over, you can simply say something like:
'That's great, but change the lighting to sunset and make the text neon blue.'

What specific detail do you want to change? Let's craft the edit request together."
```

### Capability Reference
→ `prompt_examples_library.md#example-01-edit-dont-re-roll`

---

## Trigger 2: Character/Identity Consistency

### Detection Patterns

**Italian**:
- "stesso personaggio in più scene"
- "carousel con la stessa persona"
- "mantenere l'identità"
- "serie di immagini coerenti"
- "il protagonista deve restare uguale"
- "storia a fumetti con..."
- "stessa faccia in tutte le immagini"

**English**:
- "same character in multiple scenes"
- "carousel with the same person"
- "maintain identity"
- "consistent series of images"
- "protagonist must stay the same"
- "comic story with..."
- "same face in all images"

### Proactive Response Script

```
"For consistent identity series, Nano Banana Pro supports 'Identity Locking' with up to 14 reference images (6 high fidelity).

The key pattern is to specify what must stay IDENTICAL and what can VARY:
'Keep the person's facial features EXACTLY the same as Image 1, but change their expression to [X] and pose them [Y].'

Do you already have a reference image of the character? I can build a prompt that maintains identity across all scenes, while allowing variations in:
- Facial expressions
- Poses and angles
- Settings
- Lighting"
```

### Capability Reference
→ `prompt_examples_library.md#example-21-the-viral-thumbnail`
→ `prompt_examples_library.md#example-22-the-fluffy-friends-scenario`

---

## Trigger 3: Data Visualization

### Detection Patterns

**Italian**:
- "infografica con dati"
- "visualizzare statistiche"
- "report visivo"
- "earnings report"
- "dashboard"
- "grafici e numeri"
- "dati finanziari"

**English**:
- "infographic with data"
- "visualize statistics"
- "visual report"
- "earnings report"
- "dashboard"
- "charts and numbers"
- "financial data"

### Proactive Response Script

```
"Nano Banana Pro excels at transforming data into visualizations. It has two particularly powerful capabilities:

1. **Data Ingestion**: You can upload a PDF (e.g., earnings report) and ask:
   'Generate a clean, modern infographic summarizing the key financial highlights. Include charts for Revenue Growth and Net Income.'

2. **Search Grounding**: For up-to-date data, the model can use Google Search:
   'Generate an infographic of the best times to visit the U.S. National Parks in 2025 based on current travel trends.'

Do you have a document to transform, or would you prefer the model to retrieve current data?"
```

### Capability Reference
→ `prompt_examples_library.md#example-11-earnings-report-infographic`
→ `prompt_examples_library.md#example-31-event-visualization`

---

## Trigger 4: Viral/Thumbnail Content

### Detection Patterns

**Italian**:
- "thumbnail per YouTube"
- "immagine virale"
- "post social che attira click"
- "copertina video"
- "contenuto TikTok"
- "hook visivo"

**English**:
- "YouTube thumbnail"
- "viral image"
- "click-worthy social post"
- "video cover"
- "TikTok content"
- "visual hook"

### Proactive Response Script

```
"For viral thumbnails, Nano Banana Pro can combine in a single pass:
- **Subject identity** (keeping your face/character)
- **Bold text** with outlines and shadows
- **Graphics** (arrows, emoji, highlights)
- **Optimized background**

Here's an example of a complete prompt:
'Design a viral video thumbnail using the person from Image 1. Keep facial features exactly the same but change expression to excited/surprised. Pose them on the left pointing right. Place [object] on the right. Add bold yellow arrow connecting finger to object. Overlay massive pop-style text: '[YOUR TEXT]' with thick white outline. Blurred bright background. High saturation.'

Do you have a reference image for the subject? What type of content do you want to promote?"
```

### Capability Reference
→ `prompt_examples_library.md#example-21-the-viral-thumbnail`

---

## Trigger 5: Structural Control

### Detection Patterns

**Italian**:
- "ho uno sketch/bozza"
- "seguire questo wireframe"
- "layout già definito"
- "disegno a mano da trasformare"
- "rispettare questa composizione"
- "struttura come nel riferimento"

**English**:
- "I have a sketch/draft"
- "follow this wireframe"
- "layout already defined"
- "hand drawing to transform"
- "respect this composition"
- "structure like the reference"

### Proactive Response Script

```
"Perfect! Nano Banana Pro can use sketches, wireframes, or grids as structural control.

The prompt can be surprisingly simple:
'Create an ad for [product] following this sketch.'

The model will respect the spatial composition of your input, elevating it to professional output.

It works with:
- **Hand sketches** → Finished ad/poster
- **UI wireframes** → High-fidelity mockup
- **Pixel grids** → Sprite/pixel art
- **Structural templates** → Repeatable assets

What type of input have you prepared?"
```

### Capability Reference
→ `prompt_examples_library.md#example-91-sketch-to-final-ad`
→ `prompt_examples_library.md#example-92-ui-mockup-from-wireframe`

---

## Trigger 6: Localization/Translation

### Detection Patterns

**Italian**:
- "adattare per il mercato..."
- "tradurre in giapponese/cinese/tedesco"
- "localizzare"
- "versione per [paese]"
- "cambiare lingua e contesto"

**English**:
- "adapt for the market..."
- "translate to Japanese/Chinese/German"
- "localize"
- "version for [country]"
- "change language and context"

### Proactive Response Script

```
"Nano Banana Pro can do full localization: text translation AND cultural adaptation of the image.

Example:
'Take this concept and localize it to a Tokyo setting, including translating the tagline into Japanese. Change the background to a bustling Shibuya street at night.'

This includes:
- Accurate text translation
- Environmental adaptation (London → Tokyo)
- Culturally appropriate elements
- Core concept preservation

What target market and what type of content do you need to adapt?"
```

### Capability Reference
→ `prompt_examples_library.md#example-43-localization`

---

## Trigger 7: Photo Restoration/Colorization

### Detection Patterns

**Italian**:
- "foto vecchia da restaurare"
- "colorare foto in bianco e nero"
- "riparare foto danneggiata"
- "manga/fumetto da colorare"
- "aggiungere colore a..."

**English**:
- "old photo to restore"
- "colorize black and white photo"
- "repair damaged photo"
- "manga/comic to colorize"
- "add color to..."

### Proactive Response Script

```
"Nano Banana Pro has advanced editing capabilities:

**For manga/comic colorization:**
'Colorize this manga panel. Use a vibrant anime style palette. Ensure lighting effects on energy beams are glowing neon blue and character outfit is consistent with official colors.'

**For historical photos:**
'Colorize this vintage photograph with historically accurate colors for the 1940s era.'

**For restoration:**
'Restore this damaged photograph, removing scratches and tears while preserving the original composition.'

What type of image do you want to work on?"
```

### Capability Reference
→ `prompt_examples_library.md#example-42-mangacomic-colorization`

---

## Trigger 8: Dimensional Translation

### Detection Patterns

**Italian**:
- "da 2D a 3D"
- "da planimetria a render"
- "floor plan"
- "interior design"
- "visualizzazione architettonica"
- "meme in 3D"

**English**:
- "from 2D to 3D"
- "from floor plan to render"
- "floor plan"
- "interior design"
- "architectural visualization"
- "meme in 3D"

### Proactive Response Script

```
"Nano Banana Pro excels at dimensional translation!

**For interior design (2D floor plan → 3D board):**
'Based on the uploaded 2D floor plan, generate a professional interior design presentation board. Layout: collage with one large main image (wide-angle living area) and three smaller images below (Master Bedroom, Home Office, 3D top-down floor plan). Style: Modern Minimalist with warm oak wood flooring. Quality: Photorealistic rendering, soft natural lighting.'

**For creative content (2D → 3D):**
'Turn the 'This is Fine' dog meme into a photorealistic 3D render. Keep composition identical but make the dog look like a plush toy and fire look like realistic flames.'

Do you have a floor plan, a 2D sketch, or a flat image to convert?"
```

### Capability Reference
→ `prompt_examples_library.md#example-51-2d-floor-plan-to-3d`
→ `prompt_examples_library.md#example-52-2d-to-3d-meme-conversion`

---

## Trigger 9: High-Resolution/Textures

### Detection Patterns

**Italian**:
- "4K"
- "alta risoluzione"
- "texture dettagliata"
- "wallpaper"
- "stampa grande formato"
- "dettagli macro"

**English**:
- "4K"
- "high resolution"
- "detailed texture"
- "wallpaper"
- "large format print"
- "macro details"

### Proactive Response Script

```
"Nano Banana Pro supports native generation from 1K to 4K.

**For wallpaper/atmospheric environments:**
'Harness native high-fidelity output to craft a breathtaking, atmospheric environment of a mossy forest floor. Command complex lighting effects and delicate textures, ensuring every strand of moss and beam of light is rendered in pixel-perfect resolution suitable for a 4K wallpaper.'

**For food photography/detailed textures:**
'Create a hyper-realistic infographic of a gourmet cheeseburger, deconstructed to show the texture of the toasted brioche bun, the seared crust of the patty, and the glistening melt of the cheese.'

Keys for high resolution:
- Explicit resolution request (2K, 4K)
- Texture descriptions ('every strand', 'glistening', 'seared crust')
- Complex lighting effects

What type of high-resolution content do you need?"
```

### Capability Reference
→ `prompt_examples_library.md#example-61-4k-atmospheric-environment`
→ `prompt_examples_library.md#example-62-deconstructed-food-photography`

---

## Trigger 10: Animation/Sprites

### Detection Patterns

**Italian**:
- "sprite sheet"
- "animazione frame by frame"
- "sequenza di movimenti"
- "gif animata"
- "asset per gioco"
- "ciclo di camminata"

**English**:
- "sprite sheet"
- "frame by frame animation"
- "movement sequence"
- "animated gif"
- "game asset"
- "walk cycle"

### Proactive Response Script

```
"For sprites and animations, Nano Banana Pro can generate structured sheets.

**Example prompt:**
'Sprite sheet of a woman doing a backflip on a drone, 3x3 grid, sequence, frame by frame animation, square aspect ratio. Follow the structure of the attached reference image exactly.'

**Tips:**
- Specify the grid (3x3, 4x4, 8 frames)
- Describe the full action
- Use a reference image for structure
- Request specific aspect ratio

**Post-processing:** You can then extract each cell and create an animated GIF.

What type of animation/sprite do you need?"
```

### Capability Reference
→ `prompt_examples_library.md#example-94-sprite-sheet`
→ `prompt_examples_library.md#example-93-pixel-art`

---

## Trigger 11: Problem-Solving/Reasoning

### Detection Patterns

**Italian**:
- "risolvere un'equazione"
- "mostrare i passaggi"
- "spiegare visivamente"
- "diagramma logico"
- "prima/dopo"
- "analizzare e ricostruire"

**English**:
- "solve an equation"
- "show the steps"
- "explain visually"
- "logic diagram"
- "before/after"
- "analyze and reconstruct"

### Proactive Response Script

```
"Nano Banana Pro has a 'Thinking' mode that enables visual reasoning.

**For mathematical problems:**
'Solve log_{x^2+1}(x^4-1)=2 in C on a whiteboard. Show the steps clearly.'

**For temporal/causal analysis:**
'Analyze this image of a room and generate a 'before' image that shows what the room might have looked like during construction, showing the framing and unfinished drywall.'

The model can:
- Work through logical problems
- Generate 'before' states from 'after' images
- Create step-by-step explanatory diagrams
- Apply physics and construction knowledge

What type of problem do you want to visualize?"
```

### Capability Reference
→ `prompt_examples_library.md#example-71-solve-equations`
→ `prompt_examples_library.md#example-72-visual-reasoning`

---

## Trigger 12: Brand/Editorial Assets

### Detection Patterns

**Italian**:
- "shooting fotografico"
- "catalogo prodotti"
- "editorial fashion"
- "brand assets"
- "lookbook"
- "serie coerente di immagini prodotto"

**English**:
- "photo shoot"
- "product catalog"
- "fashion editorial"
- "brand assets"
- "lookbook"
- "consistent product image series"

### Proactive Response Script

```
"For serial brand asset production, Nano Banana Pro can maintain stylistic consistency.

**Example prompt:**
'Create 9 stunning fashion shots as if they're from an award-winning fashion editorial. Use this reference as the brand style but add nuance and variety to the range so they convey a professional design touch. Please generate nine images, one at a time.'

**Key elements:**
- Explicit quantity (9 shots)
- Quality reference ('award-winning editorial')
- Style extracted from reference
- Variety WITHIN consistency
- One-at-a-time generation for quality control

Do you have a reference product/garment? How many variants do you need?"
```

### Capability Reference
→ `prompt_examples_library.md#example-23-brand-asset-generation`

---

## Trigger 13: Storyboarding

### Detection Patterns

**Italian**:
- "storyboard"
- "sequenza narrativa"
- "commercial/spot"
- "pitch visivo"
- "storia in immagini"
- "concept per video"

**English**:
- "storyboard"
- "narrative sequence"
- "commercial/spot"
- "visual pitch"
- "story in images"
- "video concept"

### Proactive Response Script

```
"For one-shot storyboards, Nano Banana Pro can generate complete narrative sequences.

**Example prompt:**
'Create an addictively intriguing 9-part story with 9 images featuring a woman and man in an award-winning luxury luggage commercial. The story should have emotional highs and lows, ending on an elegant shot of the woman with the logo.

The identity of the woman and man and their attire must stay consistent throughout but they can and should be seen from different angles and distances.

Please generate images one at a time. Make sure every image is in a 16:9 landscape format.'

**Key elements:**
- Explicit number of parts
- Narrative arc (highs, lows, finale)
- Identity consistency
- Permitted variation (angles, distances)
- Output format

What story do you want to tell? For which product/brand?"
```

### Capability Reference
→ `prompt_examples_library.md#example-81-one-shot-luxury-commercial`

---

## Trigger 14: Technical Diagrams

### Detection Patterns

**Italian**:
- "diagramma tecnico"
- "blueprint"
- "schema architettonico"
- "flowchart"
- "vista esplosa"
- "documentazione tecnica"

**English**:
- "technical diagram"
- "blueprint"
- "architectural schema"
- "flowchart"
- "exploded view"
- "technical documentation"

### Proactive Response Script

```
"For technical diagrams, Nano Banana Pro respects professional conventions.

**Example prompt:**
'Create an orthographic blueprint that describes this building in plan, elevation, and section. Label the 'North Elevation' and 'Main Entrance' clearly in technical architectural font. Format 16:9.'

**Capabilities:**
- Orthographic views (plan, elevation, section)
- Technical labeling
- Appropriate fonts for documentation
- Industry conventions (architecture, engineering)

**For educational diagrams:**
'Summarize the concept of 'Transformer Neural Network Architecture' as a hand-drawn whiteboard diagram suitable for a university lecture. Use different colored markers for the Encoder and Decoder blocks.'

What type of technical diagram do you need?"
```

### Capability Reference
→ `prompt_examples_library.md#example-13-technical-blueprint`
→ `prompt_examples_library.md#example-14-whiteboard-summary`

---

## Trigger 15: Video to Carousel

### Detection Patterns

**Italian**:
- "ho un video YouTube"
- "estrai concetti dal video"
- "carousel da questo video"
- "trasforma il video in carousel"
- "immagini dal video"

**English**:
- "I have a YouTube video"
- "extract concepts from video"
- "carousel from this video"
- "turn video into carousel"
- "images from video"

### Proactive Response Script

```
"To transform a YouTube video into a visual carousel, I use a 2-step workflow:

1. **Step 1**: Extract key concepts with Gemini
2. **Step 2**: Generate Cover + Concept Cards with Nano Banana Pro

The carousel will have a 'graphic recording' style (hand-drawn sketchnote).

Before starting, I'll ask you:
- Which **color palette** you prefer (4 options)
- Which **branding** you want on the images (initials, brand, newsletter, or none)

**NOTE**: The images will NOT contain references to the original video author.

Do you already have the YouTube video URL?"
```

### Capability Reference
→ `video_to_carousel_workflow.md`

---

## Response Priority Rules

When multiple triggers are detected, prioritize:

1. **Explicit user request** (if user asks specifically about a capability)
2. **Primary task** (the main deliverable user needs)
3. **Enhancement opportunity** (capability that would improve the output)

## Anti-Patterns

**DON'T suggest capabilities when:**
- User is in the middle of JSON construction (wait until complete)
- User explicitly says they know what they want
- The conversation is about non-visual topics
- User has already received a suggestion in the last 2 exchanges

**DO suggest capabilities when:**
- User describes a visual need without mentioning Nano Banana Pro features
- User seems stuck or unsure how to proceed
- A capability would significantly improve their stated goal
- User asks "what else can it do?" or similar exploratory questions
