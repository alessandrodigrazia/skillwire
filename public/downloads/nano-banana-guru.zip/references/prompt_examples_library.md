# Prompt Examples Library

This reference contains all 26 production-ready examples from the official Nano Banana Pro guide, organized by capability. Each example includes the natural language prompt, usage notes, and variations.

## Table of Contents

- [0. Golden Rules Examples](#0-golden-rules-examples)
- [1. Text Rendering & Infographics](#1-text-rendering--infographics)
- [2. Character Consistency & Viral Thumbnails](#2-character-consistency--viral-thumbnails)
- [3. Search Grounding](#3-search-grounding)
- [4. Advanced Editing](#4-advanced-editing)
- [5. Dimensional Translation](#5-dimensional-translation)
- [6. High-Resolution & Textures](#6-high-resolution--textures)
- [7. Thinking & Reasoning](#7-thinking--reasoning)
- [8. Storyboarding & Concept Art](#8-storyboarding--concept-art)
- [9. Structural Control](#9-structural-control)

---

## 0. Golden Rules Examples

### Example 0.1: Edit, Don't Re-roll

**When to use**: Image is 80% correct but needs specific adjustments.

**Prompt Pattern**:
```
"That's great, but change the lighting to sunset and make the text neon blue."
```

**Key Principle**: Do NOT regenerate from scratch. The model excels at conversational refinements.

**Variations**:
- "Perfect composition, but swap the background to a beach scene"
- "Keep everything but make the character's expression more surprised"
- "Love it, just increase the contrast and add a subtle vignette"

---

### Example 0.2: Natural Language vs Tag Soup

**Bad (Tag Soup)**:
```
"Cool car, neon, city, night, 8k."
```

**Good (Natural Language)**:
```
"A cinematic wide shot of a futuristic sports car speeding through a rainy Tokyo street at night. The neon signs reflect off the wet pavement and the car's metallic chassis."
```

**Why it works**: Full sentences activate the model's understanding of intent, physics, lighting, and composition relationships.

---

### Example 0.3: Context-Driven Generation

**Prompt**:
```
"Create an image of a sandwich for a Brazilian high-end gourmet cookbook."
```

**What the model infers**:
- Professional food photography plating
- Shallow depth of field
- Perfect studio lighting
- Premium ingredients visible
- Editorial composition

**Key Insight**: The context ("Brazilian high-end gourmet cookbook") guides artistic decisions without explicit technical instructions.

---

## 1. Text Rendering & Infographics

### Example 1.1: Earnings Report Infographic (Data Ingestion)

**When to use**: Transform dense PDF data into visual summary.

**Input**: [Upload PDF of earnings report]

**Prompt**:
```
"Generate a clean, modern infographic summarizing the key financial highlights from this earnings report. Include charts for 'Revenue Growth' and 'Net Income', and highlight the CEO's key quote in a stylized pull-quote box."
```

**Best Practices**:
- Ask model to "compress" dense text into visual aids
- Specify chart types explicitly
- Request pull-quote boxes for key statements

**Variations**:
- "Summarize this quarterly report as a one-page executive dashboard"
- "Extract the top 5 metrics and visualize them with trend arrows"

---

### Example 1.2: Retro Infographic

**When to use**: Historical or nostalgic content that benefits from period-appropriate styling.

**Prompt**:
```
"Make a retro, 1950s-style infographic about the history of the American diner. Include distinct sections for 'The Food,' 'The Jukebox,' and 'The Decor.' Ensure all text is legible and stylized to match the period."
```

**Key Elements**:
- Explicit era reference (1950s)
- Named sections for structure
- Legibility requirement despite stylization

**Variations**:
- "Create an Art Deco infographic about the golden age of cinema"
- "Design a Victorian-era scientific poster about botanical specimens"
- "Make a 1980s neon-style infographic about video game history"

---

### Example 1.3: Technical Blueprint/Diagram

**When to use**: Architectural, engineering, or technical documentation.

**Prompt**:
```
"Create an orthographic blueprint that describes this building in plan, elevation, and section. Label the 'North Elevation' and 'Main Entrance' clearly in technical architectural font. Format 16:9."
```

**Key Elements**:
- Specific view types (plan, elevation, section)
- Explicit labeling requirements
- Technical font specification
- Format/aspect ratio

**Variations**:
- "Generate a cross-section diagram of this mechanical assembly with part callouts"
- "Create an exploded view showing all components in assembly order"

---

### Example 1.4: Whiteboard Summary (Educational)

**When to use**: Educational content, lecture materials, concept explanations.

**Prompt**:
```
"Summarize the concept of 'Transformer Neural Network Architecture' as a hand-drawn whiteboard diagram suitable for a university lecture. Use different colored markers for the Encoder and Decoder blocks, and include legible labels for 'Self-Attention' and 'Feed Forward'."
```

**Key Elements**:
- "Hand-drawn whiteboard" surface specification
- Color coding for conceptual distinction
- Audience context (university lecture)
- Specific labels required

**Variations**:
- "Explain the water cycle as a classroom whiteboard drawing with blue and green markers"
- "Draw a startup business model canvas as if sketched during a strategy meeting"
- "Create a mind map of machine learning concepts in whiteboard style"

---

## 2. Character Consistency & Viral Thumbnails

### Example 2.1: The Viral Thumbnail (Identity + Text + Graphics)

**When to use**: YouTube thumbnails, social media content requiring face + text + graphics in one pass.

**Input**: [Reference image of person - Image 1]

**Prompt**:
```
"Design a viral video thumbnail using the person from Image 1. 

Face Consistency: Keep the person's facial features exactly the same as Image 1, but change their expression to look excited and surprised. 

Action: Pose the person on the left side, pointing their finger towards the right side of the frame. 

Subject: On the right side, place a high-quality image of a delicious avocado toast. 

Graphics: Add a bold yellow arrow connecting the person's finger to the toast. 

Text: Overlay massive, pop-style text in the middle: '3分钟搞定!' (Done in 3 mins!). Use a thick white outline and drop shadow. 

Background: A blurred, bright kitchen background. High saturation and contrast."
```

**Key Elements**:
- Explicit identity locking instruction
- Allowed changes (expression, pose) vs locked features (facial features)
- Spatial positioning (left/right)
- Graphics layer (arrow)
- Text styling (outline, shadow)
- Background treatment

**Technical Note**: Nano Banana Pro supports up to 14 reference images (6 with high fidelity) for identity locking.

---

### Example 2.2: The Fluffy Friends Scenario (Group Consistency)

**When to use**: Multi-character stories, mascot adventures, consistent cast across scenes.

**Input**: [3 images of different plush creatures]

**Prompt**:
```
"Create a funny 10-part story with these 3 fluffy friends going on a tropical vacation. The story is thrilling throughout with emotional highs and lows and ends in a happy moment. 

Keep the attire and identity consistent for all 3 characters, but their expressions and angles should vary throughout all 10 images. 

Make sure to only have one of each character in each image."
```

**Key Elements**:
- Multi-image sequence request (10 parts)
- Narrative arc specification (highs, lows, happy ending)
- Identity consistency for multiple characters
- Allowed variation (expressions, angles)
- Constraint: one of each character per image

**Variations**:
- "Create a 6-panel comic with these two characters solving a mystery"
- "Generate a 4-season series showing this mascot in spring, summer, fall, winter"

---

### Example 2.3: Brand Asset Generation

**When to use**: Fashion photography, product catalogs, editorial shoots requiring style consistency.

**Input**: [1 image of a product/garment]

**Prompt**:
```
"Create 9 stunning fashion shots as if they're from an award-winning fashion editorial. Use this reference as the brand style but add nuance and variety to the range so they convey a professional design touch. Please generate nine images, one at a time."
```

**Key Elements**:
- High quantity with quality ("9 stunning shots")
- Editorial reference frame ("award-winning fashion editorial")
- Style extraction from reference
- Variety within consistency
- One-at-a-time generation for quality control

**Variations**:
- "Generate 6 product shots of this watch from different angles for an e-commerce catalog"
- "Create a lookbook series of 8 images featuring this jacket in different urban settings"

---

## 3. Search Grounding

### Example 3.1: Event Visualization with Real-Time Data

**When to use**: Content requiring current information, trends, or factual verification.

**Prompt**:
```
"Generate an infographic of the best times to visit the U.S. National Parks in 2025 based on current travel trends."
```

**How it works**: 
- Model uses Google Search to gather current data
- "Thinks" (reasons) about search results before generating
- Reduces hallucinations on timely topics

**Key Elements**:
- Specific year reference (2025)
- Request for "current" information
- Data-dependent visualization

**Variations**:
- "Create a weather comparison chart for European capitals this week"
- "Visualize the current stock performance of the top 5 tech companies"
- "Generate an infographic about trending vacation destinations for summer 2025"

**Note**: Search grounding is particularly valuable for:
- Current events visualization
- Real-time data representation
- Factual verification before image generation

---

## 4. Advanced Editing

### Example 4.1: Object Removal & In-painting

**When to use**: Removing unwanted elements while maintaining scene coherence.

**Input**: [Photo with tourists in background]

**Prompt**:
```
"Remove the tourists from the background of this photo and fill the space with logical textures (cobblestones and storefronts) that match the surrounding environment."
```

**Key Elements**:
- Semantic instruction (no manual masking needed)
- Specification of replacement content
- "Logical textures" - trusting model's physics understanding
- Environment matching requirement

**Variations**:
- "Remove the power lines from this landscape and restore the sky naturally"
- "Take out the watermark and reconstruct the underlying image"

---

### Example 4.2: Manga/Comic Colorization

**When to use**: Transforming black and white art into full color.

**Input**: [Black and white manga panel]

**Prompt**:
```
"Colorize this manga panel. Use a vibrant anime style palette. Ensure the lighting effects on the energy beams are glowing neon blue and the character's outfit is consistent with their official colors."
```

**Key Elements**:
- Style specification ("vibrant anime")
- Specific color assignments (neon blue energy beams)
- Character consistency reference ("official colors")
- Lighting effect requirements

**Variations**:
- "Colorize this vintage black and white photograph with historically accurate colors"
- "Add color to this line art using a Studio Ghibli-inspired palette"

---

### Example 4.3: Localization (Text Translation + Cultural Adaptation)

**When to use**: Adapting content for different markets/cultures.

**Input**: [Image of a London bus stop ad]

**Prompt**:
```
"Take this concept and localize it to a Tokyo setting, including translating the tagline into Japanese. Change the background to a bustling Shibuya street at night."
```

**Key Elements**:
- Cultural adaptation (London → Tokyo)
- Text translation requirement
- Environmental change (Shibuya at night)
- Preserving core concept while adapting context

**Variations**:
- "Adapt this American retail poster for the German market with Euro pricing"
- "Localize this app screenshot from English to Spanish with Latin American cultural references"

---

### Example 4.4: Lighting/Seasonal Control

**When to use**: Changing time of day, season, or atmospheric conditions.

**Input**: [Image of a house in summer]

**Prompt**:
```
"Turn this scene into winter time. Keep the house architecture exactly the same, but add snow to the roof and yard, and change the lighting to a cold, overcast afternoon."
```

**Key Elements**:
- Seasonal transformation
- Architecture preservation constraint
- Weather element addition (snow)
- Lighting mood change (cold, overcast)

**Variations**:
- "Transform this daytime street photo into a moody night scene with street lamp lighting"
- "Change this spring garden to autumn with falling leaves and golden hour light"
- "Make this sunny beach scene stormy with dramatic clouds"

---

## 5. Dimensional Translation

### Example 5.1: 2D Floor Plan to 3D Interior Design Board

**When to use**: Architecture, interior design, real estate visualization.

**Input**: [2D floor plan]

**Prompt**:
```
"Based on the uploaded 2D floor plan, generate a professional interior design presentation board in a single image. 

Layout: A collage with one large main image at the top (wide-angle perspective of the living area), and three smaller images below (Master Bedroom, Home Office, and a 3D top-down floor plan). 

Style: Apply a Modern Minimalist style with warm oak wood flooring and off-white walls across ALL images. 

Quality: Photorealistic rendering, soft natural lighting."
```

**Key Elements**:
- Input type specification (2D floor plan)
- Output structure (collage layout)
- Multiple view types in one image
- Consistent style across all views
- Quality/rendering specification

**Variations**:
- "Convert this sketch to a photorealistic architectural rendering"
- "Transform this blueprint into an isometric 3D cutaway view"

---

### Example 5.2: 2D to 3D Meme Conversion

**When to use**: Creative content, humor, viral social media posts.

**Prompt**:
```
"Turn the 'This is Fine' dog meme into a photorealistic 3D render. Keep the composition identical but make the dog look like a plush toy and the fire look like realistic flames."
```

**Key Elements**:
- Cultural reference recognition ("This is Fine" meme)
- Dimensional transformation (2D → 3D)
- Composition preservation
- Material specification (plush toy, realistic flames)

**Variations**:
- "Convert this pixel art character into a 3D clay figurine style"
- "Transform this flat logo into a 3D chrome emblem with reflections"
- "Turn this cartoon character into a realistic digital sculpture"

---

## 6. High-Resolution & Textures

### Example 6.1: 4K Atmospheric Environment Texture

**When to use**: Wallpapers, game assets, high-detail background creation.

**Prompt**:
```
"Harness native high-fidelity output to craft a breathtaking, atmospheric environment of a mossy forest floor. Command complex lighting effects and delicate textures, ensuring every strand of moss and beam of light is rendered in pixel-perfect resolution suitable for a 4K wallpaper."
```

**Key Elements**:
- Explicit resolution request (4K)
- Texture detail emphasis ("every strand of moss")
- Lighting complexity ("complex lighting effects", "beam of light")
- Use case specification (wallpaper)

**Technical Note**: Nano Banana Pro supports native 1K to 4K image generation.

**Variations**:
- "Create a seamless tileable stone wall texture at 4K resolution"
- "Generate a detailed macro shot of water droplets on a leaf, suitable for print"

---

### Example 6.2: Deconstructed Food Photography with Labels

**When to use**: Editorial food content, educational materials, premium advertising.

**Prompt**:
```
"Create a hyper-realistic infographic of a gourmet cheeseburger, deconstructed to show the texture of the toasted brioche bun, the seared crust of the patty, and the glistening melt of the cheese. Label each layer with its flavor profile."
```

**Key Elements**:
- "Hyper-realistic" quality demand
- Deconstructed/exploded view
- Specific texture descriptions (toasted, seared, glistening)
- Labeling requirement with conceptual content (flavor profiles)
- Combines data visualization with photography

**Variations**:
- "Create an exploded view of a sushi roll with ingredient labels and origin information"
- "Generate a deconstructed cocktail image with each ingredient layer identified"

---

## 7. Thinking & Reasoning

### Example 7.1: Solve Equations on Whiteboard

**When to use**: Mathematical content, educational materials, problem demonstrations.

**Prompt**:
```
"Solve log_{x^2+1}(x^4-1)=2 in C on a white board. Show the steps clearly."
```

**Key Elements**:
- Mathematical problem specification
- Domain specification (Complex numbers - C)
- Surface specification (whiteboard)
- Process requirement ("show the steps")

**How it works**: Model uses "Thinking" process to work through the problem logically before rendering the visual solution.

**Variations**:
- "Demonstrate the proof of the Pythagorean theorem step by step"
- "Show the derivation of the quadratic formula on a chalkboard"

---

### Example 7.2: Visual Reasoning (Before/After Analysis)

**When to use**: Architectural visualization, renovation planning, temporal transformation.

**Input**: [Image of a finished room]

**Prompt**:
```
"Analyze this image of a room and generate a 'before' image that shows what the room might have looked like during construction, showing the framing and unfinished drywall."
```

**Key Elements**:
- Reverse temporal reasoning (finished → construction)
- Architectural knowledge application
- Maintaining spatial relationships
- Construction-accurate details (framing, drywall)

**Variations**:
- "Generate what this restored painting looked like before restoration, showing age damage"
- "Show what this garden looked like 50 years ago when first planted"
- "Create the 'before' renovation image of this modernized kitchen"

---

## 8. Storyboarding & Concept Art

### Example 8.1: One-Shot Luxury Commercial Storyboard

**When to use**: Ad concepts, pitch decks, commercial pre-visualization.

**Prompt**:
```
"Create an addictively intriguing 9-part story with 9 images featuring a woman and man in an award-winning luxury luggage commercial. The story should have emotional highs and lows, ending on an elegant shot of the woman with the logo. 

The identity of the woman and man and their attire must stay consistent throughout but they can and should be seen from different angles and distances. 

Please generate images one at a time. Make sure every image is in a 16:9 landscape format."
```

**Key Elements**:
- Quantity specification (9 parts/images)
- Narrative arc (highs, lows, elegant ending)
- Identity consistency requirement
- Allowed variation (angles, distances)
- Format specification (16:9 landscape)
- Generation pace ("one at a time")

**Variations**:
- "Create a 6-panel storyboard for a car commercial showing a journey from city to coast"
- "Generate a 12-image pitch deck visualizing a day-in-the-life using our app"

---

## 9. Structural Control

### Example 9.1: Sketch to Final Ad

**When to use**: Rapid concept iteration, maintaining client-approved layouts.

**Input**: [Hand-drawn sketch showing layout]

**Prompt**:
```
"Create an ad for a [product] following this sketch."
```

**Key Elements**:
- Layout control via sketch input
- Minimal prompt—trusting sketch to define composition
- Product specification variable

**How it works**: Sketch defines spatial relationships; model elevates to polished output while respecting the drawn layout.

**Variations**:
- "Transform this napkin sketch into a professional app icon"
- "Convert this rough wireframe into a polished website hero section"

---

### Example 9.2: UI Mockup from Wireframe

**When to use**: UI/UX design, rapid prototyping, client presentations.

**Input**: [Wireframe image with layout boxes]

**Prompt**:
```
"Create a mock-up for a [product] following these guidelines."
```

**Key Elements**:
- Wireframe as structural control
- Product/context specification
- Model fills in visual details while respecting wireframe structure

**Variations**:
- "Generate a mobile app screen based on this wireframe for a fitness app"
- "Create a dashboard UI from this layout sketch using a dark theme"

---

### Example 9.3: Pixel Art & LED Displays

**When to use**: Game development, hardware displays, retro-style content.

**Input**: [64x64 grid image]

**Prompt**:
```
"Generate a pixel art sprite of a unicorn that fits perfectly into this 64x64 grid image. Use high contrast colors."
```

**Key Elements**:
- Grid constraint specification
- Exact size requirement (64x64)
- Color guidance (high contrast)

**Technical Tip**: Developers can programmatically extract the center color of each cell to drive connected LED matrix displays.

**Variations**:
- "Create a 32x32 pixel art character for a retro platformer game"
- "Generate an 8-bit style icon set that fits this pixel grid template"

---

### Example 9.4: Sprite Sheet for Animation

**When to use**: Game assets, animated content, motion design.

**Input**: [Reference sprite sheet structure]

**Prompt**:
```
"Sprite sheet of a woman doing a backflip on a drone, 3x3 grid, sequence, frame by frame animation, square aspect ratio. Follow the structure of the attached reference image exactly."
```

**Key Elements**:
- Grid specification (3x3)
- Animation sequence request
- Action description (backflip on drone)
- Structural control via reference
- Format specification (square)

**Post-Processing Tip**: Extract each cell and convert to GIF for animated output.

**Variations**:
- "Create an 8-frame walk cycle sprite sheet for this character"
- "Generate a 4x4 explosion animation sequence"
- "Design a 6-frame idle animation sprite sheet for a robot character"

---

## Usage Notes

### Combining Capabilities

Many powerful outputs combine multiple capabilities:

- **Viral Thumbnail** = Identity Locking + Text Rendering + Structural Control
- **Localization** = Editing + Text Rendering + Cultural Adaptation
- **Brand Asset Generation** = Character Consistency + Style Universe + Multiple Outputs
- **Deconstructed Food** = High-Resolution + Data Visualization + Photography

### Iterative Refinement

Remember the Golden Rule: if output is 80% correct, use conversational editing:
- ✅ "Great, but make the text larger and change the arrow to red"
- ❌ Regenerating from scratch with modified prompt

### When to Use JSON vs Natural Language

- **Natural Language**: Quick iterations, simple requests, creative exploration
- **JSON Format**: Production assets, precise control, repeatable outputs, complex multi-zone layouts

See `work_surface_templates.md` for JSON templates corresponding to these examples.
