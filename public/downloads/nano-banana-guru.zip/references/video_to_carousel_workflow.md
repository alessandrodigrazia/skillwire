# Quick Mode: Video to Carousel

Workflow rapido per trasformare video YouTube in carousel visivi per LinkedIn/social media.

## Workflow Overview

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────────┐
│  VIDEO YOUTUBE  │ ──▶ │  STEP 1: GEMINI  │ ──▶ │  CONCETTI (max 10)  │
└─────────────────┘     └──────────────────┘     └─────────────────────┘
                                                           │
                              ┌─────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    DOMANDE INTERATTIVE                               │
│  1. Quale palette? (Sketchnote / Tech Blue / Corporate / Earthy)    │
│  2. Quale branding? (None / Initials / Brand / Newsletter)          │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────┐     ┌─────────────────────┐
│  STEP 2A: COVER │ ──▶ │  STEP 2B: CARDS    │
│  (1 immagine)   │     │  (N immagini)       │
└─────────────────┘     └─────────────────────┘
```

---

## Step 1: Concept Extraction (Gemini)

### Esecuzione

**In Claude Code (VS Code)**: Lancia automaticamente il subagente `gemini-flash`

**In Claude Desktop**:
1. Tenta MCP server Gemini se disponibile
2. Se fallisce → fornisci il prompt all'utente per uso manuale

### Prompt Template

```
Analyse this YouTube video: [URL]

Extract key concepts for a visual carousel series (cover + one image per concept).

IMPORTANT CONSTRAINTS:
- Do NOT include any reference to the video author/creator name
- Do NOT mention the YouTube channel
- Extract only the IDEAS and CONCEPTS, not attribution
- Present content as standalone educational material

Output format:

## COVER IMAGE OUTLINE
- Title: [Compelling title, max 5 words - NO author name]
- Subtitle: [One sentence that hooks the viewer]
- Visual concept: [Brief description of what the cover should convey]
- Key icons: [3-4 visual elements that represent the topic]

## KEY CONCEPTS (max 10)

### Concept [N]: [Label - 2-4 words]
- Core idea: [One clear sentence explaining this concept]
- Visual metaphor: [What image or scene could represent this?]
- Icon suggestion: [Simple symbol that captures the essence]
- Connection: [How does this relate to other concepts?]

Keep concepts digestible and visually translatable.
Prioritize the most impactful ideas over comprehensive coverage.
```

---

## Domande Interattive

Prima di generare le immagini, chiedere SEMPRE:

### Domanda 1: Palette

```
Quale palette colori preferisci per il carousel?

1. **Sketchnote** (default) - Teal, Orange, Terracotta - stile graphic recording
2. **Tech Blue** - Navy, Cyan, Light Gray - stile tech/startup
3. **Corporate** - Dark Blue, Gold, Charcoal - stile business/enterprise
4. **Warm Earthy** - Forest, Amber, Cream - stile naturale/organico
```

### Domanda 2: Branding

```
Vuoi aggiungere un badge di branding alle immagini?

1. **Nessuno** - Carousel generico
2. **[YOUR INITIALS]** - Le tue iniziali
3. **[YOUR BRAND]** - Il tuo brand
4. **[NEWSLETTER 1]** - Newsletter name
5. **[NEWSLETTER 2]** - Newsletter name
6. **[NEWSLETTER 3]** - Newsletter name
```

---

## Palette Presets

### Sketchnote (Default)

```json
{
  "color_palette": {
    "primary": [
      {"name": "ink", "hex": "#000000", "usage": "outlines and text"},
      {"name": "paper", "hex": "#FFFFFF", "usage": "background"}
    ],
    "accent": [
      {"name": "teal", "hex": "#008080", "usage": "primary highlights"},
      {"name": "orange", "hex": "#FF6B35", "usage": "secondary accents"},
      {"name": "terracotta", "hex": "#B85042", "usage": "tertiary details"}
    ]
  }
}
```

### Tech Blue

```json
{
  "color_palette": {
    "primary": [
      {"name": "ink", "hex": "#1E3A5F", "usage": "outlines and text"},
      {"name": "paper", "hex": "#FFFFFF", "usage": "background"}
    ],
    "accent": [
      {"name": "navy", "hex": "#1E3A5F", "usage": "primary highlights"},
      {"name": "cyan", "hex": "#00B4D8", "usage": "secondary accents"},
      {"name": "lightgray", "hex": "#E5E5E5", "usage": "tertiary details"}
    ]
  }
}
```

### Corporate

```json
{
  "color_palette": {
    "primary": [
      {"name": "ink", "hex": "#2C3E50", "usage": "outlines and text"},
      {"name": "paper", "hex": "#FFFFFF", "usage": "background"}
    ],
    "accent": [
      {"name": "darkblue", "hex": "#2C3E50", "usage": "primary highlights"},
      {"name": "gold", "hex": "#F39C12", "usage": "secondary accents"},
      {"name": "charcoal", "hex": "#34495E", "usage": "tertiary details"}
    ]
  }
}
```

### Warm Earthy

```json
{
  "color_palette": {
    "primary": [
      {"name": "ink", "hex": "#2D5016", "usage": "outlines and text"},
      {"name": "paper", "hex": "#F5F5DC", "usage": "background (cream)"}
    ],
    "accent": [
      {"name": "forest", "hex": "#2D5016", "usage": "primary highlights"},
      {"name": "amber", "hex": "#D4A017", "usage": "secondary accents"},
      {"name": "cream", "hex": "#F5F5DC", "usage": "tertiary details"}
    ]
  }
}
```

---

## Branding Presets

| Opzione | Badge Text | Stile Visivo |
|---------|------------|--------------|
| Nessuno | - | Nessun badge |
| Iniziali | [ABC] | Cerchio hand-drawn con iniziali, bottom-right |
| Brand | [Your Brand] | Logo stilizzato sketchnote, bottom-right |
| Newsletter 1 | [Newsletter Name] | Icona + nome, font small, bottom-right |
| Newsletter 2 | [Newsletter Name] | Icona + nome, font small, bottom-right |
| Newsletter 3 | [Newsletter Name] | Icona + nome, font small, bottom-right |

---

## Step 2A: Cover Image Template

```json
{
  "image_request": {
    "title": "Carousel Cover - [TOPIC]",
    "purpose": "Opening slide that establishes visual language and hooks viewer",

    "format": {
      "platform": "LinkedIn/Instagram carousel",
      "aspect_ratio": "1:1",
      "resolution_px": [1080, 1080],
      "orientation": "square"
    },

    "visual_style": {
      "design_language": ["graphic recording", "visual thinking", "hand-drawn sketchnote"],
      "background": {
        "color": "#FFFFFF",
        "treatment": "pristine white paper, no lines"
      },
      "tools": "Black ink fine-liners for clear outlines, colored markers for accents",
      "color_palette": "[PALETTE_PRESET]"
    },

    "content": {
      "title": "[TITLE from Step 1]",
      "subtitle": "[SUBTITLE from Step 1]",
      "icons": ["[ICON1]", "[ICON2]", "[ICON3]", "[ICON4]"]
    },

    "layout": {
      "overall_structure": "Main title large and centered in bold 3D-style hand-drawn box",
      "zones": {
        "title": {
          "position": "center",
          "style": "largest, bold strokes, 3D hand-drawn box"
        },
        "subtitle": {
          "position": "below title",
          "style": "medium, lighter weight, handwritten"
        },
        "icons": {
          "position": "surrounding title organically",
          "count": "4-6 simple doodles"
        },
        "series_indicator": {
          "position": "bottom or corner",
          "style": "small page curl or carousel dots (1 of N)"
        }
      },
      "visual_hierarchy": ["Title", "Subtitle", "Icons", "Series indicator"]
    },

    "branding": {
      "type": "[none|initials|brand|newsletter]",
      "value": "[BRANDING_VALUE]",
      "placement": "bottom-right corner",
      "style": "small, subtle, hand-drawn badge matching carousel aesthetic"
    },

    "typography": {
      "style": "handwritten, all-caps printing, fully legible",
      "hierarchy": {
        "title": "largest, bold strokes",
        "subtitle": "medium, lighter weight"
      }
    },

    "constraints_and_avoidances": {
      "mandatory": [
        "NO references to original video author/channel",
        "NO YouTube branding or attribution",
        "Content presented as original material"
      ],
      "visual": [
        "No stock photo aesthetic",
        "No digital/vector look - must feel hand-drawn",
        "No clutter - keep breathing room"
      ]
    },

    "consistency_notes": [
      "This establishes the visual language for ALL subsequent cards",
      "Same paper texture throughout series",
      "Same color palette throughout series",
      "Same hand-drawn line quality throughout series"
    ],

    "rendering_guidance": {
      "priority_order": ["Text legibility", "Hand-drawn authenticity", "Visual hierarchy"],
      "style_keywords_for_model": [
        "professional brainstorming session",
        "conference graphic recording",
        "clean and inviting",
        "sketchnote",
        "hand-drawn"
      ]
    }
  }
}
```

---

## Step 2B: Concept Card Template

Repeat for each concept (N from 1 to TOTAL).

```json
{
  "image_request": {
    "title": "Concept Card [N] of [TOTAL]",
    "purpose": "Explain one key concept with visual metaphor",

    "format": {
      "platform": "LinkedIn/Instagram carousel",
      "aspect_ratio": "1:1",
      "resolution_px": [1080, 1080],
      "orientation": "square"
    },

    "visual_style": {
      "design_language": ["graphic recording", "visual thinking", "hand-drawn sketchnote"],
      "background": {
        "color": "#FFFFFF",
        "treatment": "pristine white paper, no lines - MATCHING COVER"
      },
      "tools": "Black ink fine-liners, colored marker accents",
      "color_palette": "[SAME PALETTE AS COVER]"
    },

    "content": {
      "concept_label": "[LABEL from Step 1]",
      "core_idea": "[CORE_IDEA from Step 1]",
      "visual_metaphor": "[VISUAL_METAPHOR from Step 1]"
    },

    "layout": {
      "overall_structure": "Banner top, illustration center, explanation bottom",
      "zones": {
        "header": {
          "position": "top",
          "content": "Concept label in hand-drawn banner or box",
          "style": "bold, prominent"
        },
        "illustration": {
          "position": "center (60% of space)",
          "content": "Main visual illustration of the concept",
          "style": "The visual metaphor, simple enough to understand in 2 seconds"
        },
        "explanation": {
          "position": "bottom",
          "content": "One-sentence explanation in handwritten text",
          "style": "smaller, supporting"
        },
        "page_indicator": {
          "position": "bottom-left corner",
          "content": "[N/TOTAL]",
          "style": "small, subtle"
        },
        "branding": {
          "position": "bottom-right corner",
          "content": "[BRANDING_BADGE]",
          "style": "matching cover badge"
        }
      },
      "visual_hierarchy": ["Concept label", "Illustration", "Explanation", "Page number", "Branding"]
    },

    "illustration_guidelines": {
      "simplicity": "Understandable in 2 seconds",
      "elements": "Use stick figures, simple icons, or diagrams as appropriate",
      "flow": "Include arrows or visual flow if the concept involves a process",
      "metaphor": "Make the visual metaphor obvious and clear"
    },

    "typography": {
      "style": "handwritten, all-caps, legible",
      "hierarchy": {
        "label": "largest",
        "explanation": "smaller"
      }
    },

    "branding": {
      "type": "[SAME AS COVER]",
      "value": "[SAME AS COVER]",
      "placement": "bottom-right corner",
      "style": "identical to cover badge"
    },

    "constraints_and_avoidances": {
      "mandatory": [
        "NO references to original video author/channel",
        "NO YouTube branding or attribution",
        "Content presented as original material"
      ],
      "visual": [
        "NO jarring style shifts from cover",
        "NO complex illustrations - keep simple",
        "NO text smaller than readable at mobile size"
      ]
    },

    "consistency_notes": [
      "MUST match cover visual language exactly",
      "Same line weight as cover",
      "Same color usage patterns as cover",
      "Same hand-drawn aesthetic as cover",
      "Same branding badge position and style as cover"
    ],

    "rendering_guidance": {
      "priority_order": ["Concept clarity", "Visual metaphor effectiveness", "Series consistency"],
      "style_keywords_for_model": [
        "sketchnote",
        "hand-drawn",
        "concept card",
        "visual explanation",
        "educational illustration"
      ]
    }
  }
}
```

---

## Quick Execution Checklist

1. [ ] Ricevi URL video YouTube
2. [ ] Esegui Step 1 (estrazione concetti)
3. [ ] Chiedi palette preferita
4. [ ] Chiedi branding preferito
5. [ ] Genera Cover Image (Step 2A)
6. [ ] Genera Concept Cards (Step 2B) - una alla volta
7. [ ] Verifica consistenza visiva serie completa
8. [ ] Verifica assenza riferimenti autore originale

---

## Response Pattern

When the user activates this workflow, respond:

```
Great! I'll transform the video into a visual carousel.

**Step 1**: Extracting key concepts from the video...
[Run extraction with Gemini]

**Concepts extracted**: [N] concepts + cover outline

Before generating the images, I have two questions:

1. **Color palette**:
   - Sketchnote (teal/orange/terracotta) ← default
   - Tech Blue (navy/cyan/gray)
   - Corporate (blue/gold/charcoal)
   - Warm Earthy (forest/amber/cream)

2. **Branding** (badge bottom-right):
   - None
   - [Your Initials]
   - [Your Brand]
   - [Newsletter 1]
   - [Newsletter 2]
   - [Newsletter 3]

Which do you prefer?
```
