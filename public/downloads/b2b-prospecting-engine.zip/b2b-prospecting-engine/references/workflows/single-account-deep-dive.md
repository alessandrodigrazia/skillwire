# SINGLE ACCOUNT DEEP DIVE WORKFLOW

## Goal
To autonomously execute a highly detailed, 360-degree Tier 1 account research sprint on a single company, surfacing obscure trigger events, key strategic initiatives, and comprehensive Buying Committee (MEDDPICC) mapping.

## Pre-requisites
1. The user provides a target company name (and ideally a primary stakeholder or persona).
2. For Claude Desktop/Web: Utilize Deep Research or extensive web search iterations.
3. For Claude Cowork: Output the results directly to the local file system.

## The Core Process

Execute the following steps sequentially:

### Step 1: The Corporate Strategy Audit
Initiate a comprehensive scan of the target company:
-  Analyze the most recent 10-K, Annual Report, or earnings call transcripts (if public).
-  Extract the top 3 stated strategic priorities (e.g., "expanding margin by 2%", "launching European operations", "reducing supply chain risk").
-  Analyze recent press releases (last 6 months) for expansions, product launches, or major organizational changes.

### Step 2: Extracting Trigger Events ("Why Now")
Search specifically for:
- M&A activity, funding rounds, or IPOs.
- Leadership changes (C-suite, VP-level) within the last 6 months.
- Publicly acknowledged challenges or missed targets.
- *If none found, explicitly write: NO SPECIFIC TRIGGER EVENT FOUND.*

### Step 3: Buying Committee Mapping (MEDDPICC)
Utilize LinkedIn / company website to identify names and titles for the core decision-making unit. Map the following roles:
- **Economic Buyer**: Has final budget authority (e.g., CIO, CFO).
- **Champion**: Directly impacted by the problem, has power to push the deal (e.g., VP of Manufacturing, Director of IT).
- **Technical/Functional Buyer**: Evaluates the tech/security/legal fit (e.g., Enterprise Architect, CISO).
- **End User**: The team/person using it daily.
- **Coach/Influencer**: May not decide, but can provide vital internal insights (e.g., an analyst, a former colleague).
*If a role cannot be confidently matched, write: "TO BE VALIDATED in Discovery Phase".*

### Step 4: Outcome & Value Chain Mapping
Synthesize the findings into a strategic gap analysis:
- **Their Status Quo (Pain)**: What is their current baseline based on the research?
- **The Ideal Future State (Outcome)**: Where are they trying to go based on their strategic priorities?
- **Your Value Proposition**: How does your solution bridge the gap?

### Step 5: Deliverable Generation
1. Formulate the findings using `assets/templates/account-battle-plan.md`.
2. Save/output the Battle Plan locally as `[Company_Name]_Battle_Plan.md` or `.docx` inside the folder `Prospecting_Outputs/`.
3. Prompt the user: *"Deep Dive complete. Would you like me to generate a 3-step outreach sequence for the Champion using `craft-outreach-sequence.md`?"*

### Step 6 (Bonus): Discovery Question Prep (SPICED Framework)
Use the research gathered above to pre-build a discovery question set aligned to the SPICED framework. This prepares the user for the first live conversation with the prospect.

- **Situation**: Based on Step 1 (Corporate Strategy Audit), draft 2 questions to confirm the prospect's current state and priorities. Example: *"I noticed [Company] listed [priority] in your annual report. Is that still the top focus for your team this quarter?"*
- **Pain**: Based on Step 4 (Strategic Gap), draft 2 questions to surface the specific pain. Example: *"What's the biggest bottleneck preventing you from achieving [stated goal]?"*
- **Impact**: Draft 1 question to quantify the cost of the problem. Example: *"If [pain] persists for another 12 months, what's the estimated impact on [metric]?"*
- **Critical Event**: Based on Step 2 (Trigger Events), draft 1 question to establish urgency. Example: *"With [trigger event] happening, is there a timeline driving this decision?"*
- **Decision**: Draft 1 question to understand the buying process. Example: *"Walk me through how a decision like this typically gets made at [Company]. Who else would need to weigh in?"*

*Output this section as an appendix to the Account Battle Plan, labeled "SPICED Discovery Prep".*
