# SOCIAL SELLING PLANNER WORKFLOW

## Goal
To organize a structured, daily LinkedIn engagement plan ("The Productive Day" framework), empowering sales professionals to build their network, share commercial teaching insights, and engage key accounts without being perceived as "salesy".

## Pre-requisites
1. A list of 3-5 target personas and optional URLs to their LinkedIn profiles.
2. The user's specific industry or solution area (to frame the insights).

## The Productive Day Framework (Social Block)
This workflow automates the 'Social Block' of an SDR/KAM's day:
- **Engage**: Commenting intelligently on prospects' content.
- **Connect**: Expanding the network with hyper-relevant decision-makers.
- **Teach**: Drafting "Commercial Teaching" posts/InMails designed to challenge the status quo.

## The Core Process

Execute the following steps sequentially to produce the "Daily Social Selling Itinerary".

### Step 1: Insight Gathering & Content Review
If using Deep Research or Claude Web, scan the recent LinkedIn posts of the target personas.
- *If they post regularly*: Extract 2-3 specific themes they care about.
- *If they never post*: Extract 2-3 industry trends relevant to their role to use as "trigger themes".

### Step 2: Generate Value-Add Comments
For the active posters, draft 3 variants of comments the user can drop on their posts. 
*Constraint*: Never type "Great post, I agree!". Each comment must:
1. Validate their premise.
2. Add a unique data point or alternate perspective ("Yes, and...").
3. Ask a follow-up question to spark dialogue.

### Step 3: Connection Request Strategy
Generate 3 connection request scripts (max 300 characters each).
- **Format**: Anchor the request in a shared interest, a recent event, or an explicit piece of content they engaged with.
- **Constraint**: NO pitches, NO external links, NO "I'd love to connect to expand my network".

### Step 4: Commercial Teaching InMail (The "Challenger" Approach)
Generate 1 long-form InMail (or direct message) designed for a key prospect that challenges their current assumptions.
- **The Warmer**: A relevant industry insight or trigger event.
- **The Reframe**: Highlight an underappreciated cost or risk associated with their status quo.
- **Cost of Inaction**: Provide a concrete data point proving the cost of inaction.
- **Soft CTA**: E.g., "Curious if you are seeing this trend internally as well?"

### Step 5: Deliverable Generation
Output the "Daily Social Selling Itinerary" as a clean markdown file or document to the user. Save locally to `Prospecting_Outputs/Social_Planner_[YYYY-MM-DD].md`.
