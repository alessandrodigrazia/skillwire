# CRAFT OUTREACH SEQUENCE WORKFLOW

## Goal
To translate unstructured account research and Trigger Events into hyper-personalized, outcome-based email and LinkedIn sequences using strict human-writer protocols.

## Pre-requisites
1. A completed Account Battle Plan or user-provided Context/Trigger Events.
2. An identified intended persona/recipient (e.g., Champion or Economic Buyer).

## The Human-Writer Protocol (Strict Constraints)
Before writing any copy, adhere to these absolute constraints:
- **NO AI Fluff**: Prohibited phrases: "I hope this email finds you well", "In today's fast-paced world", "Synergy", "Revolutionize", "Navigate".
- **NO Em-Dashes or En-Dashes**: Do not use the characters `—` (em-dash) or `–` (en-dash). Use commas, periods, or parentheses instead.
- **NO Feature Dumping**: Do not list product features. Talk ONLY about the strategic "Gap" and business outcomes.
- **Format Requirements**: Use varying sentence lengths (short punches mixed with longer reasoning). Use concrete numbers. Use standard ASCII straight quotes (`"..."`).
- **Soft CTA**: Never ask for a meeting immediately (e.g., "Do you have 15 mins on Tuesday?"). Use soft, permission-based language like: "Open to learning more?", "Worth a chat?", or "Is this a priority for your team right now?".

## The Core Process

Execute the following steps sequentially:

### Step 1: Ingest Context
Review the Target Account's recent Trigger Events and primary strategic Gap. If none exist, ask the user to provide them or run `single-account-deep-dive.md`. Let the user provide the name and title of the recipient.

### Step 2: Social Selling Prep (Pre-Email)
Generate LinkedIn materials to warm up the account:
- 1 Connection Request Note (max 300 chars, insight-only, NO pitch).
- 2 Draft Comments for their specific recent posts (or industry topics) that add value/insight.

### Step 3: Generate the 3-Step Email Sequence
Generate an outcome-focused sequence. Each email stands alone but builds a narrative.

*   **Email 1: The Hook (Max 50 words)**
    *   *Subject Line*: 2-4 words, casual, all lowercase.
    *   *Body*: Immediately reference the localized Trigger Event. State an observation about their current status quo. Ask an open-ended question regarding their approach to solving it.

*   **Email 2: The Value (Max 80 words)**
    *   *(To be sent 3-4 days later as a reply to Email 1).*
    *   *Body*: Provide an insight, benchmark, or anonymized business case relevant to their industry. State the specific business outcome your solution enables (e.g., "We helped [similar company] reduce X by Y%.").
    *   *Call to Action*: Soft CTA (e.g., "Is this a challenge you're currently tackling?").

*   **Email 3: The Pushback / Break-up (Max 40 words)**
    *   *(To be sent 5-7 days later).*
    *   *Body*: Challenge the status quo gently. Assume they are sticking with the status quo or it's not a priority. 
    *   *Call to Action*: Revert to permission (e.g., "I'll assume this isn't a priority right now and will stop reaching out. Feel free to reply if things change.").

### Step 4: Deliverable Generation
1. Output the finalized sequence explicitly following the template in `assets/templates/outcome-email-sequence.md`.
2. Save the output locally as `[Recipient_Name]_[Company_Name]_Outreach.md` or `.docx` inside the folder `Prospecting_Outputs/`.
