# BATCH ACCOUNT RESEARCH WORKFLOW

## Goal
To autonomously process a list of target companies (usually provided as a `.csv` or `.xlsx`), research them in parallel, identify Trigger Events, map the Buying Committee, and generate individual Account Battle Plans.

## Pre-requisites
1. The user provides a list of companies (and optionally stakeholders/websites). See `assets/example-input.csv` for the expected CSV format.
2. For Claude Desktop/Web: Utilize Deep Research or multiple web search iterations to gather factual, recent data.
3. For Claude Cowork: Read the local Excel/CSV file and output the results as `.docx` or `.md` files in the `Prospecting_Outputs/` folder on the local file system.

## The Core Process

Execute the following steps sequentially:

### Step 1: List Ingestion & Scoring
1. Read the provided list of accounts.
2. If the user provided more than 5 accounts, ask them if they want to run the python script `scripts/account_scorer.py` to prioritize them, or just process the Top 5. (Never process more than 5 at a time to prevent context collapse).

### Step 2: The Deep Research Sprint (For each account)
For each account on the active list, execute this research sprint. 
**IMPORTANT**: Do not hallucinate. If data is missing, explicitly state "TO BE VALIDATED in Discovery Phase".

*   **Financial & Strategic Intent**: Search for the past 6 months of press releases, Annual Reports, or CEO interviews. Determine the overarching corporate goal (e.g., "cost cutting", "digital transformation", "market expansion").
*   **Trigger Events (The "Why Now")**: Search for events such as:
    *   Recent M&A activity.
    *   New executive hires (especially C-level or VP).
    *   Announcements of new facilities, markets, or product lines.
    *   Earnings misses or major challenges reported.
    *   *If none found, print: NO SPECIFIC TRIGGER EVENT FOUND.*
*   **Buying Committee Mapping (MEDDPICC)**: Search LinkedIn or company "About Us" pages to map the following roles:
    *   Economic Buyer (Who controls the budget?)
    *   Champion (Who would intuitively benefit from solving this problem?)
    *   Technical/Functional Buyer (Who evaluates the technical/legal fit?)
    *   End User (Who actually uses the system daily?)
    *   Coach/Influencer (Is there someone who can provide internal insights?)

### Step 3: Progressive Delivery (Crucial for Claude Cowork)
1. Upon completing Step 2 for an account, IMMEDIATELY formulate the findings using the template `assets/templates/account-battle-plan.md`.
2. Save/output the Battle Plan locally as `[Company_Name]_Battle_Plan.md` or `.docx` inside the folder `Prospecting_Outputs/`.
3. ONLY THEN, proceed to Step 2 for the next account on the list.

### Step 4: Next Actions
Once the batch is complete, prompt the user: *"Batch analysis complete. Should I proceed to generate Outreach Sequences for these accounts using `craft-outreach-sequence.md`?"*
