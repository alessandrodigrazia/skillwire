# PRODUCTIVE DAY PLANNER WORKFLOW

## Goal
Orchestrate a complete prospecting day using the "Productive Day" framework: prioritize target accounts, craft personalized outreach for the top prospects, and execute social selling engagement, all in a structured, time-blocked flow.

## Pre-requisites
1. The user provides a list of target accounts (CSV/XLSX) or has previously generated Account Battle Plans.
2. The user specifies their industry/solution area and the approximate time available for prospecting today.

## The Productive Day Framework

Structure your prospecting day into three high-leverage blocks:

| Block | Time Allocation | Focus | Workflow Used |
|-------|----------------|-------|---------------|
| **Block 1: Research & Strategy** | 20% of available time | Score accounts, identify triggers, select top 3 | `batch-account-research.md` |
| **Block 2: Hyper-Personalized Execution** | 60% of available time | Craft outreach sequences for selected accounts | `craft-outreach-sequence.md` |
| **Block 3: Nurturing & Social Selling** | 20% of available time | LinkedIn engagement, connection building | `social-selling-planner.md` |

## The Core Process

Execute the following steps sequentially:

### Step 1: Block 1 - Account Prioritization (20%)
1. If the user has a fresh account list, run the `batch-account-research.md` workflow (limited to top 5 accounts).
2. If Account Battle Plans already exist, review them and select the top 3 accounts with the strongest Trigger Events and clearest Strategic Gaps.
3. For each selected account, confirm the primary persona to target (typically the Champion or Economic Buyer from the Buying Committee Map).

**Deliverable:** A prioritized shortlist of 3 accounts with confirmed target personas.

### Step 2: Block 2 - Outreach Crafting (60%)
For each of the 3 prioritized accounts, execute `craft-outreach-sequence.md`:
1. Generate the Social Selling Prep (connection request + engagement comments).
2. Generate the 3-Step Email Sequence (Hook, Value, Pushback).
3. Save each sequence to `Prospecting_Outputs/` using the naming convention `[Recipient_Name]_[Company_Name]_Outreach.md`.

**Deliverable:** 3 complete outreach packages ready to execute.

### Step 3: Block 3 - Social Selling Engagement (20%)
Execute `social-selling-planner.md` for additional prospects beyond the top 3:
1. Generate value-add comments for active LinkedIn posters in the pipeline.
2. Prepare connection request scripts for new prospects.
3. Draft 1 Commercial Teaching InMail for a key strategic target.

**Deliverable:** Daily Social Selling Itinerary saved to `Prospecting_Outputs/Social_Planner_[YYYY-MM-DD].md`.

### Step 4: Day Summary & Next Actions
Compile a brief summary of the day's output:
- **Accounts Researched:** [count]
- **Outreach Sequences Generated:** [count]
- **Social Selling Actions Prepared:** [count]
- **Priority for Tomorrow:** [top follow-up or next batch to research]

Save the summary to `Prospecting_Outputs/Day_Summary_[YYYY-MM-DD].md`.
