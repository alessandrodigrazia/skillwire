# PRD: B2B Prospecting Engine

## 1. Executive Summary
The B2B Prospecting Engine is an advanced Claude skill designed to transform outbound B2B sales into an "All-Bound", outcome-based strategy. Taking full advantage of Claude Cowork's ability to read local files and Deep Research's parallel web-crawling autonomous capabilities, this skill allows users to ingest lists of target accounts (Excel/CSV), execute in-depth contextual research to find critical business "Trigger Events", identify key stakeholders (Buying Committee), and generate ready-to-send, hyper-personalized outreach sequences (LinkedIn + Email) anchored to strategic business outcomes rather than product features.

## 2. Problem Statement
- **Inefficient Prospecting**: Sales reps spend hours manually researching accounts, scanning news, and navigating LinkedIn, leaving little time for actual selling.
- **Low Conversion Rates**: Outreach is often generic, feature-centric, and not tied to the prospect's timely business needs.
- **Lack of Strategic Context**: Without understanding recent company events ("Trigger Events") and the specific goals of the individuals in the buying committee, outreach messages fail to clearly answer "Why Change?" and "Why Now?".

**Concrete Scenarios**:
- A sales rep has an Excel list of 20 manufacturing accounts but doesn't know which 3 to focus on today. The skill scores them and identifies that Company A just acquired a new plant in Germany.
- A key account manager wants to "break into" a new Tier 1 account but doesn't know who the real Economic Buyer is or what their current strategic priorities are.
- An SDR needs to write a 3-step email sequence for a CIO. Instead of generic templates, the skill drafts emails referencing a quote the CIO specifically gave in a recent interview.

## 3. Target User
- **Who it is for**: B2B Sales Representatives, Sales Development Reps (SDRs), Key Account Managers, and pre-sales engineers working in complex or enterprise sales environments.
- **Who needs something else**: B2C salespeople, transactional high-volume/low-ticket sales reps, or individuals looking for bulk automated email spam tools.

## 4. Success Metrics
- **Time Savings**: Reduction in account research time from 1-2 hours per account to under 10 minutes.
- **Quality of Output**: 100% of generated outreach sequences must explicitly reference a verified Trigger Event and a Business Outcome, containing no generic "salesy" buzzwords.
- **Workflow Efficiency**: The skill successfully reads a local target list and outputs structured `.docx` or `.md` Battle Plans and sequences directly into the `Prospecting_Outputs/` folder without manual copy-pasting required from the user.

## 5. Skill Structure
- **SKILL.md**: The core orchestrator providing instructions for ingesting lists, running the "Productive Day" blocks, and utilizing Deep Research for Tier 1 account analysis.
- **docs/PRD.md**: This exact requirements document.
- **references/workflows/productive-day-planner.md**: Orchestration workflow for a full prospecting day across all three time blocks (Research, Execution, Nurturing).
- **references/workflows/batch-account-research.md**: Instructions for analyzing target account lists and extracting Trigger Events and Buying Committee maps.
- **references/workflows/single-account-deep-dive.md**: Workflow for investigating a single Tier 1 account in high resolution, mapping public gaps, goals, and preparing SPICED discovery questions.
- **references/workflows/craft-outreach-sequence.md**: Rules to translate research into 3-step email sequences linked to business outcomes.
- **references/workflows/social-selling-planner.md**: Workflow for LinkedIn engagement (InMail strategy, connection notes, value-add comments).
- **assets/templates/account-battle-plan.md**: Standardized output structure for a researched account, including LinkedIn URL fields for Buying Committee members.
- **assets/templates/outcome-email-sequence.md**: Boilerplate structure and constraints for writing the outreach (no generic intros, include the 'Gap', use a soft CTA). Includes self-verification constraint checklist.
- **assets/example-input.csv**: Example CSV format showing expected column headers for account scoring input.
- **scripts/account_scorer.py**: Python script for deterministic sorting/scoring of an initial account list based on configurable criteria (Revenue, Employee Count, Industry fit). Supports both CSV and XLSX input via `openpyxl`.
- **scripts/test_account_scorer.py**: Unit tests for the account scorer (23 test cases covering edge cases and real-world CRM formats).

## 6. Detailed Requirements

### 6.1 Agent Execution & Routing
- **Intent Recognition**: The skill branches execution based on user intent. If a user uploads a `.csv`/`.xlsx`, automatically trigger `batch-account-research.md`. If a user asks to write an email, trigger `craft-outreach-sequence.md`. If a user asks to plan their day, trigger `productive-day-planner.md`.
- **Deep Research Integration**: The skill explicitly prompts the LLM (when using Claude/Claude Desktop) to utilize its "Deep Research" capabilities (spawning sub-agents) to comprehensively scan annual reports, press releases, and executive LinkedIn profiles.

### 6.2 File System Autonomy (Claude Cowork)
- **Setup**: The `Prospecting_Outputs/` folder must exist before workflows can save deliverables. The skill instructs the agent to create it if missing.
- **Local File Operations**: Workflows instruct Claude to read input files (`.csv` / `.xlsx` / `.md`) from the local directory and output files to the `Prospecting_Outputs/` subfolder.
- **Progressive Delivery**: When researching a batch of 5 accounts, the agent saves the file for Account 1 before starting Account 2 to prevent data loss on timeout.
- **Dependencies**: Excel (`.xlsx`) input requires `pip install openpyxl`. For `.docx` output, the `document-skills:docx` skill or Pandoc must be available.

### 6.3 Research Constraints & Anti-Hallucination
- **Evidence-Based "Why Now"**: All assertions about a company's goals or Trigger Events must be grounded in the research retrieved by the agent. If no Trigger Event is found, the agent clearly states "NO SPECIFIC TRIGGER EVENT FOUND" rather than fabricating one.
- **Buying Committee Mapping**: The agent attempts to fill all MEDDPICC Buying Committee roles (Economic Buyer, Champion, Technical Buyer, End User, Coach/Influencer) including LinkedIn profile URLs where found. If a specific role is unidentifiable via public web search, it is marked as "TO BE VALIDATED in Discovery Phase".
- **SPICED Discovery Prep**: The single-account deep dive generates pre-built discovery questions aligned to the SPICED framework (Situation, Pain, Impact, Critical Event, Decision) based on the research gathered.

### 6.4 Copywriting Constraints (Human-Writer Protocol)
- **Strict Prohibition**: Outreach sequences adhere to strict human-writer rules: absolutely no "In today's fast-paced world", no "I hope this email finds you well", no em-dashes (`—`) or en-dashes (`–`).
- **Format Requirements**: Use varying sentence lengths, concrete numbers, and standard ASCII straight quotes (`"..."`). The CTA must be "soft" (e.g., "Open to learning more?", not "Can we schedule 15 minutes on Tuesday?").

## 7. Output Templates

### 7.1 the `account-battle-plan.md` Template
Enforces this structure:
1. **Executive Summary**: Max 3 bullet points defining the Company's current status quo.
2. **Trigger Events (Why Now)**: Explicit links to news, press releases, or financial shifts.
3. **The Strategic Gap**: What they are missing and what Outcome your solution enables.
4. **Buying Committee Map**: List of 3-5 specific individuals (with LinkedIn URLs if found) categorized by MEDDPICC roles.
5. **SPICED Discovery Prep** (when generated via single-account-deep-dive): Pre-built discovery questions for the first live conversation.

### 7.2 the `outcome-email-sequence.md` Template
Enforces this structure:
1. **Social Selling Prep**: 1 Connection Request note (insight only), 2 suggested comments for their recent posts.
2. **Email 1 (The Hook)**: Focus: Trigger Event + Question. Max 50 words.
3. **Email 2 (The Value)**: Focus: Insight/Business Case + Soft CTA. Max 80 words.
4. **Email 3 (The Pushback)**: Focus: Challenging the status quo + Revert to permission. Max 40 words.

Includes a self-verification constraint checklist (unchecked) that the agent marks after generating the output, ensuring compliance with the Human-Writer Protocol.

## 8. Risks and Mitigations
- **Risk**: Deep Research fails to find relevant information for highly private or stealth-mode startups.
  - **Mitigation**: The skill includes a fallback strategy, analyzing broader industry trends or competitor moves to build the "Why Change" narrative if specific company data is unavailable.
- **Risk**: Generated emails sound robotic and standard, defeating the purpose of hyper-personalization.
  - **Mitigation**: Strict constraints defined in `craft-outreach-sequence.md` against standard AI patterns, relying heavily on the human-writer guidelines. The self-verification checklist in the output template acts as a final quality gate.
- **Risk**: Overwhelming the user with too much data.
  - **Mitigation**: The Account Battle Plan template strictly caps the length of each section, forcing the agent to synthesize findings into actionable bullet points (e.g., max 3 Trigger Events).
- **Risk**: Python scorer crashes on real-world CRM data formats.
  - **Mitigation**: The `parse_revenue()` function handles `$`, commas, `M`/`B`/`K` suffixes, `N/A`, and empty strings. Unit tests (23 cases) cover edge cases. An example CSV demonstrates the expected format.
