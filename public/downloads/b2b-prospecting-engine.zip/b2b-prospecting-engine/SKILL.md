---
name: b2b-prospecting-engine
description: Autonomous B2B Prospecting framework designed for Claude Cowork and Deep Research. Automates Tier 1 account research, stakeholder mapping (Buying Committee), and generates hyper-personalized, outcome-based outreach sequences (LinkedIn + Email) linked to real-world trigger events.
---

# The B2B Prospecting Engine (All-Bound Strategy)

Provides a comprehensive, automated workflow to shift from cold outbound to highly targeted, trigger-based "All-Bound" prospecting. Designed to leverage Claude Cowork's local file access (Excel/CSV ingestion) and Deep Research capabilities.

**Core Capabilities**:
- **Batch Account Research**: Ingest a list of target accounts and let Deep Research identify critical "trigger events" (M&A, leadership changes, financial reports).
- **Stakeholder Mapping (Buying Committee)**: Automatically map the decision center based on public data and matching ICP roles.
- **Outcome-Based Outreach**: Generate hyper-personalized emails and LinkedIn connection requests that focus on business outcomes, not product features.
- **The Productive Day Framework**: Structure daily prospecting activities into high-leverage blocks (Research 20%, Execution 60%, Nurturing 20%).
- **Discovery Prep (SPICED)**: Pre-build discovery question sets aligned to the SPICED framework based on account research.

---

## Setup

Before running any workflow, ensure the following:

1. **Output Folder**: Create a `Prospecting_Outputs/` folder in the current working directory. All workflows save deliverables to this folder.
2. **Account Scoring (optional)**: The Python scorer (`scripts/account_scorer.py`) requires `openpyxl` for Excel files: `pip install openpyxl`. CSV files work without additional dependencies.
3. **Document Output (optional)**: For `.docx` output instead of Markdown, ensure the `document-skills:docx` skill is installed or Pandoc is available on your system.

---

## When to Use This Skill

Use this skill when you need to:
- **Plan your prospecting day** with structured, time-blocked activity across research, outreach, and social selling.
- **Build an attack plan** for a list of target accounts (from an Excel/CSV export).
- **Research a specific account** deeply to find a compelling "Why Change" and "Why Now" (Trigger Events).
- **Draft a personalized email sequence** that doesn't sound like a generic sales pitch.
- **Create a LinkedIn social selling strategy** (Connection requests, InMails, and engagement comments).
- **Score and prioritize** a list of prospects to focus on Tier 1 accounts today.

---

## Decision Tree: Which Workflow When?

Depending on the user's input and starting point, route the execution to the appropriate workflow.

| Scenario / Trigger | Workflow File | Output |
|--------------------|---------------|--------|
| **"Help me plan my prospecting day."** | `productive-day-planner.md` | Full-day plan: prioritized accounts, outreach sequences, social selling itinerary. |
| **"Here is a CSV of target accounts. Which should I focus on?"** | `batch-account-research.md` | Sorted list, scoring, and Deep Research trigger definitions. |
| **"Research [Company Y] and tell me what the pain points are right now."** | `single-account-deep-dive.md` | Strategic Account Battle Plan including Buying Committee map, identified gaps, and SPICED Discovery Prep. |
| **"Write me a sequence for [Executive Name] at [Company Y]."** | `craft-outreach-sequence.md` | 3-step Email Sequence + LinkedIn approach, stripped of AI fluff. |
| **"Help me plan my social selling for today."** | `social-selling-planner.md` | Connection request scripts and engagement comment drafts for the Productive Day. |

---

## Core Frameworks

### The Outcome-Based Approach to Cold Outreach
- **Focus on the Gap**: Highlight the difference between their current status quo (problems) and a better future (business outcomes).
- **Leverage Trigger Events**: Never reach out "just because". Anchor the message to a recent event (e.g., *"Noticed your recent expansion into DACH..."*).
- **Commercial Teaching**: Share an insight they don't have, challenging their current perspective (Challenger Sale principle).

### The Productive Day (Time Blocking)
- **Block 1: Research & Strategy (20%)** - Scoring accounts and finding triggers.
- **Block 2: Hyper-Personalized Execution (60%)** - Crafting the targeted messages (Emails, InMails, Calls).
- **Block 3: Nurturing & Follow-up (20%)** - Engaging with existing pipeline and social selling.

### SPICED Discovery Framework
Used in the Single Account Deep Dive to prepare discovery questions:
- **S**ituation: Confirm the prospect's current state and priorities.
- **P**ain: Surface the specific pain and its root causes.
- **I**mpact: Quantify the cost of the problem (financial, operational, strategic).
- **C**ritical Event: Establish urgency via trigger events and timelines.
- **E**vent/Decision: Understand the buying process and decision criteria.

---

## Skill Content Structure

- `references/workflows/productive-day-planner.md`: Orchestrate a full prospecting day across all three time blocks.
- `references/workflows/batch-account-research.md`: The core routine for analyzing lists using the Python scorer.
- `references/workflows/single-account-deep-dive.md`: Workflow for deep-researching one specific Tier 1 account, mapping the Buying Committee, and preparing SPICED discovery questions.
- `references/workflows/craft-outreach-sequence.md`: Workflow to translate research into the 3-step outcome-centric email sequence.
- `references/workflows/social-selling-planner.md`: Workflow specifically for preparing LinkedIn engagement (InMails, Connection notes, Comments).
- `assets/templates/account-battle-plan.md`: The output template for account research.
- `assets/templates/outcome-email-sequence.md`: Best-practice frameworks for cold emails.
- `assets/example-input.csv`: Example CSV format for account scoring input.
- `scripts/account_scorer.py`: Script to rank accounts based on configurable criteria (Revenue, Employee Count, Industry fit).
- `scripts/test_account_scorer.py`: Unit tests for the account scorer.
