# ACCOUNT BATTLE PLAN
**Company**: [Company Name]
**Date**: [Generation Date]

---

## 1. Executive Summary
*Provide max 3 bullet points defining the Company's current status quo, their market position, and core strategic priorities derived from recent research.*
- [Status Quo / Strategy 1]
- [Status Quo / Strategy 2]
- [Status Quo / Strategy 3]

## 2. Trigger Events (Why Now)
*List 1-3 explicit recent events (M&A, leadership changes, earnings calls, major expansions) that create urgency.*
- **[Trigger Event 1]**: [Details & Source/Date]
- **[Trigger Event 2]**: [Details & Source/Date]

*(If no specific triggers found, explicitly state: "NO SPECIFIC TRIGGER EVENT FOUND. Falling back to industry trend: [Trend]")*

## 3. The Strategic Gap (Why Change)
*Synthesize the research into the 'Gap'.*
- **Current State (Pain)**: [What are they struggling with or what risks do they face?]
- **Future State (Outcome)**: [Where are they trying to go based on public goals?]
- **Your Value Proposition**: [How does your solution specifically bridge this gap and enable the outcome?]

## 4. Buying Committee Map (MEDDPICC Roles)
*Specific individuals identified via public web search. If unidentifiable, mark as "TO BE VALIDATED in Discovery Phase".*

- **Economic Buyer** (Controls Budget):
  - *Name:* [Name | TO BE VALIDATED in Discovery Phase]
  - *Title:* [Title]
  - *LinkedIn:* [URL | NOT FOUND via public search]
  - *Likely Priority:* [e.g., ROI, Cost Reduction]

- **Champion** (Directly impacted, pushes deal):
  - *Name:* [Name | TO BE VALIDATED in Discovery Phase]
  - *Title:* [Title]
  - *LinkedIn:* [URL | NOT FOUND via public search]
  - *Likely Priority:* [e.g., Operational Efficiency, Team Output]

- **Technical/Functional Buyer** (Evaluates fit/security):
  - *Name:* [Name | TO BE VALIDATED in Discovery Phase]
  - *Title:* [Title]
  - *LinkedIn:* [URL | NOT FOUND via public search]
  - *Likely Priority:* [e.g., Security, Integration, Compliance]

- **End User** (Daily usage):
  - *Name:* [Name | TO BE VALIDATED in Discovery Phase]
  - *Title:* [Title]
  - *LinkedIn:* [URL | NOT FOUND via public search]

- **Coach/Influencer** (Internal insights):
  - *Name:* [Name | TO BE VALIDATED in Discovery Phase]
  - *Title:* [Title]
  - *LinkedIn:* [URL | NOT FOUND via public search]

---
**Next Action**: Proceed to `craft-outreach-sequence.md` for the chosen Persona.
