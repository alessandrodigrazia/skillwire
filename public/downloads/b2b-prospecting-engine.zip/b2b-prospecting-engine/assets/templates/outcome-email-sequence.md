# OUTCOME-BASED OUTREACH SEQUENCE
**Target Persona**: [Name], [Title]
**Company**: [Company Name]
**Primary Trigger Event Used**: [Brief description of the trigger event]

*Constraint Checklist (Human-Writer Protocol):*
- [ ] No "I hope this email finds you well"
- [ ] No em-dashes (`—`) or en-dashes (`–`)
- [ ] Short, punchy sentences mixed with varying lengths
- [ ] Soft CTA (Asking for permission/insight, not a 15-min meeting)
- [ ] No feature dumping; pure outcome focus

---

## 1. Social Selling Prep (Pre-Email)

**Connection Request (Max 300 chars)**:
> [Insight-driven connection note. Mention a trigger event, a shared interest, or their content. Never pitch.]

**Engagement Comments (For their recent posts)**:
- *Comment 1 (Validate & Add insight)*: [Draft comment]
- *Comment 2 (Validate & Ask question)*: [Draft comment]

---

## 2. The 3-Step Email Sequence

### Email 1: The Hook
*(Send on Day 1. Max 50 words. Focus on Trigger Event + Question.)*

**Subject**: [2-4 casual lowercase words]

**Body**:
> [First Name],
>
> [Sentence 1: Reference the specific trigger event or recent news].
>
> [Sentence 2: State an observation or hypothesis about a resulting challenge they might be facing].
>
> [Sentence 3 (Soft CTA): Open-ended question regarding their approach to solving it].

### Email 2: The Value
*(Send on Day 4, as a reply to Email 1. Max 80 words. Focus on Business Case/Insight.)*

**Body**:
> [First Name],
>
> [Sentence 1: Provide an insight, benchmark, or a brief mention of a similar peer solving this].
>
> [Sentence 2: State the specific business outcome your solution enables (e.g., We helped X reduce Y by Z%)].
>
> [Sentence 3 (Soft CTA): Ask if this specific challenge is a current priority for their team].

### Email 3: The Pushback / Break-up
*(Send on Day 9, as a new thread or reply. Max 40 words. Focus on challenging status quo gently.)*

**Body**:
> [First Name] - [Sentence 1: Assume they are sticking with the status quo or dealing with other priorities].
>
> [Sentence 2: Briefly reiterate the risk of inaction or the main outcome].
>
> [Sentence 3 (Permission CTA): "I'll assume this isn't a priority right now and will stop reaching out. Feel free to reply if things change."]
