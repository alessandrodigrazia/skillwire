"""Unit tests for account_scorer.py"""

import csv
import os
import tempfile
import unittest
from account_scorer import parse_revenue, parse_employee_count, score_accounts, read_accounts


class TestParseRevenue(unittest.TestCase):

    def test_plain_integer(self):
        self.assertEqual(parse_revenue("100000000"), 100_000_000)

    def test_with_dollar_sign(self):
        self.assertEqual(parse_revenue("$100000000"), 100_000_000)

    def test_with_commas(self):
        self.assertEqual(parse_revenue("100,000,000"), 100_000_000)

    def test_with_dollar_and_commas(self):
        self.assertEqual(parse_revenue("$100,000,000"), 100_000_000)

    def test_million_suffix(self):
        self.assertEqual(parse_revenue("100M"), 100_000_000)

    def test_dollar_million_suffix(self):
        self.assertEqual(parse_revenue("$100M"), 100_000_000)

    def test_billion_suffix(self):
        self.assertEqual(parse_revenue("1.5B"), 1_500_000_000)

    def test_thousand_suffix(self):
        self.assertEqual(parse_revenue("500K"), 500_000)

    def test_na_string(self):
        self.assertEqual(parse_revenue("N/A"), 0)

    def test_dash(self):
        self.assertEqual(parse_revenue("-"), 0)

    def test_empty_string(self):
        self.assertEqual(parse_revenue(""), 0)

    def test_none_value(self):
        self.assertEqual(parse_revenue(None), 0)

    def test_null_string(self):
        self.assertEqual(parse_revenue("NULL"), 0)

    def test_float_string(self):
        self.assertEqual(parse_revenue("50000000.0"), 50_000_000)

    def test_garbage_string(self):
        self.assertEqual(parse_revenue("not a number"), 0)


class TestScoreAccounts(unittest.TestCase):

    def test_tier_a_account(self):
        accounts = [{'Company': 'BigCorp', 'Revenue': '150000000', 'Employee_Count': '5000', 'Industry': 'Manufacturing'}]
        scored = score_accounts(accounts, ['manufacturing', 'technology'])
        self.assertEqual(scored[0]['Priority'], 'A')
        self.assertEqual(scored[0]['Score'], 90)  # 50 (revenue) + 20 (employees) + 20 (industry)

    def test_tier_b_account(self):
        accounts = [{'Company': 'MidCorp', 'Revenue': '60000000', 'Employee_Count': '200', 'Industry': 'Manufacturing'}]
        scored = score_accounts(accounts, ['manufacturing'])
        self.assertEqual(scored[0]['Priority'], 'B')
        self.assertEqual(scored[0]['Score'], 55)  # 30 + 5 + 20

    def test_tier_c_account(self):
        accounts = [{'Company': 'SmallCo', 'Revenue': '5000000', 'Employee_Count': '50', 'Industry': 'Retail'}]
        scored = score_accounts(accounts, ['manufacturing', 'technology'])
        self.assertEqual(scored[0]['Priority'], 'C')
        self.assertEqual(scored[0]['Score'], 0)

    def test_sorting_descending(self):
        accounts = [
            {'Company': 'Small', 'Revenue': '1000000', 'Employee_Count': '10', 'Industry': 'Retail'},
            {'Company': 'Big', 'Revenue': '200000000', 'Employee_Count': '8000', 'Industry': 'Technology'},
            {'Company': 'Mid', 'Revenue': '60000000', 'Employee_Count': '600', 'Industry': 'Finance'},
        ]
        scored = score_accounts(accounts, ['technology', 'finance'])
        self.assertEqual(scored[0]['Company'], 'Big')
        self.assertEqual(scored[1]['Company'], 'Mid')
        self.assertEqual(scored[2]['Company'], 'Small')

    def test_missing_columns(self):
        accounts = [{'Company': 'NoCols'}]
        scored = score_accounts(accounts, ['manufacturing'])
        self.assertEqual(scored[0]['Score'], 0)
        self.assertEqual(scored[0]['Priority'], 'C')

    def test_empty_list(self):
        scored = score_accounts([], ['manufacturing'])
        self.assertEqual(scored, [])


class TestReadAccounts(unittest.TestCase):

    def test_read_csv(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['Company', 'Revenue', 'Industry'])
            writer.writeheader()
            writer.writerow({'Company': 'Test Corp', 'Revenue': '50000000', 'Industry': 'Technology'})
            tmpfile = f.name

        try:
            accounts = read_accounts(tmpfile)
            self.assertEqual(len(accounts), 1)
            self.assertEqual(accounts[0]['Company'], 'Test Corp')
        finally:
            os.unlink(tmpfile)

    def test_empty_csv(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False, newline='') as f:
            f.write('Company,Revenue,Industry\n')
            tmpfile = f.name

        try:
            accounts = read_accounts(tmpfile)
            self.assertEqual(len(accounts), 0)
        finally:
            os.unlink(tmpfile)


if __name__ == '__main__':
    unittest.main()
