"""
B2B Account Scorer - Deterministic prioritization of target accounts.

Reads a CSV or Excel (.xlsx) file of target accounts, scores them based on
configurable criteria (Revenue, Employee Count, Industry fit), and outputs
a sorted CSV with Priority tiers (A/B/C).

Usage:
    python account_scorer.py input.csv output_scored.csv
    python account_scorer.py accounts.xlsx output_scored.csv --industries "manufacturing,technology,finance"

Requirements:
    - openpyxl (only for .xlsx input): pip install openpyxl
"""

import csv
import sys
import argparse
import os


def parse_revenue(value: str) -> int:
    """Parse revenue strings from CRM exports into integer values.

    Handles formats: "$100M", "1.5B", "100,000,000", "50K", "N/A", empty strings.
    Returns 0 for any unparseable value.
    """
    if not value:
        return 0
    cleaned = str(value).strip()
    if cleaned.upper() in ('N/A', '-', '', 'NULL', 'NONE'):
        return 0
    cleaned = cleaned.replace('$', '').replace(',', '').replace(' ', '').strip()
    multipliers = {'K': 1_000, 'M': 1_000_000, 'B': 1_000_000_000}
    for suffix, mult in multipliers.items():
        if cleaned.upper().endswith(suffix):
            try:
                return int(float(cleaned[:-1]) * mult)
            except (ValueError, TypeError):
                return 0
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return 0


def parse_employee_count(value: str) -> int:
    """Parse employee count strings. Handles: "5000", "5,000", "5K", "N/A"."""
    return parse_revenue(value)  # Same parsing logic applies


def read_accounts(input_file: str) -> list:
    """Read accounts from CSV or XLSX file. Auto-detects format by extension."""
    ext = os.path.splitext(input_file)[1].lower()

    if ext == '.xlsx':
        try:
            import openpyxl
        except ImportError:
            print("Error: openpyxl is required for .xlsx files. Install with: pip install openpyxl")
            sys.exit(1)

        wb = openpyxl.load_workbook(input_file, read_only=True, data_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        wb.close()

        if not rows:
            return []

        headers = [str(h).strip() if h else f'Column_{i}' for i, h in enumerate(rows[0])]
        accounts = []
        for row in rows[1:]:
            account = {}
            for i, header in enumerate(headers):
                val = row[i] if i < len(row) else ''
                account[header] = str(val) if val is not None else ''
            accounts.append(account)
        return accounts

    else:  # Default: CSV
        accounts = []
        with open(input_file, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                accounts.append(row)
        return accounts


def score_accounts(accounts: list, target_industries: list) -> list:
    """Score and prioritize accounts based on Revenue, Employee Count, and Industry fit.

    Scoring:
        Revenue:        >100M = 50pts, >50M = 30pts, >10M = 15pts
        Employee Count:  >1000 = 20pts, >500 = 10pts, >100 = 5pts
        Industry Match:  exact match in target list = 20pts

    Priority Tiers:
        A (Hot):   score >= 70
        B (Warm):  score >= 40
        C (Cold):  score < 40
    """
    for account in accounts:
        score = 0

        # Revenue scoring
        revenue = parse_revenue(account.get('Revenue', '0'))
        if revenue > 100_000_000:
            score += 50
        elif revenue > 50_000_000:
            score += 30
        elif revenue > 10_000_000:
            score += 15

        # Employee count scoring
        employees = parse_employee_count(account.get('Employee_Count', '0'))
        if employees > 1000:
            score += 20
        elif employees > 500:
            score += 10
        elif employees > 100:
            score += 5

        # Industry fit scoring
        industry = account.get('Industry', '').strip().lower()
        if any(target.lower() in industry for target in target_industries):
            score += 20

        account['Score'] = score
        account['Priority'] = 'A' if score >= 70 else ('B' if score >= 40 else 'C')

    return sorted(accounts, key=lambda x: x.get('Score', 0), reverse=True)


def write_output(accounts: list, output_file: str):
    """Write scored accounts to CSV."""
    if not accounts:
        print("Warning: No accounts to write.")
        return

    keys = accounts[0].keys()
    with open(output_file, mode='w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(accounts)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="B2B Account Scorer - Prioritize target accounts by Revenue, Employee Count, and Industry fit."
    )
    parser.add_argument("input", help="Path to input file (CSV or XLSX)")
    parser.add_argument("output", help="Path to output scored CSV file")
    parser.add_argument(
        "--industries",
        default="manufacturing,technology",
        help="Comma-separated list of target industries (default: manufacturing,technology)"
    )

    args = parser.parse_args()
    target_industries = [i.strip() for i in args.industries.split(',') if i.strip()]

    try:
        accounts = read_accounts(args.input)
        if not accounts:
            print("Warning: Input file is empty or has no data rows.")
            sys.exit(0)

        scored = score_accounts(accounts, target_industries)
        write_output(scored, args.output)

        tier_counts = {'A': 0, 'B': 0, 'C': 0}
        for a in scored:
            tier_counts[a.get('Priority', 'C')] += 1

        print(f"Successfully scored {len(scored)} accounts. Output: {args.output}")
        print(f"  Tier A (Hot):  {tier_counts['A']}")
        print(f"  Tier B (Warm): {tier_counts['B']}")
        print(f"  Tier C (Cold): {tier_counts['C']}")

    except FileNotFoundError:
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)
    except Exception as e:
        print(f"Error processing accounts: {e}")
        sys.exit(1)
