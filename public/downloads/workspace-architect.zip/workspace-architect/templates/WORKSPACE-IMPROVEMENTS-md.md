# WORKSPACE_IMPROVEMENTS.md Template

This file is created with the header only. Content is appended by session-closer.

---

# Workspace Improvements

> Append-only log. New entries at the TOP (after this header).
> Review biweekly or monthly — implement the best suggestions, discard the rest.

## Improvement Types

| Type | Description |
|------|-------------|
| CLAUDE.md Rule | New rule or convention to add to CLAUDE.md |
| Pattern to Codify | Recurring workflow pattern worth documenting |
| Skill Modification | Existing skill that needs update or refinement |
| Stale TODO | TODO item that should be archived or reprioritized |
| Missing Context | Information Claude needed but didn't have |
| Memory Gap | Cross-session knowledge that should be saved |
| Automation Suggestion | Manual task that could be automated |

## Entry Format

```markdown
### [YYYY-MM-DD] - Session: [Title]

1. **[Type]**: [Concrete description of the improvement]
   - Impact: [high/medium/low]
   - Files involved: [path]

Status: [ ] To evaluate | [x] Implemented | [~] Discarded
```

---

<!-- Session-closer will append entries below this line -->
