# CLAUDE.md Template

Replace all `{{PLACEHOLDER}}` values with user data from Phase 1 Discovery.

---

# {{USER_NAME}} - Working Context

> **Time Context**: {{CURRENT_MONTH_YEAR}}

## Who I Am

{{ROLE_DESCRIPTION}}
Focus: {{FOCUS_AREAS}}.

**Full profile:** [PROFILE.md](PROFILE.md)

## How I Work with Claude

- Claude Code in VS Code, working from {{WORKING_DIRECTORY}}
- {{SKILL_COUNT}} custom skills + agents configured
- Primary language: {{LANGUAGE}}

## Folder Structure

| Folder | Content |
|--------|---------|
{{FOLDER_TABLE_ROWS}}

## Active Projects

| Project | Context | Focus |
|---------|---------|-------|
{{PROJECTS_TABLE_ROWS}}

## Operational Preferences

| Aspect | Preference |
|---------|------------|
| Language | {{LANGUAGE_PREFERENCE}} |
| Tone | {{TONE}} |
| Output | Structured, actionable, concrete examples |
| Timezone | {{TIMEZONE}} |

### Style by Context

| Context | Style |
|---------|-------|
{{STYLE_TABLE_ROWS}}

## Current Session

> Full history: [SESSION_LOG.md](SESSION_LOG.md)
>
> **Format:** Each session includes **Refs:** with `sessionId` and `plan` for traceability
>
> **SESSION_LOG Archiving:** At the start of each month, move all sessions from the previous month to `SESSION_LOG_ARCHIVE/SESSION_LOG_YYYY-MM.md`

### {{CURRENT_DATE}} - (New session)

**TODO** (active only, full backlog in [TODO_BACKLOG.md](TODO_BACKLOG.md)):
- [ ] (Add your active tasks here)

---

**Last updated**: {{CURRENT_DATE}} (initial workspace setup via Workspace Architect)
