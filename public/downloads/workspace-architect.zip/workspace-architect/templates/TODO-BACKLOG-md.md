# TODO_BACKLOG.md Template

Replace {{PLACEHOLDER}} values with user data from Phase 1 Discovery.
Create category sections based on user's active projects.

---

# TODO Backlog

> **Triage rules:**
> - **NOW** (in CLAUDE.md): Actionable this week. Max 15 items.
> - **WAITING** (here): Blocked by someone else. Check weekly.
> - **SOMEDAY** (here): Nice-to-have, deprioritized. Review monthly.
> - **ARCHIVE**: Completed or discarded — remove from this file.
>
> **Flow:** SOMEDAY → WAITING → NOW → completed → remove
> **Rule:** If NOW has more than 15 items, triage — don't hoard.

## WAITING (Depends on Others)

<!-- Items blocked by external dependencies -->
<!-- Format: - [ ] [Task] — waiting for [person/event] -->

## SOMEDAY

{{#each PROJECTS}}
### {{PROJECT_NAME}}

<!-- Tasks related to {{PROJECT_NAME}} that aren't urgent -->

{{/each}}

### General

<!-- Tasks not tied to a specific project -->
