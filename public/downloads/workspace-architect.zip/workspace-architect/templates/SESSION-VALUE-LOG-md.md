# SESSION_VALUE_LOG.md Template

Replace {{PLACEHOLDER}} values with user data from Phase 1 Discovery.

---

# Session Value Log

> Track the value generated in each work session.
> Estimation guideline: be conservative — better to underestimate than overstate.

## Rate Benchmarks

| Reference | Rate ({{CURRENCY}}/h) |
|-----------|----------------------|
| Your baseline | {{HOURLY_RATE}} |
| Industry equivalent | {{INDUSTRY_RATE_RANGE}} |

## How to Estimate

- **Deliverables**: Count tangible outputs (documents, emails, analyses, code, presentations)
- **Hours saved**: Compare time Claude took vs. time you'd have spent manually
- **Value**: Hours saved x rate benchmark

## Value Log

| Date | Session | Deliverables | Hours Saved | Value ({{CURRENCY}}) | Notes |
|------|---------|-------------|-------------|---------------------|-------|
<!-- Session-closer will append rows below this line -->
