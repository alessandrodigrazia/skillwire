# PROFILE.md Template

Replace all `{{PLACEHOLDER}}` values with user data from Phase 1 Discovery.
For sections the user didn't provide data for, include the placeholder prompt in italics.

---

# {{USER_NAME}} - Professional Profile

## Background

{{BACKGROUND_NARRATIVE}}

*If this section feels thin, expand it over time. Include: years of experience, key career milestones, industries you've worked in, what you're known for.*

## Current Role

{{CURRENT_ROLE_DESCRIPTION}}

## Active Channels

| Channel | Purpose | Frequency |
|---------|---------|-----------|
{{CHANNELS_TABLE_ROWS}}

*Add channels where you create or consume professional content: LinkedIn, blog, newsletter, podcast, etc.*

## How I Think

{{THINKING_STYLE}}

*Describe your reasoning approach: Do you prefer data-driven decisions or intuition? Are you a big-picture or detail-oriented thinker? Do you decide fast or deliberate?*

### Decision Patterns

| Situation | Behavior |
|-----------|----------|
{{DECISION_PATTERNS_ROWS}}

*Examples: "When under time pressure → I prioritize speed over perfection." "When facing conflicting data → I seek a third source."*

## What I Appreciate

{{APPRECIATION_LIST}}

*Examples: direct feedback, structured agendas, data-backed proposals, proactive communication.*

## What Irritates Me

{{IRRITATION_LIST}}

*Examples: vague updates, meetings without agendas, over-engineered solutions, buzzwords without substance.*

## Communication Style

| Context | Style |
|---------|-------|
{{COMMUNICATION_STYLE_ROWS}}

*Adjust how you communicate based on audience: formal with clients, direct with team, concise in writing.*

## Writing Rules

{{WRITING_RULES}}

*Your brand voice guidelines: preferred sentence length, vocabulary choices, formatting conventions, words to avoid.*

## Tool Preferences

| Task | Preferred Tool |
|------|---------------|
{{TOOL_PREFERENCES_ROWS}}

*Map common tasks to your tool of choice. This helps Claude use the right tool when helping you.*
