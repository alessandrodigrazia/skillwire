# PRD: Workspace Architect

## 1. Executive Summary

Workspace Architect transforms Claude Code from a chatbot into a professional operating system in 30 minutes. It's a guided, interactive skill that creates a complete workspace ecosystem — context files, session management, agents, folder structure, MCP servers — all personalized to the user's role and workflow.

The skill targets professionals who use Claude Code daily but lack the system-level infrastructure to make sessions productive, traceable, and self-improving. It closes the gap between "I installed Claude Code" and "I have a professional AI-powered workspace with memory, context, and continuous improvement."

Key differentiators:
1. **Document Intelligence** — the user provides CV, LinkedIn URL, company website and Claude automatically extracts a rich professional profile (not just a questionnaire)
2. **Interactive personalization** — not static templates, but a guided process that adapts to context
3. **Working agents** — not just docs, but a functional session-closer that works out of the box
4. **Self-improving workspace** — the workspace gets better session by session
5. **ROI tracking** — the user can prove AI value with time/cost metrics
6. **Gateway to Skillwire** — natural growth path to specialized skills

## 2. Problem Statement

**The Problem:** Claude Code users start every session from scratch. No persistent context, no session tracking, no structured memory, no improvement loop. Each conversation is an island.

**Concrete Scenarios:**

1. **The Repeat Explainer**: A sales manager opens Claude Code daily. Every morning, they re-explain their role, projects, clients, and preferences. Claude forgets everything between sessions. They waste 10-15 minutes of every session on context-setting.

2. **The Lost Context**: A developer finishes a complex refactoring session. Next day, they can't remember what was decided, what's pending, what trade-offs were made. There's no session log, no TODO tracking. They re-investigate problems already solved.

3. **The Flat Workspace**: A marketing lead uses Claude Code in a single flat directory. No folder structure, no profile, no preferences file. Claude treats them like a stranger every time. They've never heard of MCP servers, agents, or session-closer patterns.

**Why existing solutions fail:**
- CLAUDE.md exists but users don't know what to put in it
- Agents exist but creating them from scratch requires deep Claude Code expertise
- MCP servers exist but discovery and installation are technical and fragmented
- No integrated system ties these pieces together into a coherent operating system

## 3. Target User

**Include (who it's for):**
- Professionals who use Claude Code at least 3x/week
- Any role: sales, dev, marketing, PM, exec, freelancer
- Users who feel they're "not getting the most" out of Claude Code
- Users who want their AI to remember context across sessions
- Both technical and non-technical users (the skill handles complexity)

**Exclude (who needs something else):**
- Casual Claude Code users (once-a-week or less — the infrastructure isn't worth it)
- Teams looking for multi-user collaboration tools (this is individual workspace setup)
- Users who only use Claude via web/app, not Claude Code CLI or VS Code
- Advanced users who already have a mature CLAUDE.md, session-closer, and agents (they'd benefit more from specialized skills)

## 4. Success Metrics

| Metric | Target | How to Measure |
|--------|--------|----------------|
| Setup completion rate | >80% of users complete all phases | User reports / feedback |
| Session-closer adoption | >60% use session-closer within 1 week | Self-reported |
| Time-to-first-value | <30 minutes from skill invocation to working ecosystem | Timed during testing |
| Workspace improvement suggestions | >2 per week after 1 month | WORKSPACE_IMPROVEMENTS.md entries |
| Skillwire follow-on purchases | >15% buy at least 1 additional skill within 30 days | Whop analytics |
| User satisfaction | >4.5/5 stars | Skillwire reviews |

## 5. Skill Structure

### Files

```
workspace-architect/
├── SKILL.md                              # Main workflow (~400 lines)
├── references/
│   ├── document-intelligence.md          # Extraction patterns for CV, LinkedIn, website, CLAUDE.md, work samples
│   ├── discovery-questions.md            # Mode A (confirmation after docs) + Mode B (full interview)
│   ├── architecture-guide.md             # WHY each component exists (educational)
│   ├── role-profiles.md                  # 6 role archetypes with defaults
│   ├── growth-roadmap.md                 # Maturity model + Skillwire recommendations
│   └── mcp-servers/
│       ├── overview.md                   # What MCP servers are, why they matter
│       ├── tier1-universal.md            # MarkItDown, Playwright, Word Doc Server
│       ├── tier2-role-based.md           # Zapier MCP, Apify
│       └── tier3-specialized.md          # n8n-mcp
├── templates/
│   ├── CLAUDE-md.md                      # CLAUDE.md template with {{placeholders}}
│   ├── PROFILE-md.md                     # PROFILE.md template
│   ├── SESSION-LOG-md.md                 # SESSION_LOG.md template
│   ├── WORKSPACE-IMPROVEMENTS-md.md      # WORKSPACE_IMPROVEMENTS.md template
│   ├── SESSION-VALUE-LOG-md.md           # SESSION_VALUE_LOG.md template
│   ├── TODO-BACKLOG-md.md               # TODO_BACKLOG.md template
│   └── agents/
│       ├── session-closer.md             # Universal session-closer agent
│       ├── deal-reviewer.md              # Sales role agent
│       ├── code-reviewer.md              # Dev role agent
│       ├── content-checker.md            # Content/Marketing role agent
│       ├── spec-reviewer.md              # PM role agent
│       └── decision-challenger.md        # Exec role agent
└── docs/
    └── PRD.md                            # This file (design doc, not loaded by Claude)
```

### Progressive Disclosure

- **Always loaded**: SKILL.md (workflow + phases)
- **Loaded on Phase 1**: `references/document-intelligence.md`
- **Loaded on Phase 2**: `references/discovery-questions.md`
- **Loaded on Phase 3**: `references/role-profiles.md`, `references/architecture-guide.md`
- **Loaded on Phase 4**: `templates/CLAUDE-md.md`, `templates/PROFILE-md.md`, etc. (only relevant templates)
- **Loaded on Phase 5**: `templates/agents/session-closer.md` + role-specific agent template
- **Loaded on Phase 5.5**: `references/mcp-servers/overview.md` + relevant tier files
- **Loaded on Phase 7**: `references/growth-roadmap.md`

## 6. Detailed Requirements

### Phase 1: Document Intelligence

**Input**: User-provided documents (optional): CV/resume, LinkedIn URL, company website URL, work samples, existing CLAUDE.md
**Output**: `extracted_context` object that pre-populates `user_profile`

**Tools used (all native to Claude Code — NO MCP servers required):**
- `Read` — reads PDF, Word, TXT, images natively
- `WebFetch` — fetches public web pages (LinkedIn, company sites)
- `Glob` — searches for existing CLAUDE.md and folder patterns
- `Grep` — searches for patterns in existing files

**Document extraction targets:**

| Document | Key Fields Extracted | Maps To |
|----------|---------------------|---------|
| CV/Resume | Role, seniority, industry, company, top 5 skills, career trajectory, education, languages | `user_profile.role`, `user_profile.industry`, PROFILE.md Background |
| LinkedIn | Headline, About (tone reference), experience, skills, recent activity, content frequency | `user_profile.role`, `user_profile.tone`, content habits |
| Company website | Industry, size, products/services, target market, values | `user_profile.industry`, `user_profile.company_size` |
| Existing CLAUDE.md | All existing config sections | Upgrade path with gap analysis |
| Work samples | Content type, formality, structure, complexity, audience | Tone calibration, agent selection, PROFILE.md Writing Rules |
| Folder structure | Organization patterns (numbered, project-based, flat) | Folder structure recommendation |

**Cross-referencing rules (when multiple documents provided):**
- Role: CV title + LinkedIn headline → strongest signal
- Tone: LinkedIn About > CV style > work sample style
- Industry: Company website > CV > LinkedIn
- Projects: CV recent experience + LinkedIn activity + work samples = project list
- Skills: CV skills section + LinkedIn skills + tools in work samples (union)

**Conflict resolution:**
- If CV says "Software Engineer" but LinkedIn says "Engineering Manager" → use LinkedIn (more current)
- If tone differs between CV (formal) and LinkedIn (casual) → ask user preference in Phase 2

**UPGRADE MODE (when CLAUDE.md already exists):**
- DO NOT replace existing sections — identify gaps and propose additions
- Show a gap analysis table: what exists vs. what's missing
- Propose enhancements, not replacements

**If user provides NO documents:** Skip to Phase 2 in Mode B (full interview). No penalty.

### Phase 2: Discovery & Confirmation

**Two modes based on Phase 1 outcome:**

**Mode A — With documents (extracted_context available):**

Three question types combined:

| Type | Purpose | Examples |
|------|---------|---------|
| Confirmation | Validate extracted data | "Your CV shows 12 years in B2B sales. Correct?" |
| Adaptive follow-up | Deepen based on findings | "Since you publish on LinkedIn regularly, want a content checker agent?" |
| Standard non-extractable | Gather info that can't be extracted | Claude Code experience, cloud sync, priority, rate benchmark, git usage |

Role-specific follow-ups: only asked if NOT already answered by document extraction.

**Mode B — Without documents (Phase 1 skipped):**

Full 12-15 question interview in 3 blocks:
- Block 1: Identity (role, industry, projects, tools)
- Block 2: Technical Setup (git, language, cloud sync, experience)
- Block 3: Preferences (work style, tone, priority, rate benchmark)
Plus role-specific follow-ups.

**Branching logic (both modes):**

| Signal | Follow-up |
|--------|-----------|
| Role = sales | Ask about CRM, pipeline, content types created |
| Role = dev | Ask about languages/frameworks, testing practices |
| Role = marketing | Ask about content channels, brand guidelines |
| Role = PM | Ask about methodology, requirements tracking tool |
| Role = exec | Ask about decision areas, board/investor materials |
| Role = freelancer | Ask about services offered, client management |
| Mentions Google tools | Flag `google_workspace: true` → recommend Zapier MCP |
| Mentions Microsoft tools | Flag `microsoft_365: true` → recommend Zapier MCP |
| Mentions n8n | Flag `uses_n8n: true` → recommend n8n-mcp |

**Output**: Complete `user_profile` object (not saved, used to drive remaining phases)

**Safety**: If user has existing CLAUDE.md (detected in Phase 1), warn and offer: (a) backup + replace, (b) merge, (c) skip

### Phase 3: Blueprint

**Input**: `user_profile` from Phase 1 + Phase 2
**Output**: Blueprint document shown to user for approval

Content:
- Proposed folder structure (visual tree)
- List of files to be created (with 1-line description each)
- Agents to be created (name + function)
- MCP servers recommended (tier + reason)
- Rate benchmarks for ROI tracking
- Estimated generation time

Architecture explanation: full for beginners, concise for intermediate, skipped for advanced.

**Checkpoint**: User MUST approve before Phase 4 starts. Can modify any element.

### Phase 4: Core Generation

**For each file**, Claude:
1. Reads the relevant template from `templates/`
2. Replaces all `{{placeholders}}` with user data from Phases 1-2
3. Writes the file to the user's working directory
4. Reports what was created

**CLAUDE.md requirements:**
- Must include sections: Chi Sono, Come Lavoro con Claude, Struttura Cartelle, Progetti Attivi, Preferenze Operative, Sessione Corrente
- Projects table populated from extracted + interview data
- Tool preferences populated from extracted + interview data
- Session Corrente section starts empty with format guide

**PROFILE.md requirements:**
- Must include: Background, Current Role, How I Think, Communication Style, Writing Rules
- All populated from Phase 1 extraction (documents) + Phase 2 answers
- If LinkedIn About was provided: use as primary tone reference for Communication Style
- Placeholder prompts for sections the user didn't provide data for

**SESSION_LOG.md requirements:**
- Header with format guide
- One example entry showing the expected format
- Inverse chronological (newest at top)

**WORKSPACE_IMPROVEMENTS.md requirements:**
- Header with improvement types (Rule, Pattern, Skill modification, Stale TODO, etc.)
- Format template with impact rating
- Empty body (populated by session-closer)

**SESSION_VALUE_LOG.md requirements:**
- Header with rate benchmarks (from Phase 2)
- Table format with columns: Date, Session, Deliverable, Hours Saved, Value, Notes
- Empty body (populated by session-closer)

**TODO_BACKLOG.md requirements:**
- Header with triage rules (NOW/WAITING/SOMEDAY/ARCHIVE)
- Category sections based on user's projects from Phases 1-2
- Empty body (populated by user)

**Safety**: For EVERY file, check if it already exists. If yes: backup to `{filename}.backup.md`, then write.

### Phase 5: Agent Setup

**session-closer.md** (always created):
- Adapted from universal template
- Paths adjusted to user's working directory
- Git step included only if user uses Git
- Rate benchmarks from Phase 2
- File list matches what was created in Phase 4

**Role-specific agent** (1-2 based on role):
- Sales → deal-reviewer.md: Reviews pitches, proposals, email drafts for sales effectiveness
- Dev → code-reviewer.md: Reviews architecture decisions, code quality, technical debt
- Content → content-checker.md: Checks authenticity, brand voice consistency, AI detection risk
- PM → spec-reviewer.md: Reviews requirements completeness, edge cases, stakeholder alignment
- Exec → decision-challenger.md: Stress-tests strategic decisions, plays devil's advocate

**Safety**: Create `.claude/agents/` directory if it doesn't exist. Never overwrite existing agents.

### Phase 5.5: MCP Server Setup

**Flow:**
1. Explain what MCP servers are (1 paragraph, non-technical)
2. Present Tier 1 recommendations (always)
3. Present Tier 2 recommendations (based on role)
4. Present Tier 3 recommendations (if applicable)
5. User selects which to install
6. For each selected server:
   a. Check prerequisites (uvx, npx available?)
   b. Run install command
   c. Verify connection
   d. If error: troubleshoot (common: uvx not installed, PATH issues)
7. Summary of installed servers

**Tier 1 details:**
- MarkItDown: `claude mcp add markitdown -- uvx markitdown-mcp`
- Playwright: `claude mcp add playwright -- npx -y @playwright/mcp`
- Word Document Server: `claude mcp add word-document-server -- uvx --from office-word-mcp-server word_mcp_server`

**Tier 2 details:**
- Zapier MCP: Guide user to zapier.com/mcp → get personal MCP URL → `claude mcp add MCP_ZAPIER --type http --url {USER_URL}`
- Apify: Guide user to apify.com → create API token → `claude mcp add apify --type http --url "https://mcp.apify.com/?tools=actors,docs,apify/rag-web-browser" -H "Authorization: Bearer {TOKEN}"`

**Tier 3 details:**
- n8n-mcp: `claude mcp add n8n-mcp -- npx n8n-mcp` with env `MCP_MODE=stdio,LOG_LEVEL=error`

**Safety**: Never store API keys in the skill. Guide user to enter their own credentials.

### Phase 6: Activation

**Interactive tutorial:**
1. Claude says: "Let's do a practice session closure. I'll act as if we just finished a work session."
2. Claude simulates session summary data
3. Claude invokes the session-closer agent (or demonstrates how to)
4. Shows the user what SESSION_LOG.md, WORKSPACE_IMPROVEMENTS.md, and SESSION_VALUE_LOG.md look like after population
5. Explains the self-improvement cycle

**Alternative** (if session-closer invocation is complex): Claude manually demonstrates the output format by writing example entries into the 3 files, then explains how session-closer automates this.

### Phase 7: Growth Roadmap

**Output**: A "NEXT_STEPS.md" file in the user's working directory

Content:
- Week 1: Daily session-closer ritual
- Week 2-3: Review WORKSPACE_IMPROVEMENTS.md, implement best suggestions
- Month 1: Evaluate specialized skills (with Skillwire recommendations per role)
- Month 2-3: Add custom agents, optimize TODO triage
- Maturity model: Level 1 (Basic) → 2 (Structured) → 3 (Self-improving) → 4 (Autonomous)

**Skillwire recommendations by role:**
| Role | Recommended Skills |
|------|-------------------|
| Sales | Janus (critical analysis), B2B Presentation Builder, Deep Research Agent |
| Dev | LLM Arena VS (multi-AI), Iterative Self-Critique, Maia (multi-agent) |
| Marketing | Human-Writer, Content Pipeline Pro, Deep Research Agent |
| PM | Janus, Iterative Self-Critique, Deep Research Agent |
| Exec | Janus, Deep Research Agent, B2B Presentation Builder |
| Freelancer | CV Guru, Memory Manager, LLM Arena VS |

## 7. Output Templates

### What the user gets after completing all phases:

```
user-workspace/
├── CLAUDE.md                     # Personalized context (role, projects, tools, preferences)
├── PROFILE.md                    # Professional profile (background, style, patterns)
├── SESSION_LOG.md                # Empty template with format guide + example
├── WORKSPACE_IMPROVEMENTS.md     # Empty template with improvement types
├── SESSION_VALUE_LOG.md          # Empty template with rate benchmarks
├── TODO_BACKLOG.md               # Empty template with project categories
├── NEXT_STEPS.md                 # Growth roadmap with Skillwire recommendations
├── .claude/
│   └── agents/
│       ├── session-closer.md     # Working session closure agent
│       └── {role-agent}.md       # Role-specific review agent
└── {custom-folders}/             # Personalized folder structure
    ├── 01_{PROJECT_A}/
    ├── 02_{PROJECT_B}/
    └── 03_{PROJECT_C}/
```

## 8. Risks and Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| User has existing CLAUDE.md | Overwrite destroys their config | Phase 1 auto-detects; UPGRADE MODE merges, never replaces; always backup to .backup.md |
| LinkedIn profile not publicly visible | Document Intelligence yields little data | Graceful fallback: note limited extraction, ask more questions in Phase 2 |
| CV in unusual format | Extraction misses key data | Confirmation questions in Phase 2 catch errors; user corrects inaccuracies |
| MCP server install fails (uvx/npx missing) | User stuck at Phase 5.5 | Detect prerequisites first; provide install commands for uv/node; make Phase 5.5 optional |
| Session-closer agent doesn't work in user's environment | Core value proposition broken | Test agent template on multiple OS; include troubleshooting section |
| User overwhelmed by 8 phases | Abandons mid-setup | Allow skipping optional phases (1, 5.5, 7); provide "minimal setup" path (Phases 2-4 only) |
| Generated CLAUDE.md too generic | User doesn't feel personalization value | Document Intelligence extracts real details; specific data from docs used throughout |
| Language support beyond EN/IT | Lower quality for FR/DE/ES users | Generate in English with clear structure; add note about manual translation |
| Rate benchmarks inappropriate for user's market | ROI tracking feels inaccurate | Ask user's hourly rate in Phase 2; provide industry defaults only as fallback |
| User on Windows vs macOS | Path differences in session-closer, symlinks | Detect OS automatically; use OS-appropriate paths throughout |
| Privacy concerns about sharing CV/LinkedIn | User refuses to share documents | Phase 1 is optional; Mode B (full interview) works without any documents |
