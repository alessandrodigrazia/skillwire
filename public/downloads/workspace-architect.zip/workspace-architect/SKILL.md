---
name: workspace-architect
description: >
  Transform Claude Code from chatbot to professional operating system in 30 minutes.
  Guided setup: context files, session management, agents, MCP servers, folder structure —
  all personalized to your role and workflow.
  This skill should be used when users want to set up or improve their Claude Code workspace,
  ask about best practices for CLAUDE.md, need session management, or want to build a
  professional AI-powered work environment.
---

# Workspace Architect

## Overview

This skill guides users through building a complete workspace ecosystem for Claude Code.
It creates personalized context files, agents, folder structures, and MCP server configurations
that make Claude remember context, track sessions, measure ROI, and improve itself over time.

## How It Works

The skill runs as a sequential workflow with 8 phases. Each phase has a checkpoint where the
user reviews and approves before proceeding. Load reference files only when their phase begins.

**Estimated total time: 25-35 minutes**

---

## Phase 1: Document Intelligence (3-5 min)

**Goal:** Learn about the user by analyzing real documents they provide, instead of asking
dozens of questions from scratch.

**Load:** `references/document-intelligence.md`

### Instructions

1. Greet the user and explain what Workspace Architect does:
   > "I'm going to help you build a professional workspace for Claude Code. This means
   > Claude will remember your context across sessions, track what you've accomplished,
   > suggest improvements to your workflow, and measure the value it generates."

2. Proactively ask the user to share documents for context:
   > "To build a workspace that's truly personalized, I'd love to learn more about you.
   > Do you have any of these to share? The more context you give me, the more precise
   > the result. None of these are required — we can also work with just questions."
   >
   > 1. **Your CV or resume** — drop the file path (PDF, Word, or text)
   > 2. **Your LinkedIn profile** — paste the URL
   > 3. **Your company website** — paste the URL
   > 4. **Recent work samples** — proposals, decks, reports (drop 1-2 file paths)
   >
   > "I'll also check if you already have a CLAUDE.md in your working directory."

3. For each document the user provides, use the extraction patterns from
   `references/document-intelligence.md`:

   **CV/Resume** (via `Read` tool — native, reads PDF/Word/TXT):
   - Extract: role, seniority, industry, company, top 5 skills, career trajectory, education
   - Map to: `user_profile.role`, `user_profile.industry`, PROFILE.md Background section

   **LinkedIn profile** (via `WebFetch` tool — native):
   - Extract: headline, about section (tone reference!), experience, skills, recent activity
   - Map to: `user_profile.role`, `user_profile.tone`, content creation habits
   - Special: analyze About section for natural communication style (sentence length,
     formality, first/third person, storytelling vs. factual)

   **Company website** (via `WebFetch` tool — native):
   - Extract: industry, company size, products/services, target market, values
   - Map to: `user_profile.industry`, `user_profile.company_size`
   - If homepage is sparse, try `/about`, `/chi-siamo`, `/about-us` pages

   **Existing CLAUDE.md** (auto-detect via `Glob` + `Read`):
   - Search for CLAUDE.md in working directory and common locations
   - If found: parse existing sections, identify what's configured and what's missing
   - Activate **UPGRADE MODE**: don't replace, propose additions
   - Generate a gap analysis (see document-intelligence.md for format)

   **Work samples** (via `Read` tool — native):
   - Analyze 1-2 documents for style, formality, structure, complexity
   - Map to: tone calibration, agent selection, PROFILE.md Writing Rules

4. Auto-scan the working directory structure:
   - Run `ls -la` on the working directory (top level only)
   - Look for organizational patterns (numbered folders, project folders, flat directory)

5. Cross-reference multiple documents for consistency:
   - Role: CV title + LinkedIn headline → strongest signal
   - Tone: LinkedIn About > CV style > work sample style
   - Industry: Company website > CV > LinkedIn
   - If conflicts exist, note them for confirmation in Phase 2

6. Construct the `extracted_context` object with all findings (see document-intelligence.md
   for the full schema).

### Important Rules
- All tools used in this phase are NATIVE to Claude Code — NO MCP servers required.
- If the user doesn't provide any documents, that's fine. Skip to Phase 2 in Mode B.
- Don't pressure the user to share documents they're uncomfortable sharing.
- Process documents one at a time to give the user feedback along the way.
- When an existing CLAUDE.md is found, always offer the upgrade path.

### Checkpoint
After processing all documents, briefly summarize what was extracted:
> "Based on the documents you shared, here's what I've understood about you:
> - **Role**: [extracted role] at [company]
> - **Industry**: [extracted industry]
> - **Key skills**: [top 5 skills]
> - **Active areas**: [from recent experience/LinkedIn activity]
> - **Communication style**: [from LinkedIn About/work samples]
>
> Does this look accurate? Anything to correct or add?"

---

## Phase 2: Discovery & Confirmation (3-5 min)

**Goal:** Fill in remaining profile gaps and confirm extracted information.

**Load:** `references/discovery-questions.md`

### Two Modes

**Mode A — With documents (Phase 1 completed):**
Use when `extracted_context` is available from Phase 1.

Claude combines THREE types of questions:

1. **Confirmation questions** (generated from documents):
   - Pattern: "I noticed X in your [document]. Is that correct / still current?"
   - Example: "Your CV shows a transition from technical roles to sales leadership. Is sales
     your primary focus now?"
   - Example: "Your LinkedIn mentions AI/GenAI frequently. Is that your main domain?"
   - Example: "I see your company offers 5 service lines — do you work across all of them?"

2. **Adaptive follow-up questions** (triggered by what emerged):
   - Pattern: "Given X, would you also want Y?"
   - Example: "Since you create content regularly on LinkedIn, should I include a content
     authenticity checker agent?"
   - Example: "I notice your company uses Microsoft 365. Want me to set up Zapier MCP for
     Outlook integration?"
   - Example: "Your CV mentions Salesforce experience. Do you still use a CRM?"

3. **Standard non-extractable questions** (always asked regardless of documents):
   - Claude Code experience level (beginner / intermediate / advanced)
   - Cloud sync service (OneDrive, iCloud, Dropbox, Google Drive, none)
   - Priority (efficiency, creativity, organization, tracking)
   - Rate benchmark for ROI tracking
   - Git usage (yes/no, host)

Then ask role-specific follow-ups (see discovery-questions.md) only if not already answered
by document extraction.

**Mode B — Without documents (Phase 1 skipped):**
Use all 12-15 questions from `references/discovery-questions.md` in 3 conversational blocks:
- Block 1: Identity (role, industry, projects, tools)
- Block 2: Technical Setup (git, language, cloud sync, experience)
- Block 3: Preferences (work style, tone, priority, rate benchmark)
Plus role-specific follow-ups.

### Instructions (both modes)

1. In Mode A: present the extracted profile summary, then ask confirmation + adaptive +
   standard questions. In Mode B: ask all questions from Block 1, 2, 3.

2. Ask questions CONVERSATIONALLY, not as a numbered form.

3. Group 3-4 questions per message to keep the flow natural.

4. Use the user's language (detected from documents or asked) for all subsequent communication.

5. If the user seems impatient, offer a "quick setup" mode: ask only the essential questions
   (role, language, experience, rate) and use defaults for the rest.

6. Construct the internal `user_profile` object from all answers + extracted data.

### Checkpoint
Before moving to Phase 3, confirm the complete profile:
> "Here's what I've understood: [summary of key details]. Should I proceed with this,
> or would you like to adjust anything?"

---

## Phase 3: Blueprint (2 min)

**Goal:** Show the user exactly what will be created, get approval before generating.

**Load:** `references/role-profiles.md`, `references/architecture-guide.md`

### Instructions

1. Select the matching role profile from `references/role-profiles.md`.

2. If user experience is `beginner`, show the architecture explanation from
   `references/architecture-guide.md` (full detail). If `intermediate`, show concise version.
   If `advanced`, skip the explanation.

3. Generate and display a Blueprint document:

```markdown
# Your Workspace Blueprint

## Folder Structure
[Tree based on role profile, customized with user's project names]

## Files to Create (7)
| File | Purpose |
|------|---------|
| CLAUDE.md | Your main context file — Claude reads this every session |
| PROFILE.md | Your professional identity and communication style |
| SESSION_LOG.md | Session history log (newest first) |
| WORKSPACE_IMPROVEMENTS.md | Self-improvement suggestions from session-closer |
| SESSION_VALUE_LOG.md | ROI tracking per session |
| TODO_BACKLOG.md | Backlog with triage (NOW/WAITING/SOMEDAY) |
| NEXT_STEPS.md | Growth roadmap and recommended next skills |

## Agents to Create (2)
| Agent | Purpose |
|-------|---------|
| session-closer | Closes sessions, updates all context files, tracks ROI |
| [role-agent] | [Role-specific review function] |

## MCP Servers Recommended
### Always Recommended (free, local)
- MarkItDown — Convert PDF/Word/Excel to text
- Playwright — Browser automation and screenshots
- Word Document Server — Create/edit Word docs, export PDF

### Based on Your Role ([role])
[Tier 2 and Tier 3 recommendations from role profile]

## Rate Benchmark
[hourly_rate] [currency]/h for ROI tracking
```

4. Ask the user to review and approve:
> "This is what I'll create for you. Want me to proceed, or should I adjust anything?"

### Checkpoint
User MUST explicitly approve before Phase 4 begins.

---

## Phase 4: Core Generation (5 min)

**Goal:** Create all 7 context files personalized to the user.

**Load:** All templates from `templates/` directory (CLAUDE-md.md, PROFILE-md.md, etc.)

### Instructions

For each file:
1. Read the template from `templates/`
2. Replace ALL `{{PLACEHOLDER}}` values with user data from the profile
3. **Safety check**: If the file already exists in the working directory:
   - Create a backup: `{filename}.backup.md`
   - Inform the user: "Found existing {filename}. Backed up to {filename}.backup.md"
4. Write the file to the user's working directory
5. Report: "Created {filename}"

### File Generation Order
1. CLAUDE.md (most important — Claude reads this every session)
2. PROFILE.md
3. SESSION_LOG.md (with initial entry for this setup session)
4. WORKSPACE_IMPROVEMENTS.md (header only)
5. SESSION_VALUE_LOG.md (header with rate benchmarks)
6. TODO_BACKLOG.md (with project-based categories)
7. NEXT_STEPS.md (growth roadmap, generated in Phase 7 but file created now as placeholder)

### Folder Structure
Create the personalized folder structure in the working directory:
- Use `mkdir -p` for each folder
- Only create top-level folders (user organizes subfolders themselves)

### Checkpoint
Show the user what was created:
> "Created 7 files and [N] folders. Here's a summary:
> [List each file with a 1-line description of what's in it]
> Ready to set up your agents?"

---

## Phase 5: Agent Setup (3 min)

**Goal:** Install the session-closer agent and one role-specific agent.

**Load:** `templates/agents/session-closer.md` + role-specific agent template

### Instructions

1. Check if `.claude/agents/` directory exists in the user's home directory.
   If not, create it: `mkdir -p ~/.claude/agents/`

2. **Session-closer agent:**
   - Read `templates/agents/session-closer.md`
   - Replace `{{WORKING_DIR}}` with the user's actual working directory path
   - Replace `{{HOURLY_RATE}}` and `{{CURRENCY}}` with user's values
   - Handle `{{#if USES_GIT}}` conditional blocks based on user profile
   - Write to `~/.claude/agents/session-closer.md`

3. **Role-specific agent:**
   - Select the right template based on role:
     - sales → `templates/agents/deal-reviewer.md`
     - dev → `templates/agents/code-reviewer.md`
     - marketing → `templates/agents/content-checker.md`
     - pm → `templates/agents/spec-reviewer.md`
     - exec → `templates/agents/decision-challenger.md`
     - freelancer → select based on `role_specific.services` (see role-profiles.md)
   - Write to `~/.claude/agents/{agent-name}.md`

4. Explain how to use agents:
   > "Your agents are installed. Here's how to use them:
   > - **session-closer**: At the end of each session, tell Claude: 'close the session with session-closer'
   >   Claude will use the Task tool to invoke the agent and update all your context files.
   > - **[role-agent]**: When you need a review, tell Claude: 'use [agent-name] to review this [deliverable]'"

### Checkpoint
> "Both agents are installed. Want to set up MCP servers now, or skip to activation?"

---

## Phase 5.5: MCP Server Setup (5-10 min, optional)

**Goal:** Install recommended MCP servers to extend Claude Code's capabilities.

**Load:** `references/mcp-servers/overview.md` + relevant tier files

### Instructions

1. Check prerequisites:
   ```bash
   which uvx 2>/dev/null && echo "uvx: OK" || echo "uvx: MISSING"
   which npx 2>/dev/null && echo "npx: OK" || echo "npx: MISSING"
   ```

2. If prerequisites missing, guide installation:
   - uvx missing: "Install uv first: `curl -LsSf https://astral.sh/uv/install.sh | sh`"
   - npx missing: "Install Node.js first: `brew install node` (macOS) or download from nodejs.org"
   - After installation, user must restart their terminal

3. Present Tier 1 servers (always):
   > "These 3 free MCP servers are recommended for everyone:
   > 1. **MarkItDown** — Convert PDF, Word, Excel to text Claude can analyze
   > 2. **Playwright** — Browser automation, screenshots, web research
   > 3. **Word Document Server** — Create professional Word docs, export to PDF
   > Which ones would you like to install? (All recommended)"

4. For each selected Tier 1 server:
   ```bash
   claude mcp add markitdown -- uvx markitdown-mcp
   claude mcp add playwright -- npx -y @playwright/mcp
   claude mcp add word-document-server -- uvx --from office-word-mcp-server word_mcp_server
   ```

5. Present Tier 2 servers (based on role):
   - If role profile says "Zapier MCP: Essential":
     > "For your role, I'd also recommend **Zapier MCP** to connect Gmail, Calendar, Sheets, and Drive.
     > It requires a free Zapier account. Want me to guide you through the setup?"
   - If yes: Load `references/mcp-servers/tier2-role-based.md` and walk through setup

   - If role profile says "Apify: Essential":
     > "And **Apify** for web scraping and prospect research.
     > It requires a free Apify account (5$/month credits). Want to set it up?"
   - If yes: Load `references/mcp-servers/tier2-role-based.md` and walk through setup

6. Present Tier 3 if applicable (only if `uses_n8n: true`):
   > "Since you use n8n, I'd recommend the **n8n-mcp** server for workflow documentation and validation."

7. Verify all installed servers:
   ```bash
   claude mcp list
   ```

### Troubleshooting
If any server fails to install:
- Check error message
- Most common: `spawn uvx ENOENT` → uv not installed or PATH not updated
- Solution: Install uv, then restart terminal completely
- If HTTP servers fail: check API key validity

### Checkpoint
> "MCP servers installed: [list]. Let's test your workspace with a practice session."

---

## Phase 6: Activation (5 min)

**Goal:** Show the user how the ecosystem works in practice.

### Instructions

1. Demonstrate the session-closer workflow:
   > "Let's do a quick practice. I'll simulate closing this setup session to show you
   > how the system works."

2. Write a sample SESSION_LOG.md entry for this setup session:
   - Date: today
   - Title: "Workspace Setup (Workspace Architect)"
   - Completed: list all files and agents created
   - Decisions: role selection, rate benchmark, MCP servers installed

3. Write a sample WORKSPACE_IMPROVEMENTS.md entry:
   - 1-2 genuine improvements based on the setup (e.g., "Consider adding more detail to
     PROFILE.md sections" or "Set up cloud sync for cross-device workspace access")

4. Write a sample SESSION_VALUE_LOG.md row:
   - Estimate the setup value: "Workspace setup that would take 4-8 hours manually, done in 30 minutes"

5. Show the user the updated files:
   > "Here's what happened:
   > - SESSION_LOG.md now has your first session entry
   > - WORKSPACE_IMPROVEMENTS.md has 2 suggestions for you to review
   > - SESSION_VALUE_LOG.md shows the value of this setup session
   > This happens automatically every time you close a session with session-closer."

6. Explain the daily ritual:
   > "From now on, at the end of each work session, just tell Claude:
   > 'Close the session with session-closer'
   > Claude will update all your context files automatically."

### Checkpoint
> "Your workspace is live! One more step: let me create your growth roadmap."

---

## Phase 7: Growth Roadmap (2 min)

**Goal:** Create a personalized NEXT_STEPS.md with maturity roadmap and skill recommendations.

**Load:** `references/growth-roadmap.md`

### Instructions

1. Read `references/growth-roadmap.md`
2. Select the relevant skill recommendations based on the user's role
3. Write the complete NEXT_STEPS.md file to the working directory:
   - Week 1, 2-3, Month 1, 2-3 roadmap
   - Monthly review checklist
   - Recommended skills from skillwire.ai (role-specific table)
   - Cloud sync setup guide (if user uses cloud sync)
   - "What NOT to do" section

4. If user uses cloud sync, mention the symlink setup:
   > "Since you use [cloud service], you can sync your skills and agents across devices.
   > The instructions are in NEXT_STEPS.md under 'Cloud Sync Setup'."

---

## Final Summary

**Goal:** Provide a final overview of everything that was created.

### Instructions

Print the final summary:

```markdown
## Workspace Architect — Setup Complete!

### What Was Created

**Context Files (7):**
- CLAUDE.md — Your main context (Claude reads this every session)
- PROFILE.md — Your professional identity
- SESSION_LOG.md — Session history (first entry added)
- WORKSPACE_IMPROVEMENTS.md — Self-improvement log
- SESSION_VALUE_LOG.md — ROI tracking
- TODO_BACKLOG.md — Task backlog with triage
- NEXT_STEPS.md — Growth roadmap

**Agents (2):**
- session-closer — Closes sessions, updates all files
- [role-agent] — [Description]

**MCP Servers ([N]):**
- [List of installed servers]

**Folder Structure:**
- [List of created folders]

### Quick Start

1. **End every session** with: "Close the session with session-closer"
2. **Review improvements** weekly in WORKSPACE_IMPROVEMENTS.md
3. **Check ROI** monthly in SESSION_VALUE_LOG.md
4. **Next skills** to explore: see NEXT_STEPS.md

### Your Workspace Will Now:
- Remember your context across sessions (CLAUDE.md + SESSION_LOG.md)
- Track what you've accomplished (SESSION_LOG.md)
- Suggest improvements automatically (WORKSPACE_IMPROVEMENTS.md)
- Measure the value Claude generates (SESSION_VALUE_LOG.md)
- Keep your TODO list lean (TODO_BACKLOG.md triage)
- Get smarter every week (self-improvement loop)
```

---

## Safety Rules

1. **NEVER overwrite existing files** without creating a `.backup.md` first
2. **NEVER store API keys** in any generated file — guide users to enter their own
3. **NEVER skip the Blueprint checkpoint** (Phase 3) — user must approve before generation
4. **ALWAYS detect the OS** (macOS/Linux/Windows) and use appropriate paths
5. **ALWAYS use the user's chosen language** for all generated content
6. **If the user wants to skip a phase**, allow it — the phases are recommendations, not requirements
7. **Quick setup mode**: If user seems impatient, offer to use defaults and ask only essential questions
8. **UPGRADE MODE**: If existing CLAUDE.md detected, merge — don't replace

## Token Optimization

- Load reference files ONLY when their phase begins (progressive disclosure)
- Templates are loaded one at a time during generation (not all at once)
- Architecture guide is shown selectively based on experience level
- MCP server docs are loaded only for the tiers the user selects
- Document Intelligence tools (Read, WebFetch) are native — no external dependencies
