# Role Profiles

Six role archetypes with defaults for folder structure, agents, MCP recommendations, and CLAUDE.md sections.

Use `user_profile.role` to select the matching profile, then customize based on user's specific answers.

---

## Sales

### Folder Structure
```
{working_dir}/
├── 01_CLIENTS/          # Client-specific folders
│   ├── {client_name}/   # Per-client materials
├── 02_PIPELINE/         # Active deals and opportunities
├── 03_ASSETS/           # Proposals, decks, templates
├── 04_RESEARCH/         # Market intel, competitor analysis
└── 05_ADMIN/            # Reports, forecasts, internal docs
```

### Agents
- **session-closer.md** (always)
- **deal-reviewer.md**: Reviews proposals, pricing, email drafts for sales effectiveness. Checks value proposition clarity, objection handling, call-to-action strength.

### MCP Recommendations
- Tier 1: All three (MarkItDown for client PDFs, Playwright for prospect research, Word for proposals)
- Tier 2: Zapier MCP (Gmail/Calendar essential for sales), Apify (prospect intelligence)
- Tier 3: Skip unless uses n8n

### CLAUDE.md Sections
- Standard + Pipeline Overview table, Key Clients table, Sales Methodology reference

### Rate Benchmark Default
120-180 EUR/h (equivalent to senior sales consultant / fractional CRO)

---

## Developer

### Folder Structure
```
{working_dir}/
├── 01_PROJECTS/         # Active codebases
│   ├── {project_name}/  # Per-project
├── 02_LEARNING/         # Courses, tutorials, experiments
├── 03_TOOLS/            # Scripts, utilities, dotfiles
├── 04_DOCS/             # Technical documentation, ADRs
└── 05_ARCHIVE/          # Completed or paused projects
```

### Agents
- **session-closer.md** (always)
- **code-reviewer.md**: Reviews architecture decisions, code quality, naming conventions, test coverage, performance implications, security concerns.

### MCP Recommendations
- Tier 1: MarkItDown (technical docs/PDFs), Playwright (testing/debugging), Word (documentation)
- Tier 2: Skip Zapier (devs rarely need Gmail MCP). Apify optional (for scraping docs/APIs).
- Tier 3: n8n-mcp if uses workflow automation

### CLAUDE.md Sections
- Standard + Tech Stack table, Active Repos table, Coding Conventions section

### Rate Benchmark Default
100-150 EUR/h (equivalent to senior developer / contractor)

---

## Marketing

### Folder Structure
```
{working_dir}/
├── 01_CAMPAIGNS/        # Active campaigns
│   ├── {campaign_name}/ # Per-campaign assets
├── 02_CONTENT/          # Blog posts, social, newsletters
├── 03_ANALYTICS/        # Reports, dashboards, data
├── 04_BRAND/            # Style guides, logos, templates
└── 05_RESEARCH/         # Competitor analysis, market research
```

### Agents
- **session-closer.md** (always)
- **content-checker.md**: Reviews content for brand voice consistency, authenticity (anti-AI detection), emotional resonance, CTA effectiveness, and SEO basics.

### MCP Recommendations
- Tier 1: All three (MarkItDown for competitive PDFs, Playwright for social/web research, Word for content briefs)
- Tier 2: Zapier MCP (Gmail for outreach, Sheets for editorial calendar), Apify (competitive monitoring, social scraping)
- Tier 3: n8n-mcp if uses workflow automation for content pipeline

### CLAUDE.md Sections
- Standard + Content Calendar reference, Brand Voice summary, Active Channels table

### Rate Benchmark Default
80-130 EUR/h (equivalent to marketing strategist / content lead)

---

## Product Manager

### Folder Structure
```
{working_dir}/
├── 01_PRODUCTS/         # Product areas
│   ├── {product_name}/  # PRDs, specs, research
├── 02_ROADMAP/          # Roadmap documents, prioritization
├── 03_RESEARCH/         # User research, analytics, surveys
├── 04_STAKEHOLDERS/     # Updates, comms, presentations
└── 05_PROCESSES/        # Templates, playbooks, retrospectives
```

### Agents
- **session-closer.md** (always)
- **spec-reviewer.md**: Reviews requirements for completeness, edge cases, acceptance criteria clarity, stakeholder alignment, technical feasibility signals.

### MCP Recommendations
- Tier 1: All three (MarkItDown for research PDFs, Playwright for competitive analysis, Word for PRDs)
- Tier 2: Zapier MCP (Gmail/Calendar for stakeholder management, Sheets for metrics)
- Tier 3: Skip unless uses n8n

### CLAUDE.md Sections
- Standard + Product Areas table, Key Metrics table, Methodology reference

### Rate Benchmark Default
100-160 EUR/h (equivalent to senior PM / product consultant)

---

## Executive

### Folder Structure
```
{working_dir}/
├── 01_STRATEGY/         # Strategic plans, OKRs, vision docs
├── 02_REPORTS/          # Board decks, investor updates, KPIs
├── 03_PEOPLE/           # Team structures, hiring, reviews
├── 04_DECISIONS/        # Decision logs, memos, frameworks
└── 05_EXTERNAL/         # Partners, investors, press
```

### Agents
- **session-closer.md** (always)
- **decision-challenger.md**: Stress-tests strategic decisions. Plays devil's advocate. Identifies assumptions, second-order effects, alternative scenarios, and risks not yet considered.

### MCP Recommendations
- Tier 1: All three (MarkItDown for reports/PDFs, Playwright for market research, Word for board docs)
- Tier 2: Zapier MCP (Calendar/Gmail essential for exec workflow)
- Tier 3: Skip

### CLAUDE.md Sections
- Standard + Strategic Priorities table, Team Structure, Key Decisions Log reference

### Rate Benchmark Default
150-250 EUR/h (equivalent to fractional CxO / strategic advisor)

---

## Freelancer

### Folder Structure
```
{working_dir}/
├── 01_CLIENTS/          # Active client folders
│   ├── {client_name}/   # Per-client deliverables
├── 02_BUSINESS/         # Invoicing, contracts, proposals
├── 03_PORTFOLIO/        # Showcase, case studies, testimonials
├── 04_LEARNING/         # Skills development, courses
└── 05_ADMIN/            # Taxes, expenses, admin
```

### Agents
- **session-closer.md** (always)
- Agent selection based on `role_specific.services`:
  - If consulting → **decision-challenger.md**
  - If development → **code-reviewer.md**
  - If design/writing → **content-checker.md**
  - Default → **deal-reviewer.md** (proposal/pitch review)

### MCP Recommendations
- Tier 1: All three (MarkItDown for client docs, Playwright for research, Word for proposals/invoices)
- Tier 2: Zapier MCP (Gmail/Calendar for client management)
- Tier 3: Based on services offered

### CLAUDE.md Sections
- Standard + Active Clients table, Services & Rates table, Business Goals

### Rate Benchmark Default
60-120 EUR/h (varies widely by specialization and market)

---

## Mapping Table (Quick Reference)

| Aspect | Sales | Dev | Marketing | PM | Exec | Freelancer |
|--------|-------|-----|-----------|-----|------|------------|
| Folders | Clients/Pipeline/Assets | Projects/Tools/Docs | Campaigns/Content/Brand | Products/Roadmap/Research | Strategy/Reports/Decisions | Clients/Business/Portfolio |
| Agent | deal-reviewer | code-reviewer | content-checker | spec-reviewer | decision-challenger | varies |
| Zapier MCP | Essential | Skip | Essential | Essential | Essential | Essential |
| Apify | Essential | Optional | Essential | Optional | Optional | Optional |
| n8n | Optional | If uses | Optional | Skip | Skip | If uses |
| Rate EUR/h | 120-180 | 100-150 | 80-130 | 100-160 | 150-250 | 60-120 |
