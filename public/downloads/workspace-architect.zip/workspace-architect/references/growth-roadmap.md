# Growth Roadmap

Generate a personalized `NEXT_STEPS.md` for the user based on their role and experience level.

---

## Maturity Model

### Level 1: Basic (Day 1)
**You have:** CLAUDE.md, PROFILE.md, folder structure
**Claude knows:** Who you are, your projects, your preferences
**Value:** No more re-explaining context every session

### Level 2: Structured (Week 1-2)
**You add:** session-closer ritual, SESSION_LOG.md active, TODO triage
**Claude knows:** What happened in past sessions, what's pending
**Value:** Continuity across sessions, nothing falls through cracks

### Level 3: Self-improving (Month 1-2)
**You add:** WORKSPACE_IMPROVEMENTS.md reviewed, MCP servers active, role agent in use
**Claude knows:** How to improve itself, how to take actions (email, docs, web)
**Value:** Workspace gets smarter every week without manual effort

### Level 4: Autonomous (Month 3+)
**You add:** Custom skills, multiple agents, integrated workflows
**Claude knows:** Your entire professional operating system
**Value:** Claude handles complex multi-step tasks independently

---

## Weekly Roadmap

### Week 1: Build the Habit
- [ ] Use session-closer at the end of EVERY session (even short ones)
- [ ] Review SESSION_LOG.md entries — are they capturing the right level of detail?
- [ ] Add 3-5 items to TODO_BACKLOG.md (things you've been meaning to do)
- [ ] Move your most urgent 5-10 items to the NOW section in CLAUDE.md
- [ ] Test your MCP servers: try converting a PDF (MarkItDown), creating a Word doc (Word Server)

### Week 2: Refine Your Context
- [ ] Review CLAUDE.md — does it accurately represent your current priorities?
- [ ] Expand PROFILE.md — add your communication style, decision patterns
- [ ] Review first WORKSPACE_IMPROVEMENTS.md entries — implement the best 1-2
- [ ] Use your role agent at least once (ask it to review a real deliverable)

### Week 3-4: Expand Capabilities
- [ ] If you haven't yet: install Tier 2 MCP servers (Zapier for email/calendar)
- [ ] Create a second custom agent for a specific recurring task
- [ ] Review SESSION_VALUE_LOG.md — is the ROI tracking accurate?
- [ ] Archive completed TODOs, promote SOMEDAY items to NOW if relevant
- [ ] Consider: what repetitive task could Claude automate for you?

---

## Monthly Review Checklist

Every month, spend 15 minutes on workspace health:

- [ ] Archive SESSION_LOG entries older than 1 month → `SESSION_LOG_ARCHIVE/`
- [ ] Review WORKSPACE_IMPROVEMENTS.md: implement top suggestions, discard irrelevant ones
- [ ] Triage TODO_BACKLOG.md: promote SOMEDAY→NOW, archive completed, remove stale
- [ ] Update CLAUDE.md projects table (add new, remove completed)
- [ ] Update PROFILE.md if your role or preferences changed
- [ ] Check MCP server health: are all servers still connected? (`claude mcp list`)
- [ ] Calculate monthly ROI from SESSION_VALUE_LOG.md — update any stakeholders

---

## Recommended Skills by Role

Based on your role, these skills from skillwire.ai would amplify your workspace:

### Sales
| Skill | What It Does | Why You Need It | Price |
|-------|-------------|-----------------|-------|
| Janus | Critical analysis and stress-testing | Stress-test your proposals before sending | - |
| B2B Presentation Builder | Professional C-level decks | Create board-ready presentations | - |
| Deep Research Agent | Multi-source research with citations | Research prospects and markets deeply | - |

### Developer
| Skill | What It Does | Why You Need It | Price |
|-------|-------------|-----------------|-------|
| LLM Arena VS | Multi-AI orchestration (Claude+GPT+Gemini) | Compare AI outputs for complex problems | - |
| Iterative Self-Critique | Self-critique for complex planning | Validate architecture decisions | - |
| MaIA | Multi-agent architecture | Orchestrate complex multi-step projects | - |

### Marketing
| Skill | What It Does | Why You Need It | Price |
|-------|-------------|-----------------|-------|
| Human-Writer | Text humanization | Ensure content passes AI detection | - |
| Deep Research Agent | Multi-source research with citations | Research trends and competitors | - |
| Content Pipeline Pro | Editorial pipeline automation | Manage content at scale | - |

### Product Manager
| Skill | What It Does | Why You Need It | Price |
|-------|-------------|-----------------|-------|
| Janus | Critical analysis and stress-testing | Stress-test PRDs and feature specs | - |
| Iterative Self-Critique | Self-critique for complex planning | Validate roadmap decisions | - |
| Deep Research Agent | Multi-source research with citations | User research and market analysis | - |

### Executive
| Skill | What It Does | Why You Need It | Price |
|-------|-------------|-----------------|-------|
| Janus | Critical analysis and stress-testing | Challenge strategic assumptions | - |
| Deep Research Agent | Multi-source research with citations | Market and competitive intelligence | - |
| B2B Presentation Builder | Professional C-level decks | Board and investor presentations | - |

### Freelancer
| Skill | What It Does | Why You Need It | Price |
|-------|-------------|-----------------|-------|
| CV Guru | CV optimization and interview prep | Win more clients and contracts | - |
| Memory Manager | Persistent cross-session memory | Remember client details across sessions | - |
| LLM Arena VS | Multi-AI orchestration | Get the best output for client work | - |

> Visit [skillwire.ai](https://skillwire.ai) to browse the full catalog and find skills that match your workflow.

---

## Cloud Sync Setup (Optional)

If you use OneDrive, iCloud, Dropbox, or Google Drive, you can sync your `.claude/` directory across devices.

### Why Sync
- Work from laptop at office, desktop at home — same workspace
- Skills, agents, and session history follow you everywhere
- Backup protection against local drive issues

### How to Set Up (OneDrive example)

1. Move your `.claude/skills/` and `.claude/agents/` to your cloud-synced directory
2. Create symlinks from `~/.claude/` to the cloud location:

**macOS/Linux:**
```bash
# Move folders to cloud
mv ~/.claude/skills ~/OneDrive/Workspace/.claude/skills
mv ~/.claude/agents ~/OneDrive/Workspace/.claude/agents

# Create symlinks
ln -s ~/OneDrive/Workspace/.claude/skills ~/.claude/skills
ln -s ~/OneDrive/Workspace/.claude/agents ~/.claude/agents
```

**Windows (PowerShell as Admin):**
```powershell
# Move folders to cloud
Move-Item "$env:USERPROFILE\.claude\skills" "$env:USERPROFILE\OneDrive\Workspace\.claude\skills"
Move-Item "$env:USERPROFILE\.claude\agents" "$env:USERPROFILE\OneDrive\Workspace\.claude\agents"

# Create symlinks
New-Item -ItemType SymbolicLink -Path "$env:USERPROFILE\.claude\skills" -Target "$env:USERPROFILE\OneDrive\Workspace\.claude\skills"
New-Item -ItemType SymbolicLink -Path "$env:USERPROFILE\.claude\agents" -Target "$env:USERPROFILE\OneDrive\Workspace\.claude\agents"
```

**Important:** Only sync `skills/` and `agents/`. Do NOT sync `session-env/`, `cache/`, `history.jsonl`, or other state files — they're local to each machine.

---

## What NOT to Do

Common mistakes that reduce workspace effectiveness:

1. **Don't skip session-closer.** Even a 5-minute session generates context worth preserving.
2. **Don't let CLAUDE.md grow past 200 lines.** Trim aggressively. Move details to referenced files.
3. **Don't ignore WORKSPACE_IMPROVEMENTS.md.** Review it biweekly — the best suggestions come from actual usage patterns.
4. **Don't hoard TODOs.** If NOW has more than 15 items, you need to triage, not add.
5. **Don't create agents for everything.** Start with session-closer + 1 role agent. Add more only when you have a recurring need.
6. **Don't install all MCP servers at once.** Start with Tier 1, add Tier 2 when you feel the need.
