# Document Intelligence

Patterns for extracting professional context from user-provided documents.
All tools used here are NATIVE to Claude Code — NO MCP servers required.

---

## Overview

Instead of asking 15 questions, we ask the user for real documents and extract context automatically.
The result is a richer, more accurate profile with less effort from the user.

**Proactive prompt to the user:**

> "To build a workspace that's truly personalized, I'd love to learn more about you.
> Do you have any of these to share? The more context you give me, the more precise the result.
> None of these are required — we can also work with just questions."
>
> 1. **Your CV or resume** — drop the file path (PDF, Word, or text)
> 2. **Your LinkedIn profile** — paste the URL
> 3. **Your company website** — paste the URL
> 4. **Recent work samples** — proposals, decks, reports (drop 1-2 file paths)
>
> "I'll also check if you already have a CLAUDE.md in your working directory."

---

## Document Type 1: CV / Resume

**Tool:** `Read` (native — reads PDF, Word, TXT directly)

**How to process:**
1. User provides a file path (e.g., `/Users/name/Documents/CV.pdf`)
2. Use `Read` tool to load the document
3. Extract the following fields:

**Extraction targets:**

| Field | Where to find it | Maps to |
|-------|-------------------|---------|
| Current role/title | Header, most recent experience | `user_profile.role` |
| Seniority level | Years of experience, title progression | `user_profile.seniority` |
| Industry | Company descriptions, skills section | `user_profile.industry` |
| Company name | Most recent employer | `user_profile.company` |
| Top 5 skills | Skills section, job descriptions | `user_profile.skills` |
| Education | Education section | `PROFILE.md → Background` |
| Career trajectory | Experience timeline | `PROFILE.md → Background narrative` |
| Languages spoken | Languages section | `user_profile.language` candidates |
| Certifications | Certifications section | `PROFILE.md → Background` |
| Content types created | Job descriptions (proposals, reports, code) | Role-specific agent selection |

**Example extraction:**
```
From CV → extracted:
  role: "Sales & GTM Leader"
  seniority: "senior" (15+ years experience)
  industry: "IT/AI Consulting"
  company: "iSquared (Var Group)"
  skills: ["B2B sales", "AI/GenAI", "team leadership", "enterprise consulting", "thought leadership"]
  career_trajectory: "Technical → Sales → Sales Leadership"
```

---

## Document Type 2: LinkedIn Profile

**Tool:** `WebFetch` (native — fetches public web pages)

**How to process:**
1. User provides their LinkedIn URL (e.g., `https://www.linkedin.com/in/username`)
2. Use `WebFetch` with prompt: "Extract the professional profile information: name, headline, current position, about/summary section, list of experience entries (title, company, duration), top skills, recent activity topics, and education."
3. Parse the response into structured fields

**Note:** LinkedIn public view may be limited. Extract what's available — the user can fill gaps in Phase 2.

**Extraction targets:**

| Field | Where to find it | Maps to |
|-------|-------------------|---------|
| Headline | Profile header | `user_profile.role` (often more expressive than CV title) |
| About/Summary | About section | `PROFILE.md → How I Think`, `user_profile.tone` (natural voice) |
| Current position | Experience section (first entry) | `user_profile.role`, `user_profile.company` |
| Experience list | Experience section | `PROFILE.md → Background narrative` |
| Skills | Skills section | `user_profile.tools`, role-specific follow-ups |
| Activity | Recent posts/articles | Content creation habits, topics of expertise |
| Recommendations | Recommendations section | Personality traits, work style signals |

**Special extraction — Tone from About section:**
The "About" section is often the most authentic piece of writing a professional produces.
Analyze it for:
- Sentence length (short = direct, long = reflective)
- First person vs. third person
- Formal vs. casual vocabulary
- Storytelling vs. factual style
- Use of humor or personality

This becomes the calibration reference for `user_profile.tone` and influences how CLAUDE.md and PROFILE.md are written.

**Example extraction:**
```
From LinkedIn → extracted:
  headline: "AI Sales Leader | Helping enterprises adopt GenAI"
  about_tone: "direct, first-person, no buzzwords, practical examples"
  current_role: "Sales & GTM Leader at iSquared (Var Group)"
  content_creator: true (publishes 2-3x/week on LinkedIn)
  topics: ["AI readiness", "B2B sales", "enterprise AI adoption"]
```

---

## Document Type 3: Company Website

**Tool:** `WebFetch` (native)

**How to process:**
1. User provides the company URL (e.g., `https://www.company.com`)
2. Use `WebFetch` with prompt: "Extract company information: name, industry, main products/services, approximate company size if mentioned, geographic presence, company values or culture, and target market."
3. If the homepage is sparse, try `/about`, `/chi-siamo`, or `/about-us` pages

**Extraction targets:**

| Field | Where to find it | Maps to |
|-------|-------------------|---------|
| Company name | Header, about page | `user_profile.company` |
| Industry | Products/services, about page | `user_profile.industry` |
| Company size | About page, careers page | `user_profile.company_size` |
| Products/Services | Main navigation, homepage | Context for CLAUDE.md projects |
| Target market | About page, case studies | B2B vs B2C, enterprise vs SMB |
| Values/Culture | About page, careers | `PROFILE.md → What I Appreciate` |

**Example extraction:**
```
From website → extracted:
  company: "iSquared"
  parent: "Var Group"
  industry: "IT consulting, AI/GenAI services"
  company_size: "medium (part of Var Group, 3500+ employees)"
  products: ["AI readiness assessment", "GenAI training", "use case discovery"]
  target_market: "Enterprise B2B, Italian market"
```

---

## Document Type 4: Existing CLAUDE.md

**Tool:** `Glob` + `Read` (native)

**How to process:**
1. Auto-detect: Use `Glob` to search for `CLAUDE.md` in the working directory and common locations
2. If found, use `Read` to load it
3. Parse existing sections

**Extraction targets:**

| Section | What to extract | Action |
|---------|-----------------|--------|
| Identity (Chi Sono, Who I Am) | Role, company, focus areas | Confirm, don't overwrite |
| Projects | Active project list | Merge with CV/LinkedIn data |
| Tools | Tool list | Merge with new data |
| Preferences | Tone, language, timezone | Preserve as-is |
| Skills/Agents | Existing skill/agent references | Preserve and extend |
| Session management | SESSION_LOG references, TODO format | Check if already structured |
| Custom sections | Anything non-standard | Preserve entirely |

**Critical: Upgrade Path Logic**

If CLAUDE.md already exists, the skill operates in **UPGRADE MODE**:
- DO NOT replace existing sections — merge new data
- IDENTIFY what's missing: session management? agents? ROI tracking? TODO triage?
- PROPOSE additions, not replacements
- Show a "gap analysis" in the Blueprint phase:

```markdown
## Gap Analysis: Your Current vs. Full Ecosystem

| Component | Status | Action |
|-----------|--------|--------|
| CLAUDE.md | ✅ Exists | Enhance with missing sections |
| PROFILE.md | ❌ Missing | Create from CV + LinkedIn data |
| SESSION_LOG.md | ❌ Missing | Create with format guide |
| WORKSPACE_IMPROVEMENTS.md | ❌ Missing | Create (self-improvement loop) |
| SESSION_VALUE_LOG.md | ❌ Missing | Create (ROI tracking) |
| TODO_BACKLOG.md | ❌ Missing | Create (triage system) |
| session-closer agent | ❌ Missing | Create (session automation) |
| MCP servers | ⚠️ Partial (2 of 3 Tier 1) | Add missing servers |
```

---

## Document Type 5: Work Samples

**Tool:** `Read` (native — reads PDF, Word, PowerPoint, images)

**How to process:**
1. User provides 1-2 file paths for recent work
2. Use `Read` to load each document
3. Analyze for style and content patterns

**Extraction targets:**

| Signal | What to look for | Maps to |
|--------|-----------------|---------|
| Content type | Proposal? Deck? Report? Email? Code? | Role confirmation + agent selection |
| Formality level | C-level language vs. peer-level | `user_profile.tone` |
| Structure | Bullet-heavy vs. narrative | `PROFILE.md → Writing Rules` |
| Complexity | Executive summary vs. deep technical | Experience level signal |
| Visual design | Formatted vs. plain text | Tool preferences |
| Audience | Internal vs. external | Communication style patterns |

**Example signals:**
```
From work samples → extracted:
  primary_content: "B2B proposals and executive decks"
  formality: "high (C-level audience)"
  structure: "bullet-heavy, data-driven, ROI-focused"
  visual: "formatted, charts, tables"
  → Suggests: PROFILE.md writing rules = concise, data-driven, visual thinking
  → Suggests: Agent = deal-reviewer (proposal review focus)
```

---

## Document Type 6: Existing Folder Structure (Auto-detected)

**Tool:** `Bash` with `ls` (native)

**How to process:**
1. Automatically scan the working directory structure: `ls -la` (top level only)
2. Look for organizational patterns

**Extraction targets:**

| Pattern | Signal | Maps to |
|---------|--------|---------|
| Numbered folders (01_WORK, 02_DEV) | Already organized | Preserve structure, don't overwrite |
| Project-named folders | Active projects | `user_profile.projects` |
| Flat directory | Not yet organized | Full folder structure creation |
| `.claude/` directory exists | Intermediate+ user | Check for existing agents, skills |

---

## Combining Multiple Documents

When the user provides multiple documents, cross-reference them for consistency and depth:

1. **Role**: CV title + LinkedIn headline + current employer → strongest signal for role selection
2. **Tone**: LinkedIn About section > CV writing style > work sample style
3. **Projects**: CV recent experience + LinkedIn activity + work samples = project list
4. **Skills**: CV skills section ∪ LinkedIn skills ∪ tools mentioned in work samples
5. **Industry**: Company website > CV > LinkedIn

**Conflict resolution:**
- If CV says "Software Engineer" but LinkedIn says "Engineering Manager" → use LinkedIn (more current)
- If tone differs between CV (formal) and LinkedIn (casual) → ask in Phase 2: "Your CV is quite formal but your LinkedIn is more casual. Which tone do you prefer Claude to use?"

---

## Output: extracted_context Object

After processing all documents, construct:

```
extracted_context = {
  // From documents
  documents_provided: ["cv", "linkedin", "website"],  // which docs were analyzed

  // Pre-filled profile fields
  name: string,                    // from CV or LinkedIn
  role: string,                    // from headline/title
  role_confidence: "high"|"medium",// how confident we are
  seniority: string,               // junior/mid/senior/lead/exec
  industry: string,                // from company/CV
  company: string,                 // from CV/LinkedIn
  company_size: string,            // from website
  skills: [string],                // merged from all sources
  career_trajectory: string,       // from CV experience timeline

  // Content for PROFILE.md
  background_narrative: string,    // drafted from CV + LinkedIn
  thinking_style: string,          // from LinkedIn About
  tone_reference: string,          // from LinkedIn About analysis
  writing_rules: string,           // from work samples analysis
  communication_style: string,     // from work samples + LinkedIn

  // Content for CLAUDE.md
  projects: [{name, description}], // from CV recent + LinkedIn activity
  tools_detected: [string],        // from CV skills + LinkedIn
  content_creator: boolean,        // from LinkedIn activity

  // Upgrade path (if CLAUDE.md exists)
  existing_setup: {
    has_claude_md: boolean,
    has_profile_md: boolean,
    has_session_log: boolean,
    has_agents: boolean,
    has_mcp_servers: boolean,
    gaps: [string]                 // what's missing
  },

  // Questions to ask in Phase 2
  confirmation_questions: [string],    // "I see X, is that correct?"
  followup_questions: [string],        // "Given X, would you also want Y?"
  gaps_to_fill: [string]              // fields still unknown
}
```

This object pre-populates `user_profile` and drives the Phase 2 conversation.
