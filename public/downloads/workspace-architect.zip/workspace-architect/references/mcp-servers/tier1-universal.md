# Tier 1: Universal MCP Servers

Free, local, zero API keys. Recommended for ALL users regardless of role.

---

## 1. MarkItDown

**What it does:** Converts any document format to clean Markdown text that Claude can analyze.

**Supported formats:** PDF, Word (.docx), Excel (.xlsx), PowerPoint (.pptx), images (with OCR), HTML, CSV, JSON, ZIP archives.

**Use cases:**
- Analyze a client's PDF proposal
- Extract text from a scanned document
- Convert a PowerPoint deck to readable text
- Parse an Excel spreadsheet into structured data

**Install:**
```bash
claude mcp add markitdown -- uvx markitdown-mcp
```

**Verify:**
```bash
claude mcp list
# Should show: markitdown - Connected
```

**Test after install:**
Ask Claude: "Convert this PDF to text: /path/to/any/document.pdf"

**Important notes:**
- Process ONE document at a time (multiple simultaneous conversions can cause memory issues)
- OCR for scanned documents requires Pillow and pytesseract (auto-installed)
- Large PDFs (100+ pages) may take a few seconds
- Output is clean Markdown, ready for Claude to analyze

**Configuration in mcp.json:**
```json
"markitdown": {
  "command": "uvx",
  "args": ["markitdown-mcp"]
}
```

---

## 2. Playwright

**What it does:** Gives Claude the ability to control a web browser — navigate pages, take screenshots, click buttons, fill forms, extract content.

**Use cases:**
- Research a prospect's website
- Take a screenshot of a competitor's landing page
- Fill out a web form automatically
- Extract structured data from a web page
- Test a web application

**Install:**
```bash
claude mcp add playwright -- npx -y @playwright/mcp
```

**First-time setup:** After install, Playwright may need to download browser binaries:
```bash
npx playwright install chromium
```

**Verify:**
```bash
claude mcp list
# Should show: playwright - Connected
```

**Test after install:**
Ask Claude: "Take a screenshot of https://example.com"

**Important notes:**
- Uses Chromium by default (headless mode — no browser window appears)
- Screenshots are saved as temporary files that Claude can read
- Can handle JavaScript-heavy sites (SPAs, React apps)
- Network requests can be intercepted and logged
- Respects robots.txt and standard web conventions

**Configuration in mcp.json:**
```json
"playwright": {
  "command": "npx",
  "args": ["-y", "@playwright/mcp"]
}
```

---

## 3. Word Document Server

**What it does:** Creates and edits professional Word documents (.docx) with full formatting, tables, images, footnotes, and PDF export.

**Use cases:**
- Generate a professional proposal from structured data
- Create a report with formatted tables and headers
- Build a contract with proper legal formatting
- Add content to an existing Word template
- Export any document to PDF

**Install:**
```bash
claude mcp add word-document-server -- uvx --from office-word-mcp-server word_mcp_server
```

**Verify:**
```bash
claude mcp list
# Should show: word-document-server - Connected
```

**Test after install:**
Ask Claude: "Create a Word document called test.docx with a title 'Hello World' and a paragraph explaining what MCP servers are."

**Capabilities (50+ operations):**
- **Document management**: Create, copy, get info, list documents
- **Content**: Add paragraphs, headings, images, tables, page breaks
- **Formatting**: Custom styles, text formatting, cell alignment
- **Tables**: Merge cells, alternating row colors, column widths, header highlighting
- **Notes**: Footnotes, endnotes, comments
- **Export**: Convert to PDF
- **Protection**: Password protect/unprotect documents

**Important notes:**
- Only supports .docx format (not legacy .doc)
- PDF conversion quality depends on system libraries
- Works with existing .docx templates (open, modify, save)
- All operations are local — no cloud dependency

**Configuration in mcp.json:**
```json
"word-document-server": {
  "command": "uvx",
  "args": ["--from", "office-word-mcp-server", "word_mcp_server"]
}
```

---

## Quick Install (All Three)

Run these three commands in sequence:

```bash
claude mcp add markitdown -- uvx markitdown-mcp
claude mcp add playwright -- npx -y @playwright/mcp
claude mcp add word-document-server -- uvx --from office-word-mcp-server word_mcp_server
```

Then restart VS Code (or Claude Code CLI session).

Verify all three:
```bash
claude mcp list
# markitdown - Connected
# playwright - Connected
# word-document-server - Connected
```
