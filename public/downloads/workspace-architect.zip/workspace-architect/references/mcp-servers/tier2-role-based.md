# Tier 2: Role-Based MCP Servers

Require a free account and API key. Recommended based on your role and tools.

---

## 1. Zapier MCP

**What it does:** Connects Claude Code to 150+ Google Workspace and Microsoft 365 operations. Claude can search email, create calendar events, read/write spreadsheets, manage Drive files, and more.

**Best for:** Sales, Marketing, PM, Exec — anyone who lives in Gmail/Calendar/Sheets/Outlook.

**Skip if:** You're a developer who rarely uses email/calendar from Claude, or you prefer CLI tools for these tasks.

**Capabilities overview:**
- **Gmail**: Search, send, reply, draft, label, archive (27 operations)
- **Google Calendar**: Find events, create events, check availability (15 operations)
- **Google Sheets**: Read rows, write data, create spreadsheets, format (31 operations)
- **Google Drive**: Find files, upload, share, organize (23 operations)
- **Microsoft Outlook**: Email, calendar, contacts (25 operations)
- **Microsoft SharePoint**: Files, lists, folders (18 operations)
- **LinkedIn**: Create company updates

**Setup (5 minutes):**

1. Go to [zapier.com/mcp](https://zapier.com/mcp)
2. Sign in or create a free Zapier account
3. Connect the Google/Microsoft services you want Claude to access
4. Copy your personal MCP URL (looks like `https://mcp.zapier.com/api/mcp/s/...`)
5. Install:

```bash
claude mcp add MCP_ZAPIER --type http --url "YOUR_ZAPIER_MCP_URL_HERE"
```

**Verify:**
```bash
claude mcp list
# MCP_ZAPIER - Connected
```

**Test after install:**
Ask Claude: "Search my Gmail for emails from last week"

**Important notes:**
- Every tool call requires `instructions` (what to do) and `output_hint` (expected format) parameters
- Free Zapier plan has limited tasks/month — sufficient for personal use
- Your MCP URL is personal and tied to your Zapier account — never share it
- Claude can only access services YOU have connected in Zapier
- Attachments supported up to 150MB

**Configuration in mcp.json:**
```json
"MCP_ZAPIER": {
  "type": "http",
  "url": "https://mcp.zapier.com/api/mcp/s/YOUR_UNIQUE_ID/mcp"
}
```

**Security:** The MCP URL acts as both identifier and authentication. Treat it like a password. If compromised, regenerate it in Zapier dashboard.

---

## 2. Apify

**What it does:** Gives Claude access to 2,800+ web scraping and data extraction tools (called "Actors"). Extract structured data from any website: LinkedIn, Google Maps, Amazon, social media, news sites, and more.

**Best for:** Sales (prospect research), Marketing (competitive intelligence), Researchers (data gathering).

**Skip if:** You don't need to extract data from websites, or your company restricts web scraping.

**Capabilities overview:**
- **Search Actors**: Find the right scraper for any website
- **Run Actors**: Execute scraping tasks and get structured data
- **RAG Web Browser**: Intelligent web search + content extraction to Markdown
- **Social Media**: LinkedIn profiles, Instagram posts, TikTok videos, X/Twitter
- **Business Data**: Google Maps, company websites, job listings
- **E-commerce**: Amazon, eBay product data and reviews

**Setup (3 minutes):**

1. Go to [apify.com](https://apify.com) and create a free account
2. Go to Settings → Integrations → API Tokens
3. Create a new token (name it "Claude Code")
4. Copy the token (starts with `apify_api_`)
5. Install:

```bash
claude mcp add apify --type http --url "https://mcp.apify.com/?tools=actors,docs,apify/rag-web-browser" -H "Authorization: Bearer YOUR_APIFY_TOKEN"
```

**Verify:**
```bash
claude mcp list
# apify - Connected
```

**Test after install:**
Ask Claude: "Search Apify for a LinkedIn profile scraper"

**Important notes:**
- Free tier: $5/month in platform credits (enough for ~1,000 simple scrapes)
- Pay-per-result pricing: $0.0005 to $0.0027 per item depending on the Actor
- Output is structured JSON, exportable to CSV/Excel
- Prefer official Apify Actors (marked with blue checkmark) for reliability
- RAG Web Browser: max 10 Google results per query
- Results are saved in Apify datasets (accessible via `get-actor-output`)

**Configuration in mcp.json:**
```json
"apify": {
  "type": "http",
  "url": "https://mcp.apify.com/?tools=actors,docs,apify/rag-web-browser",
  "headers": {
    "Authorization": "Bearer apify_api_YOUR_TOKEN"
  }
}
```

**Security:** The API token grants access to your Apify account and its credits. Store it securely. If compromised, revoke and regenerate in Apify dashboard.
