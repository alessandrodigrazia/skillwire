# MCP Servers Overview

## What Are MCP Servers?

MCP (Model Context Protocol) servers are extensions that give Claude Code superpowers beyond reading and writing files. Think of them as plugins that let Claude interact with the real world: convert documents, browse the web, send emails, create Word files, scrape websites, and more.

Without MCP servers, Claude Code is limited to your local filesystem. With them, Claude becomes a full-stack productivity tool.

## How They Work

MCP servers run alongside Claude Code. Some run locally on your machine (no internet needed, no API keys), others connect to cloud services (need an account and credentials). Claude automatically discovers available tools from connected servers.

## Installation

All MCP servers are installed via a single command:
```bash
claude mcp add {server-name} -- {command} {args}
```

After adding, restart VS Code (or Claude Code CLI) to load the new tools.

To verify: `claude mcp list` — all servers should show "Connected".

## The Three Tiers

### Tier 1: Universal (Recommended for EVERYONE)
- Free, run locally, zero API keys needed
- Install in 30 seconds each
- **MarkItDown**: Convert any document (PDF, Word, Excel, PPT) to Markdown for analysis
- **Playwright**: Browser automation — take screenshots, navigate web pages, fill forms
- **Word Document Server**: Create and edit professional Word documents, export to PDF

### Tier 2: Role-Based (Recommended based on your work)
- Need a free account + API key
- 5-10 minute setup each
- **Zapier MCP**: Connect Gmail, Google Calendar, Google Sheets, Google Drive, Outlook, SharePoint
- **Apify**: Web scraping marketplace — extract data from any website, LinkedIn, Google Maps

### Tier 3: Specialized (For specific workflows)
- For users with specific automation needs
- **n8n-mcp**: Documentation and validation for n8n workflow automation platform

## Prerequisites

Before installing MCP servers, ensure you have:

### For Tier 1 servers:
- **uv** (Python package runner): `curl -LsSf https://astral.sh/uv/install.sh | sh` (macOS/Linux) or `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"` (Windows)
- **Node.js** (18+): `brew install node` (macOS) or download from nodejs.org

### For Tier 2 servers:
- A web browser to create accounts (Zapier, Apify)
- 5 minutes per account

### Verification:
```bash
# Check uv is available
uvx --version

# Check npx is available
npx --version
```

If either command fails, install the prerequisite first.

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `spawn uvx ENOENT` | Install `uv`: see prerequisites above |
| `spawn npx ENOENT` | Install Node.js: `brew install node` or nodejs.org |
| Server connected but tools not visible | Restart VS Code completely (not just reload) |
| Server not in `claude mcp list` | Check JSON syntax in `~/.claude/mcp.json` |
| Tools available but calls fail | Check API key validity; check internet connection for HTTP servers |
