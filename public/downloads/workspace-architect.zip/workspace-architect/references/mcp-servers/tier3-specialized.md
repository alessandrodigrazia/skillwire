# Tier 3: Specialized MCP Servers

For specific workflows. Only install if the use case applies to you.

---

## 1. n8n-mcp

**What it does:** Provides Claude with documentation for 800+ n8n workflow nodes and the ability to validate workflow JSON before deployment. Essential for building n8n automations with Claude Code.

**Best for:** Users who build workflow automations with n8n (self-hosted or cloud).

**Skip if:** You don't use n8n and don't plan to start.

**What is n8n?** n8n is an open-source workflow automation platform (like Zapier but self-hosted and more powerful). It lets you create automated workflows connecting 500+ services: email triggers, API calls, AI agents, database operations, and more.

**Capabilities:**
- **search_nodes**: Find the right n8n node for any task (e.g., "send email", "AI agent", "webhook")
- **get_node**: Get complete parameter schema for any node (essential for generating correct workflow JSON)
- **validate_workflow**: Validate a workflow JSON before importing into n8n (catches connection errors, missing parameters)
- **search_templates**: Find existing workflow templates as starting points
- **get_template**: Get the full JSON of a template workflow

**Setup (1 minute):**

Requires Node.js 18+ installed.

```bash
claude mcp add n8n-mcp -- npx n8n-mcp
```

For reduced logging:
```bash
claude mcp add-json n8n-mcp '{"command":"npx","args":["n8n-mcp"],"env":{"MCP_MODE":"stdio","LOG_LEVEL":"error"}}'
```

**Verify:**
```bash
claude mcp list
# n8n-mcp - Connected
```

**Test after install:**
Ask Claude: "Search n8n nodes for Gmail"

**Important notes:**
- Runs entirely locally — no API calls, no internet needed
- Database: 800+ n8n nodes documented in a local SQLite database
- Latency: ~12ms per call
- Startup: ~300ms for initialization
- Combined with the `n8n-ai-workflow-expert` skill (available on skillwire.ai), this becomes a full n8n development environment inside Claude Code

**Configuration in mcp.json:**
```json
"n8n-mcp": {
  "command": "npx",
  "args": ["n8n-mcp"],
  "env": {
    "MCP_MODE": "stdio",
    "LOG_LEVEL": "error"
  }
}
```

---

## When to Consider n8n

If you find yourself thinking "I wish I could automate this workflow," n8n might be worth exploring:

- **Email automation**: Auto-process incoming emails, extract data, route to systems
- **AI pipelines**: Chain LLM calls with data processing and external APIs
- **Content workflows**: RSS → AI summary → social media posting
- **Data sync**: Keep multiple systems in sync automatically
- **Scheduled reports**: Pull data from APIs, generate reports on schedule

n8n is free and open-source (self-host) or available as a managed cloud service (n8n.cloud).
