# Discovery Questions

This file supports TWO modes:

- **Mode A (after Document Intelligence)**: Claude already has `extracted_context` from Phase 1. Use confirmation questions + adaptive follow-ups + standard non-extractable questions.
- **Mode B (no documents provided)**: Full 12-15 question interview. Use all 3 blocks.

---

## Mode A: Confirmation & Adaptive Discovery

Use this mode when `extracted_context` is available from Phase 1 (Document Intelligence).

### Step 1: Present Extracted Profile

Show the user what was extracted:

> "Based on the documents you shared, here's what I've understood about you:
>
> - **Role**: [extracted role] at [company]
> - **Industry**: [extracted industry]
> - **Key skills**: [top 5 skills]
> - **Active areas**: [from recent experience/LinkedIn activity]
> - **Communication style**: [from LinkedIn About/work samples]
>
> Does this look accurate? Anything to correct or add?"

### Step 2: Confirmation Questions (generated from documents)

These are NOT pre-written — Claude generates them based on what was extracted:

**Pattern: "I noticed X in your [document]. Is that correct / still current?"**

Examples:
- "Your CV shows a transition from technical roles to sales leadership. Is sales your primary focus now?"
- "Your LinkedIn mentions AI/GenAI frequently. Is that your main domain of expertise?"
- "I see your company offers 5 service lines — do you work across all of them or focus on one?"
- "Your recent LinkedIn posts are about [topic] — should the workspace emphasize content creation tools?"

**Pattern: "Given X, would you also want Y?"**

Examples:
- "Since you create content regularly on LinkedIn, should I include a content authenticity checker agent?"
- "I notice your company uses Microsoft 365 (from website). Want me to set up Zapier MCP for Outlook integration?"
- "Your CV mentions Salesforce experience. Do you still use a CRM?"

### Step 3: Standard Non-Extractable Questions

These are ALWAYS asked regardless of documents provided:

**Q-always-1: Claude Code Experience**
"How would you rate your experience with Claude Code? Beginner (just started), intermediate (use it regularly), or advanced (built custom skills/agents)."

**Q-always-2: Cloud Sync**
"Do you sync your files with a cloud service? (OneDrive, iCloud, Dropbox, Google Drive, or none)"

**Q-always-3: Priority**
"What matters most to you when working with Claude? Efficiency (get things done fast), creativity (brainstorm and explore), organization (track everything), or tracking (prove AI value with metrics)."

**Q-always-4: Rate Benchmark**
"For ROI tracking, what hourly rate should I use as baseline? This helps estimate the value of time Claude saves you."
Default to industry rate from role-profiles.md if user says "I don't know."

**Q-always-5: Git Usage**
"Do you use Git for version control? If yes, where?"

### Step 4: Role-Specific Follow-ups

Only ask if not already answered by document extraction. See "Role-Specific Follow-ups" section below.

---

## Mode B: Full Discovery Interview

Use this mode when NO documents were provided in Phase 1 (user skipped or had nothing to share).

Questions are grouped in 3 conversational blocks. Ask each block naturally, not as a form.
Adapt follow-up questions based on the role selected in Q1.

## Block 1: Identity (4 questions)

### Q1: Role
**Ask:** "What's your professional role? For example: sales, developer, marketing, product manager, executive, or freelancer."

**Valid values:** `sales` | `dev` | `marketing` | `pm` | `exec` | `freelancer`

**If unclear, map:**
- "consultant", "account manager", "business development" → `sales`
- "engineer", "programmer", "data scientist", "DevOps" → `dev`
- "content creator", "copywriter", "social media", "growth" → `marketing`
- "product owner", "project manager", "scrum master" → `pm`
- "CEO", "CTO", "COO", "VP", "director", "founder" → `exec`
- "independent", "contractor", "solopreneur" → `freelancer`

### Q2: Industry and Company
**Ask:** "What industry are you in, and how large is your company? (e.g., 'Tech startup, 50 people' or 'Manufacturing, 5000+ employees')"

**Store as:** `industry` (string), `company_size` (small <50 | medium 50-500 | large 500+ | solo)

### Q3: Active Projects
**Ask:** "What are your 2-3 main active projects right now? Just a name and one line of context for each."

**Store as:** `projects` (array of {name, description})

**Example response:** "1. Product Launch Q2 - launching new SaaS feature. 2. Team Hiring - recruiting 3 engineers. 3. Investor Deck - preparing Series A materials."

### Q4: Daily Tools
**Ask:** "What tools do you use daily? Think about communication, project management, data, email, etc."

**Store as:** `tools` (array of strings)

**Used for:** MCP server recommendations (Tier 2)
- If mentions Gmail/Google Calendar/Google Drive/Sheets → flag `google_workspace: true`
- If mentions Outlook/SharePoint/Teams → flag `microsoft_365: true`
- If mentions n8n → flag `uses_n8n: true`

## Block 2: Technical Setup (4 questions)

### Q5: Git Usage
**Ask:** "Do you use Git for version control? If yes, where do you host your repos? (GitHub, GitLab, Bitbucket, or just local)"

**Store as:** `uses_git` (boolean), `git_host` (string | null)

**Impact:** If true, session-closer includes Step 4 (git commit). If GitHub, recommend gh CLI integration.

### Q6: Primary Language
**Ask:** "What language should I use for your workspace files? I support English and Italian natively, and can generate in other languages too."

**Valid values:** `en` | `it` | other ISO 639-1 codes

**Impact:** All generated files (CLAUDE.md, PROFILE.md, etc.) in selected language. For languages other than EN/IT, generate in English with a note suggesting manual translation of key sections.

### Q7: Cloud Sync
**Ask:** "Do you sync your files with a cloud service? (OneDrive, iCloud, Dropbox, Google Drive, or none)"

**Store as:** `cloud_sync` (onedrive | icloud | dropbox | gdrive | none)

**Impact:** If not `none`, offer symlink setup guide for `.claude/` directory in Phase 6 (Growth Roadmap). This enables cross-device workspace sync.

### Q8: Claude Code Experience
**Ask:** "How would you rate your experience with Claude Code? Beginner (just started), intermediate (use it regularly), or advanced (built custom skills/agents)."

**Valid values:** `beginner` | `intermediate` | `advanced`

**Impact:**
- `beginner`: Architecture guide in full detail. All phases include explanations.
- `intermediate`: Concise explanations. Skip obvious details.
- `advanced`: Minimal explanations. Focus on structure and customization. May skip Activation phase.

## Block 3: Preferences (4-5 questions)

### Q9: Work Style
**Ask:** "Do you work mostly alone or with a team?"

**Store as:** `work_style` (solo | team)

**Impact:** If `team`, CLAUDE.md includes team communication section. If `solo`, simplified structure.

### Q10: Tone
**Ask:** "What tone do you prefer Claude to use? Formal, direct, casual, or technical?"

**Valid values:** `formal` | `direct` | `casual` | `technical`

**Store as:** `tone`

### Q11: Priority
**Ask:** "What matters most to you when working with Claude? Pick your top priority: efficiency (get things done fast), creativity (brainstorm and explore), organization (track everything), or tracking (prove AI value with metrics)."

**Valid values:** `efficiency` | `creativity` | `organization` | `tracking`

**Impact:**
- `efficiency`: Emphasize agents and MCP servers
- `creativity`: Emphasize flexible PROFILE.md, brainstorming agents
- `organization`: Emphasize TODO triage, session management, folder structure
- `tracking`: Emphasize ROI tracking, session value, workspace improvements

### Q12: Rate Benchmark
**Ask:** "For ROI tracking, what hourly rate should I use as baseline? This helps estimate the value of time Claude saves you. If unsure, I'll use industry defaults."

**Store as:** `hourly_rate` (number | null)

**Defaults by role:**
| Role | Default Rate (EUR/h) |
|------|---------------------|
| sales | 120-180 |
| dev | 100-150 |
| marketing | 80-130 |
| pm | 100-160 |
| exec | 150-250 |
| freelancer | 60-120 |

## Role-Specific Follow-ups

After Q4 (Daily Tools), ask 1-2 role-specific questions:

### If role = sales
**Q-sales-1:** "Do you manage a sales pipeline? If yes, what CRM do you use? (Salesforce, HubSpot, Pipedrive, Airtable, spreadsheet, none)"
**Q-sales-2:** "What types of content do you create most? (proposals, decks, emails, call prep, none)"

### If role = dev
**Q-dev-1:** "What programming languages/frameworks do you work with most?"
**Q-dev-2:** "Do you write tests regularly? What testing framework?"

### If role = marketing
**Q-mkt-1:** "What content channels do you manage? (blog, social media, email, ads, podcast)"
**Q-mkt-2:** "Do you have brand guidelines or a style guide?"

### If role = pm
**Q-pm-1:** "What methodology do you use? (Agile/Scrum, Kanban, Waterfall, hybrid)"
**Q-pm-2:** "Where do you track requirements? (Jira, Linear, Notion, docs)"

### If role = exec
**Q-exec-1:** "What are your main decision-making areas? (strategy, hiring, investment, product)"
**Q-exec-2:** "Do you prepare board decks or investor materials?"

### If role = freelancer
**Q-free-1:** "What services do you offer? (consulting, development, design, writing, coaching)"
**Q-free-2:** "How do you manage clients? (CRM, spreadsheet, nothing)"

## Output: User Profile Object

After all questions, construct this internal profile (NOT saved as a file):

```
user_profile = {
  role: string,
  industry: string,
  company_size: string,
  projects: [{name, description}],
  tools: [string],
  google_workspace: boolean,
  microsoft_365: boolean,
  uses_n8n: boolean,
  uses_git: boolean,
  git_host: string | null,
  language: string,
  cloud_sync: string,
  experience: string,
  work_style: string,
  tone: string,
  priority: string,
  hourly_rate: number | null,
  role_specific: {key: value}  // from follow-up questions
}
```

This profile drives all subsequent phases.
