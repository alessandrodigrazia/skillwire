---
name: deep-research-agent
description: Ricerca approfondita multi-fonte con citazioni. Usa per deep research, analisi complete, report strutturati.
---

# Deep Research Agent

Questa skill abilita Claude Code a condurre ricerche approfondite, multi-fonte, con rigore metodologico, tracciamento delle citazioni e output strutturato.

## Quando Usare Questa Skill

- L'utente chiede "deep research", "ricerca approfondita", "analisi completa"
- Il topic richiede sintesi da fonti multiple e autorevoli
- L'output necessita citazioni e bibliografia
- Domande complesse che richiedono esplorazione iterativa
- Analisi competitiva, ricerche di mercato, deep-dive tecnici

## Quick Start

Quando attivata, seguire questa sequenza:

```
1. SCOPE       → Definire confini, chiarire ambiguità
2. PLAN        → Decomporre in sub-query parallele (Graph-of-Thoughts)
3. RETRIEVE    → Eseguire ricerche, recuperare pagine complete
4. TRIANGULATE → Verificare fatti incrociati, risolvere conflitti
5. DRAFT       → Scrivere con citazioni inline
6. CRITIQUE    → Auto-revisione per gap e bias
7. PACKAGE     → Formattare report finale + bibliografia
```

## Metodologia Core

### Fase 1: SCOPE (Iniziare Sempre Qui)

Prima di qualsiasi ricerca, porre 2-3 domande di chiarimento se:

- La query è sotto 15 parole
- Esistono interpretazioni multiple valide
- I vincoli chiave sono poco chiari (timeframe, geografia, settore)
- L'aspettativa di profondità è ambigua

```
Esempi di chiarimenti:
- "Cerchi dettagli tecnici di implementazione o impatto business?"
- "Mi concentro sul mercato italiano/europeo o globale?"
- "Qual è il pubblico target: C-level, team tecnico, o generale?"
```

### Fase 2: PLAN (Decomposizione Graph-of-Thoughts)

Decomporre la domanda di ricerca in un grafo di sub-query che possono essere esplorate in parallelo e poi fuse.

**Principio chiave**: A differenza del Chain-of-Thought lineare, GoT permette:

- Branching in percorsi di investigazione paralleli
- Merging di insight da percorsi diversi in conclusioni sintetizzate
- Feedback loop per raffinare pensieri precedenti basandosi su scoperte successive

```
Esempio di decomposizione per "Impatto AI nel manufacturing":

       [Domanda Principale]
            │
    ┌───────┼───────┐
    ▼       ▼       ▼
[Casi d'Uso][Dati ROI][Barriere]
    │       │       │
    └───┬───┴───┬───┘
        ▼       ▼
   [Sintesi] [Raccomandazioni]
```

Creare un file `research_plan.md` con:

- Domanda di ricerca principale
- 3-5 sub-domande (branch)
- Tipi di fonti attese per branch
- Strategia di merge

### Fase 3: RETRIEVE (Raccolta Intensiva Fonti)

**Livelli di Profondità**:

All'avvio di una ricerca, PROPORRE un livello basato sulla complessità percepita:

```
"Per questa ricerca su [topic], propongo di consultare circa [N] fonti.

- Ricerca rapida (5 fonti): overview veloce
- Ricerca standard (10-15 fonti): analisi bilanciata
- Ricerca approfondita (20+ fonti): investigazione esaustiva

Vuoi confermare o preferisci un livello diverso?"
```

**ATTENDERE SEMPRE la conferma dell'utente prima di procedere.**

**Strategia di ricerca**:

```
# Buono: Query focalizzate
"Claude AI enterprise adoption 2024"
"manufacturing AI ROI case study"

# Da evitare: Accumulo di keyword
"AI machine learning manufacturing industry impact benefits 2024 2025"
```

**Priorità delle fonti**:

1. Fonti primarie (blog aziendali, documentazione ufficiale, peer-reviewed)
2. Report di settore (Gartner, McKinsey, Forrester)
3. Giornalismo di qualità (pubblicazioni major)
4. Evitare: contenuti SEO-optimized, forum, aggregatori

**Per ogni fonte, registrare**:

- URL
- Data di pubblicazione
- Credibilità autore/organizzazione
- Claim chiave estratti
- Livello di confidenza (alto/medio/basso)

### Fase 4: TRIANGULATE (Verifica Incrociata)

Per ogni claim principale:

- Verificare su 2+ fonti indipendenti
- Segnalare conflitti esplicitamente: "Fonte A afferma X, mentre Fonte B afferma Y"
- Investigare conflitti con ricerche aggiuntive
- Annotare gap informativi che non è stato possibile colmare

### Fase 5: DRAFT (Scrivere con Citazioni)

**Struttura**:

```markdown
# [Titolo Ricerca]
*Generato: [Data] | Fonti: [N] | Confidenza: [Alta/Media/Bassa]*

## Executive Summary
[2-3 paragrafi, findings chiave in primo piano]

## Findings Principali
### [Finding 1]
[Contenuto con citazioni inline]

### [Finding 2]
...

## Analisi
[Esplorazione approfondita, comparazioni, implicazioni]

## Limitazioni & Gap
[Cosa non è stato possibile verificare, informazioni conflittuali]

## Raccomandazioni
[Next steps azionabili basati sui findings]

## Fonti
[Lista numerata, formato APA]
```

**Stile citazioni**:

- Inline: "Secondo [Nome Fonte], [claim] [1]"
- Mai inventare citazioni
- Segnalare claim incerti con qualificatori

### Fase 6: CRITIQUE (Auto-Revisione)

Prima di finalizzare, verificare esplicitamente:

- [ ] Tutti i claim principali hanno citazioni
- [ ] Viewpoint conflittuali affrontati
- [ ] Nessun gap logico nel ragionamento
- [ ] Confini dello scope rispettati
- [ ] Bias check: sto sovra-rappresentando una prospettiva?

### Fase 7: PACKAGE (Output Finale)

Salvare il report:

```
reports/{topic-slug}-{YYYY-MM-DD}.md
```

Offrire output aggiuntivi:

- "Vuoi che converta questo in un outline per presentazione?"
- "Devo creare un summary visuale?"
- "Serve un executive brief più breve per il leadership?"

## Parallelizzazione con Sub-Agenti

Per ricerche complesse, usare il Task tool per branch paralleli:

```
Task tool:
- subagent_type: "Explore" o "general-purpose"
- prompt: "Ricerca Branch [X]: [descrizione specifica]..."
- run_in_background: true (per parallelizzare)
```

Esempio di lancio parallelo:

```
Branch A: "Ricerca casi d'uso AI nel manufacturing - focus su quality control
          e manutenzione predittiva. Riporta findings in bullet con fonti."

Branch B: "Ricerca metriche ROI e case study di AI nel manufacturing.
          Includi numeri specifici e nomi aziende."

Branch C: "Ricerca barriere all'adozione AI nel manufacturing.
          Include barriere tecniche, organizzative e finanziarie."
```

Poi fondere i risultati nel thread principale.

## Directory Output

Tutti gli output di ricerca vanno in:

```
./reports/
├── {topic}-{data}.md           # Report principale
├── {topic}-sources.json        # Dati fonti strutturati
└── research_plan.md            # Artefatto di pianificazione
```

## Riferimenti

Per metodologia dettagliata, consultare:

- `references/graph-of-thoughts.md` - Spiegazione framework GoT
- `references/research-phases.md` - Descrizioni dettagliate delle fasi
- `references/prompt-templates.md` - Pattern di prompt pronti all'uso

## Anti-Pattern da Evitare

- Iniziare ricerca senza domande di chiarimento
- Affidarsi a snippet di ricerca senza recuperare pagine complete
- Claim single-source per fatti importanti
- Inventare o indovinare citazioni
- Ignorare informazioni conflittuali
- Over-quoting (parafrasare e citare invece)

## Esempio di Invocazione

Utente: "Fai una deep research sull'adozione di AI generativa nelle aziende italiane mid-market"

Claude:

1. Chiede: "Mi concentro su settori specifici (manufacturing, retail, servizi)? Che timeframe - ultimi 12 mesi o trend più ampio? Output per strategia interna o presentazione cliente?"
2. Propone livello di profondità e attende conferma
3. Crea research_plan.md con branch
4. Esegue ricerche parallele
5. Produce report 2000+ parole con 10+ fonti
6. Salva in reports/genai-italian-midmarket-2025-01-15.md
