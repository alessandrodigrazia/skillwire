---
name: deep-research-agent
description: Multi-source deep research with citations. Use for deep research, comprehensive analysis, structured reports.
---

# Deep Research Agent

This skill enables Claude Code to conduct in-depth, multi-source research with methodological rigor, citation tracking, and structured output.

## When to Use This Skill

- The user asks for "deep research", "in-depth research", "comprehensive analysis"
- The topic requires synthesis from multiple authoritative sources
- The output needs citations and bibliography
- Complex questions requiring iterative exploration
- Competitive analysis, market research, technical deep-dives

## Quick Start

When activated, follow this sequence:

```
1. SCOPE       → Define boundaries, clarify ambiguities
2. PLAN        → Decompose into parallel sub-queries (Graph-of-Thoughts)
3. RETRIEVE    → Execute searches, retrieve full pages
4. TRIANGULATE → Cross-verify facts, resolve conflicts
5. DRAFT       → Write with inline citations
6. CRITIQUE    → Self-review for gaps and bias
7. PACKAGE     → Format final report + bibliography
```

## Core Methodology

### Phase 1: SCOPE (Always Start Here)

Before any research, ask 2-3 clarifying questions if:

- The query is under 15 words
- Multiple valid interpretations exist
- Key constraints are unclear (timeframe, geography, sector)
- The depth expectation is ambiguous

```
Examples of clarifications:
- "Are you looking for technical implementation details or business impact?"
- "Should I focus on the Italian/European or global market?"
- "Who is the target audience: C-level, technical team, or general?"
```

### Phase 2: PLAN (Graph-of-Thoughts Decomposition)

Decompose the research question into a graph of sub-queries that can be explored in parallel and then merged.

**Key principle**: Unlike linear Chain-of-Thought, GoT allows:

- Branching into parallel investigation paths
- Merging insights from different paths into synthesized conclusions
- Feedback loops to refine earlier thoughts based on later discoveries

```
Decomposition example for "AI Impact in Manufacturing":

       [Main Question]
            │
    ┌───────┼───────┐
    ▼       ▼       ▼
[Use Cases][ROI Data][Barriers]
    │       │       │
    └───┬───┴───┬───┘
        ▼       ▼
   [Synthesis] [Recommendations]
```

Create a `research_plan.md` file with:

- Main research question
- 3-5 sub-questions (branches)
- Expected source types per branch
- Merge strategy

### Phase 3: RETRIEVE (Intensive Source Collection)

**Depth Levels**:

At the start of a research project, PROPOSE a level based on perceived complexity:

```
"For this research on [topic], I propose consulting approximately [N] sources.

- Quick research (5 sources): fast overview
- Standard research (10-15 sources): balanced analysis
- In-depth research (20+ sources): exhaustive investigation

Would you like to confirm or prefer a different level?"
```

**ALWAYS WAIT for user confirmation before proceeding.**

**Search strategy**:

```
# Good: Focused queries
"Claude AI enterprise adoption 2024"
"manufacturing AI ROI case study"

# Avoid: Keyword stuffing
"AI machine learning manufacturing industry impact benefits 2024 2025"
```

**Source priorities**:

1. Primary sources (company blogs, official documentation, peer-reviewed)
2. Industry reports (Gartner, McKinsey, Forrester)
3. Quality journalism (major publications)
4. Avoid: SEO-optimized content, forums, aggregators

**For each source, record**:

- URL
- Publication date
- Author/organization credibility
- Key claims extracted
- Confidence level (high/medium/low)

### Phase 4: TRIANGULATE (Cross-Verification)

For each major claim:

- Verify across 2+ independent sources
- Flag conflicts explicitly: "Source A states X, while Source B states Y"
- Investigate conflicts with additional searches
- Note information gaps that could not be filled

### Phase 5: DRAFT (Write with Citations)

**Structure**:

```markdown
# [Research Title]
*Generated: [Date] | Sources: [N] | Confidence: [High/Medium/Low]*

## Executive Summary
[2-3 paragraphs, key findings upfront]

## Key Findings
### [Finding 1]
[Content with inline citations]

### [Finding 2]
...

## Analysis
[In-depth exploration, comparisons, implications]

## Limitations & Gaps
[What could not be verified, conflicting information]

## Recommendations
[Actionable next steps based on findings]

## Sources
[Numbered list, APA format]
```

**Citation style**:

- Inline: "According to [Source Name], [claim] [1]"
- Never fabricate citations
- Flag uncertain claims with qualifiers

### Phase 6: CRITIQUE (Self-Review)

Before finalizing, explicitly verify:

- [ ] All major claims have citations
- [ ] Conflicting viewpoints addressed
- [ ] No logical gaps in reasoning
- [ ] Scope boundaries respected
- [ ] Bias check: am I over-representing one perspective?

### Phase 7: PACKAGE (Final Output)

Save the report:

```
reports/{topic-slug}-{YYYY-MM-DD}.md
```

Offer additional outputs:

- "Would you like me to convert this into a presentation outline?"
- "Should I create a visual summary?"
- "Do you need a shorter executive brief for leadership?"

## Parallelization with Sub-Agents

For complex research, use the Task tool for parallel branches:

```
Task tool:
- subagent_type: "Explore" or "general-purpose"
- prompt: "Research Branch [X]: [specific description]..."
- run_in_background: true (for parallelization)
```

Example of parallel launch:

```
Branch A: "Research AI use cases in manufacturing - focus on quality control
          and predictive maintenance. Report findings in bullets with sources."

Branch B: "Research ROI metrics and case studies for AI in manufacturing.
          Include specific numbers and company names."

Branch C: "Research barriers to AI adoption in manufacturing.
          Include technical, organizational, and financial barriers."
```

Then merge results in the main thread.

## Output Directory

All research outputs go in:

```
./reports/
├── {topic}-{date}.md           # Main report
├── {topic}-sources.json        # Structured source data
└── research_plan.md            # Planning artifact
```

## References

For detailed methodology, consult:

- `references/graph-of-thoughts.md` - GoT framework explanation
- `references/research-phases.md` - Detailed phase descriptions
- `references/prompt-templates.md` - Ready-to-use prompt patterns

## Anti-Patterns to Avoid

- Starting research without clarifying questions
- Relying on search snippets without retrieving full pages
- Single-source claims for important facts
- Fabricating or guessing citations
- Ignoring conflicting information
- Over-quoting (paraphrase and cite instead)

## Invocation Example

User: "Do a deep research on generative AI adoption in Italian mid-market companies"

Claude:

1. Asks: "Should I focus on specific sectors (manufacturing, retail, services)? What timeframe - last 12 months or broader trend? Output for internal strategy or client presentation?"
2. Proposes depth level and waits for confirmation
3. Creates research_plan.md with branches
4. Executes parallel searches
5. Produces 2000+ word report with 10+ sources
6. Saves to reports/genai-italian-midmarket-2025-01-15.md
