# Processo Deep Research: Pipeline a 7 Fasi

Questo documento dettaglia ogni fase della metodologia di ricerca approfondita, ispirata a OpenAI Deep Research, Google Gemini e pratiche di ricerca accademica.

## Panoramica delle Fasi

```
┌─────────────────────────────────────────────────────────────────┐
│  1. SCOPE → 2. PLAN → 3. RETRIEVE → 4. TRIANGULATE            │
│                                          ↓                      │
│                        5. DRAFT ← 6. CRITIQUE → 7. PACKAGE     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Fase 1: SCOPE

**Obiettivo**: Definire confini chiari ed eliminare ambiguità prima di investire sforzo nella ricerca.

### Quando Chiarire

Porre sempre domande di chiarimento se:

- La query è sotto 15 parole
- Esistono interpretazioni multiple valide
- Lo scope geografico/temporale non è chiaro
- L'aspettativa di profondità è ambigua
- Il focus tecnico vs. business non è chiaro

### Categorie di Chiarimento

| Categoria | Domande Esempio |
|-----------|-----------------|
| **Scope** | "Mi concentro su Italia/Europa o globalmente?" |
| **Profondità** | "Overview rapida o analisi completa?" |
| **Audience** | "Per decision-maker C-level o team tecnico?" |
| **Timeframe** | "Ultimi 12 mesi o trend storico più ampio?" |
| **Output** | "Formato report, outline presentazione, o executive brief?" |

### Template Documento Scope

```markdown
## Scope Ricerca

**Domanda Principale**: [Domanda raffinata dopo chiarimento]
**Confini**:
- Geografico: [Specificare]
- Temporale: [Specificare timeframe]
- Settore/Industry: [Specificare]
- Profondità: [Overview / Completa / Esaustiva]

**Fuori Scope**: [Elencare esplicitamente cosa NON ricercare]

**Criteri di Successo**: [Cosa rende questa ricerca "completa"?]
```

---

## Fase 2: PLAN

**Obiettivo**: Decomporre la domanda di ricerca in branch paralleli usando metodologia Graph-of-Thoughts.

### Strategia di Decomposizione

1. Identificare 3-5 aspetti distinti della domanda principale
2. Assicurarsi che i branch siano ricercabili indipendentemente
3. Pianificare punti di merge dove i branch si sintetizzeranno
4. Identificare potenziali connessioni cross-branch

### Template Piano di Ricerca

```markdown
## Piano di Ricerca: [Topic]

### Domanda di Ricerca Principale
[Domanda chiara e delimitata]

### Struttura Branch

#### Branch A: [Aspetto 1]
- Sub-domande: [Lista 2-3]
- Fonti attese: [Tipo di fonti da trovare]
- Termini chiave da cercare: [Query di ricerca]

#### Branch B: [Aspetto 2]
- Sub-domande: [Lista 2-3]
- Fonti attese: [Tipo di fonti da trovare]
- Termini chiave da cercare: [Query di ricerca]

#### Branch C: [Aspetto 3]
- Sub-domande: [Lista 2-3]
- Fonti attese: [Tipo di fonti da trovare]
- Termini chiave da cercare: [Query di ricerca]

### Strategia di Merge
- Branch A + B si fondono a: [Punto di sintesi]
- Tutti i branch si fondono a: [Sintesi finale]

### Output Atteso
- Conteggio parole: [Stima]
- Numero fonti: [Minimo]
- Deliverable chiave: [Lista]
```

---

## Fase 3: RETRIEVE

**Obiettivo**: Raccogliere materiale fonte completo attraverso ricerca web sistematica.

### Strategia di Ricerca

#### Formulazione Query

```
✅ Query buone:
- "generative AI adoption enterprise 2024"
- "AI transformation ROI case study manufacturing"
- "McKinsey AI report 2024"

❌ Query da evitare:
- "AI machine learning deep learning enterprise business 2024 2025 report"
- Ricerche a parola singola
- Query con operatori eccessivi
```

#### Tecniche di Ricerca Avanzata

- Usare virgolette per frasi esatte: `"generative AI adoption"`
- Usare site: per domini specifici: `site:mckinsey.com AI manufacturing`
- Usare after: per contenuto recente: `after:2024-01-01`
- Escludere risultati irrilevanti: `-forum -reddit`

### Requisiti Fonti

| Livello Sforzo | Min Fonti | Fetch Pagine Complete |
|----------------|-----------|----------------------|
| Ricerca rapida | 5 | 5 |
| Standard | 10-15 | 10-15 |
| Approfondita | 20+ | 20+ |

**Critico**: Gli snippet di ricerca NON contano. Bisogna recuperare e leggere le pagine complete.

### Gerarchia Qualità Fonti

1. **Fonti Primarie** (Priorità massima)
   - Annunci aziendali ufficiali
   - Ricerca peer-reviewed
   - Pubblicazioni governative/regolatorie
   - Dataset originali

2. **Secondarie Autorevoli**
   - Grandi società di consulenza (McKinsey, Gartner, Forrester)
   - Giornalismo di qualità (WSJ, FT, pubblicazioni tech major)
   - Report associazioni di settore

3. **Secondarie Accettabili**
   - Blog reputabili di esperti di dominio
   - Atti di conferenze
   - Articoli Medium/Substack ben citati

4. **Da Evitare**
   - Listicle SEO-optimized
   - Post forum anonimi
   - Content farm
   - Fonti obsolete (>2 anni per topic in rapida evoluzione)

### Tracking Fonti

Per ogni fonte, registrare:

```json
{
  "url": "https://...",
  "title": "Titolo fonte",
  "author": "Autore/Organizzazione",
  "date": "2024-01-15",
  "type": "primaria|secondaria|terziaria",
  "credibility": "alta|media|bassa",
  "key_claims": ["claim 1", "claim 2"],
  "branch": "A|B|C",
  "notes": "Contesto su qualità o rilevanza fonte"
}
```

---

## Fase 4: TRIANGULATE

**Obiettivo**: Verificare claim incrociandoli e risolvere informazioni conflittuali.

### Matrice di Verifica

| Claim | Fonte 1 | Fonte 2 | Fonte 3 | Status |
|-------|---------|---------|---------|--------|
| [Claim X] | ✅ Supporta | ✅ Supporta | - | Verificato |
| [Claim Y] | ✅ Supporta | ❌ Contraddice | - | Richiede investigazione |
| [Claim Z] | ✅ Supporta | - | - | Single-source (segnalare) |

### Gestione Conflitti

1. **Investigare ulteriormente**: Ricerche aggiuntive per risolvere
2. **Verificare date fonti**: La più recente potrebbe superare la più vecchia
3. **Verificare qualità fonte**: Primaria > secondaria
4. **Presentare entrambe le viste**: Se irrisolvibile, annotare il disaccordo

### Red Flag

- Solo una fonte per un claim critico
- Fonti che si citano a vicenda (riferimento circolare)
- Discrepanza significativa di date tra fonti
- Bias della fonte (vendor che afferma che il proprio prodotto è il migliore)

---

## Fase 5: DRAFT

**Obiettivo**: Scrivere un report completo con citazioni appropriate.

### Struttura Report

```markdown
# [Titolo Ricerca]

*Generato: [Data] | Fonti: [N] | Metodologia: Deep Research con GoT*

## Executive Summary
[2-3 paragrafi che coprono findings chiave e raccomandazioni]

## Metodologia di Ricerca
[Breve descrizione di approccio, scope, limitazioni]

## Findings Chiave

### Finding 1: [Titolo]
[Contenuto dettagliato con citazioni inline]

### Finding 2: [Titolo]
[Contenuto dettagliato con citazioni inline]

[Continuare come necessario]

## Analisi
[Esplorazione più profonda, comparazioni, analisi trend]

## Informazioni Conflittuali
[Dove le fonti erano in disaccordo, come è stato risolto o meno]

## Limitazioni & Gap
[Cosa non è stato possibile verificare, aree che richiedono più ricerca]

## Raccomandazioni
[Item azionabili basati sui findings]

## Fonti
1. [Autore/Org]. "[Titolo]." [Pubblicazione], [Data]. [URL]
2. ...
```

### Stile Citazioni

**Citazioni inline**:

- "Secondo il report McKinsey 2024, il 65% delle enterprise ha adottato qualche forma di AI [1]."
- "Fonti multiple confermano questo trend [1, 3, 7]."

**Gestione incertezza**:

- "Dati limitati suggeriscono..." (quando solo 1-2 fonti)
- "Le fonti sono in conflitto su questo punto; [Fonte A] afferma X mentre [Fonte B] afferma Y."

### Linee Guida Scrittura

✅ Fare:

- Iniziare con findings chiave
- Usare numeri ed esempi specifici
- Attribuire claim alle fonti
- Segnalare incertezza esplicitamente

❌ Non fare:

- Usare linguaggio hedging inutilmente
- Includere background irrilevante
- Inventare o indovinare citazioni
- Over-quoting (parafrasare e citare invece)

---

## Fase 6: CRITIQUE

**Obiettivo**: Auto-revisione per identificare gap, bias e debolezze.

### Checklist Critica

#### Completezza

- [ ] Tutti i branch del piano di ricerca sono coperti
- [ ] Ogni claim principale ha almeno una citazione
- [ ] L'executive summary cattura tutti i punti chiave
- [ ] Le raccomandazioni seguono logicamente dai findings

#### Accuratezza

- [ ] Nessun claim single-source senza segnalazione
- [ ] Informazioni conflittuali affrontate
- [ ] Date e numeri double-checked
- [ ] Nessuna citazione inventata

#### Bilanciamento

- [ ] Prospettive multiple rappresentate
- [ ] Non over-reliance su una fonte
- [ ] Contro-argomenti considerati
- [ ] Proprio bias verificato (confirmation bias, recency bias)

#### Chiarezza

- [ ] Struttura logica e facile da seguire
- [ ] Termini tecnici spiegati dove necessario
- [ ] Lunghezza appropriata per la profondità richiesta

### Azioni di Revisione

Basandosi sulla critica, agire:

- **Gap trovato**: Tornare alla Fase 3 (Retrieve) per ricerca aggiuntiva
- **Conflitto irrisolto**: Tornare alla Fase 4 (Triangulate) per investigazione più profonda
- **Sezione poco chiara**: Rivedere nella Fase 5 (Draft)

---

## Fase 7: PACKAGE

**Obiettivo**: Finalizzare i deliverable e offrire next step.

### File di Output

```
./reports/
├── [topic]-[data].md           # Report di ricerca principale
├── [topic]-sources.json        # Dati fonti strutturati
├── [topic]-executive-brief.md  # Opzionale: summary 1 pagina
└── research_plan.md            # Artefatto di pianificazione (per riferimento)
```

### Convenzione Naming File

```
{topic-slug}-{YYYY-MM-DD}.md

Esempi:
- genai-italian-midmarket-2025-01-15.md
- ai-manufacturing-roi-2025-01-15.md
- competitive-analysis-crm-2025-01-15.md
```

### Offerte Next Step

Dopo aver consegnato il report, offrire:

- "Vuoi che crei un outline per presentazione da questo?"
- "Devo generare un executive brief di 1 pagina?"
- "Serve approfondire qualche finding specifico?"
- "Vuoi una tabella comparativa o visualizzazione?"

### Metadata Qualità

Includere all'inizio del report:

```markdown
---
title: [Titolo Ricerca]
date: [YYYY-MM-DD]
sources: [N]
effort_level: [rapida|standard|approfondita]
confidence: [alta|media|bassa]
methodology: Deep Research con Graph-of-Thoughts
branches: [Lista dei branch ricercati]
---
```
