# Template di Prompt per Deep Research

Pattern di prompt pronti all'uso per diversi scenari di ricerca.

## Prompt di Raffinamento Domanda

Usare per trasformare una richiesta vaga in una query di ricerca strutturata.

```
Sei uno specialista nel raffinamento di domande di ricerca. Il tuo compito è
trasformare domande vaghe o ampie in query di ricerca ben strutturate.

Data la domanda dell'utente, produci:
1. Una domanda di ricerca principale raffinata (chiara, specifica, delimitata)
2. 3-5 sub-domande che decompongono la domanda principale
3. Confini di scope suggeriti (geografico, temporale, settoriale)
4. Formato output atteso e profondità

Domanda originale dell'utente: "[DOMANDA]"

Formato output:
## Query di Ricerca Raffinata

### Domanda Principale
[Domanda chiara e specifica]

### Sub-Domande
1. [Sub-domanda 1]
2. [Sub-domanda 2]
3. [Sub-domanda 3]

### Scope Suggerito
- Geografico: [Suggerimento]
- Temporale: [Suggerimento]
- Settore: [Suggerimento]
- Profondità: [Overview / Completa / Esaustiva]

### Domande di Chiarimento da Porre all'Utente
- [Domanda 1]
- [Domanda 2]
```

---

## Template Task Sub-Agente

Usare quando si lanciano task di ricerca paralleli tramite Task tool.

```
Ricerca Branch [X]: [Nome Branch]

## Obiettivo
[Aspetto specifico da ricercare]

## Domande Chiave a cui Rispondere
1. [Domanda 1]
2. [Domanda 2]
3. [Domanda 3]

## Requisiti Fonti
- Minimo [N] fonti autorevoli
- Priorità: [Fonti primarie / Report di settore / Accademiche]
- Recenza: [Vincolo temporale]

## Formato Output
Fornire findings come:
1. Summary in bullet point (5-10 punti chiave)
2. Lista fonti con URL e date di pubblicazione
3. Assessment di confidenza (alto/medio/basso per finding)
4. Eventuali informazioni conflittuali trovate

## Vincoli
- Concentrarsi SOLO su questo branch, non esplorare topic tangenziali
- Segnalare findings che si connettono ad altri branch
- Annotare gap che richiedono ricerca aggiuntiva
```

---

## Prompt di Sintesi Ricerca

Usare dopo aver raccolto i findings dei branch per sintetizzarli in conclusioni.

```
## Task di Sintesi Ricerca

Hai raccolto findings da branch di ricerca multipli:

### Branch A: [Nome]
[Incolla findings Branch A]

### Branch B: [Nome]
[Incolla findings Branch B]

### Branch C: [Nome]
[Incolla findings Branch C]

## Istruzioni di Sintesi

1. **Identifica Connessioni**: Quali temi o findings appaiono attraverso branch multipli?

2. **Risolvi Conflitti**: Dove i branch si contraddicono? Come va risolto?

3. **Trova Gap**: Quali domande restano senza risposta? Quale ricerca aggiuntiva serve?

4. **Trai Conclusioni**: Basandoti su tutti i branch, quali sono le 3-5 conclusioni principali?

5. **Genera Raccomandazioni**: Quali azioni seguono da queste conclusioni?

Output: Un'analisi sintetizzata che integra tutti i branch in una narrativa coerente.
```

---

## Prompt Valutazione Fonte

Usare per valutare qualità e affidabilità di una fonte.

```
Valuta la seguente fonte per scopi di ricerca:

URL: [URL]
Titolo: [Titolo]
Pubblicazione/Autore: [Autore]
Data: [Data]

Criteri di valutazione:

1. **Autorità**: L'autore/organizzazione è credibile in questo dominio?
   - [ ] Credenziali di esperto
   - [ ] Affiliazione istituzionale
   - [ ] Track record

2. **Accuratezza**: I claim sono supportati?
   - [ ] Fonti dati citate
   - [ ] Metodologia spiegata
   - [ ] Peer review o processo editoriale

3. **Attualità**: L'informazione è corrente?
   - [ ] Data di pubblicazione
   - [ ] Requisiti di attualità del topic

4. **Obiettività**: C'è bias?
   - [ ] Potenziali conflitti di interesse
   - [ ] Prospettiva bilanciata
   - [ ] Motivazione commerciale

5. **Copertura**: È completa?
   - [ ] Profondità del trattamento
   - [ ] Completezza dello scope

Valutazione complessiva: [Alta / Media / Bassa] credibilità
Raccomandazione uso: [Fonte primaria / Fonte di supporto / Usare con cautela / Evitare]
```

---

## Generatore Outline Report

Usare per creare una struttura prima di scrivere.

```
Genera un outline dettagliato per un report di ricerca su:

Topic: [TOPIC]
Profondità: [Overview / Completa / Esaustiva]
Audience: [C-level / Tecnica / Generale]
Findings chiave da includere: [Lista findings principali]

Output un outline con:
- Titoli di sezione
- Titoli di sotto-sezione
- Bullet point per contenuto chiave in ogni sezione
- Conteggio parole suggerito per sezione
- Posizionamento citazioni/fonti

Seguire questa struttura generale:
1. Executive Summary (10% del totale)
2. Metodologia (5%)
3. Findings Chiave (40%)
4. Analisi (25%)
5. Limitazioni (5%)
6. Raccomandazioni (10%)
7. Fonti (5%)
```

---

## Prompt di Critica

Usare per auto-revisione prima della finalizzazione.

```
## Critica Qualità Ricerca

Rivedi il seguente report di ricerca per problemi di qualità:

[INCOLLA REPORT]

Valuta rispetto a questi criteri:

### Completezza
- Tutte le domande di ricerca dichiarate hanno risposta?
- Ci sono gap evidenti nella copertura?
- L'executive summary è accurato rispetto al contenuto?

### Accuratezza
- Tutti i claim principali sono citati?
- Ci sono claim single-source su punti importanti?
- Le informazioni conflittuali sono affrontate?

### Bilanciamento
- Sono rappresentate prospettive multiple?
- C'è over-reliance su una singola fonte?
- I contro-argomenti sono considerati?

### Chiarezza
- La struttura è logica?
- I termini tecnici sono spiegati?
- La lunghezza è appropriata?

### Citazioni
- Tutte le citazioni sono formattate correttamente?
- Le fonti sono di alta qualità e autorevoli?
- Ci sono link rotti o sospetti?

Output:
1. Lista di problemi identificati (con severità: Alta/Media/Bassa)
2. Raccomandazioni specifiche per miglioramento
3. Score qualità complessivo (1-10)
```

---

## Generatore Executive Brief

Usare per creare una versione condensata di un report completo.

```
Crea un executive brief di 1 pagina dal seguente report di ricerca:

[INCOLLA REPORT COMPLETO]

Requisiti:
- Massimo 500 parole
- Focus su: Findings chiave, implicazioni so-what, azioni raccomandate
- Omettere: Dettagli metodologici, caveat estesi, discussione fonti dettagliata
- Includere: 3-5 bullet point per scansione rapida
- Tono: Diretto, orientato all'azione, adatto a lettori C-level

Struttura:
## Executive Brief: [Topic]
**Data**: [Data] | **Report Completo**: [Link]

### Bottom Line
[1-2 frasi: Il takeaway più importante]

### Findings Chiave
- [Finding 1]
- [Finding 2]
- [Finding 3]

### Implicazioni
[Cosa significa questo per l'organizzazione]

### Azioni Raccomandate
1. [Azione 1]
2. [Azione 2]
3. [Azione 3]

### Per Maggiori Dettagli
Vedere report completo per metodologia, fonti e analisi dettagliata.
```

---

## Generatore Query di Ricerca

Usare per generare query di ricerca efficaci per un topic.

```
Genera 10 query di ricerca efficaci per ricercare:

Topic: [TOPIC]
Aree di focus: [Lista aspetti specifici]
Requisito recenza: [Timeframe]
Tipi fonte necessari: [Report di settore / Accademiche / News / Primarie]

Per ogni query:
1. La query di ricerca stessa
2. Quale aspetto del topic targetta
3. Tipi fonte attesi da trovare

Considera:
- Usare frasi esatte tra virgolette
- Ricerche site-specific per domini autorevoli
- Filtri data per contenuto recente
- Operatori di esclusione per filtrare rumore

Formato output:
| # | Query | Aspetto Target | Fonti Attese |
|---|-------|----------------|--------------|
| 1 | "..." | ... | ... |
```
