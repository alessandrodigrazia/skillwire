# Metodologia Graph-of-Thoughts (GoT)

## Panoramica

Graph-of-Thoughts è un framework di ragionamento sviluppato da ETH Zürich (SPCL) che modella il ragionamento degli LLM come un grafo arbitrario invece che una catena lineare o un albero.

**Paper**: "Graph of Thoughts: Solving Elaborate Problems with Large Language Models" (AAAI 2024)
**Repository**: github.com/spcl/graph-of-thoughts

## Concetti Chiave

### Perché Grafi invece di Catene?

| Approccio | Struttura | Limitazione |
|-----------|-----------|-------------|
| Chain-of-Thought | Sequenza lineare | Non può combinare insight da percorsi diversi |
| Tree-of-Thoughts | Albero ramificato | I branch si sviluppano indipendentemente, niente merging |
| Graph-of-Thoughts | Grafo arbitrario | Flessibilità totale: branch, merge, loop back |

### Componenti Core

1. **Vertici (Pensieri)**: Unità di informazione generate dall'LLM
2. **Archi (Dipendenze)**: Relazioni tra pensieri
3. **Trasformazioni**: Operazioni che modificano il grafo

### Trasformazioni dei Pensieri

#### 1. Generazione

Creare pensieri multipli nuovi da un singolo pensiero.

```
[Pensiero A] → [Pensiero B1], [Pensiero B2], [Pensiero B3]
```

Caso d'uso: Esplorare ipotesi o approcci multipli in parallelo.

#### 2. Aggregazione

Combinare pensieri multipli in un pensiero sintetizzato.

```
[Pensiero A], [Pensiero B], [Pensiero C] → [Pensiero Sintetizzato]
```

Caso d'uso: Fondere findings da branch di ricerca diversi.

#### 3. Raffinamento

Migliorare un pensiero attraverso auto-riflessione (self-loop).

```
[Pensiero A] → [Pensiero A' Migliorato]
```

Caso d'uso: Criticare e migliorare conclusioni in bozza.

## Volume di un Pensiero

Una metrica introdotta nel paper GoT per quantificare la profondità del ragionamento:

- **Definizione**: Numero di pensieri predecessori che hanno contribuito a un dato pensiero
- **Chain-of-Thought**: Volume = 1 (lineare, ogni pensiero ha un predecessore)
- **Graph-of-Thoughts**: Il volume può essere arbitrariamente alto grazie all'aggregazione

Volume più alto = ragionamento più completo, migliore copertura dello spazio delle soluzioni.

## Applicare GoT alla Ricerca

### La Ricerca come Grafo

```
            [Domanda di Ricerca]
                    │
        ┌──────────┼──────────┐
        ▼          ▼          ▼
   [Branch A]  [Branch B]  [Branch C]
   (Casi d'uso) (Dati ROI)  (Barriere)
        │          │          │
        ▼          ▼          ▼
   [Findings A] [Findings B] [Findings C]
        │          │          │
        └────┬─────┴────┬─────┘
             ▼          ▼
        [Sintesi]  [Cross-Check]
             │          │
             └────┬─────┘
                  ▼
          [Conclusioni Finali]
                  │
                  ▼
         [Raccomandazioni]
```

### Implementazione Pratica

#### Step 1: Decomposizione (Generazione)

Scomporre la domanda principale in 3-5 sub-domande che possono essere ricercate indipendentemente.

```markdown
## Piano di Ricerca: AI nel Manufacturing

### Domanda Principale
Qual è lo stato attuale e la traiettoria futura dell'adozione AI nel manufacturing?

### Sub-Domande (Branch)
1. [Branch A] Quali sono i casi d'uso primari? (Manutenzione predittiva, QC, etc.)
2. [Branch B] Quali metriche ROI stanno riportando le aziende?
3. [Branch C] Quali sono le barriere principali all'adozione?
4. [Branch D] Come varia l'adozione per dimensione aziendale/geografia?
```

#### Step 2: Esplorazione Parallela

Ricercare ogni branch indipendentemente, mantenendo il tracking delle fonti per branch.

#### Step 3: Cross-Pollination (Aggregazione)

Cercare connessioni tra branch:

- "Il finding X del Branch A si collega alla barriera Y del Branch C"
- "I dati ROI del Branch B supportano/contraddicono i claim sui casi d'uso del Branch A"

#### Step 4: Sintesi (Aggregazione)

Fondere i findings dei branch in conclusioni coerenti che hanno alto "volume" (molti pensieri contribuenti).

#### Step 5: Raffinamento

Rivedere la sintesi per gap, contraddizioni o ragionamenti deboli. Tornare a branch specifici se necessario.

## Benefici rispetto alla Ricerca Lineare

1. **Efficienza parallela**: Ricercare aspetti multipli simultaneamente
2. **Migliore sintesi**: L'aggregazione crea conclusioni più robuste
3. **Auto-correzione**: I loop di raffinamento catturano errori e gap
4. **Flessibilità**: Possibilità di aggiungere nuovi branch durante la ricerca se le scoperte lo richiedono

## Implementazione in Claude Code

### Usare Sub-Task per Parallelizzazione

Usare il Task tool per lanciare ricerche parallele:

```
Task tool con subagent_type: "Explore"

Branch A: "Ricerca casi d'uso AI nel manufacturing. Focus su manutenzione
           predittiva e quality control. Lista 5 esempi specifici con fonti."

Branch B: "Ricerca dati ROI per AI nel manufacturing. Trova metriche specifiche,
           percentuali, case study. Minimo 3 fonti."

Branch C: "Ricerca barriere all'adozione AI nel manufacturing. Includi barriere
           tecniche, organizzative e finanziarie."
```

### Fondere i Risultati

Dopo che i sub-task completano, aggregare nel thread principale:

1. Rivedere tutti i findings dei branch
2. Identificare connessioni e contraddizioni
3. Scrivere sintesi che referenzia branch multipli
4. Applicare passaggio di raffinamento per coerenza

## Metriche di Qualità

Un buon output di ricerca basato su GoT dovrebbe avere:

- **Alto volume**: Le conclusioni finali attingono da molti pensieri intermedi
- **Cross-reference**: Connessioni esplicite tra branch
- **Conflitti risolti**: Contraddizioni affrontate, non ignorate
- **Ragionamento tracciabile**: Possibilità di seguire il percorso dalle fonti alle conclusioni
