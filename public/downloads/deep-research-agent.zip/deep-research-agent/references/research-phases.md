# Deep Research Process: 7-Phase Pipeline

This document details every phase of the in-depth research methodology, inspired by OpenAI Deep Research, Google Gemini, and academic research practices.

## Phase Overview

```
┌─────────────────────────────────────────────────────────────────┐
│  1. SCOPE → 2. PLAN → 3. RETRIEVE → 4. TRIANGULATE            │
│                                          ↓                      │
│                        5. DRAFT ← 6. CRITIQUE → 7. PACKAGE     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Phase 1: SCOPE

**Objective**: Define clear boundaries and eliminate ambiguity before investing effort in research.

### When to Clarify

Always ask clarifying questions if:

- The query is under 15 words
- Multiple valid interpretations exist
- The geographic/temporal scope is unclear
- The depth expectation is ambiguous
- The technical vs. business focus is unclear

### Clarification Categories

| Category | Example Questions |
|----------|-------------------|
| **Scope** | "Should I focus on Italy/Europe or globally?" |
| **Depth** | "Quick overview or comprehensive analysis?" |
| **Audience** | "For C-level decision-makers or technical team?" |
| **Timeframe** | "Last 12 months or broader historical trend?" |
| **Output** | "Report format, presentation outline, or executive brief?" |

### Scope Document Template

```markdown
## Research Scope

**Main Question**: [Refined question after clarification]
**Boundaries**:
- Geographic: [Specify]
- Temporal: [Specify timeframe]
- Sector/Industry: [Specify]
- Depth: [Overview / Comprehensive / Exhaustive]

**Out of Scope**: [Explicitly list what NOT to research]

**Success Criteria**: [What makes this research "complete"?]
```

---

## Phase 2: PLAN

**Objective**: Decompose the research question into parallel branches using Graph-of-Thoughts methodology.

### Decomposition Strategy

1. Identify 3-5 distinct aspects of the main question
2. Ensure branches are independently researchable
3. Plan merge points where branches will synthesize
4. Identify potential cross-branch connections

### Research Plan Template

```markdown
## Research Plan: [Topic]

### Main Research Question
[Clear and bounded question]

### Branch Structure

#### Branch A: [Aspect 1]
- Sub-questions: [List 2-3]
- Expected sources: [Types of sources to find]
- Key search terms: [Search queries]

#### Branch B: [Aspect 2]
- Sub-questions: [List 2-3]
- Expected sources: [Types of sources to find]
- Key search terms: [Search queries]

#### Branch C: [Aspect 3]
- Sub-questions: [List 2-3]
- Expected sources: [Types of sources to find]
- Key search terms: [Search queries]

### Merge Strategy
- Branch A + B merge at: [Synthesis point]
- All branches merge at: [Final synthesis]

### Expected Output
- Word count: [Estimate]
- Number of sources: [Minimum]
- Key deliverables: [List]
```

---

## Phase 3: RETRIEVE

**Objective**: Collect comprehensive source material through systematic web search.

### Search Strategy

#### Query Formulation

```
Good queries:
- "generative AI adoption enterprise 2024"
- "AI transformation ROI case study manufacturing"
- "McKinsey AI report 2024"

Queries to avoid:
- "AI machine learning deep learning enterprise business 2024 2025 report"
- Single-word searches
- Queries with excessive operators
```

#### Advanced Search Techniques

- Use quotes for exact phrases: `"generative AI adoption"`
- Use site: for specific domains: `site:mckinsey.com AI manufacturing`
- Use after: for recent content: `after:2024-01-01`
- Exclude irrelevant results: `-forum -reddit`

### Source Requirements

| Effort Level | Min Sources | Full Page Fetches |
|--------------|-------------|-------------------|
| Quick research | 5 | 5 |
| Standard | 10-15 | 10-15 |
| In-depth | 20+ | 20+ |

**Critical**: Search snippets do NOT count. You must retrieve and read full pages.

### Source Quality Hierarchy

1. **Primary Sources** (Highest priority)
   - Official company announcements
   - Peer-reviewed research
   - Government/regulatory publications
   - Original datasets

2. **Authoritative Secondary**
   - Major consulting firms (McKinsey, Gartner, Forrester)
   - Quality journalism (WSJ, FT, major tech publications)
   - Industry association reports

3. **Acceptable Secondary**
   - Reputable domain expert blogs
   - Conference proceedings
   - Well-cited Medium/Substack articles

4. **To Avoid**
   - SEO-optimized listicles
   - Anonymous forum posts
   - Content farms
   - Outdated sources (>2 years for fast-evolving topics)

### Source Tracking

For each source, record:

```json
{
  "url": "https://...",
  "title": "Source title",
  "author": "Author/Organization",
  "date": "2024-01-15",
  "type": "primary|secondary|tertiary",
  "credibility": "high|medium|low",
  "key_claims": ["claim 1", "claim 2"],
  "branch": "A|B|C",
  "notes": "Context on source quality or relevance"
}
```

---

## Phase 4: TRIANGULATE

**Objective**: Verify claims by cross-referencing and resolve conflicting information.

### Verification Matrix

| Claim | Source 1 | Source 2 | Source 3 | Status |
|-------|----------|----------|----------|--------|
| [Claim X] | Supports | Supports | - | Verified |
| [Claim Y] | Supports | Contradicts | - | Requires investigation |
| [Claim Z] | Supports | - | - | Single-source (flag) |

### Conflict Management

1. **Investigate further**: Additional searches to resolve
2. **Check source dates**: The most recent may supersede the older
3. **Check source quality**: Primary > secondary
4. **Present both views**: If unresolvable, note the disagreement

### Red Flags

- Only one source for a critical claim
- Sources citing each other (circular reference)
- Significant date discrepancy between sources
- Source bias (vendor claiming their own product is the best)

---

## Phase 5: DRAFT

**Objective**: Write a comprehensive report with appropriate citations.

### Report Structure

```markdown
# [Research Title]

*Generated: [Date] | Sources: [N] | Methodology: Deep Research with GoT*

## Executive Summary
[2-3 paragraphs covering key findings and recommendations]

## Research Methodology
[Brief description of approach, scope, limitations]

## Key Findings

### Finding 1: [Title]
[Detailed content with inline citations]

### Finding 2: [Title]
[Detailed content with inline citations]

[Continue as needed]

## Analysis
[Deeper exploration, comparisons, trend analysis]

## Conflicting Information
[Where sources disagreed, how it was resolved or not]

## Limitations & Gaps
[What could not be verified, areas requiring more research]

## Recommendations
[Actionable items based on findings]

## Sources
1. [Author/Org]. "[Title]." [Publication], [Date]. [URL]
2. ...
```

### Citation Style

**Inline citations**:

- "According to the McKinsey 2024 report, 65% of enterprises have adopted some form of AI [1]."
- "Multiple sources confirm this trend [1, 3, 7]."

**Handling uncertainty**:

- "Limited data suggests..." (when only 1-2 sources)
- "Sources conflict on this point; [Source A] states X while [Source B] states Y."

### Writing Guidelines

Do:

- Lead with key findings
- Use specific numbers and examples
- Attribute claims to sources
- Flag uncertainty explicitly

Don't:

- Use unnecessary hedging language
- Include irrelevant background
- Fabricate or guess citations
- Over-quote (paraphrase and cite instead)

---

## Phase 6: CRITIQUE

**Objective**: Self-review to identify gaps, bias, and weaknesses.

### Critical Checklist

#### Completeness

- [ ] All branches of the research plan are covered
- [ ] Every major claim has at least one citation
- [ ] The executive summary captures all key points
- [ ] Recommendations logically follow from findings

#### Accuracy

- [ ] No single-source claims without flagging
- [ ] Conflicting information addressed
- [ ] Dates and numbers double-checked
- [ ] No fabricated citations

#### Balance

- [ ] Multiple perspectives represented
- [ ] No over-reliance on one source
- [ ] Counter-arguments considered
- [ ] Own bias checked (confirmation bias, recency bias)

#### Clarity

- [ ] Logical and easy-to-follow structure
- [ ] Technical terms explained where necessary
- [ ] Length appropriate for the requested depth

### Review Actions

Based on the critique, take action:

- **Gap found**: Return to Phase 3 (Retrieve) for additional research
- **Unresolved conflict**: Return to Phase 4 (Triangulate) for deeper investigation
- **Unclear section**: Revise in Phase 5 (Draft)

---

## Phase 7: PACKAGE

**Objective**: Finalize deliverables and offer next steps.

### Output Files

```
./reports/
├── [topic]-[date].md           # Main research report
├── [topic]-sources.json        # Structured source data
├── [topic]-executive-brief.md  # Optional: 1-page summary
└── research_plan.md            # Planning artifact (for reference)
```

### File Naming Convention

```
{topic-slug}-{YYYY-MM-DD}.md

Examples:
- genai-italian-midmarket-2025-01-15.md
- ai-manufacturing-roi-2025-01-15.md
- competitive-analysis-crm-2025-01-15.md
```

### Next Step Offers

After delivering the report, offer:

- "Would you like me to create a presentation outline from this?"
- "Should I generate a 1-page executive brief?"
- "Do you need to dive deeper into any specific finding?"
- "Would you like a comparison table or visualization?"

### Quality Metadata

Include at the beginning of the report:

```markdown
---
title: [Research Title]
date: [YYYY-MM-DD]
sources: [N]
effort_level: [quick|standard|in-depth]
confidence: [high|medium|low]
methodology: Deep Research with Graph-of-Thoughts
branches: [List of researched branches]
---
```
