# Prompt Templates for Deep Research

Ready-to-use prompt patterns for different research scenarios.

## Question Refinement Prompt

Use to transform a vague request into a structured research query.

```
You are a research question refinement specialist. Your task is to
transform vague or broad questions into well-structured research queries.

Given the user's question, produce:
1. A refined main research question (clear, specific, bounded)
2. 3-5 sub-questions that decompose the main question
3. Suggested scope boundaries (geographic, temporal, sector)
4. Expected output format and depth

User's original question: "[QUESTION]"

Output format:
## Refined Research Query

### Main Question
[Clear and specific question]

### Sub-Questions
1. [Sub-question 1]
2. [Sub-question 2]
3. [Sub-question 3]

### Suggested Scope
- Geographic: [Suggestion]
- Temporal: [Suggestion]
- Sector: [Suggestion]
- Depth: [Overview / Comprehensive / Exhaustive]

### Clarifying Questions to Ask the User
- [Question 1]
- [Question 2]
```

---

## Sub-Agent Task Template

Use when launching parallel research tasks via the Task tool.

```
Research Branch [X]: [Branch Name]

## Objective
[Specific aspect to research]

## Key Questions to Answer
1. [Question 1]
2. [Question 2]
3. [Question 3]

## Source Requirements
- Minimum [N] authoritative sources
- Priority: [Primary sources / Industry reports / Academic]
- Recency: [Time constraint]

## Output Format
Provide findings as:
1. Bullet point summary (5-10 key points)
2. Source list with URLs and publication dates
3. Confidence assessment (high/medium/low per finding)
4. Any conflicting information found

## Constraints
- Focus ONLY on this branch, do not explore tangential topics
- Flag findings that connect to other branches
- Note gaps requiring additional research
```

---

## Research Synthesis Prompt

Use after collecting branch findings to synthesize them into conclusions.

```
## Research Synthesis Task

You have collected findings from multiple research branches:

### Branch A: [Name]
[Paste Branch A findings]

### Branch B: [Name]
[Paste Branch B findings]

### Branch C: [Name]
[Paste Branch C findings]

## Synthesis Instructions

1. **Identify Connections**: What themes or findings appear across multiple branches?

2. **Resolve Conflicts**: Where do branches contradict? How should it be resolved?

3. **Find Gaps**: What questions remain unanswered? What additional research is needed?

4. **Draw Conclusions**: Based on all branches, what are the 3-5 main conclusions?

5. **Generate Recommendations**: What actions follow from these conclusions?

Output: A synthesized analysis that integrates all branches into a coherent narrative.
```

---

## Source Evaluation Prompt

Use to assess the quality and reliability of a source.

```
Evaluate the following source for research purposes:

URL: [URL]
Title: [Title]
Publication/Author: [Author]
Date: [Date]

Evaluation criteria:

1. **Authority**: Is the author/organization credible in this domain?
   - [ ] Expert credentials
   - [ ] Institutional affiliation
   - [ ] Track record

2. **Accuracy**: Are the claims supported?
   - [ ] Data sources cited
   - [ ] Methodology explained
   - [ ] Peer review or editorial process

3. **Currency**: Is the information current?
   - [ ] Publication date
   - [ ] Topic currency requirements

4. **Objectivity**: Is there bias?
   - [ ] Potential conflicts of interest
   - [ ] Balanced perspective
   - [ ] Commercial motivation

5. **Coverage**: Is it comprehensive?
   - [ ] Depth of treatment
   - [ ] Scope completeness

Overall rating: [High / Medium / Low] credibility
Usage recommendation: [Primary source / Supporting source / Use with caution / Avoid]
```

---

## Report Outline Generator

Use to create a structure before writing.

```
Generate a detailed outline for a research report on:

Topic: [TOPIC]
Depth: [Overview / Comprehensive / Exhaustive]
Audience: [C-level / Technical / General]
Key findings to include: [List of main findings]

Output an outline with:
- Section titles
- Sub-section titles
- Bullet points for key content in each section
- Suggested word count per section
- Citation/source placement

Follow this general structure:
1. Executive Summary (10% of total)
2. Methodology (5%)
3. Key Findings (40%)
4. Analysis (25%)
5. Limitations (5%)
6. Recommendations (10%)
7. Sources (5%)
```

---

## Critique Prompt

Use for self-review before finalization.

```
## Research Quality Critique

Review the following research report for quality issues:

[PASTE REPORT]

Evaluate against these criteria:

### Completeness
- Do all stated research questions have answers?
- Are there obvious gaps in coverage?
- Is the executive summary accurate relative to the content?

### Accuracy
- Are all major claims cited?
- Are there single-source claims on important points?
- Is conflicting information addressed?

### Balance
- Are multiple perspectives represented?
- Is there over-reliance on a single source?
- Are counter-arguments considered?

### Clarity
- Is the structure logical?
- Are technical terms explained?
- Is the length appropriate?

### Citations
- Are all citations formatted correctly?
- Are sources high-quality and authoritative?
- Are there broken or suspicious links?

Output:
1. List of identified issues (with severity: High/Medium/Low)
2. Specific recommendations for improvement
3. Overall quality score (1-10)
```

---

## Executive Brief Generator

Use to create a condensed version of a full report.

```
Create a 1-page executive brief from the following research report:

[PASTE FULL REPORT]

Requirements:
- Maximum 500 words
- Focus on: Key findings, so-what implications, recommended actions
- Omit: Methodological details, extensive caveats, detailed source discussion
- Include: 3-5 bullet points for quick scanning
- Tone: Direct, action-oriented, suitable for C-level readers

Structure:
## Executive Brief: [Topic]
**Date**: [Date] | **Full Report**: [Link]

### Bottom Line
[1-2 sentences: The most important takeaway]

### Key Findings
- [Finding 1]
- [Finding 2]
- [Finding 3]

### Implications
[What this means for the organization]

### Recommended Actions
1. [Action 1]
2. [Action 2]
3. [Action 3]

### For More Details
See full report for methodology, sources, and detailed analysis.
```

---

## Search Query Generator

Use to generate effective search queries for a topic.

```
Generate 10 effective search queries for researching:

Topic: [TOPIC]
Focus areas: [List of specific aspects]
Recency requirement: [Timeframe]
Source types needed: [Industry reports / Academic / News / Primary]

For each query:
1. The search query itself
2. What aspect of the topic it targets
3. Expected source types to find

Consider:
- Using exact phrases in quotes
- Site-specific searches for authoritative domains
- Date filters for recent content
- Exclusion operators to filter noise

Output format:
| # | Query | Target Aspect | Expected Sources |
|---|-------|---------------|------------------|
| 1 | "..." | ... | ... |
```
