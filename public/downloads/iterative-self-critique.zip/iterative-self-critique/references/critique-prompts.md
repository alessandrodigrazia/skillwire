# Self-Critique Prompt Templates

Template di prompt per la fase di self-critique, basati sul paper Google DeepMind.

## Core Critique Prompt (Zero-Shot)

Usare questo template quando non si hanno esempi specifici del dominio.

```markdown
## Self-Critique Task

Given the domain definition:
{domain_definition}

For each action in the plan:
1. Take the action and its preconditions from the domain definition
2. Verify whether the preconditions are met for the action
3. Apply the action and provide the resulting state

The problem to solve:
{task_description}

The proposed solution:
{plan}

Evaluate the plan carefully. Verify each step as described above.
Do not stop until each action is verified; do not omit steps.

Conclude with the assessment literally either with:
- "the plan is correct"
- "the plan is wrong: [specific reason]"
- "goal not reached: [what is missing]"
```

## Critique Prompt with Few-Shot Examples

Usare questo template quando si hanno esempi di critica corretta.

```markdown
## Self-Critique Task

Given the domain definition:
{domain_definition}

For instance, we verify the following steps:
{critique_examples}

So, for each action:
1. Take the action and its preconditions from the domain definition
2. Verify whether the preconditions are met for the action
3. Apply the action and provide the resulting state

The problem to solve:
{task_description}

The proposed solution:
{plan}

Evaluate the plan carefully. Verify each step as described above.
Do not stop until each action is verified; do not omit steps.

Conclude with the assessment literally either with:
- "the plan is correct"
- "the plan is wrong: [specific reason]"
- "goal not reached: [what is missing]"
```

## Critique Example Format

Quando si forniscono esempi di critica, usare questo formato:

```markdown
### Example Critique

**Action:** action_name(param1, param2)

**Step 1 - Preconditions:**
- precondition_1: description
- precondition_2: description

**Step 2 - Verification:**
- precondition_1: TRUE/FALSE (explanation)
- precondition_2: TRUE/FALSE (explanation)
- All preconditions met: YES/NO

**Step 3 - Resulting State:**
- new_state_1
- new_state_2
- (removed: old_state_1)
```

## Simplified Critique Prompt

Per task meno formali, usare questa versione semplificata:

```markdown
## Quick Critique

Analyze this plan step by step:
{plan}

For each step:
1. What must be true BEFORE this step can execute?
2. Is that condition satisfied at this point in the sequence?
3. What changes after this step completes?

If any step has unmet prerequisites, explain the issue.
If all steps are valid and achieve the goal, confirm the plan is correct.

Verdict: [correct / incorrect: reason]
```

## Iteration Prompt

Usare questo template per le iterazioni successive alla prima:

```markdown
## Revised Plan Critique

The previous plan was incorrect:
{previous_plan}

The identified error was:
{previous_error}

Here is the revised plan:
{new_plan}

Verify that:
1. The previous error has been addressed
2. No new errors have been introduced
3. Each step's preconditions are satisfied
4. The goal is achieved

For each action, follow the 3-step verification process.

Verdict: [correct / incorrect: reason]
```

## Self-Consistency Aggregation

Quando si usa self-consistency con N critiche:

```markdown
## Critique Aggregation

{N} independent critiques were generated:

Critique 1: {verdict_1} - {reason_1}
Critique 2: {verdict_2} - {reason_2}
...
Critique N: {verdict_N} - {reason_N}

Vote count:
- Correct: {count_correct}
- Incorrect: {count_incorrect}

Majority verdict: {majority_verdict}

If incorrect, unique errors identified:
{aggregated_unique_errors}
```

## Domain-Specific Critique Sections

### For n8n Workflows

Aggiungere questa sezione al critique prompt:

```markdown
### n8n Workflow Validation Checklist

For each node:
- [ ] Input data schema matches expected format
- [ ] Required credentials/connections are referenced
- [ ] Output mapping is complete
- [ ] Error handling branch exists (if critical)

For the workflow:
- [ ] Trigger node is first
- [ ] All paths lead to completion or error handling
- [ ] No orphan nodes (disconnected from flow)
- [ ] Data transformations preserve required fields
```

### For Migration Plans

```markdown
### Migration Validation Checklist

For each migration step:
- [ ] Rollback procedure defined
- [ ] Data integrity check specified
- [ ] Downtime estimate provided
- [ ] Dependencies on previous steps explicit

For the plan:
- [ ] Order respects dependencies
- [ ] Parallel steps identified
- [ ] Testing/validation checkpoints included
- [ ] Rollback plan for entire migration exists
```

### For Architecture Decisions

```markdown
### Architecture Validation Checklist

For each component:
- [ ] Interfaces defined
- [ ] Dependencies listed
- [ ] Scaling considerations addressed
- [ ] Failure modes identified

For the system:
- [ ] Components can communicate as designed
- [ ] No circular dependencies
- [ ] Single points of failure addressed
- [ ] Data flow is consistent
```
