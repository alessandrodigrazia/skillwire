# Domain Definition Templates

Template per definire precondizioni ed effetti delle azioni in vari domini.

## Template Structure

Ogni domain definition segue questa struttura:

```markdown
## Domain: [domain_name]

### Objects
- object_type_1: description
- object_type_2: description

### Predicates (State Properties)
- predicate_1(param): what it means when true
- predicate_2(param1, param2): what it means when true

### Actions

#### action_name
- **Parameters:** (param1, param2)
- **Preconditions:** conditions that must be true
- **Effects:** changes to state after execution
```

---

## Domain: n8n Workflow

### Objects
- **node**: A workflow node (trigger, action, logic)
- **connection**: Link between nodes
- **credential**: Authentication for external service
- **data**: JSON payload flowing through workflow

### Predicates
- `is_trigger(node)`: node starts the workflow
- `has_input(node)`: node receives data from previous node
- `has_credential(node, service)`: node has valid auth for service
- `connected(node1, node2)`: data flows from node1 to node2
- `data_has_field(data, field)`: payload contains the field
- `is_configured(node)`: all required fields are set

### Actions

#### add_trigger_node
- **Parameters:** (node_type, config)
- **Preconditions:** workflow is empty OR no trigger exists
- **Effects:**
  - `is_trigger(node)` = true
  - `is_configured(node)` = true if config complete

#### add_action_node
- **Parameters:** (node, predecessor, config)
- **Preconditions:**
  - predecessor exists in workflow
  - credentials available if needed
- **Effects:**
  - `connected(predecessor, node)` = true
  - `has_input(node)` = true

#### add_if_node
- **Parameters:** (node, predecessor, condition_field)
- **Preconditions:**
  - predecessor exists
  - `data_has_field(input, condition_field)` = true
- **Effects:**
  - Creates two branches (true/false)
  - `connected(predecessor, node)` = true

#### add_set_node
- **Parameters:** (node, predecessor, transformations)
- **Preconditions:** predecessor exists
- **Effects:**
  - Data transformed according to spec
  - New fields available for downstream nodes

#### add_http_node
- **Parameters:** (node, predecessor, url, method, auth)
- **Preconditions:**
  - predecessor exists
  - if auth required: `has_credential(node, service)`
- **Effects:**
  - API call made
  - Response data available downstream

---

## Domain: Database Migration

### Objects
- **table**: Database table
- **column**: Table column
- **index**: Table index
- **constraint**: FK, unique, check constraint
- **data**: Table data/records

### Predicates
- `exists(table)`: table exists in database
- `has_column(table, column)`: table has the column
- `has_data(table)`: table contains records
- `depends_on(tableA, tableB)`: tableA has FK to tableB
- `is_backed_up(table)`: backup exists
- `is_indexed(table, column)`: index exists on column

### Actions

#### create_table
- **Parameters:** (table_name, columns, constraints)
- **Preconditions:** NOT `exists(table_name)`
- **Effects:** `exists(table_name)` = true

#### add_column
- **Parameters:** (table, column, type, nullable)
- **Preconditions:**
  - `exists(table)` = true
  - NOT `has_column(table, column)`
- **Effects:** `has_column(table, column)` = true

#### migrate_data
- **Parameters:** (source_table, target_table, mapping)
- **Preconditions:**
  - `exists(source_table)` = true
  - `exists(target_table)` = true
  - `is_backed_up(source_table)` = true (recommended)
  - target columns exist for all mapped fields
- **Effects:**
  - `has_data(target_table)` = true
  - Data transformed per mapping

#### add_foreign_key
- **Parameters:** (table, column, ref_table, ref_column)
- **Preconditions:**
  - `exists(table)` and `exists(ref_table)`
  - `has_column(table, column)` and `has_column(ref_table, ref_column)`
  - Data integrity: all values in column exist in ref_column
- **Effects:** `depends_on(table, ref_table)` = true

#### drop_table
- **Parameters:** (table)
- **Preconditions:**
  - `exists(table)` = true
  - `is_backed_up(table)` = true
  - No other table `depends_on(other, table)`
- **Effects:** `exists(table)` = false

#### create_index
- **Parameters:** (table, columns)
- **Preconditions:** `exists(table)`, columns exist
- **Effects:** `is_indexed(table, columns)` = true

---

## Domain: Software Architecture

### Objects
- **component**: Service, module, or system part
- **interface**: API or contract
- **dependency**: Relationship between components
- **data_store**: Database, cache, queue
- **network**: Communication channel

### Predicates
- `deployed(component)`: component is running
- `exposes(component, interface)`: component provides API
- `consumes(componentA, componentB.interface)`: A calls B
- `stores_data(component, data_store)`: component uses storage
- `can_reach(componentA, componentB)`: network allows communication

### Actions

#### deploy_component
- **Parameters:** (component, environment, config)
- **Preconditions:**
  - All dependencies are `deployed`
  - Required data_stores are available
  - Network configured for required connections
- **Effects:** `deployed(component)` = true

#### create_interface
- **Parameters:** (component, interface_spec)
- **Preconditions:** `deployed(component)` OR design phase
- **Effects:** `exposes(component, interface)` = true

#### add_dependency
- **Parameters:** (consumer, provider, interface)
- **Preconditions:**
  - `exposes(provider, interface)` = true
  - `can_reach(consumer, provider)` = true
- **Effects:** `consumes(consumer, provider.interface)` = true

#### provision_data_store
- **Parameters:** (data_store, type, config)
- **Preconditions:** infrastructure available
- **Effects:** data_store available for components

#### configure_network
- **Parameters:** (componentA, componentB, protocol)
- **Preconditions:** both components exist in design
- **Effects:** `can_reach(componentA, componentB)` = true

---

## Domain: Business Process

### Objects
- **task**: Work item to complete
- **role**: Person or system responsible
- **document**: Input or output artifact
- **decision**: Branch point with conditions
- **state**: Process status

### Predicates
- `completed(task)`: task is done
- `assigned_to(task, role)`: role is responsible
- `requires_input(task, document)`: task needs document
- `produces_output(task, document)`: task creates document
- `approved(document)`: document has approval

### Actions

#### assign_task
- **Parameters:** (task, role)
- **Preconditions:**
  - role has capacity
  - role has required permissions
- **Effects:** `assigned_to(task, role)` = true

#### complete_task
- **Parameters:** (task)
- **Preconditions:**
  - `assigned_to(task, some_role)` = true
  - All `requires_input(task, doc)` have `approved(doc)` or doc available
- **Effects:**
  - `completed(task)` = true
  - All `produces_output(task, doc)` documents created

#### approve_document
- **Parameters:** (document, approver_role)
- **Preconditions:**
  - document exists
  - approver_role has approval authority
- **Effects:** `approved(document)` = true

#### branch_decision
- **Parameters:** (decision, condition)
- **Preconditions:** all input data for condition available
- **Effects:** process follows appropriate branch

---

## Domain: API Integration

### Objects
- **endpoint**: API endpoint (URL + method)
- **request**: HTTP request with headers/body
- **response**: API response
- **auth_token**: Authentication credential
- **rate_limit**: API usage constraint

### Predicates
- `authenticated(endpoint)`: valid auth provided
- `within_rate_limit(endpoint)`: not throttled
- `response_ok(response)`: 2xx status
- `has_required_fields(request, fields)`: request is complete
- `response_has_data(response, field)`: response contains field

### Actions

#### authenticate
- **Parameters:** (service, credentials)
- **Preconditions:** credentials are valid
- **Effects:** `authenticated(service.endpoints)` = true, auth_token available

#### make_request
- **Parameters:** (endpoint, request)
- **Preconditions:**
  - `authenticated(endpoint)` if auth required
  - `within_rate_limit(endpoint)` = true
  - `has_required_fields(request, endpoint.required_fields)` = true
- **Effects:** response received, rate_limit counter updated

#### parse_response
- **Parameters:** (response, expected_fields)
- **Preconditions:** `response_ok(response)` = true
- **Effects:** data extracted and available for next steps

#### handle_error
- **Parameters:** (response, error_type)
- **Preconditions:** NOT `response_ok(response)`
- **Effects:** appropriate retry/fallback initiated

---

## Custom Domain Template

Usare questo template per definire un nuovo dominio:

```markdown
## Domain: [Your Domain Name]

### Objects
- **object_1**: [description]
- **object_2**: [description]

### Predicates
- `predicate_1(param)`: [when true, this means...]
- `predicate_2(p1, p2)`: [when true, this means...]

### Actions

#### action_name_1
- **Parameters:** (param1, param2)
- **Preconditions:**
  - [condition 1]
  - [condition 2]
- **Effects:**
  - [change 1]
  - [change 2]

#### action_name_2
- **Parameters:** (...)
- **Preconditions:** [...]
- **Effects:** [...]
```
