---
name: iterative-self-critique
description: Implementa self-critique iterativo per task di planning complessi (workflow, migration, architecture). Questa skill deve essere usata quando si generano output multi-step che beneficiano di validazione iterativa. Il pattern Plan-Critique-Revise migliora l'accuratezza dal 50% al 90% secondo il paper Google DeepMind 2025 "Enhancing LLM Planning Capabilities through Intrinsic Self-Critique". Funziona su Claude 3.5+.
---

# Iterative Self-Critique

Metodo per migliorare drasticamente la qualità di output di planning attraverso auto-critica strutturata e iterativa.

## Overview

Il self-critique iterativo è un pattern validato da Google DeepMind che permette agli LLM di:
1. **Generare** un piano iniziale
2. **Criticare** il piano con prompt strutturato
3. **Correggere** basandosi sugli errori identificati
4. **Iterare** fino a output corretto o max iterazioni

**Risultati paper (Claude 3.5 Sonnet):** 68% → 89.5% accuracy su task di planning.

## When to Use

Questa skill è indicata per:

| Use Case | Esempio |
|----------|---------|
| Workflow automation | Workflow n8n, Zapier, Make |
| Migration planning | Database migration, API versioning |
| Architecture design | System design, microservices |
| Process automation | Business process, approval flows |
| Multi-step sequences | Deployment pipelines, data pipelines |

**Non usare per:** Task semplici, one-shot questions, ricerche.

## Core Algorithm

```
Input: task_description, domain_definition (optional), max_iterations=5
Output: validated_plan

1. GENERATE initial plan from task_description
2. FOR iteration = 1 to max_iterations:
   a. CRITIQUE plan using 3-step validation:
      - Step 1: Identify preconditions for each action
      - Step 2: Verify preconditions are satisfied
      - Step 3: Calculate resulting state
   b. IF critique says "correct" → RETURN plan
   c. ELSE → ADD errors to context, REGENERATE plan
3. RETURN last plan (with warning if not validated)
```

## Workflow

### Step 1: Define Domain (Optional but Recommended)

Prima di generare un piano, definire il dominio con precondizioni ed effetti.

```markdown
## Domain Definition

### Actions
- **action_name**
  - Preconditions: [what must be true before]
  - Effects: [what becomes true after]
```

Per template specifici per dominio, vedere `references/domain-templates.md`.

### Step 2: Generate Initial Plan

Generare il piano per il task richiesto. Il piano deve essere una sequenza di azioni.

### Step 3: Self-Critique

Applicare il critique prompt strutturato (vedere `references/critique-prompts.md`):

```
Per ogni azione nel piano:
1. Identifica le precondizioni richieste dall'azione
2. Verifica se le precondizioni sono soddisfatte dato lo stato attuale
3. Calcola lo stato risultante dopo l'azione

Concludi con: "piano corretto" oppure "piano errato: [motivo specifico]"
```

### Step 4: Iterate or Return

- Se "piano corretto" → restituire il piano
- Se "piano errato" → aggiungere l'errore al contesto e tornare a Step 2
- Se max iterazioni raggiunto → restituire l'ultimo piano con warning

## Configuration

| Parametro | Default | Descrizione |
|-----------|---------|-------------|
| max_iterations | 5 | Numero massimo di cicli critique |
| include_domain | true | Include domain definition nel critique |
| verbose | false | Mostra ogni iterazione all'utente |
| self_consistency | false | Genera N critiche e vota a maggioranza |

## Quick Start Examples

### Example 1: n8n Workflow

**Task:** "Crea workflow n8n per sync nuovi contatti HubSpot → Slack notification"

**Domain Definition (caricato da template):**
- Nodo Trigger: deve essere primo, definisce quando parte il workflow
- Nodo HTTP/API: precondizione = credenziali valide
- Nodo IF: precondizione = input con campo da valutare
- Nodo Slack: precondizione = webhook URL configurato

**Iteration 1 - Plan:**
```
1. HubSpot Trigger (new contact)
2. IF (contact.email exists)
3. Slack (send message)
```

**Iteration 1 - Critique:**
```
Step 1: Azione "Slack" richiede webhook URL
Step 2: Webhook URL non definito nel flow
Step 3: Azione fallirà

Piano errato: manca configurazione Slack webhook
```

**Iteration 2 - Plan (corrected):**
```
1. HubSpot Trigger (new contact)
2. IF (contact.email exists)
3. Set (prepare message template)
4. Slack (send via webhook: $SLACK_WEBHOOK_URL)
```

**Iteration 2 - Critique:** "piano corretto"

### Example 2: Database Migration

**Task:** "Piano migrazione da MySQL a PostgreSQL"

Vedere `references/domain-templates.md` per domain definition specifico.

## Advanced: Self-Consistency Voting

Per task critici, abilitare self-consistency:

1. Generare N critiche indipendenti (N=3 o 5)
2. Votare a maggioranza: "corretto" vs "errato"
3. Se maggioranza "errato", aggregare tutti gli errori unici

Questo riduce i falsi positivi del ~5% secondo il paper.

## Error Context Accumulation

Ogni errore identificato viene aggiunto al contesto per le iterazioni successive:

```markdown
## Previous Attempts

### Attempt 1
Plan: [plan]
Error: [specific error from critique]

### Attempt 2
Plan: [revised plan]
Error: [new error if any]
```

Questo previene la ripetizione degli stessi errori.

## Limitations

1. **Token usage**: Ogni iterazione consuma token aggiuntivi (~2x per iterazione)
2. **Max ~10 iterazioni utili**: Oltre, i miglioramenti sono marginali
3. **Richiede domain knowledge**: La qualità della critique dipende dalla domain definition
4. **Non garantisce correttezza**: La self-critique riduce ma non elimina gli errori

## References

- `references/critique-prompts.md` - Template completi per self-critique
- `references/domain-templates.md` - Domain definition per vari use case
