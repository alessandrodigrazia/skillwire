---
name: iterative-self-critique
description: Implements iterative self-critique for complex planning tasks (workflows, migrations, architecture). This skill should be used when generating multi-step outputs that benefit from iterative validation. The Plan-Critique-Revise pattern improves accuracy from 50% to 90% according to the Google DeepMind 2025 paper "Enhancing LLM Planning Capabilities through Intrinsic Self-Critique". Works on Claude 3.5+.
---

# Iterative Self-Critique

A method to drastically improve the quality of planning outputs through structured, iterative self-critique.

## Overview

Iterative self-critique is a pattern validated by Google DeepMind that enables LLMs to:
1. **Generate** an initial plan
2. **Critique** the plan with a structured prompt
3. **Correct** based on identified errors
4. **Iterate** until the output is correct or max iterations reached

**Paper results (Claude 3.5 Sonnet):** 68% → 89.5% accuracy on planning tasks.

## When to Use

This skill is suited for:

| Use Case | Example |
|----------|---------|
| Workflow automation | n8n, Zapier, Make workflows |
| Migration planning | Database migration, API versioning |
| Architecture design | System design, microservices |
| Process automation | Business process, approval flows |
| Multi-step sequences | Deployment pipelines, data pipelines |

**Do not use for:** Simple tasks, one-shot questions, research.

## Core Algorithm

```
Input: task_description, domain_definition (optional), max_iterations=5
Output: validated_plan

1. GENERATE initial plan from task_description
2. FOR iteration = 1 to max_iterations:
   a. CRITIQUE plan using 3-step validation:
      - Step 1: Identify preconditions for each action
      - Step 2: Verify preconditions are satisfied
      - Step 3: Calculate resulting state
   b. IF critique says "correct" → RETURN plan
   c. ELSE → ADD errors to context, REGENERATE plan
3. RETURN last plan (with warning if not validated)
```

## Workflow

### Step 1: Define Domain (Optional but Recommended)

Before generating a plan, define the domain with preconditions and effects.

```markdown
## Domain Definition

### Actions
- **action_name**
  - Preconditions: [what must be true before]
  - Effects: [what becomes true after]
```

For domain-specific templates, see `references/domain-templates.md`.

### Step 2: Generate Initial Plan

Generate the plan for the requested task. The plan must be a sequence of actions.

### Step 3: Self-Critique

Apply the structured critique prompt (see `references/critique-prompts.md`):

```
For each action in the plan:
1. Identify the preconditions required by the action
2. Verify whether the preconditions are satisfied given the current state
3. Calculate the resulting state after the action

Conclude with: "plan is correct" or "plan is wrong: [specific reason]"
```

### Step 4: Iterate or Return

- If "plan is correct" → return the plan
- If "plan is wrong" → add the error to context and go back to Step 2
- If max iterations reached → return the last plan with a warning

## Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| max_iterations | 5 | Maximum number of critique cycles |
| include_domain | true | Include domain definition in the critique |
| verbose | false | Show each iteration to the user |
| self_consistency | false | Generate N critiques and use majority voting |

## Quick Start Examples

### Example 1: n8n Workflow

**Task:** "Create an n8n workflow to sync new HubSpot contacts → Slack notification"

**Domain Definition (loaded from template):**
- Trigger Node: must be first, defines when the workflow starts
- HTTP/API Node: precondition = valid credentials
- IF Node: precondition = input with field to evaluate
- Slack Node: precondition = webhook URL configured

**Iteration 1 - Plan:**
```
1. HubSpot Trigger (new contact)
2. IF (contact.email exists)
3. Slack (send message)
```

**Iteration 1 - Critique:**
```
Step 1: "Slack" action requires webhook URL
Step 2: Webhook URL not defined in the flow
Step 3: Action will fail

Plan is wrong: missing Slack webhook configuration
```

**Iteration 2 - Plan (corrected):**
```
1. HubSpot Trigger (new contact)
2. IF (contact.email exists)
3. Set (prepare message template)
4. Slack (send via webhook: $SLACK_WEBHOOK_URL)
```

**Iteration 2 - Critique:** "plan is correct"

### Example 2: Database Migration

**Task:** "Migration plan from MySQL to PostgreSQL"

See `references/domain-templates.md` for the specific domain definition.

## Advanced: Self-Consistency Voting

For critical tasks, enable self-consistency:

1. Generate N independent critiques (N=3 or 5)
2. Use majority voting: "correct" vs "wrong"
3. If majority says "wrong", aggregate all unique errors

This reduces false positives by ~5% according to the paper.

## Error Context Accumulation

Each identified error is added to the context for subsequent iterations:

```markdown
## Previous Attempts

### Attempt 1
Plan: [plan]
Error: [specific error from critique]

### Attempt 2
Plan: [revised plan]
Error: [new error if any]
```

This prevents repeating the same errors.

## Limitations

1. **Token usage**: Each iteration consumes additional tokens (~2x per iteration)
2. **Max ~10 useful iterations**: Beyond that, improvements are marginal
3. **Requires domain knowledge**: The quality of the critique depends on the domain definition
4. **Does not guarantee correctness**: Self-critique reduces but does not eliminate errors

## References

- `references/critique-prompts.md` - Complete templates for self-critique
- `references/domain-templates.md` - Domain definitions for various use cases
