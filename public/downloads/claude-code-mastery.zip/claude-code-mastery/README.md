# Claude Code Mastery — Skillwire Bundle

This bundle contains 5 skills. Install each one individually:

- skill-creator-guru.zip
- memory-manager.zip
- maia.zip
- llm-arena-vs.zip
- iterative-self-critique.zip

## Installation

For each skill ZIP:
- **Claude Code**: extract into ~/.claude/skills/ and you're done
- **Claude Desktop**: Settings → Features → Skills → Add, then upload the ZIP

Questions? hello@skillwire.ai
