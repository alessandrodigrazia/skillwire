# MaIA Context Stratification (FONTE System)

Detailed specification of the three-layer context management system.

---

## Overview

MaIA maintains three layers of context to prevent information loss across the multi-agent workflow:

1. **FONTE 1**: Long-term context (original objective + files)
2. **FONTE 2**: Summary Ledger (approved output summaries)
3. **FONTE 3**: Full Archive (complete approved outputs)

---

## FONTE 1: Long-Term Context

### Contents
- Original user objective (first request)
- Any attached files (PDF, DOCX, XLSX, etc.)
- Key constraints and preferences stated by user

### Purpose
Ensures the original goal is never lost, even in long conversations.

### Persistence
Entire conversation - never summarized or truncated.

### Usage
- Genesis Agent references to validate clarity
- All agents reference to ensure alignment with goal
- Assembler uses for final deliverable framing

### Format
```
--- FONTE 1: CONTESTO ORIGINALE ---
Obiettivo: [Original user request verbatim]
File allegati: [List of files with brief description]
Vincoli: [Any stated constraints or preferences]
--- FINE FONTE 1 ---
```

---

## FONTE 2: Summary Ledger (Primary)

### Contents
Condensed summaries of all approved Specialist outputs.

### Purpose
Efficient context for agent reasoning - allows quick understanding of what's been established without reading full outputs.

### Update Trigger
After each user approval (`[OK]` from user), add summary to ledger.

### Format
```
--- ELEMENTI APPROVATI (FONTE 2) ---
- **Output 1 (AGENT 1: Market Analyst)**: Mercato IT italiano vale 8.2B EUR, CAGR 7.3%, driver principale: cloud adoption
- **Output 2 (AGENT 2: Competitive Analyst)**: 5 competitor principali identificati, leader e X con 23% share
- **Output 3 (AGENT 3: Trend Scout)**: 4 trend emergenti: AI, zero-trust, cloud-native SIEM, XDR consolidation
--- FINE ELEMENTI APPROVATI ---
```

### Summary Guidelines
Each entry should be:
- 1-2 sentences max
- Capture key facts/insights
- Include specific numbers when available
- Enable next agent to understand context without full text

---

## FONTE 3: Full Archive (Reference)

### Contents
Complete text of all approved Specialist outputs.

### Purpose
Detail extraction when needed - used primarily by Assembler Agent.

### Storage
Maintained as reference, not injected into every prompt.

### Usage
- Assembler Agent extracts full details for final synthesis
- When specific details needed that aren't in summary
- For verification or fact-checking

### Format
```
--- ARCHIVIO COMPLETO (FONTE 3) ---

=== OUTPUT 1: AGENT 1 (Market Analyst) ===
[Full approved output text]

=== OUTPUT 2: AGENT 2 (Competitive Analyst) ===
[Full approved output text]

--- FINE ARCHIVIO ---
```

---

## Context Flow During Execution

### What Each Agent Receives

| Agent Type | Context Provided |
|------------|-----------------|
| Genesis | FONTE 1 only |
| Swarm Architect | FONTE 1 |
| Specialist | FONTE 1 + FONTE 2 + current task |
| QA | FONTE 1 + FONTE 2 + output to review |
| Orchestrator | FONTE 1 + FONTE 2 + user feedback |
| Assembler | FONTE 1 + FONTE 2 + FONTE 3 (full) |
| Stress Test | FONTE 1 + output to analyze |

### Context Update Flow

```
1. Specialist Agent executes
   - Receives: FONTE 1, FONTE 2, task description
   - Produces: Output

2. QA Agent reviews
   - Receives: FONTE 1, FONTE 2, output
   - Produces: [OK] or [REVISIONE]

3. User approves
   - Output frozen

4. Context updated
   - Add summary to FONTE 2
   - Add full text to FONTE 3

5. Next Specialist Agent
   - Receives updated FONTE 2
```

---

## Approved Ledger Management

### Adding Entries

After user approval, create summary:

```python
# Pseudocode
def add_to_ledger(agent_number, agent_role, output):
    summary = extract_key_points(output)  # 1-2 sentences
    ledger.append(f"- **Output {agent_number} ({agent_role})**: {summary}")
```

### Format Consistency

Always maintain this format:
```
- **Output N (AGENT N: [Role])**: [Summary with key facts/numbers]
```

Examples:
```
- **Output 1 (AGENT 1: Market Research Analyst)**: Mercato cybersecurity IT vale 1.8B EUR (2024), CAGR 12.3%, 65% dominated by managed services
- **Output 2 (AGENT 2: Competitive Intelligence)**: Top 5 player: Accenture (18%), Reply (12%), NTT (9%), Exprivia (7%), altri frammentati
- **Output 3 (AGENT 3: Regulatory Analyst)**: NIS2 entrata in vigore Oct 2024, compliance obbligatoria per 15k+ aziende IT, gap analysis urgente
```

---

## Context Overflow Prevention

### For Long Conversations (15+ outputs)

Create "Checkpoint Summary":

```
--- CHECKPOINT SUMMARY (Outputs 1-15) ---

**Fase 1 - Analisi di Mercato** (Output 1-3):
Mercato IT cybersecurity italiano: 1.8B EUR, CAGR 12.3%
Key insight: managed services dominant, compliance-driven growth

**Fase 2 - Competitive Landscape** (Output 4-7):
5 player principali mappati, mercato frammentato
Key insight: nessun leader >20%, opportunita per specializzazione

**Fase 3 - Strategic Positioning** (Output 8-12):
Positioning definito: "trusted advisor" per mid-market
Key insight: focus su NIS2 compliance come entry point

**Fase 4 - Go-to-Market** (Output 13-15):
Piano GTM 12 mesi, budget stimato 150k
Key insight: content-led + partnership strategy

--- FINE CHECKPOINT ---
```

### When to Create Checkpoint

- After 15 approved outputs
- When context window approaching limit
- Before major phase transition
- On user request

---

## Best Practices

1. **Keep FONTE 2 summaries tight**: Max 2 sentences per output
2. **Include numbers**: Specific data is more useful than generalities
3. **Update immediately**: Don't wait - add to ledger right after approval
4. **Preserve FONTE 3**: Never summarize the full archive
5. **Reference correctly**: Specialist can say "come indicato in Output 2..."
