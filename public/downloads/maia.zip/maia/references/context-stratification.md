# MaIA Context Stratification (SOURCE System)

Detailed specification of the three-layer context management system.

---

## Overview

MaIA maintains three layers of context to prevent information loss across the multi-agent workflow:

1. **SOURCE 1**: Long-term context (original objective + files)
2. **SOURCE 2**: Summary Ledger (approved output summaries)
3. **SOURCE 3**: Full Archive (complete approved outputs)

---

## SOURCE 1: Long-Term Context

### Contents
- Original user objective (first request)
- Any attached files (PDF, DOCX, XLSX, etc.)
- Key constraints and preferences stated by user

### Purpose
Ensures the original goal is never lost, even in long conversations.

### Persistence
Entire conversation - never summarized or truncated.

### Usage
- Genesis Agent references to validate clarity
- All agents reference to ensure alignment with goal
- Assembler uses for final deliverable framing

### Format
```
--- SOURCE 1: ORIGINAL CONTEXT ---
Objective: [Original user request verbatim]
Attached Files: [List of files with brief description]
Constraints: [Any stated constraints or preferences]
--- END SOURCE 1 ---
```

---

## SOURCE 2: Summary Ledger (Primary)

### Contents
Condensed summaries of all approved Specialist outputs.

### Purpose
Efficient context for agent reasoning - allows quick understanding of what's been established without reading full outputs.

### Update Trigger
After each user approval (`[OK]` from user), add summary to ledger.

### Format
```
--- APPROVED ELEMENTS (SOURCE 2) ---
- **Output 1 (AGENT 1: Market Analyst)**: Italian IT market worth 8.2B EUR, CAGR 7.3%, main driver: cloud adoption
- **Output 2 (AGENT 2: Competitive Analyst)**: 5 main competitors identified, leader is X with 23% share
- **Output 3 (AGENT 3: Trend Scout)**: 4 emerging trends: AI, zero-trust, cloud-native SIEM, XDR consolidation
--- END APPROVED ELEMENTS ---
```

### Summary Guidelines
Each entry should be:
- 1-2 sentences max
- Capture key facts/insights
- Include specific numbers when available
- Enable next agent to understand context without full text

---

## SOURCE 3: Full Archive (Reference)

### Contents
Complete text of all approved Specialist outputs.

### Purpose
Detail extraction when needed - used primarily by Assembler Agent.

### Storage
Maintained as reference, not injected into every prompt.

### Usage
- Assembler Agent extracts full details for final synthesis
- When specific details needed that aren't in summary
- For verification or fact-checking

### Format
```
--- FULL ARCHIVE (SOURCE 3) ---

=== OUTPUT 1: AGENT 1 (Market Analyst) ===
[Full approved output text]

=== OUTPUT 2: AGENT 2 (Competitive Analyst) ===
[Full approved output text]

--- END ARCHIVE ---
```

---

## Context Flow During Execution

### What Each Agent Receives

| Agent Type | Context Provided |
|------------|-----------------|
| Genesis | SOURCE 1 only |
| Swarm Architect | SOURCE 1 |
| Specialist | SOURCE 1 + SOURCE 2 + current task |
| QA | SOURCE 1 + SOURCE 2 + output to review |
| Orchestrator | SOURCE 1 + SOURCE 2 + user feedback |
| Assembler | SOURCE 1 + SOURCE 2 + SOURCE 3 (full) |
| Stress Test | SOURCE 1 + output to analyze |

### Context Update Flow

```
1. Specialist Agent executes
   - Receives: SOURCE 1, SOURCE 2, task description
   - Produces: Output

2. QA Agent reviews
   - Receives: SOURCE 1, SOURCE 2, output
   - Produces: [OK] or [REVISION]

3. User approves
   - Output frozen

4. Context updated
   - Add summary to SOURCE 2
   - Add full text to SOURCE 3

5. Next Specialist Agent
   - Receives updated SOURCE 2
```

---

## Approved Ledger Management

### Adding Entries

After user approval, create summary:

```python
# Pseudocode
def add_to_ledger(agent_number, agent_role, output):
    summary = extract_key_points(output)  # 1-2 sentences
    ledger.append(f"- **Output {agent_number} ({agent_role})**: {summary}")
```

### Format Consistency

Always maintain this format:
```
- **Output N (AGENT N: [Role])**: [Summary with key facts/numbers]
```

Examples:
```
- **Output 1 (AGENT 1: Market Research Analyst)**: IT cybersecurity market worth 1.8B EUR (2024), CAGR 12.3%, 65% dominated by managed services
- **Output 2 (AGENT 2: Competitive Intelligence)**: Top 5 players: Accenture (18%), Reply (12%), NTT (9%), Exprivia (7%), others fragmented
- **Output 3 (AGENT 3: Regulatory Analyst)**: NIS2 effective from Oct 2024, mandatory compliance for 15k+ IT companies, urgent gap analysis
```

---

## Context Overflow Prevention

### For Long Conversations (15+ outputs)

Create "Checkpoint Summary":

```
--- CHECKPOINT SUMMARY (Outputs 1-15) ---

**Phase 1 - Market Analysis** (Output 1-3):
Italian IT cybersecurity market: 1.8B EUR, CAGR 12.3%
Key insight: managed services dominant, compliance-driven growth

**Phase 2 - Competitive Landscape** (Output 4-7):
5 main players mapped, fragmented market
Key insight: no leader >20%, opportunity for specialization

**Phase 3 - Strategic Positioning** (Output 8-12):
Positioning defined: "trusted advisor" for mid-market
Key insight: focus on NIS2 compliance as entry point

**Phase 4 - Go-to-Market** (Output 13-15):
12-month GTM plan, estimated budget 150k
Key insight: content-led + partnership strategy

--- END CHECKPOINT ---
```

### When to Create Checkpoint

- After 15 approved outputs
- When context window approaching limit
- Before major phase transition
- On user request

---

## Best Practices

1. **Keep SOURCE 2 summaries tight**: Max 2 sentences per output
2. **Include numbers**: Specific data is more useful than generalities
3. **Update immediately**: Don't wait - add to ledger right after approval
4. **Preserve SOURCE 3**: Never summarize the full archive
5. **Reference correctly**: Specialist can say "as indicated in Output 2..."
