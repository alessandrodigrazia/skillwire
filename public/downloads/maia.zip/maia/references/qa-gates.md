# MaIA 4 QA Validation Gates

Detailed specification of the four quality gates applied by the QA Agent.

---

## Overview

The QA Agent applies four validation gates to every Specialist output. All gates must pass for `[OK]`; any failure triggers `[REVISION]`.

---

## Gate 1: Freshness Gate

**Purpose**: Ensure sources are sufficiently recent for the topic.

### Check Logic

1. Identify claims that require recent data (market stats, trends, regulations)
2. Check source dates against Freshness Policy thresholds
3. Flag if sources exceed `staleDaysWarning`

### Thresholds

| Topic Type | Max Acceptable Age |
|------------|-------------------|
| Market data, statistics | 90 days |
| Technology trends | 180 days |
| Regulatory/legal | 180 days (or post-law-change) |
| Historical facts | No limit |
| Evergreen concepts | No limit |

### Failure Condition

- Sources older than 12 months on evolving topics → `[REVISION]`
- Uses `staleDaysWarning` from Freshness Policy

### Failure Output

```
[REVISION]

**Freshness Gate**: The sources used (2019, 2021) are dated for a current market analysis. I suggest searching for more recent data (2023-2024).
```

---

## Gate 2: Recency Gate

**Purpose**: Verify facts that may have changed since knowledge cutoff.

### Check Logic

1. Identify claims about "current state" (market leaders, prices, regulations)
2. Check if these require verification post knowledge cutoff
3. Use web_search to verify when uncertain

### Scope

**Requires verification**:
- Current market share / company status
- Pricing and product features
- Leadership / organizational structure
- Recent events or announcements

**Exempt**:
- Historical facts
- Established concepts and frameworks
- Foundational knowledge

### Failure Condition

- Claims about current state without recent verification → `[REVISION]`
- Especially if time-sensitive (< 14 days per QA Policy)

### Failure Output

```
[REVISION]

**Recency Gate**: The claim "X is the market leader" dates back to my pre-cutoff knowledge. I recommend verification via web_search to confirm current status.
```

---

## Gate 3: Spec Mismatch Gate

**Purpose**: Ensure output aligns with provided files and specifications.

### Check Logic

1. Compare output against user-provided documents (SOURCE 1)
2. Check for contradictions with source material
3. Verify deliverable matches task specification

### Checks Performed

| Check | Description |
|-------|-------------|
| Factual consistency | Output doesn't contradict provided files |
| Scope alignment | Covers what was asked, nothing extraneous |
| Format compliance | Matches requested format/structure |
| Terminology | Uses terms from provided context correctly |

### Failure Condition

- Output contradicts information in provided files → `[REVISION]`
- Deliverable doesn't match task specification → `[REVISION]`

### Failure Output

```
[REVISION]

**Spec Mismatch Gate**: The provided document indicates revenue of 5.2M, but the output reports 4.8M. Verify and align with the primary source.
```

---

## Gate 4: Confidence Gate

**Purpose**: Ensure uncertain facts are appropriately flagged.

### Check Logic

1. Identify assertions presented as facts
2. Assess confidence level based on evidence
3. Flag assertions with < 95% confidence that aren't marked as uncertain

### Confidence Markers

Output should use appropriate markers:

| Confidence | Marker | Example |
|------------|--------|---------|
| High (>95%) | None needed | "The market is worth 8.2B" |
| Medium (70-95%) | "Likely", "Indicatively" | "Likely the CAGR is around 7%" |
| Low (<70%) | "[HYPOTHESIS]", "Rough estimate" | "[HYPOTHESIS] The market share could be 15-20%" |
| Unknown | "[FALLBACK_NO_SOURCE]" | See Computational Honesty Protocol |

### Failure Condition

- Facts presented with false certainty → `[REVISION]`
- Speculative statements not labeled → `[REVISION]`

### Failure Output

```
[REVISION]

**Confidence Gate**: The statement "the market will grow by 15% in 2025" is presented as certainty, but sources indicate a range of 10-18%. I suggest using "estimated between 10% and 18%".
```

---

## QA Decision Flow

```
For each Specialist output:

1. Apply Freshness Gate
   - Pass → continue
   - Fail → collect issue

2. Apply Recency Gate
   - Pass → continue
   - Fail → collect issue

3. Apply Spec Mismatch Gate
   - Pass → continue
   - Fail → collect issue

4. Apply Confidence Gate
   - Pass → continue
   - Fail → collect issue

If any issues collected:
   Output [REVISION] with all issues

If no issues:
   Output [OK]
```

---

## Computational Honesty Protocol Integration

When Specialist Agent uses `[FALLBACK_NO_SOURCE]`:

- QA Agent does NOT fail the output automatically
- Instead, evaluates the hypothesis quality:
  - Is it logically sound?
  - Are limitations clearly stated?
  - Is it useful for the next agent?

If hypothesis is reasonable, output passes. The tag itself signals transparency.

---

## QA Agent Guidelines

1. **Don't invent issues**: Only flag genuine quality concerns
2. **Be specific**: Cite exact text/claims that triggered the gate
3. **Be actionable**: Every [REVISION] must include clear suggestions
4. **Proportional rigor**: Simple outputs need less scrutiny than complex analyses
5. **Trust [FALLBACK]**: Transparent uncertainty is acceptable
