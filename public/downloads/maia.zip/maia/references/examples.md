# MaIA Workflow Examples

Detailed examples of MaIA in action across different use cases.

---

## Example 1: Market Analysis Request

### User Request
"Voglio che analizzi il mercato della cybersecurity in Italia usando l'approccio MaIA"

### Phase 1 - Clarification (Genesis Agent)

```
Perfetto, attivo la modalita MaIA per questa analisi di mercato.

Prima di procedere, ho alcune domande per garantire un'analisi completa:

1. Quale segmento specifico della cybersecurity ti interessa? (es. endpoint security, cloud security, consulenza, managed services)
```

[User responds: "Managed security services"]

```
2. Qual e l'obiettivo dell'analisi? (es. valutare opportunita di mercato, benchmarking competitivo, decisione go-to-market)
```

[User responds: "Valutare opportunita per entrare nel mercato"]

```
3. Hai bisogno di focus su qualche dimensione specifica? (es. dimensione mercato, trend tecnologici, panorama competitivo, regolamentazione)
```

[User responds: "Tutti questi aspetti"]

Genesis Agent: `[OK]` - Obiettivo chiaro, posso procedere.

---

### Phase 2 - Plan Definition (Swarm Architect)

```
Ecco il piano di lavoro per l'analisi del mercato italiano dei managed security services:

* **AGENT 1: Market Intelligence Analyst** - Ricercare e quantificare il mercato italiano dei managed security services: dimensione, tasso di crescita, principali driver e barriere, previsioni 2024-2027

* **AGENT 2: Competitive Landscape Mapper** - Identificare e profilare i principali player del mercato (locali e internazionali), analizzando posizionamento, offerta, modello di business e quote di mercato stimate

* **AGENT 3: Trend & Technology Scout** - Analizzare i trend tecnologici emergenti nel settore (XDR, SIEM cloud-native, AI-driven SOC, zero-trust) e il loro impatto sul mercato italiano

* **AGENT 4: Regulatory & Compliance Specialist** - Esaminare il contesto normativo italiano ed europeo (NIS2, DORA, GDPR) e il loro impatto sulla domanda di managed security services

* **AGENT 5: Strategic Synthesizer** - Integrare tutti gli insight in un report di analisi di mercato completo con takeaway chiave e implicazioni strategiche

Questo piano prevede 5 agenti specializzati che lavoreranno in sequenza. Ogni output sara sottoposto a Quality Assurance prima di procedere.

**Cosa ne pensi? Vuoi che proceda con questo piano, oppure preferisci modificarlo?**
```

[User: "Procedi"]

---

### Phase 3 - Execution (Sample Agent Output)

**AGENT 1: Market Intelligence Analyst**

```
Ho completato il lavoro dell'AGENT 1: Market Intelligence Analyst.

**OUTPUT:**

## Mercato Italiano Managed Security Services - Sizing & Dynamics

### Dimensione del Mercato
Il mercato italiano dei Managed Security Services (MSS) e stimato a **1.2 miliardi EUR nel 2024**, rappresentando circa il 35% del mercato cybersecurity complessivo italiano.

### Tasso di Crescita
- CAGR 2024-2027: **14.2%**
- Proiezione 2027: **1.78 miliardi EUR**
- Crescita trainata principalmente da:
  - Carenza di competenze interne (68% delle aziende cita come driver primario)
  - Obblighi NIS2 in vigore da ottobre 2024
  - Aumento attacchi ransomware (+45% YoY in Italia)

### Driver Principali
1. **Compliance normativa**: NIS2, DORA per financial services, GDPR enforcement
2. **Skill shortage**: 15.000+ posizioni cybersecurity non coperte in Italia
3. **Complessita tecnologica**: Stack security medio aziendale = 47 tool diversi
4. **Cost optimization**: MSS 30-40% meno costoso vs SOC interno

### Barriere
1. **Resistenza culturale**: 42% aziende preferisce controllo interno
2. **Integrazione legacy**: 56% ha sistemi >10 anni difficili da integrare
3. **Data sovereignty concerns**: 38% preoccupato per dati gestiti esternamente

### Segmentazione
| Segmento | % Mercato | Crescita |
|----------|-----------|----------|
| Managed Detection & Response | 35% | +18% |
| Managed SIEM/SOC | 28% | +12% |
| Vulnerability Management | 22% | +10% |
| Altri (IAM, email security) | 15% | +8% |

[Fonti: Clusit Report 2024, IDC Italy, Gartner Market Guide MSS 2024]

---

**REVISIONE QA:** [OK]

---

**Procediamo al prossimo step?**
```

---

## Example 2: Content Strategy Development

### User Request
"Devo sviluppare una content strategy per LinkedIn per il mio personal branding come AI consultant. Usa MaIA."

### Plan (After Clarification)

```
* **AGENT 1: Audience Researcher** - Profilare il target audience su LinkedIn: C-level e decision maker interessati all'AI, loro pain point, contenuti che consumano, orari di attivita

* **AGENT 2: Competitive Content Analyst** - Analizzare i top 5 AI influencer italiani su LinkedIn: temi trattati, formati utilizzati, frequenza, engagement patterns

* **AGENT 3: Content Pillar Strategist** - Definire 4-5 content pillar distintivi basati su expertise unica e gap competitivo identificato

* **AGENT 4: Editorial Calendar Designer** - Creare un calendario editoriale di 4 settimane con mix di formati, CTA specifiche, e metriche di successo

* **AGENT 5: Content Synthesizer** - Assemblare la strategia completa con executive summary e quick-start guide
```

---

## Example 3: Mid-Execution Plan Change

### Scenario
User has approved Agents 1-2, but during Agent 3 execution asks:

"Aspetta, voglio anche includere un'analisi dei prezzi dei competitor"

### Orchestrator Agent Response

```
[PIANO_AGGIORNATO]

**Task gia completati e approvati (invariati):**
* [checkmark] **AGENT 1: Market Intelligence Analyst** - Dimensionamento mercato MSS italiano (1.2B EUR, CAGR 14.2%)
* [checkmark] **AGENT 2: Competitive Landscape Mapper** - Mappatura 8 player principali con positioning

**Task aggiornati in base al tuo feedback:**
* **AGENT 3: Pricing & Business Model Analyst** - Analizzare i modelli di pricing dei competitor identificati: struttura prezzi (per-seat, per-endpoint, flat), range indicativi, differenziazione value/premium

* **AGENT 4: Trend & Technology Scout** - [invariato] Analizzare trend tecnologici emergenti

* **AGENT 5: Regulatory Specialist** - [invariato] Contesto normativo

* **AGENT 6: Strategic Synthesizer** - Integrare tutti gli insight inclusa analisi pricing nel report finale

**Vuoi procedere con questo piano aggiornato?**
```

---

## Example 4: QA Revision Cycle

### Agent Output with Issues

**AGENT 2: Competitive Analyst** produces output with this claim:

> "Accenture detiene il 45% del mercato MSS italiano"

### QA Agent Response

```
[REVISIONE]

Ho identificato alcuni aspetti che potrebbero essere migliorati:

1. **Confidence Gate**: La quota di mercato del 45% per Accenture appare elevata e non e supportata da fonti. I dati pubblici suggeriscono una quota nel range 15-20% per il leader di mercato.

2. **Freshness Gate**: La fonte citata (report 2022) e datata. Per quote di mercato, consiglio fonti 2024.

**Suggerimenti**:
- Verificare la quota Accenture con fonti piu recenti
- Usare range invece di cifra precisa se non verificabile (es. "15-20%")
- Considerare che il mercato italiano e frammentato senza leader dominante

**Prossimi passi consigliati**: Rielaborare con ricerca aggiornata su market share.
```

### User Options

```
**Come vuoi procedere?**

- [checkmark] **Accetta suggerimento QA**: Rielabora l'output incorporando i suggerimenti
- [thumbs up] **Approva output originale**: Procedi senza modifiche
- [pencil] **Personalizza**: Descrivi modifiche specifiche
```

---

## Example 5: Stress Test in Action

### Context
User has received final strategy deliverable and requests:

"Attiva lo Stress Test Agent su questa strategia"

### Stress Test Output

```
# Falle Logiche e Incoerenze

1. **Proiezione ottimistica non supportata**: La strategia assume una crescita lineare al 14% senza considerare possibile saturazione del mercato o entry di hyperscaler (AWS, Azure Security)

2. **Target segment vago**: "Mid-market" e definito come 50-500 dipendenti ma il pricing suggerito (50k+/anno) potrebbe essere fuori budget per la fascia bassa

# Assunzioni Implicite e Punti Ciechi

1. **Assunzione**: Le aziende italiane sono disposte a esternalizzare security a provider locali
   - Rischio: Trend verso vendor globali con presence locale

2. **Punto cieco**: Nessuna analisi del ciclo di vendita tipico (6-12 mesi per MSS enterprise)

# Rischi Non Considerati

1. **Rischio tecnologico**: Commoditizzazione del MDR con soluzioni AI-native che riducono margini
2. **Rischio regolatorio**: Possibili requisiti data residency che limitano scalabilita
3. **Rischio talent**: Piano assume capacita di hiring 15 security analyst in 12 mesi - mercato molto competitivo

# Domande Scomode da Porsi

1. "Se il nostro differenziatore e 'expertise italiana', cosa succede quando i big player aprono SOC in Italia?"
2. "Qual e il nostro piano B se i primi 3 enterprise deal richiedono 18 mesi invece di 6?"
3. "Come giustifichiamo pricing premium se il cliente puo comprare CrowdStrike MDR a meta prezzo?"

# Suggerimenti per il Rinforzo

1. Aggiungere scenario pessimistico con piano di contingenza
2. Definire criteri go/no-go per i primi 6 mesi
3. Quantificare costo opportunita se la strategia fallisce
4. Includere analisi sensitivity su pricing
```

---

## Example 6: Computational Honesty in Action

### Specialist Agent Cannot Find Data

**AGENT 3: Pricing Analyst** output:

```
## Analisi Pricing Competitor

### Metodologia
Ho condotto 2 ricerche web per pricing MSS competitor italiani.

### Risultati Ricerca

[FALLBACK_NO_SOURCE]
Dopo 2 tentativi di ricerca, non ho trovato dati pubblici sui prezzi specifici dei competitor italiani. Il pricing MSS e tipicamente confidenziale e negoziato caso per caso.

### Analisi Disponibile

Basandomi su benchmark internazionali e alcune disclosure pubbliche:

[IPOTESI_NON_VERIFICATA]
- **Range indicativo MDR**: 15-40 EUR/endpoint/mese
- **SOC-as-a-Service**: 5.000-25.000 EUR/mese base
- **Enterprise custom**: 100.000+ EUR/anno

Questa stima richiede validazione attraverso:
- Richieste di preventivo dirette
- Conversazioni con clienti competitor
- Analyst briefing (Gartner, Forrester)

### Fonti Parziali Utilizzate
- Gartner Peer Insights (review con hint pricing)
- Case study pubblici (senza cifre esatte)
- Benchmark US/UK adattati al mercato italiano

---

**REVISIONE QA:** [OK]

L'output riconosce trasparentemente i limiti delle fonti disponibili. L'ipotesi di pricing e ragionevole e basata su metodologia dichiarata. Il suggerimento di validazione e appropriato.
```
