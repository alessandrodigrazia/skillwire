#!/usr/bin/env python3
"""
MaIA Markdown to DOCX Converter

Converts markdown content to a professionally formatted DOCX document.
Supports headings, lists, tables, code blocks, and basic formatting.

Usage:
    python markdown_to_docx.py input.md output.docx
    python markdown_to_docx.py input.md output.docx --title "Report Title"

Or import and use programmatically:
    from markdown_to_docx import convert_markdown_to_docx
    convert_markdown_to_docx(markdown_content, "output.docx", title="My Report")
"""

import argparse
import re
import sys
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.style import WD_STYLE_TYPE
    from docx.enum.table import WD_TABLE_ALIGNMENT
except ImportError:
    print("Error: python-docx not installed. Run: pip install python-docx")
    sys.exit(1)


def setup_styles(doc):
    """Configure document styles for professional appearance."""
    styles = doc.styles

    # Heading 1
    h1_style = styles['Heading 1']
    h1_style.font.size = Pt(18)
    h1_style.font.bold = True
    h1_style.font.color.rgb = RGBColor(0, 51, 102)

    # Heading 2
    h2_style = styles['Heading 2']
    h2_style.font.size = Pt(14)
    h2_style.font.bold = True
    h2_style.font.color.rgb = RGBColor(0, 76, 153)

    # Heading 3
    h3_style = styles['Heading 3']
    h3_style.font.size = Pt(12)
    h3_style.font.bold = True
    h3_style.font.color.rgb = RGBColor(51, 51, 51)

    # Normal text
    normal_style = styles['Normal']
    normal_style.font.size = Pt(11)
    normal_style.font.name = 'Calibri'

    return doc


def parse_markdown_table(lines):
    """Parse markdown table into rows of cells."""
    rows = []
    for line in lines:
        if '|' in line and not re.match(r'^[\|\-\:\s]+$', line):
            cells = [cell.strip() for cell in line.split('|')[1:-1]]
            if cells:
                rows.append(cells)
    return rows


def add_table(doc, rows):
    """Add a formatted table to the document."""
    if not rows or len(rows) < 1:
        return

    num_cols = len(rows[0])
    table = doc.add_table(rows=len(rows), cols=num_cols)
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    for i, row_data in enumerate(rows):
        row = table.rows[i]
        for j, cell_text in enumerate(row_data):
            if j < len(row.cells):
                cell = row.cells[j]
                cell.text = cell_text
                # Bold header row
                if i == 0:
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:
                            run.bold = True

    doc.add_paragraph()  # Space after table


def process_inline_formatting(paragraph, text):
    """Apply inline formatting (bold, italic, code) to text."""
    # Pattern for bold, italic, code
    pattern = r'(\*\*.*?\*\*|\*.*?\*|`[^`]+`)'
    parts = re.split(pattern, text)

    for part in parts:
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        elif part.startswith('*') and part.endswith('*') and not part.startswith('**'):
            run = paragraph.add_run(part[1:-1])
            run.italic = True
        elif part.startswith('`') and part.endswith('`'):
            run = paragraph.add_run(part[1:-1])
            run.font.name = 'Consolas'
            run.font.size = Pt(10)
            run.font.color.rgb = RGBColor(128, 0, 0)
        else:
            paragraph.add_run(part)


def convert_markdown_to_docx(markdown_content, output_path, title=None):
    """
    Convert markdown content to DOCX format.

    Args:
        markdown_content: String containing markdown text
        output_path: Path for output DOCX file
        title: Optional document title

    Returns:
        Path to created DOCX file
    """
    doc = Document()
    setup_styles(doc)

    # Add title if provided
    if title:
        title_para = doc.add_heading(title, level=0)
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        doc.add_paragraph()

    lines = markdown_content.split('\n')
    i = 0
    in_code_block = False
    code_block_content = []
    table_lines = []
    in_table = False

    while i < len(lines):
        line = lines[i]

        # Code block handling
        if line.strip().startswith('```'):
            if in_code_block:
                # End code block
                code_text = '\n'.join(code_block_content)
                para = doc.add_paragraph()
                run = para.add_run(code_text)
                run.font.name = 'Consolas'
                run.font.size = Pt(9)
                para.paragraph_format.left_indent = Inches(0.3)
                code_block_content = []
                in_code_block = False
            else:
                # Start code block
                in_code_block = True
            i += 1
            continue

        if in_code_block:
            code_block_content.append(line)
            i += 1
            continue

        # Table handling
        if '|' in line and not line.strip().startswith('#'):
            if not in_table:
                in_table = True
                table_lines = []
            table_lines.append(line)
            i += 1
            continue
        elif in_table:
            # End of table
            rows = parse_markdown_table(table_lines)
            if rows:
                add_table(doc, rows)
            in_table = False
            table_lines = []
            # Don't increment i, process current line

        # Headings
        if line.startswith('# '):
            doc.add_heading(line[2:].strip(), level=1)
        elif line.startswith('## '):
            doc.add_heading(line[3:].strip(), level=2)
        elif line.startswith('### '):
            doc.add_heading(line[4:].strip(), level=3)
        elif line.startswith('#### '):
            doc.add_heading(line[5:].strip(), level=4)

        # Bullet lists
        elif line.strip().startswith('- ') or line.strip().startswith('* '):
            text = line.strip()[2:]
            para = doc.add_paragraph(style='List Bullet')
            process_inline_formatting(para, text)

        # Numbered lists
        elif re.match(r'^\s*\d+\.\s', line):
            text = re.sub(r'^\s*\d+\.\s', '', line)
            para = doc.add_paragraph(style='List Number')
            process_inline_formatting(para, text)

        # Horizontal rule
        elif re.match(r'^[\-\*\_]{3,}$', line.strip()):
            doc.add_paragraph('_' * 50)

        # Regular paragraph
        elif line.strip():
            para = doc.add_paragraph()
            process_inline_formatting(para, line)

        i += 1

    # Handle any remaining table
    if in_table and table_lines:
        rows = parse_markdown_table(table_lines)
        if rows:
            add_table(doc, rows)

    # Save document
    output_path = Path(output_path)
    doc.save(str(output_path))
    return output_path


def main():
    parser = argparse.ArgumentParser(
        description='Convert Markdown to DOCX format',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  python markdown_to_docx.py report.md report.docx
  python markdown_to_docx.py report.md report.docx --title "Market Analysis 2024"
        '''
    )
    parser.add_argument('input', help='Input markdown file path')
    parser.add_argument('output', help='Output DOCX file path')
    parser.add_argument('--title', '-t', help='Document title (optional)')

    args = parser.parse_args()

    # Read input file
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: Input file not found: {input_path}")
        sys.exit(1)

    with open(input_path, 'r', encoding='utf-8') as f:
        markdown_content = f.read()

    # Convert
    try:
        output_path = convert_markdown_to_docx(
            markdown_content,
            args.output,
            title=args.title
        )
        print(f"Successfully created: {output_path}")
    except Exception as e:
        print(f"Error during conversion: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
