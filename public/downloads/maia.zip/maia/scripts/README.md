# MaIA Scripts

Utility scripts for MaIA skill output processing.

## Setup

```bash
pip install -r requirements.txt
```

## Available Tools

### markdown_to_docx.py

Converts markdown deliverables to professionally formatted DOCX documents.

**Usage:**

```bash
# Basic conversion
python markdown_to_docx.py report.md report.docx

# With custom title
python markdown_to_docx.py report.md report.docx --title "Market Analysis Report"
```

**Programmatic usage:**

```python
from markdown_to_docx import convert_markdown_to_docx

# From string
content = """
# Report Title

## Section 1
Some content here.

| Column A | Column B |
|----------|----------|
| Value 1  | Value 2  |
"""

convert_markdown_to_docx(content, "output.docx", title="My Report")
```

**Supported Markdown Features:**
- Headings (H1-H4)
- Bold and italic text
- Inline code
- Bullet lists
- Numbered lists
- Tables
- Code blocks
- Horizontal rules

## Integration with MaIA Workflow

After the Assembler Agent produces the final markdown deliverable:

1. Save the markdown content to a file (e.g., `deliverable.md`)
2. Run the converter:
   ```bash
   python scripts/markdown_to_docx.py deliverable.md "Final Report.docx" --title "Project Deliverable"
   ```
3. The DOCX file is ready for distribution
