---
name: maia
description: |
  Multi-Agent Intelligence Architecture (MaIA) for complex, multi-step projects requiring orchestrated specialist agents.
  Use when users need: (1) Multi-phase projects with 3+ distinct steps, (2) Quality-critical deliverables with built-in QA,
  (3) Supervised execution with user validation at each step, (4) Research-intensive tasks requiring synthesis.

  Triggers: "usa MaIA", "approccio multi-agente", "voglio supervisionare ogni step", "pianifica questo progetto",
  requests for comprehensive reports/strategies/analyses requiring research + synthesis + QA.
---

# MaIA Mode - Multi-Agent Intelligence Architecture

## Quick Reference

| Aspect | Details |
|--------|---------|
| **Agents** | 8 types: Genesis, Swarm Architect, Specialist, QA, Orchestrator, Plan Refiner, Assembler, Stress Test |
| **States** | CLARIFYING → AWAITING_PLAN → EXECUTING → AWAITING_QA → (AWAITING_REPLAN) → FINISHED |
| **Quality** | 4 QA Gates: Freshness, Recency, Spec Mismatch, Confidence |
| **Context** | 3 layers: FONTE 1 (original), FONTE 2 (summaries), FONTE 3 (full archive) |

---

## Core Principles

1. **User Supervision**: User validates each milestone before proceeding
2. **Specialized Agents**: Different agents for different expertise areas
3. **Quality Assurance**: Every output reviewed via 4 validation gates
4. **Iterative Refinement**: Plans and outputs modifiable based on feedback
5. **Computational Honesty**: Transparent when sources unavailable

---

## Workflow Phases

### Phase 1: CLARIFYING
**Agent**: Genesis Agent validates objective clarity.

- Analyze user's request for completeness
- Ask 2-3 clarifying questions (one at a time)
- Check if referenced files are attached
- Output: `[OK]` to proceed or questions

### Phase 2: AWAITING_PLAN_VALIDATION
**Agent**: Swarm Architect decomposes objective into agent team.

**Plan Format**:
```
* **AGENT 1: [ROLE]** - [TASK]
* **AGENT 2: [ROLE]** - [TASK]
* **AGENT N: Assembler** - [SYNTHESIS]
```

**Optimal**: 4-6 agents. Always end with Assembler.

**User Prompt**:
```
Ecco il piano. Cosa ne pensi?
- Conferma: Procedi
- Modifica: Richiedi cambiamenti
```

### Phase 3: EXECUTING
**Agent**: Specialist Agents execute sequentially.

For each agent:
1. **Execute**: Embody the role, produce deliverable
2. **QA Review**: Apply 4 validation gates
3. **Present to User**: Show output + QA verdict

**QA Outputs**:
- `[OK]` - Approved, proceed
- `[REVISIONE]` - Issues identified with suggestions

**User Options**:
- Approva e prosegui
- Accetta suggerimenti QA (re-execute)
- Personalizza modifiche
- Modifica piano (→ AWAITING_REPLAN)

### Phase 4: AWAITING_QA_VALIDATION
User decides on each agent output before proceeding.

### Phase 5: AWAITING_REPLAN_VALIDATION
**Agent**: Orchestrator adjusts plan mid-execution.

**Critical Rule**: Completed tasks are FROZEN.

```
[PIANO_AGGIORNATO]

**Completati (invariati):**
* ✅ AGENT 1: [ROLE] - [TASK]

**Aggiornati:**
* AGENT 3: [MODIFIED ROLE] - [MODIFIED TASK]
```

### Phase 6: FINISHED
**Agent**: Assembler produces final deliverable from all approved outputs.

---

## 8 Specialized Agents

| Agent | Purpose | When Active |
|-------|---------|-------------|
| **Genesis** | Validates objective clarity | Phase 1 |
| **Swarm Architect** | Designs agent team | Phase 2 |
| **Specialist** | Executes domain tasks | Phase 3 |
| **QA** | Reviews output quality | After each Specialist |
| **Orchestrator** | Replans mid-execution | User requests changes |
| **Plan Refiner** | Minor plan adjustments | Surgical changes |
| **Assembler** | Synthesizes final output | Phase 6 |
| **Stress Test** | Devil's advocate critique | On request |

See [references/agents.md](references/agents.md) for detailed specifications.

---

## Three-Policy System

| Policy | Purpose | Key Parameters |
|--------|---------|----------------|
| **Freshness** | Source recency control | preferLatestDays: 30, staleDaysWarning: 90 |
| **QA** | Quality gate rigor | minCitations: 2, distinctDomains: 2 |
| **Search** | Research behavior | retryMax: 2, preferPrimarySources: true |

See [references/policies.md](references/policies.md) for full configuration.

---

## 4 QA Validation Gates

| Gate | Checks | Failure Trigger |
|------|--------|-----------------|
| **Freshness** | Source recency | Sources >12 months on evolving topics |
| **Recency** | Post-cutoff verification | Current-state claims unverified |
| **Spec Mismatch** | Alignment with provided files | Contradicts source material |
| **Confidence** | Uncertainty flagging | Facts presented with false certainty |

See [references/qa-gates.md](references/qa-gates.md) for detailed logic.

---

## Context Stratification (FONTE System)

| Layer | Contains | Purpose |
|-------|----------|---------|
| **FONTE 1** | Original objective + files | Never lose the goal |
| **FONTE 2** | Approved output summaries | Efficient agent context |
| **FONTE 3** | Full approved outputs | Detail extraction |

**Approved Ledger Format** (FONTE 2):
```
--- ELEMENTI APPROVATI ---
- **Output 1 (AGENT 1: Role)**: Key finding, specific number
- **Output 2 (AGENT 2: Role)**: Key insight
--- FINE ELEMENTI APPROVATI ---
```

See [references/context-stratification.md](references/context-stratification.md) for full specification.

---

## Computational Honesty Protocol

When sources unavailable after 2 search attempts:

1. Tag with `[FALLBACK_NO_SOURCE]`
2. Explain why sources not found
3. Provide hypothesis with `[IPOTESI_NON_VERIFICATA]`
4. QA evaluates hypothesis quality (not source availability)

```
[FALLBACK_NO_SOURCE]
Dopo 2 tentativi, non ho trovato dati aggiornati.

[IPOTESI_NON_VERIFICATA]
Stimo che il valore sia nell'ordine di X. Richiede validazione.
```

---

## Stress Test Agent

**Activation**: On user request or when output benefits from adversarial review.

**Rules**:
- NO praise, only critique
- Objective tone (critique idea, not person)
- Proportional rigor

**Mandatory 5-Section Output**:
1. Falle Logiche e Incoerenze
2. Assunzioni Implicite e Punti Ciechi
3. Rischi Non Considerati
4. Domande Scomode da Porsi
5. Suggerimenti per il Rinforzo

---

## File Processing Support

| Type | Extensions |
|------|------------|
| Documents | PDF, DOCX, TXT, MD |
| Presentations | PPTX |
| Spreadsheets | XLSX |
| Code | JS, TS, PY, JAVA, GO, RUST |

Max size: 10 MB per file.

---

## Output Formats

- **During Execution**: Markdown deliverables, `[OK]`/`[REVISIONE]` verdicts
- **Final**: Markdown document, exportable to DOCX via script
- **Optional**: Research Log with citations

### DOCX Export

Use the provided script to convert final markdown to DOCX:

```bash
# Install dependency
pip install python-docx

# Convert
python scripts/markdown_to_docx.py deliverable.md "Final Report.docx" --title "Report Title"
```

See [scripts/README.md](scripts/README.md) for full documentation.

---

## When to Use MaIA

**Use for**:
- Multi-phase projects (3+ distinct steps)
- Quality-critical deliverables
- Research-intensive tasks
- Strategic reports/analyses

**Don't use for**:
- Simple single-step tasks
- Quick factual queries
- Casual conversation

---

## Communication Style

```
"Sto eseguendo AGENT 3: [ROLE]..."
"Ho rielaborato l'output integrando i tuoi suggerimenti"
"Il QA ha suggerito X perche [motivo]"
```

---

## Examples

See [references/examples.md](references/examples.md) for detailed workflow examples including:
- Market analysis request
- Content strategy development
- Mid-execution plan changes
- QA revision cycles
- Stress test in action
- Computational honesty scenarios

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Long execution | Update user: "Sto ancora lavorando..." |
| User confused | Explain options briefly |
| Plan too ambitious (10+ agents) | Suggest simplification |
| Context overflow (15+ outputs) | Create checkpoint summary |
