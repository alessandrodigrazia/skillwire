# MaIA Three-Policy System

Detailed configuration for the three policies that control MaIA quality and research behavior.

---

## Overview

MaIA operates with three configurable policies:
1. **Freshness Policy** - Controls source recency requirements
2. **QA Policy** - Controls quality assurance rigor
3. **Search Policy** - Controls web research behavior

---

## 1. Freshness Policy (Source Date Control)

Controls how recent sources must be for different types of information.

### Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `preferLatestDays` | 30 | Prefer sources from last N days (0 = off) |
| `staleDaysWarning` | 90 | Warn if sources older than N days |
| `staleDaysError` | 180 | Exclude/error if sources older than N days |
| `requireFreshnessStrict` | false | Strict mode prevents use of old sources entirely |

### Application

- QA Agent uses these thresholds in Freshness Gate validation
- Time-sensitive topics (market data, regulations, tech trends) held to stricter standards
- Historical facts exempt from freshness requirements

### Examples

**Standard Research** (default):
- Prefer sources < 30 days old
- Warn if > 90 days
- Error if > 180 days

**Time-Sensitive Analysis** (recommended for market research):
- `preferLatestDays`: 14
- `staleDaysWarning`: 30
- `staleDaysError`: 90

---

## 2. QA Policy (Quality Gates)

Controls the rigor of quality assurance checks.

### Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `minCitationsForRevision` | 2 | Minimum distinct sources required |
| `requireEvidenceForClaims` | false | All claims must be evidenced |
| `timeSensitiveMaxAgeDays` | 14 | Max age for time-sensitive info |
| `distinctCitationsDomains` | 2 | Min distinct domains for citations |

### Application

- QA Agent applies these during the 4 Validation Gates
- `minCitationsForRevision`: If output makes claims with fewer sources, trigger [REVISION]
- `distinctCitationsDomains`: Encourages source diversity (not all from same website)

### Configuration Profiles

**Standard** (default):
- 2 citations minimum
- Evidence not strictly required
- 2 distinct domains

**High Rigor** (for critical reports):
- 4 citations minimum
- Evidence required for all claims
- 3 distinct domains

**Light** (for exploratory work):
- 1 citation minimum
- No evidence requirement
- 1 domain sufficient

---

## 3. Search Policy (Research Behavior)

Controls how web searches are performed and retried.

### Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `retryMaxAttempts` | 2 | Retry failed searches N times |
| `retryInitialDelayMs` | 800 | Initial backoff delay (exponential) |
| `enablePreferFreshHint` | true | Prefer recent sources in ranking |
| `preferPrimarySources` | true | Boost official/authoritative domains |

### Search Tool Modes

MaIA's web_search supports two modes:

1. **generic_search**: Standard web search with query
2. **url_analysis**: Deep analysis of specific URL content

### Retry Logic

When a search fails or returns insufficient results:
1. First attempt with original query
2. Wait 800ms, retry with refined query
3. Wait 1600ms (exponential backoff), final retry
4. If still failed, trigger Computational Honesty Protocol

### Source Preference

When `preferPrimarySources` is enabled, prioritize:
- Official company websites
- Government/regulatory sources
- Academic publications
- Established news outlets

Over:
- Aggregator sites
- User-generated content
- Forums/social media

---

## Policy Injection

Policies are injected into agent prompts as a summary. Each Specialist Agent receives:

```
--- ACTIVE POLICIES ---
Freshness: preferLatestDays=30, staleDaysWarning=90
QA: minCitations=2, distinctDomains=2
Search: retryMax=2, preferPrimary=true
Current Date: [CURRENT_DATE_ISO]
--- END POLICIES ---
```

This ensures consistent behavior across all agents.

---

## Date Awareness

MaIA maintains current date awareness for freshness validation:
- `currentDateISO` is injected into all prompts
- Enables accurate "days ago" calculations
- Critical for Freshness Gate and Recency Gate in QA

---

## Policy Customization

Users can adjust policies by stating preferences:

**Examples**:
- "I only want sources from the last 7 days" → `preferLatestDays: 7`
- "No need for too much rigor on sources" → Light QA profile
- "This is a critical report" → High Rigor QA profile
