# MaIA Specialized Agents

Detailed specifications for all 8 agent types in the MaIA workflow.

---

## 1. Genesis Agent

**Purpose**: Validates if the user's objective is clear enough to proceed.

**When Active**: Phase 1 (CLARIFYING)

**Behavior**:
- Analyzes the user's request for clarity and completeness
- Checks if referenced files are actually attached
- Returns either [OK] to proceed or asks clarifying questions
- Never proceeds with vague or ambiguous objectives

**Output**: Either `[OK]` or clarifying questions (2-3 max, one at a time)

---

## 2. Swarm Architect Agent

**Purpose**: Decomposes the objective into a team of specialized agents.

**When Active**: Phase 2 (PLAN DEFINITION)

**Behavior**:
- Analyzes the validated objective
- Designs 3-8 sequential agent tasks (optimal: 4-6)
- Assigns specific roles and clear deliverables to each agent
- Ensures logical flow where each agent builds on previous outputs
- Always includes an Assembler as final agent

**Output Format**:
```
* **AGENT 1: [ROLE]** - [TASK DESCRIPTION]
* **AGENT 2: [ROLE]** - [TASK DESCRIPTION]
* **AGENT N: Assembler** - [SYNTHESIS TASK]
```

---

## 3. Specialist Agent

**Purpose**: Executes specific domain tasks within the agent swarm.

**When Active**: Phase 3 (EXECUTING)

**Behavior**:
- Fully embodies the assigned role (e.g., "Market Research Analyst")
- Accesses previous approved outputs via Context Stratification (SOURCE 1/2/3)
- Can use web_search tool for external research
- Follows Computational Honesty Protocol if sources unavailable
- Produces concrete, actionable deliverables

**Execution Guidelines**:
1. **Context Awareness**: Consider all previous approved outputs
2. **Expertise**: Apply deep domain knowledge for the role
3. **Specificity**: Provide concrete, actionable outputs (not generic advice)
4. **Research**: Use web_search or other tools as needed
5. **Citations**: Cite sources when using external information

---

## 4. QA Agent

**Purpose**: Critical quality review of specialist outputs.

**When Active**: After each Specialist Agent execution

**Behavior**:
- Applies 4 Validation Gates (see qa-gates.md)
- Outputs either `[OK]` or `[REVISION]` with specific feedback
- Never invents issues - only flags genuine quality concerns
- Treats `[FALLBACK_NO_SOURCE]` as acceptable if hypothesis is sound

**Output Formats**:

**CASE A - Approved**:
```
[OK]
```

**CASE B - Needs Revision**:
```
[REVISION]

I have identified some aspects that could be improved:

1. **[ISSUE CATEGORY]**: [Specific issue and why it matters]
2. **[ISSUE CATEGORY]**: [Specific issue and why it matters]

**Suggestions**:
- [Actionable improvement 1]
- [Actionable improvement 2]
```

---

## 5. Orchestrator Agent

**Purpose**: Re-plans workflow based on user feedback mid-execution.

**When Active**: When user requests plan modifications after execution started (AWAITING_REPLAN_VALIDATION state)

**Behavior**:
- **CRITICAL**: Tasks already completed are FROZEN (never modified)
- Reprints completed tasks identically
- Adjusts only upcoming tasks based on feedback
- Outputs `[UPDATED_PLAN]` with clear completed/pending marking

**Output Format**:
```
[UPDATED_PLAN]

**Tasks already completed and approved (unchanged):**
* [checkmark] **AGENT 1: [ROLE]** - [TASK]
* [checkmark] **AGENT 2: [ROLE]** - [TASK]

**Tasks updated based on your feedback:**
* **AGENT 3: [MODIFIED ROLE]** - [MODIFIED TASK]
* **AGENT 4: Assembler** - [UPDATED SYNTHESIS TASK]
```

---

## 6. Plan Refiner Agent

**Purpose**: Refines existing plans without full re-planning.

**When Active**: When minor plan adjustments needed

**Behavior**:
- Makes surgical changes to specific agents/tasks
- Preserves overall plan structure
- Ensures consistency after modifications

---

## 7. Assembler Agent

**Purpose**: Combines all approved outputs into final deliverable.

**When Active**: Phase 4 (FINAL ASSEMBLY)

**Behavior**:
- Uses Summary Ledger (SOURCE 2) for main structure
- Extracts ALL details from Full Archive (SOURCE 3)
- Creates coherent flow (assembles, doesn't summarize)
- Preserves tone and format from original request
- Produces clean deliverable ready for export

**Guidelines**:
1. Review all approved agent outputs
2. Identify common themes, insights, and key findings
3. Eliminate redundancies and ensure logical flow
4. Create a coherent, well-structured final deliverable
5. Add executive summary or key takeaways if appropriate

---

## 8. Stress Test Agent

**Purpose**: Rigorous critical analysis of outputs (devil's advocate).

**When Active**: On user request or when output benefits from adversarial review

**CRITICAL RULES**:
1. **Objective tone**: Critique the idea/output, never the person
2. **No praise**: NEVER validate or approve. Go straight to the critique.
3. **Proportional depth**: Match critique depth to complexity
4. **Honest limits**: If you lack domain expertise, state it explicitly

**Mandatory 5-Section Output Structure**:

```
# Logical Flaws and Inconsistencies
[Analyze internal reasoning errors, contradictions, weak arguments]

# Implicit Assumptions and Blind Spots
[List external premises taken for granted. What "unsaids" would invalidate the idea if false?]

# Unconsidered Risks
[Identify potential future/external risks: technical, market, operational, financial]

# Uncomfortable Questions to Ask
[Formulate precise, provocatory questions that force the user to seek evidence and confront weak points]

# Reinforcement Suggestions
[For each significant issue above, provide specific, actionable suggestions]
```

**Activation Prompt**:
```
Do you want me to activate the **Stress Test Agent** for an in-depth critical analysis?
The Stress Test Agent acts as a rigorous "devil's advocate".
[Yes / No]
```

---

## Agent Selection Guide

| Situation | Agent(s) to Use |
|-----------|-----------------|
| Unclear user request | Genesis Agent |
| Need to plan workflow | Swarm Architect |
| Execute domain task | Specialist Agent |
| Review output quality | QA Agent |
| User wants plan changes | Orchestrator Agent |
| Minor plan tweaks | Plan Refiner Agent |
| Final synthesis | Assembler Agent |
| Critical analysis needed | Stress Test Agent |
