# MaIA Workflow Examples

Detailed examples of MaIA in action across different use cases.

---

## Example 1: Market Analysis Request

### User Request
"I want you to analyze the cybersecurity market in Italy using the MaIA approach"

### Phase 1 - Clarification (Genesis Agent)

```
Perfect, activating MaIA mode for this market analysis.

Before proceeding, I have a few questions to ensure a complete analysis:

1. Which specific segment of cybersecurity are you interested in? (e.g., endpoint security, cloud security, consulting, managed services)
```

[User responds: "Managed security services"]

```
2. What is the objective of the analysis? (e.g., assess market opportunities, competitive benchmarking, go-to-market decision)
```

[User responds: "Assess opportunities for market entry"]

```
3. Do you need a focus on any specific dimension? (e.g., market size, technology trends, competitive landscape, regulation)
```

[User responds: "All these aspects"]

Genesis Agent: `[OK]` - Objective clear, I can proceed.

---

### Phase 2 - Plan Definition (Swarm Architect)

```
Here is the work plan for the analysis of the Italian managed security services market:

* **AGENT 1: Market Intelligence Analyst** - Research and quantify the Italian managed security services market: size, growth rate, main drivers and barriers, forecast 2024-2027

* **AGENT 2: Competitive Landscape Mapper** - Identify and profile key players in the market (local and international), analyzing positioning, offering, business model, and estimated market share

* **AGENT 3: Trend & Technology Scout** - Analyze emerging technology trends in the sector (XDR, Cloud-native SIEM, AI-driven SOC, zero-trust) and their impact on the Italian market

* **AGENT 4: Regulatory & Compliance Specialist** - Examine the Italian and European regulatory context (NIS2, DORA, GDPR) and their impact on demand for managed security services

* **AGENT 5: Strategic Synthesizer** - Integrate all insights into a comprehensive market analysis report with key takeaways and strategic implications

This plan includes 5 specialized agents working sequentially. Each output will undergo Quality Assurance before proceeding.

**What do you think? Do you want to proceed with this plan, or would you prefer to modify it?**
```

[User: "Proceed"]

---

### Phase 3 - Execution (Sample Agent Output)

**AGENT 1: Market Intelligence Analyst**

```
I have completed the work of AGENT 1: Market Intelligence Analyst.

**OUTPUT:**

## Italian Managed Security Services Market - Sizing & Dynamics

### Market Size
The Italian Managed Security Services (MSS) market is estimated at **1.2 billion EUR in 2024**, representing approximately 35% of the total Italian cybersecurity market.

### Growth Rate
- CAGR 2024-2027: **14.2%**
- Projection 2027: **1.78 billion EUR**
- Growth driven mainly by:
  - Internal skills shortage (68% of companies cite as primary driver)
  - NIS2 obligations effective from October 2024
  - Increase in ransomware attacks (+45% YoY in Italy)

### Main Drivers
1. **Regulatory compliance**: NIS2, DORA for financial services, GDPR enforcement
2. **Skill shortage**: 15,000+ unfilled cybersecurity positions in Italy
3. **Technological complexity**: Average corporate security stack = 47 different tools
4. **Cost optimization**: MSS 30-40% cheaper vs internal SOC

### Barriers
1. **Cultural resistance**: 42% of companies prefer internal control
2. **Legacy integration**: 56% have systems >10 years old difficult to integrate
3. **Data sovereignty concerns**: 38% worried about externally managed data

### Segmentation
| Segment | % Market | Growth |
|---------|----------|--------|
| Managed Detection & Response | 35% | +18% |
| Managed SIEM/SOC | 28% | +12% |
| Vulnerability Management | 22% | +10% |
| Others (IAM, email security) | 15% | +8% |

[Sources: Clusit Report 2024, IDC Italy, Gartner Market Guide MSS 2024]

---

**QA REVISION:** [OK]

---

**Shall we proceed to the next step?**
```

---

## Example 2: Content Strategy Development

### User Request
"I need to develop a LinkedIn content strategy for my personal branding as an AI consultant. Use MaIA."

### Plan (After Clarification)

```
* **AGENT 1: Audience Researcher** - Profile the target audience on LinkedIn: C-levels and decision-makers interested in AI, their pain points, content they consume, activity times

* **AGENT 2: Competitive Content Analyst** - Analyze top 5 Italian AI influencers on LinkedIn: topics covered, formats used, frequency, engagement patterns

* **AGENT 3: Content Pillar Strategist** - Define 4-5 distinctive content pillars based on unique expertise and identified competitive gap

* **AGENT 4: Editorial Calendar Designer** - Create a 4-week editorial calendar with a mix of formats, specific CTAs, and success metrics

* **AGENT 5: Content Synthesizer** - Assemble the complete strategy with executive summary and quick-start guide
```

---

## Example 3: Mid-Execution Plan Change

### Scenario
User has approved Agents 1-2, but during Agent 3 execution asks:

"Wait, I also want to include a competitor pricing analysis"

### Orchestrator Agent Response

```
[UPDATED_PLAN]

**Tasks already completed and approved (unchanged):**
* [checkmark] **AGENT 1: Market Intelligence Analyst** - Italian MSS market sizing (1.2B EUR, CAGR 14.2%)
* [checkmark] **AGENT 2: Competitive Landscape Mapper** - Mapping of 8 main players with positioning

**Tasks updated based on your feedback:**
* **AGENT 3: Pricing & Business Model Analyst** - Analyze pricing models of identified competitors: pricing structure (per-seat, per-endpoint, flat), indicative ranges, value/premium differentiation

* **AGENT 4: Trend & Technology Scout** - [unchanged] Analyze emerging technology trends

* **AGENT 5: Regulatory Specialist** - [unchanged] Regulatory context

* **AGENT 6: Strategic Synthesizer** - Integrate all insights including pricing analysis into final report

**Do you want to proceed with this updated plan?**
```

---

## Example 4: QA Revision Cycle

### Agent Output with Issues

**AGENT 2: Competitive Analyst** produces output with this claim:

> "Accenture holds 45% of the Italian MSS market"

### QA Agent Response

```
[REVISION]

I have identified some aspects that could be improved:

1. **Confidence Gate**: The 45% market share for Accenture seems high and is not supported by sources. Public data suggests a share in the 15-20% range for the market leader.

2. **Freshness Gate**: The cited source (2022 report) is dated. For market shares, I recommend 2024 sources.

**Suggestions**:
- Verify Accenture's share with more recent sources
- Use a range instead of a precise figure if not verifiable (e.g., "15-20%")
- Consider that the Italian market is fragmented without a dominant leader

**Recommended next steps**: Rework with updated research on market share.
```

### User Options

```
**How do you want to proceed?**

- [checkmark] **Accept QA suggestion**: Rework output incorporating suggestions
- [thumbs up] **Approve original output**: Proceed without changes
- [pencil] **Customize**: Describe specific changes
```

---

## Example 5: Stress Test in Action

### Context
User has received final strategy deliverable and requests:

"Activate the Stress Test Agent on this strategy"

### Stress Test Output

```
# Logical Flaws and Inconsistencies

1. **Unsupported optimistic projection**: The strategy assumes linear growth at 14% without considering market saturation or entry of hyperscalers (AWS, Azure Security)

2. **Vague target segment**: "Mid-market" is defined as 50-500 employees but suggested pricing (50k+/year) might be out of budget for the lower end

# Implicit Assumptions and Blind Spots

1. **Assumption**: Italian companies are willing to outsource security to local providers
   - Risk: Trend towards global vendors with local presence

2. **Blind Spot**: No analysis of typical sales cycle (6-12 months for enterprise MSS)

# Unconsidered Risks

1. **Technological Risk**: Commoditization of MDR with AI-native solutions reducing margins
2. **Regulatory Risk**: Possible data residency requirements limiting scalability
3. **Talent Risk**: Plan assumes ability to hire 15 security analysts in 12 months - highly competitive market

# Uncomfortable Questions to Ask

1. "If our differentiator is 'Italian expertise', what happens when big players open SOCs in Italy?"
2. "What is our Plan B if the first 3 enterprise deals take 18 months instead of 6?"
3. "How do we justify premium pricing if the client can buy CrowdStrike MDR at half price?"

# Reinforcement Suggestions

1. Add pessimistic scenario with contingency plan
2. Define go/no-go criteria for the first 6 months
3. Quantify opportunity cost if strategy fails
4. Include sensitivity analysis on pricing
```

---

## Example 6: Computational Honesty in Action

### Specialist Agent Cannot Find Data

**AGENT 3: Pricing Analyst** output:

```
## Competitor Pricing Analysis

### Methodology
I conducted 2 web searches for Italian competitor MSS pricing.

### Research Results

[FALLBACK_NO_SOURCE]
After 2 research attempts, I did not find public data on specific pricing of Italian competitors. MSS pricing is typically confidential and negotiated case-by-case.

### Available Analysis

Based on international benchmarks and some public disclosures:

[UNVERIFIED_HYPOTHESIS]
- **Indicative MDR Range**: 15-40 EUR/endpoint/month
- **SOC-as-a-Service**: 5,000-25,000 EUR/month base
- **Enterprise Custom**: 100,000+ EUR/year

This estimate requires validation through:
- Direct quote requests
- Conversations with competitor clients
- Analyst briefings (Gartner, Forrester)

### Partial Sources Used
- Gartner Peer Insights (reviews with pricing hints)
- Public case studies (without exact figures)
- US/UK benchmarks adapted to Italian market

---

**QA REVISION:** [OK]

The output transparently acknowledges the limits of available sources. The pricing hypothesis is reasonable and based on stated methodology. The validation suggestion is appropriate.
```
