---
name: maia
description: Use when orchestrating multi-phase projects (3+ steps) with specialist agents, quality gates, and user validation at each milestone.
---

# MaIA Mode - Multi-Agent Intelligence Architecture

## Quick Reference

| Aspect | Details |
|--------|---------|
| **Agents** | 8 types: Genesis, Swarm Architect, Specialist, QA, Orchestrator, Plan Refiner, Assembler, Stress Test |
| **States** | CLARIFYING → AWAITING_PLAN → EXECUTING → AWAITING_QA → (AWAITING_REPLAN) → FINISHED |
| **Quality** | 4 QA Gates: Freshness, Recency, Spec Mismatch, Confidence |
| **Context** | 3 layers: SOURCE 1 (original), SOURCE 2 (summaries), SOURCE 3 (full archive) |

---

## Core Principles

1. **User Supervision**: User validates each milestone before proceeding
2. **Specialized Agents**: Different agents for different expertise areas
3. **Quality Assurance**: Every output reviewed via 4 validation gates
4. **Iterative Refinement**: Plans and outputs modifiable based on feedback
5. **Computational Honesty**: Transparent when sources unavailable

---

## Workflow Phases

### Phase 1: CLARIFYING
**Agent**: Genesis Agent validates objective clarity.

- Analyze user's request for completeness
- Ask 2-3 clarifying questions (one at a time)
- Check if referenced files are attached
- Output: `[OK]` to proceed or questions

### Phase 2: AWAITING_PLAN_VALIDATION
**Agent**: Swarm Architect decomposes objective into agent team.

**Plan Format**:
```
* **AGENT 1: [ROLE]** - [TASK]
* **AGENT 2: [ROLE]** - [TASK]
* **AGENT N: Assembler** - [SYNTHESIS]
```

**Optimal**: 4-6 agents. Always end with Assembler.

**User Prompt**:
```
Here is the plan. What do you think?
- Confirm: Proceed
- Modify: Request changes
```

### Phase 3: EXECUTING
**Agent**: Specialist Agents execute sequentially.

For each agent:
1. **Execute**: Embody the role, produce deliverable
2. **QA Review**: Apply 4 validation gates
3. **Present to User**: Show output + QA verdict

**QA Outputs**:
- `[OK]` - Approved, proceed
- `[REVISION]` - Issues identified with suggestions

**User Options**:
- Approve and proceed
- Accept QA suggestions (re-execute)
- Customize changes
- Modify plan (→ AWAITING_REPLAN)

### Phase 4: AWAITING_QA_VALIDATION
User decides on each agent output before proceeding.

### Phase 5: AWAITING_REPLAN_VALIDATION
**Agent**: Orchestrator adjusts plan mid-execution.

**Critical Rule**: Completed tasks are FROZEN.

```
[UPDATED_PLAN]

**Completed (unchanged):**
* ✅ AGENT 1: [ROLE] - [TASK]

**Updated:**
* AGENT 3: [MODIFIED ROLE] - [MODIFIED TASK]
```

### Phase 6: FINISHED
**Agent**: Assembler produces final deliverable from all approved outputs.

---

## 8 Specialized Agents

| Agent | Purpose | When Active |
|-------|---------|-------------|
| **Genesis** | Validates objective clarity | Phase 1 |
| **Swarm Architect** | Designs agent team | Phase 2 |
| **Specialist** | Executes domain tasks | Phase 3 |
| **QA** | Reviews output quality | After each Specialist |
| **Orchestrator** | Replans mid-execution | User requests changes |
| **Plan Refiner** | Minor plan adjustments | Surgical changes |
| **Assembler** | Synthesizes final output | Phase 6 |
| **Stress Test** | Devil's advocate critique | On request |

See [references/agents.md](references/agents.md) for detailed specifications.

---

## Three-Policy System

| Policy | Purpose | Key Parameters |
|--------|---------|----------------|
| **Freshness** | Source recency control | preferLatestDays: 30, staleDaysWarning: 90 |
| **QA** | Quality gate rigor | minCitations: 2, distinctDomains: 2 |
| **Search** | Research behavior | retryMax: 2, preferPrimarySources: true |

See [references/policies.md](references/policies.md) for full configuration.

---

## 4 QA Validation Gates

| Gate | Checks | Failure Trigger |
|------|--------|-----------------|
| **Freshness** | Source recency | Sources >12 months on evolving topics |
| **Recency** | Post-cutoff verification | Current-state claims unverified |
| **Spec Mismatch** | Alignment with provided files | Contradicts source material |
| **Confidence** | Uncertainty flagging | Facts presented with false certainty |

See [references/qa-gates.md](references/qa-gates.md) for detailed logic.

---

## Context Stratification (SOURCE System)

| Layer | Contains | Purpose |
|-------|----------|---------|
| **SOURCE 1** | Original objective + files | Never lose the goal |
| **SOURCE 2** | Approved output summaries | Efficient agent context |
| **SOURCE 3** | Full approved outputs | Detail extraction |

**Approved Ledger Format** (SOURCE 2):
```
--- APPROVED ELEMENTS ---
- **Output 1 (AGENT 1: Role)**: Key finding, specific number
- **Output 2 (AGENT 2: Role)**: Key insight
--- END APPROVED ELEMENTS ---
```

See [references/context-stratification.md](references/context-stratification.md) for full specification.

---

## Computational Honesty Protocol

When sources unavailable after 2 search attempts:

1. Tag with `[FALLBACK_NO_SOURCE]`
2. Explain why sources not found
3. Provide hypothesis with `[UNVERIFIED_HYPOTHESIS]`
4. QA evaluates hypothesis quality (not source availability)

```
[FALLBACK_NO_SOURCE]
After 2 attempts, I did not find updated data.

[UNVERIFIED_HYPOTHESIS]
I estimate the value is in the order of X. Requires validation.
```

---

## Stress Test Agent

**Activation**: On user request or when output benefits from adversarial review.

**Rules**:
- NO praise, only critique
- Objective tone (critique idea, not person)
- Proportional rigor

**Mandatory 5-Section Output**:
1. Logical Flaws and Inconsistencies
2. Implicit Assumptions and Blind Spots
3. Unconsidered Risks
4. Uncomfortable Questions to Ask
5. Reinforcement Suggestions

---

## File Processing Support

| Type | Extensions |
|------|------------|
| Documents | PDF, DOCX, TXT, MD |
| Presentations | PPTX |
| Spreadsheets | XLSX |
| Code | JS, TS, PY, JAVA, GO, RUST |

Max size: 10 MB per file.

---

## Output Formats

- **During Execution**: Markdown deliverables, `[OK]`/`[REVISION]` verdicts
- **Final**: Markdown document, exportable to DOCX via script
- **Optional**: Research Log with citations

### DOCX Export

Use the provided script to convert final markdown to DOCX:

```bash
# Install dependency
pip install python-docx

# Convert
python scripts/markdown_to_docx.py deliverable.md "Final Report.docx" --title "Report Title"
```

See [scripts/README.md](scripts/README.md) for full documentation.

---

## When to Use MaIA

**Use for**:
- Multi-phase projects (3+ distinct steps)
- Quality-critical deliverables
- Research-intensive tasks
- Strategic reports/analyses

**Don't use for**:
- Simple single-step tasks
- Quick factual queries
- Casual conversation

---

## Communication Style

```
"Executing AGENT 3: [ROLE]..."
"I have reworked the output integrating your suggestions"
"QA suggested X because [reason]"
```

---

## Examples

See [references/examples.md](references/examples.md) for detailed workflow examples including:
- Market analysis request
- Content strategy development
- Mid-execution plan changes
- QA revision cycles
- Stress test in action
- Computational honesty scenarios

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Long execution | Update user: "Still working..." |
| User confused | Explain options briefly |
| Plan too ambitious (10+ agents) | Suggest simplification |
| Context overflow (15+ outputs) | Create checkpoint summary |
