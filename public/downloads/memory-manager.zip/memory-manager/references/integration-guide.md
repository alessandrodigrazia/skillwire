# Integration Guide: Adding Memory to Skills

This guide explains how to add persistent memory to any Claude Code skill.

## Contents

- [Quick Start](#quick-start)
- [Folder Structure](#folder-structure)
- [SKILL.md Template](#skillmd-template)
- [Auto-Load Pattern](#auto-load-pattern)
- [Auto-Save Pattern](#auto-save-pattern)
- [Examples by Skill Type](#examples-by-skill-type)
- [Troubleshooting](#troubleshooting)

---

## Quick Start

To add memory to an existing skill:

1. Create `memory/` folder in skill directory
2. Create subdirectories based on memory types needed
3. Create `_index.json` file
4. Add "Memory Integration" section to SKILL.md
5. Test with sample save/recall operations

---

## Folder Structure

### Basic Setup

```
.claude/skills/{skill-name}/
├── SKILL.md
├── references/
└── memory/                    # Add this folder
    ├── _index.json           # Always required
    ├── users/                # If tracking people
    │   └── {user-id}.json
    ├── projects/             # If tracking deals/initiatives
    │   └── {project-slug}.json
    └── preferences/          # If tracking styles/patterns
        └── {context}.json
```

### Index File Template

Create `memory/_index.json`:

```json
{
  "updated": "2026-01-06T10:00:00Z",
  "users": [],
  "projects": [],
  "preferences": []
}
```

### Choose Your Memory Types

| Skill Type | Recommended Memory |
|------------|-------------------|
| Sales/CRM | projects/, users/ |
| Coaching | users/ |
| Content creation | preferences/ |
| Project management | projects/, users/ |
| Newsletter | projects/, preferences/ |

---

## SKILL.md Template

Add this section to your skill's SKILL.md (before "## References" or at the end):

```markdown
## Memory Integration

This skill supports persistent cross-session memory.

### Storage
- Path: `.claude/skills/{skill_name}/memory/`
- Types: users/, projects/, preferences/

### Auto-Load (Skill Start)
At the beginning of any session:
1. Check if user/project is mentioned
2. Load `memory/_index.json`
3. Search for matching entries
4. Load relevant JSON files
5. Include facts in conversation context

### Auto-Save (via session close automation)
At session close:
1. Identifies this skill was used
2. Extracts key facts from conversation
3. Proposes save with user confirmation
4. Updates memory files and index

### Manual Operations
- Save fact: `/memory remember {type} {id} {fact}`
- Recall: `/memory recall {query}`
- List all: `/memory list`
```

---

## Auto-Load Pattern

### When to Load Memory

Load memory automatically when:
- User mentions a person by name (-> check users/)
- User mentions a company/deal (-> check projects/)
- Skill has style preferences to apply (-> check preferences/)

### Load Workflow

```
1. Parse user request for entity mentions
2. Read memory/_index.json
3. Search keywords for matches
4. For each match:
   a. Load full JSON file
   b. Extract relevant facts
   c. Include in context
5. Proceed with skill workflow
```

### Example: Sales CRM Auto-Load

```
User: "Prepare for Acme Corp meeting tomorrow"

Auto-Load Steps:
1. Detect "Acme Corp" -> search projects/
2. Load _index.json -> find "acme-ai-transformation"
3. Load projects/acme-ai-transformation.json
4. Extract facts:
   - Budget: 500k EUR
   - Status: qualification
   - Stakeholders: jane-smith, john-doe
5. Load users/jane-smith.json, users/john-doe.json
6. Include all context in meeting prep
```

---

## Auto-Save Pattern

### What to Save

Extract and propose saving:
- **Facts**: New information learned (budget, dates, decisions)
- **Preferences**: User feedback on style/format
- **Status changes**: Deal progression, assessment results
- **Relationships**: New stakeholders, project links

### What NOT to Save

Never auto-save:
- Sensitive personal data (without explicit consent)
- Temporary/session-specific info
- Duplicate facts already stored
- Speculative or uncertain information

### Save Workflow

```
1. At skill end or /memory consolidate
2. Analyze conversation for key facts
3. Classify each fact:
   - User fact (person info)
   - Project fact (deal/initiative info)
   - Preference fact (style/pattern)
4. Present to user:
   "Save these facts?
   - User 'jane-smith': prefers direct communication [Y/N]
   - Project 'acme': budget confirmed 500k [Y/N]"
5. For confirmed facts:
   a. Load or create JSON file
   b. Add fact with timestamp and source
   c. Update _index.json keywords
```

---

## Examples by Skill Type

### Sales CRM

**Memory Types**: projects/, users/

**What to Save:**
- Prospect company info (industry, size, budget)
- Stakeholder roles and preferences
- Qualification scores and status
- Meeting outcomes and next steps

**Auto-Load Triggers:**
- Company name mentioned
- Person name mentioned
- "Follow up on" or "Update on" phrases

### Career Coach

**Memory Types**: users/

**What to Save:**
- Assessment scores
- Goal statement evolution
- Session insights and breakthroughs
- Preferred coaching style

**Auto-Load Triggers:**
- User starts new session (load their profile)
- Reference to previous session

### Content Writer

**Memory Types**: preferences/

**What to Save:**
- Tone feedback (too formal, perfect, etc.)
- Anti-patterns identified (words to avoid)
- Preferred content length
- Hook styles that worked

**Auto-Load Triggers:**
- Every session (load style preferences)

### Presentation Builder

**Memory Types**: projects/

**What to Save:**
- Presentation context (client, objective)
- Persona preferences (CFO vs CIO angle)
- Approved messaging and claims
- Revision history

**Auto-Load Triggers:**
- Client/project name mentioned
- "Continue with" or "Update" phrases

### Newsletter Manager

**Memory Types**: projects/, preferences/

**What to Save:**
- Edition history (topics covered)
- Top performing content
- Style guide refinements
- Source quality feedback

**Auto-Load Triggers:**
- "New edition" or "Next week" phrases
- Content type mentioned

---

## Troubleshooting

### Index Out of Sync

**Symptom**: Recall doesn't find known entries

**Fix**: Rebuild index by scanning all JSON files in memory/

```
1. List all .json files in users/, projects/, preferences/
2. For each file, extract id and keywords
3. Rebuild _index.json
```

### Duplicate Facts

**Symptom**: Same fact appears multiple times

**Fix**: Before saving, check if fact already exists (same key)
- If exists with same value: skip
- If exists with different value: update timestamp

### Large Memory Files

**Symptom**: Files getting too big (>50 facts)

**Fix**: Consolidate or archive old facts
- Keep only most recent value for each key
- Move historical values to separate archive file

### Cross-Skill Confusion

**Symptom**: Memory from wrong skill appears

**Fix**: Each skill has isolated memory folder
- Never read other skills' memory/
- If needed, user must explicitly mention source
