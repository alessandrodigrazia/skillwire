# Memory Schema

Standard JSON schema for the 3 memory types.

## User Memory

**File**: `memory/users/{user_id}.json`

**Use**: People (clients, users, stakeholders)

```json
{
  "id": "jane-smith",
  "type": "user",
  "created": "2026-01-06T10:00:00Z",
  "updated": "2026-01-06T14:30:00Z",
  "facts": [
    {
      "key": "role",
      "value": "HR Director at Acme Corp",
      "source": "career-coach session",
      "timestamp": "2026-01-06T10:00:00Z"
    },
    {
      "key": "assessment.score",
      "value": 3.2,
      "source": "coach assessment",
      "timestamp": "2026-01-06T10:30:00Z"
    },
    {
      "key": "goal_statement",
      "value": "Lead people-first transformation",
      "source": "coaching session-8",
      "timestamp": "2026-01-06T14:30:00Z"
    }
  ],
  "preferences": [
    {
      "key": "communication_style",
      "value": "direct, data-driven",
      "source": "user feedback",
      "timestamp": "2026-01-06T11:00:00Z"
    }
  ],
  "relationships": [
    "project:acme-ai-transformation"
  ]
}
```

### User Memory Fields

| Field | Type | Description |
|-------|------|-------------|
| id | string | Unique slug (lowercase, hyphen) |
| type | string | Always "user" |
| created | ISO8601 | Creation timestamp |
| updated | ISO8601 | Last updated |
| facts | array | List of structured facts |
| preferences | array | Communication/style preferences |
| relationships | array | Links to projects/other users |

### Fact Structure

| Field | Type | Description |
|-------|------|-------------|
| key | string | Hierarchical key (e.g., "assessment.score") |
| value | any | Value (string, number, boolean, object) |
| source | string | Origin of the fact (skill, session, user) |
| timestamp | ISO8601 | When recorded |

## Project Memory

**File**: `memory/projects/{project_slug}.json`

**Use**: Deals, opportunities, initiatives

```json
{
  "id": "acme-ai-transformation",
  "type": "project",
  "status": "qualification",
  "created": "2026-01-03T09:00:00Z",
  "updated": "2026-01-06T16:00:00Z",
  "facts": [
    {
      "key": "company",
      "value": "Acme Corp",
      "source": "sales-crm prospect-intelligence",
      "timestamp": "2026-01-03T09:00:00Z"
    },
    {
      "key": "industry",
      "value": "Manufacturing",
      "source": "sales-crm prospect-intelligence",
      "timestamp": "2026-01-03T09:00:00Z"
    },
    {
      "key": "qualification.score",
      "value": 7.5,
      "source": "sales-crm qualify-opportunity",
      "timestamp": "2026-01-05T10:00:00Z"
    },
    {
      "key": "budget.q1_2026",
      "value": "500k EUR",
      "source": "meeting-2026-01-06",
      "timestamp": "2026-01-06T16:00:00Z"
    }
  ],
  "stakeholders": [
    "jane-smith",
    "john-doe"
  ],
  "timeline": [
    {
      "event": "first-meeting",
      "date": "2026-01-03",
      "notes": "Discovery call, identified AI use cases"
    },
    {
      "event": "proposal-sent",
      "date": "2026-01-06",
      "notes": "Business case with 3 scenarios"
    }
  ]
}
```

### Project Memory Fields

| Field | Type | Description |
|-------|------|-------------|
| id | string | Unique slug |
| type | string | Always "project" |
| status | string | lead/qualification/proposal/negotiation/closed |
| created | ISO8601 | Creation timestamp |
| updated | ISO8601 | Last updated |
| facts | array | List of structured facts |
| stakeholders | array | Involved user IDs |
| timeline | array | Chronological events |

### Status Values

| Status | Description |
|--------|-------------|
| lead | First contact, not qualified |
| qualification | In qualification phase |
| proposal | Proposal sent |
| negotiation | Negotiation in progress |
| closed-won | Won |
| closed-lost | Lost |

## Preference Memory

**File**: `memory/preferences/{context}.json`

**Use**: Styles, recurring patterns

```json
{
  "id": "content-style",
  "type": "preference",
  "context": "content-writer",
  "created": "2026-01-02T08:00:00Z",
  "updated": "2026-01-06T09:00:00Z",
  "facts": [
    {
      "key": "tone",
      "value": "direct, no buzzwords",
      "source": "user feedback",
      "timestamp": "2026-01-02T08:00:00Z"
    },
    {
      "key": "anti_patterns",
      "value": ["em dash", "buckle up", "game-changer"],
      "source": "skill guidelines",
      "timestamp": "2026-01-02T08:00:00Z"
    },
    {
      "key": "preferred_length",
      "value": "1200-1500 chars",
      "source": "user feedback",
      "timestamp": "2026-01-06T09:00:00Z"
    }
  ]
}
```

### Preference Memory Fields

| Field | Type | Description |
|-------|------|-------------|
| id | string | Unique slug |
| type | string | Always "preference" |
| context | string | Reference skill |
| created | ISO8601 | Creation timestamp |
| updated | ISO8601 | Last updated |
| facts | array | List of preferences |

## Index File

**File**: `memory/_index.json`

Index for fast search.

```json
{
  "updated": "2026-01-06T16:00:00Z",
  "users": [
    {
      "id": "jane-smith",
      "keywords": ["hr", "director", "acme", "assessment", "goal"],
      "updated": "2026-01-06T14:30:00Z"
    }
  ],
  "projects": [
    {
      "id": "acme-ai-transformation",
      "keywords": ["acme", "manufacturing", "ai", "500k"],
      "status": "qualification",
      "updated": "2026-01-06T16:00:00Z"
    }
  ],
  "preferences": [
    {
      "id": "content-style",
      "keywords": ["content", "tone", "style"],
      "context": "content-writer",
      "updated": "2026-01-06T09:00:00Z"
    }
  ]
}
```

## Conventions

### ID/Slug

- Lowercase
- Hyphen for spaces
- No special characters
- Examples: `jane-smith`, `acme-ai-transformation`, `content-style`

### Timestamps

- ISO8601 format: `2026-01-06T10:00:00Z`
- Always UTC

### Hierarchical Keys

Use dot notation for hierarchies:
- `assessment.score`
- `budget.q1_2026`
- `contact.email`

### Source Naming

Conventions for source:
- Skill: `sales-crm prospect-intelligence`
- Session: `coach session-8`
- Meeting: `meeting-2026-01-06`
- User: `user feedback`
- System: `system auto`
