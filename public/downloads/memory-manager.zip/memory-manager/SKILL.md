---
name: memory-manager
description: Persistent cross-session memory system for Claude Code skills. This skill should be used when saving facts about users/projects/preferences, retrieving stored information before starting work, consolidating session knowledge, or managing memory lifecycle. Enables distributed storage where each skill manages its own memory folder.
---

# Memory Manager

> Persistent cross-session memory for Claude Code skills

## Contents

- [When to Use](#when-to-use)
- [Triggers](#triggers)
- [Architecture](#architecture-distributed-storage)
- [Memory Types](#memory-types)
- [Operations](#operations)
- [Workflows](#standard-workflows)
- [Integration](#integration-with-other-skills)
- [Implementation Notes](#implementation-notes)

## When to Use

This skill manages persistent memory for Claude Code, where sessions do NOT persist between invocations.

**NOT needed** for Claude Desktop with Projects (it has built-in Project Knowledge).

## Triggers

- `/memory remember {type} {id} {fact}` - Save a fact
- `/memory recall {query}` - Retrieve information
- `/memory consolidate` - Extract key facts from session
- `/memory forget {id}` - Remove information
- `/memory list [type]` - List available memory

## Architecture: Distributed Storage

Each skill manages its **own** memory (no cross-skill search):

```
.claude/skills/
├── sales-crm/
│   └── memory/
│       ├── projects/      # Deals/opportunities
│       ├── users/         # Stakeholders
│       └── _index.json
├── career-coach/
│   └── memory/
│       ├── users/         # User profiles
│       └── _index.json
└── [other skills]/
    └── memory/
```

## Memory Types

### User Memory (`memory/users/{user_id}.json`)

People: clients, users, stakeholders.

**Use cases**: Roles, preferences, assessments, relationships.

### Project Memory (`memory/projects/{project_slug}.json`)

Projects: deals, opportunities, initiatives.

**Use cases**: Status, stakeholders, timeline, deliverables.

### Preference Memory (`memory/preferences/{context}.json`)

Patterns: styles, recurring preferences.

**Use cases**: Tone of voice, preferred formats, anti-patterns.

## Operations

### 1. REMEMBER (Save)

Save a fact to the appropriate memory.

**Input**: type, id, fact
**Output**: Save confirmation

```
User: Remember that Acme Corp has Q1 2026 budget of 500k for AI

Claude: Saving to project memory "acme-corp":
- Fact: budget.q1_2026 = 500k
- Source: direct conversation
- Timestamp: 2026-01-06

Saved.
```

### 2. RECALL (Search)

Retrieve relevant information.

**Input**: text query or specific id
**Output**: Relevant facts with source and timestamp

```
User: What do you know about Jane Smith?

Claude: User memory "jane-smith":
- Role: HR Director at Acme Corp (2026-01-03)
- Assessment score: 3.2/5 (2026-01-05)
- Goal: "Lead people-first transformation" (2026-01-06)
- Relationships: project acme-ai-transformation
```

### 3. CONSOLIDATE (Extract)

Extract key facts from the current conversation.

**Input**: Conversation text (automatic)
**Output**: List of facts to save (with confirmation)

```
User: Consolidate this session

Claude: Key facts extracted:

**User Memory** (jane-smith):
- Prefers direct communication
- Q1 goal: reduce turnover 10%

**Project Memory** (acme-ai-transformation):
- Status: proposal-sent
- Decision date: 2026-01-15

Save these facts? [Y/N for each]
```

### 4. FORGET (Delete)

Remove obsolete information.

**Input**: id or query
**Output**: Deletion confirmation

### 5. LIST (Index)

List available memory.

**Input**: type (optional)
**Output**: Memory index

## Standard Workflows

### Skill Start

```
1. Identify active skill
2. Load skill's memory/_index.json
3. If user/project mentioned -> load specific file
4. Use context in conversation
```

### Skill End (manual)

```
1. User: "/memory consolidate"
2. Extract key facts from conversation
3. Classify by type (user/project/preference)
4. Propose save (never automatic)
5. Save with user confirmation
```

### Session Close (via automation)

```
1. Identify which skill was used
2. Extract key facts automatically
3. Save to skill/memory/ with confirmation
4. Update _index.json
```

## Integration with Other Skills

Skills can use memory-manager as a pattern. Every skill with memory should:

1. Have a `memory/` folder with appropriate subdirectories
2. Have `_index.json` for fast search
3. Document in the "Memory Integration" section of its own SKILL.md

### Example Skills with Memory

| Skill Type | Memory Types | Use Case |
|------------|-------------|----------|
| Sales CRM | projects/, users/ | Deal tracking, stakeholders |
| Career Coach | users/ | User progress, assessments |
| Presentation Builder | projects/ | Presentations in progress |
| Content Writer | preferences/ | Post style, patterns |
| Newsletter | projects/, preferences/ | Newsletter editions |

## Implementation Notes

### Persistence

- JSON files in `.claude/skills/{skill}/memory/`
- Synced via cloud storage (OneDrive, Dropbox, etc.)
- No external database

### Privacy

- Local storage only (no external cloud services)
- Explicit forget command for GDPR compliance
- Never auto-save without user confirmation

### Limitations (v1)

- Keyword search (no semantic)
- Manual consolidation (no auto-LLM)
- No automatic cross-references

## Documentation

- JSON Schema: `references/memory-schema.md`
- Integration Guide: `references/integration-guide.md`
