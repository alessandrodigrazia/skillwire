# Troubleshooting Guide

Common issues and solutions for Content Pipeline Pro.

---

## Content Generation Issues

### Posts are too short or too long

**Symptoms**: Generated content consistently outside your configured character range.

**Solutions**:
- QA Director enforces your configured length limits. If content is still off:
  - Verify your editorial profile has correct min/max values
  - Check if source content has sufficient substance (minimum ~300 words recommended)
  - Ensure the 5-part structure is complete (missing parts cause short output)
  - Review numbered section (most common area for length adjustment)

### Voice does not match expectations

**Symptoms**: Output feels generic, lacks strategic framing, or does not sound like your brand.

**Solutions**:
- Review your editorial profile voice settings
- Check if historical context is enabled (critical for voice consistency)
- Verify forbidden patterns are correctly configured
- Compare output against [content_examples.md](content_examples.md)
- Consider adding more specific voice rules to your profile

### QA always rewrites

**Symptoms**: Every piece gets a REWRITE verdict.

**Solutions**:
- **This is by design.** REWRITE is the default. The rewritten version IS the final output.
- QA rewrites are generally improvements, not failures
- If you want a more lenient system, adjust QA strictness in your profile
- If rewrites feel like lateral moves (not improvements), review your writer prompts

### Classification seems wrong

**Symptoms**: Content classified into unexpected categories.

**Solutions**:
- Review your category definitions -- are they clear and distinct?
- Check edge case rules in [classification_guide.md](classification_guide.md)
- Common confusion points:
  - Product launch (ANNOUNCEMENT) vs. analysis of a launch (ANALYSIS)
  - Tutorial content (TUTORIAL) vs. description of capabilities (ANNOUNCEMENT)
- You can override classification: "Process this as ANALYSIS: [content]"

---

## Onboarding Issues

### Profile feels wrong after setup

**Symptoms**: Output does not match what you expected based on onboarding answers.

**Solutions**:
- Say "Show my current editorial profile" to review settings
- Say "Update my editorial profile" to modify specific sections
- Start with a few test pieces and iterate on the profile
- The profile is designed to evolve -- do not expect perfection on first setup

### Not sure how to define categories

**Solutions**:
- Start with the default 4-category system (Announcement, Analysis, Tutorial, Signal)
- Customize later once you see how content flows through the pipeline
- 2-4 categories work best for most content programs
- Each category should answer a different audience question

### Not sure about writer profiles

**Solutions**:
- Start with default writers matching your categories
- The most important settings are: mission, business question, and voice
- You can always refine writer prompts after seeing initial output

---

## Integration Issues

### Database not returning historical context

**Symptoms**: Posts lack voice consistency, no improvement from having a database configured.

**Solutions**:
- Verify database credentials and connectivity
- Ensure table has records with matching category values and Published status
- Check field names match exactly (case-sensitive)
- Need at least 3-5 published records per category for meaningful context
- Test with a manual query to verify the database returns data

### Zapier/Apify not working

**Symptoms**: Automated triggers not firing, content not being fetched.

**Solutions**:
- Verify MCP server configuration in your Claude setup
- Check API credentials
- Test webhooks manually with Zapier's built-in testing
- Verify Apify Actor input format
- Review logs for error messages

---

## Quality Issues

### Output feels too generic

**Solutions**:
- Provide richer source material (longer, more detailed articles)
- Enable historical context (database integration)
- Add more specific voice rules to your editorial profile
- Include specific forbidden patterns for generic phrases you want to avoid
- Add custom rules like "Always include at least one specific data point"

### Output does not answer the right question

**Solutions**:
- Check if the content was classified correctly
- Review your category business questions -- are they specific enough?
- Verify writer mission statements match your intent
- Override classification if needed

### Amplification text is weak

**Solutions**:
- Review your persona definitions -- are voice descriptions specific enough?
- Check persona-to-category mapping
- Ensure max length is appropriate (too short limits quality, too long dilutes impact)
- Compare against examples in [personal_amplifier.md](personal_amplifier.md)

---

## Performance Issues

### Processing takes too long

**Symptoms**: More than 60 seconds for a single piece.

**Solutions**:
- This is within normal range for complex content with historical context
- If consistently slow, check if database queries are timing out
- Simplify QA strictness (lenient mode is faster)
- Process shorter source material

### Token usage seems high

**Solutions**:
- Historical context adds ~2,000 tokens per piece
- Reduce historical limit (e.g., from 10 to 5 recent posts)
- Shorter source material uses fewer tokens
- Typical usage: 3,000-5,000 tokens per piece without context

---

## Common Questions

**Q: Can I use this for platforms other than LinkedIn?**
A: Yes. During onboarding, configure your platform, length, and formatting preferences. The pipeline adapts to blogs, newsletters, Twitter/X, Substack, or any text-based platform.

**Q: Can I have multiple editorial profiles?**
A: Currently the skill manages one profile per conversation context. For multiple profiles, specify which to use when invoking: "Process this using my newsletter profile."

**Q: How do I add new categories later?**
A: Say "Update my editorial profile" and add new categories with their definitions, business questions, and writer assignments.

**Q: Can multiple people use the same pipeline?**
A: Yes. Share the editorial profile configuration so all team members produce consistent output. The profile acts as your editorial style guide.

**Q: What if I want to skip QA?**
A: Say "Process this with QA disabled." The writer output goes directly to publish-ready. Not recommended for production use.
