# Integrations Guide

## Overview

Content Pipeline Pro works standalone with manual input, but it can also integrate with external platforms for automated content discovery, publishing, and logging. All integrations are optional.

---

## Integration Points in the Pipeline

| Step | Integration | Purpose |
|------|-------------|---------|
| 1. Ingestion | Zapier, Apify, n8n | Automated content discovery |
| 3. Historical Context | Airtable, Notion | Voice consistency via recent posts |
| 7. Publishing | Zapier, n8n, webhooks | Automated posting |
| 7. Logging | Airtable, Notion | Post history and analytics |

---

## Content Ingestion Integrations

### Zapier

**Use case**: Trigger content processing from email, RSS feeds, YouTube playlists, or any of Zapier's 5000+ app connectors.

**Setup**:
1. Create a Zapier account (free tier available)
2. Build a Zap with your trigger (e.g., Gmail label, RSS feed, YouTube playlist)
3. Configure the action to send content to Claude via webhook or Zapier MCP

**Example triggers**:
- Gmail: New email with specific label -> extract body text
- RSS: New feed item -> extract article URL and summary
- YouTube: New video in playlist -> extract video metadata

**MCP Setup** (for Claude Desktop/Code):
```json
{
  "mcpServers": {
    "zapier-mcp": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://mcp.zapier.com/<YOUR_URL>"]
    }
  }
}
```

### Apify

**Use case**: Web scraping and content extraction (YouTube transcripts, article text, RSS monitoring).

**Useful Actors**:
- `apify/youtube-transcript`: Extract video transcripts
- `apify/website-content-crawler`: Extract clean article text from URLs
- `apify/rss-feed-reader`: Monitor RSS feeds

**MCP Setup**:
```json
{
  "mcpServers": {
    "apify": {
      "command": "npx",
      "args": ["-y", "@apify/actors-mcp-server"],
      "env": { "APIFY_TOKEN": "your_token_here" }
    }
  }
}
```

**Cost**: Free tier provides $5/month of credits, sufficient for ~100 articles and 200 video transcripts.

### n8n

**Use case**: Self-hosted workflow automation with full control.

**Setup**: Configure webhooks in n8n to receive content, process through pipeline, and publish results.

---

## Database Integrations

### Airtable

**Use case**: Store published content for historical context, analytics, and deduplication.

**Required table schema**:

| Field | Type | Purpose |
|-------|------|---------|
| ContentText | Long text | Full published content |
| Category | Single select | Content category |
| Status | Single select | Draft, Published, Archived |
| PublishedDate | Date with time | Publication timestamp |
| SourceURL | URL | Original source link |
| SourceType | Single select | Article, Video, RSS, Manual |

**Optional fields**: ShortTitle, AmplificationText, EngagementScore, Platform

**Configuration**:
```yaml
database:
  enabled: true
  platform: "airtable"
  base_id: "appXXXXXXXXXXXXXX"
  table_name: "Content Pipeline"
  api_key: "patXXXXXXXXXXXXXX"
  historical_limit: 10
  order_by: "PublishedDate"
```

**How historical context works**:
1. Before writing, query the last N posts in the same category
2. Inject these posts into the writer prompt as calibration context
3. The writer uses them for voice consistency but never references them explicitly

### Notion

**Use case**: Alternative to Airtable for teams already using Notion.

**Setup**: Use the Notion API to query a database with similar fields. Configure the database ID and API key in your editorial profile.

### No Database

If you prefer not to use a database, the pipeline works without historical context. Writers use only the editorial profile for voice calibration.

---

## Publishing Integrations

### Manual Publishing

Default mode. The pipeline returns formatted content ready to copy/paste to your platform.

### Automated Publishing via Zapier

**Setup**: Create a Zap that receives finalized content via webhook and publishes to your platform.

**Example flow**:
```
Pipeline completes
  -> Webhook to Zapier
  -> Zapier publishes to LinkedIn/Twitter/blog
  -> Zapier logs to Airtable
  -> Zapier sends confirmation email
```

**Typical task consumption**: ~5 Zapier tasks per published piece.

### Automated Publishing via n8n

**Setup**: Create an n8n workflow with a webhook trigger that receives pipeline output and publishes.

---

## Workflow Patterns

### Pattern A: Article to LinkedIn Post (Manual)

```
1. You paste article text
2. Pipeline: classify -> write -> QA -> amplify
3. You copy/paste to LinkedIn
```

### Pattern B: RSS to Content (Semi-Automated)

```
1. Zapier monitors RSS feeds
2. New items sent to you for review
3. You select items to process
4. Pipeline produces content
5. You publish manually
```

### Pattern C: Email to Published Post (Fully Automated)

```
1. Zapier triggers on labeled email
2. Content extracted and sent to pipeline
3. Pipeline processes end-to-end
4. Zapier publishes to platform
5. Zapier logs to database
6. You receive confirmation email
```

---

## Cost Estimates

### Zapier
- Free: 100 tasks/month, 15-minute intervals
- Professional ($19.99/month): 750 tasks/month, 2-minute intervals
- For 3 posts/day: ~450 tasks/month (Professional tier recommended)

### Apify
- Free: $5/month credits (~100 articles or 200 transcripts)
- Personal ($49/month): $50 credits
- Typical monthly cost for moderate use: $2-5

### Airtable
- Free: 1,000 records, sufficient for most content programs
- Plus ($10/month): 5,000 records

---

## Troubleshooting

**Zapier webhooks not triggering**: Test with Zapier's "Test & Review" feature. Verify webhook URL and JSON payload format.

**Apify Actors failing**: Check input format, verify target URL is accessible, review Actor run logs.

**Database queries returning empty**: Verify table has records with matching category and status. Check field names are exact matches (case-sensitive).

**Historical context not loading**: Verify database integration is enabled and credentials are correct. Test with a manual query first.
