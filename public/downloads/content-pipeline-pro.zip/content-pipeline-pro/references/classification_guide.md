# Content Classification Guide

## Overview

The **Chief Editor** (Classifier) is the first agent in the pipeline. It analyzes incoming content and assigns it to ONE of your defined editorial categories. This classification determines which specialized writer profile handles the content.

Correct classification is critical: it ensures each piece is processed with the right strategic framework and business question.

---

## How Classification Works

**Role**: Chief Editor (Classifier)
**Function**: Content type detection and categorization
**Input**: Raw content (article text, video transcript, RSS summary, manual input)
**Output**: A single category label from your editorial profile

---

## Default Category System

If you do not define custom categories during onboarding, the skill uses this proven 4-category system:

### 1. ANNOUNCEMENT

**Definition**: Content primarily about a new product launch, feature release, partnership, event, or initiative.

**Indicators**:
- Product launches or releases
- New feature announcements
- Company partnerships or acquisitions
- Funding rounds, market entry news
- Official statements from companies

**Business Question**: "Why does this matter for my business?"

### 2. ANALYSIS

**Definition**: An opinion piece, market trend analysis, strategic reflection, or commentary presenting a thesis or framework.

**Indicators**:
- Expert opinion or commentary
- Market trend analysis
- Strategic implications of events
- Thought leadership pieces
- Predictions and forecasts

**Business Question**: "How should I think about this differently?"

### 3. TUTORIAL

**Definition**: A practical case study, guide, how-to, or description of a concrete process. Its purpose is to teach or demonstrate.

**Indicators**:
- Step-by-step guides
- How-to articles and case studies
- Workflow descriptions
- Tool usage guides
- Practical examples with instructions

**Business Question**: "What can my team do now that they couldn't before?"

### 4. SIGNAL

**Definition**: Catch-all for content that does not clearly fit other categories -- weak signals, emerging trends, multi-topic roundups, or broad patterns.

**Indicators**:
- Multi-topic articles or summaries
- Industry news roundups
- Emerging weak signals
- Meta-commentary about the industry

**Business Question**: "What am I missing that I should be watching?"

---

## Custom Category System

During onboarding, you can define 2-6 custom categories. For each, provide:

1. **Name**: Short label (e.g., "PRODUCT_UPDATE", "OPINION", "HOW_TO", "TREND_WATCH")
2. **Definition**: 2-3 sentence description of what content belongs here
3. **Indicators**: Bullet list of signals that suggest this category
4. **Business Question**: The question this content answers for your audience
5. **Priority**: If content could fit multiple categories, which takes precedence?

### Example Custom Categories

**For a SaaS company blog**:
- PRODUCT_UPDATE: New features, releases, improvements
- CUSTOMER_STORY: Case studies, testimonials, use cases
- INDUSTRY_INSIGHT: Market trends, competitive analysis
- BEST_PRACTICE: How-to guides, tips, workflows

**For a personal newsletter**:
- DEEP_DIVE: Long-form analysis on a single topic
- QUICK_TAKE: Brief commentary on a recent event
- CURATED: Collection of interesting links with commentary

---

## The Classification Prompt Template

This prompt is generated from your editorial profile:

```
# ROLE AND CONTEXT

You are the Chief Editor for "{content_program_name}". Your task is to analyze
the provided content and classify it into exactly ONE of the following categories
based on its primary nature and purpose.

# CATEGORIES

{for each category in profile.categories}
* **{category.name}**: {category.definition}
{end for}

# TASK

Read the content provided below and determine which single category it belongs to.

# PRIORITIZATION

When content could fit multiple categories, use this priority order:
{numbered list of categories in priority order}

# OUTPUT FORMAT

Return ONLY the category name in uppercase. No additional text, explanation,
or punctuation.
```

---

## Classification Best Practices

### Prioritization Order

When content spans multiple categories, apply this default priority:
1. If there is a clear announcement, classify as your announcement category
2. If there is a how-to or tutorial component, use your tutorial category
3. If it presents a thesis or opinion, use your analysis category
4. Default to your catch-all/signal category only when truly ambiguous

### Edge Cases

**Product launch with tutorial**: Announcement (the news is primary)
**Tutorial using a new product**: Tutorial (the how-to is primary)
**Analysis of a product launch**: Analysis (the thesis is primary)
**Multi-topic roundup**: Signal/catch-all (no single dominant theme)

### Common Mistakes

- Classifying based on source type rather than content type (a YouTube video can be any category)
- Over-using the catch-all category (force yourself to find the dominant theme first)
- Confusing announcements with tutorials (announcement = "what was launched" vs. tutorial = "how to use it")

---

## Testing Your Classification

Before finalizing, ask three questions:

1. **What is the PRIMARY purpose of this content?** (announce, analyze, teach, or signal?)
2. **What question does it answer?** (map to your category business questions)
3. **If I had to pick ONE writer, who would handle this best?** (that determines the category)

---

## Integration with Pipeline

Once classification is complete, the category determines:

1. **Historical Context**: Query for recent posts in the same category (if database configured)
2. **Writer Selection**: Route to the matching writer profile
3. **QA Validation**: Verify the output answers the correct business question
4. **Amplification Persona**: Select the appropriate persona (if configured)
