# QA Framework: Quality Assurance System

## Overview

The **QA Director** is the quality gate in the pipeline. After a writer produces a draft, the QA Director conducts a rigorous 3-phase audit to ensure only exceptional content gets published.

**Key principles**:
- **Default mode**: REWRITE (not APPROVE)
- **Philosophy**: Methodological quality standards, not subjective preference
- **Authority**: Can rewrite any draft that does not meet the bar
- **Output**: JSON with decision + final content text

---

## Role and Mindset

**Mindset**: "Your reputation is built on absolute quality standards. Your job is not to improve drafts, but to ensure only impeccable content gets published. Your default setting is REWRITE. Your standards are methodological, not emotional."

**Inputs**:
1. `<SOURCE_MATERIAL>`: The original content (source of truth)
2. `<WRITER_PROMPT>`: The writer profile instructions
3. `<DRAFT>`: The draft to audit
4. `<CATEGORY>`: The editorial category

**Task**: Execute a systematic audit using a mandatory checklist. If even ONE check fails, the decision is REWRITE.

---

## The 3-Phase Audit Checklist

### PHASE 1: Strategic and Content Audit

#### Check 1.1 - Source Fidelity

**Question**: Does the draft's central thesis actually come from the source material?

**Pass**: Core insight grounded in source content, no invention or hallucination.
**Fail**: Claims not in source, central thesis invented or speculative, exaggeration beyond evidence.

#### Check 1.2 - Strategic Relevance

**Question**: Has the draft extracted the most powerful insight, or did it settle for a secondary point? Does it reflect the correct editorial mission for this category?

**Pass**: Highest-impact insight identified, editorial mission correctly applied, audience-appropriate framing.
**Fail**: Settled for obvious or secondary insight, misunderstood the editorial mission.

#### Check 1.3 - Hook Clarity

**Question**: Can a reader understand the context from the content alone? Can they infer what triggered this piece without needing the source?

**Pass**: Context inferible, brief contextual mentions provide grounding.
**Fail**: Too vague or abstract, no contextual anchor, over-reliance on source citations.

---

### PHASE 2: Style and Compliance Audit

#### Check 2.1 - Voice Brand Compliance (CRITICAL)

**Question**: Does the draft respect your editorial profile's voice rules? Does it avoid all forbidden patterns?

This check uses your onboarding configuration. Default banned patterns include:
- "It's not X, it's Y" and variants (sounds algorithmic)
- "The real news is..." / "The real innovation is..."
- Any pattern you listed as forbidden

**Pass**: Direct, affirmative statements. Authentic, authoritative voice.
**Fail**: Any forbidden pattern detected. Cliched AI rhetoric.

#### Check 2.2 - Rhythm and Readability

**Question**: Does the text demonstrate syntactic variety? Are paragraphs concise and scannable? Is the voice active and authoritative?

**Pass**: Varied sentence length, mobile-friendly paragraphs, active voice, confident tone.
**Fail**: Monotonous structure, wall-of-text paragraphs, passive voice, tentative tone.

#### Check 2.3 - Structure Validation

**Question**: Does the content follow the required structure from the writer profile?

Verify each structural part:
1. Hook present with required formatting
2. Central section with content appropriate to category
3. Clear and identifiable insight
4. Numbered section (if required) with correct count
5. Powerful close (no questions, no calls-to-action)

**Pass**: All parts clearly identifiable and correctly formatted.
**Fail**: Any part missing, incorrect format, or wrong number of items.

#### Check 2.4 - Technical Constraints

**Question**: Does the draft meet ALL technical constraints from the editorial profile?

**Formatting**: Bold applied to the correct number of key concepts, not full sentences.
**Length**: Within the configured min-max character range.
**Prohibitions**: No explicit source references, no questions to audience, no hashtags (or whatever your profile prohibits).

**Pass**: All constraints met.
**Fail**: Any constraint violated.

---

### PHASE 3: Final Editorial Judgment

#### Check 3.1 - Absolute Value

**Question**: Beyond every rule, is this content genuinely worthy of your target audience's time? Does it offer an original and non-trivial perspective? Does it clearly answer the business question for its category?

**Pass**: Genuine value, original perspective, clearly answers the business question.
**Fail**: Obvious or trivial insight, generic content, does not answer the question.

---

## Decision Logic

### APPROVE

Only when ALL checks across all 3 phases pass. This should be rare -- the QA Director's default is REWRITE.

```json
{
  "decision": "APPROVE",
  "rewrite_reason": "",
  "final_text": "[Original draft text]"
}
```

### REWRITE

When any check fails. The QA Director produces a version that would pass all checks.

**Special Instructions by Failure Type**:

- **Style failures (2.1, 2.2)**: Demonstrate superior stylistic mastery. Use affirmative writing, dynamic rhythm, authentically human voice.
- **Length violations (2.4)**: If too long, cut aggressively while preserving thesis. If too short, expand the numbered section with concrete examples.
- **Structure failures (2.3)**: Ensure each section is clearly identifiable and follows the correct order.

```json
{
  "decision": "REWRITE",
  "rewrite_reason": "Max 2 sentences explaining which checks failed",
  "final_text": "[Improved version]"
}
```

---

## QA Prompt Template

```
# ROLE: Executive Editorial Director for "{content_program_name}"

Your reputation is built on absolute quality standards. Your default is REWRITE.

You have received:
- <SOURCE_MATERIAL>: The source of truth
- <WRITER_PROMPT>: The writer's instructions
- <DRAFT>: The draft to audit

Execute the complete audit checklist. If even ONE check fails, REWRITE.

{full checklist from above, parameterized with editorial profile values}

## OUTPUT
Valid JSON with: "decision", "rewrite_reason", "final_text"
```

---

## Why REWRITE is Default

1. **Quality bar is exceptional, not good**: Your audience's time is precious. Content must be extraordinary.
2. **Iterative improvement**: Writers improve by seeing QA rewrites. Over time, the APPROVE rate should increase.
3. **Reputation protection**: One bad piece damages brand credibility. False negatives (rejecting good content) are better than false positives (publishing bad content).

---

## Customizing QA Strictness

Your editorial profile can adjust QA behavior:

```yaml
qa:
  strictness: "strict"     # 0 failures allowed for APPROVE
  # strictness: "moderate" # 1 failure allowed
  # strictness: "lenient"  # 2 failures allowed
  min_length: 1200
  max_length: 1500
  default_verdict: "REWRITE"
```

---

## Troubleshooting

**QA always rewrites**: This is by design. Check if rewrites are genuinely better than drafts. If so, the system is working correctly.

**QA approves weak content**: Increase strictness or add checks to Phase 3.

**QA rewrites are worse than originals**: Ensure the writer prompt is correctly injected. Add instruction: "Preserve the writer's strategic insight while fixing style/structure issues."
