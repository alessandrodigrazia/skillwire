# Writer Profiles

## Overview

After content classification, the pipeline routes content to a specialized writer profile. Each profile is optimized for a specific content type and answers a distinct question for your target audience.

All writer profiles share common constraints defined in your editorial profile (length, formatting, forbidden patterns, language) but differ in mission, business question, voice, and structure emphasis.

---

## Writer Profile Architecture

Each writer profile contains:

| Component | Description |
|-----------|-------------|
| **ID** | Unique identifier (e.g., "announce-writer") |
| **Mission** | What the output should accomplish (1 sentence) |
| **Business Question** | The audience question this content answers |
| **Voice** | Tone and style characteristics |
| **Structure Template** | How the 5-part structure is adapted |
| **Categories** | Which content categories route to this writer |

---

## Default Writer Profiles

If you do not define custom writers during onboarding, the skill provides these four proven profiles:

### Writer 1: Announcement Writer

**Mission**: Transform product launches, features, partnerships, and market moves into strategic insights.
**Business Question**: "Why does this matter for my business?"
**Voice**: Confident, data-driven. Think analyst report.
**Categories**: ANNOUNCEMENT

**Structure**:
1. **Hook**: Lead with the strategic consequence, not the announcement itself
2. **Setup**: Explain what actually happened (2-3 sentences, specific)
3. **Insight**: Core thesis -- the non-obvious implication (1-2 sentences)
4. **Implications**: 3 actionable consequences for the audience
5. **Close**: Forward-looking statement crystallizing the shift

**Prompt Template**:
```
# ROLE: Strategic News Analyst for "{content_program_name}"

You write {platform} content about product launches, features, partnerships,
and market moves for {target_audience}.

**Inputs:**
- <SOURCE_MATERIAL>: The article/transcript describing the announcement
- <RECENT_POSTS>: Recent posts for voice consistency (review but never reference)

## YOUR MISSION
Transform the announcement into a strategic insight answering:
"Why does this matter for my business?"

Not what was launched, but what changes now.

## STRUCTURE (5 Parts)
{structure template with examples}

## RULES
- Length: {length_min}-{length_max} characters
- Bold: {bold_style} on {bold_count}
- Tone: {voice_description}
- Language: {language}
- Forbidden: {forbidden_patterns}

## OUTPUT
Write the content directly. No preamble, no explanation.
```

---

### Writer 2: Analysis Writer

**Mission**: Distill market analyses, trends, and strategic theses into decision frameworks.
**Business Question**: "How should I think about this differently?"
**Voice**: Analytical, pattern-driven, forward-looking. Think strategy memo.
**Categories**: ANALYSIS

**Structure**:
1. **Hook**: Lead with the pattern or principle being revealed
2. **Context**: Establish what is happening in the market/industry (2-3 sentences with evidence)
3. **Insight**: Core framework or principle -- the reframe (1-2 sentences)
4. **Framework**: 3 actionable principles forming a mental model
5. **Close**: Strategic implication that sticks

---

### Writer 3: Tutorial Writer

**Mission**: Transform tutorials, workflows, and technical capabilities into capability unlocks.
**Business Question**: "What can my team do now that they couldn't before?"
**Voice**: Practical, outcome-focused, specific. Think ROI case study.
**Categories**: TUTORIAL

**Structure**:
1. **Hook**: Lead with the unlocked capability, not the tool
2. **Capability**: Describe what is now possible in concrete terms (2-3 sentences)
3. **Insight**: Why this changes things -- what business model/process it disrupts (1-2 sentences)
4. **Use Cases**: 3 specific applications for the audience
5. **Close**: Competitive implication

---

### Writer 4: Signal Writer

**Mission**: Find the strongest signal in multi-topic content and turn it into strategic insight.
**Business Question**: "What am I missing that I should be watching?"
**Voice**: Incisive, evidence-based, contrarian when warranted. Think market intelligence.
**Categories**: SIGNAL

**Structure**:
1. **Hook**: Lead with the signal, stated as a fact or trend
2. **Evidence**: Present data, examples, or specific proof (2-3 sentences)
3. **Insight**: Interpretation of what the signal means (1-2 sentences)
4. **Implications**: 3 strategic priorities leaders should adjust
5. **Close**: The stakes, crystallized

**Signal Selection Test** (run before writing): "If a decision-maker ignored this signal, what specific risk or opportunity would they miss in the next 6-12 months?" If the answer is vague, find a stronger signal.

---

## Custom Writer Profiles

During onboarding, you can define 2-6 custom writers. For each, provide:

1. **ID**: Short identifier (e.g., "deep-dive-writer")
2. **Mission**: One sentence describing what the output should accomplish
3. **Business Question**: The question your audience needs answered
4. **Voice**: 2-3 adjectives describing the tone
5. **Categories**: Which of your categories route to this writer
6. **Structure**: Either use the default 5-part structure or define custom parts

### Example: Newsletter Curator Writer

```yaml
id: "curator-writer"
mission: "Curate and contextualize a collection of links for busy professionals"
question: "What is worth my attention this week?"
voice: "concise, opinionated, helpful"
categories: ["CURATED"]
structure:
  - hook: "Opening thesis connecting the week's themes (1-2 sentences)"
  - items: "3-5 links with 2-sentence commentary each"
  - close: "Overarching pattern or prediction"
```

---

## Historical Context Integration

All writers can receive recent posts in the same category as context. This serves to:

1. **Maintain voice consistency**: Writers calibrate tone and style against recent output
2. **Avoid repetition**: Prevent reusing phrases, structures, or angles from recent content
3. **Reference quality bar**: See what "good" looks like for this category

**Critical rule**: Writers must NEVER explicitly reference the historical posts in their output. The context is for calibration only.

---

## Common Writing Mistakes to Avoid

### All Writers
- Using "It's not X, it's Y" constructions (sounds algorithmic, default banned)
- Questions to the audience ("What do you think?")
- Citing sources explicitly ("According to the article...")
- Violating character count limits
- Bolding full sentences instead of 2-3 key concepts

### Writer-Specific
- **Announcement**: Just summarizing the news without strategic framing
- **Analysis**: Repeating the author's opinion without extracting a pattern
- **Tutorial**: Explaining step-by-step instead of focusing on business outcome
- **Signal**: Trying to cover multiple themes instead of going deep on one

---

## Comparison Matrix

| Aspect | Announcement | Analysis | Tutorial | Signal |
|--------|-------------|----------|----------|--------|
| **Question** | Why does this matter? | How to think differently? | What can my team do now? | What am I missing? |
| **Hook Focus** | Strategic consequence | Pattern/principle | Unlocked capability | Counterintuitive fact |
| **Part 2** | Setup (what changed) | Context (market trend) | Capability (what is possible) | Evidence (data/proof) |
| **Part 4** | Implications | Framework | Use Cases | Priorities |
| **Voice** | Confident, data-driven | Analytical, pattern-driven | Practical, outcome-focused | Incisive, evidence-based |
| **Think...** | Analyst report | Strategy memo | ROI case study | Market intelligence |
