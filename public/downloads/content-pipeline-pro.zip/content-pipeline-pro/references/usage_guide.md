# Usage Guide

## Overview

This guide covers detailed workflows, examples, and usage patterns for Content Pipeline Pro across all three usage modes.

---

## Three Usage Modes

### Mode 1: Manual Input (Zero Setup)

**Workflow**:
```
You provide content -> Pipeline processes -> Copy output -> Publish manually
```

**Use when**:
- Testing the skill for the first time
- Processing one-off content
- No automation configured

**Example invocations**:
```
"Transform this article into a LinkedIn post: [paste text]"
"Generate content from this article URL: https://example.com/article"
"Process this video transcript for my newsletter: [paste transcript]"
"Create a post from this: [paste any content]"
```

### Mode 2: Semi-Automated

**Workflow**:
```
Automation fetches content -> Sends to pipeline -> You review output -> Publish manually
```

**Use when**:
- Automated content discovery (RSS, email, YouTube)
- Manual review before publishing
- Building confidence in the system

**Setup**: Configure Zapier, Apify, or n8n triggers (see [integrations.md](integrations.md))

### Mode 3: Fully Automated

**Workflow**:
```
Automation fetches -> Pipeline processes -> Automation publishes -> Database logs
```

**Use when**:
- Running production content pipeline
- High content volume
- Full trust in QA validation

**Setup**: End-to-end integrations required (see [integrations.md](integrations.md))

---

## Quick Start: Your First Post

### Step 1: Onboarding (First Time Only)

Say: "I want to set up my content pipeline"

The skill walks you through 7 questions (~5 minutes):
1. Who is your audience?
2. What voice and tone?
3. What platform and format?
4. What content categories?
5. What writer profiles?
6. Do you need personal amplification?
7. Do you want database integration?

### Step 2: Generate Your First Content

Say: "Transform this article into content for my pipeline:"
Then paste the article text.

### Step 3: Review Output

The skill returns:
```
[Content ready for your platform]

Metadata:
- Category: [detected category]
- Character count: [count]
- QA Status: [APPROVED or REWRITE]
- Amplification: [if configured, secondary content]
```

### Step 4: Publish

Copy the output and publish on your platform, or trigger automated publishing.

---

## Common Workflows

### Workflow A: One-Off Article Conversion

1. You provide article (text, URL, or email forward)
2. Pipeline classifies, writes, QA validates, amplifies
3. Returns publish-ready content + metadata
4. You copy/paste to your platform

### Workflow B: Video Content Processing

1. You provide YouTube URL or video transcript
2. If URL provided, the skill uses Apify or similar to extract transcript
3. Pipeline processes the transcript through all steps
4. Returns content optimized for your platform

### Workflow C: RSS Feed Batch Processing

1. Configure RSS feed monitoring (Zapier or Apify)
2. New items collected and sent to pipeline
3. Pipeline processes each item
4. Results delivered for review or auto-published

### Workflow D: Newsletter Compilation

1. Collect 3-5 sources during the week
2. Process each through the pipeline
3. Compile outputs into newsletter format
4. Add personal editorial where needed

---

## Managing Your Editorial Profile

### View Current Profile

Say: "Show my current editorial profile"

### Update Profile

Say: "Update my editorial profile"

You can update individual sections:
- "Change my target audience to marketing managers"
- "Add a new category called OPINION"
- "Update my character limit to 1000-1200"
- "Disable personal amplification"

### Reset Profile

Say: "Reset my editorial profile and start fresh"

---

## Advanced Usage

### Processing Multiple Items

Say: "Process these 3 articles through my pipeline:"
Then provide each article separated by clear markers.

The skill processes each independently through the full pipeline.

### Requesting Specific Categories

Override automatic classification:
"Process this as an ANALYSIS piece: [content]"

### Adjusting QA Strictness

"Process this with lenient QA: [content]"
"Process this with strict QA and show me the audit: [content]"

### Comparing Writer Outputs

"Write this as both an ANNOUNCEMENT and an ANALYSIS: [content]"

The skill produces two versions for comparison.

---

## Performance Notes

**Processing time (manual mode)**:
- Classification: ~3-5 seconds
- Writer + QA: ~15-25 seconds
- Amplification: ~5-10 seconds
- **Total**: ~25-40 seconds per piece

**Token usage (approximate)**:
- Per content piece: ~3,000-5,000 tokens
- With historical context: +2,000 tokens

---

## Tips for Best Results

1. **Provide substantial source material**: At least 300 words of source content produces better output than very short snippets.

2. **Let the classifier work**: The automatic classification is usually correct. Only override when you have a specific reason.

3. **Trust the QA Director**: REWRITE is the default and produces the final output. An REWRITE verdict is not a failure -- it is the system working as designed.

4. **Review the first 5-10 outputs carefully**: This helps you calibrate whether your editorial profile needs adjustment.

5. **Update your profile iteratively**: Start with defaults and refine based on output quality. The profile is designed to evolve.

6. **Use historical context**: If you publish regularly, configure a database. Historical context significantly improves voice consistency.
