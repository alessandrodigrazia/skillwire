# Editorial Guidelines

## Overview

This document consolidates the editorial rules, voice brand elements, and constraints that drive the pipeline. These guidelines are embedded in all writer prompts and enforced by the QA Director.

All rules are configurable through your editorial profile. The defaults below represent a proven configuration refined over 6+ months of production use with C-level audiences.

---

## The 5-Part Structure (Default)

Every piece of content follows a rigid 5-part structure, adapted based on category. This structure is the default and can be customized during onboarding.

### Part 1: Hook (First 1-2 Sentences)

**Function**: Grab attention with a strategic consequence, pattern, or capability -- not just the raw fact.

**Requirements**:
- Bold key concepts using your configured formatting (Unicode bold, markdown, etc.)
- Strategic framing that resonates with your target audience
- Context must be inferible without citing the source

**Good examples**:
```
Bold key concept here. That changes the economics of [relevant domain].
```

**Bad examples**:
```
Yesterday, Company X announced a new feature. This is interesting.
```

### Part 2: Central Section (2-3 Sentences)

**Function**: Establish facts, context, or capability description. The "what" before the "so what."

**Name varies by category**: Setup, Context, Capability, Evidence (configurable)

**Requirements**: Concrete, specific, credible. Named entities, numbers, real examples.

### Part 3: Insight (1-2 Sentences)

**Function**: State the strategic thesis -- the "so what."

**Requirements**: Non-obvious implication, reframe, or strategic shift. Declarative and confident.

**Good**: "This signals a fundamental market segmentation: fast AI for workflows, slow AI for decisions."
**Bad**: "This is an important development that companies should pay attention to."

### Part 4: Numbered Section (Max 3 Items)

**Function**: Actionable consequences, framework elements, or use cases.

**Requirements**:
- Formatted as numbered list (1., 2., 3.)
- Maximum 3 items (not 2, not 4+)
- Each item: 1-2 sentences, concrete and actionable

### Part 5: Close (1 Sentence)

**Function**: Crystallize the shift with a memorable, forward-looking statement.

**Requirements**: Stakes or competitive implication. No questions, no calls-to-action.

**Good**: "The companies that solve their data problems before buying AI tools will own the next decade."
**Bad**: "What do you think about this shift? Share your thoughts below."

---

## Voice Brand Defaults

### 1. Affirmative Writing (Critical Default)

**The #1 default rule**: Ban on "It's not X, it's Y" and all variations.

**Why**: These constructions sound algorithmic, are overused by AI-generated content, and lack authenticity. Negative framing is weaker than affirmative.

**Banned constructions**:
- "It's not X, it's Y"
- "This isn't about X, it's about Y"
- "The real news is..."
- "Don't think of this as X, think of it as Y"

**How to fix**:
- Bad: "It's not about faster models, it's about context retention."
- Good: "The race has shifted to context retention."

You can modify this rule during onboarding if your brand intentionally uses contrastive framing.

### 2. Audience-Appropriate Framing

Every piece answers a business/audience question, not just describes features.

**Characteristics**:
- Strategic implications, not feature descriptions
- Outcomes, not specifications
- Decision-enabling insight, not information for its own sake
- ROI/competitive advantage focus, not novelty focus

### 3. Forward-Looking Stakes

Content ends with stakes or competitive implications, not summaries or engagement bait.

**Pattern**: "Companies/People that [do X] will [outcome Y]"

### 4. Mobile-First Readability

**Rules**:
- Paragraphs: 2-3 sentences max
- Sentence variety: Mix short punchy (5-10 words) with longer complex (20-30 words)
- White space: Use line breaks liberally
- Numbers: Always use numbered lists for 3 items (aids scanning)

---

## Formatting Conventions

### Unicode Bold (Default for LinkedIn)

Apply Unicode bold to 2-3 key concepts (NOT full sentences) that carry strategic weight.

**What to bold**: Strategic capabilities, product names when central, market shifts, quantified impacts.

**What NOT to bold**: Full sentences, generic emphasis words, more than 3 concepts.

**Note**: Unicode bold is different from markdown bold. It uses special Unicode characters that render correctly on platforms like LinkedIn without markdown support.

### Other Formatting Options

During onboarding, you can choose:
- **Unicode bold**: For LinkedIn and platforms without markdown
- **Markdown bold**: For blogs, newsletters, Substack
- **HTML bold**: For email newsletters
- **Plain text**: No formatting

---

## Forbidden Patterns (Defaults)

These are the default forbidden patterns. All can be customized during onboarding.

### 1. Questions to the Audience
Never: "What do you think?", "How is your company handling this?", "Share your thoughts"
Why: Shifts focus from insight to engagement farming. Not aligned with analyst voice.

### 2. Hashtags
Never: Any hashtag.
Why: Most algorithms deprioritize hashtagged posts. Looks promotional, not editorial.

### 3. Explicit Source References
Never: "According to the article from...", "The report states..."
OK: Brief contextual mentions ("Company X launched..." is fine)

### 4. Historical Post References
Never: "As we discussed previously...", "Building on last week's..."
Why: Each piece must stand alone. Historical context is for writer calibration only.

---

## Custom Editorial Rules

Your editorial profile can define any additional rules:

```yaml
voice:
  custom_rules:
    - "Always include at least one named company or product"
    - "Never use the word 'revolutionary'"
    - "Include a specific number or data point in every post"
    - "Mention our product naturally, max once per piece"
```

---

## Technical Constraints Reference

| Constraint | Default | Configurable |
|-----------|---------|-------------|
| Min length | 1200 chars | Yes |
| Max length | 1500 chars | Yes |
| Language | English | Yes |
| Bold style | Unicode | Yes |
| Bold count | 2-3 concepts | Yes |
| Numbered items | Max 3 | Yes |
| Questions | Forbidden | Yes |
| Hashtags | Forbidden | Yes |
| Source citations | Forbidden | Yes |

---

## Quality Checklist

Before submitting any content, validate:

### Structure
- [ ] All required parts clearly identifiable
- [ ] Hook uses configured formatting
- [ ] Numbered section has correct item count
- [ ] Close is a single powerful statement

### Voice
- [ ] No forbidden patterns
- [ ] Answers the business question for this category
- [ ] Forward-looking stakes in close
- [ ] Active voice predominates
- [ ] Concrete examples (names, numbers, specifics)

### Technical
- [ ] Length within configured range
- [ ] Bold applied correctly (count and scope)
- [ ] No prohibited elements
- [ ] Correct language
