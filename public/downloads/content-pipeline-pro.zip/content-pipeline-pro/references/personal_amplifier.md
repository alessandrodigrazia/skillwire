# Personal Amplifier: Secondary Content Generator

## Overview

The **Personal Amplifier** is an optional final agent in the pipeline. After primary content is approved and ready for publication, the amplifier generates secondary content -- typically personal commentary, repost text, or social media shares that accompany the main piece.

This is useful when you publish content on an organization page or newsletter and want to amplify it from a personal account with a distinct voice.

**Key characteristics**:
- **Optional**: Only active if configured during onboarding
- **Persona-driven**: Selects voice based on content category
- **Brief**: Typically much shorter than primary content
- **Complements, does not repeat**: Adds a personal angle, not a summary

---

## When to Use

- Publishing on an organization page and sharing from a personal profile
- Writing a newsletter and adding a personal note
- Cross-posting to social media with platform-specific commentary
- Any scenario where primary + secondary content work together

---

## Persona System

The amplifier does not use a single voice. It selects from personas you define during onboarding, matched to content categories. This ensures the commentary feels authentic and strategically appropriate.

### Default Persona Setup (3 Personas)

| Persona | For Categories | Voice | Goal |
|---------|---------------|-------|------|
| **Analyst** | Announcements, Tutorials | Direct, assertive, innovation-focused | "What is the real innovation here?" |
| **Strategist** | Analysis | Forward-looking, consequence-focused, system-level | "What does this mean for the industry's future?" |
| **Challenger** | Signal/General | Provocative, questioning, constructive | "What is the question nobody is asking?" |

---

## Custom Personas

During onboarding, define your own personas:

```yaml
amplification:
  enabled: true
  max_length: 300  # characters
  language: "en"   # can differ from primary content
  personas:
    - name: "insider"
      for_categories: ["PRODUCT_UPDATE", "CUSTOMER_STORY"]
      voice: "enthusiastic, knowledgeable, behind-the-scenes"
      goal: "Share what excited you personally about this"
    - name: "advisor"
      for_categories: ["INDUSTRY_INSIGHT"]
      voice: "calm, experienced, advisory"
      goal: "Translate the insight into practical guidance"
    - name: "contrarian"
      for_categories: ["TREND_WATCH"]
      voice: "questioning, thoughtful, constructive"
      goal: "Challenge the obvious interpretation"
```

---

## The 3-Phase Mental Process

Before writing commentary, the amplifier follows this process:

### Phase 1: Context
Look at the content category. This determines which persona to use.

### Phase 2: Persona Selection
Apply the category-to-persona mapping. This mapping is strict -- no exceptions.

### Phase 3: Write
Read the finalized primary content. Use its thesis and language as raw material. Write following the chosen persona's voice and goal, within the length limit.

---

## Amplifier Prompt Template

```
# ROLE: Personal Amplifier for "{user_name}"

Act with the personal voice and intellectual authority of the content creator.
Your role is a "Strategic Echo": take a deep analysis and amplify it with an
incisive personal comment.

You have received:
1. <FINAL_CONTENT>: The finalized primary content
2. <CATEGORY>: The content category

## YOUR PROCESS

### 1. Consider the Category
The category determines your persona selection.

### 2. Select Your Persona
{for each persona in profile.amplification.personas}
- If category is {persona.for_categories}: adopt the **{persona.name}** persona.
  Voice: {persona.voice}. Goal: {persona.goal}.
{end for}

### 3. Write the Commentary
Read the final content carefully. Use its thesis as raw material.
Write following your selected persona's voice and goal.

## RULES
- Maximum {max_length} characters
- Tone: editorial, personal, authoritative
- Language: {amplification_language}
- DO NOT reference the source article
- DO NOT include calls-to-action
- DO NOT use hashtags or mentions
- The commentary must stand alone alongside the primary content

## OUTPUT
Return ONLY the commentary text. No preamble.
```

---

## Quality Criteria

**Good commentary**:
- Adds new perspective (does not repeat primary content)
- Feels personal and authoritative
- Matches the persona's voice
- Within length limit
- Stands alone (no context needed beyond seeing the primary content)

**Exceptional commentary**:
- Makes you rethink the primary content's thesis
- Provocative but constructive
- Quotable (people want to remember it)
- Amplifies without redundancy

**Poor commentary**:
- Summarizes the primary content
- Generic (could apply to any piece)
- Too promotional
- Wrong persona for content category
- Over length limit

---

## Example Outputs

### Announcement + Analyst Persona

**Primary content**: A post about a major AI company launching a reasoning model.

**Commentary**: "The real unlock is not the model itself -- it is persistent memory across sessions. That changes the economics of software development from consulting to continuous collaboration."

**Character count**: 198/300

### Analysis + Strategist Persona

**Primary content**: A post analyzing the convergence of multiple AI companies toward reasoning models.

**Commentary**: "The AI market is permanently segmenting: fast models for workflows, slow models for decisions. Companies building for both will dominate enterprise in the next 36 months."

**Character count**: 195/300

### Signal + Challenger Persona

**Primary content**: A post about 80% of enterprise AI projects failing to reach production.

**Commentary**: "The real question: how many CEOs know that AI readiness is a data problem, not a technology problem? Those who figure it out now gain a 12-month competitive advantage."

**Character count**: 197/300

---

## Disabling the Amplifier

If you do not need secondary content, set during onboarding:

```yaml
amplification:
  enabled: false
```

The pipeline will skip Step 6 and go directly to publish-ready output.
