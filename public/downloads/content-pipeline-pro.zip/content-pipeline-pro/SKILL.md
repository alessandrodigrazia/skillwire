---
name: content-pipeline-pro
description: |
  Professional 7-step content pipeline that transforms raw sources (articles, videos, RSS feeds) into
  publish-ready content for any platform. Configurable writer profiles, editorial voice, QA framework,
  and personal amplification layer. Works for newsletters, LinkedIn, blogs, or any content program.
  Starts with a guided onboarding to adapt the pipeline to your brand, audience, and editorial standards.
  After installation, the skill will guide you through a 5-minute initial setup to adapt it to your
  brand and audience.
---

# Content Pipeline Pro

## Overview

Content Pipeline Pro is a professional-grade content transformation system. It takes raw material from any source — articles, videos, transcripts, RSS feeds, or manual input — and produces publish-ready content through a rigorous 7-step pipeline.

The pipeline replicates and automates an editorial workflow refined over 6+ months of production use:

- **Configurable editorial voice** adapted to your brand through guided onboarding
- **Specialized writer profiles** you define (2-6 profiles, each answering a different audience question)
- **3-phase quality assurance** with REWRITE-by-default philosophy
- **Personal amplification layer** for secondary content (reposts, commentary, social shares)
- **Optional database integration** for historical context and analytics (Airtable, Notion, or none)

The system works standalone (manual mode) or integrates with automation platforms (Zapier, Apify, n8n) for end-to-end content operations.

---

## Onboarding: First-Time Setup

When you first invoke this skill, it runs a guided onboarding to build your **Editorial Profile**. This profile drives every step of the pipeline. The onboarding asks:

### 1. Audience Definition
- **Who are you writing for?** (e.g., C-level executives, developers, marketers, general audience)
- **What industry/niche?** (e.g., AI/tech, healthcare, finance, SaaS, general business)
- **What level of technical depth?** (executive summary, practitioner, deep technical)

### 2. Voice and Tone
- **Brand voice** (e.g., authoritative analyst, friendly educator, provocative challenger, neutral reporter)
- **Writing style** (e.g., affirmative/declarative, conversational, academic, data-driven)
- **Forbidden patterns** (e.g., questions to audience, hashtags, clickbait, specific phrases to avoid)

### 3. Content Formats
- **Primary platform** (LinkedIn, blog, newsletter, Twitter/X, Substack, Medium, custom)
- **Content length** (e.g., 1200-1500 characters for LinkedIn, 500-800 words for blog, custom range)
- **Output language** (English, Italian, Spanish, French, German, or any other)
- **Formatting conventions** (Unicode bold, markdown, HTML, plain text)

### 4. Content Categories
- **How many categories?** (2-6 recommended)
- **Category names and definitions** (e.g., "Announcement", "Analysis", "Tutorial", "Signal")
- **Business question each answers** (e.g., "Why does this matter?", "How should I think differently?")

### 5. Writer Profiles
- **How many writer profiles?** (match your categories, or fewer if some share a voice)
- **For each profile**: name, mission, voice characteristics, structure template
- **Default structure**: 5-part (Hook, Context, Insight, Numbered Items, Close) or custom

### 6. Personal Amplification (Optional)
- **Do you produce secondary content?** (e.g., personal commentary when sharing org posts)
- **If yes**: how many personas? What voice for each? What length?
- **Language for amplification** (can differ from main content)

### 7. Database Integration (Optional)
- **Do you want historical context?** (retrieves recent posts for voice consistency)
- **Platform**: Airtable, Notion, or none
- **If yes**: base/database ID, table name, API credentials

The onboarding produces a structured **Editorial Profile** saved as a JSON/YAML configuration. All subsequent pipeline runs use this profile. You can update it anytime by saying "Update my editorial profile."

---

## The 7-Step Content Transformation Pipeline

Every piece of content flows through this sequential process:

### Step 1: Content Ingestion

Extract clean text from the source:
- **Article**: URL, email body, or pasted text
- **Video**: YouTube URL (auto-captions or AI transcription)
- **RSS Feed**: Feed URL or individual item
- **Manual**: Any text provided directly

Optional automation: Zapier triggers, Apify Actors, n8n webhooks for automated discovery.

### Step 2: Content Classification

**Agent**: Chief Editor (Classifier)

Analyzes incoming content and assigns it to ONE of your defined categories. The classifier uses your category definitions from onboarding to make consistent routing decisions.

Classification output: a single category label that determines which writer profile handles the content.

**Details**: See [references/classification_guide.md](references/classification_guide.md)

### Step 3: Historical Context Retrieval (Optional)

If database integration is configured, query for the last N posts in the same category. This context is injected into the writer prompt to maintain voice consistency and avoid repetitive patterns.

**Fallback**: If no database is configured, writers use the base editorial profile without historical context.

### Step 4: Specialized Writer

Based on classification, the content routes to the matching writer profile. Each profile has:
- A **mission statement** defining what the output should accomplish
- A **business question** it answers for the audience
- A **structure template** (default: 5-part structure, customizable)
- **Voice characteristics** calibrated to your brand

The writer produces a draft following your editorial profile constraints (length, formatting, forbidden patterns, language).

**Details**: See [references/writer_profiles.md](references/writer_profiles.md)

### Step 5: Quality Assurance

**Agent**: QA Director

A rigorous 3-phase audit with **REWRITE as default** (only approves exceptional content):

**Phase 1: Strategic and Content Audit**
- Source fidelity (no hallucination, claims grounded in source)
- Strategic relevance (strongest insight surfaced, not a secondary point)
- Hook clarity (context inferible without citing source)

**Phase 2: Style and Compliance Audit**
- Voice brand compliance (forbidden patterns, affirmative writing)
- Rhythm and readability (sentence variety, mobile-friendly paragraphs)
- Structure validation (all required parts present and correctly formatted)
- Technical constraints (length, formatting, prohibited elements)

**Phase 3: Final Editorial Judgment**
- Absolute value: is this genuinely worth the target audience's time?
- Does it answer the business question for its category?

Output: APPROVE or REWRITE decision + final text.

**Details**: See [references/qa_framework.md](references/qa_framework.md)

### Step 6: Personal Amplification (Optional)

If configured during onboarding, generates secondary content (e.g., personal commentary for sharing organizational posts). Uses persona selection based on content category.

**Details**: See [references/personal_amplifier.md](references/personal_amplifier.md)

### Step 7: Publish-Ready Output

The final output includes:
- **Main content**: Post/article text ready for your platform
- **Amplification content** (if configured): Personal commentary or repost text
- **Metadata**: Category, character count, QA status, suggested posting time

Publishing options:
- **Manual**: Copy/paste the output
- **Automated**: Trigger via Zapier, n8n, or custom webhook to publish directly

---

## Pipeline Flow Diagram

```
+---------------------+
|  Raw Content Input  |
+---------+-----------+
          |
          v
   +---------------+
   | Chief Editor  |
   | (Classifier)  |
   +-------+-------+
           |
     +-----+------+------+------+
     |     |      |      |      |
   Cat.1  Cat.2  Cat.3  Cat.4  ...
     |     |      |      |      |
     v     v      v      v      v
  +--------+------+------+------+---+
  |    Specialized Writer Profile    |
  +----------------+-----------------+
                   |
                   v
            +------+------+
            | QA Director |
            |  (3-phase)  |
            +------+------+
                   |
            +------+------+
            |             |
         APPROVE       REWRITE
            |             |
            +------+------+
                   |
                   v
        +----------+----------+
        | Personal Amplifier  |
        |    (optional)       |
        +----------+----------+
                   |
                   v
        +----------+----------+
        | Publish-Ready Output|
        +---------------------+
```

---

## Editorial Guidelines

The skill enforces your editorial standards as defined during onboarding. The default framework includes proven patterns you can adopt or customize:

### Default 5-Part Structure

1. **Hook** (1-2 sentences): Lead with consequence or insight, not just facts. Bold key concepts.
2. **Context/Setup** (2-3 sentences): Establish the "what" before the "so what." Concrete and specific.
3. **Insight** (1-2 sentences): The strategic "so what" -- non-obvious implication or reframe.
4. **Numbered Items** (max 3): Actionable consequences, framework, or use cases.
5. **Close** (1 sentence): Forward-looking stakes. No questions or calls-to-action.

### Default Voice Rules

- **Affirmative writing**: Say what it IS, not what it ISN'T. Avoid "It's not X, it's Y" constructions.
- **Active voice**: Prefer active over passive.
- **Concrete over abstract**: Use specific names, numbers, and examples.
- **Audience-appropriate framing**: Answer the business question, not just describe features.
- **Mobile-first readability**: Short paragraphs, varied sentence length, scannable layout.

All rules are customizable through your editorial profile.

**Details**: See [references/editorial_guidelines.md](references/editorial_guidelines.md)

---

## When to Use This Skill

Use content-pipeline-pro when you need to:

- **Transform raw content** (articles, videos, transcripts) into polished, publish-ready output
- **Maintain editorial consistency** across multiple content pieces or creators
- **Apply strategic framing** to technical or news content for a specific audience
- **Automate content pipelines** from ingestion to publication
- **Generate amplification content** (commentary, reposts) alongside primary content

**Works for**:
- LinkedIn thought leadership programs
- Company newsletters and blogs
- Executive communication and social media
- Content teams managing brand voice at scale
- Any recurring content operation with consistent editorial standards

---

## Usage Modes

### Mode 1: Manual (Zero Setup)

Paste content, get publish-ready output. Uses default editorial profile or your configured one.

```
"Transform this article into a LinkedIn post: [paste text]"
```

### Mode 2: Semi-Automated

Automated content discovery (RSS, email triggers) with manual review before publishing.

### Mode 3: Fully Automated

End-to-end pipeline from content discovery to publication and logging.

**Details**: See [references/usage_guide.md](references/usage_guide.md)

---

## Reference Materials

The `references/` directory contains detailed documentation loaded as-needed:

### Core Pipeline
- **[classification_guide.md](references/classification_guide.md)** - Content classifier agent prompt and category system
- **[writer_profiles.md](references/writer_profiles.md)** - Writer profile architecture and prompt templates
- **[qa_framework.md](references/qa_framework.md)** - 3-phase QA audit checklist and decision logic
- **[personal_amplifier.md](references/personal_amplifier.md)** - Personal amplification layer with persona selection
- **[editorial_guidelines.md](references/editorial_guidelines.md)** - Voice brand rules, structure templates, formatting conventions

### Usage and Integration
- **[content_examples.md](references/content_examples.md)** - Example outputs by category with annotations
- **[integrations.md](references/integrations.md)** - Zapier, Apify, n8n, and database integration guides
- **[usage_guide.md](references/usage_guide.md)** - Detailed workflows for all 3 usage modes
- **[troubleshooting.md](references/troubleshooting.md)** - Common issues and solutions

---

## Configuration Reference

### Editorial Profile Structure

```yaml
profile:
  name: "My Content Program"
  version: 1.0

audience:
  target: "C-level executives, innovation leaders"
  industry: "AI/Technology"
  depth: "executive-summary"

voice:
  brand: "authoritative-analyst"
  style: "affirmative, data-driven, forward-looking"
  forbidden_patterns:
    - "It's not X, it's Y"
    - questions to audience
    - hashtags
    - explicit source references

format:
  platform: "linkedin"
  length_min: 1200
  length_max: 1500
  language: "en"
  bold_style: "unicode"
  bold_count: "2-3 key concepts"

categories:
  - name: "ANNOUNCEMENT"
    question: "Why does this matter for my business?"
    writer: "announce-writer"
  - name: "ANALYSIS"
    question: "How should I think about this differently?"
    writer: "analysis-writer"
  - name: "TUTORIAL"
    question: "What can my team do now that they couldn't before?"
    writer: "tutorial-writer"
  - name: "SIGNAL"
    question: "What am I missing that I should be watching?"
    writer: "signal-writer"

writers:
  - id: "announce-writer"
    mission: "Transform announcements into strategic insights"
    voice: "confident, data-driven"
    structure: "hook, setup, insight, implications(3), close"
  - id: "analysis-writer"
    mission: "Distill analyses into decision frameworks"
    voice: "analytical, pattern-driven"
    structure: "hook, context, insight, framework(3), close"
  # ... additional writers

amplification:
  enabled: true
  personas:
    - name: "analyst"
      for_categories: ["ANNOUNCEMENT", "TUTORIAL"]
      voice: "direct, innovation-focused"
      goal: "Identify the real innovation"
    - name: "strategist"
      for_categories: ["ANALYSIS"]
      voice: "forward-looking, consequence-focused"
      goal: "Extract industry-level implications"
    - name: "challenger"
      for_categories: ["SIGNAL"]
      voice: "provocative, constructive"
      goal: "Pose the uncomfortable question"
  max_length: 300
  language: "en"

database:
  enabled: false
  platform: "airtable"  # or "notion" or "none"
  # credentials configured separately
```

---

## Quick Start

### First Run (Onboarding)

```
"I want to set up my content pipeline"
```

The skill will walk you through 7 questions to build your editorial profile. Takes approximately 5 minutes.

### After Onboarding

```
"Transform this article into content for my pipeline: [paste or URL]"
"Process this video transcript: [paste]"
"Generate content from this RSS item: [paste summary]"
"Update my editorial profile"
"Show my current editorial profile"
```

---

## License

Licensed under the Skillwire Commercial License. See [LICENSE.txt](LICENSE.txt) for details.

---

**Version**: 1.0
**Last Updated**: 2026-02
