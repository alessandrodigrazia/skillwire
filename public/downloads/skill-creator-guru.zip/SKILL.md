---
name: skill-creator-guru
description: Use when creating a new skill from scratch, improving existing skills, running evals to test skill performance, benchmarking with A/B comparison, optimizing trigger descriptions, or packaging skills for distribution.
license: Complete terms in LICENSE.txt
---

# Skill Creator Guru

Create skills, test them with evals, measure performance with benchmarks, and optimize trigger descriptions. This skill combines authoring best practices with a rigorous eval/iterate loop.

## High-Level Process

1. **Create or edit** the skill (capture intent → interview → write SKILL.md)
2. **Run test cases** with subagents (with-skill vs without-skill)
3. **Evaluate results** qualitatively (viewer) and quantitatively (assertions)
4. **Iterate** based on feedback until satisfied
5. **Optimize description** for reliable triggering
6. **Package** the final skill

Figure out where the user is in this process and help them progress. Be flexible — if they say "just vibe with me", skip the formal eval loop.

---

## Creating a Skill

### Capture Intent

Understand what the user wants. If the conversation already contains a workflow to capture, extract answers from history first.

1. What should this skill enable Claude to do?
2. When should this skill trigger? (phrases/contexts)
3. What's the expected output format?
4. Should we set up test cases? (Yes for objectively verifiable outputs; optional for subjective ones like writing style)

### Interview and Research

Ask about edge cases, input/output formats, example files, success criteria, dependencies. Check available MCPs for research. Wait to write test prompts until this is ironed out.

### Write the SKILL.md

Key components:

- **name**: Skill identifier (kebab-case, max 64 chars)
- **description**: When to trigger. This is the PRIMARY triggering mechanism. See CSO Pattern below.
- **Body**: Procedural instructions, references to scripts/references/assets

#### Claude Search Optimization (CSO) for Descriptions

The `description` field determines when Claude activates the skill. In the skill list, descriptions are **truncated to ~50-60 characters** — the first words are decisive.

**The Rule:** Descriptions must contain ONLY triggering conditions. Start with "Use when..." and describe WHEN to use the skill, never WHAT it does internally.

**Format:** Always single-line. Never use YAML `>` or `|` block scalars.

**Good:** `Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes`
**Bad:** `Comprehensive PDF processor that extracts text, merges documents, fills form fields`

**Why:** Claude tends to follow the description instead of reading the full skill if it summarizes the workflow. Trigger-only descriptions force Claude to load the full SKILL.md.

Also make descriptions slightly "pushy" — Claude tends to undertrigger. Example: instead of "How to build a dashboard", write "How to build a dashboard. Use this skill whenever the user mentions dashboards, data visualization, or wants to display any kind of data."

#### Skill Structure

```
skill-name/
├── SKILL.md (required, <5k words)
│   ├── YAML frontmatter (name, description required)
│   └── Markdown instructions
└── Bundled Resources (optional)
    ├── scripts/    - Executable code (token-free, deterministic)
    ├── references/ - Docs loaded into context as needed
    └── assets/     - Files used in output (templates, icons, fonts)
```

**Progressive disclosure:** Metadata always in context (~100 tokens) → SKILL.md when triggered (<5k words) → References as needed → Scripts execute without loading.

For detailed guidance on skill patterns, best practices, anti-patterns, and writing effective scripts, read `references/best_practices_detailed.md` and `references/skill_patterns.md`.

### Initialize a New Skill

For new skills from scratch, use the init script:

```bash
scripts/init_skill.py <skill-name> --path <output-directory>
```

### Complex Skills: Write a PRD First

For skills with 3+ reference files, multiple workflows, or expected >2000 words: write a PRD first. Save as `docs/PRD.md` in the skill directory. See `references/best_practices_detailed.md` for the PRD template.

---

## Running and Evaluating Test Cases

This section is one continuous sequence — don't stop partway through. Put results in `<skill-name>-workspace/` as a sibling to the skill directory. Organize by iteration (`iteration-1/`, `iteration-2/`, etc.) and within that, each test case gets a directory (`eval-0/`, `eval-1/`, etc.).

### Step 1: Spawn all runs (with-skill AND baseline) in the same turn

For each test case, spawn **two subagents in the same turn** — one with the skill, one without. Launch everything at once.

**With-skill run:**
```
Execute this task:
- Skill path: <path-to-skill>
- Task: <eval prompt>
- Input files: <eval files if any, or "none">
- Save outputs to: <workspace>/iteration-<N>/eval-<ID>/with_skill/outputs/
```

**Baseline run** (same prompt, no skill or old version):
- **New skill**: no skill at all → save to `without_skill/outputs/`
- **Improving existing**: snapshot old version first (`cp -r`), point baseline at snapshot → save to `old_skill/outputs/`

Write `eval_metadata.json` for each test case with descriptive names. See `references/schemas.md` for the exact schema.

### Step 2: While runs are in progress, draft assertions

Don't wait — use this time to draft quantitative assertions for each test case. Good assertions are objectively verifiable and have descriptive names. Subjective skills (writing style, design) are better evaluated qualitatively.

Update `eval_metadata.json` and `evals/evals.json` with assertions. See `references/schemas.md` for the assertions schema.

### Step 3: As runs complete, capture timing data

When each subagent completes, save `total_tokens` and `duration_ms` to `timing.json` in the run directory. This data comes through the task notification and isn't persisted elsewhere — capture immediately.

### Step 4: Grade, aggregate, and launch the viewer

Once all runs are done:

1. **Grade each run** — spawn a grader subagent that reads `agents/grader.md` and evaluates assertions against outputs. Save to `grading.json`. For programmatically checkable assertions, write and run a script.

2. **Aggregate into benchmark**:
   ```bash
   python -m scripts.aggregate_benchmark <workspace>/iteration-N --skill-name <name>
   ```
   Produces `benchmark.json` and `benchmark.md` with pass_rate, time, tokens (mean +/- stddev and delta).

3. **Analyst pass** — read `agents/analyzer.md` and surface patterns: non-discriminating assertions, high-variance evals, time/token tradeoffs.

4. **Launch the viewer**:
   ```bash
   nohup python <skill-creator-guru-path>/eval-viewer/generate_review.py \
     <workspace>/iteration-N \
     --skill-name "my-skill" \
     --benchmark <workspace>/iteration-N/benchmark.json \
     > /dev/null 2>&1 &
   ```
   For iteration 2+, add `--previous-workspace <workspace>/iteration-<N-1>`.
   For headless/Cowork: use `--static <output_path>` for standalone HTML.

Always use `generate_review.py` — don't write custom HTML.

### Step 5: Read the feedback

When the user says they're done reviewing, read `feedback.json`. Empty feedback = looks good. Focus improvements on test cases with specific complaints. Kill the viewer server when done.

---

## Improving the Skill

### How to think about improvements

1. **Generalize from feedback.** Don't overfit to test examples — the skill will be used across many different prompts. Avoid fiddly, overfitty changes or oppressive MUSTs.

2. **Keep the prompt lean.** Remove things that aren't pulling weight. Read the transcripts — if the skill wastes time on unproductive steps, trim those instructions.

3. **Explain the why.** Today's LLMs are smart. Explain reasoning instead of rigid rules. If you're writing ALWAYS/NEVER in all caps, reframe with explanation.

4. **Look for repeated work across test cases.** If all subagents independently wrote the same helper script, bundle it in `scripts/`.

### The iteration loop

1. Apply improvements to the skill
2. Rerun all test cases into `iteration-<N+1>/`, including baselines
3. Launch the reviewer with `--previous-workspace`
4. Wait for user review
5. Read feedback, improve again, repeat

Keep going until: user is happy, feedback is all empty, or no meaningful progress.

---

## Advanced: Blind Comparison

For rigorous comparison between two skill versions, use the blind comparison system. Read `agents/comparator.md` and `agents/analyzer.md`. The basic idea: give two outputs to an independent agent without revealing which is which, let it judge quality, then analyze why the winner won.

Optional — the human review loop is usually sufficient.

---

## Description Optimization

After creating or improving a skill, optimize the description for better triggering.

### Step 1: Generate trigger eval queries

Create 20 eval queries — mix of should-trigger (8-10) and should-not-trigger (8-10). Save as JSON:

```json
[
  {"query": "the user prompt", "should_trigger": true},
  {"query": "another prompt", "should_trigger": false}
]
```

Queries must be **realistic and detailed** — file paths, personal context, column names, URLs, casual speech, typos, abbreviations. Avoid trivially obvious cases. For should-not-trigger, focus on near-misses that share keywords but need something different.

### Step 2: Review with user

Use the HTML template from `assets/eval_review.html`:
1. Replace `__EVAL_DATA_PLACEHOLDER__`, `__SKILL_NAME_PLACEHOLDER__`, `__SKILL_DESCRIPTION_PLACEHOLDER__`
2. Write to temp file, open it
3. User edits queries, exports to `eval_set.json`

### Step 3: Run the optimization loop

```bash
python -m scripts.run_loop \
  --eval-set <path-to-trigger-eval.json> \
  --skill-path <path-to-skill> \
  --model <model-id-powering-this-session> \
  --max-iterations 5 \
  --verbose
```

This splits eval set 60% train / 40% test, evaluates current description (3 runs per query), uses extended thinking to propose improvements, iterates up to 5 times, selects by test score (anti-overfitting).

### Step 4: Apply the result

Take `best_description` from JSON output, update SKILL.md frontmatter. Show before/after and scores.

---

## Platform-Specific Instructions

### Claude.ai

No subagents → run test cases sequentially yourself. Skip baselines and quantitative benchmarking. Present results directly in conversation. Skip description optimization (requires `claude -p`).

### Cowork

Subagents available. Use `--static <output_path>` for viewer (no browser). Feedback downloads as `feedback.json`. IMPORTANT: GENERATE THE EVAL VIEWER BEFORE evaluating outputs yourself — get results in front of the human ASAP.

### Package and Present

```bash
python -m scripts.package_skill <path/to/skill-folder>
```

Creates a `.skill` file. If `present_files` tool is available, present it to the user.

---

## Reference Files

### Agents (for specialized subagents)
- `agents/grader.md` — Evaluate assertions against outputs
- `agents/comparator.md` — Blind A/B comparison between outputs
- `agents/analyzer.md` — Analyze why one version beat another

### References
- `references/schemas.md` — JSON structures for evals.json, grading.json, benchmark.json
- `references/best_practices_detailed.md` — CSO deep dive, PRD template, token budget, versioning, security
- `references/skill_patterns.md` — 4 structural patterns with detailed examples
- `references/testing_guide.md` — Pre/post-upload testing, creating scenarios, troubleshooting

### Scripts
- `scripts/init_skill.py` — Generate new skill template
- `scripts/quick_validate.py` — Validate skill structure and quality
- `scripts/package_skill.py` — Package into .skill file
- `scripts/run_eval.py` — Run single eval iteration
- `scripts/run_loop.py` — Full description optimization loop
- `scripts/aggregate_benchmark.py` — Aggregate benchmark results
- `scripts/improve_description.py` — Single description improvement iteration
- `scripts/generate_report.py` — Generate eval report

### Eval Viewer
- `eval-viewer/generate_review.py` — Generate interactive HTML viewer
- `eval-viewer/viewer.html` — Viewer template
- `assets/eval_review.html` — Trigger eval review template

---

## Quality Checklist

Before considering a skill complete:

- [ ] Description is trigger-oriented (CSO pattern), single-line, <1024 chars
- [ ] SKILL.md body is under 5k words
- [ ] No TODO markers remaining
- [ ] Referenced files (scripts/, references/, assets/) actually exist
- [ ] At least one test iteration completed with real usage
- [ ] Tested with realistic, not trivial, scenarios
- [ ] No time-sensitive information
- [ ] Cross-platform paths (forward slashes)

For the full quality framework (Four Pillars: Effectiveness, Efficiency, Robustness, Safety), see `references/best_practices_detailed.md`.
