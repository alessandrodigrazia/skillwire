---
name: skill-creator-guru
description: Comprehensive guide for creating effective skills. This skill should be used when users want to create a new skill from scratch, improve an existing skill, package a skill for distribution, or learn best practices for skill authoring. Use this skill when users ask about skill structure, bundled resources (scripts/references/assets), skill validation, or need guidance on when to use different skill patterns.
license: Complete terms in LICENSE.txt
---

# Skill Creator

This skill provides guidance for creating effective skills.

## About Skills

Skills are modular, self-contained packages that extend Claude's capabilities by providing
specialized knowledge, workflows, and tools. Think of them as "onboarding guides" for specific
domains or tasks—they transform Claude from a general-purpose agent into a specialized agent
equipped with procedural knowledge that no model can fully possess.

### What Skills Provide

1. Specialized workflows - Multi-step procedures for specific domains
2. Tool integrations - Instructions for working with specific file formats or APIs
3. Domain expertise - Company-specific knowledge, schemas, business logic
4. Bundled resources - Scripts, references, and assets for complex and repetitive tasks

### Anatomy of a Skill

Every skill consists of a required SKILL.md file and optional bundled resources:

```
skill-name/
├── SKILL.md (required)
│   ├── YAML frontmatter metadata (required)
│   │   ├── name: (required)
│   │   └── description: (required)
│   └── Markdown instructions (required)
└── Bundled Resources (optional)
    ├── scripts/          - Executable code (Python/Bash/etc.)
    ├── references/       - Documentation intended to be loaded into context as needed
    └── assets/           - Files used in output (templates, icons, fonts, etc.)
```

#### SKILL.md (required)

**Metadata Quality:** The `name` and `description` in YAML frontmatter determine when Claude will use the skill. Be specific about what the skill does and when to use it. Use the third-person (e.g. "This skill should be used when..." instead of "Use this skill when...").

#### Bundled Resources (optional)

##### Scripts (`scripts/`)

Executable code (Python/Bash/etc.) for tasks that require deterministic reliability or are repeatedly rewritten.

- **When to include**: When the same code is being rewritten repeatedly or deterministic reliability is needed
- **Example**: `scripts/rotate_pdf.py` for PDF rotation tasks
- **Benefits**: Token efficient, deterministic, may be executed without loading into context
- **Note**: Scripts may still need to be read by Claude for patching or environment-specific adjustments

##### References (`references/`)

Documentation and reference material intended to be loaded as needed into context to inform Claude's process and thinking.

- **When to include**: For documentation that Claude should reference while working
- **Examples**: `references/finance.md` for financial schemas, `references/mnda.md` for company NDA template, `references/policies.md` for company policies, `references/api_docs.md` for API specifications
- **Use cases**: Database schemas, API documentation, domain knowledge, company policies, detailed workflow guides
- **Benefits**: Keeps SKILL.md lean, loaded only when Claude determines it's needed
- **Best practice**: If files are large (>10k words), include grep search patterns in SKILL.md
- **Avoid duplication**: Information should live in either SKILL.md or references files, not both. Prefer references files for detailed information unless it's truly core to the skill—this keeps SKILL.md lean while making information discoverable without hogging the context window. Keep only essential procedural instructions and workflow guidance in SKILL.md; move detailed reference material, schemas, and examples to references files.

##### Assets (`assets/`)

Files not intended to be loaded into context, but rather used within the output Claude produces.

- **When to include**: When the skill needs files that will be used in the final output
- **Examples**: `assets/logo.png` for brand assets, `assets/slides.pptx` for PowerPoint templates, `assets/frontend-template/` for HTML/React boilerplate, `assets/font.ttf` for typography
- **Use cases**: Templates, images, icons, boilerplate code, fonts, sample documents that get copied or modified
- **Benefits**: Separates output resources from documentation, enables Claude to use files without loading them into context

### Progressive Disclosure Design Principle

Skills use a three-level loading system to manage context efficiently:

1. **Metadata (name + description)** - Always in context (~100 words)
2. **SKILL.md body** - When skill triggers (<5k words)
3. **Bundled resources** - As needed by Claude (Unlimited*)

*Unlimited because scripts can be executed without reading into context window.

## Best Practices for Skill Creation

Follow these best practices to create effective, maintainable skills:

### Write Clear, Specific Descriptions

The `description` field in YAML frontmatter determines when Claude uses the skill. Be specific about what the skill does and when to use it.

**Good examples:**
- "Processes PDF files: extracts text, merges documents, fills form fields, and converts to images"
- "Analyzes Excel data: creates pivot tables, generates charts, performs statistical analysis"
- "Git commit helper: generates conventional commit messages following the team's style guide"

**Avoid:**
- "Helps with documents" (too vague)
- "PDF Processing Tool" (not a description, just a title)
- "Use this when..." (use third-person: "This skill should be used when...")

### Start Simple, Iterate Based on Real Usage

Create evaluations BEFORE writing comprehensive documentation:

1. Identify 3-5 concrete use cases
2. Test with minimal instructions first
3. Observe where Claude struggles
4. Add only the guidance needed to address those struggles
5. Iterate based on real usage patterns

This approach prevents over-engineering and keeps skills focused.

### Use Concrete Examples

Skills benefit enormously from concrete examples showing input and expected output:

**Template pattern example:**
```
## Export Structure
###### Export structure

export use this event template structure:
- Markdown: [Task Title]
- Location: [Event Type]
...
```

**Examples pattern:** Show what good looks like with realistic scenarios.

### Test Incrementally During Development

- **Before uploading**: Review skill description accuracy, verify referenced files exist, check all TODOs completed
- **After uploading**: Try several different prompts, review Claude's thinking process, iterate on clarity
- **Get feedback**: Have others test the skill and report struggles

### Version Your Skills

- Track major changes with version numbers in comments or changelog
- Create evaluations that test core functionality
- Measure Claude's performance before and after changes
- Don't break existing workflows when iterating

### Keep SKILL.md Concise

- SKILL.md should be under 5k words for optimal performance
- Move detailed information to `references/` files
- Include only essential procedural instructions in SKILL.md
- Use grep patterns to help Claude find information in large reference files

## Anti-Patterns to Avoid

Avoid these common mistakes when creating skills:

### Avoid Windows-Style Paths in Cross-Platform Skills

**Bad example:**
```
C:\Code\scripts\helper.py
F:\Work\scripts\helper.py
```

**Good example:** Use forward slashes that work on all platforms:
```
/Code/scripts/helper.py
~/work/scripts/helper.py
```

### Don't Offer Too Many Options

**Bad example:** Providing 10 different ways to accomplish the same task overwhelms Claude and users.

**Good example:** Provide 2-3 clear options when choice is necessary, with guidance on when to use each.

### Avoid Deeply Nested References

Keep reference structure flat or 2 levels deep maximum. Deeply nested files are harder to navigate.

**Bad example:**
```
references/api/v2/endpoints/users/authentication/oauth/...
```

**Good example:**
```
references/api_endpoints.md
references/authentication.md
```

### Don't Make SKILL.md Too Long

If SKILL.md exceeds 5k words, move content to reference files. Long skills hog context window.

### Avoid Time-Sensitive Information

**Bad example:** "In 2024, the API uses version 2.1..."

**Good example:** "The API uses version 2.1 (check current version at...)"

### Don't Duplicate Content

Information should live in either SKILL.md or references files, not both. Duplication creates maintenance burden and inconsistencies.

### Avoid Vague Trigger Descriptions

**Bad example:** "Helper for data" or "Utility tool"

**Good example:** "Parse CSV files, perform data validation, and generate summary statistics"

## Content Guidelines

Follow these guidelines to ensure skill content is clear and effective:

### Avoid Time-Sensitive Information

Don't include information that will become outdated:
- Specific dates or years: "In 2024..."
- Trending topics or current events
- "Latest" or "newest" without context

Instead, provide timeless guidance or point to authoritative sources.

### Use Consistent Terminology

Choose one term and stick with it throughout the skill:

**Good - Consistent:**
- Always "API endpoint" (not mixing with "API route" or "service URL")
- Always "field" (not mixing with "column", "attribute", "property")

**Bad - Inconsistent:**
- Mixing "PDF rotation", "rotating documents", "turn pages"

Consistency helps Claude understand and follow instructions accurately.

### Write in Imperative/Infinitive Form

Use objective, instructional language:

**Good examples:**
- "To rotate a PDF, use the rotate_pdf.py script"
- "Extract form field information with..."
- "For simple edits, modify the file directly"

**Avoid:**
- "You should rotate PDFs using..." (second person)
- "Claude will need to use..." (referring to Claude)

### Provide Progressive Disclosure

Structure information from general to specific:

1. **High-level overview** - What the skill enables
2. **When to use it** - Specific scenarios and triggers
3. **How to use it** - Step-by-step instructions
4. **Details** - Edge cases, advanced features (or in references/)

### Include Concrete Examples

Abstract instructions are harder to follow. Provide concrete examples:

**Bad example:** "Format the data appropriately"

**Good example:** "Format the data as JSON: `{\"name\": \"John\", \"age\": 30}`"

### Structure Long Reference Files with Table of Contents

For reference files over 100 lines, include a table of contents at the top:

```markdown
## Contents
- [Authentication and Setup](#authentication-and-setup)
- [Core Methods](#core-methods)
- [Error Handling](#error-handling)
- [Examples](#examples)
```

## Degrees of Freedom

Skills can provide varying levels of freedom to Claude. Choose the appropriate level based on the task:

### High Freedom (Task-Based Instructions)

Provide goal and constraints; Claude figures out implementation.

**When to use:** Creative tasks, varying requirements, multiple valid approaches

**Example:**
```
## Code Review Process

Review code for potential bugs and improvements:
1. Check for security vulnerabilities
2. Assess code readability and maintainability
3. Suggest performance optimizations
4. Verify test coverage
```

### Medium Freedom (Provided Scripts with Parameters)

Provide tools/templates; Claude adapts them to the situation.

**When to use:** Structured tasks with variation, reusable patterns

**Example:**
```
## Generate Report

Use `scripts/generate_report.py` with these options:
- Format: --format [json|html|pdf]
- Date range: --from DATE --to DATE
- Filters: --filter EXPRESSION
```

### Low Freedom (Specific Scripts, Minimal Variation)

Provide exact instructions; Claude follows precisely.

**When to use:** Deterministic tasks, compliance requirements, exact formatting

**Example:**
```
## Export Financial Data

Run exactly: `python scripts/export.py --format csv --validate`
- Do not modify parameters
- Do not skip validation step
- Output must match schema in references/schema.md
```

**Guideline:** Match the level of freedom to task variability. Too much freedom for deterministic tasks creates inconsistency; too little freedom for creative tasks limits effectiveness.

## Common Skill Patterns

Skills typically follow one of these structural patterns:

### Pattern 1: Workflow-Based (Sequential Processes)

Best for skills with clear step-by-step procedures.

**Structure:**
- Overview
- Workflow Decision Tree
- Step 1 → Step 2 → Step 3...

**Example use case:** Document creation workflow, data analysis pipeline, research synthesis

**When to use:** Tasks have natural sequential steps or decision points

### Pattern 2: Task-Based (Tool Collections)

Best for skills offering different operations/capabilities.

**Structure:**
- Overview
- Quick Start
- Task Category 1 → Task Category 2...

**Example use case:** PDF manipulation (merge, split, extract), API operations (CRUD), file conversions

**When to use:** Skill provides distinct, independent operations

### Pattern 3: Reference/Guidelines (Standards or Specifications)

Best for brand guidelines, coding standards, or requirements.

**Structure:**
- Overview
- Guidelines
- Specifications → Usage Examples

**Example use case:** Brand styling guidelines, coding standards, compliance requirements

**When to use:** Providing standards, rules, or specifications to follow

### Pattern 4: Capabilities-Based (Integrated Systems)

Best for skills with multiple interrelated features.

**Structure:**
- Overview
- Core Capabilities (numbered list)
- Feature 1 → Feature 2...

**Example use case:** Product management system, integrated development environment features

**When to use:** Features work together as part of a larger system

**Note:** Patterns can be combined. Most skills mix patterns (e.g., task-based structure with workflow sections for complex operations).

## Extended Thinking vs Think Tool

Two mechanisms for deeper reasoning in skills:

### Extended Thinking (keywords in prompts)

Use for **initial planning** before action. Include these keywords in skill instructions:

| Keyword | Effect |
|---------|--------|
| "think" | Baseline reasoning |
| "think hard" | More computational budget |
| "think harder" | Even more budget |
| "ultrathink" | Maximum reasoning depth |

**Example in skill instructions:**
```markdown
Before implementing this workflow, think hard about alternative approaches and their trade-offs.
```

**Best for**: Complex decisions at workflow start, architectural choices, evaluating trade-offs upfront.

### Think Tool (structured reflection)

Use for **analyzing output** after tool calls. The think tool allows Claude to pause and reflect after receiving results from previous steps.

**Best for**:
- Processing complex results from previous tool calls
- Policy-heavy environments requiring compliance checks
- Sequential decisions where errors are costly
- Multi-step workflows where each step depends on previous output

### When to Use Which

| Scenario | Use |
|----------|-----|
| Planning approach before starting | Extended thinking |
| Analyzing API response before next call | Think tool |
| Evaluating trade-offs upfront | Extended thinking |
| Verifying compliance after data retrieval | Think tool |

**Best practice:** Include thinking instructions at decision points, not throughout. Overuse reduces effectiveness.

## Skill Creation Process

To create a skill, follow these 7 steps in order, skipping steps only if there is a clear reason why they are not applicable.

**Process overview:**

1. Understanding the Skill with Concrete Examples
2. Planning the Reusable Skill Contents
3. Writing the PRD (for complex skills)
4. Initializing the Skill
5. Edit the Skill
6. Packaging a Skill
7. Test and Iterate

### Step 1: Understanding the Skill with Concrete Examples

Skip this step only when the skill's usage patterns are already clearly understood. It remains valuable even when working with an existing skill.

**Critical insight:** Research and planning phases dramatically improve solution quality. Without exploration, Claude tends to jump straight to coding. Follow the **Explore → Plan → Code → Commit** pattern:

1. **Explore**: Examine existing skills, patterns, user needs
2. **Plan**: Document approach before writing SKILL.md
3. **Code**: Write the skill content
4. **Commit**: Finalize and version

To create an effective skill, clearly understand concrete examples of how the skill will be used. This understanding can come from either direct user examples or generated examples that are validated with user feedback.

For example, when building an image-editor skill, relevant questions include:

- "What functionality should the image-editor skill support? Editing, rotating, anything else?"
- "Can you give some examples of how this skill would be used?"
- "I can imagine users asking for things like 'Remove the red-eye from this image' or 'Rotate this image'. Are there other ways you imagine this skill being used?"
- "What would a user say that should trigger this skill?"

To avoid overwhelming users, avoid asking too many questions in a single message. Start with the most important questions and follow up as needed for better effectiveness.

Conclude this step when there is a clear sense of the functionality the skill should support.

### Step 2: Planning the Reusable Skill Contents

To turn concrete examples into an effective skill, analyze each example by:

1. Considering how to execute on the example from scratch
2. Identifying what scripts, references, and assets would be helpful when executing these workflows repeatedly

Example: When building a `pdf-editor` skill to handle queries like "Help me rotate this PDF," the analysis shows:

1. Rotating a PDF requires re-writing the same code each time
2. A `scripts/rotate_pdf.py` script would be helpful to store in the skill

Example: When designing a `frontend-webapp-builder` skill for queries like "Build me a todo app" or "Build me a dashboard to track my steps," the analysis shows:

1. Writing a frontend webapp requires the same boilerplate HTML/React each time
2. An `assets/hello-world/` template containing the boilerplate HTML/React project files would be helpful to store in the skill

Example: When building a `big-query` skill to handle queries like "How many users have logged in today?" the analysis shows:

1. Querying BigQuery requires re-discovering the table schemas and relationships each time
2. A `references/schema.md` file documenting the table schemas would be helpful to store in the skill

To establish the skill's contents, analyze each concrete example to create a list of the reusable resources to include: scripts, references, and assets.

### Step 3: Writing the PRD (Product Requirements Document)

**When to write a PRD:** For complex skills that meet ANY of these criteria:

- Multiple reference files (3+)
- Multiple branches or workflows
- Safety protocols or handoff requirements
- Multiple assessment tools or frameworks
- Expected to exceed 2000 words in SKILL.md

**Why PRD matters:** The PRD separates "what to build" from "how to build it". This separation:

- **Reduces cognitive load**: Architectural decisions are made upfront, freeing focus for implementation
- **Enables verification**: Gap analysis becomes possible (PRD vs. produced files)
- **Prevents drift**: Reference files stay consistent with original vision
- **Catches gaps early**: Missing elements are identified before implementation, not after

**PRD Structure (template):**

```markdown
# PRD: [Skill Name]

## 1. Executive Summary
- What the skill does (2-3 sentences)
- Target user and use cases
- Key differentiators

## 2. Problem Statement
- What problem does this solve?
- Concrete scenarios (2-3 examples)

## 3. Target User
- Who will use this skill
- Include criteria (who it's for)
- Exclude criteria (who needs something else)

## 4. Success Metrics
- How will we know the skill works?
- Measurable outcomes

## 5. Skill Structure
- SKILL.md sections outline
- Reference files list with purpose
- Scripts needed (if any)

## 6. Detailed Requirements
- For each reference file: what it must contain
- For each workflow: steps and decision points
- Safety/boundary conditions

## 7. Output Templates
- What outputs will the skill produce?
- Format and structure

## 8. Risks and Mitigations
- What could go wrong?
- Edge cases to handle
```

**PRD location:** Save as `docs/PRD.md` in the skill directory. The PRD is a design document, not loaded by Claude during skill execution. Keep the root clean with only SKILL.md.

```text
skill-name/
├── SKILL.md          # Only file in root
├── docs/
│   └── PRD.md        # Design document (not loaded by Claude)
├── references/       # Runtime documentation
├── scripts/          # Executable code
└── assets/           # Output resources
```

**Skip PRD when:** The skill is simple (single workflow, 1-2 reference files, <1500 words expected). In this case, proceed directly to Step 4.

### Step 4: Initializing the Skill

At this point, it is time to actually create the skill.

Skip this step only if the skill being developed already exists, and iteration or packaging is needed. In this case, continue to the next step.

When creating a new skill from scratch, run the `init_skill.py` script. The script conveniently generates a new template skill directory that automatically includes everything a skill requires, making the skill creation process much more efficient and reliable.

Usage:

```bash
scripts/init_skill.py <skill-name> --path <output-directory>
```

The script:

- Creates the skill directory at the specified path
- Generates a SKILL.md template with proper frontmatter and TODO placeholders
- Creates example resource directories: `scripts/`, `references/`, and `assets/`
- Adds example files in each directory that can be customized or deleted

After initialization, customize or remove the generated SKILL.md and example files as needed.

### Step 5: Edit the Skill

When editing the (newly-generated or existing) skill, remember that the skill is being created for another instance of Claude to use. Focus on including information that would be beneficial and non-obvious to Claude. Consider what procedural knowledge, domain-specific details, or reusable assets would help another Claude instance execute these tasks more effectively.

#### Start with Reusable Skill Contents

To begin implementation, start with the reusable resources identified above: `scripts/`, `references/`, and `assets/` files. Note that this step may require user input. For example, when implementing a `brand-guidelines` skill, the user may need to provide brand assets or templates to store in `assets/`, or documentation to store in `references/`.

Also, delete any example files and directories not needed for the skill. The initialization script creates example files in `scripts/`, `references/`, and `assets/` to demonstrate structure, but most skills won't need all of them.

#### Update SKILL.md

**Writing Style:** Write the entire skill using **imperative/infinitive form** (verb-first instructions), not second person. Use objective, instructional language (e.g., "To accomplish X, do Y" rather than "You should do X" or "If you need to do X"). This maintains consistency and clarity for AI consumption.

To complete SKILL.md, answer the following questions:

1. What is the purpose of the skill, in a few sentences?
2. When should the skill be used?
3. In practice, how should Claude use the skill? All reusable skill contents developed above should be referenced so that Claude knows how to use them.

#### Consider Workflows and Feedback Loops for Complex Tasks

For skills involving complex, multi-step tasks, consider including structured workflows and feedback loops.

**Workflow pattern example (Research synthesis):**

```markdown
## Research Synthesis Workflow

Copy this checklist and track progress:

Task Progress:
- [ ] Step 1: Read all source documents
- [ ] Step 2: Extract key themes
- [ ] Step 3: Cross-reference claims
- [ ] Step 4: Create structured summary
- [ ] Step 5: Verify citations

Follow this workflow:

**Step 1:** Done all source documents

Bar: `python scripts/analyze_docs.py input.pdf`

This extracts text and their locations, saving to `fields.json`.

**Step 2:** Identify key themes

...
```

This checklist helps Claude track multi-step progress and skip critical validations.

**Feedback loop pattern (Document editing):**

```markdown
## Document Editing Process

1. Read your content following the guidelines in STYLE_GUIDE.md:
   - Review the standards for structure
   - Identify all required sections
   - Confirm all required sections are present

2. If anything is unclear:
   - Note each unclear item with specific section reference
   - Review the relevant section in references/standards.md
   - Ask for clarification if still unclear

3. Only proceed once all requirements are met
4. Finalize and save the document
```

This validation loop ensures quality before continuing.

**When to use workflows:**
- Tasks have clear sequential dependencies
- Validation is needed between steps
- Multiple rounds of refinement are expected
- Process involves checking against external criteria

### Step 6: Packaging a Skill

Once the skill is ready, it should be packaged into a distributable zip file that gets shared with the user. The packaging process automatically validates the skill first to ensure it meets all requirements:

```bash
scripts/package_skill.py <path/to/skill-folder>
```

Optional output directory specification:

```bash
scripts/package_skill.py <path/to/skill-folder> ./dist
```

The packaging script will:

1. **Validate** the skill automatically, checking:
   - YAML frontmatter format and required fields
   - Skill naming conventions and directory structure
   - Description completeness and quality
   - File organization and resource references

2. **Package** the skill if validation passes, creating a zip file named after the skill (e.g., `my-skill.zip`) that includes all files and maintains the proper directory structure for distribution.

If validation fails, the script will report the errors and exit without creating a package. Fix any validation errors and run the packaging command again.

### Step 7: Test and Iterate

After creating the skill, systematic testing and iteration ensure effectiveness. This step is critical for developing high-quality skills.

#### Testing Before Uploading

Before uploading a skill to Claude, perform these checks:

1. **Review skill description accuracy**
   - Does the description clearly state when to use the skill?
   - Are trigger scenarios specific and accurate?
   - Is it written in third-person (not "Use this when..." but "This skill should be used when...")?

2. **Verify referenced files exist**
   - All scripts referenced in SKILL.md are present in `scripts/`
   - All references mentioned exist in `references/`
   - All assets are in `assets/` directory
   - Check paths are correct (no Windows-style paths if cross-platform)

3. **Check all TODOs completed**
   - Search for "[TODO" in SKILL.md
   - Verify all placeholder text has been replaced
   - Ensure example content has been customized or removed

4. **Run validation**
   - Execute `scripts/quick_validate.py` on the skill directory
   - Fix any validation errors before proceeding

#### Testing After Uploading to Claude

After uploading, test how Claude actually uses the skill:

1. **Try several different prompts** that should trigger the skill
   - Test with varied phrasing
   - Try edge cases and boundary scenarios
   - Verify skill triggers appropriately

2. **Review Claude's thinking process** when using the skill
   - Does Claude understand when to use which sections?
   - Are there confusing parts that need clarification?
   - Does Claude skip important steps?

3. **Iterate on clarity based on observations**
   - If Claude misunderstands instructions, simplify or add examples
   - If Claude skips steps, make them more explicit
   - If Claude over-complicates, reduce options or freedom

#### Gathering Feedback

Get input from others using the skill:

- Share with colleagues or team members
- Ask them to report where they struggled
- Document common issues or confusion points
- Prioritize fixes based on frequency and impact

#### Iteration Workflow

After testing reveals issues:

1. **Identify the root cause**
   - Is the description too vague?
   - Are instructions unclear or missing?
   - Do examples not cover common cases?
   - Are scripts or references inadequate?

2. **Make targeted improvements**
   - Update only what's needed (avoid over-engineering)
   - Add examples where understanding was lacking
   - Clarify ambiguous instructions
   - Enhance scripts or references as needed

3. **Test the specific improvement**
   - Re-test scenarios that previously failed
   - Verify the fix doesn't break other functionality
   - Ensure changes align with best practices

4. **Version and document changes**
   - Note what was changed and why
   - Track major iterations for reference
   - Consider keeping a changelog for significant skills

**Important:** Iteration should be driven by real usage observations, not hypothetical scenarios. Start minimal, observe struggles, then add only what's needed.

## Quality Checklist for Effective Skills

Before considering a skill complete, verify it meets these quality standards:

### Planning (for complex skills)

- [ ] **PRD written before implementation** - For skills with 3+ reference files or multiple workflows
- [ ] **PRD covers all 8 sections** - Executive summary through risks/mitigations
- [ ] **Gap analysis performed** - PRD requirements verified against produced files

### Core Quality

- [ ] **Description is specific and includes key terms** - Includes what the skill does and when to use it
- [ ] **Includes "when to use this skill"** - Clearly states trigger scenarios in SKILL.md
- [ ] **SKILL.md body is under 5000 words** - Longer content moved to reference files
- [ ] **No time-sensitive information** - Avoids "in 2024" or "latest" without context
- [ ] **Consistent terminology throughout** - Same terms used consistently (not mixing synonyms)
- [ ] **Examples are concrete, not abstract** - Shows specific input/output, not vague descriptions
- [ ] **File/folder structure is appropriate** - Uses flat structure, avoids deep nesting
- [ ] **Progressive disclosure is appropriate** - Information ordered from general to specific

### Code and Scripts

- [ ] **Scripts solve problems rather than just guide** - Provides executable code for deterministic tasks
- [ ] **Error handling is explicit and helpful** - Scripts provide clear error messages
- [ ] **No "vendor-container" or similar jargon** - Uses clear, standard terminology
- [ ] **Required packages listed in instructions** - Dependencies documented and verified
- [ ] **Scripts have clear documentation** - Each script includes purpose and usage
- [ ] **No Windows-only paths** - Uses cross-platform path formats (forward slashes)
- [ ] **Validation/verification steps included** - Quality checks built into critical code
- [ ] **Feedback loops included for quality-critical tasks** - Ensures validation before proceeding

### Testing

- [ ] **At least one test-driven iteration** - Tested with real usage, not just theory
- [ ] **Tested with realistic, not trivial, scenarios** - Goes beyond "hello world" examples
- [ ] **Tested with full range of expected use cases** - Covers edge cases and variations
- [ ] **Team feedback incorporated (if applicable)** - Others have tested and provided input

### Additional Considerations

- [ ] **Workflows have clear steps** - Multi-step processes are explicit and ordered
- [ ] **Reference files have table of contents** (if > 100 lines) - Easy navigation for long files
- [ ] **Assets are properly referenced** - All asset files are actually used in outputs
- [ ] **Security considerations addressed** (if applicable) - Credentials, inputs validated

## Four Pillars of Skill Quality (Runtime Assessment)

Beyond structural quality, evaluate skills against these four runtime quality dimensions (based on Google's Agent Quality framework):

### 1. Effectiveness

Does the skill produce correct and complete output?

- [ ] Output matches user intent accurately
- [ ] All requested information is included
- [ ] Output format is appropriate for the use case
- [ ] No missing steps or incomplete workflows

**Test question:** "If I gave this output to someone unfamiliar with the task, would they have everything they need?"

### 2. Efficiency

Does the skill use resources optimally?

- [ ] Minimal tool calls needed to complete task
- [ ] No redundant file reads or searches
- [ ] Token usage proportional to task complexity
- [ ] No unnecessary verbosity in output

**Test question:** "Could this task be completed with fewer tool calls or tokens without sacrificing quality?"

### 3. Robustness

Does the skill handle edge cases gracefully?

- [ ] Handles missing or incomplete user input
- [ ] Provides helpful error messages
- [ ] Offers recovery paths when things go wrong
- [ ] Works across different input formats/variations

**Test question:** "What happens if the user provides incomplete, ambiguous, or malformed input?"

### 4. Safety

Does the skill avoid harmful outputs?

- [ ] No hallucinated facts or citations
- [ ] No exposure of sensitive data patterns
- [ ] Clear boundaries on what skill cannot do
- [ ] Appropriate disclaimers where needed

**Test question:** "Could this output cause harm if the user trusts it without verification?"

### Using the Four Pillars

**During skill development:**

1. Test each pillar with representative scenarios
2. Document known limitations in SKILL.md
3. Add guardrails for identified risks

**When reviewing existing skills:**

1. Run through pillar questions after each major change
2. Prioritize fixes: Safety > Effectiveness > Robustness > Efficiency

## Security Considerations

When creating skills that involve scripts, external access, or user data, keep security in mind:

### Exercise Caution When Adding Scripts

- Don't hardcode sensitive information (API keys, passwords, tokens) in scripts
- Validate and sanitize user inputs before processing
- Use appropriate error handling to avoid exposing system details
- Document required permissions clearly

### Don't Hardcode Sensitive Information

**Bad example:**
```python
API_KEY = "sk-1234567890abcdef"
DATABASE_URL = "postgresql://user:pass@localhost/db"
```

**Good example:**
```python
import os
API_KEY = os.environ.get('API_KEY')
if not API_KEY:
    raise ValueError("API_KEY environment variable required")
```

### Use Appropriate MCP Connectors for External Service Access

For skills requiring external API access or database connections:

- Prefer MCP (Model Context Protocol) connectors when available
- Document which MCP servers are needed
- Don't implement custom authentication unless necessary
- Provide clear setup instructions for required connectors

### Validate User Inputs in Scripts

When scripts accept user input:

```python
# Validate file paths to prevent directory traversal
def safe_file_path(user_input):
    # Remove dangerous patterns
    if '..' in user_input or user_input.startswith('/'):
        raise ValueError("Invalid file path")
    return user_input
```

## Token Budget Optimization

Skills load into Claude's context window, so optimize for token efficiency:

### Context Engineering Principles

**Core insight from Anthropic:** Find the smallest set of high-signal tokens. More tokens don't always mean better results—in fact, excessive context leads to "context rot" where recall accuracy degrades.

**Key principles:**

1. **Right altitude** - Instructions should be neither too specific nor too vague
   - Too specific: Claude can't adapt to variations
   - Too vague: Claude makes assumptions that may be wrong

2. **High-signal density** - Every token should earn its place
   - Remove filler words, redundant explanations
   - Consolidate duplicate information
   - Use tables instead of verbose prose where possible

3. **Just-in-time retrieval** - Load context dynamically when needed
   - Don't pre-load everything "just in case"
   - Reference files load only when Claude determines they're needed
   - Scripts execute without loading into context

4. **Compression over expansion** - Summarize where possible
   - Link to detailed references instead of embedding them
   - Use patterns and templates instead of exhaustive lists

### Keep SKILL.md Under 5K Words

**Why:** SKILL.md loads into context when triggered. Longer files consume more tokens and may degrade performance.

**How to optimize:**
- Keep only essential procedural instructions in SKILL.md
- Move detailed documentation to `references/` files
- Move examples to `references/` if SKILL.md is getting long
- Use concise language without sacrificing clarity

### Progressive Disclosure Token Costs

Skills use a three-tier loading system with specific token costs:

| Level | Content | Token Cost | When Loaded |
|-------|---------|------------|-------------|
| 1 | Metadata (name + description) | ~100 tokens | Always in context |
| 2 | SKILL.md body | <5k tokens | When skill triggers |
| 3 | References | Variable | When Claude determines needed |
| 4 | Scripts | 0 tokens* | Executed without reading |

*Scripts execute without loading into context window, making them extremely token-efficient for repetitive code.

**Leverage this:** Put procedural "how-to" in SKILL.md, detailed reference material in `references/`.

### Include Grep Patterns for Large Reference Files

If reference files are large (>10k words), help Claude find relevant sections:

```markdown
For detailed API documentation, see references/api_docs.md
- To find authentication methods, search for "auth"
- To find error codes, search for "error:"
- To find rate limits, search for "limit"
```

### Scripts Execute Without Loading

**Advantage:** Scripts can be executed without reading into context window.

**Use this:** For repetitive or complex code that would consume many tokens if written each time, bundle as a script instead.

**When to use scripts vs. inline code:**
- Repetitive code (PDF manipulation, data processing) → Script
- Environment-specific adjustments → Script that can be read/modified
- Simple, one-off operations → Inline in SKILL.md guidance

## Skill Versioning and Evolution

Skills improve over time. Plan for evolution from the start:

### Create Evaluations Before Writing Documentation

**Evaluation-driven development approach:**

1. **Identify 3-5 concrete use cases** before writing SKILL.md
2. **Test with minimal instructions first** - Start with bare-bones guidance
3. **Observe where Claude struggles** - Note specific failure points
4. **Add only what's needed** - Address observed struggles, don't speculate
5. **Iterate based on real usage** - Let actual problems drive improvements

This prevents over-engineering and keeps skills focused.

### Build Test Scenarios First, Then Iterate

**Before extensive documentation:**
- Create test scenarios that represent real usage
- Run Claude through these scenarios with minimal guidance
- Measure performance (success rate, quality of output)

**After establishing baseline:**
- Add instructions incrementally
- Re-test after each addition
- Verify improvements justify the added complexity

### Establish Baselines and Measure Performance

Track skill effectiveness over time:

- **Before changes**: Test with current version, record results
- **After changes**: Re-test same scenarios, compare results
- **Document**: Note what improved and what regressed

This objective measurement prevents "improvements" that actually degrade performance.

### Write Minimal Instructions, Create Just Enough Content

**Start minimal principle:**
- Begin with shortest viable SKILL.md
- Add examples only where Claude demonstrably struggles
- Expand only based on observed failures
- Resist the urge to document edge cases that never occur

### Iterate Based on Observation, Not Speculation

**Observation-driven iteration:**
- ✅ "Claude consistently misunderstands X, add clarifying example"
- ✅ "Users report confusion about Y, expand that section"
- ❌ "Someone might eventually need Z, add just in case"
- ❌ "This could theoretically be unclear, add more detail"

**Version tracking:**
- Note significant changes with dates or version numbers
- Keep a simple changelog for skills used by teams
- Archive old versions if breaking changes are made

### When to Create New Versions vs. Iterate

**Iterate the same skill when:**
- Clarifying existing functionality
- Fixing errors or unclear instructions
- Adding examples for existing use cases
- Improving existing scripts

**Create a new skill version when:**
- Fundamentally changing the skill's purpose
- Adding major new capabilities
- Making breaking changes to script APIs
- Targeting different use cases

## Integration with Custom Slash Commands

Skills can work alongside custom slash commands stored in `.claude/commands/`.

### $ARGUMENTS Pattern

Slash command templates can accept parameters using the `$ARGUMENTS` keyword:

```markdown
# .claude/commands/use-skill.md
Activate the skill and process: $ARGUMENTS

Follow the skill's workflow for the given input.
```

**Usage**: `/project:use-skill "analyze this document"`

### When to Use Slash Commands vs Skills

| Use Case | Best Choice |
|----------|-------------|
| Persistent knowledge/procedures | Skill |
| Quick parameterized actions | Slash command |
| Complex multi-step workflows | Skill + slash command trigger |

### Creating Skill-Specific Commands

For skills that benefit from quick invocation, create a companion slash command:

```markdown
# .claude/commands/pdf-merge.md
Use the pdf skill to merge these files: $ARGUMENTS

Follow the merge workflow from the skill.
```

This allows users to trigger skill workflows with `/project:pdf-merge file1.pdf file2.pdf` instead of typing full instructions.

## Security Considerations

Skills provide Claude with new capabilities through instructions and code. **Only use skills from trusted sources.**

### Audit Checklist for Third-Party Skills

Before using a skill from an unknown source:

- [ ] Review SKILL.md for unexpected instructions or unusual directives
- [ ] Examine all scripts for: network calls, file access patterns, unusual operations
- [ ] Check if scripts fetch external URLs (risk: content may change over time)
- [ ] Verify bundled images/assets don't contain hidden instructions
- [ ] Test in isolated environment first

### Risks of Malicious Skills

| Risk | Description |
|------|-------------|
| Data exfiltration | Scripts could send sensitive data to external servers |
| Unauthorized access | Instructions could direct Claude to access unintended files |
| Tool misuse | Skill could invoke tools (bash, file operations) in harmful ways |

**Rule**: Treat skill installation like software installation. When in doubt, don't install.

## Writing Effective Scripts

Scripts bundled with skills should be designed for agent consumption, not just human execution.

### Design Principles

**1. Prompt-engineer your docstrings**

Script descriptions guide Claude's behavior. Small refinements yield dramatic improvements.

```python
# ❌ Vague
def process(data):
    """Process the data."""

# ✅ Specific
def extract_form_fields(pdf_path: str) -> dict:
    """Extract all fillable form fields from a PDF.

    Returns dict with field names as keys, current values as values.
    Empty fields have None values.

    Raises FileNotFoundError if PDF doesn't exist.
    Raises ValueError if PDF has no fillable fields.
    """
```

**2. Use unambiguous parameter names**

```python
# ❌ Ambiguous
def search(user, date):

# ✅ Clear
def search_transactions(user_id: str, transaction_date: str):
```

**3. Return semantic information**

```python
# ❌ Technical only
return {"id": "a1b2c3", "mime": "application/pdf"}

# ✅ Semantic + technical
return {
    "id": "a1b2c3",
    "name": "Q4_Report.pdf",
    "type": "PDF Document",
    "size_human": "2.3 MB"
}
```

**4. Constructive error handling**

```python
# ❌ Opaque
raise Exception("Error")

# ✅ Actionable
raise ValueError(
    f"Invalid date format '{date}'. "
    f"Expected YYYY-MM-DD. Example: 2024-03-15"
)
```

### Consolidation Principle

Prefer fewer, more capable scripts over many narrow ones:

| Instead of | Use |
|------------|-----|
| `list_users.py`, `get_user.py`, `search_users.py` | `users.py` with mode parameter |
| `merge_pdfs.py`, `split_pdf.py`, `extract_pdf.py` | `pdf_tools.py` with operation parameter |

### Namespacing Patterns

Use consistent naming conventions for scripts to help Claude select the right one:

**By service/domain:**
```
pdf_merge.py, pdf_extract.py, pdf_fill.py
excel_read.py, excel_write.py, excel_chart.py
```

**By resource:**
```
form_validate.py, form_fill.py, form_export.py
user_create.py, user_update.py, user_delete.py
```

**Naming guidelines:**
- Use snake_case for Python scripts
- Lead with the domain/resource name for easy discovery
- Be specific: `pdf_extract_text.py` not just `extract.py`
- Keep names under 30 characters

## Cross-Platform Considerations

Skills run differently across Claude's products:

| Platform | Network Access | Package Install | Notes |
|----------|---------------|-----------------|-------|
| Claude API | ❌ None | ❌ Pre-installed only | Most restrictive |
| Claude.ai | ⚠️ Varies | ❌ No | Depends on user/admin settings |
| Claude Code | ✅ Full | ✅ Yes | Avoid global installs |

**Recommendation**: Design skills for the most restrictive environment (API) unless targeting specific platforms.

Scripts should:
- Not assume network access
- Use only common pre-installed packages
- Fail gracefully if dependencies unavailable
