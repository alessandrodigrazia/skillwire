# Best Practices for Skill Creation - Detailed Guide

This reference expands on best practices for creating effective, maintainable skills with real-world examples and detailed guidance.

## Contents

- [Writing Effective Descriptions](#writing-effective-descriptions)
- [Start Simple, Iterate Based on Real Usage](#start-simple-iterate-based-on-real-usage)
- [Using Concrete Examples Effectively](#using-concrete-examples-effectively)
- [Testing and Validation](#testing-and-validation)
- [Versioning and Change Management](#versioning-and-change-management)
- [Token Budget Management](#token-budget-management)
- [Progressive Disclosure in Practice](#progressive-disclosure-in-practice)
- [Case Studies](#case-studies)

---

## Writing Effective Descriptions

The description in YAML frontmatter is the most important part of a skill—it determines when Claude will use it.

### Anatomy of a Good Description

**Formula:** `[What the skill does] + [When to use it] + [Key capabilities/scenarios]`

**Examples:**

✅ **Good - PDF skill:**
```yaml
description: Processes PDF files: extracts text, merges documents, fills form fields, and converts to images. This skill should be used when working with PDF documents for text extraction, document assembly, form manipulation, or format conversion.
```

**Why it works:**
- **What**: "Processes PDF files"
- **Key capabilities**: Lists main functions (extract, merge, fill, convert)
- **When**: "when working with PDF documents for..." + specific scenarios

✅ **Good - Data analysis skill:**
```yaml
description: Analyzes tabular data: creates pivot tables, generates statistical summaries, performs trend analysis, and produces visualizations. Use this skill when working with CSV or Excel files that need data exploration, statistical analysis, or chart generation.
```

**Why it works:**
- Specific about data types (tabular, CSV, Excel)
- Lists concrete capabilities
- Clear trigger scenarios

❌ **Bad examples:**

```yaml
description: Helps with documents
```
**Problems:** Too vague. What kind of documents? What kind of help?

```yaml
description: PDF Processing Tool
```
**Problems:** Just a title, not a description. No "when to use" guidance.

```yaml
description: Use this skill when you need to work with PDF files
```
**Problems:** Second person ("you"). No information about what it actually does.

### Description Length Guidelines

- **Minimum**: ~50 characters (provides meaningful information)
- **Sweet spot**: 100-200 characters (specific without being verbose)
- **Maximum**: ~300 characters (stays concise, avoids token waste)

### Specific Triggers to Include

Mention specific scenarios that should trigger the skill:

**Good trigger mentions:**
- File types: "when working with PDF documents"
- User intents: "when needing to extract data from images"
- Task types: "when creating data visualizations"
- Contexts: "when following brand guidelines for presentations"

---

## Start Simple, Iterate Based on Real Usage

The most common mistake in skill creation is over-engineering. Start minimal.

### The Minimal Viable Skill Approach

**Step 1: Identify 3-5 Core Use Cases**

Before writing anything, list concrete examples:

```
PDF Skill Use Cases:
1. "Merge these three PDF files into one document"
2. "Extract all text from this scanned PDF"
3. "Fill out this PDF form with data from my spreadsheet"
4. "Split this 100-page PDF into individual chapters"
5. "Extract all images from this PDF document"
```

**Step 2: Write Minimal Instructions**

For each use case, write the shortest viable instructions:

```markdown
## Merge PDFs

Run: `python scripts/merge_pdfs.py file1.pdf file2.pdf --output merged.pdf`
```

That's it. Don't add:
- "This merges PDF files together" (obvious)
- Examples of when you might want to merge PDFs (not needed yet)
- Options you haven't tested (YAGNI - You Aren't Gonna Need It)

**Step 3: Test With Real Scenarios**

Actually use the skill. Watch where Claude struggles:
- Does Claude misunderstand when to use it? → Improve description
- Does Claude use wrong script? → Clarify which script for what
- Does Claude miss important details? → Add those specific details
- Does Claude work perfectly? → You're done, don't add more

**Step 4: Add Only What's Needed**

Based on actual observed problems:

```markdown
## Merge PDFs

Combine multiple PDF files preserving page order:

`python scripts/merge_pdfs.py file1.pdf file2.pdf file3.pdf --output merged.pdf`

Files are merged in the order specified.
```

Added "preserving page order" and "in the order specified" because that was an actual question that came up.

### Red Flags of Over-Engineering

⚠️ **Warning signs you're over-engineering:**

1. **Adding edge cases never encountered**
   - "If the user has more than 1000 files..." (has this happened?)
   - "In the rare case where..." (how rare? ever?)

2. **Documenting every possible option**
   - If 90% of use cases use default values, document defaults only
   - Add options only when actually needed

3. **Explaining obvious things**
   - "The merge command merges PDFs" (redundant)
   - "Files must be PDF format" (obvious from context)

4. **Hypothetical workflows**
   - "You might want to..." (has anyone wanted to?)
   - "This could be useful for..." (has it been?)

### Iteration Cycle

```
1. Create minimal skill
   ↓
2. Use on real tasks
   ↓
3. Note where Claude struggles ← ┐
   ↓                              │
4. Add specific guidance          │
   ↓                              │
5. Re-test same scenario          │
   ↓                              │
6. Did it improve? ───────────────┘
   │
   ├─ Yes → Move to next scenario
   │
   └─ No → Try different approach
```

---

## Using Concrete Examples Effectively

Abstract instructions are hard for Claude to follow. Concrete examples are vastly better.

### The Power of Concrete Examples

**Abstract (harder to follow):**
```markdown
Format the data appropriately based on the context and requirements.
```

**Concrete (easier to follow):**
```markdown
Format data as JSON:
```json
{
  "name": "John Doe",
  "age": 30,
  "email": "john@example.com"
}
```
```

### Example Patterns That Work

#### Pattern 1: Template Pattern

Show the exact template structure:

```markdown
## Event Export Format

Use this exact structure:

```
📅 Event: [Event Title]
📍 Location: [Venue Name]
🕐 Time: [Start Time] - [End Time]
👥 Attendees: [Number]

Description:
[Event description here]
```
```

#### Pattern 2: Before/After Examples

Show transformation clearly:

```markdown
## Data Cleaning

**Input CSV:**
```csv
Name,Email,Phone
John Doe,john@example.com,(555) 123-4567
Jane Smith,jane@example.com,555-234-5678
```

**Output (cleaned):**
```csv
name,email,phone
john doe,john@example.com,5551234567
jane smith,jane@example.com,5552345678
```

**Changes applied:**
- Lowercase headers and values
- Remove special characters from phone
- Consistent formatting
```

#### Pattern 3: Good vs. Bad Examples

Explicitly show what to do and what to avoid:

```markdown
## Writing Commit Messages

✅ **Good:**
```
feat: Add user authentication with OAuth 2.0

Implements login/logout functionality using OAuth 2.0 protocol.
Includes token refresh and secure session management.

Resolves #123
```

❌ **Bad:**
```
updated stuff
```

❌ **Bad:**
```
feat: add authentication and also refactor database code and fix
some bugs and update dependencies and change config
```
```

### When Examples Are Most Valuable

Use concrete examples especially for:

1. **Data formats** - JSON, CSV, XML structures
2. **Output templates** - Reports, documents, exports
3. **Code patterns** - Snippets that should be replicated
4. **Style guidelines** - What good looks like
5. **Error handling** - Common problems and solutions

---

## Testing and Validation

Systematic testing is what separates good skills from great skills.

### Pre-Upload Testing

Before sharing a skill, test these aspects:

#### 1. Description Accuracy Test

**Test:** Read only the description. Can you predict what the skill does?
- If yes → description is probably clear
- If no → description needs work

**Test:** Does the description mention scenarios that actually trigger the skill?
- Check: Do keywords in description match real usage?

#### 2. File Reference Test

**Test:** Search SKILL.md for file references (`scripts/`, `references/`, `assets/`)

For each reference found:
```bash
# Verify file exists
ls scripts/mentioned_script.py
ls references/mentioned_doc.md
ls assets/mentioned_asset.png
```

#### 3. Completeness Test

**Test:** Search for TODO markers:
```bash
grep -n "TODO" SKILL.md
grep -n "\[TODO\]" SKILL.md
```

Should return zero results before publishing.

#### 4. Example Code Test

**Test:** Copy each code example from SKILL.md and try running it
- Does it work as documented?
- Are there missing dependencies?
- Are paths correct?

### Post-Upload Testing

After uploading to Claude:

#### 1. Trigger Test

Try multiple ways of asking for the skill:

**Example for PDF skill:**
- "I need to merge these PDFs"
- "How do I combine multiple PDF files?"
- "Extract text from this PDF document"
- "I have a PDF form to fill out"

**Verify:** Does Claude correctly use the skill for all of these?

#### 2. Comprehension Test

Ask Claude to explain the skill:
- "What can this skill do?"
- "When should I use this skill?"

**Verify:** Does Claude's explanation match your intent?

#### 3. Edge Case Test

Try scenarios at the boundaries:
- Very large files
- Missing inputs
- Unusual combinations
- Error conditions

**Verify:** Does the skill handle these gracefully?

### Creating Test Scenarios

Document your test cases:

```markdown
## Test Scenarios for PDF Skill

### Scenario 1: Basic Merge
**Input:** 3 PDF files (5 pages, 10 pages, 3 pages)
**Expected:** Single PDF with 18 pages in correct order
**Status:** ✅ Pass

### Scenario 2: Form Filling
**Input:** Template PDF + JSON data file
**Expected:** Filled PDF with all fields populated
**Status:** ✅ Pass

### Scenario 3: Large File Extraction
**Input:** 500-page scanned PDF
**Expected:** Text extracted, warnings about OCR quality
**Status:** ⚠️  Works but slow - add performance note

### Scenario 4: Corrupted Input
**Input:** Damaged PDF file
**Expected:** Clear error message, suggest repair
**Status:** ❌ Fail - improve error handling
```

---

## Versioning and Change Management

Skills evolve. Plan for it.

### Version Numbering

**Simple approach for SKILL.md:**

```markdown
# Skill Name

Version: 2.1.0
Last updated: 2024-11-15

...
```

**Semantic versioning:**
- **Major** (2.0.0): Breaking changes to scripts or structure
- **Minor** (2.1.0): New features added
- **Patch** (2.1.1): Bug fixes, clarifications

### Changelog

Keep a simple log at the end of SKILL.md:

```markdown
## Changelog

### Version 2.1.0 (2024-11-15)
- Added batch processing capability
- New script: process_batch.py
- Improved error messages for file not found

### Version 2.0.0 (2024-10-01)
- BREAKING: Changed output format from CSV to JSON
- Migration guide in references/migration_v2.md
- Deprecated old format support

### Version 1.2.0 (2024-09-15)
- Added validation checks before processing
- New examples for edge cases
```

### When to Create a New Version vs. Update

**Update in place (patch/minor):**
- Fixing bugs
- Clarifying existing instructions
- Adding examples for existing features
- Improving performance
- Better error messages

**Create new version (major):**
- Changing script APIs
- Removing features
- Changing output formats
- Restructuring significantly
- Different use cases

### Migration Support

For breaking changes, provide migration path:

```markdown
## Migrating from v1 to v2

### What Changed
- Output format changed from CSV to JSON
- Script renamed: process.py → process_data.py
- New required parameter: --format

### Migration Steps

1. **Update script calls:**
   ```bash
   # Old (v1):
   python process.py input.txt

   # New (v2):
   python process_data.py input.txt --format json
   ```

2. **Update output parsing:**
   ```python
   # Old (v1):
   data = pd.read_csv(output_file)

   # New (v2):
   with open(output_file) as f:
       data = json.load(f)
   ```

### Backward Compatibility

For legacy support:
```bash
python process_data.py input.txt --format csv --legacy
```
```

---

## Token Budget Management

Skills consume tokens. Optimize wisely.

### Measuring Token Usage

**Quick estimate:**
- ~4 characters = 1 token
- 1000 words ≈ 750 tokens
- 5000 words ≈ 3,750 tokens

**Check your SKILL.md:**
```bash
# Word count
wc -w SKILL.md

# Character count
wc -m SKILL.md
```

### Progressive Disclosure in Practice

**Tier 1: Metadata (always loaded)**
- name + description
- Target: <100 tokens

**Tier 2: SKILL.md (loaded when triggered)**
- Core instructions
- Target: <4,000 tokens (≈5,000 words)

**Tier 3: References (loaded as needed)**
- Detailed documentation
- No strict limit

### When to Move Content to References

Move to `references/` when:

✅ **Content is detailed documentation**
- API specifications
- Comprehensive examples
- Deep-dive explanations

✅ **Content is large reference material**
- Database schemas
- Complete style guides
- Extensive code examples

✅ **Content is optional/advanced**
- Edge cases
- Advanced features
- Troubleshooting guides

Keep in SKILL.md when:

✅ **Content is core instructions**
- Basic usage
- Common workflows
- Essential commands

✅ **Content is navigational**
- Pointers to references
- Structure overview
- Quick start

### Optimization Techniques

**1. Use pointers instead of duplication:**

❌ **Bad:**
```markdown
## API Authentication

[500 words of authentication documentation]

## Making API Calls

[Repeat authentication information]
```

✅ **Good:**
```markdown
## API Authentication

See references/authentication.md for complete authentication guide.

Quick start: Use OAuth token in Authorization header.

## Making API Calls

Authentication: See above section.
```

**2. Summarize with reference:**

```markdown
## Database Schema

**Tables:** users, products, orders, order_items

For complete schema with field types and relationships,
see references/schema.md. Search for table name to find details.
```

**3. Consolidate examples:**

Instead of 10 separate examples throughout SKILL.md,
create references/examples.md with all examples categorized.

---

## Case Studies

Real-world examples of skills created following these best practices.

### Case Study 1: PDF Processing Skill (Iterative Development)

**v0.1 - Initial (Too Minimal):**
```markdown
## PDF Skill

Merge PDFs: `python merge.py file1.pdf file2.pdf`
```

**Problem:** Users didn't know what scripts existed.

**v0.2 - Added Overview:**
```markdown
## PDF Processing

Available operations:
- Merge: scripts/merge_pdfs.py
- Split: scripts/split_pdf.py
- Extract text: scripts/extract_text.py
```

**Problem:** Users didn't know which to use when.

**v1.0 - Added Guidance:**
```markdown
## PDF Processing

### Merge Documents
Combine multiple PDFs into one:
`python scripts/merge_pdfs.py file1.pdf file2.pdf --output merged.pdf`

### Extract Text
Pull text content from PDF:
`python scripts/extract_text.py input.pdf --output text.txt`

[Continued for each operation]
```

**Result:** Clear, usable, effective.

**Key Lesson:** Iterate based on real confusion, not hypothetical needs.

### Case Study 2: Brand Guidelines Skill (Structure Evolution)

**Initial approach - All in SKILL.md (8,000 words):**
- Complete brand guidelines
- Every color, font, spacing rule
- Tons of examples

**Problem:** SKILL.md was huge, slow to load, hard to navigate.

**Refactored approach:**

**SKILL.md (1,200 words):**
```markdown
## Brand Guidelines

Core brand elements and usage rules.

### Logo
- Minimum size: 40px height
- Files: assets/logos/
- Details: references/logo_guidelines.md

### Colors
- Primary: #0066CC (Brand Blue)
- Secondary: #00AA44 (Accent Green)
- Full palette: references/color_system.md

[Continue with summaries...]
```

**references/logo_guidelines.md:** All logo details
**references/color_system.md:** Complete color system
**references/typography.md:** Font specifications

**Result:** Fast loading, easy navigation, comprehensive when needed.

**Key Lesson:** Use progressive disclosure. Summaries in SKILL.md, details in references.

---

## Quick Reference Checklist

Before finalizing a skill:

- [ ] Description is specific and includes "when to use"
- [ ] Started minimal, iterated based on real usage
- [ ] Concrete examples for data formats and outputs
- [ ] Tested with multiple real scenarios
- [ ] All file references verified to exist
- [ ] No TODO markers remaining
- [ ] SKILL.md under 5,000 words
- [ ] Detailed content moved to references/
- [ ] Version number and changelog (if applicable)
- [ ] Migration guide (if breaking changes)

**Remember:** Perfect is the enemy of good. Ship a working v1.0, then iterate based on real feedback.
