# Skill Patterns - Detailed Examples and Guidance

This reference provides in-depth examples of common skill patterns, helping guide the choice and implementation of the right structure for different types of skills.

## Contents

- [Pattern 1: Workflow-Based (Sequential Processes)](#pattern-1-workflow-based-sequential-processes)
- [Pattern 2: Task-Based (Tool Collections)](#pattern-2-task-based-tool-collections)
- [Pattern 3: Reference/Guidelines (Standards or Specifications)](#pattern-3-referenceguidelines-standards-or-specifications)
- [Pattern 4: Capabilities-Based (Integrated Systems)](#pattern-4-capabilities-based-integrated-systems)
- [Mixing Patterns](#mixing-patterns)
- [Choosing the Right Pattern](#choosing-the-right-pattern)

---

## Pattern 1: Workflow-Based (Sequential Processes)

### When to Use

- Tasks have clear sequential dependencies
- Processes involve decision points or branching
- Validation is needed between steps
- Multiple rounds of refinement are expected

### Structure

```
## Overview
[Brief description of the workflow]

## Workflow Decision Tree
[Help Claude decide which path to take]

## Step 1: [First Step Name]
[Detailed instructions for first step]

## Step 2: [Second Step Name]
[Detailed instructions for second step]

...

## Validation and Quality Checks
[How to verify the work is correct]
```

### Real Example: Research Synthesis Workflow

```markdown
## Research Synthesis Workflow

This skill guides systematic synthesis of research documents into structured summaries.

## Workflow Decision Tree

Determine your starting point:
- **Have source documents ready?** → Proceed to Step 1
- **Need to gather sources first?** → Use search/collection tools first
- **Have existing summary to refine?** → Jump to Step 4

## Step 1: Read All Source Documents

For each document:
1. Extract the main thesis or argument
2. Note key supporting evidence
3. Identify methodology or approach used
4. Record any limitations or caveats mentioned

**Output:** Create a structured notes file for each source.

## Step 2: Extract Key Themes

Across all documents:
1. Identify recurring themes or topics
2. Note areas of consensus
3. Highlight points of disagreement or debate
4. Track evolution of ideas chronologically (if applicable)

**Use:** `scripts/theme_analysis.py` to help identify patterns.

## Step 3: Cross-Reference Claims

For major claims:
1. Track which sources support the claim
2. Note the strength of evidence provided
3. Identify any counterarguments
4. Assess the overall consensus

**Validation checkpoint:** Ensure no major claims lack citation.

## Step 4: Create Structured Summary

Build the final synthesis:
1. Introduction: State the research question/topic
2. Consensus findings: What most sources agree on
3. Points of debate: Where sources disagree
4. Knowledge gaps: What's not yet well understood
5. Conclusion: Overall state of the field

## Step 5: Verify Citations

Final quality check:
- Every claim has at least one source citation
- Contradictory evidence is acknowledged
- Sources are accurately represented
- No plagiarism or overly close paraphrasing
```

### Key Features

- **Checkpoints**: Built-in validation between steps
- **Decision trees**: Help Claude navigate different scenarios
- **Outputs**: Each step has clear deliverable
- **Tools integration**: Scripts referenced at appropriate points

---

## Pattern 2: Task-Based (Tool Collections)

### When to Use

- Skill provides distinct, independent operations
- Users need different capabilities at different times
- Operations don't have strict dependencies
- Focus is on "what can be done" rather than "in what order"

### Structure

```
## Overview
[What this skill enables]

## Quick Start
[Most common use case example]

## Task Category 1: [Category Name]

### Operation 1.1: [Specific Task]
[How to accomplish this specific task]

### Operation 1.2: [Another Task]
[How to accomplish this other task]

## Task Category 2: [Category Name]
...
```

### Real Example: PDF Manipulation Skill

```markdown
## Overview

This skill enables comprehensive PDF document manipulation: merging, splitting, extracting content, filling forms, and converting to other formats.

## Quick Start

Most common task - merge multiple PDFs:

```bash
python scripts/merge_pdfs.py input1.pdf input2.pdf input3.pdf --output merged.pdf
```

## Document Assembly

### Merge PDFs

Combine multiple PDF files into a single document:

```bash
python scripts/merge_pdfs.py [files...] --output result.pdf
```

**Options:**
- `--bookmarks`: Add bookmarks for each source file
- `--toc`: Generate table of contents

### Split PDF

Extract specific pages or ranges:

```bash
python scripts/split_pdf.py input.pdf --pages 1-5,10,15-20 --output section.pdf
```

**Use cases:**
- Extract chapters from larger document
- Separate appendices
- Create handouts from presentation

## Content Extraction

### Extract Text

Pull all text content from PDF:

```bash
python scripts/extract_text.py input.pdf --output text.txt
```

**Options:**
- `--preserve-layout`: Maintain spatial arrangement
- `--pages`: Extract from specific pages only

### Extract Images

Save all images embedded in PDF:

```bash
python scripts/extract_images.py input.pdf --output-dir images/
```

## Form Handling

### Fill Form Fields

Populate fillable PDF forms programmatically:

```bash
python scripts/fill_form.py template.pdf data.json --output filled.pdf
```

See `references/form_field_guide.md` for field naming and data format.

### Extract Form Data

Read existing form field values:

```bash
python scripts/extract_form_data.py filled.pdf --output data.json
```

## Conversion

### PDF to Images

Convert each page to an image file:

```bash
python scripts/pdf_to_images.py input.pdf --format png --output-dir pages/
```

**Formats supported:** PNG, JPEG, TIFF

### PDF to DOCX

Convert to editable Word document:

```bash
python scripts/pdf_to_docx.py input.pdf --output document.docx
```

**Note:** Complex layouts may not convert perfectly. Review output.
```

### Key Features

- **Categorization**: Related operations grouped together
- **Independence**: Each operation stands alone
- **Quick reference**: Easy to find specific capability
- **Examples**: Every operation has usage example

---

## Pattern 3: Reference/Guidelines (Standards or Specifications)

### When to Use

- Providing standards, rules, or specifications to follow
- Enforcing brand consistency or coding standards
- Documenting company policies or procedures
- Establishing quality criteria

### Structure

```
## Overview
[Purpose of these guidelines]

## Core Principles
[Fundamental rules that underlie everything]

## [Category 1]: [Aspect Name]

### Specification
[Exact requirements]

### Examples
[Good and bad examples]

### Rationale
[Why this matters]

## [Category 2]: [Aspect Name]
...

## Usage Guide
[How to apply these guidelines in practice]

## Validation
[How to check compliance]
```

### Real Example: Brand Style Guidelines

```markdown
## Brand Style Guidelines

Official brand guidelines for all company communications and materials. Use these standards for consistent brand representation across all touchpoints.

## Core Principles

1. **Clarity First**: All communications should be immediately clear
2. **Consistency**: Use established patterns and styles
3. **Accessibility**: Design for all audiences and abilities

## Visual Identity

### Logo Usage

**Specifications:**
- Minimum size: 40px height (digital), 0.5 inches (print)
- Clear space: Minimum 25% of logo width on all sides
- Acceptable formats: Primary (full color), Monochrome (black or white), Reversed

**Correct usage:**
- Use approved logo files from `assets/logos/`
- Maintain aspect ratio (never stretch or distort)
- Place on backgrounds with sufficient contrast

**Incorrect usage:**
- ❌ Never rotate the logo
- ❌ Never add effects (shadows, outlines, gradients)
- ❌ Never change colors outside approved palette
- ❌ Never place on busy backgrounds

### Color Palette

**Primary Colors:**
- **Brand Blue**: #0066CC (RGB: 0, 102, 204)
  - Use for: Primary CTAs, headers, key elements
  - Accessibility: WCAG AA compliant on white background

- **Brand Gray**: #333333 (RGB: 51, 51, 51)
  - Use for: Body text, secondary elements
  - Accessibility: AAA compliant on white background

**Secondary Colors:**
- **Accent Green**: #00AA44 (RGB: 0, 170, 68)
  - Use for: Success states, positive indicators

- **Accent Orange**: #FF6600 (RGB: 255, 102, 0)
  - Use for: Warnings, highlights

**Never:**
- Don't use colors outside the approved palette
- Don't reduce opacity below 80% for text elements
- Don't use vibrating color combinations

### Typography

**Primary Typeface:** Helvetica Neue
- **Headers**: Helvetica Neue Bold
  - H1: 32pt / 48pt line height
  - H2: 24pt / 36pt line height
  - H3: 18pt / 27pt line height

- **Body**: Helvetica Neue Regular
  - Body text: 14pt / 21pt line height
  - Small text: 12pt / 18pt line height minimum

**Web Fallback:** Use Arial if Helvetica Neue unavailable

**Specifications:**
- Line length: Maximum 75 characters for optimal readability
- Paragraph spacing: 1em between paragraphs
- Never use more than 2 font weights per design

## Communication Tone

### Voice Characteristics

- **Professional but friendly**: Expert without being stuffy
- **Clear and direct**: No jargon unless necessary (define when used)
- **Helpful**: Focus on user benefit and value
- **Confident**: State facts clearly, avoid hedging language

### Writing Guidelines

**Good examples:**
- ✅ "Download the guide to get started"
- ✅ "This feature helps you save time on repetitive tasks"
- ✅ "Contact support if you need assistance"

**Avoid:**
- ❌ "You might want to consider possibly downloading..."
- ❌ "This revolutionary paradigm-shifting solution..."
- ❌ "Reach out to our team..." (too casual)

## Application Templates

All templates available in `assets/templates/`:

- `presentation_template.pptx` - Standard slide deck
- `document_template.docx` - Official documents
- `email_signature.html` - Email signatures
- `social_media_templates/` - Social post templates

## Validation Checklist

Before publishing any branded material:

- [ ] Logo usage follows specifications
- [ ] Colors match approved palette (hex codes exact)
- [ ] Typography uses approved fonts and sizes
- [ ] Tone matches voice guidelines
- [ ] Templates used as base (if applicable)
- [ ] Accessibility requirements met
- [ ] Legal review completed (if required)
```

### Key Features

- **Specifications**: Exact, measurable requirements
- **Examples**: Both correct and incorrect usage shown
- **Rationale**: Explains the "why" behind rules
- **Validation**: Checklist for compliance verification

---

## Pattern 4: Capabilities-Based (Integrated Systems)

### When to Use

- Multiple features that work together
- System with interrelated components
- Features build on each other
- Holistic approach needed rather than isolated tasks

### Structure

```
## Overview
[What the integrated system provides]

## Core Capabilities
[Numbered list of main features]

### Capability 1: [Feature Name]

#### What It Does
[Description]

#### How to Use
[Instructions]

#### Integration Points
[How it connects with other features]

### Capability 2: [Feature Name]
...

## Workflows
[Common ways to combine capabilities]
```

### Real Example: Product Management System

```markdown
## Product Management Assistant

Comprehensive product management support system integrating context building, decision tracking, and stakeholder communication.

## Core Capabilities

This skill provides four integrated capabilities:

1. **Context Building** - Gather and organize product context
2. **Decision Documentation** - Track and communicate decisions
3. **Stakeholder Updates** - Generate status communications
4. **Roadmap Planning** - Develop and maintain product roadmaps

### Capability 1: Context Building

#### What It Does

Systematically gathers product context across multiple dimensions: user needs, business goals, technical constraints, market conditions, and team capacity.

#### How to Use

Start context building for a new initiative:

```
scripts/build_context.py --initiative "Mobile App Redesign"
```

This creates a structured context document with prompts for:
- User research findings
- Business objectives and KPIs
- Technical dependencies and constraints
- Competitive landscape
- Resource availability

#### Integration Points

- **Feeds into** Decision Documentation (provides context for decisions)
- **Informs** Roadmap Planning (constraints and opportunities)
- **Referenced in** Stakeholder Updates (background information)

See `references/context_building.md` for detailed guidance.

### Capability 2: Decision Documentation

#### What It Does

Creates clear, structured decision records that capture what was decided, why, alternatives considered, and who was involved.

#### How to Use

Document a product decision:

```
scripts/create_decision.py --title "Choose Mobile Framework"
```

Follow the prompts to complete:
- **Decision**: What was decided
- **Context**: Why this decision was needed (links to Context Building)
- **Alternatives**: Options considered and why rejected
- **Stakeholders**: Who was involved in decision
- **Implications**: What this means going forward

#### Integration Points

- **Uses** Context Building (references existing context)
- **Feeds into** Stakeholder Updates (decisions to communicate)
- **Influences** Roadmap Planning (decisions affect timeline)

See `references/decision_framework.md` for the decision template.

### Capability 3: Stakeholder Updates

#### What It Does

Generates tailored status updates for different stakeholder audiences: executives, engineering teams, customers, and cross-functional partners.

#### How to Use

Create a stakeholder update:

```
scripts/generate_update.py --audience executive --period weekly
```

Automatically includes:
- Recent decisions (from Decision Documentation)
- Progress against roadmap (from Roadmap Planning)
- Context changes (from Context Building)
- Risks and blockers
- Next steps

#### Integration Points

- **Pulls from** Decision Documentation (recent decisions)
- **References** Roadmap Planning (progress updates)
- **Uses** Context Building (background for new stakeholders)

See `references/communication.md` for audience-specific guidance.

### Capability 4: Roadmap Planning

#### What It Does

Develops realistic, stakeholder-aligned product roadmaps that balance user needs, business goals, and technical constraints.

#### How to Use

Generate or update a roadmap:

```
scripts/plan_roadmap.py --timeline Q1-2025
```

Incorporates:
- Context from Context Building (constraints and opportunities)
- Decisions from Decision Documentation (commitments made)
- Team capacity and technical dependencies
- Business priorities and user needs

#### Integration Points

- **Informed by** Context Building (constraints and goals)
- **Reflects** Decision Documentation (commitments and directions)
- **Reported in** Stakeholder Updates (progress and changes)

See `references/roadmap_guide.md` for planning frameworks.

## Common Workflows

### Workflow 1: Launch a New Initiative

1. **Build Context** - Use Context Building to gather background
2. **Make Key Decisions** - Use Decision Documentation for framework choices
3. **Plan Roadmap** - Use Roadmap Planning to sequence work
4. **Communicate** - Use Stakeholder Updates to align everyone

### Workflow 2: Quarterly Planning

1. **Review Context** - Update market and business context
2. **Review Decisions** - Revisit key decisions still in effect
3. **Update Roadmap** - Adjust based on new information
4. **Stakeholder Alignment** - Generate executive update

### Workflow 3: Handle a Major Blocker

1. **Document Decision** - Use Decision Documentation for mitigation approach
2. **Update Context** - Reflect new constraints in Context Building
3. **Adjust Roadmap** - Use Roadmap Planning to resequence
4. **Communicate Impact** - Use Stakeholder Updates to inform teams
```

### Key Features

- **Integration explicit**: Shows how capabilities connect
- **Workflows**: Demonstrates combining features
- **Holistic**: Presents as unified system rather than isolated tools
- **Cross-references**: Points to detailed docs in references/

---

## Mixing Patterns

Most real-world skills combine multiple patterns. Here are common combinations:

### Task-Based + Workflow

**Structure:** Present task-based organization, but include workflow sections for complex operations.

**Example:** PDF skill is primarily task-based (merge, split, extract) but includes a workflow section for "Creating an Interactive Form Document":

```markdown
## Document Assembly
[Task-based sections for merge, split]

## Content Extraction
[Task-based sections for text, images]

## Complex Workflow: Creating Interactive Form Documents

### Step 1: Design Form Layout
Create initial PDF with form structure...

### Step 2: Add Form Fields
Use scripts/add_form_fields.py...

### Step 3: Configure Field Properties
Set validation rules...

### Step 4: Test Form Functionality
Validate all fields work correctly...
```

### Guidelines + Examples

**Structure:** Present guidelines/standards, heavily illustrated with examples.

**Example:** Coding standards skill with:

```markdown
## Code Style Guidelines
[Reference/Guidelines pattern]

## Common Patterns
[Examples pattern showing good implementations]

## Review Checklist
[Validation pattern]
```

### Capabilities + Workflows

**Structure:** Describe capabilities individually, then show how they combine in common workflows.

**Example:** See Product Management example above.

---

## Choosing the Right Pattern

Use this decision guide:

```
Start here: What's the primary nature of your skill?

┌─────────────────────────────────────────┐
│ Are tasks sequential with dependencies? │
└──────────────┬──────────────────────────┘
               │
         Yes ──┼── No
               │         │
               ▼         ▼
       ┌───────────┐  Are operations independent?
       │ WORKFLOW  │
       └───────────┘  Yes ──┬── No
                             │         │
                             ▼         ▼
                      ┌──────────┐  Do features integrate as a system?
                      │   TASK   │
                      └──────────┘  Yes ──┬── No
                                           │         │
                                           ▼         ▼
                                   ┌──────────────┐  Is it primarily standards?
                                   │ CAPABILITIES │
                                   └──────────────┘  Yes ──┬── No
                                                            │
                                                            ▼
                                                    ┌────────────┐
                                                    │ GUIDELINES │
                                                    └────────────┘
```

### Pattern Selection Criteria

| Pattern | Best For | Avoid If |
|---------|----------|----------|
| **Workflow** | Sequential processes, decision trees, validation between steps | Tasks are independent, no clear ordering |
| **Task** | Independent operations, tool collections, reference guide | Strong dependencies between operations |
| **Guidelines** | Standards, specifications, compliance rules | Primarily executable tasks rather than rules |
| **Capabilities** | Integrated systems, interrelated features | Features are truly independent |

### When in Doubt

- **Start with Task-Based** - It's the most flexible and can incorporate workflow sections as needed
- **Add workflows** where complex operations need step-by-step guidance
- **Include guidelines** section if standards or rules apply
- **Describe integration** if capabilities work together

Remember: Patterns are tools, not rules. Mix and adapt them to serve your skill's specific needs.

---

## Advanced Techniques

### Using Subagents for Verification

For capabilities-based skills with complex verification needs, consider using subagents (separate Claude instances) to verify work.

**When subagents help:**
- Quality-critical outputs requiring independent review
- Multi-step workflows where errors compound
- Tasks requiring both generation and evaluation
- Situations where "author blindness" is a risk

**Pattern: Write + Review**
```markdown
## Complex Analysis Workflow

1. **Primary agent**: Generate the analysis
2. **Review agent**: Verify findings independently
   - Use /clear or separate session
   - Review without seeing generation reasoning
   - Flag discrepancies or concerns
3. **Resolution**: Address flagged issues

This separation catches errors that single-pass review might miss.
```

**When NOT to use subagents:**
- Simple, deterministic tasks
- Tasks with clear right/wrong answers
- When speed is more important than exhaustive verification
- Low-stakes outputs

### Compaction Strategies for Long Workflows

Workflow-based skills with many steps can exceed optimal context length. Use these compaction strategies:

**1. Summarize completed steps**

Instead of keeping full output from every step:
```markdown
## Progress Summary (auto-updated)

Completed:
- Step 1: Analyzed 5 documents, found 12 themes
- Step 2: Cross-referenced claims, 3 conflicts identified
- Step 3: Draft summary created (1200 words)

Current: Step 4 - Verification

Key decisions made:
- Using chronological organization (decided Step 2)
- Excluding outlier study (decided Step 1)
```

**2. Preserve high-value context, discard low-value**

What to keep:
- Architectural decisions and their rationale
- Unresolved issues or blockers
- Key findings that affect later steps
- User preferences expressed

What to discard:
- Redundant tool outputs
- Exploratory dead-ends
- Verbose intermediate results
- Repeated instructions

**3. Checkpoint pattern**

For very long workflows, create explicit checkpoints:

```markdown
## Checkpoint: After Step 3

State:
- Input files: report1.pdf, report2.pdf, report3.pdf
- Extracted themes: [list]
- Conflicts identified: [list]
- Draft location: output/draft_v1.md

Resume instructions:
If continuing from this checkpoint, start at Step 4.
Previous context not needed beyond this summary.
```

**4. Reference external state**

Instead of keeping everything in context:
```markdown
Progress tracked in: progress.json
Decisions logged in: decisions.md
Draft saved at: output/draft.md

Read these files only when needed for current step.
```

This offloads state management to files, keeping context lean.
