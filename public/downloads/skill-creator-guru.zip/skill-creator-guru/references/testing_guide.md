# Skill Testing Guide - Comprehensive Testing Framework

This guide provides a systematic approach to testing skills before and after deployment, ensuring quality and effectiveness.

## Contents

- [Testing Philosophy](#testing-philosophy)
- [Pre-Upload Testing](#pre-upload-testing)
- [Post-Upload Testing](#post-upload-testing)
- [Creating Test Scenarios](#creating-test-scenarios)
- [Automated Testing](#automated-testing)
- [Gathering Feedback](#gathering-feedback)
- [Troubleshooting Common Issues](#troubleshooting-common-issues)

---

## Testing Philosophy

### Why Test Skills?

Skills are different from traditional software:
- **Usage is unpredictable** - Users phrase requests differently
- **Context matters** - Same request, different contexts may need different approaches
- **Claude interprets** - Instructions must be clear enough for AI comprehension
- **Iteration is key** - First version rarely perfect

### Testing Goals

1. **Accuracy** - Does the skill do what it's supposed to?
2. **Clarity** - Does Claude understand the instructions?
3. **Completeness** - Are all necessary pieces present?
4. **Efficiency** - Is the skill optimized for token usage?
5. **Usability** - Can users easily trigger and use it?

### Test-Driven Skill Development

**Recommended workflow:**

```
1. Write test scenarios FIRST (3-5 concrete examples)
   ↓
2. Create minimal skill to handle those scenarios
   ↓
3. Run tests, observe failures
   ↓
4. Add only what's needed to fix observed failures
   ↓
5. Re-test until passing
   ↓
6. Add new test scenario if needed
   ↓
7. Repeat from step 3
```

This prevents over-engineering and keeps skills focused.

**TDD Workflow in Detail:**

| Step | Action | Why |
|------|--------|-----|
| 1. Define expectations | Write test scenarios with expected inputs/outputs | Provides concrete targets |
| 2. Verify failure | Minimal skill should NOT pass all tests yet | Confirms tests are meaningful |
| 3. Commit tests | Checkpoint your expectations | Creates baseline |
| 4. Implement iteratively | Add instructions until tests pass (2-3 cycles typical) | Focused improvement |
| 5. Independent review | Use separate Claude instance to verify | Fresh perspective catches issues |
| 6. Commit skill | Finalize working implementation | Ready for deployment |

**Key insight:** Claude performs best with concrete targets. Tests provide measurable success criteria enabling rapid iteration.

---

## Pre-Upload Testing

Testing before uploading to Claude catches issues early.

### Test 1: YAML Frontmatter Validation

**What to test:** Frontmatter format and content

**How to test:**
```bash
# Use the validation script
python scripts/quick_validate.py path/to/skill/
```

**Manual checks:**
- [ ] Frontmatter starts with `---` and ends with `---`
- [ ] `name:` field present and hyphen-case
- [ ] `description:` field present and informative
- [ ] Description includes "when to use" guidance
- [ ] Description uses third-person voice
- [ ] No angle brackets (`<`, `>`) in description
- [ ] No TODO markers in description

### Test 2: File Reference Validation

**What to test:** All referenced files actually exist

**How to test:**

```bash
# Search SKILL.md for file references
grep -o 'scripts/[^` ]*' SKILL.md
grep -o 'references/[^` ]*' SKILL.md
grep -o 'assets/[^` ]*' SKILL.md

# Verify each file exists
ls scripts/mentioned_file.py    # Should succeed
ls references/mentioned_doc.md  # Should succeed
ls assets/mentioned_asset.png   # Should succeed
```

**Checklist:**
- [ ] All scripts/ references point to existing files
- [ ] All references/ mentions point to existing files
- [ ] All assets/ mentions point to existing files
- [ ] No broken links to non-existent files

### Test 3: Completeness Check

**What to test:** Skill is finished, not a draft

**How to test:**

```bash
# Search for TODO markers
grep -i "TODO" SKILL.md
grep -i "\[TODO\]" SKILL.md

# Search for placeholder text
grep -i "PLACEHOLDER" SKILL.md
grep -i "EXAMPLE" SKILL.md | grep -i "TODO"
```

**Checklist:**
- [ ] Zero TODO markers found
- [ ] No placeholder text remaining
- [ ] All example files customized or removed
- [ ] All template sections filled in

### Test 4: Code Example Validation

**What to test:** Code examples are correct and runnable

**How to test:**

1. Extract each code example from SKILL.md
2. Save to a test file
3. Run the code/command
4. Verify it works as documented

**Example:**

If SKILL.md contains:
```bash
python scripts/merge_pdfs.py file1.pdf file2.pdf --output merged.pdf
```

Test:
```bash
# Create test PDFs
echo "test" > test1.txt && echo "test" > test2.txt

# Try the actual command
python scripts/merge_pdfs.py test1.pdf test2.pdf --output merged.pdf

# Did it work? Check result
ls merged.pdf  # Should exist
```

**Checklist:**
- [ ] All bash commands tested and work
- [ ] All Python examples tested and work
- [ ] All file paths are correct
- [ ] All dependencies are available
- [ ] Examples produce expected output

### Test 5: Length and Token Budget

**What to test:** SKILL.md isn't too long

**How to test:**

```bash
# Word count
wc -w SKILL.md

# Should be under 5000 words
# If over 4000, consider moving content to references/
```

**Token estimate:**
- 5000 words ≈ 3,750 tokens
- 1000 words ≈ 750 tokens

**Checklist:**
- [ ] SKILL.md under 5000 words (preferred <3000)
- [ ] Detailed content moved to references/
- [ ] No unnecessary verbosity
- [ ] Concise without sacrificing clarity

### Test 6: Cross-Platform Compatibility

**What to test:** Skill works on Windows, Mac, and Linux

**How to test:**

```bash
# Search for Windows-specific paths
grep -E '[A-Z]:\\|\\\\[A-Za-z]' SKILL.md

# Should return nothing
```

**Checklist:**
- [ ] No Windows-style paths (C:\, \\server\)
- [ ] Use forward slashes for paths
- [ ] Scripts use cross-platform libraries
- [ ] No OS-specific commands without alternatives

---

## Post-Upload Testing

After uploading skill to Claude, test actual usage.

### Test 1: Trigger Accuracy

**What to test:** Skill triggers when it should, doesn't when it shouldn't

**How to test:**

Create variations of requests that should trigger:

**Example for PDF skill:**

Test these phrases:
- "I need to merge these PDFs" ✅ Should trigger
- "How do I combine multiple PDF files?" ✅ Should trigger
- "Extract text from this PDF document" ✅ Should trigger
- "I have a PDF form to fill out" ✅ Should trigger
- "Convert this Word doc to PDF" ❌ Should NOT trigger (different skill)
- "Merge these images" ❌ Should NOT trigger (not PDFs)

**Record results:**

| Phrase | Should Trigger? | Actually Triggered? | Pass/Fail |
|--------|----------------|---------------------|-----------|
| "merge these PDFs" | Yes | Yes | ✅ Pass |
| "combine PDF files" | Yes | Yes | ✅ Pass |
| "merge images" | No | No | ✅ Pass |
| "PDF form fillout" | Yes | No | ❌ Fail |

If failures occur, improve description to include missing keywords/scenarios.

### Test 2: Instruction Comprehension

**What to test:** Claude understands and follows instructions correctly

**How to test:**

For each major section of SKILL.md:

1. Ask Claude to perform that task
2. Observe what Claude does
3. Check if Claude followed the instructions

**Observation checklist:**
- [ ] Did Claude use the correct script?
- [ ] Did Claude pass correct parameters?
- [ ] Did Claude follow the specified order?
- [ ] Did Claude include validation steps?
- [ ] Did Claude handle errors gracefully?

**Example test:**

SKILL.md says:
```markdown
## Merge PDFs

Run: python scripts/merge_pdfs.py file1.pdf file2.pdf --output merged.pdf

Files are merged in the order specified.
```

User request: "Merge doc1.pdf and doc2.pdf"

Expected Claude behavior:
```bash
python scripts/merge_pdfs.py doc1.pdf doc2.pdf --output merged.pdf
```

✅ If Claude runs exactly this → Pass
❌ If Claude runs something different → Review why, improve instructions

### Test 3: Edge Case Handling

**What to test:** Skill handles unusual situations

**How to test:**

Create edge case scenarios:

**Size edges:**
- Very large files (500 pages)
- Very small files (1 page)
- Empty files
- Many files at once (100+)

**Content edges:**
- Corrupted files
- Password-protected files
- Scanned vs. digital PDFs
- Non-English text

**Usage edges:**
- Missing required parameters
- Invalid parameters
- Files don't exist
- Permission denied

**Example test script:**

```bash
# Test with missing file
python scripts/merge_pdfs.py nonexistent.pdf --output merged.pdf
# Expected: Clear error message "File not found: nonexistent.pdf"

# Test with corrupted PDF
python scripts/merge_pdfs.py corrupted.pdf --output merged.pdf
# Expected: Error message suggesting repair or different file

# Test with too many files
python scripts/merge_pdfs.py $(ls *.pdf) --output merged.pdf
# Expected: Warning if excessive, or batch processing suggestion
```

### Test 4: Multi-Turn Conversation

**What to test:** Skill works in context of longer conversation

**How to test:**

Simulate a realistic conversation:

```
User: "I'm working on a report"
Claude: [General response]

User: "I need to combine the executive summary, main report, and appendix PDFs"
Claude: [Should trigger PDF skill]

User: "Actually, put the appendix first"
Claude: [Should understand context, adjust order]

User: "Thanks! Now extract just the charts from the main report"
Claude: [Should still be in PDF skill context]
```

**Checklist:**
- [ ] Skill maintains context across turns
- [ ] Claude remembers earlier parts of task
- [ ] Skill doesn't interfere with unrelated parts of conversation

### Test 5: Error Recovery

**What to test:** Skill provides helpful guidance when things go wrong

**How to test:**

Deliberately cause errors:

```bash
# Wrong file type
python scripts/merge_pdfs.py image.jpg --output merged.pdf

# Missing dependency
# (temporarily rename a required library)

# Insufficient permissions
chmod 000 input.pdf
python scripts/merge_pdfs.py input.pdf --output merged.pdf
```

**Good error messages:**
- ✅ "Error: image.jpg is not a PDF file. This script requires PDF format."
- ✅ "Missing dependency: PyPDF2. Install with: pip install PyPDF2"
- ✅ "Permission denied reading input.pdf. Check file permissions."

**Bad error messages:**
- ❌ "Error"
- ❌ "Exception in line 42"
- ❌ [Cryptic stack trace]

---

## Creating Test Scenarios

Test scenarios should be concrete, realistic, and cover the expected usage.

### Scenario Template

```markdown
## Test Scenario: [Descriptive Name]

**Purpose:** [What this tests]

**Setup:**
- [Required files/data]
- [Pre-conditions]

**Input:**
- [User request/command]
- [Files provided]

**Expected Output:**
- [What should happen]
- [Files created]
- [Messages shown]

**Actual Output:**
[Fill in during testing]

**Status:** ✅ Pass / ⚠️  Partial / ❌ Fail

**Notes:**
[Any observations, issues, or improvements needed]
```

### Example: PDF Merge Test

```markdown
## Test Scenario: Basic PDF Merge

**Purpose:** Verify basic merge functionality works correctly

**Setup:**
- Create 3 test PDFs:
  - doc1.pdf (5 pages)
  - doc2.pdf (10 pages)
  - doc3.pdf (3 pages)

**Input:**
User request: "Merge doc1.pdf, doc2.pdf, and doc3.pdf"

**Expected Output:**
- Command: `python scripts/merge_pdfs.py doc1.pdf doc2.pdf doc3.pdf --output merged.pdf`
- File created: merged.pdf (18 pages total)
- Page order: doc1 content, then doc2, then doc3
- Message: "Successfully merged 3 PDFs into merged.pdf"

**Actual Output:**
✅ All expectations met
- merged.pdf created with 18 pages
- Page order correct
- Clear success message

**Status:** ✅ Pass

**Notes:** Works perfectly for basic case
```

### Test Suite Structure

Organize tests by priority:

**Priority 1: Core Functionality (Must Pass)**
- Basic happy path scenarios
- Most common use cases
- Essential features

**Priority 2: Common Variations (Should Pass)**
- Different parameter combinations
- Typical edge cases
- Moderate complexity scenarios

**Priority 3: Edge Cases (Nice to Pass)**
- Unusual situations
- Error conditions
- Extreme values

### Sample Test Suite: PDF Skill

```markdown
# PDF Skill Test Suite

## Priority 1: Core Functionality

### Test 1.1: Merge Two PDFs
[Basic merge test as shown above]

### Test 1.2: Extract Text from PDF
**Input:** PDF with searchable text
**Expected:** Text file with all content
**Status:** ✅ Pass

### Test 1.3: Fill Simple Form
**Input:** PDF form template + JSON data
**Expected:** Filled PDF with all fields populated
**Status:** ✅ Pass

## Priority 2: Common Variations

### Test 2.1: Merge Many PDFs (10+)
**Expected:** Performance warning if slow, but completes
**Status:** ⚠️  Partial - works but no performance warning

### Test 2.2: Extract from Scanned PDF
**Expected:** OCR warning, best-effort text extraction
**Status:** ✅ Pass

## Priority 3: Edge Cases

### Test 3.1: Merge with Corrupted PDF
**Expected:** Clear error, suggest repair
**Status:** ❌ Fail - cryptic error message
**Action:** Improve error handling

### Test 3.2: Form with Missing Fields
**Expected:** Partial fill, list missing fields
**Status:** ✅ Pass
```

---

## Automated Testing

For skills with scripts, create automated tests.

### Python Script Tests

```python
# tests/test_merge_pdfs.py
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / 'scripts'))

from merge_pdfs import merge_pdfs

class TestMergePDFs(unittest.TestCase):
    def setUp(self):
        """Create test fixtures"""
        self.test_dir = Path('tests/fixtures')
        self.test_dir.mkdir(exist_ok=True)

    def test_basic_merge(self):
        """Test merging two PDFs"""
        output = self.test_dir / 'merged.pdf'

        result = merge_pdfs(
            ['tests/fixtures/doc1.pdf', 'tests/fixtures/doc2.pdf'],
            output
        )

        self.assertTrue(output.exists())
        self.assertEqual(result.page_count, 15)  # 5 + 10 pages

    def test_nonexistent_file(self):
        """Test error handling for missing file"""
        with self.assertRaises(FileNotFoundError):
            merge_pdfs(['nonexistent.pdf'], 'output.pdf')

    def tearDown(self):
        """Clean up test files"""
        if self.test_dir.exists():
            for file in self.test_dir.glob('*'):
                file.unlink()

if __name__ == '__main__':
    unittest.main()
```

### Running Automated Tests

```bash
# Run all tests
python -m pytest tests/

# Run with coverage
python -m pytest --cov=scripts tests/

# Run specific test
python -m pytest tests/test_merge_pdfs.py::TestMergePDFs::test_basic_merge
```

---

## Gathering Feedback

User feedback is the most valuable testing data.

### Feedback Collection Methods

**1. Direct observation:**
Watch someone use the skill for the first time.

Observe:
- Where do they get confused?
- What questions do they ask?
- What do they try that doesn't work?
- What works well?

**2. Survey questions:**

```
Skill Feedback Survey:

1. How easy was it to use this skill? (1-5)
2. Did the skill do what you expected? (Yes/No)
   - If no, what was different?
3. What was confusing or unclear?
4. What worked well?
5. What features are missing?
6. Would you use this skill again? (Yes/No)
```

**3. Usage analytics:**

If possible, track:
- How often skill is triggered
- Which features are used most
- Where errors occur most
- Completion rate of tasks

### Feedback Log Template

```markdown
# Skill Feedback Log

## Feedback Entry: 2024-11-15

**User:** Jane D.
**Task:** Merge quarterly reports
**Outcome:** ✅ Success

**What went well:**
- Found the skill quickly
- Merge command worked perfectly
- Output was exactly what needed

**Issues encountered:**
- Initially tried "combine" instead of "merge" - didn't trigger skill
- Unclear if page order mattered

**Suggested improvements:**
- Add "combine" as trigger word in description
- Clarify that files are merged in order specified

**Action items:**
- [ ] Update description to include "combine"
- [ ] Add note about order in merge section

---

## Feedback Entry: 2024-11-14

**User:** John S.
**Task:** Extract text from scanned PDF
**Outcome:** ⚠️  Partial success

**What went well:**
- Script ran successfully
- Output file created

**Issues encountered:**
- Extracted text was poor quality (OCR issue)
- No warning that OCR might be imperfect
- Wasn't clear why text was garbled

**Suggested improvements:**
- Add warning when PDF appears to be scanned
- Suggest alternatives (better OCR tools, manual review)
- Set expectations about OCR accuracy

**Action items:**
- [ ] Add OCR detection and warning
- [ ] Add references/ocr_guide.md with alternatives
- [ ] Update extract_text script to check if PDF is scanned
```

---

## Troubleshooting Common Issues

### Issue: Skill Doesn't Trigger

**Symptoms:**
- User request should trigger skill, but doesn't
- Skill rarely gets used

**Diagnosis:**
```bash
# Check description
grep "description:" SKILL.md

# Is it specific enough?
# Does it mention keywords users would actually use?
```

**Fixes:**
1. Add more trigger keywords to description
2. Include specific file types or task names
3. Test with varied phrasings

**Example fix:**

Before:
```yaml
description: Document manipulation tool
```

After:
```yaml
description: Processes PDF files: extracts text, merges documents, splits pages, and fills forms. This skill should be used when working with PDF documents for merging, splitting, text extraction, or form filling tasks.
```

### Issue: Claude Misinterprets Instructions

**Symptoms:**
- Claude uses wrong script
- Claude skips important steps
- Claude adds unnecessary steps

**Diagnosis:**
- Review thinking/reasoning (if visible)
- Test with explicit instructions vs. implicit

**Fixes:**
1. Make instructions more explicit
2. Add examples of correct usage
3. Clarify ambiguous terms
4. Add "Do not..." for common mistakes

### Issue: Scripts Fail in Practice

**Symptoms:**
- Scripts work in testing but fail for users
- Environment-specific errors
- Missing dependencies

**Diagnosis:**
```bash
# Test in clean environment
python -m venv clean_env
source clean_env/bin/activate
pip install [only specified dependencies]
python scripts/your_script.py
```

**Fixes:**
1. Document all dependencies explicitly
2. Add dependency checking to scripts
3. Provide clear error messages
4. Add installation instructions

### Issue: Skill is Too Slow

**Symptoms:**
- Skill takes long time to load
- Claude response is slow when skill is active

**Diagnosis:**
```bash
# Check SKILL.md size
wc -w SKILL.md

# Over 5000 words?
```

**Fixes:**
1. Move detailed content to references/
2. Consolidate duplicate information
3. Use pointers instead of full explanations
4. Simplify language without losing clarity

---

## Multi-Claude Quality Assurance

For critical skills, use separate Claude instances for writing and review. This separation produces better results than single-instance handling.

### Why Multi-Claude Works

- **Fresh context**: Second instance catches issues the original author missed
- **No accumulated bias**: Reviewer has no preconceptions about the skill
- **Independent verification**: Confirms skill works for someone unfamiliar with development history

### Multi-Claude QA Workflow

```
1. Claude A: Writes the skill
   ↓
2. Run /clear OR start Claude B in separate terminal
   ↓
3. Claude B: Reviews skill for issues, gaps, clarity
   ↓
4. Claude C (or /clear again): Reads both skill and feedback
   ↓
5. Claude C: Makes improvements based on feedback
```

### Review Prompts for Claude B

Use these prompts when asking a fresh Claude to review:

**Trigger accuracy review:**
```
Review this skill's description and tell me:
1. What scenarios would trigger this skill?
2. What scenarios SHOULD trigger it but might not?
3. Are there any ambiguous trigger conditions?
```

**Instruction clarity review:**
```
Read this skill as if you're seeing it for the first time.
1. Are any instructions unclear or ambiguous?
2. What questions would you have about how to use it?
3. What's missing that you'd need to execute these workflows?
```

**Completeness review:**
```
Analyze this skill for gaps:
1. Are all referenced files present?
2. Are there workflows mentioned but not explained?
3. What edge cases aren't covered?
```

### When to Use Multi-Claude QA

- Skills used by multiple team members
- Skills with safety implications
- Complex workflow skills (3+ decision points)
- Skills that will be published or shared externally

---

## Context Management During Testing

Long testing sessions accumulate context that can degrade performance. Use these techniques to maintain quality.

### Using /clear Strategically

The `/clear` command resets Claude's context. Use it:

- **Between test rounds** - Start fresh for each major test scenario
- **After debugging sessions** - Clear accumulated error context
- **When Claude seems confused** - Context overload may cause inconsistent behavior
- **Before final validation** - Ensure skill works without accumulated context

**Pattern for comprehensive testing:**
```
1. Run test scenario A
2. /clear
3. Run test scenario B (no context from A)
4. /clear
5. Run combined scenario A+B (tests interaction)
```

### Checklist-Based Testing

For complex skill testing, use markdown checklists to maintain state across /clear commands:

```markdown
## Testing Checklist for [Skill Name]

Date: [Date]
Version: [Version]

### Core Functionality
- [ ] Trigger test 1: "merge these PDFs" → Passed
- [ ] Trigger test 2: "combine documents" → Passed
- [ ] Script execution: merge_pdfs.py → Passed
- [ ] Error handling: missing file → Passed

### Edge Cases
- [ ] Large file (100+ pages) → [Status]
- [ ] Empty file → [Status]
- [ ] Corrupted file → [Status]

### Multi-Turn
- [ ] Context maintained across 3 turns → [Status]
- [ ] No interference with unrelated requests → [Status]
```

**Benefits of checklists:**
- Resume testing after /clear or session break
- Track what's been tested across multiple sessions
- Share progress with team members
- Create reproducible test records

### When to Clear vs. Continue

| Situation | Action |
|-----------|--------|
| Testing independent scenarios | /clear between each |
| Testing multi-turn conversation | Continue without clear |
| Debugging specific issue | Continue until resolved, then /clear |
| Performance seems degraded | /clear and retry |
| Testing real user flow | Continue (simulates actual use) |

---

## Course Correction During Development

When developing skills iteratively, use these techniques to adjust direction.

### Interrupt and Redirect

**Escape key** - Press Escape to interrupt Claude mid-response:
- Use when Claude is heading in wrong direction
- Saves time and tokens
- Allows immediate course correction

**Double Escape** - Press Escape twice to rewind:
- Cancels current response
- Returns to previous state
- Useful for trying alternative approaches

### Asking to Undo

When Claude has made changes that need reverting:

```
"Undo the last change to SKILL.md"
"Revert the modifications to the merge script"
"Go back to the previous version of the description"
```

**Best practice:** Commit/save frequently during skill development so you have restore points.

### Iteration Patterns

**Small iterations:**
```
1. Make one change
2. Test immediately
3. If works → commit
4. If fails → undo, try different approach
```

**Exploratory development:**
```
1. Ask Claude to propose 2-3 approaches
2. Evaluate each without implementing
3. Select best approach
4. Implement in small steps
```

**Red-Green iteration:**
```
1. Write test that should pass
2. Verify it currently fails
3. Make minimal change to pass
4. Verify it now passes
5. Refactor if needed
```

---

## Testing Checklist

Use this checklist before publishing a skill:

### Pre-Upload
- [ ] YAML frontmatter validated
- [ ] All file references verified to exist
- [ ] No TODO markers remaining
- [ ] Code examples tested and working
- [ ] SKILL.md under 5000 words
- [ ] Cross-platform compatible

### Post-Upload
- [ ] Triggers correctly for intended scenarios
- [ ] Doesn't trigger for unrelated scenarios
- [ ] Instructions followed correctly
- [ ] Edge cases handled gracefully
- [ ] Error messages are helpful
- [ ] Works in multi-turn conversations

### User Testing
- [ ] At least 3 users tested the skill
- [ ] Feedback collected and reviewed
- [ ] Common issues identified
- [ ] Improvements prioritized
- [ ] Documentation updated based on feedback

### Maintenance
- [ ] Test scenarios documented
- [ ] Automated tests created (for scripts)
- [ ] Feedback log established
- [ ] Version number assigned
- [ ] Changelog maintained

**Remember:** Testing is ongoing. Skills improve through iteration based on real usage.
