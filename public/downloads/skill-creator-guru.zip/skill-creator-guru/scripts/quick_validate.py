#!/usr/bin/env python3
"""
Enhanced validation script for skills - technical and qualitative checks
"""

import sys
import os
import re
from pathlib import Path

def validate_skill(skill_path):
    """Comprehensive validation of a skill with technical and qualitative checks"""
    skill_path = Path(skill_path)
    warnings = []

    # Check SKILL.md exists
    skill_md = skill_path / 'SKILL.md'
    if not skill_md.exists():
        return False, "❌ SKILL.md not found"

    # Read and validate frontmatter
    content = skill_md.read_text(encoding='utf-8')
    if not content.startswith('---'):
        return False, "❌ No YAML frontmatter found"

    # Extract frontmatter
    match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
    if not match:
        return False, "❌ Invalid frontmatter format"

    frontmatter = match.group(1)
    body = content[match.end():]

    # Check required fields
    if 'name:' not in frontmatter:
        return False, "❌ Missing 'name' in frontmatter"
    if 'description:' not in frontmatter:
        return False, "❌ Missing 'description' in frontmatter"

    # Extract name for validation
    name_match = re.search(r'name:\s*(.+)', frontmatter)
    if name_match:
        name = name_match.group(1).strip()

        # OFFICIAL REQUIREMENTS (from platform.claude.com docs)
        # Max 64 characters
        if len(name) > 64:
            return False, f"❌ Name exceeds 64 characters ({len(name)} chars). Official limit is 64."

        # No XML tags
        if '<' in name or '>' in name:
            return False, "❌ Name cannot contain XML tags (< or >)"

        # No reserved words
        reserved_words = ['anthropic', 'claude']
        if any(word in name.lower() for word in reserved_words):
            return False, f"❌ Name contains reserved word ('anthropic' or 'claude' not allowed)"

        # Check naming convention (hyphen-case: lowercase with hyphens)
        if not re.match(r'^[a-z0-9-]+$', name):
            return False, f"❌ Name '{name}' should be hyphen-case (lowercase letters, digits, and hyphens only)"
        if name.startswith('-') or name.endswith('-') or '--' in name:
            return False, f"❌ Name '{name}' cannot start/end with hyphen or contain consecutive hyphens"
        if len(name) > 40:
            warnings.append(f"⚠️  Name '{name}' is quite long ({len(name)} chars). Consider shorter name.")

    # Extract and validate description
    desc_match = re.search(r'description:\s*(.+)', frontmatter)
    if desc_match:
        description = desc_match.group(1).strip()

        # OFFICIAL REQUIREMENTS (from platform.claude.com docs)
        # Max 1024 characters
        if len(description) > 1024:
            return False, f"❌ Description exceeds 1024 characters ({len(description)} chars). Official limit is 1024."

        # Check for angle brackets (XML tags not allowed)
        if '<' in description or '>' in description:
            return False, "❌ Description cannot contain XML tags (< or >)"

        # Check for [TODO markers
        if '[TODO' in description or 'TODO:' in description:
            return False, "❌ Description contains TODO markers - please complete it"

        # Check description length
        if len(description) < 30:
            warnings.append(f"⚠️  Description is quite short ({len(description)} chars). Consider adding more detail about when to use this skill.")

        # Check if description includes "when to use" guidance
        when_keywords = ['when', 'use this skill', 'should be used']
        has_when = any(keyword in description.lower() for keyword in when_keywords)
        if not has_when:
            warnings.append("⚠️  Description should include 'when to use' guidance (e.g., 'This skill should be used when...')")

        # Check for vague terms
        vague_terms = ['helps with', 'utility', 'tool for', 'helper']
        if any(term in description.lower() for term in vague_terms):
            warnings.append(f"⚠️  Description contains vague terms. Be more specific about what the skill does.")

        # Check for second person
        if description.lower().startswith('use this') or 'you should' in description.lower():
            warnings.append("⚠️  Description should use third-person (e.g., 'This skill should be used...' not 'Use this skill...')")

    # QUALITATIVE CHECKS

    # Check SKILL.md length (token budget)
    word_count = len(body.split())
    if word_count > 5000:
        warnings.append(f"⚠️  SKILL.md is quite long ({word_count} words). Consider moving detailed content to references/ files.")
    elif word_count > 4000:
        warnings.append(f"⚠️  SKILL.md is approaching the 5k word recommendation ({word_count} words).")

    # Check for Windows-style paths (cross-platform compatibility)
    windows_path_pattern = r'[A-Z]:\\|\\\\[A-Za-z]'
    if re.search(windows_path_pattern, content):
        warnings.append("⚠️  Found Windows-style paths (C:\\ or \\\\). Use forward slashes for cross-platform compatibility.")

    # Check for time-sensitive information
    time_sensitive = re.search(r'\bin\s+202\d\b|\blatest\b|\bnewest\b|\bcurrent\s+version\b', content, re.IGNORECASE)
    if time_sensitive:
        warnings.append("⚠️  Found potentially time-sensitive information. Consider making it timeless or pointing to authoritative source.")

    # Check for TODO markers in body
    todo_count = len(re.findall(r'\[TODO|\bTODO:', content))
    if todo_count > 0:
        warnings.append(f"⚠️  Found {todo_count} TODO marker(s) in SKILL.md. Complete these before finalizing.")

    # Check if references/ is mentioned but doesn't exist
    if 'references/' in content:
        refs_dir = skill_path / 'references'
        if not refs_dir.exists() or not any(refs_dir.iterdir()):
            warnings.append("⚠️  SKILL.md mentions references/ but directory is empty or doesn't exist.")

    # Check if scripts/ is mentioned but doesn't exist
    if 'scripts/' in content or '`scripts/' in content:
        scripts_dir = skill_path / 'scripts'
        if not scripts_dir.exists() or not any(scripts_dir.iterdir()):
            warnings.append("⚠️  SKILL.md mentions scripts/ but directory is empty or doesn't exist.")

    # Check if assets/ is mentioned but doesn't exist
    if 'assets/' in content:
        assets_dir = skill_path / 'assets'
        if not assets_dir.exists() or not any(assets_dir.iterdir()):
            warnings.append("⚠️  SKILL.md mentions assets/ but directory is empty or doesn't exist.")

    # Build final message
    if warnings:
        warning_msg = "\n".join(warnings)
        return True, f"✅ Skill passed technical validation!\n\n{warning_msg}\n\nConsider addressing warnings for higher quality."

    return True, "✅ Skill is valid! All technical and qualitative checks passed."

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python quick_validate.py <skill_directory>")
        sys.exit(1)
    
    valid, message = validate_skill(sys.argv[1])
    print(message)
    sys.exit(0 if valid else 1)