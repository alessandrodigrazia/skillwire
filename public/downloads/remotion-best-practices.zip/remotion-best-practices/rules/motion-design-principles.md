---
name: motion-design-principles
description: Core creative motion design principles - spring strategy, easing, stagger, breathing, micro-animation patterns
metadata:
  tags: motion-design, spring, easing, stagger, breathing, creative, overshoot, z-index
---

These principles define **how** and **why** to animate, not just which API to call.
See [timing.md](timing.md) for spring/interpolate API basics. This file covers **creative strategy**.

---

## 1. No Linear Animations — Ever

Linear motion looks robotic. Every animation must have easing — spring or bezier.
This is not a suggestion, it's the single most important rule for professional output.

```tsx
// WRONG — linear feels mechanical
const opacity = interpolate(frame, [0, 30], [0, 1]);

// RIGHT — spring feels natural
const progress = spring({ frame, fps, config: { damping: 14, mass: 0.6, stiffness: 120 } });
const opacity = progress;

// RIGHT — bezier easing for precise control
import { Easing } from "remotion";
const opacity = interpolate(frame, [0, 30], [0, 1], {
  easing: Easing.bezier(0.25, 0.1, 0.25, 1),
  extrapolateRight: "clamp",
});
```

**When to use**: Always. No exceptions. Even subtle 5-frame micro-animations need easing.

---

## 2. Named Spring Presets Strategy

Choose ONE strategy per video: either a single spring config for consistency, or 3-5 named presets for variety.
Mixing unnamed ad-hoc configs across a video creates visual incoherence.

```tsx
// Strategia A: Config unica (stile corporate, data viz, educational)
const SPRING = { damping: 14, mass: 0.6, stiffness: 120 };

// Strategia B: Preset nominati (stile promo, brand, product demo)
const SPRINGS = {
  standard: { damping: 14, mass: 0.6, stiffness: 120 },  // General purpose
  bouncy:   { damping: 10, mass: 0.5, stiffness: 150 },  // Playful entries
  gentle:   { damping: 20, mass: 1,   stiffness: 60 },   // Soft transitions
  snappy:   { damping: 18, mass: 0.4, stiffness: 200 },  // Quick reactions
  impact:   { damping: 8,  mass: 0.5, stiffness: 180 },  // Dramatic reveals
} as const;

// Usage
const scale = spring({ frame, fps, config: SPRINGS.bouncy });
```

**When to use**: Strategia A for educational/corporate videos where consistency matters.
Strategia B for promos where different moments need different energy.
Never use unnamed inline configs like `{ damping: 12 }` scattered across components.

---

## 3. Dramatic Bezier Curves

Springs are great for physical motion. Bezier curves are better for **precise timing control** and **dramatic pacing**.

```tsx
import { Easing, interpolate } from "remotion";

// DRAMATIC — quasi-step con ease. Per transizioni drammatiche, data viz reveals
const DRAMATIC = Easing.bezier(0.9, 0, 0.1, 1);

// ELASTIC — overshoot fisico controllato. Valore 1.56 > 1.0 = bounce
const ELASTIC = Easing.bezier(0.34, 1.56, 0.64, 1);

// Usage: bolla che "poppa" con overshoot preciso
const scale = interpolate(frame, [0, 50], [0, 1], {
  easing: ELASTIC,
  extrapolateRight: "clamp",
});

// Usage: reveal drammatico con timing cinematografico
const progress = interpolate(frame, [0, 40], [0, 1], {
  easing: DRAMATIC,
  extrapolateRight: "clamp",
});
```

**When to use**: Bezier when you need frame-exact timing (data viz, synchronized events).
Spring when you want physics-based natural feel (UI elements, bouncing).
DRAMATIC for "slow-slow-FAST-slow" pacing. ELASTIC for pop-in with controlled overshoot.

---

## 4. Scale Overshoot for Drama

Elements that land at exactly 1x feel flat. Overshooting creates impact and energy.

```tsx
// Pattern A: Manual 3-step (massimo controllo, 5.4x → 1x)
const scale = interpolate(
  frame,
  [0, 3, 8],       // 3 frame velocissimi, poi settle in 5
  [5.4, 0.95, 1],  // Enorme → undershoot leggero → settle
  { extrapolateRight: "clamp", extrapolateLeft: "clamp" }
);

// Pattern B: Spring low-damping (bounce naturale)
const scale = spring({
  frame,
  fps,
  config: { damping: 8, mass: 0.5, stiffness: 180 }, // "impact" preset
});

// Pattern C: Click simulation (0.85 → 1.1 → 1 in 8 frame)
const clickScale = interpolate(
  frame - clickStartFrame,
  [0, 3, 8],
  [1, 0.85, 1],       // press down → release with slight overshoot
  { extrapolateRight: "clamp", extrapolateLeft: "clamp" }
);

// Pattern D: Elastic bezier — overshoot controllato senza oscillazione
const scale = interpolate(frame, [0, 20], [0, 1], {
  easing: Easing.bezier(0.34, 1.56, 0.64, 1),
  extrapolateRight: "clamp",
});
```

**When to use**: Pattern A for hero reveals (logo, brand name).
Pattern B for playful entries (icons, cards, stickers).
Pattern C for simulated clicks and button presses.
Pattern D when you want overshoot without oscillation (one-shot bounce).

---

## 5. Breathing Animation for Living Objects

Static objects feel dead. A subtle scale oscillation simulates "breathing" — the object is alive, active, important.

```tsx
// Base breathing — scala oscillante impercettibile
const breathe = Math.sin(frame * 0.08) * 4; // ±4px
const scale = 1 + Math.sin(frame * 0.05) * 0.02; // ±2% scale

// Breathing glow — pulsazione di un radial gradient
const glowOpacity = 0.5 + Math.sin(frame * 0.06) * 0.15;

// Combined breathing per un'icona "viva" (brain, heart, logo)
const MyLivingIcon: React.FC = () => {
  const frame = useCurrentFrame();
  const breatheScale = 1 + Math.sin(frame * 0.05) * 0.03;
  const breatheY = Math.sin(frame * 0.04) * 3;

  return (
    <div style={{
      transform: `scale(${breatheScale}) translateY(${breatheY}px)`,
    }}>
      <BrainIcon />
    </div>
  );
};
```

**When to use**: On hero elements that should feel "alive" (brain icon, logo, active indicators).
On backgrounds for subtle movement (glow pulsation, gradient breathing).
Never on text being read — it distracts. Never on multiple elements simultaneously — pick ONE focal point.

---

## 6. Stagger Patterns — The Rhythm of Sequential Entry

Stagger is the delay between sequential element entries. The gap defines the energy.

```tsx
// TIGHT stagger: 3-8 frame — rapid fire, energetico, promo style
const STAGGER_TIGHT = 5;

// STANDARD stagger: 8 frame — professionale, ordinato, liste
const STAGGER_STANDARD = 8;

// DRAMATIC stagger: 20 frame — deliberato, data viz, peso per elemento
const STAGGER_DRAMATIC = 20;

// Implementazione con array di elementi
const items = ["First", "Second", "Third", "Fourth"];

const StaggeredList: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <>
      {items.map((item, i) => {
        const delay = i * STAGGER_STANDARD; // 0, 8, 16, 24
        const progress = spring({
          frame: frame - delay,
          fps,
          config: { damping: 14, mass: 0.6, stiffness: 120 },
        });

        return (
          <div
            key={item}
            style={{
              opacity: progress,
              transform: `translateY(${interpolate(progress, [0, 1], [20, 0])}px)`,
            }}
          >
            {item}
          </div>
        );
      })}
    </>
  );
};
```

**When to use**: TIGHT (3-8f) for rapid intros, tag clouds, icon grids.
STANDARD (8f) for lists, cards, social media items — balanced and professional.
DRAMATIC (20f) for data visualization, hero elements — each item gets attention.

---

## 7. Growth vs Slide — Semantic Distinction

Width animation (growth) and translateX (slide) look different and **mean** different things.

```tsx
// GROWTH — "espansione". L'elemento si genera, cresce dal nulla
// Suggerisce: creazione, espansione, progressione
const barWidth = interpolate(progress, [0, 1], [0, 100]);
// <div style={{ width: `${barWidth}%` }} />

// SLIDE — "arrivo". L'elemento era altrove e arriva
// Suggerisce: movimento, provenienza, direzione
const translateX = interpolate(progress, [0, 1], [-200, 0]);
// <div style={{ transform: `translateX(${translateX}px)` }} />

// Esempio pratico: barra che cresce da dietro un'icona (social card pattern)
const BarGrowth: React.FC<{ progress: number; maxWidth: number }> = ({ progress, maxWidth }) => (
  <div style={{
    width: interpolate(progress, [0, 1], [0, maxWidth]),
    height: 90,
    borderRadius: 12,
    backgroundColor: "#5865F2",
    position: "absolute",
    left: 50,  // inizia da dietro l'icona
    zIndex: -1, // sotto l'icona
  }} />
);
```

**When to use**: Growth for bars, progress indicators, loading states, elements "materializing".
Slide for panels entering from sides, elements arriving from off-screen, navigation.
The choice is semantic — pick based on what the motion **communicates**, not what looks "cool".

---

## 8. Three-Phase Micro Animation

Complex components don't appear all at once. They "assemble" in overlapping phases.

```tsx
// Tre fasi con overlap — l'icona è ancora in bounce quando la barra inizia
const PHASE_CONFIG = {
  iconPop:  { start: 0,  dur: 15, spring: { damping: 8,  stiffness: 150, mass: 0.8 } },
  barSlide: { start: 10, dur: 20, spring: { damping: 15, stiffness: 100, mass: 1 } },
  textFade: { start: 20, dur: 20, spring: { damping: 20, stiffness: 120, mass: 1 } },
};

const ThreePhaseCard: React.FC<{ startFrame: number }> = ({ startFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const f = frame - startFrame;

  // Fase 1: Icon Pop
  const iconScale = spring({
    frame: Math.max(0, f - PHASE_CONFIG.iconPop.start),
    fps,
    config: PHASE_CONFIG.iconPop.spring,
  });

  // Fase 2: Bar Slide (inizia mentre icona è ancora in bounce)
  const barProgress = spring({
    frame: Math.max(0, f - PHASE_CONFIG.barSlide.start),
    fps,
    config: PHASE_CONFIG.barSlide.spring,
  });

  // Fase 3: Text Fade (inizia mentre barra si estende)
  const textProgress = spring({
    frame: Math.max(0, f - PHASE_CONFIG.textFade.start),
    fps,
    config: PHASE_CONFIG.textFade.spring,
  });

  return (
    <div>
      <div style={{ transform: `scale(${iconScale})` }}>🎯</div>
      <div style={{ width: `${barProgress * 100}%` }}>Bar</div>
      <div style={{ opacity: textProgress, transform: `translateY(${(1 - textProgress) * 10}px)` }}>
        Description text
      </div>
    </div>
  );
};
```

**When to use**: For any component with 2+ visual elements (cards, list items, data points).
The overlap between phases (fase 2 starts before fase 1 ends) eliminates "dead time" and creates flow.
Each phase uses a different spring config to communicate "weight": bouncy for pop, smooth for slide, gentle for text.

---

## 9. Reverse Exit = Mirror of Entry

When elements exit, they should reverse the entry animation. This creates narrative symmetry and completeness.

```tsx
const SymmetricCard: React.FC<{
  entryStart: number;
  exitStart: number;
  duration: number;
}> = ({ entryStart, exitStart, duration }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Entry: scale 0 → 1, opacity 0 → 1
  const entryProgress = spring({
    frame: Math.max(0, frame - entryStart),
    fps,
    config: { damping: 12, stiffness: 150 },
  });

  // Exit: scale 1 → 0, opacity 1 → 0 (reverse)
  const exitProgress = spring({
    frame: Math.max(0, frame - exitStart),
    fps,
    config: { damping: 15, stiffness: 100 },
  });

  // Combina: entry porta a 1, exit porta via da 1
  const isExiting = frame >= exitStart;
  const scale = isExiting ? 1 - exitProgress : entryProgress;
  const opacity = scale; // scala e opacity linkati

  return (
    <div style={{
      transform: `scale(${scale})`,
      opacity,
    }}>
      Content
    </div>
  );
};
```

**When to use**: Social cards, overlay components, any element that appears AND disappears.
The exit spring config can be slightly different (faster damping = exits feel "snappier" than entries).
For multi-element components, reverse the stagger order too (last in = first out).

---

## 10. Loop Effects — Nothing Should Be Truly Static

Backgrounds, decorative elements, and ambient effects should have subtle continuous animation.

```tsx
// Shimmer loop — luce che scorre su un bottone CTA
const shimmerX = interpolate(frame % 60, [0, 60], [-200, 200]);

// Floating animation — card che galleggia (sin-based)
const floatY = Math.sin(frame * 0.03) * 8;
const floatX = Math.cos(frame * 0.02) * 4;

// Rotating icon — freccia circolare per "loop/ciclo"
const rotation = (frame * 2) % 360;

// Pulsing rings — anelli sfasati che pulsano
const rings = [0, 1, 2].map((i) => {
  const pulsePhase = (frame + i * 10) % 30;
  const pulseScale = 1 + interpolate(pulsePhase, [0, 15, 30], [0, 0.15, 0], {
    extrapolateRight: "clamp",
  });
  return pulseScale;
});

// Floating particles su orbita circolare
const particleAngle = (frame * 0.02) + (index * Math.PI * 2 / particleCount);
const particleX = Math.cos(particleAngle) * radius;
const particleY = Math.sin(particleAngle) * radius;
```

**When to use**: Shimmer on CTA buttons (60-frame cycle). Floating on background cards.
Rotating on process/loop indicators. Pulsing on tech preview effects.
Keep amplitude LOW — these are ambient, not focal. If the user notices them consciously, they're too strong.

---

## 11. Z-Index as Narrative Tool

Z-index is not just layering — it communicates **importance**. Foreground = important, background = context.

```tsx
// Testo SOPRA l'highlight box (il testo è il contenuto, il box è decorazione)
<div style={{ position: "relative" }}>
  <div style={{ position: "absolute", zIndex: 1, backgroundColor: "#CCFF00" }}>
    {/* Highlight box */}
  </div>
  <span style={{ position: "relative", zIndex: 2 }}>
    Important Word
  </span>
</div>

// Video SOTTO la tipografia (il video è contesto, il testo è messaggio)
<AbsoluteFill>
  <Video src={backgroundClip} style={{ zIndex: 0 }} />
  <div style={{ zIndex: 1, fontSize: 120, fontWeight: 900 }}>
    HEADLINE TEXT
  </div>
</AbsoluteFill>

// 3D depth ordering — elementi più "vicini" hanno z-index più alto
const zPosition = Math.sin(angle); // -1 (lontano) a 1 (vicino)
const zIndex = Math.round(interpolate(zPosition, [-1, 1], [0, 10]));
const scale = interpolate(zPosition, [-1, 1], [0.5, 0.75]); // più piccolo se lontano
```

**When to use**: Text > highlight boxes (always). Text > background video/images.
Interactive elements (cursor, buttons) on top of everything.
In 3D scenes, calculate z-index from z-position for correct occlusion ordering.

---

## 12. Timing Offsets Between Animation Phases

Different types of content should enter at different times within a scene. Order: structure → content → decoration → effects.

```tsx
// Scena con timing offset deliberati tra fasi
const TIMING = {
  backgroundEnter: 0,      // Background prima di tutto
  titleEnter: 8,           // Titolo dopo che bg è stabile
  contentEnter: 20,        // Contenuto dopo che titolo è leggibile
  highlightAppear: 35,     // Highlight DOPO che testo si è fermato
  ambientEffectsStart: 40, // Effetti ambientali per ultimi
};

const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const bgProgress = spring({ frame: Math.max(0, frame - TIMING.backgroundEnter), fps });
  const titleProgress = spring({ frame: Math.max(0, frame - TIMING.titleEnter), fps });
  const contentProgress = spring({ frame: Math.max(0, frame - TIMING.contentEnter), fps });

  // Highlight appare SOLO dopo che il testo si è fermato
  const highlightScale = frame >= TIMING.highlightAppear
    ? interpolate(frame - TIMING.highlightAppear, [0, 10], [0, 1], {
        easing: Easing.bezier(0.34, 1.56, 0.64, 1),
        extrapolateRight: "clamp",
      })
    : 0;

  return (
    <AbsoluteFill>
      <div style={{ opacity: bgProgress }}>Background</div>
      <div style={{ opacity: titleProgress }}>Title</div>
      <div style={{ opacity: contentProgress }}>Content</div>
      <div style={{ transform: `scaleX(${highlightScale})` }}>Highlight</div>
    </AbsoluteFill>
  );
};
```

**When to use**: Every scene should have deliberate timing offsets between content types.
The gap creates rhythm and guides the eye through the information hierarchy.
Critical rule: decorative elements (highlights, glows, shimmer) appear AFTER content has settled.
See [visual-storytelling.md](visual-storytelling.md) for scene-level pacing strategies.
