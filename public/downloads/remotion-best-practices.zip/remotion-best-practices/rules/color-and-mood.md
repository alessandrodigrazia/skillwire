---
name: color-and-mood
description: Background types, semantic colors, glassmorphism, atmosphere, and visual mood systems
metadata:
  tags: color, mood, background, gradient, glassmorphism, vignette, palette, semantic-colors
---

Color and background are not decoration — they define the **emotional register** of each scene.
This file covers creative color strategy. See [animations.md](animations.md) for animation basics.

---

## 1. Background Types Catalog

Five proven background types, each with a distinct mood. Pick one per video or use 2-3 with intentional transitions.

```tsx
// TYPE 1: Dark Radial — dramatic, tech, AI explainers
const DarkRadial = () => (
  <AbsoluteFill style={{
    background: "radial-gradient(circle at 50% 50%, #222222 0%, #000000 100%)",
  }} />
);

// TYPE 2: Pure White — editorial, data viz, educational
const PureWhite = () => (
  <AbsoluteFill style={{ backgroundColor: "#FFFFFF" }} />
);

// TYPE 3: Warm Cream — friendly, approachable, product intros
const WarmCream = () => (
  <AbsoluteFill style={{ backgroundColor: "#FFF8F0" }} />
);

// TYPE 4: Pulsing Radial — Vercel/Stripe minimal premium (see rule #11)
// TYPE 5: Fluid Blob — Apple-style organic premium (see rule #12)
```

**When to use**: Dark = AI, tech, dramatic. White = data, education, clarity. Cream = product, friendly.
Pulsing = Vercel/Stripe premium. Fluid blob = Apple premium.
Never use plain flat colors for premium content — add at least gradient or subtle movement.

---

## 2. Background Change = Mood Change

When the background changes within a video, it signals a **shift in emotional register**.

```tsx
const MOODS = {
  friendly: "#FFF8F0",    // Cream — caldo, approachable
  technical: "linear-gradient(135deg, #0891B2, #1E3A5F)", // Blue — competente, tech
  dramatic: "radial-gradient(circle, #222 0%, #000 100%)", // Dark — impattante
  editorial: "#FFFFFF",   // White — pulito, professionale
  energetic: "linear-gradient(135deg, #FF7D00, #FF5D47)", // Orange — azione, CTA
};

// Transition tra mood con interpolate (non crossfade, ma "takeover")
const MoodTransition: React.FC<{
  switchFrame: number;
  from: string;
  to: string;
}> = ({ switchFrame, from, to }) => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame, [switchFrame, switchFrame + 20], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill>
      <div style={{ background: from, position: "absolute", inset: 0 }} />
      <div style={{ background: to, position: "absolute", inset: 0, opacity: progress }} />
    </AbsoluteFill>
  );
};
```

**When to use**: Cream → Blue = "from friendly intro to technical demo".
White → Dark = "from overview to dramatic climax".
Each background change should coincide with a narrative beat (new phase, new topic, new energy).

---

## 3. Semantic Colors

Assign meaning to colors and use them consistently throughout the entire video.

```tsx
// Sistema a 3 colori semantici (AI Explainer style)
const SEMANTIC = {
  positive: "#22C55E",  // Green — can do, success, capability
  negative: "#EF4444",  // Red — cannot, limitation, warning
  action:   "#FF5D47",  // Orange — brand, CTA, active state
  neutral:  "#9CA3AF",  // Gray — inactive, secondary, disabled
};

// Usage: icone con colore semantico
const CapabilityIcon: React.FC<{ canDo: boolean }> = ({ canDo }) => (
  <div style={{
    color: canDo ? SEMANTIC.positive : SEMANTIC.negative,
    fontSize: 48,
  }}>
    {canDo ? "✓" : "✗"}
  </div>
);

// Colore sincronizzato tra elementi distanti (testo e icona)
const activeIndex = Math.floor(frame / 30) % 3;
const textColor = i === activeIndex ? SEMANTIC.action : SEMANTIC.neutral;
const iconBorderColor = i === activeIndex ? SEMANTIC.action : "transparent";
```

**When to use**: Educational videos explaining capabilities/limitations.
Process visualizations where steps can succeed or fail.
Any video where elements have "states" (active/inactive, positive/negative).
Keep consistent: once green=positive, it must ALWAYS mean positive throughout the video.

---

## 4. Dual Accent System

Use exactly TWO accent colors with distinct semantic roles. Never more than two.

```tsx
// Dual accent con ruoli chiari
const ACCENTS = {
  affirm:   "#CCFF00",  // Neon Green — fatti, affermazioni, conferme
  question: "#FF0066",  // Hot Pink — domande, azioni, emphasis critico
};

// Usage: highlight box con colore semantico
const HighlightBox: React.FC<{
  type: "affirm" | "question";
  width: number;
  progress: number;
}> = ({ type, width, progress }) => (
  <div style={{
    backgroundColor: ACCENTS[type],
    width: width * progress,
    height: "100%",
    position: "absolute",
    zIndex: 0,
    transformOrigin: "left",
  }} />
);

// Neon Green dietro "DIGITAL" (affermazione)
// Hot Pink dietro "HAPPENED" (domanda provocatoria)
```

**When to use**: Kinetic typography where different words need different emphasis.
Promotional videos with "positive feature" vs "call to action" highlighting.
Rule: the two colors must be **visually distinct** (no two shades of blue) and **semantically different**.

---

## 5. Max 4 Colors Rule

The entire video palette should have at most 4 colors: background + text + accent1 + accent2.

```tsx
// Palette completa di un video
const PALETTE = {
  bg:      "#FFFFFF",   // Background
  text:    "#1A1A2E",   // Primary text
  accent1: "#8B5CF6",   // Purple — brand, emphasis
  accent2: "#EC4899",   // Pink — secondary emphasis, CTA
};

// Derivare varianti dalla palette base (mai aggiungere nuovi colori)
const VARIANTS = {
  textMuted:   PALETTE.text + "80",    // 50% opacity
  accent1Soft: PALETTE.accent1 + "20", // 12% opacity per background
  accent2Glow: PALETTE.accent2 + "40", // 25% opacity per glow
};
```

**When to use**: Always as a starting constraint. Limiting the palette forces visual coherence.
If you need more "colors", derive them as opacity variants of the 4 base colors.
Exception: per-brand theming (social cards) where each card has its own mini-palette.

---

## 6. Gradient Text as Emphasis System

Keywords highlighted with gradient text using `background-clip: text`. Use consistently for ALL emphasized words.

```tsx
// Gradient text per keyword — sistema coerente
const GradientKeyword: React.FC<{ children: string }> = ({ children }) => (
  <span style={{
    backgroundImage: "linear-gradient(90deg, #FFFFFF, #A855F7)",
    backgroundClip: "text",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    color: "transparent",
    fontWeight: 700,
  }}>
    {children}
  </span>
);

// Usage: "Create powerful videos" — "powerful" in gradient
<p style={{ color: "white", fontSize: 64 }}>
  Create <GradientKeyword>powerful</GradientKeyword> videos
</p>

// Variante: gradient diverso per accento diverso
const GRADIENTS = {
  brand:   "linear-gradient(90deg, #8B5CF6, #EC4899)", // Purple → Pink
  tech:    "linear-gradient(90deg, #06B6D4, #3B82F6)", // Cyan → Blue
  energy:  "linear-gradient(90deg, #F59E0B, #EF4444)", // Amber → Red
};
```

**When to use**: Every keyword that needs emphasis in text-heavy scenes.
The gradient direction and colors must be the SAME for all keywords in one video.
Works best on dark backgrounds. On light backgrounds, use darker gradient colors.

---

## 7. Per-Brand Color Theming

When showing platform logos/cards, use each brand's official color scheme. Colors are identity, not configuration.

```tsx
// Colori brand come lookup table
const BRAND_THEMES = {
  instagram: {
    icon: "linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)",
    bar: "linear-gradient(90deg, #E1306C, #833AB4)",
    text: "#FFFFFF",
  },
  x: {
    icon: "#000000",
    bar: "#000000",
    text: "#FFFFFF",
  },
  tiktok: {
    icon: "#000000",
    bar: "#000000",
    text: "#00F2EA", // Cyan TikTok
  },
  twitch: {
    icon: "#9146FF",
    bar: "#9146FF",
    text: "#FFFFFF",
  },
  discord: {
    icon: "#5865F2",
    bar: "#5865F2",
    text: "#FFFFFF",
  },
} as const;

// Usage: colore derivato dalla prop platform
const SocialCard: React.FC<{ platform: keyof typeof BRAND_THEMES }> = ({ platform }) => {
  const theme = BRAND_THEMES[platform];
  return (
    <div style={{ background: theme.bar, color: theme.text }}>
      @username
    </div>
  );
};
```

**When to use**: Social media showcases, multi-platform comparison scenes, follow cards.
Never approximate brand colors — use official hex values.
The color IS the brand recognition; getting it wrong breaks trust.

---

## 8. Blur + Dim to "Age" the Old

In comparison scenes, blur and dim the "old" option to make the "new" option pop.

```tsx
// "Vecchio" sfuocato e oscurato, "Nuovo" nitido e brillante
const ComparisonScene: React.FC<{ transitionFrame: number }> = ({ transitionFrame }) => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame, [transitionFrame, transitionFrame + 30], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const oldBlur = interpolate(progress, [0, 1], [0, 6]);
  const oldOpacity = interpolate(progress, [0, 1], [1, 0.5]);
  const oldScale = interpolate(progress, [0, 1], [1, 0.95]);

  return (
    <div style={{ display: "flex", gap: 40 }}>
      {/* "Old" — sfuocato, oscurato, leggermente rimpicciolito */}
      <div style={{
        filter: `blur(${oldBlur}px)`,
        opacity: oldOpacity,
        transform: `scale(${oldScale})`,
      }}>
        <OldMethodCard />
      </div>

      {/* "New" — nitido, pieno, scala 1 */}
      <div style={{ opacity: 1, transform: "scale(1)" }}>
        <NewMethodCard />
      </div>
    </div>
  );
};
```

**When to use**: Before/after comparisons. CLI vs GUI. Manual vs automated.
The triple combo (blur + dim + slight scale-down) is more effective than any single effect.
Apply gradually (30 frames) — never instant. The "aging" should feel like losing focus, not disappearing.

---

## 9. Glassmorphism Recipe

Glassmorphism (frosted glass effect) works as a "stage" or "window" for demo content.

```tsx
const GlassCard: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{
    background: "rgba(255, 255, 255, 0.15)",
    backdropFilter: "blur(16px)",
    WebkitBackdropFilter: "blur(16px)",
    borderRadius: 24,
    border: "1px solid rgba(255, 255, 255, 0.2)",
    padding: 40,
    boxShadow: "0 8px 32px rgba(0, 0, 0, 0.1)",
  }}>
    {children}
  </div>
);

// Variante con glow perimetrale
const GlassCardGlow: React.FC<{ glowColor?: string; children: React.ReactNode }> = ({
  glowColor = "#8B5CF6",
  children,
}) => (
  <div style={{
    background: "rgba(255, 255, 255, 0.1)",
    backdropFilter: "blur(20px)",
    WebkitBackdropFilter: "blur(20px)",
    borderRadius: 24,
    border: `1px solid ${glowColor}30`,
    padding: 40,
    boxShadow: `0 0 40px ${glowColor}20, 0 8px 32px rgba(0, 0, 0, 0.15)`,
  }}>
    {children}
  </div>
);
```

**When to use**: As container for product demos (the card is the "stage" for the demo).
Over dark or colorful backgrounds — glassmorphism needs contrast behind it.
Animate entry with spring scale (0.9→1), exit with scale (1→0.9) + opacity fade.
Never stack multiple glassmorphism layers — the blur compounds and becomes unreadable.

---

## 10. Vignette and Ambient Glow

Vignette darkens edges to focus attention center. Ambient glow adds warmth at a specific position.

```tsx
// Vignette — bordi scuri per focalizzare il centro
const Vignette = () => (
  <div style={{
    position: "absolute",
    inset: 0,
    background: "radial-gradient(ellipse at 50% 50%, transparent 50%, rgba(0,0,0,0.6) 100%)",
    pointerEvents: "none",
    zIndex: 100, // sopra tutto
  }} />
);

// Ambient glow — ellisse colorata al centro-basso
const AmbientGlow: React.FC<{ color?: string }> = ({ color = "#A855F7" }) => {
  const frame = useCurrentFrame();
  const breathe = 0.4 + Math.sin(frame * 0.03) * 0.1; // respira tra 0.3 e 0.5

  return (
    <div style={{
      position: "absolute",
      bottom: -100,
      left: "50%",
      transform: "translateX(-50%)",
      width: 800,
      height: 400,
      background: `radial-gradient(ellipse, ${color}${Math.round(breathe * 255).toString(16).padStart(2, "0")} 0%, transparent 70%)`,
      pointerEvents: "none",
    }} />
  );
};
```

**When to use**: Vignette on dark background videos to create cinematic focus.
Ambient glow on dark backgrounds to add warmth/color without illuminating the whole scene.
Both are "set and forget" — place them once, they work for the whole scene.

---

## 11. Pulsing Background

A radial gradient that subtly breathes. More minimal than fluid blobs, perfect for Vercel/Stripe aesthetics.

```tsx
const PulsingBackground: React.FC<{
  centerColor?: string;
  edgeColor?: string;
}> = ({ centerColor = "#F3E8FF", edgeColor = "#FFFFFF" }) => {
  const frame = useCurrentFrame();

  // Pulsazione lenta — impercettibile consciamente, percepita inconsciamente
  const pulseScale = 1 + Math.sin(frame * 0.03) * 0.05;
  const pulseOpacity = 0.8 + Math.sin(frame * 0.02) * 0.1;

  return (
    <AbsoluteFill style={{ backgroundColor: edgeColor }}>
      <div style={{
        position: "absolute",
        top: "50%",
        left: "50%",
        width: 1200,
        height: 1200,
        transform: `translate(-50%, -50%) scale(${pulseScale})`,
        background: `radial-gradient(circle, ${centerColor} 0%, transparent 70%)`,
        opacity: pulseOpacity,
      }} />
    </AbsoluteFill>
  );
};
```

**When to use**: Premium minimal videos (SaaS promos, Vercel/Stripe style).
When fluid blobs are too "organic" and you want something more geometric.
The pulsation must be VERY subtle (±5% scale, ±10% opacity) — if you can notice it easily, reduce it.

---

## 12. Fluid Blob Background

Three large blurred circles moving slowly across the frame. Creates an organic, Apple-style premium feel.

```tsx
const FluidBlobBackground: React.FC<{ durationInFrames: number }> = ({ durationInFrames }) => {
  const frame = useCurrentFrame();

  const blobs = [
    { color: "#E6E6FA", size: 900, blur: 120, speed: 0.7 },
    { color: "#DDD6FE", size: 800, blur: 100, speed: 0.5 },
    { color: "#FDE68A", size: 850, blur: 110, speed: 0.6 },
  ];

  return (
    <AbsoluteFill style={{ backgroundColor: "#FFFFFF" }}>
      {blobs.map((blob, i) => {
        // Posizioni X/Y interpolate su tutta la durata del video
        const x = interpolate(frame, [0, durationInFrames], [
          200 + i * 300,
          800 - i * 200,
        ]);
        const y = interpolate(frame, [0, durationInFrames / 2, durationInFrames], [
          150 + i * 200,
          600 - i * 100,
          250 + i * 150,
        ]);

        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: blob.size,
              height: blob.size,
              borderRadius: "50%",
              backgroundColor: blob.color,
              filter: `blur(${blob.blur}px)`,
              opacity: 0.65,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};
```

**When to use**: Apple-style premium promos. Videos that need to feel "organic" and "fluid".
The blobs should move SO slowly that you only notice movement over 5+ seconds.
Keep opacity below 0.7 and blur above 80px — they should be atmospheric, not geometric.
This background persists for the ENTIRE video — don't change it between scenes.
See also [motion-design-principles.md](motion-design-principles.md) rule #5 for breathing effects on these blobs.
