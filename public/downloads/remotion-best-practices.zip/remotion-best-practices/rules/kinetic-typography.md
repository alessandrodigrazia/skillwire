---
name: kinetic-typography
description: Advanced kinetic typography - highlight boxes, word insertion, stacked text, emphasis systems, gradient text
metadata:
  tags: typography, kinetic, highlight-box, word-insertion, stacked-text, gradient-text, emphasis
---

Kinetic typography goes beyond typewriter effects. This file covers **advanced text animation systems**.
See [text-animations.md](text-animations.md) for basic typewriter and text entry patterns.
See [fonts.md](fonts.md) for loading Google Fonts and local fonts.

---

## 1. Highlight Box (scaleX Behind Word)

A colored rectangle expands horizontally behind a specific keyword. The text stays ON TOP of the box.

```tsx
import { spring, useCurrentFrame, useVideoConfig, interpolate, Easing } from "remotion";

const HighlightWord: React.FC<{
  word: string;
  color: string;
  highlightStartFrame: number;
}> = ({ word, color, highlightStartFrame }) => {
  const frame = useCurrentFrame();

  // Highlight appare SOLO dopo highlightStartFrame
  const highlightProgress = frame >= highlightStartFrame
    ? interpolate(frame - highlightStartFrame, [0, 12], [0, 1], {
        easing: Easing.bezier(0.34, 1.56, 0.64, 1), // elastic overshoot
        extrapolateRight: "clamp",
      })
    : 0;

  return (
    <span style={{ position: "relative", display: "inline-block" }}>
      {/* Highlight box — BEHIND the text (zIndex 0) */}
      <span style={{
        position: "absolute",
        inset: "-4px -8px",
        backgroundColor: color,
        zIndex: 0,
        transform: `scaleX(${highlightProgress})`,
        transformOrigin: "left",
        borderRadius: 4,
      }} />
      {/* Text — ON TOP of the box (zIndex 1) */}
      <span style={{ position: "relative", zIndex: 1 }}>
        {word}
      </span>
    </span>
  );
};

// Usage: "Change your DIGITAL mindset"
// <HighlightWord word="DIGITAL" color="#CCFF00" highlightStartFrame={45} />
```

**When to use**: Every time a keyword needs visual emphasis in typography-heavy scenes.
Critical timing rule: the highlight appears AFTER the text has stopped moving (see rule #13).
Use `transformOrigin: "left"` for left-to-right expansion. Use `"center"` for center-out.

---

## 2. Word Insertion Between Existing Words

A new word inserts itself between two existing words, pushing them apart. Three coordinated animations.

```tsx
const WordInsertion: React.FC<{ insertFrame: number }> = ({ insertFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const insertProgress = frame >= insertFrame
    ? spring({ frame: frame - insertFrame, fps, config: { damping: 12, stiffness: 120 } })
    : 0;

  // Le parole esistenti si allontanano per fare spazio
  const topWordY = interpolate(insertProgress, [0, 1], [0, -80]);
  const bottomWordY = interpolate(insertProgress, [0, 1], [0, 80]);

  // La nuova parola entra da sinistra con opacity
  const newWordX = interpolate(insertProgress, [0, 1], [-300, 0]);
  const newWordOpacity = insertProgress;

  return (
    <div style={{
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      lineHeight: 0.8,
      fontWeight: 900,
      fontSize: 140,
    }}>
      <div style={{ transform: `translateY(${topWordY}px)` }}>NEXT</div>
      <div style={{
        transform: `translateX(${newWordX}px)`,
        opacity: newWordOpacity,
        color: "#FF0066",
      }}>
        TODAY
      </div>
      <div style={{ transform: `translateY(${bottomWordY}px)` }}>LEVEL</div>
    </div>
  );
};

// Result: "NEXT LEVEL" → inserisce "TODAY" → "NEXT TODAY LEVEL"
```

**When to use**: For narrative surprise — the inserted word changes the meaning.
"NEXT LEVEL" is expected, "NEXT TODAY LEVEL" is surprising.
The highlight box (rule #1) can appear on the inserted word AFTER it settles.

---

## 3. Stacked Single Words

One word per line, ultra-tight line-height, massive font. Each word has its own visual weight.

```tsx
const StackedWords: React.FC<{
  words: string[];
  entryDelay?: number;
}> = ({ words, entryDelay = 5 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <div style={{
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      lineHeight: 0.8, // ultra-tight — le righe quasi si toccano
      fontWeight: 900,
      fontSize: 160,
      textTransform: "uppercase",
    }}>
      {words.map((word, i) => {
        const progress = spring({
          frame: Math.max(0, frame - i * entryDelay),
          fps,
          config: { damping: 14, stiffness: 120 },
        });

        return (
          <div
            key={i}
            style={{
              opacity: progress,
              transform: `translateY(${(1 - progress) * 30}px)`,
            }}
          >
            {word}
          </div>
        );
      })}
    </div>
  );
};

// Usage: <StackedWords words={["CHANGE", "YOUR", "MINDSET"]} />
```

**When to use**: For maximum typographic impact. Each word fills the screen width.
Line-height 0.8 is critical — standard 1.2 leaves too much air between words.
Works best with bold/black weight fonts (Inter Black, Eina Bold, Montserrat Black).

---

## 4. 70% Screen Occupancy Rule

Text blocks should occupy exactly 70% of the screen width AND height. Not 50%, not 100%.

```tsx
const TitleSlide: React.FC<{
  children: React.ReactNode;
  width?: number;
  height?: number;
}> = ({ children, width = 1920, height = 1080 }) => (
  <AbsoluteFill style={{
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  }}>
    <div style={{
      width: width * 0.7,   // 70% della larghezza video
      height: height * 0.7, // 70% dell'altezza video
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      // Il testo è centrato dentro questa "safe zone"
    }}>
      {children}
    </div>
  </AbsoluteFill>
);

// Usage:
// <TitleSlide>
//   <StackedWords words={["THE", "FUTURE", "IS", "NOW"]} />
// </TitleSlide>
```

**When to use**: For all typography-dominant scenes. The 70% creates a natural margin.
50% feels too small (wasted space). 100% risks clipping characters at edges.
Font size should be UNIFORM across all text scenes — consistency = professionalism.
Always test that descenders (g, p, y, q) and ascenders (h, k, l) don't get clipped.

---

## 5. Stroke-to-Fill Wipe

A pill/box shape starts as outline (stroke only) and fills left-to-right while text color inverts simultaneously.

```tsx
const StrokeToFillWipe: React.FC<{
  text: string;
  fillStartFrame: number;
  duration?: number;
}> = ({ text, fillStartFrame, duration = 20 }) => {
  const frame = useCurrentFrame();

  const fillProgress = interpolate(
    frame, [fillStartFrame, fillStartFrame + duration], [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
  );

  return (
    <div style={{
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      padding: "12px 32px",
      borderRadius: 9999, // pill shape
      border: "2px solid white",
      overflow: "hidden",
    }}>
      {/* Fill che avanza da sinistra a destra */}
      <div style={{
        position: "absolute",
        left: 0,
        top: 0,
        bottom: 0,
        width: `${fillProgress * 100}%`,
        backgroundColor: "white",
        zIndex: 0,
      }} />

      {/* Testo bianco (visibile su sfondo nero/vuoto) */}
      <span style={{
        position: "relative",
        zIndex: 1,
        color: "white",
        fontWeight: 700,
        fontSize: 32,
        // Clip: mostra solo la parte NON ancora riempita
        clipPath: `inset(0 0 0 ${fillProgress * 100}%)`,
      }}>
        {text}
      </span>

      {/* Testo nero (visibile dove il fill è passato) */}
      <span style={{
        position: "absolute",
        zIndex: 2,
        color: "black",
        fontWeight: 700,
        fontSize: 32,
        padding: "12px 32px",
        left: 0,
        // Clip: mostra solo la parte GIA riempita
        clipPath: `inset(0 ${(1 - fillProgress) * 100}% 0 0)`,
      }}>
        {text}
      </span>
    </div>
  );
};
```

**When to use**: Brand openers, kinetic typography, call-to-action reveals.
Very sophisticated effect — the color inversion creates a "scanning" feel.
Works best on dark backgrounds where white outline → white fill is high contrast.

---

## 6. Tag Cloud Explosion

Multiple pill-shaped tags appear elastically, creating a "word cloud" effect.

```tsx
const TagCloud: React.FC<{
  tags: Array<{ label: string; x: number; y: number; filled: boolean }>;
  startFrame: number;
}> = ({ tags, startFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <>
      {tags.map((tag, i) => {
        const delay = i * 3; // stagger tight
        const progress = spring({
          frame: Math.max(0, frame - startFrame - delay),
          fps,
          config: { damping: 10, stiffness: 150 }, // bouncy per "esplosione"
        });

        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: tag.x,
              top: tag.y,
              transform: `scale(${progress})`,
              padding: "8px 20px",
              borderRadius: 9999,
              border: tag.filled ? "none" : "2px solid white",
              backgroundColor: tag.filled ? "white" : "transparent",
              color: tag.filled ? "black" : "white",
              fontWeight: 700,
              fontSize: 22,
              whiteSpace: "nowrap",
            }}
          >
            {tag.label}
          </div>
        );
      })}
    </>
  );
};

// Constraint: pill shapes CANNOT overlap (possono toccarsi ma non sovrapporsi)
// Mix di wireframe (outline) e filled pills per varietà visiva
```

**When to use**: To represent a multitude of concepts/skills/features in one view.
The elastic entry creates an "explosion" feel — all tags popping into existence.
Pre-calculate positions to avoid overlap. Mix filled and outline pills for visual variety.

---

## 7. Character-by-Character Reveal

Individual characters appear one at a time with individual animation.

```tsx
const CharacterReveal: React.FC<{
  text: string;
  startFrame: number;
  charDelay?: number;
}> = ({ text, startFrame, charDelay = 2 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <div style={{ display: "flex", fontSize: 80, fontWeight: 900 }}>
      {text.split("").map((char, i) => {
        const charProgress = spring({
          frame: Math.max(0, frame - startFrame - i * charDelay),
          fps,
          config: { damping: 15, stiffness: 200 },
        });

        return (
          <span
            key={i}
            style={{
              opacity: charProgress,
              transform: `translateY(${(1 - charProgress) * 20}px)`,
              display: "inline-block",
              minWidth: char === " " ? "0.3em" : undefined,
            }}
          >
            {char}
          </span>
        );
      })}
    </div>
  );
};
```

**When to use**: For suspense and build-up. Each character appearing creates anticipation.
Use short charDelay (2-3 frames) for fast reveal, longer (4-6) for dramatic reveal.
Works well for final messages, brand names, or short impactful phrases.

---

## 8. Masked Slide-In

Text slides in from one direction, masked by a container with `overflow: hidden`. The text "appears from nothing".

```tsx
const MaskedSlideIn: React.FC<{
  text: string;
  direction?: "left" | "right" | "bottom";
  startFrame: number;
}> = ({ text, direction = "left", startFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = spring({
    frame: Math.max(0, frame - startFrame),
    fps,
    config: { damping: 18, stiffness: 160 },
  });

  const transforms = {
    left:   `translateX(${interpolate(progress, [0, 1], [-100, 0])}%)`,
    right:  `translateX(${interpolate(progress, [0, 1], [100, 0])}%)`,
    bottom: `translateY(${interpolate(progress, [0, 1], [100, 0])}%)`,
  };

  return (
    <div style={{ overflow: "hidden", display: "inline-block" }}>
      <div style={{
        transform: transforms[direction],
        fontSize: 72,
        fontWeight: 800,
        whiteSpace: "nowrap",
      }}>
        {text}
      </div>
    </div>
  );
};

// Il testo scorre da sinistra ma il container lo maschera —
// l'effetto è che il testo "appare dal nulla", non scorre visibilmente
```

**When to use**: Brand openers, title reveals, scene headings.
More elegant than fade-in — the text has directionality without showing where it came from.
Can add horizontal lines above/below the container for a "frame" effect.

---

## 9. Alternating Exit Direction (Zig-Zag)

Multiple text elements exit alternating left and right, creating a zig-zag rhythm.

```tsx
const AlternatingExit: React.FC<{
  items: string[];
  exitStartFrame: number;
  stagger?: number;
}> = ({ items, exitStartFrame, stagger = 4 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <>
      {items.map((item, i) => {
        const exitProgress = spring({
          frame: Math.max(0, frame - exitStartFrame - i * stagger),
          fps,
          config: { damping: 15, stiffness: 100 },
        });

        // Alterna direzione: pari → sinistra, dispari → destra
        const direction = i % 2 === 0 ? -1 : 1;
        const exitX = interpolate(exitProgress, [0, 1], [0, direction * 1200]);
        const exitOpacity = interpolate(exitProgress, [0, 1], [1, 0]);

        return (
          <div
            key={i}
            style={{
              transform: `translateX(${exitX}px)`,
              opacity: exitOpacity,
              fontSize: 64,
              fontWeight: 900,
            }}
          >
            {item}
          </div>
        );
      })}
    </>
  );
};

// Item 1: ← sinistra, Item 2: → destra, Item 3: ← sinistra, Item 4: → destra
```

**When to use**: Clearing the screen before a final reveal (see [visual-storytelling.md](visual-storytelling.md) rule #8).
The zig-zag creates visual energy during exit — more dynamic than uniform direction.
Use tight stagger (3-5 frames) for rapid clearing, wider (8-10) for deliberate exit.

---

## 10. Dual Accent Colors with Semantics

Two highlight colors, each with a specific meaning. Green for statements, Pink for questions/actions.

```tsx
// Dual accent system
const HIGHLIGHT_COLORS = {
  affirm:   "#CCFF00", // Neon Green — fatti, affermazioni, cose che sono vere
  question: "#FF0066", // Hot Pink — domande, azioni, call to action
};

// Usage nel componente TitleSlide
interface Highlight {
  wordIndex: number;
  color: "affirm" | "question";
}

const HighlightedText: React.FC<{
  words: string[];
  highlights: Highlight[];
  highlightStartFrame: number;
}> = ({ words, highlights, highlightStartFrame }) => {
  const frame = useCurrentFrame();

  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
      {words.map((word, i) => {
        const hl = highlights.find((h) => h.wordIndex === i);

        if (hl) {
          return (
            <HighlightWord
              key={i}
              word={word}
              color={HIGHLIGHT_COLORS[hl.color]}
              highlightStartFrame={highlightStartFrame + i * 3}
            />
          );
        }

        return <span key={i} style={{ fontWeight: 900, fontSize: 120 }}>{word}</span>;
      })}
    </div>
  );
};
```

**When to use**: Typography-heavy videos where different words carry different semantic weight.
"CHANGE YOUR **DIGITAL** MINDSET" — DIGITAL in green (affirmation).
"WHAT **HAPPENED** NEXT?" — HAPPENED in pink (questioning).
The two colors must be visually distinct and never used interchangeably.

---

## 11. Font Weight as Hierarchy

Use font weight (not just size) to communicate importance. Regular → Bold → Black = low → medium → high.

```tsx
// Gerarchia tipografica basata su weight
const TYPOGRAPHY = {
  primary:   { fontWeight: 900, fontSize: 120 }, // Black — headline
  secondary: { fontWeight: 700, fontSize: 80 },  // Bold — subheadline
  body:      { fontWeight: 400, fontSize: 48 },  // Regular — body text
  caption:   { fontWeight: 300, fontSize: 32 },  // Light — captions, timestamps
};

// Usage: gerarchia visiva chiara senza cambiare colore
<div>
  <p style={TYPOGRAPHY.primary}>MAIN MESSAGE</p>
  <p style={TYPOGRAPHY.secondary}>Supporting detail</p>
  <p style={TYPOGRAPHY.body}>Longer explanation text here</p>
  <p style={TYPOGRAPHY.caption}>@username · 2 min ago</p>
</div>
```

**When to use**: Always pair font-weight with font-size for hierarchy.
A 120px Regular looks less important than an 80px Bold — weight trumps size for emphasis.
Use at most 3-4 weight levels. More creates confusion.

---

## 12. Gradient Text Emphasis

Keywords in gradient (`background-clip: text`) as a consistent emphasis system throughout the video.

```tsx
// Component riutilizzabile per gradient text
const GradientText: React.FC<{
  children: string;
  gradient?: string;
  fontSize?: number;
}> = ({
  children,
  gradient = "linear-gradient(90deg, #8B5CF6, #EC4899)",
  fontSize = 64,
}) => (
  <span style={{
    backgroundImage: gradient,
    backgroundClip: "text",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    color: "transparent",
    fontWeight: 800,
    fontSize,
    display: "inline-block",
  }}>
    {children}
  </span>
);

// Usage: "Remotion is powerful" — "powerful" in gradient
// <span>Remotion is </span><GradientText>powerful</GradientText>

// Variante: underline rosa come secondo tipo di emphasis
const UnderlineEmphasis: React.FC<{ children: string }> = ({ children }) => (
  <span style={{
    borderBottom: "3px solid #EC4899",
    paddingBottom: 4,
    fontWeight: 700,
  }}>
    {children}
  </span>
);
```

**When to use**: For keywords on dark backgrounds. Gradient text is the premium version of bold text.
Use the SAME gradient direction and colors for ALL emphasized words in one video.
On light backgrounds, use darker gradient colors or switch to underline emphasis.
See [color-and-mood.md](color-and-mood.md) rule #6 for gradient color choices.

---

## 13. Entry-Then-Highlight Timing (Critical Rule)

The highlight box MUST appear AFTER the text has stopped moving. Never simultaneously.

```tsx
// WRONG — highlight e testo appaiono insieme
const textProgress = spring({ frame, fps });
const highlightScale = textProgress; // ← NO! Stesso timing

// RIGHT — highlight appare dopo che il testo si è fermato
const TEXT_ENTER = 0;
const TEXT_SETTLE = 20; // frame in cui il testo ha finito l'animazione
const HIGHLIGHT_START = TEXT_SETTLE + 5; // 5 frame di "pausa" poi highlight

const textProgress = spring({
  frame: Math.max(0, frame - TEXT_ENTER),
  fps,
  config: { damping: 14, stiffness: 120 },
});

const highlightScale = frame >= HIGHLIGHT_START
  ? interpolate(frame - HIGHLIGHT_START, [0, 10], [0, 1], {
      easing: Easing.bezier(0.34, 1.56, 0.64, 1),
      extrapolateRight: "clamp",
    })
  : 0;

// La sequenza è:
// Frame 0-20:  testo entra con spring
// Frame 20-25: testo fermo, viewer legge
// Frame 25-35: highlight appare dietro keyword
```

**When to use**: ALWAYS when combining text entry with highlight boxes.
The gap (5-10 frames) between text settle and highlight appear mimics natural reading:
you read the word first, THEN your brain highlights it as important.
This timing principle applies to any decoration that follows content entry.
See [motion-design-principles.md](motion-design-principles.md) rule #12 for the general timing offset principle.
