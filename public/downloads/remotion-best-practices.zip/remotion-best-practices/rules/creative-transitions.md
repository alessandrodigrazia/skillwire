---
name: creative-transitions
description: Creative manual transitions - camera push, clip-path masks, 3D perspective, synchronized slides
metadata:
  tags: transitions, camera-push, clip-path, ken-burns, 3d-perspective, center-open, diagonal-slice
---

Creative transitions beyond `<TransitionSeries>` built-in effects.
See [transitions.md](transitions.md) for TransitionSeries API and built-in fade/slide/wipe.
See [motion-design-principles.md](motion-design-principles.md) for spring/easing strategy.

---

## 1. Camera Push

Simulate a camera pushing into the scene: scale up + blur increase + opacity fade. Creates tension and forward momentum.

```tsx
const CameraPush: React.FC<{
  startFrame: number;
  duration?: number;
  children: React.ReactNode;
}> = ({ startFrame, duration = 15, children }) => {
  const frame = useCurrentFrame();

  const progress = interpolate(frame, [startFrame, startFrame + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const scale = interpolate(progress, [0, 1], [1, 1.5]);
  const blur = interpolate(progress, [0, 1], [0, 20]);
  const opacity = interpolate(progress, [0, 1], [1, 0]);

  return (
    <div style={{
      transform: `scale(${scale})`,
      filter: `blur(${blur}px)`,
      opacity,
    }}>
      {children}
    </div>
  );
};

// Usare come exit della scena corrente, overlap con entry della prossima
```

**When to use**: As scene exit in the first 1-3 scenes (hook section) for tension buildup.
NOT for mid-video transitions — it's too dramatic for informational content.
The blur simulates depth of field, the scale simulates physical camera movement.

---

## 2. Ken Burns Effect

Slow, barely perceptible zoom on static images. Gives life to photographs without explicit animation.

```tsx
const KenBurns: React.FC<{
  src: string;
  durationInFrames: number;
  zoomFactor?: number;
}> = ({ src, durationInFrames, zoomFactor = 1.05 }) => {
  const frame = useCurrentFrame();

  // Zoom lentissimo — quasi impercettibile ma percepito inconsciamente
  const scale = interpolate(frame, [0, durationInFrames], [1, zoomFactor], {
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill>
      <Img
        src={src}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
          transform: `scale(${scale})`,
        }}
      />
    </AbsoluteFill>
  );
};
```

**When to use**: On ALL static images/photographs — never show a truly static image.
Keep zoomFactor between 1.03 and 1.08. Anything over 1.1 becomes noticeable and distracting.
Can also pan slightly (translateX/Y) alongside zoom for more dynamic feel.

---

## 3. Diagonal Slice

Split the scene diagonally using `clip-path: polygon()`. Two halves slide in opposite directions.

```tsx
const DiagonalSlice: React.FC<{
  startFrame: number;
  duration?: number;
}> = ({ startFrame, duration = 20 }) => {
  const frame = useCurrentFrame();

  const progress = interpolate(frame, [startFrame, startFrame + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.25, 0.1, 0.25, 1),
  });

  // Metà superiore scorre in alto-destra
  const topX = interpolate(progress, [0, 1], [0, 100]);
  const topY = interpolate(progress, [0, 1], [0, -100]);

  // Metà inferiore scorre in basso-sinistra
  const bottomX = interpolate(progress, [0, 1], [0, -100]);
  const bottomY = interpolate(progress, [0, 1], [0, 100]);

  return (
    <>
      {/* Metà superiore — taglio diagonale */}
      <div style={{
        position: "absolute",
        inset: 0,
        clipPath: "polygon(0 0, 100% 0, 100% 50%, 0 60%)",
        transform: `translate(${topX}%, ${topY}%)`,
      }}>
        <SceneContent />
      </div>

      {/* Metà inferiore — taglio complementare */}
      <div style={{
        position: "absolute",
        inset: 0,
        clipPath: "polygon(0 60%, 100% 50%, 100% 100%, 0 100%)",
        transform: `translate(${bottomX}%, ${bottomY}%)`,
      }}>
        <SceneContent />
      </div>
    </>
  );
};
```

**When to use**: For energy and dynamism — the diagonal creates visual tension.
Works best as transition out of action/photography scenes.
The angle of the polygon defines the personality: steep = dramatic, shallow = elegant.

---

## 4. Center-Open Mask

Scene reveals by expanding from the center outward, like an eye opening.

```tsx
const CenterOpenMask: React.FC<{
  startFrame: number;
  duration?: number;
  children: React.ReactNode;
}> = ({ startFrame, duration = 30, children }) => {
  const frame = useCurrentFrame();

  const progress = interpolate(frame, [startFrame, startFrame + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.25, 0.1, 0.25, 1),
  });

  // inset(50%) = punto invisibile al centro, inset(0%) = completamente visibile
  const inset = interpolate(progress, [0, 1], [50, 0]);

  return (
    <div style={{
      position: "absolute",
      inset: 0,
      clipPath: `inset(${inset}% ${inset}% ${inset}% ${inset}%)`,
    }}>
      {children}
    </div>
  );
};

// Variante: apertura solo orizzontale (effetto "tenda")
// clipPath: `inset(0% ${inset}% 0% ${inset}%)`

// Variante: apertura solo verticale (effetto "sipario")
// clipPath: `inset(${inset}% 0% ${inset}% 0%)`
```

**When to use**: Dramatic scene reveals, especially for video content.
The "eye opening" metaphor creates a feeling of discovery.
Works particularly well for transitioning into full-screen video clips.
Use with spring easing for organic feel, or with DRAMATIC bezier for cinematic feel.

---

## 5. Background Takeover

The new background rapidly "eats" the old one. Not a crossfade — a deliberate replacement.

```tsx
const BackgroundTakeover: React.FC<{
  switchFrame: number;
  oldBg: string;
  newBg: string;
  direction?: "top" | "bottom" | "left" | "right";
}> = ({ switchFrame, oldBg, newBg, direction = "top" }) => {
  const frame = useCurrentFrame();

  const progress = interpolate(frame, [switchFrame, switchFrame + 20], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.25, 0.1, 0.25, 1),
  });

  const clipPaths = {
    top:    `inset(0 0 ${(1 - progress) * 100}% 0)`,
    bottom: `inset(${(1 - progress) * 100}% 0 0 0)`,
    left:   `inset(0 ${(1 - progress) * 100}% 0 0)`,
    right:  `inset(0 0 0 ${(1 - progress) * 100}%)`,
  };

  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", inset: 0, background: oldBg }} />
      <div style={{
        position: "absolute",
        inset: 0,
        background: newBg,
        clipPath: clipPaths[direction],
      }} />
    </AbsoluteFill>
  );
};
```

**When to use**: When background change signals a mood shift (see [color-and-mood.md](color-and-mood.md) rule #2).
Faster than crossfade (20 frames vs 30+), more intentional.
The direction should match the content flow (e.g., "top" if new content comes from above).

---

## 6. Synchronized Scene Sliding

Scenes move like a train: outgoing scene exits in one direction, incoming enters from the opposite, at the same speed.

```tsx
const SyncSlide: React.FC<{
  transitionFrame: number;
  duration?: number;
  direction?: "horizontal" | "vertical";
  outgoing: React.ReactNode;
  incoming: React.ReactNode;
}> = ({ transitionFrame, duration = 25, direction = "vertical", outgoing, incoming }) => {
  const frame = useCurrentFrame();

  const progress = interpolate(frame, [transitionFrame, transitionFrame + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.25, 0.1, 0.25, 1),
  });

  const isHorizontal = direction === "horizontal";
  // Outgoing: si muove via
  const outTranslate = isHorizontal
    ? `translateX(${interpolate(progress, [0, 1], [0, -100])}%)`
    : `translateY(${interpolate(progress, [0, 1], [0, -100])}%)`;

  // Incoming: arriva dalla direzione opposta
  const inTranslate = isHorizontal
    ? `translateX(${interpolate(progress, [0, 1], [100, 0])}%)`
    : `translateY(${interpolate(progress, [0, 1], [100, 0])}%)`;

  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", inset: 0, transform: outTranslate }}>
        {outgoing}
      </div>
      <div style={{ position: "absolute", inset: 0, transform: inTranslate }}>
        {incoming}
      </div>
    </AbsoluteFill>
  );
};
```

**When to use**: Corporate videos, event promos — professional and clean.
The synchronized movement feels like a physical object being pushed aside.
Use vertical for content flow (top→bottom = chronological), horizontal for comparisons.

---

## 7. Blur In/Out (Focus/Defocus)

Scene enters by coming into focus (blur→sharp), exits by losing focus (sharp→blur). Like a camera lens.

```tsx
const BlurInOut: React.FC<{
  inFrame: number;
  outFrame: number;
  blurAmount?: number;
  blurDuration?: number;
  children: React.ReactNode;
}> = ({ inFrame, outFrame, blurAmount = 20, blurDuration = 15, children }) => {
  const frame = useCurrentFrame();

  // Blur in: sfuocato → nitido
  const blurIn = interpolate(frame, [inFrame, inFrame + blurDuration], [blurAmount, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // Blur out: nitido → sfuocato
  const blurOut = interpolate(frame, [outFrame, outFrame + blurDuration], [0, blurAmount], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const currentBlur = frame < outFrame ? blurIn : blurOut;

  return (
    <div style={{ filter: `blur(${currentBlur}px)` }}>
      {children}
    </div>
  );
};
```

**When to use**: Organic, cinematic transitions. Mimics real camera focus behavior.
Particularly effective for text transitions: old text blurs out, new text blurs in.
Better than fade for "Apple-style" minimal aesthetics — blur feels more physical than opacity.

---

## 8. 3D rotateY Comparison ("Flip the Coin")

Old view rotates away to -90 deg (disappears in 3D), new view rotates in from 90 deg. Like flipping a coin.

```tsx
const RotateYComparison: React.FC<{
  flipFrame: number;
  duration?: number;
  oldContent: React.ReactNode;
  newContent: React.ReactNode;
}> = ({ flipFrame, duration = 30, oldContent, newContent }) => {
  const frame = useCurrentFrame();

  const progress = interpolate(frame, [flipFrame, flipFrame + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.25, 0.1, 0.25, 1),
  });

  // Old: ruota via a -90° (scompare verso sinistra in 3D)
  const oldRotateY = interpolate(progress, [0, 0.5], [0, -90], {
    extrapolateRight: "clamp",
  });

  // New: ruota dentro da 90° a 0° (appare dalla destra in 3D)
  const newRotateY = interpolate(progress, [0.5, 1], [90, 0], {
    extrapolateLeft: "clamp",
  });

  const showOld = progress <= 0.5;

  return (
    <div style={{ perspective: 1000 }}>
      {showOld ? (
        <div style={{ transform: `rotateY(${oldRotateY}deg)` }}>
          {oldContent}
        </div>
      ) : (
        <div style={{ transform: `rotateY(${newRotateY}deg)` }}>
          {newContent}
        </div>
      )}
    </div>
  );
};
```

**When to use**: Before/after comparisons, old→new, terminal→browser.
The 3D rotation creates a natural "other side of the same thing" metaphor.
Content switches at 90 deg (perpendicular to viewer) when the element is invisible.
See also [3d.md](3d.md) for Three.js-based 3D content.

---

## 9. Hard Cuts for Rhythm

No transition at all. The abrupt change creates energy and matches fast-paced content.

```tsx
// Hard cuts — nessuna transizione tra scene
// Il cambio di medium (testo → video → testo) È la transizione

// In TransitionSeries senza <Transition>:
<TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={120}>
    <TextScene1 />
  </TransitionSeries.Sequence>
  {/* Nessun <Transition> — hard cut diretto */}
  <TransitionSeries.Sequence durationInFrames={45}>
    <VideoClip src="/public/city.mp4" />
  </TransitionSeries.Sequence>
  {/* Nessun <Transition> */}
  <TransitionSeries.Sequence durationInFrames={120}>
    <TextScene2 />
  </TransitionSeries.Sequence>
</TransitionSeries>

// O con <Series> semplice senza overlap:
<Series>
  <Series.Sequence durationInFrames={120}><TextScene1 /></Series.Sequence>
  <Series.Sequence durationInFrames={45}><VideoClip /></Series.Sequence>
  <Series.Sequence durationInFrames={120}><TextScene2 /></Series.Sequence>
</Series>
```

**When to use**: Between text and video scenes — the medium change IS the transition.
For fast-paced brand openers (1 scene/second).
When transitions would slow down the rhythm. Hard cuts = maximum energy.
Rule: when scenes are under 2 seconds, never add transitions — they'd eat the entire scene.

---

## 10. Slide vs Fade — Intentional Choice

Slide-in communicates direction and energy. Fade-in communicates softness and apparition. Choose based on meaning.

```tsx
// SLIDE — ha direzione, energia, provenienza
// Comunica: "questo arriva da qualche parte"
const slideIn = interpolate(progress, [0, 1], [200, 0]); // translateX
// Usage: titoli, pannelli, elementi che "entrano in scena"

// FADE — non ha direzione, morbido, etereo
// Comunica: "questo si materializza"
const fadeIn = progress; // opacity
// Usage: descrizioni, sottotitoli, elementi secondari

// REGOLA DECISIONALE:
// Se l'elemento è il SOGGETTO della scena → SLIDE (ha presenza fisica)
// Se l'elemento è DESCRIZIONE/supporto → FADE (non deve dominare)

// Esempio: header slides, description fades
const headerX = interpolate(progress, [0, 1], [300, 0]); // slide from right
const descOpacity = progress; // fade in
```

**When to use**: Make this choice consciously for EVERY element. Default to slide for titles, fade for descriptions.
Mixing both in the same scene creates visual hierarchy: slide elements feel "more important" than faded ones.
Never use the same transition for all elements — the monotony kills the rhythm.

---

## 11. rotateX Exit ("Falling Backward")

Element rotates backward on the X axis like a door falling. More dramatic than fade or slide.

```tsx
const RotateXExit: React.FC<{
  exitFrame: number;
  duration?: number;
  children: React.ReactNode;
}> = ({ exitFrame, duration = 20, children }) => {
  const frame = useCurrentFrame();

  const progress = interpolate(frame, [exitFrame, exitFrame + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.25, 0.1, 0.25, 1),
  });

  // Ruota all'indietro come una porta che cade
  const rotateX = interpolate(progress, [0, 1], [0, 90]);
  const opacity = interpolate(progress, [0, 1], [1, 0]);

  return (
    <div style={{
      perspective: 800,
      transformOrigin: "center top",
    }}>
      <div style={{
        transform: `rotateX(${rotateX}deg)`,
        opacity,
      }}>
        {children}
      </div>
    </div>
  );
};

// Entry complementare: cade dall'alto
const RotateXEntry: React.FC<{
  entryFrame: number;
  duration?: number;
  children: React.ReactNode;
}> = ({ entryFrame, duration = 20, children }) => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame, [entryFrame, entryFrame + duration], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const rotateX = interpolate(progress, [0, 1], [-90, 0]);

  return (
    <div style={{ perspective: 800, transformOrigin: "center bottom" }}>
      <div style={{ transform: `rotateX(${rotateX}deg)` }}>
        {children}
      </div>
    </div>
  );
};
```

**When to use**: More dramatic alternative to fade-out for text/card exits.
The `transformOrigin` controls the "hinge": top = falls backward, bottom = falls forward.
Pair rotateX exit with rotateX entry for a "page flip" feel between content.

---

## 12. Composite Transitions with Dependency Chain

Multiple simultaneous transforms on different elements, with some animations starting ONLY after others complete.

```tsx
const CompositeTransition: React.FC<{ startFrame: number }> = ({ startFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const f = frame - startFrame;

  // Step 1: Video shrink + shift (simultanei, 0-30 frame)
  const shrinkProgress = interpolate(f, [0, 30], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.bezier(0.25, 0.1, 0.25, 1),
  });

  const videoWidth = interpolate(shrinkProgress, [0, 1], [1600, 400]);
  const videoHeight = interpolate(shrinkProgress, [0, 1], [700, 550]);
  const videoX = interpolate(shrinkProgress, [0, 1], [0, 450]);

  // Step 2: Pannello laterale entra da sinistra (simultaneo al shrink)
  const panelX = interpolate(shrinkProgress, [0, 1], [-500, 0]);

  // Step 3: Logo appare SOLO dopo che shrink è completato (dependency!)
  const logoProgress = f >= 35
    ? spring({ frame: f - 35, fps, config: { damping: 14, stiffness: 120 } })
    : 0;

  return (
    <AbsoluteFill>
      {/* Video che si rimpicciolisce e si sposta */}
      <div style={{
        width: videoWidth,
        height: videoHeight,
        transform: `translateX(${videoX}px)`,
      }}>
        <VideoContent />
      </div>

      {/* Pannello che entra simultaneamente */}
      <div style={{ transform: `translateX(${panelX}px)`, width: 400 }}>
        <SidePanel />
      </div>

      {/* Logo DOPO che tutto si è stabilizzato */}
      <div style={{
        opacity: logoProgress,
        transform: `scale(${logoProgress})`,
      }}>
        <Logo />
      </div>
    </AbsoluteFill>
  );
};
```

**When to use**: Complex scene transitions where multiple elements move simultaneously.
The dependency chain (B starts after A completes) prevents visual chaos.
Rule: simultaneous movements for related elements, sequential for dependent elements.
Never animate more than 3 independent transforms at the same time — the viewer can only track so much.
