---
name: component-architecture
description: Reusable component patterns, custom hooks, JSON-driven timelines, and template systems for video
metadata:
  tags: components, architecture, hooks, json-timeline, template, reusable, parametrized
---

How to architect Remotion projects for reusability, maintainability, and template customization.
See [compositions.md](compositions.md) for `<Composition>` registration basics.
See [parameters.md](parameters.md) for Zod schema-based parametrization.

---

## 1. Parametrized Scene Components

Every scene that appears more than once should be a parametrized component. Data in, visual out.

```tsx
// TitleSlide — parametrizzato con testo, highlights, colore
interface TitleSlideProps {
  words: string[];
  highlights?: Array<{ wordIndex: number; color: string }>;
  highlightStartFrame?: number;
  fontSize?: number;
  screenOccupancy?: number; // 0.7 = 70% dello schermo
}

const TitleSlide: React.FC<TitleSlideProps> = ({
  words,
  highlights = [],
  highlightStartFrame = 25,
  fontSize = 140,
  screenOccupancy = 0.7,
}) => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();

  return (
    <AbsoluteFill style={{
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}>
      <div style={{
        width: width * screenOccupancy,
        height: height * screenOccupancy,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        lineHeight: 0.85,
      }}>
        {words.map((word, i) => {
          const entryProgress = spring({
            frame: Math.max(0, frame - i * 5),
            fps,
            config: { damping: 14, stiffness: 120 },
          });

          const hl = highlights.find((h) => h.wordIndex === i);

          return (
            <div
              key={i}
              style={{
                position: "relative",
                opacity: entryProgress,
                transform: `translateY(${(1 - entryProgress) * 30}px)`,
                fontSize,
                fontWeight: 900,
                textTransform: "uppercase",
              }}
            >
              {hl && (
                <HighlightBox
                  color={hl.color}
                  startFrame={highlightStartFrame + i * 3}
                />
              )}
              <span style={{ position: "relative", zIndex: 1 }}>{word}</span>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

// Usage:
// <TitleSlide
//   words={["CHANGE", "YOUR", "DIGITAL", "MINDSET"]}
//   highlights={[{ wordIndex: 2, color: "#CCFF00" }]}
// />
```

**When to use**: Any text-heavy scene that follows a consistent visual pattern.
Props should cover: content (what to show), timing (when to animate), visual overrides (colors, sizes).
Keep defaults sensible — the component should work with just `words` prop.

---

## 2. Animation Primitives Library

5-7 base components that cover 80% of video needs. Compose complex scenes from simple primitives.

```tsx
// Primitive 1: FadeInText — fade + translateY entry
const FadeInText: React.FC<{
  text: string;
  delay?: number;
  fontSize?: number;
  fontWeight?: number;
}> = ({ text, delay = 0, fontSize = 48, fontWeight = 600 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const progress = spring({
    frame: Math.max(0, frame - delay),
    fps,
    config: { damping: 14, stiffness: 120 },
  });

  return (
    <div style={{
      opacity: progress,
      transform: `translateY(${(1 - progress) * 20}px)`,
      fontSize,
      fontWeight,
    }}>
      {text}
    </div>
  );
};

// Primitive 2: MacWindow — macOS window chrome
const MacWindow: React.FC<{ children: React.ReactNode; title?: string }> = ({
  children,
  title = "",
}) => (
  <div style={{
    borderRadius: 12,
    overflow: "hidden",
    boxShadow: "0 25px 50px rgba(0,0,0,0.25)",
    backgroundColor: "#FFFFFF",
  }}>
    <div style={{
      height: 40,
      backgroundColor: "#F3F4F6",
      display: "flex",
      alignItems: "center",
      padding: "0 12px",
      gap: 8,
    }}>
      <div style={{ width: 12, height: 12, borderRadius: "50%", backgroundColor: "#EF4444" }} />
      <div style={{ width: 12, height: 12, borderRadius: "50%", backgroundColor: "#F59E0B" }} />
      <div style={{ width: 12, height: 12, borderRadius: "50%", backgroundColor: "#22C55E" }} />
      {title && <span style={{ marginLeft: 8, fontSize: 13, color: "#6B7280" }}>{title}</span>}
    </div>
    <div style={{ padding: 24 }}>{children}</div>
  </div>
);

// Primitive 3: TerminalBlock — dark terminal window
const TerminalBlock: React.FC<{
  lines: string[];
  typingSpeed?: number;
}> = ({ lines, typingSpeed = 2 }) => {
  const frame = useCurrentFrame();

  return (
    <MacWindow title="Terminal">
      <div style={{
        backgroundColor: "#1E1E1E",
        color: "#4ADE80",
        fontFamily: "JetBrains Mono, monospace",
        fontSize: 18,
        padding: 20,
        minHeight: 200,
      }}>
        {lines.map((line, i) => {
          const lineStart = i * 30; // 30 frame per riga
          const charsVisible = Math.max(0, Math.floor((frame - lineStart) / typingSpeed));
          return (
            <div key={i} style={{ marginBottom: 4 }}>
              <span style={{ color: "#22C55E" }}>$ </span>
              {line.slice(0, charsVisible)}
              {charsVisible < line.length && charsVisible > 0 && (
                <span style={{ opacity: frame % 30 > 15 ? 1 : 0 }}>▋</span>
              )}
            </div>
          );
        })}
      </div>
    </MacWindow>
  );
};

// Primitive 4: ChatBubble — messaggio chat
const ChatBubble: React.FC<{
  message: string;
  isUser?: boolean;
  delay?: number;
}> = ({ message, isUser = false, delay = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const progress = spring({
    frame: Math.max(0, frame - delay),
    fps,
    config: { damping: 12, stiffness: 150 },
  });

  return (
    <div style={{
      alignSelf: isUser ? "flex-end" : "flex-start",
      opacity: progress,
      transform: `scale(${progress}) translateY(${(1 - progress) * 20}px)`,
      backgroundColor: isUser ? "#3B82F6" : "#F3F4F6",
      color: isUser ? "white" : "#1F2937",
      padding: "12px 18px",
      borderRadius: 18,
      maxWidth: "70%",
      fontSize: 20,
    }}>
      {message}
    </div>
  );
};

// Primitive 5: FloatingBubble (alias di ChatBubble con spring più bouncy)
```

**When to use**: Create your primitives library at project start. Reuse across ALL scenes.
Each primitive handles its own animation internally — the parent just provides data + timing.
A good set of 5 primitives can build 80% of a typical promo video.

---

## 3. JSON-Driven Timeline

Define the video timeline as a JSON data structure. Separate data from presentation.

```tsx
// Scene data come JSON
interface SceneConfig {
  type: "text" | "transition" | "product" | "comparison" | "demo" | "cta";
  startFrame: number;
  durationInFrames: number;
  content: Record<string, unknown>;
}

const SCENES: SceneConfig[] = [
  {
    type: "text",
    startFrame: 0,
    durationInFrames: 90,
    content: { lines: ["Remotion is powerful", "Built for developers"] },
  },
  {
    type: "transition",
    startFrame: 90,
    durationInFrames: 60,
    content: { text: "What if... in your Browser?" },
  },
  {
    type: "product",
    startFrame: 150,
    durationInFrames: 120,
    content: { name: "Topview", tagline: "Vibe Editing in the browser" },
  },
  // ... più scene
];

// Componente che renderizza la timeline da JSON
const VideoFromJSON: React.FC<{ scenes: SceneConfig[] }> = ({ scenes }) => {
  const frame = useCurrentFrame();

  // Trova la scena attiva
  const activeScene = scenes.find(
    (s) => frame >= s.startFrame && frame < s.startFrame + s.durationInFrames
  );

  if (!activeScene) return null;

  // Mappa type → componente
  const SCENE_MAP: Record<string, React.FC<any>> = {
    text: TextSequenceScene,
    transition: TransitionScene,
    product: ProductIntroScene,
    comparison: ComparisonScene,
    demo: DemoActionScene,
    cta: CTAScene,
  };

  const SceneComponent = SCENE_MAP[activeScene.type];
  return SceneComponent ? (
    <SceneComponent
      {...activeScene.content}
      localFrame={frame - activeScene.startFrame}
      durationInFrames={activeScene.durationInFrames}
    />
  ) : null;
};
```

**When to use**: For template videos that will be customized for different products/clients.
The JSON can be generated programmatically, stored in a CMS, or edited by non-developers.
Keep the scene `type` → component mapping explicit and simple.
See [calculate-metadata.md](calculate-metadata.md) for dynamic composition props.

---

## 4. Custom Hooks for Animation Logic

Extract reusable animation logic into custom hooks. DRY, testable, composable.

```tsx
// useTypingEffect — restituisce testo parziale con cursor
const useTypingEffect = (
  text: string,
  speed: number = 2,
  startFrame: number = 0
): { visibleText: string; showCursor: boolean } => {
  const frame = useCurrentFrame();
  const elapsed = Math.max(0, frame - startFrame);
  const charsVisible = Math.min(Math.floor(elapsed / speed), text.length);

  return {
    visibleText: text.slice(0, charsVisible),
    showCursor: charsVisible < text.length && elapsed > 0,
  };
};

// useSpringEntry — spring con delay e config
const useSpringEntry = (
  delay: number = 0,
  config?: Partial<{ damping: number; stiffness: number; mass: number }>
): number => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({
    frame: Math.max(0, frame - delay),
    fps,
    config: { damping: 14, stiffness: 120, mass: 0.6, ...config },
  });
};

// useStagger — calcola delay per un elemento in una lista
const useStagger = (
  index: number,
  gap: number = 8,
  baseDelay: number = 0
): number => {
  return baseDelay + index * gap;
};

// Usage combinato
const MyComponent: React.FC<{ index: number }> = ({ index }) => {
  const delay = useStagger(index, 8, 10);
  const progress = useSpringEntry(delay, { damping: 12 });
  const { visibleText, showCursor } = useTypingEffect("Hello World", 3, delay);

  return (
    <div style={{ opacity: progress, transform: `translateY(${(1 - progress) * 20}px)` }}>
      {visibleText}{showCursor && "▋"}
    </div>
  );
};
```

**When to use**: When the same animation logic appears in 2+ components.
Hooks handle the LOGIC (timing, calculation), components handle the VISUAL (rendering, styling).
Keep hooks pure — no side effects, just frame → value transformation.

---

## 5. Three-Phase Component Pattern

Components that "assemble" in 3 overlapping phases, each with its own spring config.

```tsx
// Pattern riutilizzabile per componenti multi-fase
interface PhaseConfig {
  start: number;
  duration: number;
  spring: { damping: number; stiffness: number; mass: number };
}

const useThreePhase = (startFrame: number) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const f = Math.max(0, frame - startFrame);

  const phases: Record<string, PhaseConfig> = {
    pop:   { start: 0,  duration: 15, spring: { damping: 8,  stiffness: 150, mass: 0.8 } },
    slide: { start: 10, duration: 20, spring: { damping: 15, stiffness: 100, mass: 1 } },
    fade:  { start: 20, duration: 20, spring: { damping: 20, stiffness: 120, mass: 1 } },
  };

  const getProgress = (phase: PhaseConfig) =>
    spring({
      frame: Math.max(0, f - phase.start),
      fps,
      config: phase.spring,
    });

  return {
    pop: getProgress(phases.pop),
    slide: getProgress(phases.slide),
    fade: getProgress(phases.fade),
  };
};

// Usage: componente che usa le tre fasi
const AnimatedCard: React.FC<{ startFrame: number }> = ({ startFrame }) => {
  const { pop, slide, fade } = useThreePhase(startFrame);

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <div style={{ transform: `scale(${pop})` }}>🎯</div>
      <div style={{ width: `${slide * 200}px`, height: 60, backgroundColor: "#5865F2" }} />
      <div style={{ opacity: fade }}>@username</div>
    </div>
  );
};
```

**When to use**: Cards, list items, any component with icon + bar/line + text structure.
The overlapping phases (slide starts while pop is still bouncing) prevent dead time.
See [motion-design-principles.md](motion-design-principles.md) rule #8 for the principle.

---

## 6. Sub-Component Internal Timeline

Components with their own internal micro-choreography, driven by a local frame offset.

```tsx
// Bottone con timeline interna
const AnimatedButton: React.FC<{
  label: string;
  startFrame: number;
}> = ({ label, startFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const localFrame = Math.max(0, frame - startFrame);

  // Internal timeline del bottone
  // Frame 0-10: container appare
  const containerProgress = spring({
    frame: localFrame,
    fps,
    config: { damping: 15, stiffness: 100 },
  });

  // Frame 5-20: freccia interna scorre da sinistra a destra
  const arrowX = interpolate(localFrame, [5, 20], [-30, 30], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // Frame 20+: quando freccia raggiunge il bordo destro, testo appare
  const textOpacity = localFrame >= 20
    ? spring({ frame: localFrame - 20, fps, config: { damping: 20, stiffness: 120 } })
    : 0;

  return (
    <div style={{
      opacity: containerProgress,
      transform: `scale(${containerProgress})`,
      display: "flex",
      alignItems: "center",
      padding: "16px 32px",
      borderRadius: 12,
      backgroundColor: "#3B82F6",
      color: "white",
      gap: 12,
    }}>
      <span style={{ transform: `translateX(${arrowX}px)` }}>→</span>
      <span style={{ opacity: textOpacity, fontWeight: 700 }}>{label}</span>
    </div>
  );
};
```

**When to use**: Any interactive-looking component (buttons, dialogs, form elements).
The internal timeline creates micro-choreography that makes the component feel "alive".
Use `localFrame = frame - startFrame` to make the component self-contained and reusable.

---

## 7. Template Customization System

Define variables at the top of the project that can be swapped to rebrand the entire video.

```tsx
// config.ts — tutte le variabili personalizzabili in un posto
export const VIDEO_CONFIG = {
  // Brand
  brandName: "Topview",
  tagline: "Vibe Editing in your Browser",
  logoUrl: "/public/logo.png",
  ctaUrl: "topview.ai",
  ctaText: "Try it free",

  // Colors (max 4 — see color-and-mood.md rule #5)
  colors: {
    bg: "#FFF5F0",
    text: "#1A1A2E",
    accent1: "#FF7D00",
    accent2: "#8B5CF6",
  },

  // Typography
  fontFamily: "Inter",
  headingWeight: 800,
  bodyWeight: 400,

  // Timing
  fps: 30,
  totalDuration: 750, // 25s @30fps
};

// Usage nei componenti
import { VIDEO_CONFIG } from "./config";

const Headline: React.FC<{ text: string }> = ({ text }) => (
  <h1 style={{
    fontFamily: VIDEO_CONFIG.fontFamily,
    fontWeight: VIDEO_CONFIG.headingWeight,
    color: VIDEO_CONFIG.colors.text,
  }}>
    {text}
  </h1>
);
```

**When to use**: For any video that might be adapted for different products/clients.
Centralize ALL customizable values. A client should only need to edit `config.ts`.
Keep the number of variables manageable (9-15). Too many defeats the purpose of a template.
See [parameters.md](parameters.md) for Zod schema-based parametrization with Remotion Studio.

---

## 8. Per-Phase Spring Configs

Different animation phases use different spring configs to communicate "weight" and "character".

```tsx
// Le spring config NON sono intercambiabili — ognuna ha un significato
export const PHASE_SPRINGS = {
  // Pop — bouncy, leggero, giocoso. Per "apparizione" di icone/elementi piccoli
  pop: { damping: 8, stiffness: 150, mass: 0.8 },

  // Smooth — controllato, professionale. Per "estensione" di barre/pannelli
  smooth: { damping: 15, stiffness: 100, mass: 1 },

  // Gentle — morbido, lento. Per "apparizione" di testo/descrizioni
  gentle: { damping: 20, stiffness: 120, mass: 1 },

  // Impact — basso damping, rimbalzo forte. Per "atterraggio" di elementi pesanti
  impact: { damping: 8, stiffness: 180, mass: 0.5 },

  // Snappy — rapido, reattivo. Per "click" e interazioni
  snappy: { damping: 18, stiffness: 200, mass: 0.4 },
} as const;

// Regola decisionale:
// "Cosa PESA questo elemento?"
// Leggero (icona, dot, badge) → pop o snappy
// Medio (card, panel, barra) → smooth
// Pesante (headline, hero image) → impact
// Etereo (description, caption) → gentle
```

**When to use**: When defining your spring presets (see [motion-design-principles.md](motion-design-principles.md) rule #2).
The spring config should match the "physical weight" of the element being animated.
Heavy elements (headlines) need more damping. Light elements (icons) need more bounce.

---

## 9. Child Follows Parent Transform

When a parent element moves/resizes, child elements must follow its transform for spatial coherence.

```tsx
// Video che si rimpicciolisce + bottone "Register" che segue
const ShrinkWithChild: React.FC<{ shrinkProgress: number }> = ({ shrinkProgress }) => {
  const videoWidth = interpolate(shrinkProgress, [0, 1], [1600, 400]);
  const videoX = interpolate(shrinkProgress, [0, 1], [160, 960]);
  const videoY = interpolate(shrinkProgress, [0, 1], [190, 130]);

  // Il bottone è posizionato RELATIVAMENTE al video, non assoluto nello schermo
  const buttonOffsetX = videoWidth - 150; // sempre a 150px dal bordo destro del video
  const buttonOffsetY = -50; // sempre 50px sopra il video

  return (
    <div style={{
      position: "absolute",
      left: videoX,
      top: videoY,
      width: videoWidth,
    }}>
      <VideoPlayer />

      {/* Bottone che SEGUE il video durante shrink */}
      <div style={{
        position: "absolute",
        right: 20,
        top: buttonOffsetY,
      }}>
        <RegisterButton />
      </div>
    </div>
  );
};
```

**When to use**: Any time a parent container is animated (shrink, shift, resize).
Position children RELATIVE to parent, not with absolute screen coordinates.
If a child "jumps" during parent animation, it's positioned absolutely — make it relative.

---

## 10. Config-First Structure

Start every project with a centralized config file containing ALL project-wide constants.

```tsx
// config.ts — fonte unica di verità per tutto il progetto

// Colori
export const COLORS = {
  bg: "#FFF5F0",
  text: "#1A1A2E",
  accent1: "#FF7D00",
  accent2: "#8B5CF6",
  muted: "#9CA3AF",
} as const;

// Spring presets
export const SPRINGS = {
  standard: { damping: 14, mass: 0.6, stiffness: 120 },
  bouncy:   { damping: 10, mass: 0.5, stiffness: 150 },
  gentle:   { damping: 20, mass: 1,   stiffness: 60 },
  snappy:   { damping: 18, mass: 0.4, stiffness: 200 },
} as const;

// Scene timing
export const SCENE_FRAMES = {
  hook:       { start: 0,   duration: 120 },
  question:   { start: 120, duration: 110 },
  reveal:     { start: 230, duration: 80 },
  benefit:    { start: 310, duration: 130 },
  comparison: { start: 440, duration: 80 },
  feature:    { start: 520, duration: 75 },
  evaluation: { start: 595, duration: 115 },
  cta:        { start: 710, duration: 160 },
} as const;

// Video specs
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL_FRAMES = 870;

// Usage: import { COLORS, SPRINGS, SCENE_FRAMES, FPS } from "./config";
```

**When to use**: EVERY project. Create config.ts BEFORE any component.
Benefits: change one value → entire video updates. No magic numbers scattered across files.
Keep this file SHORT — only project-wide constants, not component-specific values.
The config + JSON timeline (rule #3) + parametrized components (rule #1) = a complete video template system.
