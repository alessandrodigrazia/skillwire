---
name: visual-storytelling
description: Narrative arcs, pacing, scene duration, progressive reveal, and storytelling structures for video
metadata:
  tags: storytelling, narrative, pacing, scene-duration, progressive-reveal, freeze-frame, rhythm
---

How to structure a video's narrative flow, control pacing, and guide the viewer's attention over time.
See [motion-design-principles.md](motion-design-principles.md) for animation-level principles.
See [sequencing.md](sequencing.md) for `<Sequence>` and `<Series>` API usage.

---

## 1. Narrative Arc Structures

Every video needs a dramatic arc. Choose from proven structures based on video length and purpose.

```tsx
// 3-ACT structure (8-15s, quick promo)
const THREE_ACT = [
  { name: "Hook",    frames: 90,  purpose: "Grab attention, present pain" },
  { name: "Demo",    frames: 180, purpose: "Show the solution" },
  { name: "CTA",     frames: 90,  purpose: "Call to action" },
];

// 4-PHASE structure (15-25s, product intro, explainer)
const FOUR_PHASE = [
  { name: "Hook",       frames: 50,  purpose: "Pain point or question" },
  { name: "Transition", frames: 30,  purpose: "Mood shift, background change" },
  { name: "Demo",       frames: 100, purpose: "Interactive proof — longest phase" },
  { name: "CTA",        frames: 60,  purpose: "Logo + action button" },
];

// 6-ACT structure (20-30s, detailed SaaS promo)
const SIX_ACT = [
  { name: "Pain Point",   frames: 60 },
  { name: "Inspiration",  frames: 70 },
  { name: "Hero Reveal",  frames: 50 },
  { name: "Feature Demo", frames: 140 },
  { name: "Social Proof",  frames: 100 },
  { name: "CTA",          frames: 80 },
];

// 8-SCENE structure (25-35s, complete template)
const EIGHT_SCENE = [
  { name: "Hook",       frames: 120 },
  { name: "Question",   frames: 110 },
  { name: "Reveal",     frames: 80 },
  { name: "Benefit",    frames: 130 },
  { name: "Comparison", frames: 80 },
  { name: "Feature",    frames: 75 },
  { name: "Evaluation", frames: 115 },
  { name: "CTA",        frames: 160 },
];

// Usage con JSON-driven timeline
const SCENES = THREE_ACT; // o FOUR_PHASE, SIX_ACT, etc.
const totalFrames = SCENES.reduce((sum, s) => sum + s.frames, 0);
```

**When to use**: 3-act for ads and shorts (under 15s). 4-phase for product intros and explainers.
6-act for SaaS promos with multiple features. 8-scene for complete video templates.
The demo/proof phase is ALWAYS the longest — it's where value is demonstrated.

---

## 2. Pacing by Scene Type

Different scene types need different durations. Emotional scenes are short, informational scenes are long.

```tsx
// Durate raccomandate per tipo di scena @30fps
const SCENE_DURATIONS = {
  hook:        { frames: [60, 120],  seconds: [2, 4],   note: "Short, punchy, grab attention" },
  transition:  { frames: [20, 45],   seconds: [0.7, 1.5], note: "Quick mood shift" },
  demo:        { frames: [120, 240], seconds: [4, 8],   note: "Longest — prove the value" },
  comparison:  { frames: [80, 150],  seconds: [2.7, 5], note: "Before/after, old/new" },
  socialProof: { frames: [90, 150],  seconds: [3, 5],   note: "Grid, testimonials, logos" },
  cta:         { frames: [60, 160],  seconds: [2, 5.3], note: "Logo + button + URL" },
  textSlide:   { frames: [60, 120],  seconds: [2, 4],   note: "Pure typography" },
  videoClip:   { frames: [30, 60],   seconds: [1, 2],   note: "Footage as punctuation" },
};

// Regola empirica: emozione = corto, informazione = lungo
// Hook (60-95f) è CORTO perché genera emozione (curiosità, dolore)
// Demo (144-214f) è LUNGO perché trasferisce informazione (feature, come funziona)
```

**When to use**: As a starting point when estimating total video duration.
If a scene feels too fast, it's probably informational and needs more frames.
If a scene feels slow, it's probably emotional and needs fewer frames.

---

## 3. Variable Rhythm Creates Tension

Alternating fast and slow sections prevents monotony and creates narrative tension.

```tsx
// Pattern "Fast → Slow" — energia poi approfondimento
// Esempio: 5 scene foto rapide (1s each) → sezione tipografica lenta (5-10s)
const SCENES_RHYTHM = [
  { name: "Photo1", frames: 30, type: "fast" },
  { name: "Photo2", frames: 30, type: "fast" },
  { name: "Photo3", frames: 30, type: "fast" },
  { name: "Photo4", frames: 30, type: "fast" },
  { name: "Photo5", frames: 30, type: "fast" },
  // Rallentamento improvviso — contrasto ritmico
  { name: "Typography", frames: 300, type: "slow" },
];

// Pattern "Text → Image → Text → Image" — cadenza alternata
// Le scene immagine sono "respiri" tra blocchi tipografici densi
const ALTERNATING_RHYTHM = [
  { name: "Quote",        frames: 120, type: "text" },
  { name: "CityDrone",    frames: 45,  type: "image" }, // respiro visivo
  { name: "Statement",    frames: 90,  type: "text" },
  { name: "NatureShot",   frames: 45,  type: "image" }, // respiro visivo
  { name: "Question",     frames: 120, type: "text" },
  { name: "Architecture", frames: 30,  type: "image" }, // respiro visivo
  { name: "Conclusion",   frames: 120, type: "text" },
];
```

**When to use**: Always plan rhythm variations. A video with uniform scene lengths feels monotone.
The fast→slow transition is the most powerful: rapid energy buildup followed by a deliberate slowdown.
Text/image alternation works well for kinetic typography videos — the images reset the viewer's attention.

---

## 4. Background Change as Narrative Beat

A background color shift marks the beginning of a new narrative phase. See [color-and-mood.md](color-and-mood.md) rule #2.

```tsx
// Background change coincide con cambio narrativo
// Fase 1 (Hook): Cream — warm, friendly, approachable
// Fase 2 (Demo): Blue gradient — technical, capable
// Fase 3 (CTA): Dark — dramatic, authoritative

const NarrativeBg: React.FC = () => {
  const frame = useCurrentFrame();

  // Non cambiare background a caso — ogni cambio = nuovo atto narrativo
  const phase =
    frame < 90 ? "hook" :
    frame < 270 ? "demo" :
    "cta";

  const bgColors = {
    hook: "#FFF8F0",
    demo: "linear-gradient(135deg, #0891B2, #1E3A5F)",
    cta:  "radial-gradient(circle, #1a1a2e, #000000)",
  };

  return <AbsoluteFill style={{ background: bgColors[phase] }} />;
};
```

**When to use**: At major narrative transitions (hook→demo, demo→CTA).
Never change background for minor scene changes — it breaks visual continuity.
The change should be fast (20-30 frames) and coincide with content transition.

---

## 5. Progressive Reveal (Accumulative)

In educational/explanatory videos, elements ACCUMULATE on screen. Never remove what was already shown.

```tsx
// Diagramma che si costruisce progressivamente
const ProgressiveDiagram: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Fase 1: Triangolo base (frame 0-60)
  const showTriangle = frame >= 0;

  // Fase 2: Labels ai vertici (frame 30-90) — appaiono SENZA rimuovere triangolo
  const showLabels = frame >= 30;

  // Fase 3: Quadrato sul lato A (frame 90-150) — si aggiunge al diagramma
  const showSquareA = frame >= 90;

  // Fase 4: Quadrato sul lato B (frame 150-210) — si aggiunge
  const showSquareB = frame >= 150;

  // Fase 5: Formula finale (frame 210+) — tutto resta visibile
  const showFormula = frame >= 210;

  return (
    <AbsoluteFill>
      {showTriangle && <Triangle />}
      {showLabels && <VertexLabels />}
      {showSquareA && <SquareOnSideA />}
      {showSquareB && <SquareOnSideB />}
      {showFormula && <FormulaDisplay />}
    </AbsoluteFill>
  );
};
```

**When to use**: Math/science explanations. Step-by-step tutorials. Process diagrams.
Critical rule: NEVER remove previously shown elements. The diagram builds up.
Each new element enters with animation (spring, fade), but old elements stay put.
This supports **dual-channel learning** — the viewer reads new info while reviewing old info.

---

## 6. Freeze Frame for Assimilation

The last 1-3 seconds of a scene should be static — no new animations. Let the viewer process.

```tsx
// Scena con freeze frame finale
const SceneWithFreeze: React.FC<{
  contentDuration: number;
  freezeDuration: number;
}> = ({ contentDuration, freezeDuration }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Tutte le animazioni completano entro contentDuration
  const animProgress = interpolate(frame, [0, contentDuration], [0, 1], {
    extrapolateRight: "clamp",
  });

  // Da contentDuration a contentDuration + freezeDuration: niente si muove
  // Il diagramma completo è visibile, immobile, per assimilazione

  return (
    <AbsoluteFill>
      {/* Animazioni guidate da animProgress — ferme dopo contentDuration */}
      <DiagramComplete progress={animProgress} />
    </AbsoluteFill>
  );
};

// Usage nella timeline
// <Sequence durationInFrames={contentDuration + freezeDuration}>
//   <SceneWithFreeze contentDuration={120} freezeDuration={60} />
// </Sequence>
```

**When to use**: After educational scenes where the viewer needs to absorb a complete diagram.
After the final CTA — hold the logo/URL visible for 1-2 seconds.
After a dramatic reveal — let the "wow" moment sink in.
Rule: allocate at least 30 frames (1s @30fps) of freeze at the end of informational scenes.

---

## 7. Video Clips as Punctuation

Short video clips (1-2 seconds) between text scenes act as visual separators, not content.

```tsx
// Video "respiro" di 1.5 secondi tra scene di testo
const VideoPunctuation: React.FC<{ src: string }> = ({ src }) => {
  const { fps } = useVideoConfig();
  return (
    <Sequence durationInFrames={Math.round(1.5 * fps)}>
      <AbsoluteFill>
        <Video
          src={src}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
      </AbsoluteFill>
    </Sequence>
  );
};

// Timeline con video come punteggiatura
// TextScene1 → VideoPunctuation(cityscape) → TextScene2 → VideoPunctuation(nature) → TextScene3
```

**When to use**: In kinetic typography videos between dense text blocks.
The clip is too short to "read" (1-2s) — its job is to reset the viewer's visual attention.
Choose visually striking clips (cityscape, nature, architecture) that don't require context.
Use hard cuts (no transition) — the medium change itself IS the transition.

---

## 8. Clear Screen Before Final Message

Empty the screen completely before showing the final message or CTA. The void creates maximum impact.

```tsx
const ClearAndReveal: React.FC<{
  clearStartFrame: number;
  revealFrame: number;
  message: string;
}> = ({ clearStartFrame, revealFrame, message }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Fase 1: elementi escono alternando sinistra/destra
  const exitProgress = interpolate(frame, [clearStartFrame, clearStartFrame + 30], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // Fase 2: schermo vuoto per ~15 frame (0.5s di "vuoto")

  // Fase 3: messaggio finale appare su schermo vuoto
  const messageProgress = frame >= revealFrame
    ? spring({ frame: frame - revealFrame, fps, config: { damping: 14, stiffness: 120 } })
    : 0;

  return (
    <AbsoluteFill style={{ backgroundColor: "#000000" }}>
      {frame < clearStartFrame + 45 && (
        <div style={{ opacity: 1 - exitProgress }}>Previous content</div>
      )}
      <div style={{
        opacity: messageProgress,
        transform: `scale(${interpolate(messageProgress, [0, 1], [0.8, 1])})`,
        fontSize: 96,
        fontWeight: 900,
        color: "#FFFFFF",
        textAlign: "center",
      }}>
        {message}
      </div>
    </AbsoluteFill>
  );
};
```

**When to use**: As the finale of kinetic typography or brand opener videos.
The empty screen (even just 0.5s) creates anticipation — the viewer expects something.
The final message on a clean background gets 100% of the viewer's attention.

---

## 9. Text-Image Cadence

Alternating text and image scenes creates a reading rhythm that sustains attention over longer videos.

```tsx
// Schema: Testo (2-4s) → Immagine (1-2s) → Testo (2-4s) → Immagine (1-2s) → ...
// Il ritmo crea aspettativa: il viewer sa che dopo il testo arriva una "pausa visiva"

type SceneType = "text" | "image";
interface SceneConfig {
  type: SceneType;
  durationInFrames: number;
  content: string | string; // testo o path video
}

const CADENCE: SceneConfig[] = [
  { type: "text",  durationInFrames: 120, content: "THE FUTURE\nIS NOW" },
  { type: "image", durationInFrames: 45,  content: "/public/drone-city.mp4" },
  { type: "text",  durationInFrames: 90,  content: "CHANGE YOUR\nMINDSET" },
  { type: "image", durationInFrames: 45,  content: "/public/fjord.mp4" },
  { type: "text",  durationInFrames: 120, content: "WHAT HAPPENED\nNEXT?" },
  { type: "image", durationInFrames: 30,  content: "/public/arch.mp4" },
  { type: "text",  durationInFrames: 120, content: "NEXT\nTODAY\nLEVEL" },
];
```

**When to use**: Videos longer than 15 seconds that are primarily text/typography.
The image scenes prevent "text fatigue" and act as visual rest points.
Keep image scenes SHORT (1-2s) — they're punctuation, not content. See rule #7.

---

## 10. Duration as Information Density

Allocate screen time proportionally to the complexity/importance of the information.

```tsx
// Regola: tempo ∝ densità informativa
const TIME_ALLOCATION = {
  // Setup / orientamento — l'utente capisce il contesto (VELOCE)
  setup: { ratio: 0.1, note: "Just enough to orient — 10% of video" },

  // Demo / spiegazione — l'utente apprende qualcosa (LENTO)
  demo: { ratio: 0.5, note: "Core value — 50% of video" },

  // Climax / reveal — momento di massimo impatto (MEDIO + PAUSA)
  climax: { ratio: 0.2, note: "Impact + freeze frame — 20% of video" },

  // CTA / chiusura — azione finale (BREVE)
  cta: { ratio: 0.2, note: "Clear, memorable — 20% of video" },
};

// Per un video di 30s (900 frame @30fps):
// Setup:  90 frame (3s)   — rapido orientamento
// Demo:   450 frame (15s) — cuore del video
// Climax: 180 frame (6s)  — impatto + freeze
// CTA:    180 frame (6s)  — azione + URL persistente
```

**When to use**: As a planning tool when designing the video timeline.
The demo/explanation phase should always be the longest section (40-50% of total).
If setup is longer than CTA, the video is probably slow to start — cut the intro.
If CTA is longer than demo, you're selling without proving — expand the demo.
