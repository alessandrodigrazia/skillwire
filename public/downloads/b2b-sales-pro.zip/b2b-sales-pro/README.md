# B2B Sales Pro — Skillwire Bundle

This bundle contains 4 skills. Install each one individually:

- ai-b2b-sales-methodology.zip
- b2b-presentation-builder.zip
- janus.zip
- deep-research-agent.zip

## Installation

For each skill ZIP:
- **Claude Code**: extract into ~/.claude/skills/ and you're done
- **Claude Desktop**: Settings → Features → Skills → Add, then upload the ZIP

Questions? hello@skillwire.ai
