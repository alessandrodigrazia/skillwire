# Career Navigator — Skillwire Bundle

This bundle contains 4 skills. Install each one individually:

- ask-to-vera.zip
- ask-to-andrew.zip
- cv-guru.zip
- human-writer.zip

## Installation

For each skill ZIP:
- **Claude Code**: extract into ~/.claude/skills/ and you're done
- **Claude Desktop**: Settings → Features → Skills → Add, then upload the ZIP

Questions? hello@skillwire.ai
