#!/usr/bin/env python3
"""
Interview Briefing DOCX Generator

Generates an interview preparation document in DOCX format
from a structured JSON.

Requirements:
    pip install python-docx

Usage:
    python generate_briefing_docx.py --input briefing.json --output Briefing_Name.docx

    Or from Claude:
    - Save the briefing JSON to a temporary file
    - Run the script with the appropriate parameters
"""

import json
import argparse
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE


# Theme colors
COLORS = {
    'primary': RGBColor(0x2F, 0x54, 0x96),  # Professional blue
    'secondary': RGBColor(0x2E, 0x3A, 0x59),  # Dark gray
    'success': RGBColor(0x28, 0xA7, 0x45),  # Green
    'warning': RGBColor(0xDC, 0x35, 0x45),  # Red
}


def setup_styles(doc):
    """Configure document styles."""
    styles = doc.styles

    # Main title style
    if 'BriefingTitle' not in [s.name for s in styles]:
        style = styles.add_style('BriefingTitle', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(24)
        style.font.bold = True
        style.font.color.rgb = COLORS['secondary']
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style.paragraph_format.space_after = Pt(6)

    # Subtitle style
    if 'BriefingSubtitle' not in [s.name for s in styles]:
        style = styles.add_style('BriefingSubtitle', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(14)
        style.font.italic = True
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style.paragraph_format.space_after = Pt(12)

    # Section style
    if 'BriefingSection' not in [s.name for s in styles]:
        style = styles.add_style('BriefingSection', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(14)
        style.font.bold = True
        style.font.color.rgb = COLORS['primary']
        style.paragraph_format.space_before = Pt(16)
        style.paragraph_format.space_after = Pt(8)

    # Question style
    if 'BriefingQuestion' not in [s.name for s in styles]:
        style = styles.add_style('BriefingQuestion', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.font.bold = True
        style.font.italic = True
        style.paragraph_format.space_before = Pt(8)
        style.paragraph_format.space_after = Pt(4)

    # Normal style
    if 'BriefingNormal' not in [s.name for s in styles]:
        style = styles.add_style('BriefingNormal', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.paragraph_format.space_after = Pt(4)


def add_section_header(doc, emoji, title):
    """Add a section header with emoji."""
    p = doc.add_paragraph(style='BriefingSection')
    p.add_run(f'{emoji} {title}')


def add_header(doc, job_title, company, candidate_name):
    """Add the document header."""
    doc.add_paragraph('Interview Briefing', style='BriefingTitle')
    doc.add_paragraph(f'{job_title} at {company}', style='BriefingSubtitle')

    p = doc.add_paragraph(style='BriefingNormal')
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run('Candidate: ').bold = True
    p.add_run(candidate_name)


def add_objective(doc, objective):
    """Add the objective section."""
    if not objective:
        return
    add_section_header(doc, '🎯', 'Objective')
    doc.add_paragraph(objective, style='BriefingNormal')


def add_key_messages(doc, messages):
    """Add the key messages."""
    if not messages:
        return
    add_section_header(doc, '💬', 'Key Messages')
    for i, msg in enumerate(messages, 1):
        p = doc.add_paragraph(style='BriefingNormal')
        p.add_run(f'{i}. ').bold = True
        p.add_run(msg)


def add_likely_questions(doc, questions):
    """Add the likely questions with guidance."""
    if not questions:
        return
    add_section_header(doc, '❓', 'Likely Questions')

    for q in questions:
        question = q if isinstance(q, str) else q.get('question', '')
        guidance = '' if isinstance(q, str) else q.get('guidance', '')

        doc.add_paragraph(f'"{question}"', style='BriefingQuestion')
        if guidance:
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('Guidance: ').bold = True
            p.add_run(guidance)


def add_star_stories(doc, stories):
    """Add the STAR stories."""
    if not stories:
        return
    add_section_header(doc, '📖', 'STAR Stories to Tell')

    for story in stories:
        if isinstance(story, str):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('• ').bold = True
            p.add_run(story)
        else:
            # Full STAR format
            hook = story.get('hook', 'Story')
            p = doc.add_paragraph(style='BriefingQuestion')
            p.add_run(hook)

            for key, label in [('situation', 'Situation'), ('task', 'Task'),
                              ('action', 'Action'), ('result', 'Result')]:
                if story.get(key):
                    p = doc.add_paragraph(style='BriefingNormal')
                    p.add_run(f'{label}: ').bold = True
                    p.add_run(story[key])

            if story.get('metrics'):
                p = doc.add_paragraph(style='BriefingNormal')
                p.add_run('Metrics: ').bold = True
                p.add_run(story['metrics'])


def add_red_flags(doc, red_flags, how_to_handle):
    """Add the red flags and how to handle them."""
    if not red_flags:
        return
    add_section_header(doc, '⚠️', 'Red Flags to Manage')

    for i, flag in enumerate(red_flags):
        p = doc.add_paragraph(style='BriefingNormal')
        p.add_run('• ').bold = True
        run = p.add_run(flag)
        run.font.color.rgb = COLORS['warning']

        # Add how to handle if available
        if how_to_handle and i < len(how_to_handle):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('  ➔ How to handle: ').bold = True
            p.add_run(how_to_handle[i])


def add_interviewer_matrix(doc, matrix):
    """Add the interviewer matrix."""
    if not matrix:
        return
    add_section_header(doc, '👥', 'Interviewer Matrix')

    for interviewer in matrix:
        # Role and stage
        p = doc.add_paragraph(style='BriefingQuestion')
        role = interviewer.get('role', 'Interviewer')
        stage = interviewer.get('stage', '')
        p.add_run(f'{role}')
        if stage:
            p.add_run(f' ({stage})')

        # Wants
        if interviewer.get('wants'):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('Looking for: ').bold = True
            p.add_run(', '.join(interviewer['wants']))

        # Risks
        if interviewer.get('risks'):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('Risks: ').bold = True
            run = p.add_run(', '.join(interviewer['risks']))
            run.font.color.rgb = COLORS['warning']

        # Traps
        if interviewer.get('traps'):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('Traps: ').bold = True
            p.add_run(', '.join(interviewer['traps']))


def add_discovery_questions(doc, questions):
    """Add the questions to ask."""
    if not questions:
        return
    add_section_header(doc, '🙋', 'Questions to Ask')
    for q in questions:
        p = doc.add_paragraph(style='BriefingNormal')
        p.add_run('• ').bold = True
        p.add_run(q)


def add_closing_pitch(doc, pitch):
    """Add the closing pitch."""
    if not pitch:
        return
    add_section_header(doc, '🎤', 'Closing Pitch')
    p = doc.add_paragraph(style='BriefingNormal')
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f'"{pitch}"')
    run.italic = True


def add_next_steps(doc, steps):
    """Add the next steps."""
    if not steps:
        return
    add_section_header(doc, '➡️', 'Next Steps')
    for step in steps:
        p = doc.add_paragraph(style='BriefingNormal')
        p.add_run('☐ ').bold = True
        p.add_run(step)


def generate_briefing_docx(briefing_json, output_path, job_title='', company='', candidate_name=''):
    """
    Generate the DOCX document from the briefing JSON.

    Args:
        briefing_json: dict with briefing data
        output_path: output file path
        job_title: role title
        company: company name
        candidate_name: candidate name
    """
    doc = Document()

    # Set margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(0.75)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)

    # Setup styles
    setup_styles(doc)

    # Header
    add_header(doc, job_title, company, candidate_name)

    # Briefing sections
    add_objective(doc, briefing_json.get('objective'))
    add_key_messages(doc, briefing_json.get('keyMessages'))
    add_likely_questions(doc, briefing_json.get('likelyQuestions'))

    # STAR Stories
    stories = briefing_json.get('storyBankSTAR') or briefing_json.get('storiesToTell')
    add_star_stories(doc, stories)

    # Red flags
    add_red_flags(doc, briefing_json.get('redFlags'), briefing_json.get('howToHandle'))

    # Interviewer matrix
    add_interviewer_matrix(doc, briefing_json.get('interviewerMatrix'))

    # Discovery questions
    questions = briefing_json.get('discoveryQuestions') or briefing_json.get('closingQuestions')
    add_discovery_questions(doc, questions)

    # Closing pitch
    add_closing_pitch(doc, briefing_json.get('closingPitch'))

    # Next steps
    add_next_steps(doc, briefing_json.get('nextSteps'))

    # Save document
    doc.save(output_path)
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Generate interview briefing in DOCX format')
    parser.add_argument('--input', '-i', required=True, help='Briefing JSON file')
    parser.add_argument('--output', '-o', required=True, help='Output DOCX file')
    parser.add_argument('--job-title', '-j', default='Position', help='Role title')
    parser.add_argument('--company', '-c', default='Company', help='Company name')
    parser.add_argument('--candidate', '-n', default='Candidate', help='Candidate name')

    args = parser.parse_args()

    # Read JSON
    with open(args.input, 'r', encoding='utf-8') as f:
        briefing_json = json.load(f)

    # Generate DOCX
    output = generate_briefing_docx(
        briefing_json,
        args.output,
        job_title=args.job_title,
        company=args.company,
        candidate_name=args.candidate
    )
    print(f"Briefing generated: {output}")


if __name__ == '__main__':
    main()
