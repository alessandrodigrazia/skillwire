# Reference: Layout Profiles

## Panoramica

I Layout Profiles definiscono la struttura e le sezioni del CV in base al tipo di ruolo e industria target. Ogni profilo enfatizza aspetti diversi dell'esperienza del candidato.

## Profili Disponibili

### 1. STANDARD

**Ideale per**: Ruoli generalisti, prime esperienze, candidature multiple.

**Struttura**:
```
├── Header (nome, contatti)
├── Profile/Summary
├── Work Experience (cronologico inverso)
├── Education
└── Skills
```

**Caratteristiche**:
- Formato universale, accettato ovunque
- Cronologico inverso standard
- Bilanciato tra esperienza e competenze
- ATS-friendly al massimo

**Quando usare**:
- Non si conosce bene l'azienda target
- Ruoli mid-level generalisti
- Candidature su job board

---

### 2. EXECUTIVE

**Ideale per**: C-level, VP, Director, Senior Management.

**Struttura**:
```
├── Header
├── Executive Profile (statement strategico)
├── Key Achievements (3-5 bullet impatto)
├── Work Experience (condensato, focus leadership)
├── Board & Advisory Roles
├── Education & Executive Education
└── Leadership & Skills
```

**Sezioni Specifiche**:

```json
{
  "keyAchievements": [
    "Guidato turnaround da -5M€ a +15M€ EBITDA in 24 mesi",
    "Costruito organizzazione da 0 a 200 FTE in 3 paesi",
    "Negoziato acquisizione strategica da 50M€"
  ],
  "leadership": [
    {
      "role": "Board Member",
      "organization": "Industry Association",
      "dates": "2020 - presente"
    }
  ]
}
```

**Caratteristiche**:
- Summary più lungo e strategico
- Achievement-focused vs task-focused
- Esperienza condensata (no dettagli operativi)
- Enfasi su impatto business e leadership
- Include ruoli advisory/board

---

### 3. TECHNICAL

**Ideale per**: Developer, Engineer, Architect, Data Scientist, DevOps.

**Struttura**:
```
├── Header
├── Technical Profile
├── Tech Stack (visual)
├── Key Projects
├── Work Experience (dettagliato tecnicamente)
├── Open Source / Side Projects
├── Certifications
├── Education
└── Skills (categorizzate)
```

**Sezioni Specifiche**:

```json
{
  "techStack": {
    "languages": ["Python", "Go", "TypeScript"],
    "frameworks": ["React", "FastAPI", "Django"],
    "databases": ["PostgreSQL", "MongoDB", "Redis"],
    "cloud": ["AWS", "GCP", "Kubernetes"],
    "tools": ["Docker", "Terraform", "GitHub Actions"]
  },
  "projects": [
    {
      "name": "Real-time Analytics Platform",
      "description": "Piattaforma streaming per 1M+ eventi/sec",
      "technologies": ["Kafka", "Flink", "ClickHouse"],
      "impact": "Riduzione latency 80%, cost saving 200K€/anno",
      "link": "github.com/user/project"
    }
  ]
}
```

**Caratteristiche**:
- Tech stack prominente e dettagliato
- Progetti con specifiche tecniche
- Metriche di performance (latency, throughput)
- Link a GitHub/portfolio
- Certificazioni tecniche evidenziate

---

### 4. CREATIVE

**Ideale per**: Designer, UX/UI, Marketing, Content, Brand.

**Struttura**:
```
├── Header (con link portfolio)
├── Creative Profile
├── Selected Works / Portfolio Highlights
├── Work Experience (condensato)
├── Clients & Brands
├── Awards & Recognition
├── Education
└── Skills & Tools
```

**Sezioni Specifiche**:

```json
{
  "selectedWorks": [
    {
      "title": "Brand Redesign - TechCorp",
      "type": "Branding",
      "description": "Rebranding completo per scale-up tech",
      "impact": "+40% brand recognition, Awwwards nomination",
      "link": "behance.net/project/techcorp"
    }
  ],
  "awards": [
    "Awwwards - Site of the Day (2023)",
    "Red Dot Design Award (2022)"
  ],
  "clients": ["Nike", "Spotify", "Airbnb"]
}
```

**Caratteristiche**:
- Portfolio integrato o linkato
- Esperienza più condensata
- Focus su progetti e risultati creativi
- Lista clienti/brand
- Awards e riconoscimenti prominenti

---

### 5. CORPORATE

**Ideale per**: Finance, Legal, Consulting, Banking, Big 4.

**Struttura**:
```
├── Header
├── Professional Profile
├── Work Experience (dettagliato, formale)
├── Education & Professional Qualifications
├── Certifications & Licenses
├── Publications / Speaking
└── Skills & Languages
```

**Caratteristiche**:
- Tono formale e conservativo
- Esperienza molto dettagliata
- Titoli di studio e certificazioni prominenti
- Ordini professionali (es. commercialisti, avvocati)
- Pubblicazioni se rilevanti

**Enfasi su**:
- Istituzioni prestigiose
- Qualifiche professionali
- Track record di deal/transazioni
- Clienti enterprise

---

### 6. STARTUP

**Ideale per**: Founder, Startup employee, VC-backed companies, Scale-up.

**Struttura**:
```
├── Header
├── Founder/Operator Profile
├── Impact Highlights (metriche di crescita)
├── Venture Experience
├── Work Experience (focus su scaling)
├── Projects / Side Ventures
├── Education
└── Skills
```

**Sezioni Specifiche**:

```json
{
  "impactHighlights": [
    "0→1: Lanciato prodotto da idea a 50K MAU in 8 mesi",
    "Scaling: Cresciuto team da 3 a 30 persone in 18 mesi",
    "Fundraising: Lead round Seed da 2M€",
    "Exit: Venduto side project per 500K€"
  ],
  "ventures": [
    {
      "name": "TechStartup",
      "role": "Co-founder & CTO",
      "dates": "2020 - 2023",
      "stage": "Seed → Series A",
      "highlights": "Raised 5M€, grew to 40 FTE, 2M€ ARR"
    }
  ]
}
```

**Caratteristiche**:
- Focus su metriche di crescita (MAU, ARR, MRR)
- Esperienza di fundraising
- Velocità di execution
- Comfort con ambiguità
- Side projects valorizzati

---

## Mapping Ruolo → Layout

| Ruolo Target | Layout Consigliato |
|--------------|-------------------|
| Software Engineer | Technical |
| Data Scientist | Technical |
| Product Manager | Standard o Startup |
| Project Manager | Standard o Corporate |
| CEO, CFO, COO | Executive |
| VP Engineering | Executive + Technical |
| Marketing Manager | Creative o Standard |
| UX Designer | Creative |
| Investment Banker | Corporate |
| Management Consultant | Corporate |
| Startup Founder | Startup |
| Growth Hacker | Startup |

## Sezioni Comuni vs Specifiche

### Sempre Presenti (tutti i layout)
- contactInfo
- summary/profile
- workExperience
- education
- skills

### Opzionali per Layout

| Sezione | Standard | Executive | Technical | Creative | Corporate | Startup |
|---------|----------|-----------|-----------|----------|-----------|---------|
| keyAchievements | - | ✓ | - | - | - | - |
| leadership | - | ✓ | - | - | - | - |
| techStack | - | - | ✓ | - | - | - |
| projects | - | - | ✓ | - | - | ✓ |
| selectedWorks | - | - | - | ✓ | - | - |
| awards | - | - | - | ✓ | - | - |
| certifications | - | - | ✓ | - | ✓ | - |
| publications | - | - | - | - | ✓ | - |
| impactHighlights | - | - | - | - | - | ✓ |
| ventures | - | - | - | - | - | ✓ |

## Adattamento Dinamico

Se il candidato ha elementi di più profili, combinare:

**Esempio**: CTO di Startup
- Base: Executive (per seniority)
- Aggiungi: techStack (competenze tecniche)
- Aggiungi: impactHighlights (metriche startup)
- Aggiungi: ventures (storia imprenditoriale)
