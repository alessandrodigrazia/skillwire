# Reference: Layout Profiles

## Overview

Layout Profiles define the structure and sections of the CV based on the type of target role and industry. Each profile emphasizes different aspects of the candidate's experience.

## Available Profiles

### 1. STANDARD

**Ideal for**: Generalist roles, first experiences, multiple applications.

**Structure**:
```
├── Header (name, contacts)
├── Profile/Summary
├── Work Experience (reverse chronological)
├── Education
└── Skills
```

**Characteristics**:
- Universal format, accepted everywhere
- Standard reverse chronological
- Balanced between experience and skills
- Maximum ATS-friendliness

**When to use**:
- Target company not well known
- Mid-level generalist roles
- Applications on job boards

---

### 2. EXECUTIVE

**Ideal for**: C-level, VP, Director, Senior Management.

**Structure**:
```
├── Header
├── Executive Profile (strategic statement)
├── Key Achievements (3-5 impact bullets)
├── Work Experience (condensed, leadership focus)
├── Board & Advisory Roles
├── Education & Executive Education
└── Leadership & Skills
```

**Specific Sections**:

```json
{
  "keyAchievements": [
    "Led turnaround from -5M to +15M EBITDA in 24 months",
    "Built organization from 0 to 200 FTE across 3 countries",
    "Negotiated strategic acquisition worth 50M"
  ],
  "leadership": [
    {
      "role": "Board Member",
      "organization": "Industry Association",
      "dates": "2020 - present"
    }
  ]
}
```

**Characteristics**:
- Longer and more strategic summary
- Achievement-focused vs task-focused
- Condensed experience (no operational details)
- Emphasis on business impact and leadership
- Includes advisory/board roles

---

### 3. TECHNICAL

**Ideal for**: Developer, Engineer, Architect, Data Scientist, DevOps.

**Structure**:
```
├── Header
├── Technical Profile
├── Tech Stack (visual)
├── Key Projects
├── Work Experience (technically detailed)
├── Open Source / Side Projects
├── Certifications
├── Education
└── Skills (categorized)
```

**Specific Sections**:

```json
{
  "techStack": {
    "languages": ["Python", "Go", "TypeScript"],
    "frameworks": ["React", "FastAPI", "Django"],
    "databases": ["PostgreSQL", "MongoDB", "Redis"],
    "cloud": ["AWS", "GCP", "Kubernetes"],
    "tools": ["Docker", "Terraform", "GitHub Actions"]
  },
  "projects": [
    {
      "name": "Real-time Analytics Platform",
      "description": "Streaming platform for 1M+ events/sec",
      "technologies": ["Kafka", "Flink", "ClickHouse"],
      "impact": "80% latency reduction, 200K/year cost saving",
      "link": "github.com/user/project"
    }
  ]
}
```

**Characteristics**:
- Prominent and detailed tech stack
- Projects with technical specifications
- Performance metrics (latency, throughput)
- Links to GitHub/portfolio
- Technical certifications highlighted

---

### 4. CREATIVE

**Ideal for**: Designer, UX/UI, Marketing, Content, Brand.

**Structure**:
```
├── Header (with portfolio link)
├── Creative Profile
├── Selected Works / Portfolio Highlights
├── Work Experience (condensed)
├── Clients & Brands
├── Awards & Recognition
├── Education
└── Skills & Tools
```

**Specific Sections**:

```json
{
  "selectedWorks": [
    {
      "title": "Brand Redesign - TechCorp",
      "type": "Branding",
      "description": "Complete rebranding for tech scale-up",
      "impact": "+40% brand recognition, Awwwards nomination",
      "link": "behance.net/project/techcorp"
    }
  ],
  "awards": [
    "Awwwards - Site of the Day (2023)",
    "Red Dot Design Award (2022)"
  ],
  "clients": ["Nike", "Spotify", "Airbnb"]
}
```

**Characteristics**:
- Integrated or linked portfolio
- More condensed experience
- Focus on projects and creative results
- Client/brand list
- Prominent awards and recognitions

---

### 5. CORPORATE

**Ideal for**: Finance, Legal, Consulting, Banking, Big 4.

**Structure**:
```
├── Header
├── Professional Profile
├── Work Experience (detailed, formal)
├── Education & Professional Qualifications
├── Certifications & Licenses
├── Publications / Speaking
└── Skills & Languages
```

**Characteristics**:
- Formal and conservative tone
- Very detailed experience
- Prominent degrees and certifications
- Professional associations (e.g., CPAs, lawyers)
- Publications if relevant

**Emphasis on**:
- Prestigious institutions
- Professional qualifications
- Deal/transaction track record
- Enterprise clients

---

### 6. STARTUP

**Ideal for**: Founder, Startup employee, VC-backed companies, Scale-up.

**Structure**:
```
├── Header
├── Founder/Operator Profile
├── Impact Highlights (growth metrics)
├── Venture Experience
├── Work Experience (focus on scaling)
├── Projects / Side Ventures
├── Education
└── Skills
```

**Specific Sections**:

```json
{
  "impactHighlights": [
    "0 to 1: Launched product from idea to 50K MAU in 8 months",
    "Scaling: Grew team from 3 to 30 people in 18 months",
    "Fundraising: Led Seed round of 2M",
    "Exit: Sold side project for 500K"
  ],
  "ventures": [
    {
      "name": "TechStartup",
      "role": "Co-founder & CTO",
      "dates": "2020 - 2023",
      "stage": "Seed to Series A",
      "highlights": "Raised 5M, grew to 40 FTE, 2M ARR"
    }
  ]
}
```

**Characteristics**:
- Focus on growth metrics (MAU, ARR, MRR)
- Fundraising experience
- Speed of execution
- Comfort with ambiguity
- Side projects valued

---

## Role to Layout Mapping

| Target Role | Recommended Layout |
|-------------|-------------------|
| Software Engineer | Technical |
| Data Scientist | Technical |
| Product Manager | Standard or Startup |
| Project Manager | Standard or Corporate |
| CEO, CFO, COO | Executive |
| VP Engineering | Executive + Technical |
| Marketing Manager | Creative or Standard |
| UX Designer | Creative |
| Investment Banker | Corporate |
| Management Consultant | Corporate |
| Startup Founder | Startup |
| Growth Hacker | Startup |

## Common vs Specific Sections

### Always Present (all layouts)
- contactInfo
- summary/profile
- workExperience
- education
- skills

### Optional by Layout

| Section | Standard | Executive | Technical | Creative | Corporate | Startup |
|---------|----------|-----------|-----------|----------|-----------|---------|
| keyAchievements | - | ✓ | - | - | - | - |
| leadership | - | ✓ | - | - | - | - |
| techStack | - | - | ✓ | - | - | - |
| projects | - | - | ✓ | - | - | ✓ |
| selectedWorks | - | - | - | ✓ | - | - |
| awards | - | - | - | ✓ | - | - |
| certifications | - | - | ✓ | - | ✓ | - |
| publications | - | - | - | - | ✓ | - |
| impactHighlights | - | - | - | - | - | ✓ |
| ventures | - | - | - | - | - | ✓ |

## Dynamic Adaptation

If the candidate has elements from multiple profiles, combine them:

**Example**: Startup CTO
- Base: Executive (for seniority)
- Add: techStack (technical skills)
- Add: impactHighlights (startup metrics)
- Add: ventures (entrepreneurial history)
