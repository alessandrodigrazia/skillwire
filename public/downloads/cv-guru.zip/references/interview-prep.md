# Reference: Interview Preparation (Phase 5)

## Role

Act as a **Head Hunter and Executive Coach** with decades of experience preparing candidates for high-level interviews.

## Objective

Generate a comprehensive strategic briefing that prepares the candidate for every aspect of the interview, anticipating questions, preparing STAR stories, and identifying potential red flags.

## Tone and Style

- **Tone**: Second person, actionable imperatives
- **Style**: Strategic, practical, success-oriented
- **Focus**: Mental and tactical preparation

## Required Inputs

1. **Optimized CV**: JSON from Phase 4
2. **Job Context**: Role, company, JD
3. **Fit Analysis**: Strengths, gaps
4. **Interview Details** (optional):
   - Stage (screening, technical, final)
   - Interviewer roles (HR, Hiring Manager, Team)

## Complete JSON Output

```json
{
  "objective": "Interview objective in 1-2 clear sentences",

  "keyMessages": [
    "Key message 1: what you want them to remember about you",
    "Key message 2: your unique value",
    "Key message 3: why you are the ideal candidate"
  ],

  "likelyQuestions": [
    {
      "question": "Why do you want this role?",
      "guidance": "Connect your experience in X with the company's mission..."
    },
    {
      "question": "What is your greatest achievement?",
      "guidance": "Use the STAR story from project Y, emphasize the metrics..."
    }
  ],

  "storiesToTell": [
    "Story of project X: how you overcame challenge Y with result Z",
    "Leadership story: when you managed crisis W"
  ],

  "redFlags": [
    "Time gap 2020-2021: prepare a proactive explanation",
    "Frequent company changes: present as strategic growth"
  ],

  "howToHandle": [
    "If they ask about the gap: 'I dedicated that period to...'",
    "If they ask why you're leaving your current role: 'I'm seeking greater impact opportunities...'"
  ],

  "closingPitch": "Memorable closing statement that summarizes your value",

  "nextSteps": [
    "Ask about the decision timeline",
    "Offer to provide references",
    "Confirm next steps in the process"
  ],

  "interviewerMatrix": [
    {
      "role": "HR Manager",
      "stage": "Screening",
      "wants": ["Cultural fit", "Genuine motivation", "Soft skills"],
      "risks": ["Appearing overqualified", "Salary out of budget"],
      "traps": ["Speaking badly of former employer", "Asking about salary immediately"]
    },
    {
      "role": "Hiring Manager",
      "stage": "Technical",
      "wants": ["Specific competencies", "Problem solving", "Autonomy"],
      "risks": ["Evident technical gaps", "Lack of concrete examples"],
      "traps": ["Not admitting what you don't know", "Overly theoretical answers"]
    }
  ],

  "storyBankSTAR": [
    {
      "hook": "How I saved a 2M project",
      "situation": "Enterprise project 3 months behind schedule, furious client",
      "task": "Recover the delay and restore client trust",
      "action": "Reorganized the team, implemented daily standups, negotiated new scope",
      "result": "Delivered on time, client signed contract extension",
      "metrics": "+500K additional revenue, client NPS from 3 to 9"
    }
  ],

  "discoveryQuestions": [
    "What are the priorities for the first 90 days in this role?",
    "How is the team structured and what are the dynamics?",
    "What are the main challenges the team is facing?",
    "How is success measured in this role?"
  ],

  "closingQuestions": [
    "What is the next step in the selection process?",
    "Is there anything about my profile you have concerns about?",
    "When do you expect to make a decision?"
  ]
}
```

## Detailed Sections

### 1. Objective

**Purpose**: Clearly define what you want to achieve from the interview.

**Format**:
```
"Demonstrate that you are the ideal candidate for [role] thanks to your
experience in [key area] and your ability to [unique value]"
```

**Example**:
```
"Convince them that you are the ideal Senior PM to lead the digital
transformation, thanks to your 8 years of enterprise experience and your
track record of delivering complex projects"
```

### 2. Key Messages

**Purpose**: 3 messages you want the interviewer to remember.

**Criteria**:
- Differentiating compared to other candidates
- Supported by concrete evidence
- Relevant to the role

**Example**:
```json
[
  "I have managed digital transformation projects for Fortune 500 with an average ROI of 200%",
  "My Agile approach has reduced time-to-market by 35% in the teams I led",
  "I am a natural bridge between business and technology, with both a technical background and an MBA"
]
```

### 3. Likely Questions + Guidance

**Categories to cover**:

1. **Motivational**
   - Why this role?
   - Why this company?
   - Where do you see yourself in 5 years?

2. **Experiential**
   - Tell me about a complex project
   - A conflict situation you managed
   - Biggest failure and what you learned

3. **Technical/Functional**
   - How would you approach [specific problem]?
   - What methodologies do you use for [task]?
   - Experience with [technology/tool]?

4. **Behavioral (STAR)**
   - When did you have to [situation]?
   - How did you handle [challenge]?

**Guidance Format**:
```json
{
  "question": "Why do you want to leave your current job?",
  "guidance": "Focus on the future, not the past. Emphasize: 'I'm looking
  for opportunities with greater strategic impact and this position offers
  exactly what I'm seeking: [specific element from the JD]'.
  NEVER criticize your current employer."
}
```

### 4. STAR Story Bank

**STAR Method**:
- **S**ituation: Context and challenge
- **T**ask: Your role/objective
- **A**ction: What you did (YOU, not the team)
- **R**esult: Outcome with METRICS

**Complete Template**:
```json
{
  "hook": "[Catchy title in 5-7 words]",
  "situation": "[Context: company, project, initial challenge - 2-3 sentences]",
  "task": "[Your specific role and the objective to achieve - 1-2 sentences]",
  "action": "[Concrete actions that YOU took - 3-4 bullets]",
  "result": "[Positive outcome with impact - 1-2 sentences]",
  "metrics": "[Specific numbers: %, currency, time, quantity]"
}
```

**Complete Example**:
```json
{
  "hook": "How I recovered a project given up for lost",
  "situation": "1.5M CRM project for a banking client, 4 months behind
  schedule, demotivated team, business sponsor ready to cancel",
  "task": "Brought on board as rescue PM, had to deliver in 6 weeks
  or the contract would be terminated",
  "action": "- Completed a full assessment in 48h identifying 3 critical blockers
  - Renegotiated scope with the client, cutting 30% of non-essential features
  - Reorganized the team into 2 parallel squads with daily sync
  - Implemented a war room with the client for real-time decisions",
  "result": "Delivered MVP in 5 weeks, client signed phase 2",
  "metrics": "+800K additional revenue, client retention, team NPS from 4 to 8"
}
```

### 5. Interviewer Matrix

**Purpose**: Prepare for each type of interviewer.

**For each role**:
- **Wants**: What they're looking for in the candidate
- **Risks**: What could concern them
- **Traps**: Mistakes to avoid

**Template**:
```json
{
  "role": "[Interviewer title]",
  "stage": "[Process phase]",
  "wants": ["Looking for 1", "Looking for 2"],
  "risks": ["Potential concern 1", "Potential concern 2"],
  "traps": ["Mistake to avoid 1", "Mistake to avoid 2"]
}
```

### 6. Red Flags and How to Handle

**Identify potential red flags**:
- Time gaps in the CV
- Job hopping (frequent changes)
- Overqualification/Underqualification
- Sector/function change
- Terminations

**Response format**:
```json
{
  "redFlag": "8-month gap in 2021",
  "howToHandle": "Proactively address it: 'In 2021, I dedicated a period
  to upskilling in [area], completing [certification] which allowed me
  to [benefit for the current role]'"
}
```

### 7. Discovery & Closing Questions

**Discovery Questions** (to ask during the interview):
- Better understand the role
- Show genuine interest
- Gather info for negotiation

**Closing Questions** (at the end):
- Handle objections
- Clarify next steps
- Leave a positive impression

## Complete Briefing Checklist

- [ ] Clear and specific objective
- [ ] 3+ differentiating key messages
- [ ] 5+ likely questions with guidance
- [ ] 2+ complete STAR stories
- [ ] Red flags identified with responses
- [ ] Interviewer matrix for each expected role
- [ ] Smart discovery questions
- [ ] Memorable closing pitch
- [ ] Next steps defined
