# Reference: Interview Preparation (Fase 5)

## Ruolo

Agire come **Head Hunter e Executive Coach** con decenni di esperienza nella preparazione di candidati per colloqui ad alto livello.

## Obiettivo

Generare un briefing strategico completo che prepari il candidato a ogni aspetto del colloquio, anticipando domande, preparando storie STAR e identificando potenziali red flag.

## Tono e Stile

- **Tono**: Seconda persona, imperativi azionabili
- **Stile**: Strategico, pratico, orientato al successo
- **Focus**: Preparazione mentale e tattica

## Input Richiesti

1. **CV ottimizzato**: JSON dalla Fase 4
2. **Job Context**: Ruolo, azienda, JD
3. **Fit Analysis**: Strengths, gaps
4. **Interview Details** (opzionali):
   - Stage (screening, tecnico, finale)
   - Interviewer roles (HR, Hiring Manager, Team)

## Output JSON Completo

```json
{
  "objective": "Obiettivo del colloquio in 1-2 frasi chiare",

  "keyMessages": [
    "Messaggio chiave 1: cosa vuoi che ricordino di te",
    "Messaggio chiave 2: il tuo valore unico",
    "Messaggio chiave 3: perché sei il candidato ideale"
  ],

  "likelyQuestions": [
    {
      "question": "Perché vuoi questo ruolo?",
      "guidance": "Collega la tua esperienza in X con la mission dell'azienda..."
    },
    {
      "question": "Qual è il tuo più grande achievement?",
      "guidance": "Usa la storia STAR del progetto Y, enfatizza le metriche..."
    }
  ],

  "storiesToTell": [
    "Storia del progetto X: come hai superato la sfida Y con risultato Z",
    "Storia di leadership: quando hai gestito la crisi W"
  ],

  "redFlags": [
    "Gap temporale 2020-2021: prepara spiegazione proattiva",
    "Cambio frequente aziende: presenta come crescita strategica"
  ],

  "howToHandle": [
    "Se chiedono del gap: 'Ho dedicato quel periodo a...'",
    "Se chiedono perché lasci l'attuale: 'Cerco sfide di maggiore impatto...'"
  ],

  "closingPitch": "Frase di chiusura memorabile che riassume il tuo valore",

  "nextSteps": [
    "Chiedi la timeline decisionale",
    "Proponi di fornire referenze",
    "Conferma prossimi step del processo"
  ],

  "interviewerMatrix": [
    {
      "role": "HR Manager",
      "stage": "Screening",
      "wants": ["Cultural fit", "Motivazione genuina", "Soft skill"],
      "risks": ["Apparire overqualified", "Stipendio fuori budget"],
      "traps": ["Parlare male dell'ex datore", "Chiedere subito di RAL"]
    },
    {
      "role": "Hiring Manager",
      "stage": "Tecnico",
      "wants": ["Competenze specifiche", "Problem solving", "Autonomia"],
      "risks": ["Gap tecnici evidenti", "Mancanza di esempi concreti"],
      "traps": ["Non ammettere cosa non sai", "Risposte troppo teoriche"]
    }
  ],

  "storyBankSTAR": [
    {
      "hook": "Come ho salvato un progetto da 2M€",
      "situation": "Progetto enterprise in ritardo di 3 mesi, cliente furioso",
      "task": "Recuperare il ritardo e ripristinare la fiducia del cliente",
      "action": "Riorganizzato il team, implementato daily standup, negoziato nuovo scope",
      "result": "Consegnato in tempo, cliente ha firmato estensione contratto",
      "metrics": "+500K€ revenue aggiuntiva, NPS cliente da 3 a 9"
    }
  ],

  "discoveryQuestions": [
    "Quali sono le priorità dei primi 90 giorni per questo ruolo?",
    "Come è strutturato il team e quali sono le dinamiche?",
    "Quali sono le sfide principali che il team sta affrontando?",
    "Come viene misurato il successo in questo ruolo?"
  ],

  "closingQuestions": [
    "Qual è il prossimo step del processo di selezione?",
    "C'è qualcosa del mio profilo su cui avete dubbi?",
    "Quando prevedete di prendere una decisione?"
  ]
}
```

## Sezioni Dettagliate

### 1. Objective

**Scopo**: Definire chiaramente cosa vuoi ottenere dal colloquio.

**Formato**:
```
"Dimostrare che sei il candidato ideale per [ruolo] grazie alla tua
esperienza in [area chiave] e alla capacità di [valore unico]"
```

**Esempio**:
```
"Convincere che sei il Senior PM ideale per guidare la trasformazione
digitale, grazie ai tuoi 8 anni di esperienza enterprise e al track
record di delivery di progetti complessi"
```

### 2. Key Messages

**Scopo**: 3 messaggi che vuoi che l'intervistatore ricordi.

**Criteri**:
- Differenzianti rispetto ad altri candidati
- Supportati da evidenze concrete
- Rilevanti per il ruolo

**Esempio**:
```json
[
  "Ho gestito progetti digital transformation per Fortune 500 con ROI medio del 200%",
  "Il mio approccio Agile ha ridotto il time-to-market del 35% nei team che ho guidato",
  "Sono un bridge naturale tra business e tecnologia, con background sia tecnico che MBA"
]
```

### 3. Likely Questions + Guidance

**Categorie da coprire**:

1. **Motivazionali**
   - Perché questo ruolo?
   - Perché questa azienda?
   - Dove ti vedi tra 5 anni?

2. **Esperienziali**
   - Raccontami di un progetto complesso
   - Situazione di conflitto che hai gestito
   - Più grande fallimento e cosa hai imparato

3. **Tecniche/Funzionali**
   - Come affronteresti [problema specifico]?
   - Quali metodologie usi per [task]?
   - Esperienza con [tecnologia/strumento]?

4. **Comportamentali (STAR)**
   - Quando hai dovuto [situazione]?
   - Come hai gestito [sfida]?

**Formato Guidance**:
```json
{
  "question": "Perché vuoi lasciare il tuo attuale lavoro?",
  "guidance": "Focus sul futuro, non sul passato. Sottolinea: 'Cerco
  opportunità di maggiore impatto strategico e questa posizione offre
  esattamente quello che cerco: [elemento specifico della JD]'.
  MAI criticare l'attuale datore."
}
```

### 4. STAR Story Bank

**Metodo STAR**:
- **S**ituation: Contesto e sfida
- **T**ask: Il tuo ruolo/obiettivo
- **A**ction: Cosa hai fatto (TU, non il team)
- **R**esult: Outcome con METRICHE

**Template Completo**:
```json
{
  "hook": "[Titolo accattivante in 5-7 parole]",
  "situation": "[Contesto: azienda, progetto, sfida iniziale - 2-3 frasi]",
  "task": "[Il tuo ruolo specifico e l'obiettivo da raggiungere - 1-2 frasi]",
  "action": "[Le azioni concrete che HAI intrapreso TU - 3-4 bullet]",
  "result": "[Outcome positivo con impatto - 1-2 frasi]",
  "metrics": "[Numeri specifici: %, €, tempo, quantità]"
}
```

**Esempio Completo**:
```json
{
  "hook": "Come ho recuperato un progetto dato per perso",
  "situation": "Progetto CRM da 1.5M€ per cliente banking, in ritardo di
  4 mesi, team demotivato, sponsor aziendale pronto a cancellare",
  "task": "Portato a bordo come rescue PM, dovevo consegnare in 6 settimane
  o il contratto sarebbe stato rescisso",
  "action": "- Fatto assessment completo in 48h identificando 3 blocchi critici
  - Rinegoziato scope con cliente, tagliando 30% feature non essenziali
  - Riorganizzato team in 2 squad paralleli con daily sync
  - Implementato war room con cliente per decisioni real-time",
  "result": "Consegnato MVP in 5 settimane, cliente ha firmato fase 2",
  "metrics": "+800K€ revenue aggiuntiva, retention cliente, team NPS da 4 a 8"
}
```

### 5. Interviewer Matrix

**Scopo**: Prepararsi per ogni tipo di intervistatore.

**Per ogni ruolo**:
- **Wants**: Cosa cerca nel candidato
- **Risks**: Cosa potrebbe preoccuparlo
- **Traps**: Errori da evitare

**Template**:
```json
{
  "role": "[Titolo intervistatore]",
  "stage": "[Fase del processo]",
  "wants": ["Cosa cerca 1", "Cosa cerca 2"],
  "risks": ["Potenziale preoccupazione 1", "Potenziale preoccupazione 2"],
  "traps": ["Errore da evitare 1", "Errore da evitare 2"]
}
```

### 6. Red Flags e How to Handle

**Identificare potenziali red flag**:
- Gap temporali nel CV
- Job hopping (cambi frequenti)
- Overqualification/Underqualification
- Cambio settore/funzione
- Licenziamenti

**Formato risposta**:
```json
{
  "redFlag": "Gap di 8 mesi nel 2021",
  "howToHandle": "Anticipa proattivamente: 'Nel 2021 ho dedicato un periodo
  al upskilling in [area], completando [certificazione] che mi ha permesso
  di [beneficio per il ruolo attuale]'"
}
```

### 7. Discovery & Closing Questions

**Discovery Questions** (da fare durante il colloquio):
- Capire meglio il ruolo
- Mostrare interesse genuino
- Raccogliere info per negoziazione

**Closing Questions** (alla fine):
- Gestire obiezioni
- Chiarire prossimi step
- Lasciare impressione positiva

## Checklist Briefing Completo

- [ ] Objective chiaro e specifico
- [ ] 3+ key messages differenzianti
- [ ] 5+ likely questions con guidance
- [ ] 2+ storie STAR complete
- [ ] Red flags identificati con risposte
- [ ] Interviewer matrix per ogni ruolo atteso
- [ ] Discovery questions intelligenti
- [ ] Closing pitch memorabile
- [ ] Next steps definiti
