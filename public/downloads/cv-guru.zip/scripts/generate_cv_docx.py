#!/usr/bin/env python3
"""
CV DOCX Generator

Genera un CV professionale in formato DOCX a partire da un JSON strutturato.
Supporta diversi layout profiles: Standard, Executive, Technical, Creative, Corporate, Startup.

Requisiti:
    pip install python-docx

Uso:
    python generate_cv_docx.py --input cv.json --output CV_Nome_Cognome.docx --layout standard

    Oppure da Claude:
    - Salvare il JSON del CV in un file temporaneo
    - Eseguire lo script con i parametri appropriati
"""

import json
import argparse
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE


# Colori tema
COLORS = {
    'primary': RGBColor(0x2F, 0x54, 0x96),  # Blu professionale
    'secondary': RGBColor(0x2E, 0x3A, 0x59),  # Grigio scuro
    'accent': RGBColor(0x00, 0x76, 0xD6),  # Blu accent
}


def setup_styles(doc):
    """Configura gli stili del documento."""
    styles = doc.styles

    # Stile titolo nome
    if 'CVName' not in [s.name for s in styles]:
        style = styles.add_style('CVName', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(28)
        style.font.bold = True
        style.font.color.rgb = COLORS['secondary']
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style.paragraph_format.space_after = Pt(6)

    # Stile contatti
    if 'CVContact' not in [s.name for s in styles]:
        style = styles.add_style('CVContact', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style.paragraph_format.space_after = Pt(12)

    # Stile sezione
    if 'CVSection' not in [s.name for s in styles]:
        style = styles.add_style('CVSection', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(14)
        style.font.bold = True
        style.font.color.rgb = COLORS['primary']
        style.paragraph_format.space_before = Pt(12)
        style.paragraph_format.space_after = Pt(6)

    # Stile job title
    if 'CVJobTitle' not in [s.name for s in styles]:
        style = styles.add_style('CVJobTitle', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(12)
        style.font.bold = True
        style.paragraph_format.space_before = Pt(8)
        style.paragraph_format.space_after = Pt(2)

    # Stile company
    if 'CVCompany' not in [s.name for s in styles]:
        style = styles.add_style('CVCompany', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.font.bold = True
        style.font.italic = True
        style.paragraph_format.space_after = Pt(4)

    # Stile normale CV
    if 'CVNormal' not in [s.name for s in styles]:
        style = styles.add_style('CVNormal', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.paragraph_format.space_after = Pt(4)


def add_section_header(doc, title):
    """Aggiunge un'intestazione di sezione con linea."""
    p = doc.add_paragraph(title, style='CVSection')
    # Aggiungi linea sotto
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run('─' * 60)
    run.font.color.rgb = COLORS['primary']
    run.font.size = Pt(8)


def add_header(doc, contact_info):
    """Aggiunge l'header con nome e contatti."""
    # Nome
    name = contact_info.get('name', 'Nome Cognome')
    doc.add_paragraph(name, style='CVName')

    # Contatti
    contacts = []
    if contact_info.get('email'):
        contacts.append(f"📧 {contact_info['email']}")
    if contact_info.get('phone'):
        contacts.append(f"📱 {contact_info['phone']}")
    if contact_info.get('linkedin'):
        linkedin = contact_info['linkedin']
        if not linkedin.startswith('http'):
            linkedin = f"linkedin.com/in/{linkedin}"
        contacts.append(f"🔗 {linkedin}")

    if contacts:
        doc.add_paragraph(' | '.join(contacts), style='CVContact')


def add_summary(doc, summary):
    """Aggiunge il profilo professionale."""
    if not summary:
        return
    add_section_header(doc, 'Profilo Professionale')
    p = doc.add_paragraph(summary, style='CVNormal')
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY


def add_key_achievements(doc, achievements):
    """Aggiunge sezione Key Achievements (per layout Executive)."""
    if not achievements:
        return
    add_section_header(doc, 'Achievement Chiave')
    for achievement in achievements:
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('• ').bold = True
        p.add_run(achievement)


def add_tech_stack(doc, tech_stack):
    """Aggiunge sezione Tech Stack (per layout Technical)."""
    if not tech_stack:
        return
    add_section_header(doc, 'Stack Tecnologico')

    categories = {
        'languages': 'Linguaggi',
        'frameworks': 'Framework',
        'databases': 'Database',
        'cloud': 'Cloud & DevOps',
        'tools': 'Tools'
    }

    for key, label in categories.items():
        if key in tech_stack and tech_stack[key]:
            p = doc.add_paragraph(style='CVNormal')
            p.add_run(f'{label}: ').bold = True
            p.add_run(', '.join(tech_stack[key]))


def add_impact_highlights(doc, highlights):
    """Aggiunge sezione Impact Highlights (per layout Startup)."""
    if not highlights:
        return
    add_section_header(doc, 'Impact Highlights')
    for highlight in highlights:
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('• ').bold = True
        p.add_run(highlight)


def add_work_experience(doc, experiences, condensed=False):
    """Aggiunge la sezione esperienze lavorative."""
    if not experiences:
        return
    add_section_header(doc, 'Esperienza Professionale')

    for exp in experiences:
        # Job Title
        doc.add_paragraph(exp.get('title', ''), style='CVJobTitle')

        # Company e date
        company_line = exp.get('company', '')
        if exp.get('dates'):
            company_line += f" | {exp['dates']}"
        doc.add_paragraph(company_line, style='CVCompany')

        # Description/achievements
        description = exp.get('description', '')
        if description:
            # Split per bullets
            lines = description.split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith('- '):
                    line = line[2:]
                if line:
                    p = doc.add_paragraph(style='CVNormal')
                    p.add_run('• ').bold = True
                    p.add_run(line)
                    if condensed:
                        p.paragraph_format.space_after = Pt(2)


def add_projects(doc, projects):
    """Aggiunge sezione Progetti (per layout Technical/Startup)."""
    if not projects:
        return
    add_section_header(doc, 'Progetti Rilevanti')

    for project in projects:
        # Nome progetto
        p = doc.add_paragraph(style='CVJobTitle')
        p.add_run(project.get('name', ''))

        # Descrizione
        if project.get('description'):
            doc.add_paragraph(project['description'], style='CVNormal')

        # Tecnologie
        if project.get('technologies'):
            p = doc.add_paragraph(style='CVNormal')
            p.add_run('Tecnologie: ').bold = True
            p.add_run(', '.join(project['technologies']))

        # Impatto
        if project.get('impact'):
            p = doc.add_paragraph(style='CVNormal')
            p.add_run('Impatto: ').bold = True
            p.add_run(project['impact'])


def add_education(doc, education):
    """Aggiunge la sezione formazione."""
    if not education:
        return
    add_section_header(doc, 'Formazione')

    for edu in education:
        # Titolo
        doc.add_paragraph(edu.get('degree', ''), style='CVJobTitle')

        # Istituzione e date
        inst_line = edu.get('institution', '')
        if edu.get('dates'):
            inst_line += f" | {edu['dates']}"
        doc.add_paragraph(inst_line, style='CVCompany')


def add_skills(doc, skills):
    """Aggiunge la sezione competenze."""
    if not skills:
        return
    add_section_header(doc, 'Competenze')

    if skills.get('technical'):
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('Tecniche: ').bold = True
        p.add_run(', '.join(skills['technical']))

    if skills.get('soft'):
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('Trasversali: ').bold = True
        p.add_run(', '.join(skills['soft']))

    if skills.get('languages'):
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('Lingue: ').bold = True
        p.add_run(', '.join(skills['languages']))


def add_leadership(doc, leadership):
    """Aggiunge sezione Leadership (per layout Executive)."""
    if not leadership:
        return
    add_section_header(doc, 'Leadership & Board')

    for role in leadership:
        p = doc.add_paragraph(style='CVNormal')
        p.add_run(f"{role.get('role', '')} ").bold = True
        p.add_run(f"- {role.get('organization', '')}")
        if role.get('dates'):
            p.add_run(f" ({role['dates']})")


def generate_cv_docx(cv_json, output_path, layout='standard'):
    """
    Genera il documento DOCX dal JSON del CV.

    Args:
        cv_json: dict con i dati del CV
        output_path: percorso del file di output
        layout: 'standard', 'executive', 'technical', 'creative', 'corporate', 'startup'
    """
    doc = Document()

    # Imposta margini
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(0.75)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)

    # Setup stili
    setup_styles(doc)

    # Header (sempre presente)
    add_header(doc, cv_json.get('contactInfo', {}))

    # Sezioni in base al layout
    layout = layout.lower()

    if layout == 'executive':
        add_summary(doc, cv_json.get('summary'))
        add_key_achievements(doc, cv_json.get('keyAchievements'))
        add_work_experience(doc, cv_json.get('workExperience'), condensed=True)
        add_leadership(doc, cv_json.get('leadership'))
        add_education(doc, cv_json.get('education'))
        add_skills(doc, cv_json.get('skills'))

    elif layout == 'technical':
        add_summary(doc, cv_json.get('summary'))
        add_tech_stack(doc, cv_json.get('techStack'))
        add_projects(doc, cv_json.get('projects'))
        add_work_experience(doc, cv_json.get('workExperience'))
        add_education(doc, cv_json.get('education'))
        add_skills(doc, cv_json.get('skills'))

    elif layout == 'startup':
        add_summary(doc, cv_json.get('summary'))
        add_impact_highlights(doc, cv_json.get('impactHighlights'))
        add_work_experience(doc, cv_json.get('workExperience'))
        add_projects(doc, cv_json.get('projects'))
        add_education(doc, cv_json.get('education'))
        add_skills(doc, cv_json.get('skills'))

    else:  # standard, corporate, creative
        add_summary(doc, cv_json.get('summary'))
        add_work_experience(doc, cv_json.get('workExperience'))
        add_education(doc, cv_json.get('education'))
        add_skills(doc, cv_json.get('skills'))

    # Salva documento
    doc.save(output_path)
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Genera CV in formato DOCX')
    parser.add_argument('--input', '-i', required=True, help='File JSON del CV')
    parser.add_argument('--output', '-o', required=True, help='File DOCX di output')
    parser.add_argument('--layout', '-l', default='standard',
                        choices=['standard', 'executive', 'technical', 'creative', 'corporate', 'startup'],
                        help='Layout profile del CV')

    args = parser.parse_args()

    # Leggi JSON
    with open(args.input, 'r', encoding='utf-8') as f:
        cv_json = json.load(f)

    # Genera DOCX
    output = generate_cv_docx(cv_json, args.output, args.layout)
    print(f"✅ CV generato: {output}")


if __name__ == '__main__':
    main()
