#!/usr/bin/env python3
"""
CV DOCX Generator

Generates a professional CV in DOCX format from a structured JSON.
Supports different layout profiles: Standard, Executive, Technical, Creative, Corporate, Startup.

Requirements:
    pip install python-docx

Usage:
    python generate_cv_docx.py --input cv.json --output CV_First_Last.docx --layout standard

    Or from Claude:
    - Save the CV JSON to a temporary file
    - Run the script with the appropriate parameters
"""

import json
import argparse
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE


# Theme colors
COLORS = {
    'primary': RGBColor(0x2F, 0x54, 0x96),  # Professional blue
    'secondary': RGBColor(0x2E, 0x3A, 0x59),  # Dark gray
    'accent': RGBColor(0x00, 0x76, 0xD6),  # Blue accent
}


def setup_styles(doc):
    """Configure document styles."""
    styles = doc.styles

    # Name title style
    if 'CVName' not in [s.name for s in styles]:
        style = styles.add_style('CVName', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(28)
        style.font.bold = True
        style.font.color.rgb = COLORS['secondary']
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style.paragraph_format.space_after = Pt(6)

    # Contact style
    if 'CVContact' not in [s.name for s in styles]:
        style = styles.add_style('CVContact', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style.paragraph_format.space_after = Pt(12)

    # Section style
    if 'CVSection' not in [s.name for s in styles]:
        style = styles.add_style('CVSection', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(14)
        style.font.bold = True
        style.font.color.rgb = COLORS['primary']
        style.paragraph_format.space_before = Pt(12)
        style.paragraph_format.space_after = Pt(6)

    # Job title style
    if 'CVJobTitle' not in [s.name for s in styles]:
        style = styles.add_style('CVJobTitle', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(12)
        style.font.bold = True
        style.paragraph_format.space_before = Pt(8)
        style.paragraph_format.space_after = Pt(2)

    # Company style
    if 'CVCompany' not in [s.name for s in styles]:
        style = styles.add_style('CVCompany', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.font.bold = True
        style.font.italic = True
        style.paragraph_format.space_after = Pt(4)

    # Normal CV style
    if 'CVNormal' not in [s.name for s in styles]:
        style = styles.add_style('CVNormal', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.paragraph_format.space_after = Pt(4)


def add_section_header(doc, title):
    """Add a section header with a line."""
    p = doc.add_paragraph(title, style='CVSection')
    # Add line below
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run('─' * 60)
    run.font.color.rgb = COLORS['primary']
    run.font.size = Pt(8)


def add_header(doc, contact_info):
    """Add the header with name and contacts."""
    # Name
    name = contact_info.get('name', 'First Last')
    doc.add_paragraph(name, style='CVName')

    # Contacts
    contacts = []
    if contact_info.get('email'):
        contacts.append(f"📧 {contact_info['email']}")
    if contact_info.get('phone'):
        contacts.append(f"📱 {contact_info['phone']}")
    if contact_info.get('linkedin'):
        linkedin = contact_info['linkedin']
        if not linkedin.startswith('http'):
            linkedin = f"linkedin.com/in/{linkedin}"
        contacts.append(f"🔗 {linkedin}")

    if contacts:
        doc.add_paragraph(' | '.join(contacts), style='CVContact')


def add_summary(doc, summary):
    """Add the professional profile."""
    if not summary:
        return
    add_section_header(doc, 'Professional Profile')
    p = doc.add_paragraph(summary, style='CVNormal')
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY


def add_key_achievements(doc, achievements):
    """Add Key Achievements section (for Executive layout)."""
    if not achievements:
        return
    add_section_header(doc, 'Key Achievements')
    for achievement in achievements:
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('• ').bold = True
        p.add_run(achievement)


def add_tech_stack(doc, tech_stack):
    """Add Tech Stack section (for Technical layout)."""
    if not tech_stack:
        return
    add_section_header(doc, 'Tech Stack')

    categories = {
        'languages': 'Languages',
        'frameworks': 'Frameworks',
        'databases': 'Databases',
        'cloud': 'Cloud & DevOps',
        'tools': 'Tools'
    }

    for key, label in categories.items():
        if key in tech_stack and tech_stack[key]:
            p = doc.add_paragraph(style='CVNormal')
            p.add_run(f'{label}: ').bold = True
            p.add_run(', '.join(tech_stack[key]))


def add_impact_highlights(doc, highlights):
    """Add Impact Highlights section (for Startup layout)."""
    if not highlights:
        return
    add_section_header(doc, 'Impact Highlights')
    for highlight in highlights:
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('• ').bold = True
        p.add_run(highlight)


def add_work_experience(doc, experiences, condensed=False):
    """Add the work experience section."""
    if not experiences:
        return
    add_section_header(doc, 'Professional Experience')

    for exp in experiences:
        # Job Title
        doc.add_paragraph(exp.get('title', ''), style='CVJobTitle')

        # Company and dates
        company_line = exp.get('company', '')
        if exp.get('dates'):
            company_line += f" | {exp['dates']}"
        doc.add_paragraph(company_line, style='CVCompany')

        # Description/achievements
        description = exp.get('description', '')
        if description:
            # Split by bullets
            lines = description.split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith('- '):
                    line = line[2:]
                if line:
                    p = doc.add_paragraph(style='CVNormal')
                    p.add_run('• ').bold = True
                    p.add_run(line)
                    if condensed:
                        p.paragraph_format.space_after = Pt(2)


def add_projects(doc, projects):
    """Add Projects section (for Technical/Startup layout)."""
    if not projects:
        return
    add_section_header(doc, 'Relevant Projects')

    for project in projects:
        # Project name
        p = doc.add_paragraph(style='CVJobTitle')
        p.add_run(project.get('name', ''))

        # Description
        if project.get('description'):
            doc.add_paragraph(project['description'], style='CVNormal')

        # Technologies
        if project.get('technologies'):
            p = doc.add_paragraph(style='CVNormal')
            p.add_run('Technologies: ').bold = True
            p.add_run(', '.join(project['technologies']))

        # Impact
        if project.get('impact'):
            p = doc.add_paragraph(style='CVNormal')
            p.add_run('Impact: ').bold = True
            p.add_run(project['impact'])


def add_education(doc, education):
    """Add the education section."""
    if not education:
        return
    add_section_header(doc, 'Education')

    for edu in education:
        # Degree
        doc.add_paragraph(edu.get('degree', ''), style='CVJobTitle')

        # Institution and dates
        inst_line = edu.get('institution', '')
        if edu.get('dates'):
            inst_line += f" | {edu['dates']}"
        doc.add_paragraph(inst_line, style='CVCompany')


def add_skills(doc, skills):
    """Add the skills section."""
    if not skills:
        return
    add_section_header(doc, 'Skills')

    if skills.get('technical'):
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('Technical: ').bold = True
        p.add_run(', '.join(skills['technical']))

    if skills.get('soft'):
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('Transferable: ').bold = True
        p.add_run(', '.join(skills['soft']))

    if skills.get('languages'):
        p = doc.add_paragraph(style='CVNormal')
        p.add_run('Languages: ').bold = True
        p.add_run(', '.join(skills['languages']))


def add_leadership(doc, leadership):
    """Add Leadership section (for Executive layout)."""
    if not leadership:
        return
    add_section_header(doc, 'Leadership & Board')

    for role in leadership:
        p = doc.add_paragraph(style='CVNormal')
        p.add_run(f"{role.get('role', '')} ").bold = True
        p.add_run(f"- {role.get('organization', '')}")
        if role.get('dates'):
            p.add_run(f" ({role['dates']})")


def generate_cv_docx(cv_json, output_path, layout='standard'):
    """
    Generate the DOCX document from the CV JSON.

    Args:
        cv_json: dict with CV data
        output_path: output file path
        layout: 'standard', 'executive', 'technical', 'creative', 'corporate', 'startup'
    """
    doc = Document()

    # Set margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(0.75)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)

    # Setup styles
    setup_styles(doc)

    # Header (always present)
    add_header(doc, cv_json.get('contactInfo', {}))

    # Sections based on layout
    layout = layout.lower()

    if layout == 'executive':
        add_summary(doc, cv_json.get('summary'))
        add_key_achievements(doc, cv_json.get('keyAchievements'))
        add_work_experience(doc, cv_json.get('workExperience'), condensed=True)
        add_leadership(doc, cv_json.get('leadership'))
        add_education(doc, cv_json.get('education'))
        add_skills(doc, cv_json.get('skills'))

    elif layout == 'technical':
        add_summary(doc, cv_json.get('summary'))
        add_tech_stack(doc, cv_json.get('techStack'))
        add_projects(doc, cv_json.get('projects'))
        add_work_experience(doc, cv_json.get('workExperience'))
        add_education(doc, cv_json.get('education'))
        add_skills(doc, cv_json.get('skills'))

    elif layout == 'startup':
        add_summary(doc, cv_json.get('summary'))
        add_impact_highlights(doc, cv_json.get('impactHighlights'))
        add_work_experience(doc, cv_json.get('workExperience'))
        add_projects(doc, cv_json.get('projects'))
        add_education(doc, cv_json.get('education'))
        add_skills(doc, cv_json.get('skills'))

    else:  # standard, corporate, creative
        add_summary(doc, cv_json.get('summary'))
        add_work_experience(doc, cv_json.get('workExperience'))
        add_education(doc, cv_json.get('education'))
        add_skills(doc, cv_json.get('skills'))

    # Save document
    doc.save(output_path)
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Generate CV in DOCX format')
    parser.add_argument('--input', '-i', required=True, help='CV JSON file')
    parser.add_argument('--output', '-o', required=True, help='Output DOCX file')
    parser.add_argument('--layout', '-l', default='standard',
                        choices=['standard', 'executive', 'technical', 'creative', 'corporate', 'startup'],
                        help='CV layout profile')

    args = parser.parse_args()

    # Read JSON
    with open(args.input, 'r', encoding='utf-8') as f:
        cv_json = json.load(f)

    # Generate DOCX
    output = generate_cv_docx(cv_json, args.output, args.layout)
    print(f"CV generated: {output}")


if __name__ == '__main__':
    main()
