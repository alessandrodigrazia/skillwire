#!/usr/bin/env python3
"""
Interview Briefing DOCX Generator

Genera un documento di preparazione al colloquio in formato DOCX
a partire da un JSON strutturato.

Requisiti:
    pip install python-docx

Uso:
    python generate_briefing_docx.py --input briefing.json --output Briefing_Nome.docx

    Oppure da Claude:
    - Salvare il JSON del briefing in un file temporaneo
    - Eseguire lo script con i parametri appropriati
"""

import json
import argparse
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE


# Colori tema
COLORS = {
    'primary': RGBColor(0x2F, 0x54, 0x96),  # Blu professionale
    'secondary': RGBColor(0x2E, 0x3A, 0x59),  # Grigio scuro
    'success': RGBColor(0x28, 0xA7, 0x45),  # Verde
    'warning': RGBColor(0xDC, 0x35, 0x45),  # Rosso
}


def setup_styles(doc):
    """Configura gli stili del documento."""
    styles = doc.styles

    # Stile titolo principale
    if 'BriefingTitle' not in [s.name for s in styles]:
        style = styles.add_style('BriefingTitle', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(24)
        style.font.bold = True
        style.font.color.rgb = COLORS['secondary']
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style.paragraph_format.space_after = Pt(6)

    # Stile sottotitolo
    if 'BriefingSubtitle' not in [s.name for s in styles]:
        style = styles.add_style('BriefingSubtitle', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(14)
        style.font.italic = True
        style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style.paragraph_format.space_after = Pt(12)

    # Stile sezione
    if 'BriefingSection' not in [s.name for s in styles]:
        style = styles.add_style('BriefingSection', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(14)
        style.font.bold = True
        style.font.color.rgb = COLORS['primary']
        style.paragraph_format.space_before = Pt(16)
        style.paragraph_format.space_after = Pt(8)

    # Stile domanda
    if 'BriefingQuestion' not in [s.name for s in styles]:
        style = styles.add_style('BriefingQuestion', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.font.bold = True
        style.font.italic = True
        style.paragraph_format.space_before = Pt(8)
        style.paragraph_format.space_after = Pt(4)

    # Stile normale
    if 'BriefingNormal' not in [s.name for s in styles]:
        style = styles.add_style('BriefingNormal', WD_STYLE_TYPE.PARAGRAPH)
        style.font.name = 'Calibri'
        style.font.size = Pt(11)
        style.paragraph_format.space_after = Pt(4)


def add_section_header(doc, emoji, title):
    """Aggiunge un'intestazione di sezione con emoji."""
    p = doc.add_paragraph(style='BriefingSection')
    p.add_run(f'{emoji} {title}')


def add_header(doc, job_title, company, candidate_name):
    """Aggiunge l'header del documento."""
    doc.add_paragraph('Briefing Colloquio', style='BriefingTitle')
    doc.add_paragraph(f'{job_title} presso {company}', style='BriefingSubtitle')

    p = doc.add_paragraph(style='BriefingNormal')
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run('Candidato: ').bold = True
    p.add_run(candidate_name)


def add_objective(doc, objective):
    """Aggiunge la sezione obiettivo."""
    if not objective:
        return
    add_section_header(doc, '🎯', 'Obiettivo')
    doc.add_paragraph(objective, style='BriefingNormal')


def add_key_messages(doc, messages):
    """Aggiunge i messaggi chiave."""
    if not messages:
        return
    add_section_header(doc, '💬', 'Messaggi Chiave')
    for i, msg in enumerate(messages, 1):
        p = doc.add_paragraph(style='BriefingNormal')
        p.add_run(f'{i}. ').bold = True
        p.add_run(msg)


def add_likely_questions(doc, questions):
    """Aggiunge le domande probabili con guidance."""
    if not questions:
        return
    add_section_header(doc, '❓', 'Domande Probabili')

    for q in questions:
        question = q if isinstance(q, str) else q.get('question', '')
        guidance = '' if isinstance(q, str) else q.get('guidance', '')

        doc.add_paragraph(f'"{question}"', style='BriefingQuestion')
        if guidance:
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('Guida: ').bold = True
            p.add_run(guidance)


def add_star_stories(doc, stories):
    """Aggiunge le storie STAR."""
    if not stories:
        return
    add_section_header(doc, '📖', 'Storie STAR da Raccontare')

    for story in stories:
        if isinstance(story, str):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('• ').bold = True
            p.add_run(story)
        else:
            # Formato completo STAR
            hook = story.get('hook', 'Storia')
            p = doc.add_paragraph(style='BriefingQuestion')
            p.add_run(hook)

            for key, label in [('situation', 'Situazione'), ('task', 'Task'),
                              ('action', 'Azione'), ('result', 'Risultato')]:
                if story.get(key):
                    p = doc.add_paragraph(style='BriefingNormal')
                    p.add_run(f'{label}: ').bold = True
                    p.add_run(story[key])

            if story.get('metrics'):
                p = doc.add_paragraph(style='BriefingNormal')
                p.add_run('Metriche: ').bold = True
                p.add_run(story['metrics'])


def add_red_flags(doc, red_flags, how_to_handle):
    """Aggiunge i red flags e come gestirli."""
    if not red_flags:
        return
    add_section_header(doc, '⚠️', 'Red Flag da Gestire')

    for i, flag in enumerate(red_flags):
        p = doc.add_paragraph(style='BriefingNormal')
        p.add_run('• ').bold = True
        run = p.add_run(flag)
        run.font.color.rgb = COLORS['warning']

        # Aggiungi how to handle se disponibile
        if how_to_handle and i < len(how_to_handle):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('  ➔ Come gestirlo: ').bold = True
            p.add_run(how_to_handle[i])


def add_interviewer_matrix(doc, matrix):
    """Aggiunge la matrice interviewer."""
    if not matrix:
        return
    add_section_header(doc, '👥', 'Matrice Interviewer')

    for interviewer in matrix:
        # Role e stage
        p = doc.add_paragraph(style='BriefingQuestion')
        role = interviewer.get('role', 'Interviewer')
        stage = interviewer.get('stage', '')
        p.add_run(f'{role}')
        if stage:
            p.add_run(f' ({stage})')

        # Wants
        if interviewer.get('wants'):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('Cerca: ').bold = True
            p.add_run(', '.join(interviewer['wants']))

        # Risks
        if interviewer.get('risks'):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('Rischi: ').bold = True
            run = p.add_run(', '.join(interviewer['risks']))
            run.font.color.rgb = COLORS['warning']

        # Traps
        if interviewer.get('traps'):
            p = doc.add_paragraph(style='BriefingNormal')
            p.add_run('Trappole: ').bold = True
            p.add_run(', '.join(interviewer['traps']))


def add_discovery_questions(doc, questions):
    """Aggiunge le domande da fare."""
    if not questions:
        return
    add_section_header(doc, '🙋', 'Domande da Fare')
    for q in questions:
        p = doc.add_paragraph(style='BriefingNormal')
        p.add_run('• ').bold = True
        p.add_run(q)


def add_closing_pitch(doc, pitch):
    """Aggiunge il closing pitch."""
    if not pitch:
        return
    add_section_header(doc, '🎤', 'Closing Pitch')
    p = doc.add_paragraph(style='BriefingNormal')
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f'"{pitch}"')
    run.italic = True


def add_next_steps(doc, steps):
    """Aggiunge i next steps."""
    if not steps:
        return
    add_section_header(doc, '➡️', 'Next Steps')
    for step in steps:
        p = doc.add_paragraph(style='BriefingNormal')
        p.add_run('☐ ').bold = True
        p.add_run(step)


def generate_briefing_docx(briefing_json, output_path, job_title='', company='', candidate_name=''):
    """
    Genera il documento DOCX dal JSON del briefing.

    Args:
        briefing_json: dict con i dati del briefing
        output_path: percorso del file di output
        job_title: titolo del ruolo
        company: nome azienda
        candidate_name: nome candidato
    """
    doc = Document()

    # Imposta margini
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(0.75)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)

    # Setup stili
    setup_styles(doc)

    # Header
    add_header(doc, job_title, company, candidate_name)

    # Sezioni del briefing
    add_objective(doc, briefing_json.get('objective'))
    add_key_messages(doc, briefing_json.get('keyMessages'))
    add_likely_questions(doc, briefing_json.get('likelyQuestions'))

    # STAR Stories
    stories = briefing_json.get('storyBankSTAR') or briefing_json.get('storiesToTell')
    add_star_stories(doc, stories)

    # Red flags
    add_red_flags(doc, briefing_json.get('redFlags'), briefing_json.get('howToHandle'))

    # Interviewer matrix
    add_interviewer_matrix(doc, briefing_json.get('interviewerMatrix'))

    # Discovery questions
    questions = briefing_json.get('discoveryQuestions') or briefing_json.get('closingQuestions')
    add_discovery_questions(doc, questions)

    # Closing pitch
    add_closing_pitch(doc, briefing_json.get('closingPitch'))

    # Next steps
    add_next_steps(doc, briefing_json.get('nextSteps'))

    # Salva documento
    doc.save(output_path)
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Genera briefing colloquio in formato DOCX')
    parser.add_argument('--input', '-i', required=True, help='File JSON del briefing')
    parser.add_argument('--output', '-o', required=True, help='File DOCX di output')
    parser.add_argument('--job-title', '-j', default='Posizione', help='Titolo del ruolo')
    parser.add_argument('--company', '-c', default='Azienda', help='Nome azienda')
    parser.add_argument('--candidate', '-n', default='Candidato', help='Nome candidato')

    args = parser.parse_args()

    # Leggi JSON
    with open(args.input, 'r', encoding='utf-8') as f:
        briefing_json = json.load(f)

    # Genera DOCX
    output = generate_briefing_docx(
        briefing_json,
        args.output,
        job_title=args.job_title,
        company=args.company,
        candidate_name=args.candidate
    )
    print(f"✅ Briefing generato: {output}")


if __name__ == '__main__':
    main()
