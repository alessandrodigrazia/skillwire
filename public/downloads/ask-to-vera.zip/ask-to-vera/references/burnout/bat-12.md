# BAT-12 - Burnout Assessment Tool (Short Version)

## Overview

The BAT-12 (Schaufeli et al., 2020) is a short version of the BAT-23 for rapid burnout screening. A free and validated tool, an alternative to the MBI (which is costly).

### Advantages
- Free for clinical and research use
- 12 items vs 23 (full version)
- High sensitivity (92%)
- Validated clinical cutoffs

---

## Complete Items (12)

### Exhaustion (3 items)
1. "At work, I feel mentally exhausted"
2. "Everything I do at work requires a great deal of effort"
3. "After a day at work, I find it hard to recover my energy"

### Mental Distance (3 items)
4. "I struggle to find any enthusiasm for my work"
5. "At work, I don't think much about what I'm doing and act on autopilot"
6. "I feel disconnected from my work"

### Cognitive Impairment (3 items)
7. "At work, I have difficulty concentrating"
8. "At work, I make mistakes because my mind is elsewhere"
9. "At work, I forget things"

### Emotional Impairment (3 items)
10. "At work, I get easily upset without wanting to"
11. "At work, I get easily irritated when things don't go my way"
12. "At work, I overreact without wanting to"

---

## Scale

| Value | Frequency |
|-------|-----------|
| 1 | Never |
| 2 | Rarely |
| 3 | Sometimes |
| 4 | Often |
| 5 | Always |

**Instruction**: "The following statements are about how you feel at work. Indicate how often you've felt this way in the last 4 weeks."

---

## Scoring

### Per Dimension
Arithmetic mean of the 3 items (1-5)

### Total Score
Mean of all 12 items (1-5)

---

## Clinical Cutoffs (Schaufeli et al., 2020)

### Total Score
| Score | Level | Color | Action |
|-------|-------|-------|--------|
| < 2.00 | Low | Green | None |
| 2.00-2.58 | Medium | Yellow | Monitoring |
| **2.59-3.01** | **High** | **Orange** | **Clinical attention** |
| **>= 3.02** | **Very high** | **Red** | **Handoff recommended** |

### Per Dimension
| Dimension | Green | Yellow | Orange | Red |
|-----------|-------|--------|--------|-----|
| Exhaustion | <2.60 | 2.60-3.19 | 3.20-3.79 | >=3.80 |
| Mental Distance | <2.20 | 2.20-2.69 | 2.70-3.19 | >=3.20 |
| Cognitive | <2.00 | 2.00-2.49 | 2.50-2.99 | >=3.00 |
| Emotional | <2.20 | 2.20-2.69 | 2.70-3.19 | >=3.20 |

---

## Profile Interpretation

### "Exhausted but Present" Profile
- Exhaustion high (>=3.20)
- Mental Distance low (<2.20)
- Interpretation: Still engaged but physically/mentally depleted
- Risk: Evolution toward complete burnout

### "Detached" Profile
- Mental Distance high (>=2.70)
- Others normal
- Interpretation: Coping strategy (withdrawal)
- Risk: Chronic disengagement

### "Cognitive" Profile
- Cognitive Impairment high (>=2.50)
- Interpretation: Concentration difficulties, errors
- Risk: Reduced performance, accidents

### "Complete Burnout" Profile
- All dimensions high
- Total score >= 3.02
- Action: Clinical handoff

---

## When to Administer

1. **Initial screening**: If burnout is suspected from history
2. **Elevated PHQ/GAD**: Differentiate burnout from depression/anxiety
3. **Very low UWES**: Investigate disengagement
4. **Verbal signals**: "I'm destroyed", "I can't take it anymore"

---

## Integration with Other Assessments

| BAT-12 + | Interpretation |
|----------|----------------|
| PHQ-9 >= 10 | Possible depression comorbidity |
| UWES < 2.0 | Confirms disengagement |
| Low PERMA P | Anhedonia (differentiate) |
| High JCS RD | Withdrawal as coping |

---

## Post-Screening Protocol

### BAT < 2.59 (Green/Yellow)
- Continue career coaching journey
- Monitor in subsequent sessions
- Focus on prevention (job crafting, boundaries)

### BAT 2.59-3.01 (Orange)
- Continue with caution
- Recommend baseline medical consultation
- Focus on recovery before changes
- Re-screening every 4 weeks

### BAT >= 3.02 (Red)
- Clinical handoff recommended
- Do not proceed with aggressive job crafting
- Focus on stabilization
- Consider leave/workload reduction

---

## Delivery Scripts

### Green/Yellow
> "Your work stress levels are normal / slightly elevated. There's nothing concerning, but it's important to take care of yourself. In our journey, we'll work on this too."

### Orange
> "Your levels indicate significant work stress. It's not clinical burnout yet, but it's an important signal. I'd recommend talking to your doctor about it. Meanwhile, we'll work together to lighten the load."

### Red
> "Your levels indicate significant burnout. Before continuing with career coaching, I recommend consulting a health professional - your doctor or a psychologist. Serious burnout requires specialized attention. Can I help you find resources?"

---

## Important Notes

1. **This is not a diagnosis**: The BAT is a screening tool, not a substitute for clinical evaluation
2. **ICD-11**: Burnout is an "occupational phenomenon" (QD85), NOT a mental disorder
3. **Comorbidity**: 90% of severe burnout meets criteria for depression
4. **Recovery time**: Severe burnout requires 6-12 months for full recovery
5. **Prevention**: Easier to prevent than to cure

---

## Resources

- BAT Manual: www.burnoutassessmenttool.be
- Full version (BAT-23): Available for free
- Multiple language validations available
