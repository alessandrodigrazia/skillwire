# Clinical Handoff Protocol

## Fundamental Principles

1. **Safety comes first**: Always
2. **You are not a therapist**: Recognize the limits
3. **Don't abandon**: Handoff is not abandonment
4. **Facilitate, don't force**: The user decides
5. **Document**: Everything for accountability

---

## Handoff Levels

### LEVEL 1: EMERGENCY (Immediate)

**Trigger**:
- Active suicidal ideation with a plan
- Ongoing self-harm
- Imminent risk to self or others
- Evident psychosis

**Action**:
1. STOP the normal session
2. Validate ("Thank you for telling me this")
3. Don't leave them alone
4. Provide emergency resources
5. Verify safety plan

**Script**:
> "[Name], what you're telling me is very important. Your safety is the most important thing right now.
>
> I ask you to contact IMMEDIATELY:
> - **Your local emergency number** (e.g., 911, 112, 999)
> - **A crisis hotline** (e.g., 988 Suicide & Crisis Lifeline in the US, or your local equivalent)
> - **The nearest emergency room**
>
> Are you with someone right now? Is there someone you can call?
>
> You are not alone in this. There are trained people to help you."

**If they refuse**:
> "I understand this may feel difficult. But I really need to know you are safe. Can we call together?"

---

### LEVEL 2: CRITICAL (Within 24-48 hours)

**Trigger**:
- PHQ-9 >= 20 (severe depression)
- Passive suicidal ideation
- BAT >= 3.02 + depressive symptoms
- Severe functional impairment

**Action**:
1. End session in a supportive manner
2. Express concern and care
3. Strongly recommend consultation
4. Offer support in finding resources
5. Follow-up within 48 hours

**Script**:
> "[Name], from what emerges today -- and I don't want to alarm you unnecessarily -- I believe it's important that you speak with a mental health professional.
>
> It's not a failure, quite the opposite: it's an act of self-care. What you're going through deserves specialized attention.
>
> Can I help you find someone? Or do you already have a doctor or psychologist you trust?
>
> Would it be okay if we check in again in a couple of days to see how you're doing?"

---

### LEVEL 3: HIGH (Within 1 week)

**Trigger**:
- PHQ-9 15-19 (moderate-severe depression)
- GAD-7 >= 15 (severe anxiety)
- BAT >= 3.02 (clinical burnout)
- Recent unprocessed trauma

**Action**:
1. Complete the session
2. Recommend consultation
3. Propose a parallel support path
4. Do not interrupt abruptly

**Script**:
> "[Name], career coaching can be useful for you, but I think you might also benefit from the support of a psychologist or counselor.
>
> It's not about choosing one or the other -- they can work in parallel. A mental health professional can help you with aspects that go beyond what I can offer as a coach.
>
> What do you think? Have you had experiences with therapy before?"

---

### LEVEL 4: MONITORING (Continue with attention)

**Trigger**:
- PHQ-9 10-14 (mild-moderate depression)
- GAD-7 10-14 (moderate anxiety)
- BAT 2.59-3.01 (at-risk burnout)
- Past history (in remission)

**Action**:
1. Continue the journey
2. Monitor every session
3. Suggest consultation (not mandatory)
4. Re-screening every 4 weeks

**Script**:
> "Your levels are a bit elevated but manageable. Let's continue our journey, but I ask you to let me know if you notice any worsening. And if you'd like, it might also be helpful to check in with your primary care doctor."

---

## Handoff Resources

### Emergency Resources
| Service | How to Access | Availability |
|---------|---------------|--------------|
| Emergency services | 911 (US), 112 (EU), 999 (UK), or local number | 24/7 |
| Crisis hotline | 988 (US), 116 123 (EU), Samaritans (UK) | 24/7 |
| Crisis Text Line | Text HOME to 741741 (US) or local equivalent | 24/7 |

### Non-Emergency Resources
| Type | How to Find |
|------|-------------|
| Psychologist | Psychology Today directory, local professional associations |
| Psychiatrist | Referral from primary care physician |
| Counseling services | Community mental health centers |
| Employee support | Employee Assistance Program (EAP) through employer |

### Online
- **Psychology Today**: Therapist directory with filters
- **BetterHelp / Talkspace**: Online therapy platforms
- **IASP**: International Association for Suicide Prevention (https://www.iasp.info/resources/Crisis_Centres/)

---

## Managing Resistance

### "I don't need a psychologist"
> "I understand. Many people feel that way at first. I'm not saying there's something wrong with you -- I'm saying that what you're facing is heavy and you deserve all the support possible. What worries you about the idea?"

### "I can't afford it"
> "I understand the financial concern. There are options: community health centers often offer free or sliding-scale services, some therapists have reduced rates, and many employers offer Employee Assistance Programs (EAP) with free sessions. Would you like to explore the options?"

### "I don't have time"
> "Time is a challenge, I understand. But think: how much time are you 'losing' because of how you feel? One session per week could give you much more than what you invest. And many therapists offer evening or online sessions."

### "I don't want medication"
> "Not all psychological pathways involve medication. A psychologist does not prescribe medication -- that's a psychiatrist, if needed. You can start with talk therapy and see how it goes."

---

## After the Handoff

### Follow-up
- [ ] Reach out within 48-72 hours to see how they are doing
- [ ] Ask if they took the recommended step
- [ ] Don't judge if they haven't
- [ ] Gently re-propose

### Continue or Not?
| Situation | Action |
|-----------|--------|
| Started clinical path | Continue coaching in parallel (if appropriate) |
| Hasn't contacted yet | Reiterate importance, explore obstacles |
| Categorically refuses | Document, continue with extreme caution |
| Getting worse | Insist on handoff, consider discontinuing |

### Documentation
For each handoff, record:
- Date and time
- Trigger (what activated handoff)
- Level (1-4)
- Script used
- User response
- Actions agreed upon
- Planned follow-up

---

## Scope of Practice Boundaries

### What Constitutes Unauthorized Practice
- Making diagnoses (e.g., "You have depression")
- Prescribing treatments
- Using psychotherapeutic techniques
- Treating mental disorders

### What a Coach CAN Do
- Observe symptoms ("I notice that...")
- Suggest consultation ("I recommend that you...")
- Provide information ("Depression is...")
- Support in the process of seeking help

**NOTE**: Always be aware of the scope of practice regulations in your jurisdiction. Career coaching is not a substitute for licensed mental health care.

---

## Coach Self-Care

Performing a handoff can be emotionally taxing. Remember:
- You are not responsible for the user's choices
- You fulfilled your duty by recommending help
- It's okay to feel distressed
- Seek supervision if needed
- You can't save everyone
