# Differential Diagnosis: Burnout vs Depression vs Anxiety

## Importance of Differentiation

Burnout, depression, and anxiety can present with similar symptoms but require different interventions. Correct differentiation is crucial for:
- Directing the appropriate intervention
- Avoiding harm (e.g., job crafting on clinical depression)
- Knowing when to handoff

**NOTE**: Vera does NOT make diagnoses. This guide serves to recognize signals and decide whether to continue or handoff.

---

## Comparison Table

| Criterion | Burnout | Depression | Generalized Anxiety |
|-----------|---------|------------|---------------------|
| **Specificity** | Work only | Pervasive (all areas) | Pervasive |
| **Weekends/holidays** | Improves | Does not improve | May improve |
| **Anhedonia** | Sectoral (work) | Global | Partial |
| **Self-esteem** | Professional | Global | Variable |
| **Energy** | Work exhaustion | Constant fatigue | Tension/agitation |
| **Sleep** | Difficulty "switching off" | Insomnia/hypersomnia | Difficulty falling asleep |
| **Concentration** | At work | Everywhere | Worries interfere |
| **Suicidal ideation** | Rare | Possible | Less common |
| **Onset** | Gradual (months-years) | Variable | Gradual |
| **ICD-11** | QD85 (occupational) | 6A70-6A7Z (disorder) | 6B00 (disorder) |

---

## Discriminating Questions

### To Differentiate Burnout from Depression

1. **"How do you feel on weekends or on vacation?"**
   - Burnout: "Better, I can relax"
   - Depression: "The same, nothing changes"

2. **"Are there activities that still give you pleasure?"**
   - Burnout: "Yes, outside of work I enjoy [hobbies, family, etc.]"
   - Depression: "Nothing gives me pleasure anymore"

3. **"Does your self-esteem concern only work or everything?"**
   - Burnout: "I feel like a failure at work"
   - Depression: "I feel like a failure as a person"

4. **"Do you ever think it's not worth going on?"**
   - Burnout: Rarely, if so related to work
   - Depression: Possible passive/active ideation

### To Differentiate Burnout from Anxiety

1. **"Do your worries concern only work?"**
   - Burnout: "Yes, mainly work"
   - Anxiety: "I worry about everything"

2. **"Can you physically relax?"**
   - Burnout: "Yes, when I disconnect"
   - Anxiety: "Never truly, I'm always tense"

3. **"Do you have constant physical symptoms?"**
   - Burnout: Fatigue, headaches after work
   - Anxiety: Muscle tension, palpitations, sweating

---

## Comorbidity

### Burnout + Depression
- **Prevalence**: 90% of severe burnout meets criteria for depression
- **Implication**: If BAT >= 3.02, always screen with PHQ-9
- **Action**: Handoff if PHQ-9 >= 15

### Burnout + Anxiety
- **Prevalence**: 70-80% of burnout has anxiety symptoms
- **Implication**: Anxiety may be reactive to burnout
- **Action**: Handoff if GAD-7 >= 15 or anxiety is disabling

### Triad
- Burnout + Depression + Anxiety can coexist
- When in doubt: always handoff
- Career coaching is NOT the primary intervention

---

## Decision Tree

```
SUSPECTED BURNOUT/DEPRESSION/ANXIETY
                |
                v
        [PHQ-2 >= 3?]
           /        \
          Yes        No
          |          |
          v          v
      [PHQ-9]    [GAD-2 >= 3?]
          |          /      \
          v         Yes      No
    [PHQ-9 Score]   |        |
     /    |    \    v        v
  >=15  10-14  <10 [GAD-7]  [BAT-12]
    |     |     |     |        |
    v     v     v     v        v
HANDOFF MONIT. OK  [Score]  [Score]
                    /   \    /   \
                  >=15 <15 >=3.02 <3.02
                   |    |    |      |
                   v    v    v      v
                HANDOFF OK HANDOFF CONT.
```

---

## Warning Signals for Immediate Handoff

### Depression
- [ ] Suicidal ideation (any)
- [ ] Self-harm
- [ ] PHQ-9 >= 20
- [ ] Psychotic symptoms
- [ ] Severe functional impairment

### Anxiety
- [ ] Frequent panic attacks
- [ ] Pervasive avoidance
- [ ] GAD-7 >= 15 + functional impairment
- [ ] Disabling physical symptoms

### Burnout
- [ ] BAT >= 3.02 + depressive symptoms
- [ ] Inability to work
- [ ] Severe somatic symptoms
- [ ] Substance use for coping

---

## What Vera Can Do

### Mild-Moderate Burnout (BAT < 2.59)
- [ ] Continue career coaching journey
- [ ] Job crafting (Branch A)
- [ ] Transition if appropriate (Branch B)
- [ ] Support on boundaries, priorities

### Moderate-High Burnout (BAT 2.59-3.01)
- [ ] Continue with caution
- [ ] Focus on recovery, not performance
- [ ] Recommend medical consultation
- [ ] Frequent monitoring

### CANNOT Do
- [ ] Clinical diagnoses
- [ ] Treatment for depression/anxiety
- [ ] Crisis management
- [ ] Interventions for severe burnout without clinical support

---

## Navigation Scripts

### When You Suspect Depression
> "Some things you're telling me make me think there might be something deeper than just work stress. I'm not a clinician, but I would recommend talking to your doctor or a psychologist to get a complete picture. What do you think?"

### When You Suspect Anxiety
> "I notice that your worries seem to go beyond work. Anxiety can have a significant impact. I would suggest consulting with a professional who can help you specifically with this aspect."

### When Boundaries Are Clear (Burnout)
> "From what you're telling me, it seems the problem is very much tied to work and improves when you disconnect. That's a good sign -- it means we can work together on how to better manage the work situation."

---

## Resources for Further Study

### Screening Tools
- PHQ-9: Public domain
- GAD-7: Public domain
- BAT: Free (www.burnoutassessmenttool.be)

### Guidelines
- ICD-11: Burnout definition (QD85)
- DSM-5: Depression/Anxiety criteria
- NICE Guidelines: Burnout management
