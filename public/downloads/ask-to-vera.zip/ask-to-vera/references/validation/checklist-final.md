# End-of-Journey Validation Checklist

## Before the Final Session

### Journey Review
- [ ] All sessions documented
- [ ] All assessments completed
- [ ] SMART objectives defined at session 4
- [ ] Branch-specific interventions executed
- [ ] Experiments documented with outcomes

### Output Preparation
- [ ] Data for PERMA delta ready (pre vs post)
- [ ] Final report template ready
- [ ] 90-day plan draft ready

---

## During Final Session

### Re-Assessment
- [ ] PERMA-Profiler re-administered
- [ ] Delta calculated for each dimension
- [ ] Total flourishing delta calculated
- [ ] UWES-9 re-administered (if Branch A)
- [ ] Branch-specific assessment re-administered

### Objective Review
- [ ] Objective 1: Achieved / Partial / Not achieved
- [ ] Objective 2: Achieved / Partial / Not achieved
- [ ] Objective 3: Achieved / Partial / Not achieved
- [ ] Achievement percentage calculated

### 90-Day Plan
- [ ] Month 1 defined with concrete actions
- [ ] Month 2 defined
- [ ] Month 3 defined
- [ ] Anticipated obstacles and strategies
- [ ] Self-check-ins planned
- [ ] Success criteria defined

### Emotional Closure
- [ ] Acknowledgment of the journey completed
- [ ] Authentic celebration of progress
- [ ] Space for user feedback
- [ ] Managing any closure emotions

### Autonomy
- [ ] Tools for continuing independently provided
- [ ] Criteria for potential follow-up clear
- [ ] Additional resources shared

---

## Success Metrics

### Primary Outcomes

| Metric | Target | Result | Achieved? |
|--------|--------|--------|-----------|
| PERMA Delta | >= 0.5 SD (+0.8 points) | | |
| Completion | Session 10 completed | | |
| Goal Achievement | >= 80% objectives | | |

### Secondary Outcomes

| Metric | Target | Result | Achieved? |
|--------|--------|--------|-----------|
| Final Session NPS | >= 8/10 | | |
| Assessment Completion | 100% | | |
| 90-Day Plan | Completed | | |

### Branch-Specific Metrics

**Branch A - Job Crafting**
| Metric | Target | Result |
|--------|--------|--------|
| JCS post > pre | >= +0.5 | |
| UWES post > pre | >= +0.5 | |
| Experiments completed | >= 2/3 | |

**Branch B - Transition**
| Metric | Target | Result |
|--------|--------|--------|
| Decision made | Yes/No | |
| Transition plan | Completed | |
| CAAS post > pre | >= +0.3 | |

**Branch C - Purpose**
| Metric | Target | Result |
|--------|--------|--------|
| Purpose Statement | Articulated | |
| Ikigai-9 post > pre | >= +0.3 | |
| Perceived alignment | >= 6/10 | |

---

## Final Report

### Required Contents
- [ ] Executive summary
- [ ] Initial situation
- [ ] Defined objectives
- [ ] Pre-assessment with visualizations
- [ ] Interventions carried out
- [ ] Post-assessment with delta
- [ ] Objectives achieved vs defined
- [ ] 90-day plan
- [ ] Resources for autonomy

### Format
- [ ] Markdown formatted correctly
- [ ] Visualizations included (PERMA radar, etc.)
- [ ] Language understandable (no technical jargon)
- [ ] Personalized for the user

---

## Post-Journey

### Documentation
- [ ] Final report saved
- [ ] Final scores recorded
- [ ] Closing notes written
- [ ] Any follow-up flags noted

### Overall Quality

Post-journey self-evaluation (1-5):

| Criterion | Score |
|-----------|-------|
| Therapeutic alliance | /5 |
| User progress | /5 |
| Protocol adherence | /5 |
| Safety management | /5 |
| Output quality | /5 |
| **TOTAL** | **/25** |

### Lessons Learned
- What worked particularly well?
- What could I have done better?
- Insights to carry into future journeys?

---

## Follow-Up Criteria

### When to Suggest Follow-Up
- [ ] Objectives partially achieved
- [ ] User expresses desire to continue
- [ ] New themes emerge to explore
- [ ] Transition in progress (Branch B)
- [ ] Purpose alignment still low (Branch C)

### When Follow-Up Is NOT Needed
- [ ] Objectives achieved
- [ ] User feels autonomous
- [ ] 90-day plan clear and achievable
- [ ] No active monitoring flags

### Suggested Follow-Up Timing
| Situation | Timing |
|-----------|--------|
| Light check-in | 30 days |
| Plan review | 90 days |
| New transition | When needed |
| Safety monitoring | Per protocol |

---

## Feedback for Skill Improvement

### Questions for the User
1. "What was most useful about this journey?"
2. "What could I have done differently?"
3. "Would you recommend this journey to others?"
4. "On a scale of 1 to 10, how satisfied are you?"

### To Document
- [ ] Feedback collected
- [ ] Suggestions for improving the skill
- [ ] Patterns to replicate
- [ ] Mistakes to avoid
