# Red Flags - Warning Signals

## Overview

This guide helps recognize warning signals during the coaching journey. Red flags require immediate attention or monitoring.

---

## Red Flag Level CRITICAL (Immediate Action)

### Suicide Risk
**Signals**:
- Direct expressions: "I don't want to live anymore", "It would be better if I wasn't here"
- Indirect expressions: "Soon it won't be a problem anymore", "I want to end it all"
- Giving away important possessions
- Talking about "being a burden"
- Sudden relief after a period of depression

**Action**:
1. STOP activity
2. C-SSRS screening
3. Emergency protocol if positive
4. Don't leave them alone

### Psychosis / Dissociation
**Signals**:
- Incoherent speech
- References to voices/visions
- Clearly unrealistic beliefs
- Loss of contact with reality
- Sudden bizarre behavior

**Action**:
1. Don't challenge the beliefs
2. Stay calm
3. Immediate handoff
4. Contact emergency services if there is risk

### Active Self-Harm
**Signals**:
- Direct admission
- Recent visible signs
- References to "hurting oneself"

**Action**:
1. Don't judge
2. Assess severity
3. Clinical handoff

---

## Red Flag Level HIGH (Handoff Recommended)

### Severe Depression
**Signals**:
- PHQ-9 >= 15
- Total anhedonia
- Functional impairment
- Marked isolation
- Significant appetite/sleep loss
- Pervasive feelings of worthlessness

**Action**:
1. Complete PHQ-9 screening
2. Recommend consultation
3. Follow-up within 48h

### Disabling Anxiety
**Signals**:
- GAD-7 >= 15
- Frequent panic attacks
- Pervasive avoidance
- Inability to carry out normal activities
- Constant physical symptoms

**Action**:
1. Complete GAD-7 screening
2. Recommend consultation
3. Monitoring

### Clinical Burnout
**Signals**:
- BAT >= 3.02
- Total exhaustion
- Marked cynicism
- Perceived inefficacy
- Somatic symptoms (headaches, digestive problems)
- Repeated "I can't take it anymore"

**Action**:
1. BAT-12 screening
2. Differentiate from depression
3. Handoff if severe

### Unprocessed Trauma
**Signals**:
- Flashbacks during session
- Avoidance of certain topics with strong reaction
- Dissociation (blank stare, disconnection)
- Disproportionate reaction to triggers
- Recent trauma history (< 6 months)

**Action**:
1. Don't force exploration
2. Acknowledge the trauma
3. Recommend specialized therapist
4. Do not proceed with coaching on trauma

---

## Red Flag Level MEDIUM (Monitoring)

### Moderate Depression
**Signals**:
- PHQ-9 10-14
- Persistently low mood
- Fatigue
- Concentration difficulties
- But still functional

**Action**:
1. Monitor every session
2. Suggest consultation
3. Re-screening every 4 weeks
4. Continue journey with caution

### Moderate Anxiety
**Signals**:
- GAD-7 10-14
- Frequent worries
- Tension
- But still manageable

**Action**: Same as above

### At-Risk Burnout
**Signals**:
- BAT 2.59-3.01
- Frequent tiredness
- Detachment from work
- But not yet clinical

**Action**:
1. No aggressive job crafting
2. Focus on recovery
3. Monitoring
4. Suggest primary care doctor visit

### Severe Interpersonal Conflict
**Signals**:
- References to mobbing/workplace bullying
- Toxic relationship with supervisor
- Harassment
- Discrimination

**Action**:
1. Don't minimize
2. Explore options (HR, legal)
3. It's not just a career coaching issue
4. Possible handoff to legal/HR

---

## Red Flag Level PROCESS (Journey Attention)

### Dropout Risk
**Signals**:
- Repeated cancellations
- Homework not completed
- Declining engagement
- Short answers, detachment

**Action**:
1. Explore causes
2. Renegotiate commitment
3. Adjust approach
4. Accept if it's not the right time

### Coach Dependency
**Signals**:
- Asks for confirmation for every decision
- Doesn't act without "permission"
- Frequent contacts between sessions
- Idealization of the coach

**Action**:
1. Reinforce autonomy
2. Avoid giving solutions
3. Reflect on the pattern
4. Consider if different support is needed

### Persistent Resistance
**Signals**:
- Rejects every suggestion
- Constant "Yes, but..."
- Doesn't do experiments
- Always stays stuck

**Action**:
1. Explore resistance (don't judge)
2. What scares them?
3. Is this the right path?
4. Possible different need

### Unrealistic Expectations
**Signals**:
- "I want to change everything right now"
- Impossible objectives
- Frustration if no immediate results
- Looking for "the answer"

**Action**:
1. Realign expectations
2. Focus on process, not outcome
3. Celebrate small progress
4. Educate on realistic timelines

---

## Branch-Specific Signals

### Branch A - Job Crafting
| Red Flag | Action |
|----------|--------|
| BAT increases during journey | Stop JC, focus on recovery |
| Manager blocks every change | Assess feasibility, possible Branch B |
| Objectively toxic environment | It's not a crafting problem |

### Branch B - Transition
| Red Flag | Action |
|----------|--------|
| Reactive decision (anger) | Cooling off period |
| Only push, no pull | Don't proceed |
| Zero runway | Financial stability first |
| Paralysis > 4 weeks | Return to bias audit |

### Branch C - Purpose
| Red Flag | Action |
|----------|--------|
| Deep existential crisis | Possible depression |
| Perfectionism in search | No "right" purpose exists |
| Pervasive emptiness | Depression screening |

---

## Quick Reference

| Color | Level | Action | Timing |
|-------|-------|--------|--------|
| RED | Critical | Emergency/Immediate handoff | Now |
| ORANGE | High | Handoff recommended | 24-48h |
| YELLOW | Medium | Monitoring + Suggest consultation | Next session |
| BLUE | Process | Adjust approach | During session |
