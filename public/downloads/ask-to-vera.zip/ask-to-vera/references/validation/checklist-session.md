# Session Validation Checklist

## Pre-Session

### Context
- [ ] Read the notes from the previous session
- [ ] Know the user's branch (A/B/C)
- [ ] Have a clear objective for this session
- [ ] Have the necessary reference files ready

### Safety
- [ ] Checked the last screening (PHQ/GAD/BAT)
- [ ] Know if there are active monitoring flags
- [ ] Aware of any warning signals that emerged

---

## During the Session

### Opening (5 min)
- [ ] Emotional check-in ("How are you today?")
- [ ] Recap of previous session
- [ ] Confirm agenda/session objective
- [ ] Any updates from the user

### Safety Check (if needed)
- [ ] Mood monitoring if flag is active
- [ ] Questions about significant changes
- [ ] Verify there are no new warning signals

### Session Body
- [ ] Session objective pursued
- [ ] Assessment administered correctly (if scheduled)
- [ ] Exercises/reflections completed
- [ ] Emerging insights documented
- [ ] Feedback given constructively

### Communication
- [ ] Asked open, non-leading questions
- [ ] Avoided prescriptive advice ("You should...")
- [ ] Validated emotions without minimizing
- [ ] Gently challenged if necessary
- [ ] Did not project own experiences

### Closing (10 min)
- [ ] Summary of what was explored
- [ ] Homework/action assigned (specific and measurable)
- [ ] Clear next steps
- [ ] Check-out ("How do you feel after this session?")
- [ ] Confirm next appointment

---

## Post-Session

### Documentation
- [ ] Session notes saved
- [ ] Assessment scores recorded (if administered)
- [ ] Key insights annotated
- [ ] Homework documented
- [ ] Warning signals (if present) highlighted

### Evaluation
- [ ] Session objective achieved?
- [ ] User seems to have benefited?
- [ ] Were there difficult moments to manage?
- [ ] Is follow-up needed on anything?

### Preparation for Next Session
- [ ] What to prepare for next session
- [ ] Assessments to administer
- [ ] Topics to revisit

---

## Checklist by Session Type

### Session 0 (Intake)
- [ ] PHQ-2 administered
- [ ] GAD-2 administered
- [ ] If >= 3, follow-up completed
- [ ] Current situation understood
- [ ] Branch identified
- [ ] Branch confirmed with user
- [ ] Commitment verified (>= 7/10)
- [ ] Expectations aligned
- [ ] Homework "what I wouldn't sacrifice" assigned

### Sessions 1-2 (Assessment)
- [ ] PERMA-Profiler completed
- [ ] Career Anchors (COI) completed
- [ ] UWES-9 completed
- [ ] Branch-specific assessment completed
- [ ] Scores calculated correctly
- [ ] Data ready for feedback session

### Session 3 (Results Feedback)
- [ ] Visualizations prepared
- [ ] Started with strengths
- [ ] Patterns explained in an understandable way
- [ ] User had space to react
- [ ] Gap analysis completed
- [ ] Insight shared and validated

### Session 4 (Goal Setting)
- [ ] SMART objectives defined (1-3)
- [ ] Objectives aligned with Career Anchors
- [ ] Anticipated obstacles discussed
- [ ] Commitment to objectives verified

### Sessions 5-7 (Intervention)
- [ ] Branch protocol followed
- [ ] Experiment defined (specific, measurable)
- [ ] Homework assigned
- [ ] Progress vs previous session verified

### Sessions 8-10 (Consolidation)
- [ ] Experiments reviewed
- [ ] Learnings documented
- [ ] 90-day plan built
- [ ] Re-assessment completed (if session 10)
- [ ] Delta calculated
- [ ] Final report generated
- [ ] Resources for autonomy provided

---

## Red Flags During Session

### Stop and Evaluate if:
- [ ] User mentions suicidal ideation
- [ ] User appears dissociated
- [ ] User in acute crisis
- [ ] Undisclosed trauma emerges
- [ ] Distress level increases significantly

### Action:
1. Stop current activity
2. Validate ("Thank you for telling me this")
3. Assess risk level
4. Follow handoff protocol if necessary
5. Document

---

## Session Quality Score

Post-session self-evaluation (1-5):

| Criterion | Score |
|-----------|-------|
| Objective achieved | /5 |
| User engaged | /5 |
| Effective communication | /5 |
| Safety monitored | /5 |
| Clean closure | /5 |
| **TOTAL** | **/25** |

- 20-25: Excellent session
- 15-19: Good session
- 10-14: Needs improvement
- <10: Review needed
