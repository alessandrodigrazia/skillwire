# Output Template - Branch B: Career Transition

## Career Transition Assessment Report

```markdown
# CAREER TRANSITION PROFILE - [Name]
Date: [Date]
Session: [Number]

---

## 1. INITIAL SITUATION

### Current Context
- Role: [Current role]
- Company/Sector: [Name/Sector]
- Tenure: [X years]

### Transition Motivation
[Brief description of why they are considering change]

### Considered Direction
[Where they're thinking of going]

---

## 2. ASSESSMENT RESULTS

### CAAS - Career Adapt-Abilities
| Dimension | Score | Level | Notes |
|-----------|-------|-------|-------|
| Concern | /5 | | |
| Control | /5 | | |
| Curiosity | /5 | | |
| Confidence | /5 | | |
| **Total** | **/5** | | |

**Profile**: [E.g. "Explorer without direction", "Ready for change", etc.]

### Career Anchors (Relevant for Transition)
| Anchor | Score | Implication |
|--------|-------|------------|
| [Top 1] | | |
| [Top 2] | | |
| [Top 3] | | |

### PERMA (Focus on M and A)
- Meaning: /10
- Accomplishment: /10

---

## 3. DECISION ANALYSIS

### Push-Pull Analysis

**Push Factors** (What drives away):
| Factor | Weight |
|--------|--------|
| | |
| | |
| **Total Push** | |

**Pull Factors** (What attracts):
| Factor | Weight |
|--------|--------|
| | |
| | |
| **Total Pull** | |

**Push:Pull Ratio**: [X:Y]
**Interpretation**: [...]

### Identified Biases
- [ ] Status quo: [Present/Absent] - [Notes]
- [ ] Loss aversion: [Present/Absent] - [Notes]
- [ ] Sunk cost: [Present/Absent] - [Notes]

### Bridges Phase
Currently in: [ ] Endings [ ] Neutral Zone [ ] New Beginnings

---

## 4. OPTIONS EVALUATED

### Decision Matrix

| Criterion | Weight | Opt 1 | Opt 2 | Opt 3 |
|----------|--------|-------|-------|-------|
| | | | | |
| | | | | |
| **TOTAL** | | | | |

### Recommended Option
[Option X] because [...]

### Remaining Information Gaps
- [ ] [Gap 1]: [How to fill]
- [ ] [Gap 2]: [How to fill]

---

## 5. TRANSITION PLAN

### Timeline
- Transition type: [Same sector/Sector change/...]
- Estimated duration: [X months]
- Target date: [Date]

### Milestones

**Phase 1: Preparation (Weeks 1-4)**
- [ ] [Action 1]
- [ ] [Action 2]
- [ ] [Action 3]

**Phase 2: Exploration (Weeks 5-8)**
- [ ] [Action 4]
- [ ] [Action 5]
- [ ] [Action 6]

**Phase 3: Action (Weeks 9-12)**
- [ ] [Action 7]
- [ ] [Action 8]
- [ ] Decision Point

### Plan B
- Plan B trigger: [Condition]
- Alternative: [Description]
- Exit strategy: [Description]

---

## 6. RISKS AND MITIGATIONS

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| | | | |
| | | | |
| | | | |

---

## 7. SUPPORT

### Support Network
- Mentor/Coach: [Name]
- Peer support: [Who]
- Family: [Who]

### External Resources
- [Resource 1]
- [Resource 2]

---

*Report generated with Ask to Vera - Career & Purpose Coach AI*
```

---

## 90-Day Plan - Career Transition

```markdown
# 90-DAY PLAN - CAREER TRANSITION
Name: [Name]
Start date: [Date]
Branch: B - Career Transition
Target: [Target role/sector]

---

## MAIN OBJECTIVE
[SMART description: e.g. "Obtain at least 1 offer in sector X by [date]"]

---

## RUNWAY CHECK
- Current runway in months: [X]
- Minimum necessary runway: [Y]
- Gap to fill: [Z]

---

## MONTH 1: PREPARATION

### Week 1: Foundations
- [ ] Update CV (version for [target sector])
- [ ] LinkedIn audit (headline, about, experience)
- [ ] List 10 target companies
- [ ] Identify 5 contacts in the sector

### Week 2: Network Activation
- [ ] Message 3 warm contacts
- [ ] Connection requests to 5 target people
- [ ] LinkedIn post on [relevant topic]
- [ ] Join 2 groups/communities

### Week 3: Informational Interviews
- [ ] Schedule 2 informational interviews
- [ ] Prepare questions
- [ ] Conduct first interview
- [ ] Follow-up and notes

### Week 4: Review and Adjust
- [ ] What did I learn this month?
- [ ] Is the direction still right?
- [ ] What do I need to adjust?

**Month 1 Milestone**:
- [ ] CV ready
- [ ] 2 informational interviews completed
- [ ] Direction validated or adjusted

---

## MONTH 2: ACTIVE EXPLORATION

### Weeks 5-6: Exploratory Applications
- [ ] 3-5 applications to target positions
- [ ] Tracking in spreadsheet
- [ ] 30-60-90 pitch preparation

### Weeks 7-8: Skill Gap
- [ ] Identify critical skill gap
- [ ] Start course/certification if needed
- [ ] Side project to demonstrate skills

**Month 2 Milestone**:
- [ ] At least 5 applications sent
- [ ] At least 1 interview obtained
- [ ] Main skill gap being addressed

---

## MONTH 3: DECISIVE ACTION

### Weeks 9-10: Intensification
- [ ] Targeted applications (10+)
- [ ] Follow-up on all applications
- [ ] Intensive interview preparation

### Week 11: Decision Point
- [ ] Evaluate offers (if present)
- [ ] Go/No-Go assessment
- [ ] Negotiate if Go

### Week 12: Execution or Pivot
**If Go**:
- [ ] Accept offer
- [ ] Communicate resignation
- [ ] Plan onboarding

**If No-Go**:
- [ ] Analysis: what didn't work?
- [ ] Decision: continue, pivot, or pause?
- [ ] New plan if needed

---

## TRACKING

### Weekly Dashboard
| Week | Applications | Interviews | Network | Notes |
|------|-------------|----------|---------|-------|
| 1 | | | | |
| 2 | | | | |
| ... | | | | |

### KPIs
- Applications sent: ___ / 20 target
- Interviews obtained: ___ / 5 target
- Offers received: ___ / 1 target
- Informational interviews: ___ / 5 target

---

## OBSTACLES AND STRATEGIES

| Obstacle | Strategy | Plan B |
|----------|----------|--------|
| No responses to applications | Increase network referrals | Review CV with feedback |
| Interviews don't convert | Mock interview + feedback | Different targeting |
| Offers below expectations | Negotiate / evaluate growth | Extend search |
| Search burnout | Week off, self-care | Peer support |

---

## SELF CHECK-INS

### End of Month 1
- [ ] Did I reach the milestones?
- [ ] Is the direction still right?
- [ ] What do I need to continue?

### End of Month 2
- [ ] Progress vs expectations?
- [ ] Do I need to adjust the timeline?
- [ ] Red flags to consider?

### End of Month 3
- [ ] Outcome: [Success/In progress/Pivot]
- [ ] Lessons learned
- [ ] Next steps

---

## WHEN TO ASK FOR HELP

Contact Vera again if:
- [ ] Decision paralysis > 2 weeks
- [ ] Disabling anxiety
- [ ] Doubts about direction
- [ ] Offer to evaluate
- [ ] Need mock interview support

---

*Plan created with Ask to Vera - Career & Purpose Coach AI*
*Good luck with your transition!*
```
