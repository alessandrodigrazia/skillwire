# Decision Tools - Branch B

## Tool 1: Weighted Decision Matrix

### How to Use It

**Step 1**: List the options (minimum 3)
```
Option A: _______________
Option B: _______________
Option C: _______________
```

**Step 2**: Define the criteria important to YOU

| # | Criterion | Weight (1-5) |
|---|----------|------------|
| 1 | Alignment with my values | |
| 2 | Professional growth | |
| 3 | Financial compensation | |
| 4 | Work-life balance | |
| 5 | Security/stability | |
| 6 | Interest in content | |
| 7 | Relationship quality | |
| 8 | [Personalized] | |

**Step 3**: Rate each option (1-5 per criterion)

| Criterion | Weight | Opt A | Opt B | Opt C |
|----------|--------|-------|-------|-------|
| 1 | | x = | x = | x = |
| 2 | | x = | x = | x = |
| ... | | | | |
| **TOTAL** | | **__** | **__** | **__** |

**Step 4**: Calculate (Weight x Rating for each cell, then sum)

**Step 5**: Analyze
- Highest score = rationally best option
- Does the result surprise you?
- Which option were you "hoping" would win?

---

## Tool 2: Push-Pull Analysis

### Template

**PUSH FACTORS** (What drives you away from current situation)

| # | Factor | Intensity (1-10) |
|---|--------|-------------------|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| | **TOTAL PUSH** | **___** |

**PULL FACTORS** (What attracts you toward the new)

| # | Factor | Intensity (1-10) |
|---|--------|-------------------|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| | **TOTAL PULL** | **___** |

### Interpretation

| Ratio | Meaning | Action |
|-------|---------|--------|
| Pull > Push | Positive motivation | Good sign for transition |
| Pull = Push | Balance | Explore more |
| Push > Pull | Flight, not choice | Find Pull before acting |
| Only Push | Red flag | Not the right time |

---

## Tool 3: Pre-Mortem Analysis

### Concept
Instead of asking "how to succeed?", ask "how could this fail?"

### Template

**Scenario**: Imagine that in 12 months the transition has failed miserably.

**Questions**:

1. **What went wrong?**
   - _______________
   - _______________
   - _______________

2. **What signals had you ignored?**
   - _______________
   - _______________

3. **What hadn't you considered?**
   - _______________
   - _______________

4. **What resources were you missing?**
   - _______________
   - _______________

### Mitigation Plan

| Identified Risk | Probability (1-5) | Impact (1-5) | Mitigation |
|----------------|-------------------|---------------|------------|
| | | | |
| | | | |
| | | | |

**Priority**: Focus on risks with Probability x Impact >= 15

---

## Tool 4: Regret Minimization Framework

### Exercise (Jeff Bezos)

> Imagine you are 80 years old and looking back at your life.

**Scenario A: You made the change**
- How do you feel looking back?
- What are you proud of?
- What do you regret?
- Answer: _______________

**Scenario B: You didn't make the change**
- How do you feel looking back?
- What are you proud of?
- What do you regret?
- Answer: _______________

### Final Question
> "What would you regret more: having tried and failed, or never having tried?"

---

## Tool 5: Reversibility Assessment

### Concept
Not all decisions carry the same weight. Assessing reversibility reduces anxiety.

### Template

| Aspect of Decision | Reversible? | Cost of Reversal | Time to Reverse |
|-------------------|-------------|------------------|-----------------|
| Leaving current job | | | |
| Accepting new position | | | |
| Relocating | | | |
| Changing sectors | | | |
| Investing in training | | | |
| [Other] | | | |

### Classification

| Type | Description | Approach |
|------|-------------|----------|
| **Revolving door** | Easily reversible | Act, experiment |
| **Glass door** | Reversible with cost | Test before committing |
| **Steel door** | Difficult to reverse | Deep analysis first |

---

## Tool 6: 10-10-10 Analysis (Suzy Welch)

### Questions

For each option, ask:

1. **How will I feel in 10 MINUTES?**
   - Immediate emotional reaction
   - Answer: _______________

2. **How will I feel in 10 MONTHS?**
   - After initial adaptation
   - Answer: _______________

3. **How will I feel in 10 YEARS?**
   - Long-term impact
   - Answer: _______________

### Analysis
- If all three positive: GO
- If only 10 minutes negative: That's normal (fear of change)
- If 10 years negative: Reconsider

---

## Tool 7: Decision Journal

### Purpose
Document the decision-making process to learn from it.

### Entry Template

**Date**: _______________
**Decision in question**: _______________

**Options considered**:
1. _______________
2. _______________
3. _______________

**Available information**:
- _______________
- _______________

**Missing information**:
- _______________

**Current emotions**:
- _______________

**Potential biases**:
- _______________

**Decision made**: _______________

**Main reasons**:
1. _______________
2. _______________
3. _______________

**What I expect to happen**: _______________

**3-month review** (to be completed later):
- What actually happened: _______________
- Was the decision right? _______________
- What I learned: _______________

---

## Tool 8: Confidence Check

### Calibration Questions

Before making a final decision:

| Question | Score (1-10) |
|----------|--------------|
| How certain am I of this decision? | |
| How thoroughly have I explored alternatives? | |
| How much have I consulted others? | |
| How well do I understand the risks? | |
| How prepared am I to fail? | |

**If average < 6**: More exploration needed
**If average 6-8**: Proceed with caution
**If average > 8**: Watch for overconfidence

### Final Reality Check
> "If a friend were in my situation and asked me for advice, what would I tell them?"
