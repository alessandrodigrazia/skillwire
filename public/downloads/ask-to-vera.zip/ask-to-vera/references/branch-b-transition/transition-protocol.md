# Career Transition Protocol - Branch B

## Overview

Branch B guides professionals through career change decisions using evidence-based frameworks: Bridges Transition Model and Planned Happenstance.

---

## Bridges Transition Model

### The 3 Phases

```
[ENDINGS]  ->  [NEUTRAL ZONE]  ->  [NEW BEGINNINGS]
 Letting go     Uncertainty          Starting
               Exploration          something new
```

### Phase 1: Endings
Before starting something new, one must conclude something old.

**Psychological tasks**:
- Recognize what is being left behind
- Process the losses (even of negative things)
- Say goodbye to the previous identity

**Key questions**:
- "What do you lose by leaving your current role?"
- "What won't you miss?"
- "Who were you in that role?"

### Phase 2: Neutral Zone
A period of uncertainty between old and new. It is not emptiness - it is transformation.

**Characteristics**:
- Normal disorientation
- Increased creativity
- Anxiety and opportunity coexist

**Tasks**:
- Tolerate uncertainty
- Explore possibilities
- Don't rush decisions

**Key questions**:
- "How are you experiencing this uncertainty?"
- "What are you discovering about yourself?"
- "What possibilities are opening up?"

### Phase 3: New Beginnings
The psychological beginning, not just the practical change.

**Characteristics**:
- New identity
- New skills
- New relationships

**Tasks**:
- Build new professional identity
- Acquire necessary skills
- Create new network

---

## Session 5: Decision Diagnosis

### Objective
Understand WHETHER to change (not yet WHAT or HOW)

### Phase 1: Cognitive Bias Audit (20 min)

**Biases to check**:

| Bias | Description | Test Question |
|------|-------------|---------------|
| **Status Quo** | Preference for current situation | "Are you choosing to stay or avoiding change?" |
| **Loss Aversion** | Losses weigh 2x more than gains | "What weighs more: what you lose by going or what you lose by staying?" |
| **Sunk Cost** | Weight of time/resources invested | "How much does the time already invested influence your decision?" |
| **Present Bias** | Undervaluing the future | "How will you feel in 5 years if you don't change?" |
| **Confirmation** | Seeking confirmation for a decision already made | "Are you seeking reasons or gathering information?" |

**De-biasing exercise**:
> "Imagine giving advice to a friend in your exact same situation. What would you tell them?"

### Phase 2: Push vs Pull Analysis (20 min)

**Push Factors** (what drives away):
- Current dissatisfaction
- Toxic environment
- Lack of growth
- Values misalignment

**Pull Factors** (what attracts):
- Specific opportunity
- Interesting sector
- Possible growth
- Values alignment

**Red Flag**: Only push, no pull = "running from" not "going toward"

**Template**:
| Push (Drives Away) | Weight (1-10) | Pull (Attracts) | Weight (1-10) |
|-------------------|---------------|-----------------|---------------|
| | | | |
| | | | |

**Analysis**:
- Total Push: ___
- Total Pull: ___
- Ideal ratio: Pull >= Push

### Phase 3: Go/No-Go Criteria (20 min)

**Pre-Decision Checklist**:

| Criterion | Yes | No | Notes |
|----------|-----|-----|-------|
| I have at least 1 clear Pull | | | |
| I'm not in an acute crisis | | | |
| I have 6+ months runway | | | |
| I've explored alternatives | | | |
| I've talked to someone who's been through it | | | |

**If 3+ "No"**: Slow down, it's not the right time

**Homework**: Write "letter to myself in 1 year" from both perspectives (stay vs go)

---

## Session 6: Exploring Options

### Objective
Generate and evaluate concrete alternatives

### Phase 1: Option Brainstorming (15 min)

**Rules**:
- Minimum 3 options (including "stay")
- No judgment in this phase
- Include "crazy" options

**Prompts**:
- "If you could do anything, what would you do?"
- "What would you do if you weren't afraid?"
- "What would your friends recommend?"

### Phase 2: Decision Matrix (25 min)

**Step 1**: Define important criteria
- Values alignment (weight: ___)
- Professional growth (weight: ___)
- Financial compensation (weight: ___)
- Work-life balance (weight: ___)
- Security/stability (weight: ___)
- [Other]: (weight: ___)

**Step 2**: Evaluate each option

| Criterion | Weight | Option 1 | Option 2 | Option 3 |
|----------|--------|----------|----------|----------|
| | | | | |
| | | | | |
| **TOTAL** | | | | |

**Step 3**: Analyze results
- Which option has the highest score?
- Does the result surprise you?
- What's missing from the evaluation?

### Phase 3: Information Gaps (10 min)

**For each top option**:
- What do I still need to know?
- Who could tell me?
- How can I find out?

| Option | Information Gap | Source | Action |
|--------|----------------|--------|--------|
| | | | |

### Phase 4: Regret Minimization (10 min)

**Bezos Exercise**:
> "Imagine you're 80 years old and looking back.
> What would you regret most?
> - Not having tried?
> - Having tried and failed?
> - Having stayed?"

**Homework**: Informational interview with 1 person in the target sector/role

---

## Session 7: Transition Plan

### Objective
Build a concrete and realistic roadmap

### Phase 1: Realistic Timeline (15 min)

**Reference Timeline**:
| Transition Type | Timeline | Notes |
|-----------------|----------|-------|
| Same sector, similar role | 3-6 months | |
| Same sector, different role | 6-9 months | Upskilling |
| Different sector, similar role | 6-12 months | Networking |
| Different sector, different role | 12-18 months | Gradual transition |
| Entrepreneurship | 12-24 months | Validation + runway |

**Questions**:
- "What type of transition are you considering?"
- "When would you ideally like to start?"
- "How much financial runway do you have?"

### Phase 2: Milestones (20 min)

**Plan Template**:

**PHASE 1: Preparation (Weeks 1-4)**
- [ ] Update CV
- [ ] Optimize LinkedIn
- [ ] Identify 5 target companies
- [ ] Activate network

**PHASE 2: Exploration (Weeks 5-8)**
- [ ] 3 informational interviews
- [ ] 2 exploratory applications
- [ ] Close 1 skill gap
- [ ] Validate direction

**PHASE 3: Action (Weeks 9-12)**
- [ ] Targeted applications
- [ ] Negotiate offers
- [ ] Decision point: Go/No-Go
- [ ] Communication (if Go)

### Phase 3: Plan B (15 min)

**Questions**:
- "If in 6 months you haven't found anything, what do you do?"
- "What's your point of no return?"
- "What would happen if you went back to your current role?"

**Exit Strategy**:
- Maximum timeline: ___ months
- Stop signal: ___
- Alternative if it doesn't work: ___

### Phase 4: Quick Wins (10 min)

**Immediate actions (next 7 days)**:
1. ___
2. ___
3. ___

**Principle**: Start small to build momentum

---

## Managing Uncertainty

### Normalizing Anxiety

> "Uncertainty is normal and necessary in transitions. It doesn't mean you're doing it wrong - it means you're changing."

### Planned Happenstance (Krumboltz)

**Principle**: The best careers often arise from unexpected events, not rigid plans.

**5 Competencies**:
1. **Curiosity**: Exploring new opportunities
2. **Persistence**: Not giving up at the first obstacles
3. **Flexibility**: Adapting to changing circumstances
4. **Optimism**: Seeing possibilities, not just risks
5. **Risk-taking**: Acting despite uncertainty

---

## Red Flags During Branch B

| Signal | Action |
|--------|--------|
| Decision paralysis > 4 weeks | Return to bias audit |
| Only flight, no pull | Explore deeper causes |
| Disabling anxiety | Consider psychological support |
| Reactive decision (argument, anger) | Cooling off period |
| Insufficient runway | Plan accumulation first |
