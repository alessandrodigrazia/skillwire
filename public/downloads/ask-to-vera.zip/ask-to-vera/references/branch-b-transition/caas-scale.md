# CAAS - Career Adapt-Abilities Scale

## Overview

The Career Adapt-Abilities Scale (Savickas & Porfeli, 2012) measures psychosocial resources for managing career transitions and changes. It is the primary instrument for assessing career adaptability.

### Evidence Base
- Validated in 13 countries
- Predicts employability (r = .54), job satisfaction (r = .48), career success (r = .42)
- Total alpha: .92

---

## The 4Cs of Adaptability

| Dimension | Description | Key Question |
|-----------|-------------|--------------|
| **Concern** | Caring about the professional future | "Do I have a future?" |
| **Control** | Feeling responsible for one's career | "Who decides?" |
| **Curiosity** | Exploring possibilities and options | "What could I do?" |
| **Confidence** | Believing in one's ability to achieve aspirations | "Can I do it?" |

---

## Complete Items (24 total)

### Concern - Future Orientation (6 items)
1. Thinking about what my future will be like
2. Realizing that today's choices shape my future
3. Preparing for the future
4. Becoming aware of the educational and career choices I must make
5. Planning how to achieve my goals
6. Concerned about my career

### Control (6 items)
7. Keeping my beliefs
8. Counting on myself
9. Doing what is right for me
10. Taking responsibility for my actions
11. Standing up for my beliefs
12. Making decisions on my own

### Curiosity (6 items)
13. Exploring my surroundings
14. Looking for opportunities to grow
15. Investigating options before making a choice
16. Observing different ways of doing things
17. Probing deeply into questions I have
18. Becoming curious about new opportunities

### Confidence (6 items)
19. Performing tasks efficiently
20. Taking care to do things well
21. Learning new skills
22. Working up to my abilities
23. Overcoming obstacles
24. Solving problems

---

## Scale

| Value | Label |
|-------|-------|
| 1 | Not at all strong |
| 2 | Not very strong |
| 3 | Somewhat strong |
| 4 | Strong |
| 5 | Very strong |

**Instruction**: "People use different abilities to build their careers. Nobody is good at everything. How strong do you consider each of the following abilities to be in you?"

---

## Scoring

### Per Dimension
Arithmetic mean of 6 items (1-5)

### Total Score
Mean of the 4 dimension means (1-5)

---

## Reference Norms

### International (Savickas, 2012)
| Dimension | Mean | SD |
|-----------|------|-----|
| Concern | 3.83 | 0.68 |
| Control | 4.03 | 0.58 |
| Curiosity | 3.73 | 0.66 |
| Confidence | 3.98 | 0.57 |
| **Total** | **3.89** | **0.51** |

### Interpretation
| Score | Level | Description |
|-------|-------|-------------|
| < 3.0 | Low | Resource to develop |
| 3.0-3.5 | Medium-low | Area of attention |
| 3.5-4.0 | Medium | Normal range |
| 4.0-4.5 | High | Resource present |
| > 4.5 | Very high | Strength |

---

## Typical Profiles in Transitions

### "Ready for Change" Profile
- All 4Cs high (> 4.0)
- Balance across dimensions
- Good candidate for transition

### "Decision Paralysis" Profile
- Control high, Curiosity low
- Knows they need to decide but doesn't explore
- Intervention: stimulate exploration

### "Explorer Without Direction" Profile
- Curiosity high, Concern low
- Explores without direction
- Intervention: build future vision

### "Insecure Dreamer" Profile
- Concern high, Confidence low
- Has goals but doesn't believe in them
- Intervention: build self-efficacy

### "Stuck" Profile
- All 4Cs low
- Requires multi-front intervention
- Start with Control (internal locus)

---

## Interventions per Dimension

### Low Concern
- "Letter from the future" exercise
- Career timeline (past -> present -> future)
- Questions: "Where do you see yourself in 5 years?"

### Low Control
- Identify areas under your own control
- Past successful decisions exercise
- Questions: "When did you make an important decision that worked?"

### Low Curiosity
- Informational interviews
- Job shadowing
- Exploring adjacent sectors
- Questions: "What interests you that you've never explored?"

### Low Confidence
- Past successes inventory
- Identify transferable skills
- Progressive micro-successes
- Questions: "What was the most difficult challenge you overcame?"

---

## Integration with Other Assessments

| CAAS + | Pattern | Meaning |
|--------|---------|---------|
| High COI AU | Control important | Transition toward autonomy |
| High COI SE | Concern about security | Attention to risk assessment |
| Low PERMA M | Missing purpose | Branch C first, then B |
| Low UWES | Disengagement | Intrinsic motivation? |

---

## Operational Notes

- Administer at the start of Branch B
- Time: 10 minutes
- Use results to personalize intervention
- Re-assessment optional at end of journey
- Focus on lowest dimension as intervention priority
