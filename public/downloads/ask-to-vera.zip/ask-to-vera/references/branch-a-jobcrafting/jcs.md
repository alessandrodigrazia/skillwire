# JCS - Job Crafting Scale

## Overview

The Job Crafting Scale (Tims & Bakker, 2012; Italian validation: Cenciotti et al., 2016) measures proactive behaviors in redesigning one's own work. A 13-item reduced version of the original JCS.

## Dimensions

| Dimension | Description | Items |
|-----------|-------------|-------|
| **Seeking Structural Resources** | Seeking development and learning opportunities | 4 |
| **Seeking Social Resources** | Seeking feedback and support | 3 |
| **Seeking Challenges** | Seeking new challenges and tasks | 3 |
| **Reducing Demands** | Reducing cognitive/emotional demands | 3 |

---

## Complete Items (13)

### Seeking Structural Resources (SR) - 4 items
1. "I try to learn new things at work"
2. "I try to develop my skills"
3. "I try to develop my professional capabilities"
4. "I try to use my abilities to the fullest in my work"

### Seeking Social Resources (SS) - 3 items
5. "I ask others for feedback on my performance"
6. "I ask colleagues for advice"
7. "I ask my supervisor to coach me"

### Seeking Challenges (SC) - 3 items
8. "When there isn't much to do, I see it as an opportunity to start new projects"
9. "I try to make my work more challenging by examining the underlying mechanisms"
10. "I volunteer for new projects"

### Reducing Demands (RD) - 3 items
11. "I organize my work to reduce contact with people whose problems affect me emotionally"
12. "I organize my work to reduce contact with colleagues who have unrealistic expectations"
13. "I try to ensure that my work is mentally less demanding"

---

## Scale

| Value | Label |
|-------|-------|
| 1 | Never |
| 2 | Rarely |
| 3 | Sometimes |
| 4 | Often |
| 5 | Very often |

---

## Scoring

### Per Dimension
Arithmetic mean of the dimension's items (1-5)

### Total Score
Mean of all 13 items (1-5)

**NOTE**: The "Reducing Demands" score should be interpreted separately - do NOT add it to the others.

---

## Psychometric Properties (Cenciotti et al., 2016; Tims & Bakker, 2012)

| Dimension | Alpha | Mean | SD |
|-----------|-------|------|-----|
| Seeking Structural | .85 | 3.89 | 0.71 |
| Seeking Social | .78 | 3.12 | 0.89 |
| Seeking Challenges | .81 | 3.34 | 0.85 |
| Reducing Demands | .76 | 2.45 | 0.92 |

---

## Interpretation

### Seeking Resources (SR + SS + SC)
| Score | Level | Interpretation |
|-------|-------|----------------|
| < 2.5 | Low | Little proactivity |
| 2.5-3.5 | Medium | Moderate job crafting |
| > 3.5 | High | Active job crafting |

### Reducing Demands (RD)
| Score | Level | Interpretation |
|-------|-------|----------------|
| < 2.0 | Low | Not reducing demands |
| 2.0-3.0 | Medium | Some coping strategies |
| > 3.0 | High | **ATTENTION** - Possible burnout or withdrawal |

---

## Reducing Demands Paradox

**IMPORTANT**: Research shows that high levels of "Reducing Demands" are often correlated with:
- Burnout (not the solution, but a symptom)
- Disengagement
- Reduced performance

**Clinical interpretation**:
- High RD = sign of overload, not an effective coping strategy
- Before doing "expansive" job crafting (seeking), verify the user is not in burnout
- If high RD + low UWES: priority is recovery, not aggressive job crafting

---

## Diagnostic Patterns

| Pattern | Interpretation | Action |
|---------|----------------|--------|
| SR high, SS low | Learns alone, avoids feedback | Explore resistance to feedback |
| SC high, others low | Seeks challenges but not resources | Exhaustion risk |
| RD high, others low | Withdrawal | Burnout screening |
| All low | Passivity | Explore causes (learned helplessness?) |
| All high except RD | Balanced job crafter | Continue journey |

---

## Exploration Questions

**For low SR**:
- "What would prevent you from seeking new learning opportunities?"
- "When was the last time you learned something new at work?"

**For low SS**:
- "How often do you ask for feedback? How does it make you feel?"
- "Who do you trust enough to ask for advice?"

**For low SC**:
- "What happens when you have free time at work?"
- "When was the last time you proposed something new?"

**For high RD**:
- "What's driving you to reduce certain aspects of your work?"
- "Are these strategies helping you or do you feel more isolated?"

---

## Integration with Other Assessments

| JCS + | Pattern | Meaning |
|-------|---------|---------|
| Low UWES | Disengagement | JC as attempt at recovery |
| Low PERMA E | No flow | JC to find engagement |
| High COI AU | Autonomy need | JC as expression of AU |
| High BAT + high RD | Burnout | Recovery first, then JC |

---

## Operational Notes

- Administer after Career Anchors (understand motivations first)
- Time: 5 minutes
- Use as pre-intervention and post-intervention baseline
- Intervention focus on "seeking" dimensions, not on RD
