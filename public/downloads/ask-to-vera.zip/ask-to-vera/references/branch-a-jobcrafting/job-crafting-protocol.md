# Job Crafting Protocol - Branch A

## Overview

Job Crafting is the set of proactive behaviors through which workers redesign their own work to align it with their needs, skills, and preferences (Wrzesniewski & Dutton, 2001).

### Evidence Base
- Meta-analysis Rudolph et al. (2017): 35,670 workers, JC correlated with engagement (rc = .45)
- 6-week protocol Gordon et al. (2018): significant improvements in wellbeing and performance

---

## Three Forms of Job Crafting

### 1. Task Crafting
**What you do**: Modify the number, type, or nature of tasks

Strategies:
- Add tasks that give energy
- Reduce/delegate draining tasks
- Modify how you perform tasks
- Change sequence or priority

### 2. Relational Crafting
**Who you work with**: Modify quality/quantity of interactions

Strategies:
- Increase interactions with energizing colleagues
- Build new strategic relationships
- Reduce exposure to toxic relationships
- Change the nature of interactions

### 3. Cognitive Crafting
**How you perceive**: Modify the meaning attributed to work

Strategies:
- Connect daily tasks to a higher purpose
- Reframe unpleasant tasks
- See your contribution in the bigger picture
- Identify impact on others

---

## Session 5: Task Crafting

### Objective
Redesign WHAT the user does in their work

### Structure (60 min)

#### Phase 1: Current Mapping (15 min)

**Exercise: Time Audit**
> "Think about your typical work week. List all the tasks you perform and estimate how much time you dedicate to each (in %)."

Template:
| Task | % Time | Energy (+/-) |
|------|--------|--------------|
| ... | ... | ... |

#### Phase 2: Energy Classification (15 min)

**Guide questions**:
- "Which tasks give you energy when you do them?"
- "Which ones drain you?"
- "Which would you like to do more? Less?"

**Task Matrix**:
```
         High Energy
              |
    EXPAND   | MAINTAIN
              |
 ------------|------------
              |
    MINIMIZE | DELEGATE
              |
         Low Energy
```

#### Phase 3: Identifying Margins (15 min)

**Key questions**:
- "How much control do you have over how you spend your time?"
- "Who decides what you do each day?"
- "Where do you have room to maneuver?"

**Autonomy Map**:
| Task | Autonomy (1-5) | Modifiable? |
|------|----------------|-------------|
| ... | ... | Yes/No/Maybe |

#### Phase 4: Weekly Experiment (15 min)

**Define experiment**:
> "For the next week, try to:
> - Spend 30 more minutes on [ENERGIZING TASK]
> - Reduce by 30 minutes [DRAINING TASK]"

**Valid experiment criteria**:
- Specific (not generic)
- Measurable (time, frequency)
- Under the user's control
- Small (micro-change)

**Homework**: Daily energy journal (1-10) + notes on experiment

---

## Session 6: Relational Crafting

### Objective
Redesign WHO the user works with

### Structure (60 min)

#### Phase 1: Review Previous Experiment (10 min)
- What happened?
- What worked?
- What did you learn?

#### Phase 2: Relationship Mapping (15 min)

**Exercise: Relationship Circles**
```
         [YOU]
        /    \
  [Daily]   [Weekly]
      |          |
  [Who?]      [Who?]
```

**For each person**:
- Interaction frequency
- Type (support, task, social)
- Energy (+2 to -2)

#### Phase 3: Pattern Analysis (15 min)

**Questions**:
- "Who do you feel most energized after talking to?"
- "Who drains you?"
- "Are there people you'd like to work with more?"
- "Are there relationships you avoid? Why?"

**Identify**:
- 2-3 relationships to cultivate
- 1-2 relationships to limit (if possible)
- 1 new relationship to build

#### Phase 4: Weekly Experiment (20 min)

**Experiment options**:
1. **Intentional conversation**: Schedule 1 meeting with an energizing person
2. **New connection**: Start a conversation with someone new
3. **Boundary**: Reduce a draining interaction (with tact)

**Script for intentional conversation**:
> "What would you like to know from [PERSON]?"
> "What could you ask them that you've never asked?"

**Homework**: Conversation report + effect on energy

---

## Session 7: Cognitive Crafting

### Objective
Redesign HOW the user perceives work

### Structure (60 min)

#### Phase 1: Review Previous Experiment (10 min)

#### Phase 2: Meaning Exploration (20 min)

**Central question**:
> "Why do you do what you do? Beyond the paycheck."

**Exercise: Meaning Chain**
```
Daily task
      |
Direct output
      |
Impact on others
      |
Contribution to the world
```

**Example**:
- Task: I write reports
- Output: Manager has information
- Impact: Team makes better decisions
- Contribution: Company serves clients better

#### Phase 3: Reframing (15 min)

**For "unpleasant" tasks**:
> "How could you see [TASK] differently?"
> "Who benefits from it?"
> "What would happen if you didn't do it?"

**Reframing techniques**:
1. **Beneficiary**: Who do I help with this?
2. **Learning**: What do I learn by doing it?
3. **Puzzle**: How can I make it more interesting?

#### Phase 4: Weekly Experiment (15 min)

**Exercise: Meaning Journaling**
> "Every evening, write 1-2 sentences answering:
> 'Today I contributed to... because I...'"

**Alternative: Professional gratitude**
> "3 things you're grateful for in your work today"

---

## Job Crafting Contraindications

### When NOT to Do Aggressive JC

| Situation | Why | Alternative |
|-----------|-----|-------------|
| Severe burnout | Recovery needed first | Clinical support |
| Zero autonomy | JC impossible | Consider role change |
| Toxic environment | JC doesn't fix it | Branch B or exit |
| Total misalignment | Band-aid on structural problem | Branch C |

### Red Flags During the Journey

- Experiments systematically fail
- Manager blocks every change
- User worsens instead of improving
- Deeper issues emerge

---

## Success Metrics Branch A

| Metric | Target | Measurement |
|--------|--------|-------------|
| JCS post > pre | + 0.5 points | Pre/post assessment |
| UWES post > pre | + 0.5 points | Pre/post assessment |
| PERMA E post > pre | + 1 point | Pre/post assessment |
| Experiments completed | >= 2/3 | Self-report |
| Journey satisfaction | >= 7/10 | Final rating |

---

## Session 7 Output

**Deliverable**: Personal Job Crafting Plan

Document that includes:
- Task map with energy classification
- Key relationships to cultivate
- Identified cognitive reframes
- 3 sustainable micro-actions to maintain
- Self check-in timeline (30-60-90 days)
