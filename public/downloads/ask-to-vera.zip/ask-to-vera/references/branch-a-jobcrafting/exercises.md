# Job Crafting Exercises

## Exercise 1: Weekly Time Audit

### Instructions
Complete this table thinking about a typical work week.

### Template

| # | Task/Activity | % Weekly Time | Energy (-2 to +2) | Notes |
|---|---------------|---------------|-------------------|-------|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| 7 | | | | |
| 8 | | | | |

### Energy Legend
- +2: Energizes me greatly
- +1: I enjoy it
- 0: Neutral
- -1: Weighs on me
- -2: Drains me

### Reflection Questions
1. Which task takes up the most time?
2. Which task gives you the most energy?
3. Is there a correlation between time and energy?
4. What would you do if you had 2 extra hours?
5. What would you eliminate if you could?

---

## Exercise 2: Energy-Control Matrix

### Instructions
Position your main tasks in the matrix.

```
                    HIGH CONTROL
                          |
        +------------------+------------------+
        |                  |                  |
        |   EXPAND         |   OPTIMIZE       |
        |   (+ time)       |   (+ quality)    |
 HIGH   |                  |                  |
ENERGY  +------------------+------------------+ LOW
        |                  |                  |  ENERGY
        |   PROTECT        |   MINIMIZE       |
        |   (boundaries)   |   (delegate)     |
        |                  |                  |
        +------------------+------------------+
                          |
                    LOW CONTROL
```

### Actions per Quadrant

**EXPAND** (High energy + High control):
- Dedicate more time
- Try to do it early in the day
- Use it to recharge after heavy tasks

**OPTIMIZE** (Low energy + High control):
- Find ways to make it more interesting
- Gamify (challenge yourself)
- Connect to a meaningful outcome

**PROTECT** (High energy + Low control):
- Don't let it be eroded
- Communicate the value to decision-makers
- Defend this space

**MINIMIZE** (Low energy + Low control):
- Automate if possible
- Delegate if possible
- Batch (do it all at once, one time)

---

## Exercise 3: Professional Relationship Map

### Instructions
Draw your relationship circles and classify each person.

### Template

**Circle 1 - Daily** (see every day):
| Name | Relationship Type | Energy (-2/+2) |
|------|------------------|-----------------|
| | | |
| | | |

**Circle 2 - Weekly** (see every week):
| Name | Relationship Type | Energy (-2/+2) |
|------|------------------|-----------------|
| | | |
| | | |

**Circle 3 - Monthly** (see occasionally):
| Name | Relationship Type | Energy (-2/+2) |
|------|------------------|-----------------|
| | | |
| | | |

### Relationship Types
- **M**: Mentor/Coach
- **P**: Peer/Colleague
- **S**: Supervisor
- **C**: Client/Stakeholder
- **F**: Friend/Support

### Analysis
1. Who is in Circle 1 with negative energy? (management priority)
2. Who is in Circle 2/3 with positive energy? (bring closer?)
3. Who is missing? (relationships to build)

---

## Exercise 4: Meaning Chain

### Instructions
For each "neutral" or "negative" task, build the meaning chain.

### Template

**Task**: _________________

```
DAILY ACTION
"What do I concretely do?"
-> _______________________

        |

DIRECT OUTPUT
"What does this action produce?"
-> _______________________

        |

IMMEDIATE BENEFICIARY
"Who benefits directly?"
-> _______________________

        |

SECOND-LEVEL IMPACT
"How does this help the beneficiary?"
-> _______________________

        |

CONTRIBUTION TO THE WORLD
"What value do I create in the world?"
-> _______________________
```

### Completed Example

**Task**: Compiling monthly reports

```
ACTION: I collect data and create reports

        |

OUTPUT: Report with performance metrics

        |

BENEFICIARY: My manager

        |

IMPACT: Can make informed decisions

        |

CONTRIBUTION: Team works on right priorities,
              company serves clients better
```

---

## Exercise 5: Meaning Journaling (7 days)

### Instructions
Every evening, complete this reflection (max 5 minutes).

### Daily Template

**Date**: _______

**Today I contributed to...**
_________________________________

**...because I...**
_________________________________

**One thing I'm grateful for in my work today:**
_________________________________

**End-of-day energy (1-10):** ____

### Weekly Review
After 7 days, reread and answer:
1. Which day had the most meaning?
2. Which activities recur in the answers?
3. What does this tell you about what matters to you?

---

## Exercise 6: Job Crafting Experiment

### Instructions
Define a micro-experiment to try for one week.

### Template

**Type of Crafting**: [ ] Task  [ ] Relational  [ ] Cognitive

**Experiment description**:
_________________________________

**What I will do concretely**:
_________________________________

**When I will do it**:
- Day: _______
- Time: _______
- Frequency: _______

**How I will know if it works**:
_________________________________

**What could get in my way**:
_________________________________

**How I will overcome the obstacle**:
_________________________________

### Valid Experiment Criteria
- [ ] Specific (not vague)
- [ ] Under my control
- [ ] Measurable
- [ ] Small (start micro)
- [ ] Time-bound (1 week)

### Experiment Journal

| Day | Did I do the experiment? | What happened? | Energy (1-10) |
|-----|--------------------------|----------------|----------------|
| Mon | | | |
| Tue | | | |
| Wed | | | |
| Thu | | | |
| Fri | | | |

### Experiment Review
1. Did I complete the experiment? If not, why?
2. What did I notice?
3. Would I do it again? Would I modify it?
4. What do I try next?

---

## Exercise 7: Before-After Vision

### Instructions
Imagine your "crafted" work in 3 months.

### Before (Today)

**A typical day**:
_________________________________

**How I usually feel**:
_________________________________

**What I'd like to change**:
_________________________________

### After (In 3 months)

**A typical day (realistic ideal)**:
_________________________________

**How I will feel**:
_________________________________

**What will be different**:
_________________________________

### Gap Analysis
What needs to happen to go from Before to After?

| Change needed | Type (T/R/C) | Difficulty (1-5) | First action |
|---------------|--------------|-------------------|--------------|
| | | | |
| | | | |
| | | | |
