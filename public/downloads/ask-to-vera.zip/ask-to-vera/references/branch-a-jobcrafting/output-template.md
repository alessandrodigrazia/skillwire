# Output Template - Branch A: Job Crafting

## Job Crafting Assessment Report

```markdown
# JOB CRAFTING PROFILE - [Name]
Date: [Date]
Session: [Number]

---

## 1. INITIAL SITUATION

### Context
- Role: [Role]
- Time in role: [X years]
- Company/Sector: [Name/Sector]

### Journey motivation
[Brief description of why they started]

### Stated objectives
1. [Objective 1]
2. [Objective 2]
3. [Objective 3]

---

## 2. ASSESSMENT RESULTS

### PERMA-Profiler
| Dimension | Score | Level |
|-----------|-------|-------|
| P - Positive Emotions | /10 | |
| E - Engagement | /10 | |
| R - Relationships | /10 | |
| M - Meaning | /10 | |
| A - Accomplishment | /10 | |
| **Flourishing** | **/10** | |

### Career Anchors (Top 3)
1. [Anchor 1]: [Score] - [Interpretation]
2. [Anchor 2]: [Score]
3. [Anchor 3]: [Score]

### UWES-9
| Dimension | Score | Level |
|-----------|-------|-------|
| Vigor | /6 | |
| Dedication | /6 | |
| Absorption | /6 | |
| **Total** | **/6** | |

### Job Crafting Scale
| Dimension | Score | Level |
|-----------|-------|-------|
| Seeking Structural Resources | /5 | |
| Seeking Social Resources | /5 | |
| Seeking Challenges | /5 | |
| Reducing Demands | /5 | |

---

## 3. IDENTIFIED PATTERNS

### Strengths
- [Strength 1]
- [Strength 2]
- [Strength 3]

### Development Areas
- [Area 1]
- [Area 2]

### Frustration Gap
[Anchor X] high but [PERMA Y] low -> [Interpretation]

---

## 4. CURRENT WORK MAP

### Main Tasks
| Task | % Time | Energy | Autonomy |
|------|--------|--------|----------|
| | | | |
| | | | |
| | | | |

### Key Relationships
| Person | Frequency | Energy | Action |
|--------|-----------|--------|--------|
| | | | |
| | | | |

---

## 5. INTERVENTIONS COMPLETED

### Task Crafting
- Experiment: [Description]
- Result: [Outcome]
- Learning: [Insight]

### Relational Crafting
- Experiment: [Description]
- Result: [Outcome]
- Learning: [Insight]

### Cognitive Crafting
- Reframe identified: [Description]
- Perceived impact: [Description]

---

## 6. SUSTAINABILITY PLAN

### Micro-actions to Maintain
1. [Action 1] - Frequency: [Daily/Weekly]
2. [Action 2] - Frequency: [...]
3. [Action 3] - Frequency: [...]

### Self Check-ins
- [ ] 30 days: [Date] - Reflection on [...]
- [ ] 60 days: [Date] - Verify [...]
- [ ] 90 days: [Date] - UWES assessment

### Warning Signs
If you notice these signs, consider resuming the journey:
- [Sign 1]
- [Sign 2]

---

## 7. RESOURCES

### Recommended Reading
- "Job Crafting" - Amy Wrzesniewski
- [Other relevant resources]

### Tools
- Meaning journaling template
- Energy-control matrix

---

*Report generated with Ask to Vera - Career & Purpose Coach AI*
*Generation date: [Date]*
```

---

## 90-Day Plan - Job Crafting

```markdown
# 90-DAY PLAN - JOB CRAFTING
Name: [Name]
Start date: [Date]
Branch: A - Job Crafting

---

## MAIN OBJECTIVE
[SMART description of the crafting objective]

---

## MONTH 1: EXPERIMENTATION (Weeks 1-4)

### Weeks 1-2: Task Crafting
**Action**: [Task micro-experiment]
**Frequency**: [Daily/Weekly]
**Success indicator**: [How you'll know it works]

### Weeks 3-4: Relational Crafting
**Action**: [Relationship micro-experiment]
**Frequency**: [...]
**Success indicator**: [...]

### Month 1 Milestone
- [ ] Completed at least 2 experiments
- [ ] Identified what works
- [ ] Weekly energy average >= [X]/10

---

## MONTH 2: CONSOLIDATION (Weeks 5-8)

### Focus
- Stabilize the actions that work
- Integrate cognitive crafting
- Build sustainable routines

### Weekly Actions
| Action | Mon | Tue | Wed | Thu | Fri |
|--------|-----|-----|-----|-----|-----|
| [Action 1] | | | | | |
| [Action 2] | | | | | |
| [Journaling] | | | | | |

### Month 2 Milestone
- [ ] Job crafting routine established
- [ ] At least 1 active cognitive reframe
- [ ] Informal UWES >= [X]/6

---

## MONTH 3: AUTONOMY (Weeks 9-12)

### Focus
- Maintain without effort
- Adapt to circumstances
- Prepare to fly solo

### Week 9 Check-in
Self-assessment questions:
1. Have the actions become habits?
2. What do I need to adjust?
3. Do I feel more energized at work?

### Week 12 Check-in (Final)
- [ ] UWES re-assessment
- [ ] Comparison with baseline
- [ ] Decision: continue independently or follow-up

---

## ANTICIPATED OBSTACLES

| Obstacle | Strategy |
|----------|----------|
| [Obstacle 1] | [How to overcome it] |
| [Obstacle 2] | [How to overcome it] |
| Intense week | Reduce to just 1 action |
| Loss of motivation | Re-read initial "why" |

---

## SUCCESS CRITERIA

### Quantitative
- [ ] UWES post > UWES pre (at least +0.5)
- [ ] Weekly energy average >= 7/10
- [ ] At least 2 active job crafting routines

### Qualitative
- [ ] I feel more in control of my work
- [ ] I have more energizing relationships
- [ ] I find more meaning in what I do

---

## WHEN TO ASK FOR HELP

Contact Vera again if:
- [ ] Energy drops below 4/10 for 2+ weeks
- [ ] Actions aren't working despite adjustments
- [ ] Thoughts of leaving the job emerge
- [ ] You need support for a bigger change

---

*Plan created with Ask to Vera - Career & Purpose Coach AI*
*Best of luck on your job crafting journey!*
```
