# Ikigai-9 Scale

## Overview

The Ikigai-9 (Imai et al., 2012) is a validated scale for measuring the sense of ikigai - the feeling of having a life worth living. Developed in Japan, based on Kamiya's 7 needs.

### Evidence Base
- Original validation: n=735, alpha=.87
- Predicts: physical health, psychological wellbeing, longevity
- Ohsaki Cohort (n=43,391): those with ikigai = -50% cardiovascular mortality at 7 years

---

## IMPORTANT: Debunking the 4-Circle Diagram

The famous "4-circle" diagram (Passion, Mission, Vocation, Profession) is **NOT authentic ikigai**.

**Origin of the myth**:
- 2014: Marc Winn merged two diagrams in a blog post
- One was a "Purpose Venn" diagram (Western)
- The other mentioned "ikigai" without understanding it
- The meme spread without verification

**Authentic ikigai**:
- It is the sense of purpose in DAILY life
- Does not require a "grand purpose" or monetization
- Can come from simple activities (gardening, grandchildren, hobbies)
- It is personal and intimate, not a career framework

**In coaching**: Use the Ikigai-9 to measure sense of purpose, but avoid using the 4-circle diagram which is culturally inappropriate and methodologically incorrect.

---

## Complete Items (9)

### Factor 1: Life Optimism (3 items)
1. "I think my life is happy"
2. "I think my life is full of joy"
3. "I think my life is worth living"

### Factor 2: Meaningful Activities (3 items)
4. "I have something I actively dedicate myself to"
5. "I have something worth striving for"
6. "I feel pleasure in doing things"

### Factor 3: Sense of Existence (3 items)
7. "I feel I have a role in society"
8. "I feel I am needed by others"
9. "I feel I contribute to society"

---

## Scale

| Value | Label |
|-------|-------|
| 1 | Strongly disagree |
| 2 | Disagree |
| 3 | Neutral |
| 4 | Agree |
| 5 | Strongly agree |

---

## Scoring

### Per Factor
Arithmetic mean of the 3 items (1-5)

### Total Score
Mean of all 9 items (1-5)

### Interpretation

| Score | Level | Description |
|-------|-------|-------------|
| < 2.5 | Low | Sense of ikigai lacking |
| 2.5-3.0 | Medium-low | Partial ikigai |
| 3.0-3.5 | Medium | Normal range |
| 3.5-4.0 | High | Good sense of ikigai |
| > 4.0 | Very high | Strong ikigai |

---

## Diagnostic Profiles

### "Existence Without Direction" Profile
- Factor 1 (Optimism) high
- Factor 2 (Activities) low
- Interpretation: Life is okay but missing "something to do"
- Intervention: Explore hobbies, projects, volunteering

### "Doing Without Being" Profile
- Factor 2 (Activities) high
- Factor 3 (Existence) low
- Interpretation: Busy but doesn't feel useful
- Intervention: Connect activities to impact on others

### "Existential Void" Profile
- All factors low
- Interpretation: Possible depression, existential crisis
- Intervention: Depression screening, possible handoff

### "Full Ikigai" Profile
- All factors high
- Interpretation: Person with integrated sense of purpose
- Intervention: Maintenance, eventual deepening

---

## Integration with Other Assessments

| Ikigai-9 + | Pattern | Meaning |
|------------|---------|---------|
| Low PERMA M | Confirms | Meaning deficit |
| High COI SV | Paradox | Service value not expressed |
| Low UWES DE | Disengagement | Lacking dedication |
| Low PERMA R | Isolation | Lacking social connection |

### Interpretive Sequence
1. Ikigai-9 total -> General level of sense of purpose
2. Per-factor analysis -> Where is the deficit?
3. Correlation with PERMA M -> Confirmation or divergence?
4. Correlation with Career Anchors -> Values expressed?

---

## Exploration Questions

### For Low Factor 1 (Optimism)
- "What would make your life happier?"
- "When was the last time you felt truly joyful?"
- "What would you remove from your life to feel better?"

### For Low Factor 2 (Activities)
- "Is there something you want to do but don't?"
- "What were you passionate about when you were younger?"
- "If you had 2 extra free hours per day, what would you do?"

### For Low Factor 3 (Existence)
- "Who benefits from what you do?"
- "What would be missing if you weren't there?"
- "How do you feel when you help someone?"

---

## Methodological Warnings

1. **Don't monetize ikigai**: It shouldn't become "find your market niche"
2. **No cultural appropriation**: Respect the Japanese origin
3. **Small things count**: Ikigai can come from morning tea
4. **It's not fixed**: Ikigai evolves with life stages
5. **It's not a goal**: It's a process, not a destination
6. **Community matters**: Japanese ikigai is relational, not individualistic
7. **No need to be special**: Ordinary ikigai is just as valid as extraordinary
8. **Avoid the diagram**: Never use the 4-circle "Venn diagram"

---

## Operational Notes

- Administer at the start of Branch C
- Time: 5 minutes
- Contextualize: "These questions are about how you feel about your life in general"
- Do not use for clinical diagnoses
- Use as a starting point for qualitative exploration
