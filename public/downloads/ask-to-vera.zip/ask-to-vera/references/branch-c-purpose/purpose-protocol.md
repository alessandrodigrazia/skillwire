# Purpose Discovery Protocol - Branch C

## Overview

Branch C guides professionals in the search for meaning and professional direction. It does not seek "the answer" but helps build a personal Purpose Statement.

### Guiding Principles
1. **Purpose is personal**: There is no "right" purpose
2. **Purpose evolves**: It is not fixed forever
3. **Purpose is ordinary**: You don't need to change the world
4. **The process matters**: The journey counts as much as the destination

---

## Session 5: Values Exploration

### Objective
Understand the deep "why" through Career Anchors and Kamiya needs

### Phase 1: Deep Dive Career Anchors (20 min)

For the top 3 anchors from the assessment:

**Questions for each anchor**:
1. "What does [ANCHOR] mean to you?"
2. "When did you feel it most alive in your career?"
3. "When was it most frustrated?"
4. "What would you be willing to sacrifice to maintain it?"
5. "How does it express itself (or not) in your current role?"

**Exploration template**:
```
ANCHOR: [Name]
Score: [X/6]

Means to me: _______
Moment alive: _______
Moment frustrated: _______
Would sacrifice: _______
In current role: _______
```

### Phase 2: Exploring Kamiya's 7 Needs (25 min)

**Introduction**:
> "Now we'll explore 7 fundamental needs that contribute to a sense of purpose. For each one I'll ask how satisfied you feel (1-5) and then we'll go deeper."

For each need (see `kamiya-7-needs.md`):
1. Rating 1-5
2. Deepening question if <= 3
3. Notes on emerging insights

**Priority focus**: Needs with score <= 2

### Phase 3: Eulogy Exercise (15 min)

**Introduction**:
> "This exercise might feel intense, but it's very powerful. Take a moment to imagine..."

**Prompt**:
> "Imagine your retirement. Colleagues, friends, family are speaking about you. What would you want them to say?
>
> - About your professional contribution?
> - About the kind of colleague/leader you were?
> - About what you leave to others?"

**Less intense variant**:
> "Imagine receiving a lifetime achievement award 20 years from now. The award citation says..."

**Homework**: Write the eulogy/award speech in extended form

---

## Session 6: Life-Work Connection

### Objective
Find patterns of meaning in professional history

### Phase 1: Review Homework + Insights (10 min)

- What did you write in the eulogy?
- What surprised you?
- What moved you?

### Phase 2: Flow Experience Mapping (20 min)

**Introduction**:
> "Flow is that state where you lose track of time because you're completely absorbed. Think about flow moments in your professional life."

**Flow Mapping Template**:
| # | Experience | What were you doing | With whom | Why flow? |
|---|------------|---------------------|-----------|-----------|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |

**Pattern analysis**:
- What do these experiences have in common?
- Is there a recurring "type" of activity?
- Is there a recurring context?

### Phase 3: Patterns in Professional History (15 min)

**Meaning timeline**:
> "Think back over your career from the beginning. Mark the moments when you felt most aligned with yourself."

```
[Career start] -------- [Now]

Moments of alignment:
1. _____ (when, what)
2. _____
3. _____

Moments of misalignment:
1. _____
2. _____
```

**Questions**:
- "What makes the alignment moments different?"
- "What was missing in the misalignment moments?"

### Phase 4: Authentic Ikigai (15 min)

**NOTE**: Do NOT use the 4-circle diagram. Use authentic approach.

**Key questions**:
1. "What gives you a sense of purpose in daily life?" (not just work)
2. "What do you find genuine joy in doing?"
3. "What makes you get up in the morning with energy?"
4. "What would you be willing to make sacrifices for?"

**Integration**:
- How do these answers connect to Career Anchors?
- How do they connect to Kamiya needs?
- What emerges as a "common thread"?

**Homework**: Journaling on "When do I feel most myself professionally?"

---

## Session 7: Purpose Statement

### Objective
Articulate and operationalize purpose

### Phase 1: Review and Synthesis (15 min)

Review insights from previous sessions:
- Top Career Anchors and their meaning
- Priority Kamiya needs
- Eulogy/Award
- Flow patterns
- Emerging common thread

**Synthesis question**:
> "If you had to describe in one sentence what truly matters to you professionally, what would you say?"

### Phase 2: Building the Purpose Statement (25 min)

**Template 1 - Classic**:
> "I help [WHO] to [WHAT] through [HOW] because [WHY]"

**Template 2 - Contributive**:
> "My unique contribution is [WHAT] for [WHO] which creates [IMPACT]"

**Template 3 - Values-based**:
> "I live my values of [VALUES] when [ACTIONS] for [PURPOSE]"

**Process**:
1. Initial draft (doesn't need to be perfect)
2. Read aloud
3. "How does it make you feel?"
4. Iterate if necessary
5. Test: "Does this truly represent you?"

**Effective Purpose Statement Criteria**:
- [ ] It moves you to read it
- [ ] It's specific enough to guide decisions
- [ ] It's broad enough not to limit you
- [ ] It reflects your core values
- [ ] It's authentic (not what you "should" say)

### Phase 3: Alignment Check (10 min)

**Key question**:
> "How much does your current role allow you to live this purpose?"

**Scale**:
| Score | Description |
|-------|-------------|
| 1-3 | Little alignment |
| 4-6 | Partial alignment |
| 7-8 | Good alignment |
| 9-10 | Full alignment |

**If < 5**: Explore what's missing and how to bridge the gap
**If >= 7**: Explore how to amplify

### Phase 4: Micro-Actions (10 min)

**Identify 3 ways to express more purpose in the current role**:

1. **Immediate action** (this week):
   _______________

2. **Medium-term action** (this month):
   _______________

3. **Structural action** (next 3 months):
   _______________

**For each action**:
- What will I do concretely?
- When?
- How will I know it's working?

---

## Managing Special Cases

### "I can't find my purpose"

> "Purpose isn't something to find like hidden treasure. It's something you build, bit by bit. You don't need THE answer - just directions."

**Action**: Focus on micro-actions, not grand purpose

### "My purpose isn't compatible with my job"

**Explore**:
1. Is it truly incompatible or are there margins?
2. Can purpose be expressed outside of work?
3. Is it time to consider Branch B?

### "I've changed my mind about my purpose"

> "That's perfectly normal. Purpose evolves with us. What matters is that YOU recognize yourself in what you say."

---

## Branch C Output

### Purpose Statement
Document with:
- Final Purpose Statement
- Correlated Career Anchors
- Satisfied Kamiya needs
- 3 micro-actions for living the purpose

### Success Criteria
- [ ] Purpose Statement articulated
- [ ] User recognizes themselves in the statement
- [ ] At least 1 action identified to increase alignment
- [ ] Ikigai-9 post >= pre
