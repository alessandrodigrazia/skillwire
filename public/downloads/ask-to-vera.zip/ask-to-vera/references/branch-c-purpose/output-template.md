# Output Template - Branch C: Purpose Discovery

## Purpose Discovery Report

```markdown
# PURPOSE DISCOVERY PROFILE - [Name]
Date: [Date]
Session: [Number]

---

## 1. YOUR JOURNEY

### Starting Point
[Brief description of initial situation and journey motivation]

### Guiding Question
[The central question that guided the journey]

---

## 2. YOUR CORE VALUES

### Career Anchors - Your Professional DNA

**Dominant Anchor: [NAME]**
Score: [X/6]
What it means to you: [Personalized description]
How it expresses: [Concrete examples from the user's life]

**Second Anchor: [NAME]**
Score: [X/6]
Meaning: [...]

**Third Anchor: [NAME]**
Score: [X/6]
Meaning: [...]

### Value Tensions
[If conflicts between anchors exist, describe them]

---

## 3. YOUR DEEP NEEDS (Kamiya)

| Need | Level | Insight |
|------|-------|---------|
| Life satisfaction | /5 | |
| Change and growth | /5 | |
| Bright future | /5 | |
| Resonance with others | /5 | |
| Freedom | /5 | |
| Self-actualization | /5 | |
| Meaning and existence | /5 | |

### Needs to Cultivate
[The 2-3 needs with lowest scores and strategies]

### Satisfied Needs
[Recognition of what's working]

---

## 4. PATTERNS OF MEANING

### Flow Experiences
[The 3-5 identified flow experiences and the common pattern]

### Common Thread
[The recurring theme that emerges from professional history]

### Eulogy Insight
[What emerged from the eulogy exercise]

---

## 5. IKIGAI

### Ikigai-9 Score
- Life optimism: [/5]
- Meaningful activities: [/5]
- Sense of existence: [/5]
- **Total**: [/5]

### Your Daily Ikigai
[Description of what gives meaning to the user's daily life]

---

## 6. PURPOSE STATEMENT

### Your Statement of Purpose

> "[COMPLETE PURPOSE STATEMENT]"

### Decoded
- **WHO you help**: [Target]
- **WHAT you do**: [Action]
- **HOW you do it**: [Method]
- **WHY you do it**: [Deep motivation]

### Current Alignment
Current role vs Purpose: [X/10]
[Description of what's aligned and what's not]

---

## 7. ALIGNMENT PLAN

### Immediate Micro-Actions (7 days)
1. [Action 1]
2. [Action 2]

### Monthly Actions
1. [Action 3]
2. [Action 4]

### Quarterly Actions
1. [Action 5]

### Success Indicators
- [How you'll know you're living your purpose]
- [Positive signals to look for]

---

## 8. RESOURCES FOR THE JOURNEY

### Recommended Reading
- "Man's Search for Meaning" - Viktor Frankl
- [Other resources relevant to the profile]

### Suggested Practices
- [Practice 1, e.g. journaling, meditation, etc.]
- [Practice 2]

### Questions for Self-Reflection
- [Question 1 to ask yourself periodically]
- [Question 2]

---

## 9. FINAL NOTE

[Personalized message acknowledging the user's journey and offering authentic encouragement]

---

*Report generated with Ask to Vera - Career & Purpose Coach AI*
*"Purpose is not a destination, it's a compass"*
```

---

## 90-Day Plan - Purpose Discovery

```markdown
# 90-DAY PLAN - PURPOSE DISCOVERY
Name: [Name]
Start date: [Date]
Branch: C - Purpose Discovery

---

## YOUR PURPOSE STATEMENT

> "[PURPOSE STATEMENT]"

---

## 90-DAY OBJECTIVE

Increase alignment between current role and purpose from [X/10] to [Y/10]

---

## MONTH 1: AWARENESS

### Focus
Bring purpose into daily life through small practices

### Weeks 1-2: Noticing
**Daily practice** (5 min):
- [ ] Evening: "Today I lived my purpose when..."
- [ ] Morning: "Today I can live my purpose by..."

**Weekly journaling** (15 min):
- When did I feel most aligned?
- When least?
- What did I learn?

### Weeks 3-4: First Action
**Specific action**: [Immediate action from session 7]
- What: ___
- When: ___
- Frequency: ___

**Check-in**: Is the action working? What to adjust?

### Month 1 Milestone
- [ ] Daily practice established
- [ ] First action implemented
- [ ] Awareness increased

---

## MONTH 2: AMPLIFICATION

### Focus
Increase opportunities to live the purpose

### Actions
1. **[Monthly action 1]**
   - What:
   - When:
   - Expected outcome:

2. **[Monthly action 2]**
   - What:
   - When:
   - Expected outcome:

### Exploration
- [ ] Identify 1 new area to express purpose
- [ ] Talk to someone who lives a similar purpose
- [ ] Read/listen to related inspirational content

### Month 2 Milestone
- [ ] At least 2 actions completed
- [ ] New area identified
- [ ] Perceived alignment increased

---

## MONTH 3: INTEGRATION

### Focus
Make purpose a structural part of professional life

### Structural Action
**[Quarterly action from session 7]**
- What:
- Timeline:
- Resources needed:
- Potential obstacles:

### Comprehensive Review
- [ ] Ikigai-9 re-assessment
- [ ] Comparison with baseline
- [ ] Recalculate role/purpose alignment

### Decisions
Based on the 90 days:
- [ ] Continue current path with more integrated purpose
- [ ] Consider job crafting (Branch A)
- [ ] Consider transition (Branch B)
- [ ] Other: ___

---

## DAILY PRACTICES

### Morning (2 min)
> "Today I can live my purpose by..."

### Evening (3 min)
> "Today I lived my purpose when..."
> "Tomorrow I could..."

### Weekly (15 min)
- Journal review
- Week planning
- Gratitude for moments of alignment

---

## GUIDING QUESTIONS

To ask yourself periodically:

1. "Am I living according to my values?"
2. "Where am I expressing my purpose?"
3. "What's missing for me to feel more aligned?"
4. "What can I do this week?"
5. "Who can I help with my purpose?"

---

## POSITIVE SIGNALS

How you'll know you're living your purpose:
- [ ] You wake up with more energy
- [ ] You find meaning in what you do
- [ ] You feel more "yourself" at work
- [ ] Others notice a positive change
- [ ] You have more clarity in decisions

---

## OBSTACLES AND STRATEGIES

| Obstacle | Strategy |
|----------|----------|
| "I don't have time" | Start with 2 min/day |
| "Work doesn't change" | Focus on what I can control |
| "I lose motivation" | Re-read purpose statement |
| "It feels too vague" | Return to concrete micro-actions |

---

## WHEN TO ASK FOR HELP

Contact Vera again if:
- [ ] Purpose statement no longer resonates
- [ ] Alignment doesn't improve after 60 days
- [ ] Important career decisions emerge
- [ ] You need to redefine actions
- [ ] You want to explore transition

---

*Plan created with Ask to Vera - Career & Purpose Coach AI*
*"Your purpose is already within you. This plan helps you live it."*
```
