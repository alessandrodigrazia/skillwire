# Kamiya's 7 Needs - Purpose Framework

## Overview

Mieko Kamiya (1914-1979), Japanese psychiatrist, identified 7 fundamental needs that, when satisfied, create the sense of ikigai. Her book "Ikigai ni tsuite" (1966) is the authoritative source on ikigai.

---

## The 7 Needs

### 1. Need for Life Satisfaction
**Description**: Feeling that one's life has value and is worth living.

**Exploratory questions**:
- "Do you feel your life is worth living?"
- "What gives you deep satisfaction?"
- "When do you feel truly alive?"

**Deficiency indicators**:
- "I'm living on autopilot"
- "One day is the same as another"
- "Nothing would change if I weren't here"

### 2. Need for Change and Growth
**Description**: Feeling that one is evolving, learning, improving.

**Exploratory questions**:
- "In what ways have you grown in recent years?"
- "What are you learning that's new?"
- "How are you different from the person you were 5 years ago?"

**Deficiency indicators**:
- "I'm always the same"
- "I don't learn anything new anymore"
- "I feel stuck"

### 3. Need for a Bright Future
**Description**: Having something to look forward to, hope in the future.

**Exploratory questions**:
- "What are you looking forward to with enthusiasm?"
- "What do you hope for your future?"
- "Do you have projects that excite you?"

**Deficiency indicators**:
- "I see nothing good on the horizon"
- "The future scares me"
- "I have nothing to look forward to"

### 4. Need for Resonance with Others
**Description**: Feeling connected, understood, in authentic relationship.

**Exploratory questions**:
- "Who do you feel truly understood by?"
- "Where do you find community?"
- "Who shares your values?"

**Deficiency indicators**:
- "Nobody really gets me"
- "I feel alone even in company"
- "I don't belong to any group"

### 5. Need for Freedom
**Description**: Feeling free to choose, self-determined.

**Exploratory questions**:
- "How free do you feel in your choices?"
- "What would you do if you had no constraints?"
- "Where do you feel most free?"

**Deficiency indicators**:
- "I only do what I must"
- "I have no choice"
- "My life is decided by others"

### 6. Need for Self-Actualization
**Description**: Expressing one's potential, becoming who one can be.

**Exploratory questions**:
- "Are you expressing your potential?"
- "Is there something in you that finds no expression?"
- "Who would you be if you could be anyone?"

**Deficiency indicators**:
- "There's more in me"
- "I'm not using my talents"
- "I could do more"

### 7. Need for Meaning and Existence
**Description**: Feeling that one's existence has a purpose, that one matters.

**Exploratory questions**:
- "Why do you exist?"
- "What is your contribution to the world?"
- "What would be missing if you weren't here?"

**Deficiency indicators**:
- "What's the point of what I do?"
- "I don't make a difference"
- "I could disappear and no one would notice"

---

## Qualitative Assessment

### Exploration Template

For each need, rate (1-5):

| # | Need | Score | Notes |
|---|------|-------|-------|
| 1 | Life satisfaction | | |
| 2 | Change and growth | | |
| 3 | Bright future | | |
| 4 | Resonance with others | | |
| 5 | Freedom | | |
| 6 | Self-actualization | | |
| 7 | Meaning and existence | | |

**Legend**:
- 1 = Need completely unmet
- 2 = Need barely met
- 3 = Need partially met
- 4 = Need well met
- 5 = Need fully met

### Interpretation

**Priority needs**: Score <= 2
**Needs to cultivate**: Score 3
**Satisfied needs**: Score >= 4

### Common Patterns

| Pattern | Interpretation | Intervention Focus |
|---------|----------------|-------------------|
| 1-3 low | General existential crisis | Start with 1 (baseline satisfaction) |
| 4 low | Relational isolation | Build community |
| 5 low | Sense of imprisonment | Explore margins of freedom |
| 6 low | Unexpressed potential | Job crafting or transition |
| 7 low | Void of meaning | Purpose statement |

---

## Exercises per Need

### 1. Life Satisfaction
**"Moments of Fullness" Exercise**:
- List 10 moments when you felt truly alive
- Look for patterns: where, with whom, doing what
- What do these moments tell you?

### 2. Change and Growth
**"Growth Timeline" Exercise**:
- Draw a timeline of the last 10 years
- Mark the moments of growth/learning
- Where is the line heading?

### 3. Bright Future
**"Letter from the Future" Exercise**:
- Write a letter from yourself 5 years from now
- Describe your ideal (realistic) life
- What happened to get there?

### 4. Resonance with Others
**"Circles of Belonging" Exercise**:
- Draw concentric circles
- Position people/groups based on closeness
- Where do you want to build connections?

### 5. Freedom
**"Freedom Map" Exercise**:
- List life areas: work, relationships, time, money, health
- For each: how free do you feel (1-10)?
- Where do you want more freedom?

### 6. Self-Actualization
**"Dormant Talents" Exercise**:
- What did you do when younger that you no longer do?
- What do people often tell you you're good at?
- What would you do if nobody judged you?

### 7. Meaning and Existence
**"Eulogy Test" Exercise**:
- What would you want said at your funeral?
- What would you want written on your gravestone?
- How would you want to be remembered?

---

## Integration in the Journey

### Session 5: Exploration
- Qualitative assessment of 7 needs
- Identify priority needs (<=2)
- Deepen with questions

### Session 6: Connection
- Connect needs to Career Anchors
- Connect needs to flow experiences
- Identify historical patterns

### Session 7: Action
- For each priority need: 1 micro-action
- Purpose statement that integrates top needs
- Maintenance plan

---

## Career Anchors Connection

| Kamiya Need | Correlated Career Anchor |
|-------------|--------------------------|
| Growth | TF (Technical), CH (Challenge) |
| Freedom | AU (Autonomy), LS (Lifestyle) |
| Self-actualization | EC (Entrepreneurial), GM (Managerial) |
| Meaning | SV (Service), EC |
| Resonance | SV, GM |
| Future security | SE (Security) |

Use these connections to integrate quantitative analysis (COI) with qualitative (Kamiya).
