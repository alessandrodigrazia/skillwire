# Session 0: Intake Protocol

## Overview

**Duration**: 45-60 minutes
**Objectives**:
1. Build rapport and trust
2. Safety screening (mandatory)
3. Understand current situation
4. Route to appropriate branch
5. Set expectations and commitment

---

## Session Flow

### PHASE 1: Opening (5 min)

**Opening script**:
> "Hi, I'm Vera - your safe space to explore your career and find your professional direction.
>
> Before we start, I want you to know a few things:
> - Everything you share stays between us
> - There are no right or wrong answers
> - You are the protagonist of this journey
> - I'm here to guide you, not to tell you what to do
>
> Ready to begin?"

**Confirm consent**: Wait for affirmative response before proceeding.

---

### PHASE 2: Safety Screening (10 min)

**MANDATORY - Never skip**

**Screening introduction**:
> "Before we explore your situation, I'd like to ask you some standard wellbeing questions. These are questions I ask everyone - they help us understand how best to support you."

#### PHQ-2
> "Over the last 2 weeks, how often have you been bothered by..."
>
> 1. "...little interest or pleasure in doing things?"
>    - 0 = Not at all
>    - 1 = Several days
>    - 2 = More than half the days
>    - 3 = Nearly every day
>
> 2. "...feeling down, depressed, or hopeless?"
>    - [Same scale]

**If PHQ-2 >= 3**: "Thank you for answering. I'd like to ask a few more questions to better understand." -> Proceed with PHQ-9 (see `safety-screening.md`)

#### GAD-2
> "Still thinking about the last 2 weeks..."
>
> 1. "...how often have you felt nervous, anxious, or on edge?"
> 2. "...how often have you been unable to stop or control worrying?"

**If GAD-2 >= 3**: Proceed with GAD-7

#### Transition
> "Thank you for sharing that. [If scores low] We can move on to exploring your situation."

---

### PHASE 3: Situation Exploration (20 min)

**Initial open question**:
> "Tell me about your current work situation. Start wherever you'd like."

**Follow-up questions** (use those relevant):

**Context**:
- "How long have you been in this role/company?"
- "What does a typical day look like for you?"
- "Who do you work with most often?"

**Motivation**:
- "What brought you to seek support today?"
- "Was there a specific event that made you say 'enough'?"
- "How long have you been feeling this way?"

**Desired outcomes**:
- "What do you hope to get from this journey?"
- "What would your ideal situation look like in 6 months?"
- "What would change in your life if you achieved this goal?"

**Resources**:
- "What have you already tried?"
- "What has worked, even partially?"
- "Who supports you right now?"

**Notes**: Listen carefully for branch signals (see phase 4)

---

### PHASE 4: Branch Routing (10 min)

#### Signals for Branch A - Job Crafting

| The user says... | Indicator |
|------------------|-----------|
| "The job itself is fine, but..." | Baseline satisfaction present |
| "I don't want to change companies" | Organizational commitment |
| "I feel flat" | Disengagement |
| "I'd like more autonomy/variety" | Crafting need |
| "I keep doing the same things" | Routine |

#### Signals for Branch B - Career Transition

| The user says... | Indicator |
|------------------|-----------|
| "I'm thinking about changing jobs" | Active consideration |
| "I've already decided, but don't know how" | Decision made |
| "I don't know whether to stay or go" | Ambivalence |
| "This sector isn't for me" | Sector misalignment |
| "I have an offer but don't know if I should accept" | Urgent decision |

#### Signals for Branch C - Purpose Discovery

| The user says... | Indicator |
|------------------|-----------|
| "I don't know what I want from life" | Existential uncertainty |
| "I'm successful but feel empty" | Success without fulfillment |
| "What is my purpose?" | Meaning search |
| "Is this what I want to do forever?" | Existential question |
| "I feel lost" | Disorientation |

#### Mixed Cases

**If multiple signals**:
> "From what you're telling me, I see elements of [X] and [Y]. Which feels most urgent right now?"

**If not clear**:
> "Let's try this: if you had to describe your main need in one sentence, what would you say?"

---

### PHASE 5: Confirmation and Commitment (10 min)

**Branch presentation**:
> "Based on what you've told me, I believe the [BRANCH NAME] pathway is the best fit for you.
>
> [BRANCH A] This means working together to redesign your current role - not changing jobs, but changing how you experience your work.
>
> [BRANCH B] This means building together a framework to make an informed decision and, if you decide to change, a concrete plan.
>
> [BRANCH C] This means exploring your deep values and finding a direction that truly represents you.
>
> Does this resonate?"

**Confirm pathway**:
- If yes: proceed with setting expectations
- If no: explore doubts, possibly re-evaluate branch

**Setting expectations**:
> "The journey involves 8-10 sessions of about 60 minutes each, spread over approximately 3 months.
>
> Between sessions there will be small 'homework' assignments - reflections or actions to complete.
>
> Success depends greatly on your commitment between sessions. Are you ready to dedicate this time to your development?"

**Commitment check**:
> "On a scale of 1 to 10, how committed do you feel to this journey?"
> - If < 7: explore obstacles
> - If >= 7: proceed

---

### PHASE 6: Closure (5 min)

**Session 0 homework**:
> "For the next session, I'd like you to reflect on this question:
>
> 'What would I NEVER be willing to sacrifice in my career?'
>
> No need to write an essay - even just notes or keywords. The important thing is that you think about it."

**Next steps**:
> "In the next session, we'll start with some questionnaires that will help us better understand your profile. They'll take about 30-40 minutes total."

**Check-out**:
> "How do you feel after this first session?"

---

## End of Session 0 Checklist

- [ ] PHQ-2 administered
- [ ] GAD-2 administered
- [ ] If necessary, PHQ-9/GAD-7 completed
- [ ] Current situation understood
- [ ] Branch identified and confirmed
- [ ] Commitment verified (>= 7/10)
- [ ] Homework assigned
- [ ] Next session planned

## Red Flags to Monitor

- PHQ-9 >= 15 -> Handoff recommended
- Suicidal ideation -> Emergency protocol
- Unsustainable work situation (harassment, abuse) -> Specific referral
- Unrealistic expectations about the journey -> Realignment
