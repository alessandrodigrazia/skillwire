# Branch Routing Criteria

## Decision Tree

```
START: "What is your main need?"
|
+-> "I want to improve how I experience my current role"
|   +-> BRANCH A: Job Crafting
|
+-> "I'm thinking about changing jobs/sectors"
|   +-> BRANCH B: Career Transition
|
+-> "I don't know what I really want"
|   +-> BRANCH C: Purpose Discovery
|
+-> Not clear
    +-> Deepening questions
```

---

## Branch A: Job Crafting

### Typical Profile
- Manager/Professional aged 30-50
- 3+ years in the same role
- Baseline satisfaction with company/salary
- Disengagement or latent burnout
- Does not want to change organization

### Positive Indicators
| Signal | Score |
|--------|-------|
| "The job itself is fine" | +2 |
| "I don't want to change companies" | +2 |
| "I'm in a rut" | +1 |
| "I'd like more autonomy/variety" | +2 |
| "I keep doing the same things" | +1 |
| "I feel flat" | +1 |
| "I've lost my enthusiasm" | +1 |

### Contraindications
| Signal | Action |
|--------|--------|
| Severe burnout (BAT >= 3.02) | Recovery first, then JC |
| Toxic environment | Branch B or referral |
| Zero autonomy in role | Evaluate JC feasibility |
| Already decided to leave | Branch B |

### Discriminating Question
> "If you could change how you spend your workdays without changing companies, would you?"
> - Yes -> Branch A
> - No/Maybe not -> Explore other branches

---

## Branch B: Career Transition

### Typical Profile
- Professional aged 30-50
- Actively considering a change
- Has transferable skills
- Uncertainty about direction or timing
- Possible decision biases

### Positive Indicators
| Signal | Score |
|--------|-------|
| "I'm thinking about changing jobs" | +2 |
| "I've already decided, don't know how" | +2 |
| "I don't know whether to stay or go" | +2 |
| "This sector isn't for me anymore" | +1 |
| "I have an offer but I'm undecided" | +2 |
| "I want to change sectors" | +1 |
| "I'm afraid of making a mistake" | +1 |

### Contraindications
| Signal | Action |
|--------|--------|
| Only push, no pull | Explore motivations |
| Reactive decision (argument, stress) | Cooling off period |
| Zero financial runway | Evaluate timing |
| Acute crisis | Stabilize first |

### Discriminating Questions
> "Have you already identified concrete alternatives or are you still searching for direction?"
> - Concrete alternatives -> Branch B
> - Searching for direction -> Could be Branch C

> "If the perfect offer arrived tomorrow, what would you do?"
> - I'd accept -> Branch B (decision)
> - I don't know -> Could be Branch C

---

## Branch C: Purpose Discovery

### Typical Profile
- Senior professional aged 35-55
- External success but inner emptiness
- Existential questions about career
- Seeking meaning, not just change
- Possible life transition

### Positive Indicators
| Signal | Score |
|--------|-------|
| "I don't know what I want from life" | +2 |
| "I'm successful but feel empty" | +2 |
| "What is my purpose?" | +2 |
| "Is this what I want to do forever?" | +1 |
| "I feel lost" | +1 |
| "I have everything but I'm not happy" | +2 |
| "I'm looking for something more" | +1 |

### Contraindications
| Signal | Action |
|--------|--------|
| Clinical depression | Handoff first |
| Acute existential crisis | Psychological support |
| Urgent decision needed | Branch B first |
| Immediate practical need | Branch A or B first |

### Discriminating Questions
> "Are you trying to figure out WHAT to do or WHY to do it?"
> - What -> Branch B
> - Why -> Branch C

> "If money weren't a problem, what would you do?"
> - Clear answer -> Explore Branch B
> - "I don't know" -> Branch C

---

## Special Cases

### Burnout + Desire to Change
**Sequence**: First BAT screening, then:
- BAT < 2.59: Branch B with caution
- BAT 2.59-3.01: Branch A first (recovery), then reassess
- BAT >= 3.02: Clinical handoff

### Genuine Uncertainty
If the user truly doesn't know what they want:
1. Administer core assessments (PERMA, Career Anchors)
2. Use results to guide toward branch
3. Dominant Career Anchor may indicate direction

### Mid-Journey Branch Change
It is possible to change branches during the journey if it emerges that:
- The real problem is different from the initial one
- Assessments reveal unexpressed needs
- The situation changes (e.g., receives an offer)

---

## Scoring System

### Calculation
Sum positive indicators for each branch.
Branch with highest score = primary recommendation.

### Threshold
- Score >= 5: Clear branch
- Score 3-4: Likely, confirm with questions
- Score < 3: Explore other branches

### In Case of Tie
Use final question:
> "If you had to choose between [improving your current role / changing jobs / finding your purpose], what attracts you most?"

---

## Confirmation Template

> "Based on what you've told me, the pathway I recommend is [BRANCH].
>
> This means we'll work on [BRANCH FOCUS]:
>
> **Branch A**: Redesigning how you experience your work - tasks, relationships, meaning - without necessarily changing positions.
>
> **Branch B**: Building a framework to decide whether and how to change, and then a concrete plan for the transition.
>
> **Branch C**: Exploring your deep values to find a professional direction that truly represents you.
>
> Does this resonate? Do you have doubts or would you prefer to explore a different pathway?"
