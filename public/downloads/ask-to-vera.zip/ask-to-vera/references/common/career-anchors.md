# Career Anchors - Career Orientation Inventory (COI)

## Overview

Career Anchors (Schein, 1990) represent the professional "self-concept": what one is NEVER willing to sacrifice in their career. Validated internationally with multiple language versions (Sarchielli & Toderi, 2007; Schein & Van Maanen, 2016).

## The 8 Anchors

| Code | Name | Description |
|------|------|-------------|
| **TF** | Technical/Functional Competence | Excellence in a specific area |
| **GM** | General Managerial Competence | Responsibility, leadership, results |
| **AU** | Autonomy/Independence | Freedom, doing things your own way |
| **SE** | Security/Stability | Predictability, safety, stability |
| **EC** | Entrepreneurial Creativity | Creating something of your own |
| **SV** | Service/Dedication to a Cause | Contributing to a greater cause |
| **CH** | Pure Challenge | Difficult challenges, competition |
| **LS** | Lifestyle | Work-life integration |

## COI: 40 Items (5 per anchor)

### Technical/Functional (TF)
1. I dream of being so expert in what I do that I would be consulted as a reference
2. I will feel successful in my career only if I develop my technical or functional competencies to the highest level
3. I would rather leave my organization than be promoted out of my area of expertise
4. Becoming a senior manager does not appeal to me if it means giving up my expertise
5. I enjoy being identified by my particular expertise

### General Managerial (GM)
6. I dream of being responsible for an entire organization
7. I will feel successful only when I am in a general leadership position
8. I would rather leave my organization than accept a job that takes me away from the managerial track
9. Leading people and managing resources appeals to me more than being a technical expert
10. Success for me means managing others toward important results

### Autonomy/Independence (AU)
11. I dream of a career where I can be free from organizational constraints
12. I will feel successful only if I achieve complete autonomy
13. I would rather leave than accept a job that limits my freedom
14. Working independently is more important to me than security
15. Doing things my way is more important than salary

### Security/Stability (SE)
16. I dream of a career with long-term security and stability
17. I will feel successful only with stable employment
18. I would rather leave than accept a job that puts my security at risk
19. Financial security is more important than autonomy
20. A stable and predictable organization is ideal for me

### Entrepreneurial Creativity (EC)
21. I dream of starting and building my own business
22. I will feel successful only if I create something of my own
23. I would rather leave than give up the opportunity to create something new
24. Building an enterprise is more important than security
25. Creating something recognized as mine is fundamental

### Service/Dedication (SV)
26. I dream of a career that truly contributes to humanity
27. I will feel successful only by using my talents in service of others
28. I would rather leave than do work that doesn't help others
29. Making a difference is more important than money
30. The meaning of my work is more important than position

### Pure Challenge (CH)
31. I dream of a career with seemingly impossible problems to solve
32. I will feel successful only if I face and overcome difficult challenges
33. I would rather leave than accept a job without challenges
34. Challenge is more important than everything else
35. Competing and winning are fundamental to me

### Lifestyle (LS)
36. I dream of a career that lets me integrate personal, family, and work needs
37. I will feel successful only if I achieve work-life balance
38. I would rather leave than accept a job that interferes with my personal life
39. Work-life balance is more important than advancement
40. A career must adapt to my life, not the other way around

## Scale and Scoring

**Scale**: 1-6 (never true of me to always true of me)

**Scoring per anchor**: Arithmetic mean of the 5 items

**Output**: Ranking of 8 anchors + top 2-3 dominant

## Reference Norms (Sarchielli & Toderi, 2007)

| Anchor | Mean | SD | Alpha |
|--------|------|-----|-------|
| TF | 4.02 | 0.94 | .80 |
| GM | 3.41 | 1.12 | .88 |
| AU | 4.15 | 0.89 | .82 |
| SE | 4.38 | 0.98 | .84 |
| SV | 3.89 | 1.01 | .85 |
| EC | 3.21 | 1.18 | .91 |
| CH | 3.67 | 1.05 | .86 |
| LS | 4.28 | 0.92 | .83 |

**Note**: Security (SE) and Lifestyle (LS) tend to score higher in certain cultural contexts

## Interpretation

### Reading the Profile
1. Identify the top 2-3 anchors (score >= 4.5)
2. Identify low anchors (score <= 2.5)
3. Look for patterns and conflicts

### Typical Conflicts

| Conflict | Description | Exploration |
|----------|-------------|-------------|
| AU vs SE | Freedom vs security | Trade-off to negotiate |
| EC vs SE | Entrepreneurship vs stability | Timing, runway |
| GM vs TF | Management vs expertise | Career path |
| CH vs LS | Challenge vs balance | Life stages |

### Integration with PERMA

| Pattern | Interpretation |
|---------|----------------|
| High anchor + low PERMA M | Value not expressed = frustration |
| High AU anchor + low PERMA R | Isolation from autonomy |
| High SV anchor + low PERMA A | Impact not perceived |

## Exploration Questions

For top anchors:
- "What does [ANCHOR] mean to you?"
- "When did you feel it most alive?"
- "When was it most frustrated?"
- "What would you be willing to sacrifice to maintain it?"

For conflicts:
- "How do you manage the tension between [ANCHOR A] and [ANCHOR B]?"
- "In which direction are you leaning?"
- "What would happen if you had to choose?"

## Operational Notes

- Administer AFTER initial rapport (personal items)
- Time: 15-20 minutes
- Anchors are relatively stable but can evolve with life stages
- Watch for social desirability on certain anchors (SV, LS)
