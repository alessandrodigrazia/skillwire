# UWES-9 - Utrecht Work Engagement Scale

## Overview

The UWES-9 (Schaufeli et al., 2006) measures work engagement as a positive psychological state characterized by vigor, dedication, and absorption. It is the short validated version of the UWES-17.

## Complete Items (9 total)

### Vigor (VI) - 3 items
Energy, resilience, persistence

1. "At my work, I feel full of energy" (0-6)
2. "I feel strong and vigorous in my work" (0-6)
3. "When I get up in the morning, I feel like going to work" (0-6)

### Dedication (DE) - 3 items
Sense of meaning, enthusiasm, pride

4. "I am enthusiastic about my job" (0-6)
5. "My job inspires me" (0-6)
6. "I am proud of the work that I do" (0-6)

### Absorption (AB) - 3 items
Concentration, immersion, difficulty detaching

7. "I feel happy when I am working intensely" (0-6)
8. "I am immersed in my work" (0-6)
9. "I get carried away when I'm working" (0-6)

## Scale

| Value | Label | Frequency |
|-------|-------|-----------|
| 0 | Never | Not at all |
| 1 | Almost never | A few times a year |
| 2 | Rarely | Once a month or less |
| 3 | Sometimes | A few times a month |
| 4 | Often | Once a week |
| 5 | Very often | A few times a week |
| 6 | Always | Every day |

## Scoring

### Per Dimension
Arithmetic mean of the 3 items (0-6)

### Total Score
Mean of all 9 items (0-6)

## International Norms (Schaufeli, 2017)

| Level | Total Score | Percentile |
|-------|------------|------------|
| Very low | < 1.77 | < 5 |
| Low | 1.78 - 2.88 | 5-25 |
| Average | 2.89 - 4.66 | 25-75 |
| High | 4.67 - 5.50 | 75-95 |
| Very high | > 5.50 | > 95 |

### Per Dimension

| Dimension | Very low | Low | Average | High | Very high |
|-----------|----------|-----|---------|------|-----------|
| Vigor | < 2.17 | 2.17-3.20 | 3.21-4.80 | 4.81-5.60 | > 5.60 |
| Dedication | < 1.60 | 1.60-3.00 | 3.01-4.90 | 4.91-5.79 | > 5.79 |
| Absorption | < 1.60 | 1.60-2.75 | 2.76-4.40 | 4.41-5.35 | > 5.35 |

## Interpretation

### Balanced Profile
- All dimensions in the same range
- Consistent and sustainable engagement

### Uneven Profiles

| Pattern | Interpretation | Warning |
|---------|----------------|---------|
| VI high, DE low | Energy without meaning | Future burnout risk |
| DE high, VI low | Motivated but exhausted | Overload |
| AB high, others low | Masked workaholism | Work dependency |
| All low | Disengagement | Explore causes |

### Relationship with Burnout

Engagement is conceptually the opposite of burnout (JD-R model):
- VI opposite of exhaustion
- DE opposite of cynicism
- AB opposite of inefficacy

**Red flag**: UWES < 2.0 + physical symptoms = burnout screening (BAT)

## Integration with Other Assessments

| Pattern | Action |
|---------|--------|
| Low UWES + low PERMA E | Confirms disengagement |
| Low UWES DE + high COI SV | Service anchor not expressed |
| High UWES + low PERMA | Workaholism (explore) |

## Operational Notes

- Time: 3-5 minutes
- Administer after PERMA (more general first)
- Useful for pre/post monitoring in Branch A (Job Crafting)
- Always compare with sector-specific context if available

## Resources

- Full manual: www.wilmarschaufeli.nl
- Sector-specific norms available in the international manual
