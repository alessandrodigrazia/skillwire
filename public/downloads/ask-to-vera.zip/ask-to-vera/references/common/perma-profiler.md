# PERMA-Profiler

## Overview

The PERMA-Profiler (Butler & Kern, 2016) measures flourishing according to Seligman's model (2011). Italian validation: Giangrasso (2021), n=1,006. International norms also available.

## Complete Items (23 total)

### Positive Emotions (P) - 3 items
1. "In general, how often do you feel joyful?" (0-10)
2. "In general, how often do you feel positive?" (0-10)
3. "In general, how often do you feel contented?" (0-10)

### Engagement (E) - 3 items
4. "How often do you become completely absorbed in what you're doing?" (0-10)
5. "How often do you lose track of time while doing something you enjoy?" (0-10)
6. "How often do you feel completely engaged in what you're doing?" (0-10)

### Relationships (R) - 3 items
7. "To what extent do you receive help and support from others when you need it?" (0-10)
8. "To what extent do you feel loved?" (0-10)
9. "How satisfied are you with your personal relationships?" (0-10)

### Meaning (M) - 3 items
10. "In general, to what extent do you lead a meaningful and purposeful life?" (0-10)
11. "In general, to what extent do you feel that what you do in life has value?" (0-10)
12. "In general, to what extent do you feel you have a sense of direction in life?" (0-10)

### Accomplishment (A) - 3 items
13. "How often do you achieve the important goals you set for yourself?" (0-10)
14. "How often are you able to handle your responsibilities?" (0-10)
15. "How often do you make progress toward accomplishing your goals?" (0-10)

### Additional Items

**Health (H) - 3 items**:
16. "In general, how would you rate your health?" (0-10: terrible-excellent)
17. "How satisfied are you with your current health?" (0-10)
18. "Compared to others your age, how would you rate your health?" (0-10: terrible-excellent)

**Negative Emotions (N) - 3 items** (reverse scored):
19. "In general, how often do you feel anxious?" (0-10)
20. "In general, how often do you feel angry?" (0-10)
21. "In general, how often do you feel sad?" (0-10)

**Single items**:
22. "How happy are you?" (0-10: extremely unhappy - extremely happy)
23. "How lonely do you feel in your daily life?" (0-10: not at all - completely)

## Scoring

### Per Dimension
Arithmetic mean of the 3 items in the dimension (0-10)

### Total Flourishing
Mean of the 5 PERMA dimensions (0-10)

### Reference Norms (Giangrasso, 2021; Butler & Kern, 2016)

| Dimension | Mean | SD |
|-----------|------|-----|
| P - Positive | 6.38 | 1.89 |
| E - Engagement | 6.41 | 1.83 |
| R - Relationships | 7.11 | 2.02 |
| M - Meaning | 6.70 | 2.15 |
| A - Accomplishment | 6.68 | 1.75 |
| **Flourishing** | **6.66** | **1.57** |
| H - Health | 6.87 | 2.11 |
| N - Negative | 4.21 | 2.06 |

### Interpretation

| Score | Level |
|-------|-------|
| 0-3 | Low (below mean - 1 SD) |
| 4-6 | Normal range |
| 7-8 | High (above mean + 1 SD) |
| 9-10 | Very high |

## Psychometric Properties

- **Cronbach's Alpha**: .94 (total), .80-.91 (dimensions)
- **Test-retest**: .70-.80
- **Convergent**: r = .81 with Ryff Psychological Well-being

## Use in the Journey

1. **Baseline**: Sessions 1-2 (pre)
2. **Follow-up**: Session 10 (post)
3. **Expected delta**: >= 0.5 SD improvement (approximately +0.8 points)

## Visualization

Present results as a **radar chart** with 5 axes (P, E, R, M, A) to facilitate delivery.

## Notes

- The Engagement item may have lower alpha (.65-.72) - interpret with caution
- The Negative Emotions dimension should be presented as "Emotional Management" (positive reframe)
- Always compare with appropriate reference norms for the user's context
