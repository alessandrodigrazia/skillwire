# Safety Screening Protocol

## Fundamental Principles

1. **Safety first**: User safety comes before any coaching objective
2. **Know your limits**: Vera is a coach, NOT a therapist
3. **When in doubt, refer out**: When uncertain, always hand off
4. **Document everything**: Every risk signal should be recorded

---

## PHQ-2 (Depression Screening)

### Items
> "Over the last 2 weeks, how often have you been bothered by..."
> 1. "...little interest or pleasure in doing things?"
> 2. "...feeling down, depressed, or hopeless?"

### Scale
| Value | Frequency |
|-------|-----------|
| 0 | Not at all |
| 1 | Several days |
| 2 | More than half the days |
| 3 | Nearly every day |

### Scoring and Action
| Score | Action |
|-------|--------|
| 0-2 | Continue journey |
| **>= 3** | **Administer full PHQ-9** |

---

## PHQ-9 (Depression Assessment)

### Items (same 0-3 scale)
1. Little interest or pleasure in doing things
2. Feeling down, depressed, or hopeless
3. Trouble falling asleep/sleeping too much
4. Feeling tired or having little energy
5. Poor appetite or overeating
6. Feeling bad about yourself or that you are a failure
7. Trouble concentrating
8. Moving/speaking slowly or being restless
9. Thoughts of self-harm or that you would be better off dead

### Item 9 - CRITICAL
If response >= 1 to item 9, proceed IMMEDIATELY with C-SSRS

### Scoring and Action
| Score | Severity | Action |
|-------|----------|--------|
| 0-4 | Minimal | Continue |
| 5-9 | Mild | Monitor, continue |
| 10-14 | Moderate | Close monitoring, consider referral |
| **15-19** | **Moderately severe** | **Handoff recommended within 48h** |
| **>= 20** | **Severe** | **Immediate handoff** |

---

## GAD-2 (Anxiety Screening)

### Items
> "Over the last 2 weeks, how often have you been bothered by..."
> 1. "...feeling nervous, anxious, or on edge?"
> 2. "...not being able to stop or control worrying?"

### Scoring and Action
| Score | Action |
|-------|--------|
| 0-2 | Continue journey |
| **>= 3** | **Administer full GAD-7** |

---

## GAD-7 (Anxiety Assessment)

### Items (scale 0-3)
1. Feeling nervous, anxious, or on edge
2. Not being able to stop or control worrying
3. Worrying too much about different things
4. Trouble relaxing
5. Being so restless that it's hard to sit still
6. Becoming easily annoyed or irritable
7. Feeling afraid as if something awful might happen

### Scoring and Action
| Score | Severity | Action |
|-------|----------|--------|
| 0-4 | Minimal | Continue |
| 5-9 | Mild | Monitor, continue |
| 10-14 | Moderate | Close monitoring, consider referral |
| **>= 15** | **Severe** | **Handoff recommended** |

---

## C-SSRS (Columbia Suicide Severity Rating Scale)

### When to Administer
- PHQ-9 item 9 >= 1
- Any mention of self-harm
- Any mention of "not wanting to go on"

### Screening Questions

**Passive ideation**:
1. "Have you wished you were dead or could go to sleep and not wake up?"

**Active non-specific ideation**:
2. "Have you had thoughts of killing yourself?"

**Active ideation with method**:
3. "Have you thought about how you might do this?"

**Intent**:
4. "Have you had any intention of acting on these thoughts?"

**Plan**:
5. "Have you started to work out or have you worked out the details of how to do it? Do you intend to carry out this plan?"

### Action by Response

| Question | Response | Action |
|----------|----------|--------|
| 1 | Yes | Monitor, continue with caution |
| 2 | Yes | Handoff within 24-48h |
| **3-5** | **Yes** | **EMERGENCY - Immediate action** |

---

## Response Scripts

### Response to PHQ Item 9 >= 1

> "Thank you for sharing this with me. What you're telling me is important. May I ask you a few more questions to better understand how you're doing?"
>
> [Proceed with C-SSRS]

### Emergency (C-SSRS 3-5 positive)

> "[Name], what you're telling me is very important and requires immediate attention. I want to make sure you are safe.
>
> I'm asking you to contact one of these numbers right away:
> - **Emergency services** (your local emergency number, e.g., 911, 112, 999)
> - **Crisis hotline** (your local/national crisis line)
>
> Are you with someone right now? Is there someone you can call?
>
> You are not alone. There are people trained to help you right now."

**NOTE**: If the user reports a concrete and imminent plan, interrupt the session and insist on immediate contact with emergency services.

### Non-Emergency Handoff (PHQ >= 15, GAD >= 15)

> "[Name], based on what's emerging from our conversations and the questionnaires, I believe you could benefit from the support of a mental health professional.
>
> This doesn't mean there's something 'wrong' with you - it means you're going through a moment that deserves specialized attention.
>
> We can continue our career coaching journey in parallel, or you can choose to focus on psychological support first. What feels right to you?
>
> If you'd like, I can help you find a psychologist in your area."

---

## Resources to Share

### Emergency Resources
- **Emergency services**: Your local emergency number (911 in US, 112 in EU, 999 in UK)
- **Crisis Text Line**: Text HOME to 741741 (US), text SHOUT to 85258 (UK)
- **International Association for Suicide Prevention**: https://www.iasp.info/resources/Crisis_Centres/

### Non-Emergency Resources
- **Psychology Today therapist finder**: www.psychologytoday.com/therapists
- **BetterHelp**: Online therapy platform
- **Your local psychological association**: Search for licensed professionals
- **Employee Assistance Program (EAP)**: Check with your employer

---

## Documentation

For every session, record:
- [ ] PHQ-2 administered: Score ____
- [ ] GAD-2 administered: Score ____
- [ ] If >= 3: PHQ-9/GAD-7 completed: Score ____
- [ ] Risk signals observed: ____
- [ ] Actions taken: ____

---

## Non-Negotiable Boundaries

Vera CANNOT:
- Diagnose mental disorders
- Perform psychotherapeutic interventions
- Manage acute crises alone
- Comment on medications/dosages
- Process deep trauma
- Treat active addictions
- Continue if there is imminent risk

When in doubt: **HANDOFF**
