# Assessment Integration and Scoring

## Integration Principles

### Optimal Sequence
1. **Safety** (PHQ-2, GAD-2) - Before everything
2. **General wellbeing** (PERMA) - Current state
3. **Professional identity** (Career Anchors) - Self-concept
4. **Engagement** (UWES-9) - Work motivation
5. **Branch-specific** - Deep dive

### Anti-Redundancy Rules
- Max 4-6 total assessments per user
- 20-25% of total journey time on assessments
- If MBTI already done, do NOT administer Big Five (r=.69-.74)
- Career Anchors is complementary to everything (unique domain)

---

## Integrated Profile

### Normalized Scores

To compare assessments with different scales, normalize to a 0-100 scale:

| Assessment | Normalization Formula |
|------------|----------------------|
| PERMA (0-10) | Score * 10 |
| Career Anchors (1-6) | (Score - 1) * 20 |
| UWES-9 (0-6) | Score * 16.67 |
| JCS (1-5) | (Score - 1) * 25 |
| CAAS (1-5) | (Score - 1) * 25 |
| Ikigai-9 (1-5) | (Score - 1) * 25 |

### Key Patterns to Identify

#### 1. Frustration Gap
**Formula**: High anchor (>= 4.5) + low correlated PERMA dimension (<= 5)

| Anchor | Correlated PERMA |
|--------|-----------------|
| TF | A (Accomplishment) |
| GM | A (Accomplishment) |
| AU | E (Engagement) |
| SE | P (Positive emotions) |
| EC | A (Accomplishment) |
| SV | M (Meaning) |
| CH | E (Engagement) |
| LS | R (Relationships) |

**Interpretation**: The value is not being expressed in the current role = priority intervention target

#### 2. Anchor Conflict
**Pattern**: Two opposing anchors both high (>= 4.0)

| Conflict | Exploration |
|----------|-------------|
| AU vs SE | Freedom/security trade-off |
| EC vs SE | Entrepreneurship timing |
| GM vs TF | Career path |
| CH vs LS | Life stages |

#### 3. Disengagement
**Pattern**: UWES < 2.5 + PERMA E < 5

**Action**: Investigate causes, burnout screening (BAT)

#### 4. Masked Workaholism
**Pattern**: Very high UWES AB (> 5) + other UWES normal + low PERMA R

**Action**: Explore work-life balance, LS anchors

---

## Integrated Delivery

### Delivery Structure

1. **Flourishing Overview** (PERMA total)
   - "Your overall wellbeing level is [LEVEL]"
   - Radar visualization

2. **Strengths** (ALWAYS FIRST)
   - Top 2-3 PERMA dimensions
   - Top 2-3 Career Anchors
   - UWES if high

3. **Significant Patterns**
   - Identified frustration gaps
   - Anchor conflicts
   - Alignment/misalignment

4. **Development Areas**
   - Low PERMA dimensions
   - Engagement if low
   - Branch-specific (JCS/CAAS/Ikigai)

5. **Preliminary Recommendations**
   - Suggested intervention focus
   - Connection to chosen branch

### Recommended Visualizations

| Assessment | Visualization |
|------------|---------------|
| PERMA | 5-axis radar chart |
| Career Anchors | Horizontal bar chart (ranking) |
| UWES-9 | 3 gauges (VI/DE/AB) |
| Integrated profile | Combined dashboard |

---

## Managing Divergences

When assessments give seemingly contradictory results:

### Principle
Divergences are **information**, not errors. Reframe as complexity, not contradiction.

### Examples

**High PERMA E + low UWES AB**:
> "Interesting: you feel engaged in life in general but less absorbed by work specifically. What do you think about that?"

**High Career Anchor SV + low PERMA M**:
> "Service to others is important to you, but it seems it's not finding expression in your current role. Is that right?"

**High JCS Seeking + low UWES**:
> "You're actively trying to improve your work, but engagement is still low. Perhaps the actions haven't borne fruit yet?"

---

## Assessment Report (Template)

```markdown
# ASSESSMENT PROFILE - [Name]
Date: [Date]
Branch: [A/B/C]

## OVERALL FLOURISHING
Score: [X]/10 - [Level]
[PERMA radar chart]

## CAREER IDENTITY
Top Anchors:
1. [Anchor 1]: [Score] - [Brief description]
2. [Anchor 2]: [Score]
3. [Anchor 3]: [Score]

Low Anchors:
- [Anchor]: [Score]

## WORK ENGAGEMENT
Total score: [X]/6 - [Level]
- Vigor: [X]
- Dedication: [X]
- Absorption: [X]

## [BRANCH-SPECIFIC]
[Specific assessment with results]

## KEY PATTERNS

### Strengths
- [Strength 1]
- [Strength 2]

### Development Areas
- [Area 1]
- [Area 2]

### Integrated Insights
- [Pattern 1]
- [Pattern 2]

## SUGGESTED INTERVENTION FOCUS
[Description of priority area based on gap analysis]
```

---

## Technical Notes

### Minimum Reliability
Do not interpret assessment scores with alpha < .70 as reliable

### Missing Data
- If more than 20% items of a scale are missing, do not calculate score
- Single missing items: impute with mean of remaining items in subscale

### Pre/Post Comparison
- Use same assessments
- Clinically significant difference: >= 0.5 SD
- Report effect size (Cohen's d)
