# Pathway Affinity Scoring Algorithm

## General Formula

```
AFFINITY = RIASEC_match(40%) + Interests(20%) + Skills(20%) +
           Market(10%) + Logistics(10%) + Performance(5%) + Values(5%)
```

**Weight justification**:
- RIASEC: most robust predictor of job satisfaction (Holland 1997)
- Interests + Skills: predict pathway persistence (60% combined)
- Market + Logistics: critical practical constraints but not identity-related (20%)
- Performance + Values: influence success but more malleable (10%)

---

## Dimension 1: RIASEC Match (40%)

### Calculation

1. **Calculate differences** between student profile and pathway profile for each type
2. **Convert to match**: match = 100 - difference
3. **Weight** by type relevance in the pathway (dominant types weigh more)
4. **Bonus** +5-10% if student's top types are also the pathway's top types

### Example Pathway RIASEC Profiles

| Pathway | R | I | A | S | E | C | Dominant |
|---------|---|---|---|---|---|---|----------|
| Liceo Scientifico | 40 | 95 | 30 | 35 | 40 | 60 | I, C |
| Liceo Artistico | 55 | 30 | 95 | 50 | 45 | 25 | A, R |
| IT Informatica | 70 | 85 | 40 | 30 | 50 | 75 | I, R, C |
| IP Socio-Sanitario | 60 | 40 | 35 | 90 | 45 | 50 | S, R |
| Engineering (Uni) | 75 | 95 | 50 | 25 | 55 | 70 | I, R, C |
| Psychology (Uni) | 20 | 80 | 50 | 95 | 40 | 60 | S, I |
| ITS Mechatronics | 95 | 70 | 30 | 30 | 60 | 65 | R, I, E |

Full profiles: see `superiori/percorsi-mapping.md` or `universita/percorsi-mapping.md`

---

## Dimension 2: Interest Match (20%)

### Calculation

1. **Categorize student interests** into domains (STEM, Humanities, Artistic, Sports, Technology, Social, Business, Languages)
2. **Map pathway subjects** to the same domains
3. **Calculate weighted overlap** by interest intensity
4. **Penalty -25%** if the student's dominant interest is absent from the pathway

### Interest-Subject Table

| Interest | Domains | Subjects |
|----------|---------|----------|
| Math, logic | STEM, Tech | Mathematics, Physics, Computer Science |
| Science, nature | STEM, Bio | Biology, Chemistry, Agriculture |
| Books, writing | Humanities | Literature, Languages, Philosophy |
| Art, music | Artistic | Art, Design, Music |
| Helping people | Social | Human sciences, Psychology |
| Sports, movement | Sports | Physical education, Sports sciences |
| Computer, tech | Technology | Computer Science, Electronics |
| Business, economics | Business | Economics, Law, Marketing |

---

## Dimension 3: Skills Match (20%)

### The 9 Soft Skills

1. Problem solving
2. Critical thinking
3. Creativity
4. Communication
5. Teamwork
6. Leadership
7. Time management
8. Adaptability
9. Emotional intelligence

### Calculation

For each skill:
- If student >= required: match = 100
- Otherwise: match = 100 - (gap x 15)

Weight by skill importance in the pathway (1-5).

### Example Pathway Profile

**Liceo Scientifico**:
- Problem solving: required 8, importance 5
- Critical thinking: required 8, importance 5
- Creativity: required 5, importance 2
- Time management: required 7, importance 4

---

## Dimension 4: Job Market Match (10%)

### Calculation

For each career outcome:
- Trend score (strong_growth=100, growth=80, stable=60, decline=40, strong_decline=20)
- Employment score (high=100, medium=70, low=40)
- Profession score = trend*0.6 + employment*0.4
- Weighted average by outcome probability

### Age Adjustment

If student <=14 years: M_match x 0.80 (market will change in 10+ years)

### Current Trends (2025-2030)

**Strong growth**: AI/ML, cybersecurity, software development, renewable energy, data science, digital marketing, home healthcare

**Stable**: Teachers, health professionals, specialized craftspeople, lawyers

**Declining**: Data entry, cashiers, routine assembly workers, call center operators

---

## Dimension 5: Logistics Match (10%)

### Calculation

```
Start: L_match = 100

Geographic availability:
- In province: 100
- In region + mobility ok: 90
- Out of region + national mobility: 70
- Online: 85
- Not reachable: 20-40

Economic sustainability:
- Severe constraints + cost >3000: x0.60 (recovery +20% if scholarships available)
- Moderate constraints + cost >8000: x0.85

Accessibility (competitive admission):
- Admission probability <50%: x0.70
- Admission probability 50-75%: x0.90
```

### Average Annual Costs (2025, Italy)

| Pathway | Tuition | Out-of-town Housing | Total |
|---------|---------|---------------------|-------|
| Public high school (Liceo) | 0-150 | 6000-9000 | 150-9150 |
| University (ISEE <20k) | 0-500 | 6000-9000 | 500-9500 |
| University (ISEE >40k) | 2000-3500 | 6000-9000 | 5500-12500 |
| ITS Academy | 0-1000 | 6000-9000 | 1000-10000 |

---

## Dimension 6: Performance Match (5%)

### Calculation

1. Average grades in key subjects for the pathway
2. Required threshold = 6 + (difficulty - 3)
3. Score based on distance from threshold

| Difficulty Level | Threshold | Pathways |
|-----------------|-----------|----------|
| 5 (Very high) | 8+ | Liceo Classico, Scientifico, Medicine |
| 4 (High) | 7+ | Liceo Linguistico, Humanities degrees |
| 3 (Medium) | 6.5+ | Technical schools, Liceo Artistico, ITS |
| 2 (Medium-low) | 6+ | Vocational schools (Professionali) |

Bonus +10% if grade trend is improving.

---

## Dimension 7: Values Match (5%)

### The 7 Values

1. Earnings
2. Stability
3. Creativity
4. Social impact
5. Autonomy
6. Prestige
7. Work-life balance

### Calculation

For each value important to the student (>7):
- Match = how much the pathway fulfills that value x 10

If value is not important: neutral match (80).

### Pathway Value Profiles

| Pathway | Earnings | Stability | Creativity | Impact | Autonomy | Prestige |
|---------|----------|-----------|------------|--------|----------|----------|
| Medicine | 7 | 8 | 5 | 10 | 6 | 9 |
| Engineering | 8 | 8 | 7 | 6 | 6 | 7 |
| Fine Arts | 3 | 3 | 10 | 6 | 9 | 4 |
| ITS Industry | 8 | 9 | 5 | 5 | 6 | 5 |

---

## Confidence Score

### Factors That Reduce Confidence

| Factor | Penalty |
|--------|---------|
| Data collected <20 | -20 |
| Data collected <15 | -35 |
| Flat RIASEC profile (max <70) | -15 |
| Dimension incoherence (diff >30) | -10 |
| Critical logistics (L_match <50) | -15 |
| Age <=13 years | -10 |
| Outdated market data | -10 |

### Mapping

- Score >=75: **HIGH** (green)
- Score 50-74: **MEDIUM** (yellow)
- Score <50: **LOW** (red)

---

## Output Presentation

Always include:

1. **Numerical score**: 82/100
2. **Confidence**: HIGH/MEDIUM/LOW
3. **Breakdown** of top-3 dimensions with percentages
4. **Qualitative interpretation**

```
90-100: Excellent match, very high probability of success
80-89: Very good match, great prospects
70-79: Good match, valid pathway with some compromises
60-69: Moderate match, requires strong motivation
<60: Limited match, consider alternatives
```

5. **Disclaimer**: "Score is an estimate based on current data. Interests and the market will evolve."
