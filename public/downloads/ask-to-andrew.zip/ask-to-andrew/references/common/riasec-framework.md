# RIASEC Holland Framework

## Theoretical Foundations

The RIASEC model (Holland, 1959-1997) postulates that:
- People seek work environments congruent with their personality
- There are 6 types of work personality (RIASEC hexagon)
- Greater person-environment congruence = greater satisfaction and performance
- Most people have a combined profile (2-3 dominant types)

---

## The Six Types

### R - REALISTIC ("The Doer")

**Characteristics**: Prefers concrete, practical, hands-on activities. Enjoys working with objects, tools, machines, animals, plants. Results-oriented.

**Values**: Utility, efficiency, concreteness

**Ideal environments**: Workshops, labs, construction sites, farms, gyms

**Typical professions**: Mechanical engineer, electrician, chef, veterinarian, personal trainer, farmer, pilot, IT technician

**Related subjects**: Science, technology, physical education, technical labs

**Typical hobbies**: Sports, DIY, gardening, repairs, cooking, hiking

---

### I - INVESTIGATIVE ("The Thinker")

**Characteristics**: Prefers observing, analyzing, understanding phenomena. Enjoys scientific research, complex problem-solving. Analytical, logical, systematic approach.

**Values**: Truth, knowledge, innovation

**Ideal environments**: Research labs, libraries, universities, R&D centers

**Typical professions**: Scientist, doctor, data analyst, researcher, biologist, mathematician, experimental psychologist, cybersecurity expert

**Related subjects**: Mathematics, physics, chemistry, biology, computer science, philosophy

**Typical hobbies**: Non-fiction reading, documentaries, experiments, logic puzzles, programming

---

### A - ARTISTIC ("The Creator")

**Characteristics**: Prefers expressing through creative forms. Enjoys originality, aesthetic innovation, breaking patterns. Intuitive, emotional, imaginative approach.

**Values**: Beauty, authenticity, creative freedom

**Ideal environments**: Studios, design firms, theaters, editorial offices, galleries

**Typical professions**: Graphic designer, architect, musician, writer, director, photographer, fashion designer, illustrator

**Related subjects**: Art, music, literature, art history, foreign languages

**Typical hobbies**: Drawing, playing instruments, creative writing, photography, dance, theater

---

### S - SOCIAL ("The Helper")

**Characteristics**: Prefers interacting, helping, training others. Enjoys meaningful relationships, empathy, support. Collaborative, welcoming, patient approach.

**Values**: Others' well-being, equity, community

**Ideal environments**: Schools, hospitals, social centers, NGOs, counseling offices

**Typical professions**: Teacher, nurse, social worker, educator, clinical psychologist, physiotherapist, HR specialist

**Related subjects**: Human sciences, psychology, pedagogy, social sciences, languages

**Typical hobbies**: Volunteering, team sports, tutoring, organizing social events

---

### E - ENTERPRISING ("The Persuader")

**Characteristics**: Prefers leading, persuading, organizing projects. Enjoys competitive challenges, calculated risk, leadership. Assertive, energetic, results-oriented approach.

**Values**: Success, power, influence, status

**Ideal environments**: Corporations, startups, law firms, marketing agencies, politics

**Typical professions**: Manager, entrepreneur, lawyer, salesperson, strategic consultant, PR specialist, politician, event manager

**Related subjects**: Economics, law, marketing, political science, communications

**Typical hobbies**: Event organizing, association leadership, debates, competitions

---

### C - CONVENTIONAL ("The Organizer")

**Characteristics**: Prefers order, precision, structured procedures. Enjoys managing data, following regulations, ensuring accuracy. Methodical, reliable, detail-oriented approach.

**Values**: Security, stability, precision

**Ideal environments**: Offices, banks, public administration, accounting firms

**Typical professions**: Accountant, administrator, management programmer, librarian, quality controller, financial analyst

**Related subjects**: Applied mathematics, business economics, law, management IT

**Typical hobbies**: Collections, home organization, strategy games, genealogy

---

## Relationships Between Types (Holland Hexagon)

```
        R
       / \
      C   I
      |   |
      E   A
       \ /
        S
```

**Adjacent types** (more compatible):
- R-I, I-A, A-S, S-E, E-C, C-R

**Opposite types** (less compatible):
- R-S, I-E, A-C

If two opposite types are both >75, check whether there is genuine integration or tension.

---

## Typical Combined Profiles

### STEM Profiles
- **I-R**: Practical researcher (engineering, applied sciences)
- **I-C**: Systematic analyst (computer science, statistics)
- **I-A**: Creative researcher (architecture, industrial design)

### Humanities Profiles
- **A-S**: Social artist (art teaching, expressive therapy)
- **S-I**: Analytical helper (psychology, speech therapy)
- **A-E**: Creative entrepreneur (marketing, fashion)

### Business Profiles
- **E-C**: Organizational manager (administration, finance)
- **E-S**: Relational leader (HR, public relations)
- **E-R**: Operational entrepreneur (tech startup)

### Technical Profiles
- **R-C**: Precise technician (mechanics, electronics)
- **R-I**: Innovative technologist (robotics, biotechnology)
- **C-S**: Relational organizer (secretarial work, personnel management)

---

## Problematic Profiles

### Flat Profile (all scores 40-60)

**Possible causes**:
- Developmental stage: identity not yet defined
- Low self-awareness
- Socially desirable responses
- Demotivation/depression

**Strategy**: Flexible pathways, exploratory plan, follow-up in 3-6 months, LOW Confidence

### Conflicting Profile (opposites both >75)

**Example**: R-90, A-85

**Interpretation**: Not necessarily problematic - many professions require combinations (artistic craftsman, industrial designer). Check whether it's genuine integration or tension.

**Strategy**: "Bridge" pathways, explore authenticity

### Monochromatic Profile (1 type >85, all others <40)

**Interpretation**: Highly focused identity, clear vocation. Risk of rigidity.

**Strategy**: Leverage clarity, develop complementary skills

---

## Age-Based Evolution

| Age | Characteristics |
|-----|-----------------|
| 11-13 | Unstable profiles, influenced by recent experiences. Flat profile is normal. |
| 14-16 | Initial consolidation, dominant types emerge but fluctuations are normal |
| 17-19 | More stable profiles, identity crystallizing |

**Implication**: For ages 11-13, Confidence always <=MEDIUM. Suggest follow-up.

---

## Profile Validation

Before using the profile for recommendations, verify:

1. **Test-interests coherence**: Do the 2 dominant types match preferred subjects? (tolerance +/-15%)
2. **Test-activities coherence**: Do dominant types reflect declared hobbies?
3. **Test-values coherence**: Are dominant types aligned with declared values?
4. **Plausibility**: Adjacent types are more compatible than opposites

**If discrepancy >15%**: Present findings to student, explore causes, corrective action.

---

## Soft Skills Integration

| Skill | Related RIASEC Types |
|-------|---------------------|
| Problem solving | I, E, R |
| Creativity | A, I |
| Communication | S, E, A |
| Teamwork | S, E |
| Leadership | E, S |
| Time management | C, E |
| Adaptability | A, E, I |
| Critical thinking | I, A |
| Resilience | R, E |
