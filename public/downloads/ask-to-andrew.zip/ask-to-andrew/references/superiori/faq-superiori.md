# FAQ and Special Cases - High School (Scuole Superiori)

## "Dream vs Reality" Protocol

### When to Use It

When a 12-13 year old student declares an unrealistic career aspiration:
- "I want to be a YouTuber"
- "I want to be a hairdresser/shampoo assistant"
- "I want to be a soccer player"
- "I want to be an influencer"
- "I want to be a pro gamer"

### The 7 Steps

#### A. Distinguish Passion vs Career

"You like [X]? That's great! Let's distinguish two things:
1. What you ENJOY doing (hobby/passion)
2. What you'd want to do 8 HOURS A DAY for 40 years (job)

Sometimes they align, sometimes they don't. Let's figure it out together."

#### B. RIASEC Coherence Test

If declared aspiration != RIASEC profile, flag it:

"You say you want to be a YouTuber, but your profile shows strong R (practical)
and low E (enterprising). Being a YouTuber requires high E (self-promotion,
building an audience). Let's explore what really attracts you about YouTube..."

#### C. Objective Data (without crushing dreams)

Provide real data but constructively:

**Example Hairdresser/Shampoo Assistant**:
"Great profession! Here are the numbers:
- Employment rate: 65% within 3 years
- Average salary: 18-25k euros/year
- Pathway: Vocational (Professionale) Services or IeFP (3 years)
- Industry: Stable

For comparison, other creative hands-on professions:
- CAD technician/designer: 78% employment, 28-35k euros
- Advanced beautician (beauty tech): growing sector"

**Example YouTuber/Influencer**:
"I understand the appeal! Real numbers:
- YouTubers who earn enough to live on: <0.1% of those who try
- Average time to monetize: 3-5 years of regular content
- Required skills: video editing, marketing, business (high E type)

Many successful YouTubers had a 'Plan B' (regular job) until
they took off. What could yours be?"

#### D. Deep Exploratory Questions

"What EXACTLY do you like about [hairdressing/YouTube]?

- Working with your hands? -> Let's explore hands-on jobs with better prospects
- Creativity? -> Design, communications, graphic design
- Contact with people? -> Services, sales, education
- Freedom and autonomy? -> Entrepreneurship in various sectors
- Fame/visibility? -> Honest truth: probability of YouTube success = 0.01%
- Easy money? -> Honest truth: it doesn't exist. Every job requires effort"

#### E. Pathways That Keep Options Open

**Never close doors**. Even if they want to be a hairdresser:

"I'd recommend IT Commercial Services (IT Servizi Commerciali) instead of a purely vocational Beauty (Professionale Estetica) track.
Why? If you change your mind in 3 years, IT gives you more options.
From a purely vocational track, fewer options. And you can always specialize later."

#### F. Plan B Always Explicit

Every recommendation includes:

"If [dream] doesn't work out, from this pathway you could also do [X, Y, Z]"

**Never** suggest a pathway with no exit route.

#### G. Empowerment (not Paternalism)

"The choice is YOURS. My job is to make sure you choose with ALL the data,
not just with the excitement of the moment. In 5 years you'll either thank me
or curse me -- I want it to be the first one!"

---

## Common Situations

### 1. Flat RIASEC Profile (all scores 40-60)

**Causes**: Normal at ages 12-13, limited exposure to experiences, exploratory phase.

**Strategy**:
- Use projective scenarios to surface preferences
- Recommend flexible pathways (Liceo Scienze Umane, IT with specializations)
- Exploratory plan: 4-5 open days across different areas
- Follow-up after 6 months of experiences
- Confidence: LOW

**Message**: "Your profile is still forming, which is completely normal
at your age. Proceed by experimenting, not by certainties."

### 2. Family-Student Conflict

**Scenario**: Student wants Liceo Artistico, family insists on Liceo Scientifico.

**Strategy**:
1. Validate student's emotions
2. Explore family motivations (financial fear? prestige?)
3. Provide objective data on career outcomes
4. Propose a compromise (e.g., Architecture = art + engineering)
5. Suggest mediation with school guidance counselor

**Output**:
- Pathway #1: The one matching student's profile (authentic)
- Pathway #2: The one the family wants (honest analysis)
- Pathway #3: Compromise
- Confidence: MEDIUM

**If coercive pressure (threats, blackmail)**:
RED FLAG -> Refer to school psychologist/social services

### 3. Student with SEN/SLD (BES/DSA)

**Collect**: Type of disorder, compensatory tools used, affected subjects.

**Consider**:
- Hands-on/lab-based teaching is more accessible
- Text-heavy licei are harder for students with dyslexia
- Technical/Vocational schools are often more SEN-friendly

**Guaranteed rights**: PDP (Personalized Learning Plan) is mandatory in all high schools.

**Recommended pathways for severe dyslexia**:
- Liceo Artistico (practical assessment)
- IT Informatica (code > text)
- Vocational (Professionale) (mainly practical)

**Message**: "Your SEN/SLD is not a limitation. Many excellent professionals
are dyslexic. Leverage your strengths (e.g., visual thinking)."

### 4. Severe Financial Constraints

**Prioritize**:
- Local public schools (free)
- Avoid suggestions requiring costly relocation

**Highlight**:
- Regional merit-based scholarships
- Economic hardship scholarships
- ITS after diploma (often free, high employability)

**Message**: "There are excellent free schools near you. Money
should not limit your choices."

### 5. High Decision Anxiety (>7/10)

**Strategy**:
1. Normalize: "60% of students feel the same way"
2. Reduce pressure: "You can always change; no choice is final"
3. Gradual decision: first the broad area, then details
4. Suggest flexible pathways that keep doors open

**If anxiety >8/10 + somatic symptoms**:
RED FLAG -> "I suggest talking to a school psychologist.
Guidance can wait until you're feeling better."

### 6. "All My Friends Are Going to School X"

**Response**:
"Friends are important, but you'll spend 30+ hours/week studying
those subjects. If they bore you, the price is high.

Consider: making new friends at a school that excites you,
or struggling for 5 years with old friends?

Real friendships survive different schools."

### 7. "What If I Make the Wrong Choice?"

**Response**:
"15% of students change tracks. You can correct course within the first
year with few debts. There's no perfect choice at age 13.

Choose the 'least imperfect one for you right now' and adjust as you go."

### 8. "Good at Everything" Student / Gifted

**Risks**: Boredom, underachievement, choosing any pathway.

**Strategy**:
- Stimulating pathways (Liceo Scientifico with Olympiads, enhanced sections)
- Challenging extracurricular activities
- Warning: "Choose an environment that challenges you, not one that gives you easy grades"

### 9. Apathetic Student ("I don't know what I like")

**Distinguish**:
- Depression (persistent low mood) -> RED FLAG psychologist
- Lack of experiences -> Forced exploratory plan

**If not depression**:
- Elimination approach: "Which one would you rule out immediately?"
- Universal pathways (Scienze Umane, AFM)
- Pact: neutral choice now + 3 extracurricular activities in 6 months + review

### 10. Immigrant Background

**Consider**:
- Language gap (practical pathways more accessible)
- Family's cultural values
- Leverage intercultural skills

**Message**: "Your multicultural background is an added value."

---

## Frequently Asked Student Questions

**"Without a degree I'll never find a job?"**
No. ITS programs have 85% employment, better than many degrees. It depends on the field.

**"Is Liceo Classico useless?"**
No, but it's very demanding. Excellent for those who love ancient languages and text analysis.

**"Is vocational school (Professionale) for people who don't want to study?"**
False. Vocational school is different, not easier. It requires practical effort.

**"Can I switch schools later?"**
Yes. Before December of year 1 it's simple. After that it's more complex but doable.

---

## Red Flags to Report

| Situation | Action |
|-----------|--------|
| Anxiety >8/10 + somatic symptoms | School psychologist |
| Coercive family pressure | School mediator |
| Signs of depression | Psychological support |
| Severe identity conflict | Counselor |
| Suicidal ideation | Emergency - immediate support |
