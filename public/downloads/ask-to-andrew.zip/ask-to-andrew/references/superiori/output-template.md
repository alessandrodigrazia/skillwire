# Output Template - High School Guidance (Ages 12-13)

## Target Length

Report: ~2000 words
Parents version: ~500 additional words

---

## Report Structure

```
======================================
GUIDANCE REPORT
======================================

**Name**: [Name]
**Age**: [X] years | **Grade**: [grade]
**Date**: [dd/month/year]

---

## YOUR PROFILE

[Personalized narrative - 100-150 words]
[Simple language, short sentences, concrete examples]
[Must be recognizable - no generic descriptions]

Example:
"You're a curious person who loves understanding how things work.
You like [interest 1] and [interest 2], and when you do [activity] you lose
track of time. Your strengths are [skill 1] and
[skill 2] - you showed this when [concrete example].
For you, [main value] is important."

---

### RIASEC Profile

**Your code**: [e.g., I-R-C]

| Type | Score | What it means |
|------|-------|---------------|
| R Realistic | [X]/100 | You like doing practical things with your hands |
| I Investigative | [X]/100 | You like understanding how things work |
| A Artistic | [X]/100 | You like creating and expressing yourself |
| S Social | [X]/100 | You like helping and being with people |
| E Enterprising | [X]/100 | You like organizing and leading |
| C Conventional | [X]/100 | You like order and precision |

[Simple explanation - 50 words max]

---

### Your Strengths

- **[Skill 1]**: [Brief concrete example]
- **[Skill 2]**: [Brief concrete example]
- **[Skill 3]**: [Brief concrete example]

---

## RECOMMENDED PATHWAYS

[Repeat for 3-5 pathways]

======================================
### PATHWAY #1: [NAME]
======================================

**Affinity**: [X]/100 | **Confidence**: [HIGH/MEDIUM/LOW]

---

#### WHY IT SUITS YOU

[150-200 words - Connect profile to pathway]

- Your [dominant RIASEC] type fits well because...
- Your passion for [interest] is expressed in...
- Your strength in [skill] helps you in...

---

#### WHAT YOU'LL STUDY

**Key subjects**:
- [Subject 1]: [hours/week] - [simple description]
- [Subject 2]: [hours/week] - [simple description]
- [Subject 3]: [hours/week] - [simple description]

**How you study**:
[Theory/Practice - Labs yes/no - Types of assessments]

**Difficulty**: [X]/5 - [Comment]

---

#### AFTER THE DIPLOMA

**You could become**:
- [Profession 1] - [trend indicator]
- [Profession 2] - [trend indicator]
- [Profession 3] - [trend indicator]

**Or continue studying**:
- [University/ITS option 1]
- [University/ITS option 2]

---

#### WHERE TO STUDY

**Schools in your area**:
- [School 1] - [city]
- [School 2] - [city]
(or: "Search on [regional portal] for schools in your area")

---

#### WHAT TO DO NOW

- [ ] Go to the open day at [school] (check dates on their website)
- [ ] Talk to students who already attend
- [ ] Try [concrete activity to test interest]
- [ ] Watch videos/stories from students on YouTube

---

#### HOW I CALCULATED THE AFFINITY

| Dimension | Weight | Your score | Contribution |
|-----------|--------|------------|--------------|
| RIASEC Match | 40% | [X]/100 | [X] points |
| Interest Match | 20% | [X]/100 | [X] points |
| Skills Match | 20% | [X]/100 | [X] points |
| Market Match | 10% | [X]/100 | [X] points |
| Logistics Match | 10% | [X]/100 | [X] points |
| Academic Performance | 5% | [X]/100 | [X] points |
| Values Match | 5% | [X]/100 | [X] points |
| **TOTAL** | **100%** | | **[X]/100** |

**Confidence**: [HIGH/MEDIUM/LOW] - [If not HIGH, explain why]

---

[END single pathway - repeat for #2, #3, etc.]

======================================
======================================

---

## FINAL THOUGHTS

**Remember**:

1. **There's no perfect choice**. Every school has pros and cons.

2. **You can always change your mind**. If after a year you're not happy, you can
   switch tracks. It happens to 15% of students.

3. **It's normal to be unsure**. You're 12-13 years old, you don't have to have it
   all figured out. Use this report as a compass, not a verdict.

4. **Before deciding, have experiences**. Go to at least 2-3 open days.
   Talk to current students. Try concrete activities.

5. **You're the expert on yourself**. If something in this report doesn't
   convince you, trust your instinct and dig deeper.

[If high anxiety or red flag]:
**Important note**: [Professional support referral - school psychologist,
counselor, etc.]

---

## USEFUL RESOURCES

**For you**:
- [Regional school portal] - find schools in your area
- [YouTube/guidance channels] - student videos

**For your parents**:
- [UNICA MIM platform] - official enrollment and guidance portal

---

## CALENDAR

**Next steps**:
- By [month]: Attend 2-3 open days
- By [month]: Talk to current/former students
- By [month]: Decide your top-2 schools
- [Enrollment date]: Online enrollment

**Let's reconnect** after you've had some experiences!

---

## QUESTIONS FOR THE OPEN DAY

Bring these questions when you visit schools:

1. "How many hours of lab work do you have per week?"
2. "What are the assessments like? Written, oral, practical?"
3. "What do you do during PCTO (internships)?"
4. "What do students do after graduation?"
5. "How do you help students who are struggling?"

======================================
End of Report
======================================
```

---

## Parents Version (attachment)

```
======================================
SUMMARY FOR PARENTS
======================================

**[Name]'s profile**:
[100-word summary - adult language]

**Recommended pathways** (in order of affinity):

1. [Pathway] - Affinity [X]% - [1-sentence rationale]
2. [Pathway] - Affinity [X]% - [1-sentence rationale]
3. [Pathway] - Affinity [X]% - [1-sentence rationale]

**How to support the choice**:

- Accompany them to open days but let them ask the questions
- Avoid phrases like "that school has no career prospects" - the data say otherwise
- If your expectations differ, let's discuss it together
- The final choice should be theirs, not yours

**Important deadlines**:
- Open days: [period]
- Online enrollment: [dates]

**Useful contacts**:
- School guidance counselor: [if available]
- [Regional resources]
======================================
```

---

## Style Notes

**For ages 12-13**:
- Sentences <20 words
- Simple vocabulary
- Everyday examples
- Encouraging but honest tone
- Avoid jargon (CFU, ECTS, etc.)
- Use direct "you" address

**Emoji/symbols**:
- Job trends: strong growth, growth, stable, decline
- Confidence: HIGH, MEDIUM, LOW
- Checklist: empty boxes for actions

**Total length**: Max 2500 words (report + parents)
