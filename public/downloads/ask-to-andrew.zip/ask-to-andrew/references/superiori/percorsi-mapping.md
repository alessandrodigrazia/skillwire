# High School Pathway Mapping (Scuole Superiori)

## School Types

### LICEI (5 years)

**Characteristics**: Predominantly theoretical education, university preparation, diploma grants access to all university faculties.

#### Liceo Classico

| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:25 I:80 A:65 S:50 E:55 C:60 |
| **Dominant** | I (text analysis), A (interpretation), C (rigor) |
| **Subjects** | Latin 5h, Ancient Greek 4h, Italian, Philosophy, History |
| **Weekly hours** | 27 (first 2 years), 31 (last 3 years) |
| **Difficulty** | 5/5 (very high study workload) |
| **Typical outcomes** | Law, Literature, Philosophy, Medicine (with supplementary prep) |
| **Ideal profile** | Passion for ancient languages, history, excellent text analysis |

#### Liceo Scientifico

| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:40 I:95 A:30 S:35 E:40 C:60 |
| **Dominant** | I (logical-mathematical), C (rigor) |
| **Subjects** | Mathematics 4-5h, Physics 2-3h, Sciences 3h |
| **Weekly hours** | 27 (first 2 years), 30 (last 3 years) |
| **Options** | Applied Sciences (+Computer Science, -Latin), Sports track |
| **Difficulty** | 5/5 |
| **Typical outcomes** | Engineering, Physics, Mathematics, Medicine, Economics |
| **Ideal profile** | Strong mathematical logic, scientific curiosity |

#### Liceo Linguistico

| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:20 I:55 A:65 S:70 E:60 C:45 |
| **Dominant** | S (communication), A (languages), E (relationships) |
| **Subjects** | 3 foreign languages (12h total), CLIL |
| **Weekly hours** | 27 (first 2 years), 30 (last 3 years) |
| **Difficulty** | 4/5 |
| **Typical outcomes** | Languages, Mediation, International Relations, Tourism |
| **Ideal profile** | Passion for languages, openness to different cultures |

#### Liceo Scienze Umane

| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:25 I:65 A:55 S:90 E:45 C:50 |
| **Dominant** | S (helping relationship), I (psychology) |
| **Subjects** | Human Sciences 4-5h (Psychology, Pedagogy, Sociology), Philosophy |
| **Option** | Economico-Sociale (+Law, Economics, -Latin) |
| **Weekly hours** | 27 (first 2 years), 30 (last 3 years) |
| **Difficulty** | 3/5 |
| **Typical outcomes** | Psychology, Education Sciences, Social Work |
| **Ideal profile** | Interest in human dynamics, empathy |

#### Liceo Artistico

| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:55 I:30 A:95 S:50 E:45 C:25 |
| **Dominant** | A (creativity), R (hands-on) |
| **Subjects** | Painting/Sculpture disciplines 12h, Lab work, Art History |
| **Specializations (from year 3)** | Figurative Arts, Architecture, Design, Audiovisual, Graphic Design, Set Design |
| **Weekly hours** | 34 |
| **Difficulty** | 3/5 |
| **Typical outcomes** | Fine Arts Academy, Architecture, Design, DAMS |
| **Ideal profile** | Strong visual creativity, artistic manual skills |

#### Liceo Musicale/Coreutico

| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:60 I:35 A:95 S:55 E:50 C:40 |
| **Dominant** | A (artistic expression), R (instrumental/body practice) |
| **Subjects** | Music track: Instrument 6h, Theory-composition. Dance track: Dance 8h |
| **Requirements** | Practical aptitude test |
| **Difficulty** | 4/5 (requires already-developed talent) |
| **Typical outcomes** | Conservatories, Dance Academies, DAMS, artistic careers |

---

### ISTITUTI TECNICI - Technical Schools (5 years)

**Characteristics**: Balance of theory and practice (30-40% lab work), PCTO internships, technical diploma.

#### Economic Sector

**Amministrazione Finanza Marketing (AFM) - Administration Finance Marketing**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:30 I:55 A:30 S:50 E:75 C:85 |
| **Dominant** | C (precision), E (business) |
| **Subjects** | Business Economics 8h, Law, Computer Science |
| **Specializations** | International Relations, Information Systems |
| **Weekly hours** | 32 |
| **Difficulty** | 3/5 |
| **Outcomes** | Administrative clerk, accountant, marketing |
| **Employment 3y** | 65% |

**Turismo - Tourism**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:35 I:40 A:50 S:80 E:70 C:55 |
| **Dominant** | S (relationships), E (organization) |
| **Subjects** | Tourism disciplines, 3 languages, Tourism Geography |
| **Difficulty** | 3/5 |
| **Outcomes** | Tourism operator, event planner |
| **Employment 3y** | 58% |

#### Technology Sector

**Informatica e Telecomunicazioni - IT and Telecommunications**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:70 I:85 A:40 S:30 E:50 C:75 |
| **Dominant** | I (logic), R (practical), C (precision) |
| **Subjects** | Computer Science 6h, Networks 4h, TPSIT |
| **Specializations** | Computer Science, Telecommunications |
| **Weekly hours** | 32 |
| **Difficulty** | 4/5 |
| **Outcomes** | Programmer, system administrator, network technician |
| **Employment 3y** | 78% |

**Elettronica ed Elettrotecnica - Electronics and Electrical Engineering**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:85 I:75 A:30 S:25 E:45 C:70 |
| **Dominant** | R (practical), I (technical) |
| **Subjects** | Electronics 7h, Automated Systems |
| **Specializations** | Electronics, Electrical Engineering, Automation |
| **Difficulty** | 4/5 |
| **Outcomes** | Electronics technician, designer, maintenance tech |
| **Employment 3y** | 72% |

**Meccanica Meccatronica - Mechanical Engineering and Mechatronics**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:90 I:70 A:35 S:25 E:50 C:65 |
| **Dominant** | R (hands-on practical), I (technical) |
| **Subjects** | Mechanics 5h, Automation Systems, CAD |
| **Difficulty** | 4/5 |
| **Outcomes** | Mechanical technician, CAD designer, Industry 4.0 |
| **Employment 3y** | 75% |

**Chimica Materiali Biotecnologie - Chemistry, Materials, Biotechnologies**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:65 I:90 A:35 S:45 E:35 C:70 |
| **Dominant** | I (research), R (lab work) |
| **Specializations** | Chemistry, Environmental Biotechnologies, Health Biotechnologies |
| **Difficulty** | 4/5 |
| **Outcomes** | Lab technician, quality control |
| **Employment 3y** | 68% |

**Costruzioni Ambiente Territorio (ex Geometra) - Construction, Environment, Territory**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:80 I:65 A:55 S:30 E:50 C:70 |
| **Dominant** | R (construction site), I (design) |
| **Subjects** | Design, Topography, Site Management |
| **Difficulty** | 3/5 |
| **Outcomes** | Surveyor (with state exam), building technician |
| **Employment 3y** | 70% |

**Grafica e Comunicazione - Graphic Design and Communications**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:55 I:50 A:85 S:45 E:55 C:50 |
| **Dominant** | A (creativity), R (technique) |
| **Subjects** | Multimedia Design 6h, Labs |
| **Difficulty** | 3/5 |
| **Outcomes** | Graphic designer, web designer, print technician |
| **Employment 3y** | 62% |

---

### ISTITUTI PROFESSIONALI - Vocational Schools (5 years, 3-year qualification available)

**Characteristics**: Strongly practice-oriented (50%+ lab work), 3rd-year qualification, intensive internships.

**Servizi Socio-Sanitari - Social and Healthcare Services**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:60 I:40 A:35 S:90 E:45 C:50 |
| **Dominant** | S (care), R (practical assistance) |
| **Subjects** | Operational Methods, Hygiene, Psychology |
| **Difficulty** | 2/5 |
| **Outcomes** | Healthcare assistant (OSS, with qualification), educator, nurse (with university) |
| **Employment 3y** | 65% |

**Enogastronomia e Ospitalita - Food and Hospitality**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:85 I:30 A:60 S:75 E:55 C:45 |
| **Dominant** | R (kitchen/dining room), S (hospitality), A (creativity) |
| **Specializations** | Gastronomy, Dining Service, Hospitality |
| **Difficulty** | 2/5 |
| **Outcomes** | Cook, waiter, receptionist |
| **Employment 3y** | 70% |

**Servizi Commerciali - Commercial Services**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:40 I:45 A:45 S:65 E:75 C:70 |
| **Dominant** | E (sales), C (management), S (customer) |
| **Difficulty** | 2/5 |
| **Outcomes** | Sales assistant, e-commerce, social media |
| **Employment 3y** | 60% |

**Manutenzione e Assistenza Tecnica - Maintenance and Technical Assistance**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:95 I:60 A:25 S:30 E:40 C:55 |
| **Dominant** | R (repair), I (diagnostics) |
| **Difficulty** | 2/5 |
| **Outcomes** | Mechanical/electrical maintenance tech, systems technician |
| **Employment 3y** | 73% |

**Produzioni Industriali e Artigianali - Industrial and Artisan Production**
| Aspect | Detail |
|--------|--------|
| **RIASEC Profile** | R:90 I:45 A:55 S:30 E:40 C:50 |
| **Dominant** | R (manual production) |
| **Specializations** | Industry, Craftsmanship (wood, ceramics, textiles) |
| **Difficulty** | 2/5 |
| **Outcomes** | Specialized craftsman, production technician |
| **Employment 3y** | 68% |

---

## Choosing Guide

### Choose a LICEO if:

- University is the primary goal
- You prefer a theoretical approach, intensive study
- Your interests are still broad and undefined
- You want to keep more doors open

### Choose a TECHNICAL SCHOOL (Istituto Tecnico) if:

- You want a balance between university and work readiness
- You're interested in technical-scientific subjects with practical application
- You want immediately usable skills
- You enjoy lab work

### Choose a VOCATIONAL SCHOOL (Istituto Professionale) if:

- You have a strong preference for the practical component
- Your primary goal is a job after graduation
- You're interested in a specific sector (food service, mechanics, social care)
- You want a qualification after 3 years (optional)

---

## Note: Pathways That Keep Doors Open vs Close Them

**Pathways that open more doors** (recommended if uncertain):
- Liceo Scientifico (access to any university faculty)
- Liceo Linguistico (flexible)
- IT Informatica (tech + university)
- IT AFM (business + university)

**Specialized pathways** (only if vocation is clear):
- Liceo Classico (specific preparation)
- Liceo Musicale/Coreutico (requires talent)
- Vocational Enogastronomia (specific sector)
