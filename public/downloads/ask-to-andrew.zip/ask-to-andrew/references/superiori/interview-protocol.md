# Interview Protocol - High School (Ages 12-13)

## Principles for Ages 12-13

- Short sentences (<20 words)
- Concrete, everyday examples
- Friendly tone, not an interrogation
- Frequent validation ("Did I understand correctly that...")
- Pauses for processing
- Normalize: "You don't have to know what you want to do when you grow up already"

---

## Required Data (min 15)

1. Name, age, grade, city/province
2. Main subject grades (which are easy, which are hard)
3. Favorite subject (with reason)
4. Study style (books vs hands-on vs mixed)
5. Free time interests (at least 3 with depth)
6. Extracurricular activities
7. Perceived strengths ("what are you good at?")
8. Hobbies and passions
9. Geographic mobility (nearby or distant schools?)
10. Family expectations
11. Emotional state (anxiety 1-10)
12. Clarity level (I know what I want / some ideas / confused)
13. Preliminary ideas if any
14. Fears about the choice
15. Role models / admired people

---

## Questions by Area

### Area 1: Who You Are

**Q1**: "Hi! What's your name and what grade are you in? Where do you live?"

**Q2**: "How are you finding school? What do you like and what feels heavy?"

**Q3**: "Have you ever thought about how far from home you could go for high school?"
- Follow-up: "Would you be okay taking a train every day?"

### Area 2: Subjects and Study

**Q4**: "Which subjects come easiest to you? And which ones give you trouble?"
- Follow-up: "What makes [subject] easy/hard for you?"

**Q5**: "If you could study only ONE subject all day, which would you choose?"
- Ladder: "What do you like about that subject?"

**Q6**: "How do you usually study? Read and repeat, make diagrams, watch videos, do hands-on exercises...?"

**Q7**: "Do you prefer when things are explained from books or when you do them with your hands?"

### Area 3: Interests and Passions

**Q8**: "Imagine a free afternoon with no homework. What do you do?"
- Follow-up: "What do you like about [activity]?"

**Q9**: "Is there something that when you do it, you lose track of time?"
- Ladder: "Tell me about the last time that happened."

**Q10**: "Which YouTube channels or social media accounts do you follow most? What are they about?"

**Q11**: "Do you do any activities outside of school? Sports, music, volunteering...?"
- Follow-up: "What does that activity give you?"

### Area 4: Strengths

**Q12**: "What do your friends ask you for help with?"

**Q13**: "What do people say you're good at?"

**Q14**: "Tell me about a time when you solved a difficult problem."
- Follow-up: "How did you manage it?"

### Area 5: Family and Context

**Q15**: "What do your parents think about choosing a school? Do they leave you free or do they have specific ideas?"
- Follow-up if pressure: "How do you feel about that?"

**Q16**: "Are there practical things to keep in mind? For example, do you need to stay close to home for some reason?"

### Area 6: Emotional State

**Q17**: "From 1 to 10, how worried are you about this choice?"
- If >7: "What worries you most?"
- If <3: "How come you're so relaxed?"

**Q18**: "If you had to choose: you know exactly what you want / you have some ideas / you're confused / you haven't thought about it yet?"

**Q19**: "What's your biggest fear related to this choice?"

### Area 7: Aspirations

**Q20**: "If you could do ANY job when you grow up, with no limits, what would you choose?"
- Follow-up: "What attracts you about that job?"

**Q21**: "Is there someone you admire for their work or their life?"
- Follow-up: "What do you like about that person?"

---

## Projective Scenarios (for indirect RIASEC profiling)

### Class Project Scenario

"Imagine your class has to organize a party. Would you prefer to:
- Organize everything and tell others what to do
- Manage the budget and accounts
- Create the decorations and graphics
- Welcome people and be the point of contact
- Set up audio, lights, and fix technical issues
- Convince people to come and promote the event"

Follow-up: "Why that role?"

### Superpower Scenario

"If you could have one superpower for a day:
- Speak every language in the world
- Instantly solve any math problem
- Create beautiful works of art with a thought
- Understand what people are feeling
- Convince anyone of anything
- Repair any machine"

Follow-up: "What would you do with that power?"

---

## Summary and Verification

At the end, provide a brief summary:

"Let me check if I got it right:

**Who you are**: [2-3 characteristics]
**What you like**: [top 3 interests]
**Strengths**: [top 2 skills]
**What matters to you**: [main value]
**How you feel**: [emotional state]

Does this sound right? Anything to add or correct?"

---

## Transition to RIASEC Test

"Great! Now I'll ask you 30 quick questions to better understand what kind of activities you enjoy. It'll take about 10 minutes. For each one, tell me from 1 to 5 how much it describes you. Ready?"
