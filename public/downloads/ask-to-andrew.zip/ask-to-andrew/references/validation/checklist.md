# Validation Checklist - Pre-Output Quality Control

## Objective

MANDATORY checklist before generating the final report. Every checkbox must be verified:
if even ONE fails, STOP and complete the missing analysis.

**Principle**: Better a report that's 10 minutes late and complete, than one that's fast but shallow.

---

## SECTION 0: BRANCH IDENTIFICATION

- [ ] **BRANCH-001**: Branch correctly identified at the start of conversation
  - Branch A = High School (Scuole Superiori) (student ages 12-13, 8th/9th grade)
  - Branch B = University/Post-Diploma (student ages 17-18, 12th/13th grade)

- [ ] **BRANCH-002**: Correct reference files loaded for the branch
  - Branch A: references/superiori/*
  - Branch B: references/universita/*

---

## SECTION 1: DATA COLLECTION VALIDATION

### 1.1 Information Quantity

| Checkpoint | Branch A | Branch B |
|------------|----------|----------|
| MIN-001 | >=15 key data points | >=20 key data points |
| MIN-002 | >=16 exchanges (8+8) | >=20 exchanges (10+10) |

**Details:**

- [ ] **MIN-001-A** (Branch A): Collected >=15 key data points
  - Demographics, grade averages, study style, interests (>=3), skills, family context, mobility, emotional state

- [ ] **MIN-001-B** (Branch B): Collected >=20 key data points
  - As above + PCTO, languages/certifications, values ranking, budget, risk tolerance, timeline, Plan B, gap year

- [ ] **MIN-002**: Conversation with sufficient exchanges
  - **If fails**: Conversation too shallow, go deeper

### 1.2 Information Quality

- [ ] **QUAL-001**: Identified >=5 specific interests (not "I like everything")
  - Example PASS: "I like programming in Python because I enjoy creating things"
  - Example FAIL: "I like technology"
  - **If fails**: Use ladder questioning

- [ ] **QUAL-002**: For at least 3 interests, deep motivation understood (answered "why?")

- [ ] **QUAL-003**: Collected information on >=5 subjects (grades or assessments)

- [ ] **QUAL-004**: Understood learning style (theoretical/practical, individual/social)

### 1.3 Branch A Specific Checkpoints (High School)

- [ ] **QUAL-A01**: Verified middle school performance (indicative grades)
- [ ] **QUAL-A02**: Explored free time interests (not just academic)
- [ ] **QUAL-A03**: Verified family expectations and pressures
- [ ] **QUAL-A04**: Assessed decision-making maturity level

### 1.4 Branch B Specific Checkpoints (University)

- [ ] **QUAL-B01**: Collected PCTO/internship data (sector, duration, feedback)
- [ ] **QUAL-B02**: Work values ranking (7 items ordered)
- [ ] **QUAL-B03**: Family budget made explicit (scholarship/off-campus/constraints)
- [ ] **QUAL-B04**: Risk tolerance assessed (competitive admission?)
- [ ] **QUAL-B05**: Explicit Plan B declared
- [ ] **QUAL-B06**: Gap year explored (considered? for what purpose?)

### 1.5 Information Coherence

- [ ] **COER-001**: Coherence between preferred subjects - interests - activities (15% tolerance)
- [ ] **COER-002**: Coherence between performance - declared aptitudes
- [ ] **COER-003**: Coherence between age - grade attended (range +/-1 year)

---

## SECTION 2: RIASEC PROFILE VALIDATION

### 2.1 Test Completeness

- [ ] **RIAS-001**: All 30 items administered (5 per type)
  - ZERO exceptions

- [ ] **RIAS-002**: Every item with response 1-5 (no "dunno" or "not sure")
  - If student uncertain: encourage instinctive response

- [ ] **RIAS-003**: All 6 normalized scores calculated 0-100
  - Formula: ((sum_of_5_items - 5) / 20) * 100

### 2.2 Correct Language Version

- [ ] **RIAS-LANG-A** (Branch A): "Junior" version used (simple language)
- [ ] **RIAS-LANG-B** (Branch B): "Senior" version used (professional language)

### 2.3 Profile Validity

- [ ] **RIAS-004**: Profile has >=2 dominant types >60 OR 1 type >85
  - **If flat profile**: Follow "Flat Profile" protocol in riasec-framework.md

- [ ] **RIAS-005**: RIASEC - declared interests coherence (15% tolerance)
  - If "I love drawing" -> A should be >60
  - If "I love math" -> I should be >60

- [ ] **RIAS-006**: RIASEC - extracurricular activities coherence

### 2.4 Transferable Skills

- [ ] **SOFT-001**: All 9 skills assessed (scale 1-10)
  - Problem solving, Critical thinking, Creativity, Communication, Teamwork, Leadership, Time management, Adaptability, Emotional intelligence

- [ ] **SOFT-002**: For at least 5 skills, STAR example collected

- [ ] **SOFT-003**: Soft skills - RIASEC profile coherence
  - E.g.: S high (>80) but EI low (<4) -> INVESTIGATE

---

## SECTION 3: RECOMMENDATIONS VALIDATION

### 3.1 Selection Process

- [ ] **REC-001**: Analyzed >=8 candidate pathways before selecting top 3-5

- [ ] **REC-002**: Affinity score calculated across 7 dimensions for each pathway
  - RIASEC (40%) + Interests (20%) + Skills (20%) + Market (10%) + Logistics (10%) + Performance (5%) + Values (5%)

- [ ] **REC-003**: Explicit affinity breakdown for pathway #1

- [ ] **REC-004**: If top-3 all in the same category, diversified alternative included if score >=65

### 3.2 Argumentation Quality

- [ ] **ARG-001**: Each recommendation has >=4 specific arguments
  - PASS: "Leverages your interest in biology through 6h/week microscopy lab"
  - FAIL: "It suits you because you like science"

- [ ] **ARG-002**: Each recommendation connects:
  - At least 2 RIASEC types -> Pathway characteristics
  - At least 2 specific interests -> Subjects/activities
  - At least 1 skill -> Teaching methodology

- [ ] **ARG-003**: Each recommendation includes >=3 realistic risks/difficulties

### 3.3 Branch A Specific Checkpoints (High School)

- [ ] **REC-A01**: Estimated study workload indicated (hours/week)
- [ ] **REC-A02**: Key subjects clearly described
- [ ] **REC-A03**: Future flexibility (post-diploma outcomes) explained
- [ ] **REC-A04**: Local school availability verified (or declared "check on...")

### 3.4 Branch B Specific Checkpoints (University)

- [ ] **REC-B01**: Job market data included (trend, employment %, salary)
- [ ] **REC-B02**: Explicit University vs ITS comparison (if ITS relevant)
- [ ] **REC-B03**: Admission requirements specified (test, competitive, dates)
- [ ] **REC-B04**: Estimated costs for the student's ISEE bracket
- [ ] **REC-B05**: Available scholarships indicated (EDISU, merit)
- [ ] **REC-B06**: Recommended universities with rationale (ranking, specific strength)

### 3.5 Job Market Data (Primarily Branch B)

- [ ] **MERC-001**: For each pathway, data from >=2 sources
  - Sources: mercato-lavoro.md + ISTAT/Almalaurea/Excelsior

- [ ] **MERC-002**: For each pathway, >=5 outcomes with trend
  - Trend: strong growth / growth / stable / decline / strong decline

- [ ] **MERC-003**: Quantitative employability data (% at 1/3/5 years)

### 3.6 Logistics and Accessibility

- [ ] **LOG-001**: Pathway availability in the area verified
  - If info unavailable: DECLARE "Check on [official source]"
  - NEVER invent school/institution names

- [ ] **LOG-002**: If relocation required, compatibility with student's mobility

- [ ] **LOG-003**: If severe financial constraints, estimated costs + scholarships indicated

- [ ] **LOG-004**: If competitive admission, estimated admission probability
  - If probability <50%: WARNING + Plan B

---

## SECTION 4: OUTPUT VALIDATION

### 4.1 Structure and Completeness

- [ ] **OUT-001**: Output follows template (output-template.md for the branch)

- [ ] **OUT-002**: All sub-sections present for each pathway:
  - Why it suits you (Branch A: 150-200 words, Branch B: 200-300 words)
  - What you'll study (Branch A: 100-150 words, Branch B: 150-200 words)
  - Future prospects (Branch A: 100-150 words, Branch B: 200-250 words)
  - Logistics (100-150 words)
  - Confidence score
  - Next steps (>=4 actions)

- [ ] **OUT-003**: Personalized profile narrative (student recognizes themselves)
  - FAIL: "You're a curious student with many interests"
  - PASS: "You're fascinated by applied math and love building concrete things"

### 4.2 Output Length

| Branch | Target | Minimum | Maximum |
|--------|--------|---------|---------|
| A (High School) | ~2000 words | 1500 | 2500 |
| B (University) | ~3500 words | 3000 | 4500 |

- [ ] **OUT-LEN**: Output length in the correct range for the branch

### 4.3 Language and Tone

- [ ] **LANG-001**: Language adapted to age
  - Branch A (12-13): Short sentences (<15 words), concrete examples, zero jargon
  - Branch B (17-18): Mature language, concrete data, accountability

- [ ] **LANG-002**: Balanced tone (empathetic not condescending)
  - Avoid: "Awesome!", "You're special!", paternalism
  - Prefer: "Your interests indicate...", "Worth considering..."

- [ ] **LANG-003**: Zero unexplained jargon (STEM, AFAM, ITS, PCTO)

- [ ] **LANG-004**: Emoji only for standard indicators
  - Allowed: confidence, market trends

### 4.4 Bias and Inclusivity

- [ ] **BIAS-001**: Absence of gender bias
- [ ] **BIAS-002**: Absence of socioeconomic bias
- [ ] **BIAS-003**: Absence of geographic bias
- [ ] **BIAS-004**: If SEN/SLD, accessibility considered

### 4.5 Transparency

- [ ] **TRASP-001**: Recommendation limitations declared
- [ ] **TRASP-002**: Missing/outdated data declared
- [ ] **TRASP-003**: If confidence MEDIUM/LOW, explained why
- [ ] **TRASP-004**: Score breakdown shown for pathway #1

---

## SECTION 5: CONFIDENCE VALIDATION

### 5.1 Calculation

- [ ] **CONF-001**: Confidence calculated for each recommendation (not the same for all)

- [ ] **CONF-002**: Penalizing factors considered:
  - Incomplete data (<15 Branch A / <20 Branch B): -20pts
  - Poorly defined RIASEC profile (max <70): -15pts
  - Dimension incoherence (|R_match - I_match| >30): -10pts
  - Critical logistics (L_match <50): -15pts
  - Age <=13 (Branch A automatic): -10pts
  - Outdated market data: -10pts

- [ ] **CONF-003**: Correct mapping:
  - >=75 -> HIGH
  - 50-74 -> MEDIUM
  - <50 -> LOW

### 5.2 Actions for LOW Confidence

- [ ] **CONF-LOW-001**: If any recommendation is LOW:
  - Explain causes
  - Indicate actions to increase it
  - If + high anxiety: suggest human counselor

---

## SECTION 6: RESOURCES AND ACTIONS

### 6.1 Next Steps

- [ ] **STEP-001**: For each pathway, >=4 CONCRETE next steps
  - PASS: "Attend the open day at Liceo Volta on January 18 (register at...)"
  - FAIL: "Look into schools in your area"

- [ ] **STEP-002**: Diversified next steps:
  - >=1 field experience (open day, PCTO)
  - >=1 online resource (school website, video)
  - >=1 human interaction (professional, students)
  - >=1 self-test (simulation, project)

### 6.2 Branch A Checkpoints (High School)

- [ ] **RES-A01**: UNICA MIM platform mentioned
- [ ] **RES-A02**: Open day calendar suggested
- [ ] **RES-A03**: Parents output included (if requested)

### 6.3 Branch B Checkpoints (University)

- [ ] **RES-B01**: University portals cited (Universitaly, Almalaurea)
- [ ] **RES-B02**: Personalized decision timeline included
- [ ] **RES-B03**: Explicit Plan B in dedicated section
- [ ] **RES-B04**: If financial constraints, scholarship sources indicated

---

## SECTION 7: FOLLOW-UP

- [ ] **FOLL-001**: Suggested when to reconnect
  - Branch A: "After visiting 2-3 schools (by February)"
  - Branch B: "After university open days / test results"

- [ ] **FOLL-002**: Explained what to bring to the follow-up

- [ ] **FEEDB-001**: Asked if student recognizes themselves in the profile

- [ ] **FEEDB-002**: Encouraged dialogue for refinement

---

## SECTION 8: RED FLAGS

### 8.1 Critical Situations

If ANY of the following, MANDATORY to refer to professional support:

- [ ] **RED-001**: Anxiety >8/10 + somatic symptoms -> Psychologist

- [ ] **RED-002**: Coercive family pressure -> School mediator

- [ ] **RED-003**: Signs of depression (apathy, absence of interests) -> Psychological support

- [ ] **RED-004**: Severe identity conflict -> Support services

- [ ] **RED-005**: Severe unaddressed SEN/SLD -> Certification activation

### 8.2 Branch A Checkpoint: Unrealistic Aspirations

- [ ] **RED-A01**: If unrealistic declared aspiration (YouTuber, TikToker, influencer):
  - "Dream vs Reality" protocol applied (faq-superiori.md)
  - RIASEC coherence test performed
  - Objective data provided without crushing dreams
  - Pathway keeping options open suggested
  - Explicit Plan B included

### 8.3 Red Flag Reporting Template

If red flag present, include:

"**Important note**: From our conversations, elements emerge that could
benefit from professional human support. I suggest speaking with
[school psychologist / counselor / guidance professional] about [specific reason].
This doesn't mean something is wrong with you, but that you deserve
deeper support than what I can offer."

---

## SECTION 9: FINAL PRE-SEND CHECKLIST

### 9.1 Global Verification

Answer YES/NO before sending:

- [ ] **FINAL-001**: Sequential workflow followed (Phase 0 -> 1 -> 2 -> 3 -> 4 -> 5)?
- [ ] **FINAL-002**: Correct branch identified and files loaded?
- [ ] **FINAL-003**: Sufficient information collected (Branch A: >=15, Branch B: >=20)?
- [ ] **FINAL-004**: Recommendations backed by specific data?
- [ ] **FINAL-005**: All sections 1-8 checkpoints verified?
- [ ] **FINAL-006**: Age-appropriate language?
- [ ] **FINAL-007**: Limitations and uncertainties highlighted?
- [ ] **FINAL-008**: Concrete actions provided (not just theory)?
- [ ] **FINAL-009**: Red flags handled (if present)?
- [ ] **FINAL-010**: Output length in the correct range for the branch?

**IF EVEN ONE ANSWER IS "NO" -> STOP AND FIX.**

### 9.2 Quality Self-Assessment

| Criterion | Score 1-5 | Notes |
|-----------|-----------|-------|
| Data completeness | __ / 5 | All necessary info? |
| Methodological rigor | __ / 5 | Protocols followed? |
| Personalization | __ / 5 | Generic or tailored output? |
| Age appropriateness | __ / 5 | Language appropriate? |
| Transparency | __ / 5 | Calculations and limits explicit? |
| Actionability | __ / 5 | Student knows what to do next? |

**Minimum acceptable score: 24/30**

**If <24/30**: Identify weak areas and improve.

---

## Checkpoint Summary by Branch

### Branch A (High School) - Specific Checkpoints

| ID | Description |
|----|-------------|
| QUAL-A01 | Middle school performance |
| QUAL-A02 | Free time interests |
| QUAL-A03 | Family expectations |
| QUAL-A04 | Decision-making maturity |
| REC-A01 | Estimated study workload |
| REC-A02 | Key subjects |
| REC-A03 | Future flexibility |
| REC-A04 | Local schools |
| RES-A01 | UNICA platform |
| RES-A02 | Open day calendar |
| RES-A03 | Parents output |
| RED-A01 | Unrealistic aspirations |

### Branch B (University) - Specific Checkpoints

| ID | Description |
|----|-------------|
| QUAL-B01 | PCTO data |
| QUAL-B02 | Values ranking |
| QUAL-B03 | Family budget |
| QUAL-B04 | Risk tolerance |
| QUAL-B05 | Explicit Plan B |
| QUAL-B06 | Gap year |
| REC-B01 | Job market data |
| REC-B02 | Uni vs ITS comparison |
| REC-B03 | Admission requirements |
| REC-B04 | Estimated costs |
| REC-B05 | Scholarships |
| REC-B06 | Recommended universities |
| RES-B01 | University portals |
| RES-B02 | Decision timeline |
| RES-B03 | Plan B section |
| RES-B04 | Scholarship sources |

---

**REMEMBER: This checklist is your quality guarantee. Use it always, without exceptions.**
