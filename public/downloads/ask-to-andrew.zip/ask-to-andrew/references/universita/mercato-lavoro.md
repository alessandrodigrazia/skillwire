# Job Market Trends 2025-2030

## Data Sources

- ISTAT, Unioncamere Excelsior, Almalaurea
- World Economic Forum - Future of Jobs
- ANPAL, OECD Employment Outlook

---

## Professions in Strong Growth (+15%+)

### Tech & Digital

| Profession | Trend | Entry Salary | Senior |
|------------|-------|--------------|--------|
| AI/ML Specialist | +45% | 45-80k | 80-150k |
| Data Scientist | +38% | 35-60k | 60-100k |
| Cybersecurity | +40% | 40-65k | 70-120k |
| Cloud Architect | +35% | 40-70k | 70-110k |
| Full-stack Developer | +30% | 30-50k | 50-90k |

**Education**: Computer Science/Engineering degree or ITS ICT + certifications

### Green Economy

| Profession | Trend | Entry Salary | Senior |
|------------|-------|--------------|--------|
| Renewable Energy Engineer | +42% | 35-55k | 60-95k |
| ESG/Sustainability Manager | +38% | 35-55k | 60-100k |
| Solar Panel Technician | +40% | 28-45k | - |

**Education**: Energy/Environmental Engineering, ITS Energy Efficiency

### Healthcare

| Profession | Trend | Entry Salary | Senior |
|------------|-------|--------------|--------|
| Nurses | +25% | 25-35k | 35-45k |
| Biotechnologists | +28% | 28-45k | 50-80k |
| Physiotherapists | +15% | 25-40k | 40-55k |

### Digital Marketing

| Profession | Trend | Entry Salary | Senior |
|------------|-------|--------------|--------|
| Digital Marketing Specialist | +32% | 25-40k | 45-75k |
| E-commerce Manager | +30% | 30-50k | 55-90k |
| Growth Hacker | +35% | 28-45k | 50-80k |

---

## Stable Professions (+/-5%)

| Profession | Trend | Notes |
|------------|-------|-------|
| Medical Specialists | Stable | High demand but competitive admission |
| Pharmacists | Stable | Saturation in some areas |
| Accountants | Stable | Digitalization changing tasks |
| Teachers | +8% | Retirement turnover |
| Specialized Craftspeople | +5% | Shortage in some specializations |

---

## Declining Professions

| Profession | Trend | Cause |
|------------|-------|-------|
| Data Entry | -12% | RPA automation |
| Basic Call Center | -18% | AI chatbots |
| Cashiers | -15% | Self-checkout |
| Traditional Travel Agents | -20% | Online booking |
| Routine Assembly Workers | -25% | Robotics |
| Generalist Translators | -22% | AI translation |

---

## Most In-Demand Skills

### Top 10 Soft Skills

1. Analytical thinking and innovation
2. Continuous learning
3. Creativity and initiative
4. Digital literacy
5. Critical thinking
6. Complex problem solving
7. Leadership
8. Emotional intelligence
9. Resilience and flexibility
10. Effective communication

### Emerging Hard Skills

**Digital**:
- Python, SQL, R
- Cloud (AWS, Azure, GCP)
- Cybersecurity
- UX/UI Design
- Marketing automation
- AI/ML literacy

**Green**:
- LCA (Life Cycle Assessment)
- EU regulations (CSRD, Taxonomy)
- Circular economy

**Cross-cutting**:
- Agile project management
- Data visualization
- BIM (construction)

---

## Expanding Sectors

| Sector | Growth 2025-2030 |
|--------|-------------------|
| Tech/AI/Cybersecurity | +35% |
| Renewable Energy | +40% |
| Healthcare/Telemedicine | +25% |
| E-commerce/Logistics | +28% |
| ESG Consulting | +35% |
| Gaming/Entertainment | +30% |
| Fintech | +32% |

## Contracting Sectors

| Sector | Decline |
|--------|---------|
| Traditional Retail | -10% |
| Print Publishing | -15% |
| Low-tech Manufacturing | -12% |
| Banks (branches) | -18% |

---

## Supply-Demand Gap (Hard to Find)

| Profession | % Companies with Difficulty |
|------------|---------------------------|
| Cybersecurity | 55% |
| Data Analyst | 50% |
| Developers | 48% |
| ICT Technicians | 45% |
| Engineers | 42% |
| Nurses | 40% |
| Systems Technicians | 38% |

**Implication**: These profiles have greater bargaining power and easier job placement.

---

## AI and Automation Impact

### Automatable Tasks

| Work Type | % Automatable |
|-----------|--------------|
| Routine manual | 60-80% |
| Routine cognitive | 50-70% |
| Non-routine manual | 20-30% |
| Non-routine cognitive | 10-25% |

### Hard-to-Automate Skills

- Strategic creativity
- Empathy and emotional intelligence
- Complex negotiation
- Ethical leadership
- Problem solving in novel contexts
- Moral judgment

---

## Italian Employment Geography

### Top Regions for Qualified Work

1. **Lombardia** (Milan): Tech, Finance, Consulting
2. **Lazio** (Rome): Public Admin, Consulting, Tech
3. **Emilia-Romagna**: Mechanics, Automotive, Food
4. **Veneto**: Manufacturing 4.0, Fashion
5. **Piemonte** (Turin): Automotive, Aerospace

### Smart Working

+35% remote positions 2025 vs 2019
Expands geographic opportunities for digital jobs

---

## Usage for Affinity Scoring

To calculate M_match (Job market):

1. Identify career outcomes for the pathway
2. Assign trend score:
   - Strong growth: 100
   - Growth: 80
   - Stable: 60
   - Decline: 40
   - Strong decline: 20
3. Consider employment rate:
   - High (>80%): 100
   - Medium (60-80%): 70
   - Low (<60%): 40
4. Weighted average by outcome probability
