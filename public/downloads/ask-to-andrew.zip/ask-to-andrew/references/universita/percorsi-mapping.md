# Post-Diploma Pathway Mapping

## Main Options

1. **University** (3+2 or single cycle)
2. **ITS Academy** (2 years)
3. **AFAM** (Academies, Conservatories)
4. **Direct employment** (with diploma)

---

## UNIVERSITY

### System

- Bachelor's Degree (Laurea Triennale): 3 years, 180 CFU
- Master's Degree (Laurea Magistrale): 2 years, 120 CFU
- Single Cycle: 5-6 years (Medicine, Law, Architecture, Pharmacy)

### Annual Costs (public universities)

| ISEE | Tuition/year |
|------|------------|
| <13k | Full exemption |
| 13-20k | 0-500 euros |
| 20-40k | 500-2000 euros |
| >40k | 2000-3500 euros |

Out-of-town housing: 5000-10000 euros/year (varies by city)

---

### STEM AREA

#### Engineering

| Specialization | RIASEC | Employment 3y | Entry Salary |
|---------------|--------|---------------|-------------|
| Computer Science | R:70 I:90 C:75 | 88% | 30-38k |
| Management | I:80 E:75 C:80 | 85% | 28-35k |
| Mechanical | R:85 I:85 C:70 | 82% | 27-33k |
| Electronics | R:80 I:90 C:75 | 85% | 28-35k |
| Civil | R:75 I:80 C:70 | 78% | 25-32k |
| Biomedical | I:90 S:60 R:65 | 80% | 26-33k |
| Energy | I:85 R:75 C:70 | 82% | 28-35k |
| Aerospace | I:95 R:80 C:75 | 82% | 30-38k |

**Admission**: TOLC-I/E test, locally programmed enrollment
**Difficulty**: 5/5
**Market trend**: Strong growth (especially computer science, energy)

#### Computer Science and Data Science

| Aspect | Detail |
|--------|--------|
| **RIASEC** | R:60 I:95 A:40 C:80 |
| **Duration** | 3+2 |
| **Admission** | TOLC-I, programmed or open (varies by university) |
| **Employment 3y** | 85% |
| **Entry salary** | 28-38k |
| **Trend** | Strong growth (+35%) |
| **Outcomes** | Developer, Data Scientist, ML Engineer, System Admin |

#### Mathematics, Physics, Chemistry

| Course | RIASEC | Employment 3y | Salary |
|--------|--------|---------------|--------|
| Mathematics | I:95 C:80 A:50 | 78% | 25-32k |
| Physics | I:95 R:70 A:55 | 80% | 26-35k |
| Chemistry | I:90 R:75 C:70 | 75% | 24-30k |

**Note**: Often requires master's/PhD continuation for better outcomes.

#### Biological Sciences and Biotechnology

| Aspect | Detail |
|--------|--------|
| **RIASEC** | I:90 R:70 S:50 C:65 |
| **Admission** | TOLC-B, often programmed enrollment |
| **Employment 3y** | 68% (bachelor's), 78% (master's) |
| **Entry salary** | 22-28k (bachelor's), 26-35k (master's) |
| **Trend** | Growth (+28% biotech) |
| **Outcomes** | Researcher, Lab Technician, Quality Control, Pharma |

---

### MEDICAL-HEALTH AREA

#### Medicine and Surgery

| Aspect | Detail |
|--------|--------|
| **RIASEC** | I:90 S:85 R:60 C:70 |
| **Duration** | 6 years + specialization (4-6 years) |
| **Admission** | National test TOLC-MED, competitive (approx. 17k spots) |
| **Employment** | 95% |
| **Salary** | 40k (resident), 60-100k+ (specialist) |
| **Admission difficulty** | 5/5 (ratio 1:5) |

#### Healthcare Professions

| Course | RIASEC | Employment 3y | Spots/year |
|--------|--------|---------------|------------|
| Nursing | S:90 R:70 C:60 | 92% | ~15k |
| Physiotherapy | S:85 R:80 I:60 | 88% | ~2k |
| Speech Therapy | S:90 I:70 A:55 | 85% | ~800 |
| Midwifery | S:90 R:70 C:65 | 90% | ~1k |
| Dietetics | S:80 I:75 C:65 | 80% | ~600 |

**Admission**: Test, national competitive enrollment
**Trend**: Strong growth (structural shortage)

#### Pharmacy

| Aspect | Detail |
|--------|--------|
| **RIASEC** | I:85 C:80 S:65 R:55 |
| **Duration** | 5 years single cycle |
| **Admission** | Open or programmed (varies) |
| **Employment** | 82% |
| **Salary** | 26-35k (employed), variable (owner) |

---

### ECONOMICS AND LAW AREA

#### Economics and Management

| Specialization | RIASEC | Employment | Salary |
|---------------|--------|------------|--------|
| Business | E:80 C:85 I:65 | 80% | 26-32k |
| Finance | I:80 C:85 E:75 | 82% | 28-38k |
| Marketing | E:85 A:65 S:70 | 78% | 25-30k |

**Admission**: TOLC-E, often programmed enrollment
**Trend**: Stable/moderate growth

#### Law

| Aspect | Detail |
|--------|--------|
| **RIASEC** | I:75 C:85 E:70 S:60 |
| **Duration** | 5 years single cycle + internship (18 months) + state exam |
| **Admission** | Open (most) |
| **Employment** | 72% at 5 years |
| **Salary** | 15-20k (internship), 30-50k (associate), 60k+ (senior) |
| **Note** | Saturated market for generalists; specializations growing (tech law, IP, ESG) |

---

### HUMANITIES AREA

#### Literature, Philosophy, History

| Aspect | Detail |
|--------|--------|
| **RIASEC** | I:80 A:75 S:60 C:55 |
| **Admission** | Generally open |
| **Employment 3y** | 55-65% |
| **Entry salary** | 18-25k |
| **Outcomes** | Teaching, publishing, communications, public administration |
| **Note** | Often requires master's + competitive exam for teaching |

#### Languages and Linguistic Mediation

| Aspect | Detail |
|--------|--------|
| **RIASEC** | A:75 S:80 E:60 I:55 |
| **Admission** | Test, often programmed enrollment |
| **Employment** | 68% |
| **Salary** | 20-28k |
| **Trend** | Stable (machine translation impacts generalists) |
| **Outcomes** | Specialized translation, international relations, tourism |

#### Psychology

| Aspect | Detail |
|--------|--------|
| **RIASEC** | S:90 I:80 A:50 C:60 |
| **Admission** | Programmed enrollment (many universities) |
| **Duration** | 3+2 + internship + state exam |
| **Employment** | 72% (master's) |
| **Salary** | 18-28k (employed), 25-50k (private practice) |
| **Trend** | Growth (+12%, increased attention to mental health) |

#### Education Sciences

| Aspect | Detail |
|--------|--------|
| **RIASEC** | S:95 A:55 I:60 C:50 |
| **Admission** | Programmed for Primary Education, open for others |
| **Employment** | 75% |
| **Salary** | 22-30k |
| **Outcomes** | Educator, teacher (with qualification), trainer |

---

### COMMUNICATIONS AND ARTS AREA

#### Communications Sciences

| Aspect | Detail |
|--------|--------|
| **RIASEC** | A:70 S:75 E:70 I:50 |
| **Admission** | Open or programmed |
| **Employment** | 65% |
| **Salary** | 20-28k |
| **Outcomes** | Social media, PR, journalism, marketing |

#### DAMS (Performing Arts, Music, Visual Arts)

| Aspect | Detail |
|--------|--------|
| **RIASEC** | A:90 S:65 I:55 E:50 |
| **Admission** | Generally open |
| **Employment** | 58% |
| **Salary** | 18-26k |
| **Outcomes** | Cultural production, events, communications, teaching |

#### Architecture

| Aspect | Detail |
|--------|--------|
| **RIASEC** | A:85 I:80 R:70 C:65 |
| **Duration** | 5 years single cycle |
| **Admission** | National test, competitive enrollment |
| **Employment** | 75% |
| **Salary** | 22-30k (entry), 35-60k (senior) |
| **Trend** | Moderate growth (PNRR, urban renewal) |

---

## ITS ACADEMY

### Characteristics

- Duration: 2 years (1800-2000 hours)
- Internship: 40-50% of hours in companies
- Costs: 0-1000 euros total (often free)
- Average employment: 85% at 12 months
- Faculty: 50%+ industry professionals

### Technology Areas

| Area | Profiles | RIASEC | Employment | Salary |
|------|---------|--------|------------|--------|
| ICT/Digital | Developer, Cloud, Cybersecurity | I:85 R:70 C:75 | 90% | 26-35k |
| Mechatronics | Industry 4.0 Technician, Automation | R:90 I:75 C:70 | 88% | 25-32k |
| Energy | Renewables Technician, Efficiency | R:85 I:75 C:65 | 85% | 26-33k |
| Made in Italy - Fashion | Fashion tech, Product manager | A:80 R:65 E:60 | 78% | 22-28k |
| Made in Italy - Food | Food innovation, Quality | R:75 I:70 S:60 | 80% | 22-28k |
| Mobility | Electric vehicles, Smart logistics | R:85 I:70 C:70 | 82% | 24-30k |
| Biotech | Biomedical technician, Pharma | I:85 R:70 C:75 | 80% | 24-30k |

### Advantages vs University

- Faster employment
- Paid internships
- Direct company contacts
- Nearly zero costs
- Practice > theory

### Disadvantages

- Less "prestigious" pathway (perception)
- Some careers require a degree by law
- Less developed alumni network
- Less international mobility

---

## AFAM (Higher Arts Education)

### Institutions

- Fine Arts Academies
- Music Conservatories
- Dance/Drama Academies
- ISIA (Design)

### Characteristics

| Aspect | Detail |
|--------|--------|
| **RIASEC** | A:95 R:60 S:55 |
| **Duration** | 3+2 (equivalent to university degree) |
| **Admission** | Practical aptitude test |
| **Costs** | 500-3000 euros/year |
| **Employment** | 55-70% (varies by sector) |
| **Outcomes** | Artists, musicians, designers, restorers |

---

## Quick Comparison

| Criterion | University | ITS | AFAM |
|-----------|------------|-----|------|
| Duration | 3-6 years | 2 years | 3-5 years |
| Costs | 0-3500+housing | 0-1000 | 500-3000 |
| Theory/Practice | 70/30 | 30/70 | 40/60 |
| Employment | 60-90% | 80-90% | 55-70% |
| Perceived prestige | High | Medium-growing | Niche |
| Regulated professions | Yes | Some | Some |
| Research/PhD | Yes | No | Limited |
