# FAQ and Special Cases - University/Post-Diploma

## Common Situations

### 1. Undecided Between University and ITS

**Scenario**: Student doesn't know whether to choose university or ITS.

**Strategy**:

1. **Explore deep motivations**:
   - "Why are you considering university? Passion, prestige, family expectations?"
   - "Why are you considering ITS? Practicality, quick employment, costs?"

2. **Objective comparison**:

| Choose UNIVERSITY if | Choose ITS if |
|---------------------|---------------|
| The profession requires a degree by law (doctor, psychologist, registered engineer) | Your goal is specialized work within 2 years |
| You want to pursue research/PhD | You prefer hands-on learning |
| You have time and resources for 3-5 years | You have financial/time constraints |
| You want facilitated international mobility | You want immediate contact with companies |

3. **Propose a hybrid pathway if undecided**:
   "You can do ITS and then possibly complete with a master's degree.
   ITS credits are recognizable (120 ECTS)."

### 2. I Won't Pass the Medical School Entrance Exam

**Scenario**: Student wants Medicine but high risk of not passing the test.

**Strategy**:

1. **Assess realism**:
   - Current grades in science/math
   - Has preparation already started?
   - Practice test scores?

2. **Structured Plan B**:

| Level | Option |
|-------|--------|
| Plan A | Medicine (try anyway) |
| Plan B1 | Healthcare professions (Nursing, Physiotherapy) - same field |
| Plan B2 | Biotechnology/Biology - then retry Medicine |
| Plan B3 | Veterinary Medicine/Pharmacy - still in health sector |

3. **Message**:
   "Not getting in on the first try is not a failure. Many doctors got in
   on their second or third attempt. The important thing is to have a plan
   while you retry."

### 3. Gap Year - Yes or No?

**Scenario**: Student considering a year off.

**Strategy**:

1. **Explore motivations**:
   - Post-diploma burnout? (legitimate, but watch out for losing momentum)
   - Indecision? (gap years rarely clarify things unless structured)
   - Specific experience? (work, volunteering, travel - ok if planned)

2. **Gap year YES if**:
   - Concrete plan (structured work, volunteering, specific course)
   - Clear goal (save for university, sector experience, language)
   - Family financially supportive

3. **Gap year NO if**:
   - Just "I want to rest" (risk of losing motivation)
   - No plan (a year goes by fast without accomplishing anything)
   - Financial pressure (better to start and work part-time)

4. **Alternative**: Part-time university or ITS with internship (work while studying)

### 4. Family Conflict Over Choice

**Scenario**: Student wants Literature, family insists on Economics.

**Strategy**:

1. **Validate emotions**:
   "It's frustrating to have aspirations different from your family's."

2. **Understand family concerns**:
   - Usually: financial security, employability
   - Often: lack of information about actual career outcomes

3. **Provide objective data**:
   - Show Almalaurea data on actual employment
   - Highlight pathways that combine interests + security
   - Example: "Literature + Communications Master = Marketing/PR (75% employment)"

4. **Propose compromise**:
   - Hybrid pathway (e.g., Economics with Communications specialization)
   - "Safe" degree + parallel pursuit of passion
   - Double degree if feasible

5. **If coercive pressure**:
   RED FLAG -> Mediation with counselor/psychologist

### 5. Competitive Admission Anxiety

**Scenario**: Student paralyzed by fear of not passing entrance tests.

**Strategy**:

1. **Normalize**:
   "Pre-test anxiety is physiological. 100% of students experience it."

2. **Put it in perspective**:
   - "The test doesn't define your value as a person"
   - "Not passing doesn't close all doors - there are valid alternatives"
   - "You can retry the following year"

3. **Practical techniques**:
   - Regular practice tests (desensitization)
   - Breathing exercises before the test
   - Focus on preparation, not on the result

4. **Explicit Plan B**:
   "If you don't pass, what will you do? Having a plan reduces the anxiety of 'what if I fail?'"

5. **If debilitating anxiety** (panic attacks, insomnia):
   RED FLAG -> Psychological support before the test

### 6. Switching After Enrollment

**Scenario**: First-year student realizes they made the wrong choice.

**Strategy**:

1. **Distinguish causes**:
   - Difficult subjects? (normal adjustment vs genuine mismatch)
   - Not interested in the content? (wrong choice)
   - Toxic environment? (university issue, not course issue)
   - Unmet expectations? (needed better research first)

2. **Optimal timing**:
   - **By December year 1**: Easy switch, credit recovery possible
   - **By March year 1**: Switch possible, some credits lost
   - **End of year 1**: Evaluate whether to complete the year + switch, or switch immediately

3. **Options**:
   - Switch courses within the same university (simplest, some exams recognized)
   - Switch universities (more complex, credits need evaluation)
   - Transfer to ITS (if you prefer practical)
   - Gap year + rethink

4. **Message**:
   "Switching is not failing. It's correcting course. Better now than after 3 years."

### 7. Severe Financial Constraints

**Scenario**: Family cannot support university costs away from home.

**Strategy**:

1. **Map free/low-cost options**:
   - Local university (zero housing costs)
   - ITS (often free + paid internships)
   - Accredited online universities (flexibility + work)

2. **Scholarships**:
   - EDISU regional (ISEE <23k: 5-7k/year scholarship + housing)
   - University merit-based scholarships
   - Merit colleges (free for excellent students)

3. **Work + study**:
   - Part-time student (work 20h/week)
   - Higher education apprenticeship (salary + degree)
   - Intensive summer work + savings

4. **ROI calculation**:
   "Investment: 5 years (20k euros total) vs expected salary (30k/year).
   You recover the investment in <2 years of work. That's a good ROI."

5. **Don't hide expensive options**:
   "Bocconi costs 12k/year. With a low ISEE, 90% scholarship. With part-time work, doable."

### 8. "I Know Everything Already" Student (Overconfident)

**Scenario**: Student convinced they already know what to do, refuses alternatives.

**Strategy**:

1. **Don't contradict head-on**:
   "Great that you have clear ideas. Let's do the full analysis anyway
   to confirm."

2. **Coherence test**:
   - Verify if RIASEC profile confirms declared aspiration
   - If discrepancy: "The test shows a different profile. How do you explain that?"

3. **Challenging questions**:
   - "What would you do if you couldn't pursue [choice]?"
   - "What would happen if after 2 years you realized it wasn't for you?"
   - "Have you spoken with people who've been doing that job for years? What did they say?"

4. **Mandatory Plan B**:
   "Even if you're sure, having a Plan B is smart, not a sign of weakness."

### 9. Immigrant Background Student

**Scenario**: First/second generation student with different family expectations.

**Strategy**:

1. **Explore cultural context**:
   "In your family's culture, which professions are most valued?"
   (Often: Medicine, Engineering, Law - high prestige in many cultures)

2. **Manage divergent expectations**:
   - If student aligns with family: support
   - If student in conflict: sensitive mediation, value autonomy

3. **Leverage intercultural skills**:
   "Your bilingual/bicultural background is an asset for international careers."

4. **Mind financial constraints**:
   - Immigrant families often face financial pressures
   - Prioritize fast, employable pathways if necessary

### 10. Total Confusion

**Scenario**: Student has no idea what to do, everything seems the same.

**Strategy**:

1. **Depression screening**:
   "How are you feeling in general? Do you have energy, motivation?"
   If suspected clinical apathy -> psychological support before guidance

2. **Elimination approach**:
   "You don't know what you want, but you know what you DON'T want. Let's eliminate together."
   - "Rule out scientific area?" Yes/No
   - "Rule out humanities area?" Yes/No
   - etc.

3. **Flexible pathways**:
   - Economics (wide range of outcomes)
   - Communications Sciences (cross-cutting)
   - Generalist ITS (work + figure out what you like)

4. **Exploratory plan**:
   "Choose a 'neutral' pathway for now. In the first 6 months:
   - Attend industry events
   - Do informational interviews with professionals
   - We'll reassess together"

---

## Frequently Asked Questions

**"University or straight to work?"**
It depends. If your desired profession requires a degree: university.
If you want rapid practical skills: ITS or work + training.
Statistics: graduates earn 30-40% more at equivalent positions.

**"Is ITS second-rate?"**
No. ITS programs have 85% employment, often higher than bachelor's degrees.
Perception is changing. Many companies prefer ITS graduates.

**"Can I change my mind later?"**
Yes. Switching between courses is possible (with some lost credits).
Switching to ITS is possible. Masters can redirect after a degree.

**"Competitive admission: what if I don't pass?"**
Options: retry (you can prepare better), Plan B (related course),
structured gap year, ITS in related sector.

**"Is studying abroad worth it?"**
It depends. UK/USA: very high costs. Erasmus: excellent and free.
Foreign degree: recognition must be verified for regulated professions.

**"Is online worth it?"**
For flexibility (you work, you have constraints): yes.
For networking and university life: no.
Verify the university is accredited (11 accredited online universities in Italy).

---

## Red Flags to Report

| Situation | Action |
|-----------|--------|
| Debilitating anxiety (panic, insomnia) | Psychologist |
| Coercive family pressure | School mediator |
| Depression / total apathy | Psychological support |
| Unrealistic idealization (e.g., "I'll be rich in 2 years") | Gentle reality check |
| Total refusal to consider alternatives | Explore resistance |
