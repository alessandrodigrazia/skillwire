# Interview Protocol - University/Post-Diploma (Ages 17-18)

## Principles for Ages 17-18

- Mature, direct language
- Concrete market data
- Acknowledge decision-making autonomy
- Focus on "what you want to become" (not just "what you like")
- Accountability for choices

---

## Required Data (min 20)

1. Type of high school (track, grade)
2. Expected diploma grade (voto maturita)
3. Key subject grades
4. PCTO/internship experiences (sector, feedback)
5. Technical skills acquired
6. Languages and certifications
7. Previous work experience
8. Professional interests (at least 3 with depth)
9. Work values (ranking of 7 items)
10. Geographic preference (local/national/international)
11. Available budget (family + scholarships)
12. Risk tolerance (competitive admission?)
13. Decision timeline (when deciding? tests taken?)
14. Explicit Plan B
15. Gap year (considered?)
16. Expected entry-level salary
17. Desired work-life balance
18. Categorically excluded sectors
19. Professional role models (admired people)
20. Emotional state (pressure, clarity)
21. Family support (financial, moral)

---

## Questions by Area

### Area 1: School Background

**Q1**: "What school are you in and what year? How's it going?"

**Q2**: "What grade do you expect on your diploma exam (maturita)? What are you aiming for?"

**Q3**: "Which subjects come easiest? Which are hardest? Why do you think?"

**Q4**: "Have you done PCTO or internships? In what sector? Did you enjoy it?"
- Follow-up: "What did you learn from that experience?"

**Q5**: "Have you acquired any particular technical skills? (languages, software, certifications)"

### Area 2: Experience and Skills

**Q6**: "Have you ever worked, even part-time or summer jobs? Doing what?"
- Follow-up: "What did you like/not like about that experience?"

**Q7**: "What would you say you're particularly good at?"
- Use STAR method: "Give me a concrete example of when you demonstrated [skill]."

**Q8**: "What are your areas for improvement?"

### Area 3: Professional Interests

**Q9**: "If you could do any job in 5 years, what would it be?"
- Ladder: "What exactly attracts you about that job?"

**Q10**: "Which sectors or areas interest you? (tech, healthcare, business, art, social...)"
- For each interest: "Why that area? What fascinates you?"

**Q11**: "Are there sectors you categorically rule out?"
- Follow-up: "Why do you rule them out?"

**Q12**: "Is there someone you admire for their work or career path?"
- Follow-up: "What do you like about that person?"

### Area 4: Values and Priorities

**Q13**: "Rank these in order of importance for you (1=most important, 7=least):
- Earning well
- Having security/stability
- Being creative/innovating
- Helping others/social impact
- Being independent/autonomous
- Being recognized/respected
- Having time for personal life"

**Q14**: "How much do you expect to earn at your first job? And after 10 years?"
- (Verify realism vs market expectations)

**Q15**: "Work-life balance: do you prefer an intense but well-paid job, or more humane rhythms with an average salary?"

### Area 5: Logistics and Constraints

**Q16**: "Would you be willing to relocate for studies? How far at most?"
- Options: same city / same region / Italy / abroad

**Q17**: "Are there financial constraints to keep in mind? (university costs, out-of-town rent)"
- Follow-up: "Have you looked into scholarships or working part-time?"

**Q18**: "How does your family feel about it? Do they support you financially and emotionally?"

### Area 6: Decision and Risk

**Q19**: "Would you be ready to face a competitive admission test?"
- Follow-up: "Have you already started preparing?"

**Q20**: "If you don't get into your first choice, what's your Plan B?"

**Q21**: "Have you considered a gap year? To do what?"

**Q22**: "Are you also considering ITS or direct employment, besides university?"

### Area 7: Emotional State

**Q23**: "From 1 to 10, how much pressure do you feel about this choice?"
- If >7: "What weighs on you most?"

**Q24**: "How clear do you feel about what you want to do?
- I know exactly what I want / I have 2-3 options / I'm confused"

**Q25**: "What's your biggest fear related to this choice?"

---

## Projective Scenarios (for values and preferences)

### Future Job Scenario

"Imagine two scenarios:
A) Prestigious job, 60k euros/year, but 55 hours/week, high stress
B) Normal job, 35k euros/year, 40 hours/week, time for yourself

Which do you prefer? Why?"

### Risk Scenario

"Imagine:
A) Try for Medicine (difficult competitive admission), with Plan B in Biotechnology
B) Go straight to Biotechnology (open admission, safe)

What would you choose? Why?"

### Geographic Scenario

"Perfect opportunity for you, but:
A) In Milan (800 euros/month rent, far from home)
B) In your city (less perfect job but close)

What matters more in your choice?"

---

## Summary and Verification

"Let me recap what I've understood:

**Background**: [school, grades, PCTO]
**Distinctive skills**: [top 3]
**Professional interests**: [top 3 areas]
**Priority values**: [top 3]
**Constraints**: [geographic, financial]
**Risk tolerance**: [high/medium/low]
**Current state**: [clarity, anxiety]

Does this sound right? Would you add anything?"

---

## Transition to RIASEC Test

"Now I'll ask you 30 questions to better define your professional profile.
For each one, indicate from 1 to 5 how much it describes you. It'll take 10 minutes."
