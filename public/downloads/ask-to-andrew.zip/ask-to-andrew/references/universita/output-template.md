# Output Template - University Guidance (Ages 17-18)

## Target Length

Report: ~3500-4000 words
Including Plan B and Timeline sections

---

## Report Structure

```
======================================
POST-DIPLOMA GUIDANCE REPORT
======================================

**Name**: [Name]
**Age**: [X] years | **Grade**: [grade] | **Track**: [school type]
**Date**: [dd/month/year]

---

## YOUR PROFILE

[Personalized narrative - 150-200 words]
[Mature language, concrete data, connection to career outcomes]

Example:
"Your profile shows a strong Investigative component (88/100) combined
with strong organizational abilities (C: 75). Your PCTO experience in [sector]
and your passion for [interest] indicate a clear orientation toward [area].
Your strengths - [skill 1] and [skill 2] - are aligned
with the most in-demand skills in the 2025-2030 job market.
Your priority for [value] and willingness to [mobility/risk]
open several concrete paths."

---

### RIASEC Holland Profile

**Code**: [e.g., I-C-R]

| Type | Score | Interpretation |
|------|-------|----------------|
| R Realistic | [X]/100 | [Level] - [Brief description] |
| I Investigative | [X]/100 | [Level] - [Brief description] |
| A Artistic | [X]/100 | [Level] - [Brief description] |
| S Social | [X]/100 | [Level] - [Brief description] |
| E Enterprising | [X]/100 | [Level] - [Brief description] |
| C Conventional | [X]/100 | [Level] - [Brief description] |

**Profile interpretation**: [100 words - connecting dominant types to outcomes]

---

### Distinctive Skills

| Skill | Score | Evidence |
|-------|-------|----------|
| [Top 1] | [X]/10 | [Concrete example from PCTO/experiences] |
| [Top 2] | [X]/10 | [Concrete example] |
| [Top 3] | [X]/10 | [Concrete example] |

**Market alignment**: These skills are among the most in-demand
in the 2025-2030 market, particularly for [sectors].

---

### Values and Priorities

| Value | Priority |
|-------|----------|
| [Value 1] | #1 |
| [Value 2] | #2 |
| [Value 3] | #3 |

---

## RECOMMENDED PATHWAYS

[Repeat for 3-5 pathways, including at least 1 ITS alternative if relevant]

======================================
### PATHWAY #1: [FULL NAME]
======================================

**Type**: [University / ITS / AFAM]
**Affinity**: [X]/100 | **Confidence**: [HIGH/MEDIUM/LOW]

---

#### WHY IT SUITS YOU

[200-300 words]

**RIASEC Match**:
[Connect RIASEC profile to pathway characteristics]
"Your I-C (Investigative-Conventional) profile finds ideal expression
in [pathway] where [explanation]..."

**Interest and PCTO Alignment**:
[Connect concrete experiences]
"Your PCTO experience in [sector] and your passion for [interest]
come together in [pathway subjects/projects]..."

**Skills Leverage**:
[Connect soft skills to teaching methods]

**Values Resonance**:
[Connect values to career outcomes]
"Your priority value [value] is fulfilled in typical outcomes
like [profession] where [explanation]..."

---

#### WHAT YOU'LL STUDY

**Study plan** (indicative):

*Year 1-2*:
- [Subject 1] - [brief description]
- [Subject 2] - [brief description]
- [Subject 3] - [brief description]

*Year 3 (+ master's if applicable)*:
- Available specializations: [list]

**Teaching approach**:
[Theory/practice %, labs, internships, thesis]

**Difficulty**: [X]/5 - [Comment]

---

#### CAREER OUTCOMES

**Main professions**:

| Profession | Trend | Employment | Entry Salary |
|------------|-------|------------|--------------|
| [Prof 1] | [indicator] | [X]% | [range]k |
| [Prof 2] | [indicator] | [X]% | [range]k |
| [Prof 3] | [indicator] | [X]% | [range]k |
| [Prof 4] | [indicator] | [X]% | [range]k |
| [Prof 5] | [indicator] | [X]% | [range]k |

**Hiring sectors**: [List 3-4 sectors]

**Market trends 2025-2030**:
[100 words - outlook analysis based on mercato-lavoro.md]

**Typical career progression**:
- Entry (0-3 years): [role, salary]
- Mid (3-7 years): [role, salary]
- Senior (7+ years): [role, salary]

---

#### ACCESS AND LOGISTICS

**Admission requirements**:
- Type: [National competitive / locally programmed / open access]
- Test: [TOLC-X / University test / None]
- Test dates: [period]
- Available spots: [if known]
- Admission difficulty: [X]/5

**Recommended universities**:
| University | City | Ranking | Notes |
|-----------|------|---------|-------|
| [Uni 1] | [City] | [position] | [key strength] |
| [Uni 2] | [City] | [position] | [key strength] |
| [Uni 3] | [City] | [position] | [key strength] |

**Estimated costs** (for you):
- Annual tuition: [range] euros (ISEE bracket [bracket])
- Housing (if away from home): [range] euros/year
- 3-year total: [range] euros

**Available scholarships**:
- EDISU [region]: [conditions]
- University merit-based: [conditions]
- Merit colleges: [if applicable]

---

#### NEXT STEPS

- [ ] **Test preparation** (if competitive admission):
      [Specific resources: books, courses, practice tests]
- [ ] **Open day/orientation**:
      Attend [university] open day ([dates if known])
- [ ] **Practice test**:
      Try the TOLC demo at [link]
- [ ] **Contact students**:
      Find Facebook/Telegram groups for [course] [university] students
- [ ] **Check scholarships**:
      Fill out the EDISU simulator for scholarship estimate

---

#### AFFINITY BREAKDOWN

```
TOTAL AFFINITY: [X]/100

- RIASEC Match: [X]/100 (40%) = [contribution]
- Interest Match: [X]/100 (20%) = [contribution]
- Skills Match: [X]/100 (20%) = [contribution]
- Market Match: [X]/100 (10%) = [contribution]
- Logistics Match: [X]/100 (10%) = [contribution]
- Performance Match: [X]/100 (5%) = [contribution]
- Values Match: [X]/100 (5%) = [contribution]

Confidence [indicator]: [Explanation if MEDIUM or LOW]
```

---

[END single pathway - repeat for #2, #3, etc.]

======================================
======================================

---

## EXPLICIT PLAN B

[Mandatory section]

**If the first choice doesn't work**:

| Scenario | Plan B | Rationale |
|----------|--------|-----------|
| Don't pass [course 1] test | [Alternative] | [Why it works] |
| Costs too high away from home | [Local/online alternative] | [How it's still valid] |
| After 1 year I realize it's not for me | [Switch/ITS option] | [Exit path] |

**"Bridge" pathway** (if uncertain between multiple areas):
[Suggest a flexible pathway that keeps multiple doors open]

---

## UNIVERSITY vs ITS COMPARISON

[If ITS is among considered options]

| Criterion | University [course] | ITS [course] |
|-----------|-------------------|-------------|
| Duration | [X] years | 2 years |
| Total costs | [range] euros | [range] euros |
| Employment | [X]% | [X]% |
| Entry salary | [range]k | [range]k |
| Internship | [X]% hours | 40-50% hours |
| Further studies | Yes | Limited |
| Regulated professions | [list] | [list] |

**Recommendation**: [Which to choose based on student profile]

---

## DECISION TIMELINE

[Personalize based on student situation]

```
[CURRENT MONTH] ───────────────────────────────────
                │
                v
[+1 month]   Attend open days (at least 2-3)
                │
                v
[+2 months]  Register for admission tests (if competitive)
                │
                v
[+3 months]  Intensive test preparation
                │
                v
[SUMMER]     Admission tests / Diploma exam (maturita)
                │
                v
[SEPTEMBER]  University enrollment
                │
                v
[OCTOBER]    Classes begin
```

**Key deadlines**:
- TOLC registration: [dates]
- National competitive admission registration: [dates]
- University enrollment: [dates]
- EDISU scholarships: [dates]

---

## FINAL THOUGHTS

**Remember**:

1. **These are projections, not certainties**. The market evolves,
   your interests may change. Stay flexible.

2. **The pathway doesn't define the career**. Many successful professionals
   changed direction after their degree.

3. **Educational investment**. Evaluate ROI: time + money invested
   vs outcomes and expected salaries.

4. **The choice is yours**. Parents, friends, society have opinions.
   But you're the one who'll live with the consequences. Choose with awareness.

5. **Plan B is not failure**. It's strategy. The best professionals
   always have alternatives.

[If red flags present]:
**Important note**: [Support referral]

---

## RESOURCES

**Guidance**:
- Universitaly.it - Italian course database
- Almalaurea.it - Employment statistics
- [Regional guidance portal]

**Test preparation**:
- [Specific resources for relevant tests]
- TOLC practice: [link]

**Scholarships**:
- EDISU [region]: [link]
- Merit colleges: [list]

**University comparison**:
- QS World University Rankings
- Censis university ranking

---

## FEEDBACK

**Does this report reflect who you are and what you want?**
Are there elements that don't convince you or that you'd like to explore further?

======================================
End of Report
======================================
```

---

## Style Notes

**For ages 17-18**:
- Mature and direct language
- Concrete data (salaries, %, rankings)
- Accountability for choices
- Focus on educational ROI
- Explicit options comparison

**Length**: 3500-4000 words (more extensive than high school version)
