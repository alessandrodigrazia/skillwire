#!/usr/bin/env python3
"""
N8N Workflow Search Tool
Search through 2054 workflows using metadata index
"""

import json
import sys
from pathlib import Path
import argparse

class WorkflowSearcher:
    def __init__(self, index_file):
        self.index_file = Path(index_file)
        self.metadata = self._load_index()

    def _load_index(self):
        """Load workflow metadata index"""
        if not self.index_file.exists():
            print(f"Error: Index file not found: {self.index_file}")
            sys.exit(1)

        with open(self.index_file, 'r', encoding='utf-8') as f:
            return json.load(f)

    def search(self, **criteria):
        """
        Search workflows by multiple criteria

        Args:
            pattern: Filter by key_patterns (e.g., "ai-agent")
            model: Filter by AI model (e.g., "gemini", "gpt-4o")
            node_type: Filter by node type (e.g., "gmail", "airtable")
            trigger: Filter by trigger type (e.g., "email", "webhook")
            complexity: Filter by complexity ("simple", "medium", "complex")
            has_ai: Filter AI-powered workflows (True/False)
            min_nodes: Minimum node count
            max_nodes: Maximum node count
            limit: Max results to return
        """
        results = self.metadata['workflows']

        # Filter by pattern
        if criteria.get('pattern'):
            pattern = criteria['pattern'].lower()
            results = [w for w in results if any(pattern in p.lower() for p in w.get('key_patterns', []))]

        # Filter by AI model
        if criteria.get('model'):
            model = criteria['model'].lower()
            results = [w for w in results if any(model in m.lower() for m in w.get('ai_models', []))]

        # Filter by node type
        if criteria.get('node_type'):
            node_type = criteria['node_type'].lower()
            results = [w for w in results if any(node_type in n.lower() for n in w.get('nodes_types', []))]

        # Filter by trigger type
        if criteria.get('trigger'):
            trigger = criteria['trigger'].lower()
            results = [w for w in results if trigger in [t.lower() for t in w.get('trigger_types', [])]]

        # Filter by complexity
        if criteria.get('complexity'):
            complexity = criteria['complexity'].lower()
            results = [w for w in results if w.get('complexity', '').lower() == complexity]

        # Filter by AI presence
        if criteria.get('has_ai') is not None:
            has_ai = criteria['has_ai']
            results = [w for w in results if w.get('has_ai') == has_ai]

        # Filter by node count
        if criteria.get('min_nodes'):
            min_nodes = int(criteria['min_nodes'])
            results = [w for w in results if w.get('nodes_count', 0) >= min_nodes]

        if criteria.get('max_nodes'):
            max_nodes = int(criteria['max_nodes'])
            results = [w for w in results if w.get('nodes_count', 0) <= max_nodes]

        # Limit results
        limit = criteria.get('limit', 10)
        if limit:
            results = results[:int(limit)]

        return results

    def format_results(self, results, verbose=False):
        """Format search results for display"""
        if not results:
            return "No workflows found matching criteria."

        output = []
        output.append(f"\n{'='*80}")
        output.append(f"Found {len(results)} workflow(s)")
        output.append(f"{'='*80}\n")

        for i, wf in enumerate(results, 1):
            output.append(f"{i}. {wf['name']}")
            output.append(f"   ID: {wf['id']}")
            output.append(f"   File: {wf['file_path']}")
            output.append(f"   Nodes: {wf['nodes_count']} | Complexity: {wf['complexity']}")

            if wf.get('has_ai'):
                models = ', '.join(wf.get('ai_models', [])[:3])
                if len(wf.get('ai_models', [])) > 3:
                    models += f" + {len(wf['ai_models']) - 3} more"
                output.append(f"   AI Models: {models}")

            if wf.get('key_patterns'):
                patterns = ', '.join(wf['key_patterns'])
                output.append(f"   Patterns: {patterns}")

            if verbose:
                output.append(f"   Trigger: {', '.join(wf.get('trigger_types', ['N/A']))}")
                output.append(f"   Category: {wf.get('category', 'N/A')}")

                # Show key nodes
                ai_nodes = [n for n in wf.get('nodes_types', []) if 'langchain' in n.lower()]
                if ai_nodes:
                    output.append(f"   AI Nodes: {', '.join(ai_nodes[:2])}")

            output.append("")

        return '\n'.join(output)

    def export_json(self, results, output_file):
        """Export results to JSON file"""
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        print(f"Results exported to: {output_file}")

def main():
    parser = argparse.ArgumentParser(
        description='Search N8N workflows by pattern, model, nodes, etc.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Find AI agent workflows
  python search-workflows.py --pattern ai-agent

  # Find Gemini workflows
  python search-workflows.py --model gemini --limit 5

  # Find simple Gmail automations
  python search-workflows.py --node-type gmail --complexity simple

  # Find email-triggered AI workflows
  python search-workflows.py --trigger email --has-ai

  # Find complex workflows with many nodes
  python search-workflows.py --min-nodes 10 --complexity complex

  # Export results to JSON
  python search-workflows.py --pattern structured-extraction --export results.json
        """
    )

    parser.add_argument('--index',
                       default='../references/index/workflow-metadata.json',
                       help='Path to workflow metadata index')
    parser.add_argument('--pattern', help='Filter by pattern (e.g., ai-agent, structured-extraction)')
    parser.add_argument('--model', help='Filter by AI model (e.g., gemini, gpt-4o)')
    parser.add_argument('--node-type', help='Filter by node type (e.g., gmail, airtable)')
    parser.add_argument('--trigger', help='Filter by trigger type (e.g., email, webhook, schedule)')
    parser.add_argument('--complexity', choices=['simple', 'medium', 'complex'],
                       help='Filter by complexity')
    parser.add_argument('--has-ai', action='store_true', help='Only AI-powered workflows')
    parser.add_argument('--min-nodes', type=int, help='Minimum node count')
    parser.add_argument('--max-nodes', type=int, help='Maximum node count')
    parser.add_argument('--limit', type=int, default=10, help='Max results (default: 10)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Show detailed info')
    parser.add_argument('--export', help='Export results to JSON file')

    args = parser.parse_args()

    # Build search criteria
    criteria = {}
    if args.pattern:
        criteria['pattern'] = args.pattern
    if args.model:
        criteria['model'] = args.model
    if args.node_type:
        criteria['node_type'] = args.node_type
    if args.trigger:
        criteria['trigger'] = args.trigger
    if args.complexity:
        criteria['complexity'] = args.complexity
    if args.has_ai:
        criteria['has_ai'] = True
    if args.min_nodes:
        criteria['min_nodes'] = args.min_nodes
    if args.max_nodes:
        criteria['max_nodes'] = args.max_nodes
    if args.limit:
        criteria['limit'] = args.limit

    # Execute search
    searcher = WorkflowSearcher(args.index)
    results = searcher.search(**criteria)

    # Display or export results
    if args.export:
        searcher.export_json(results, args.export)

    print(searcher.format_results(results, verbose=args.verbose))

    # Show summary stats
    if results:
        print(f"\nSearch Summary:")
        print(f"  Total matches: {len(results)}")

        ai_count = sum(1 for w in results if w.get('has_ai'))
        if ai_count > 0:
            print(f"  AI-powered: {ai_count}")

        # Show pattern distribution
        patterns = {}
        for w in results:
            for p in w.get('key_patterns', []):
                patterns[p] = patterns.get(p, 0) + 1

        if patterns:
            print(f"\n  Pattern Distribution:")
            for p, count in sorted(patterns.items(), key=lambda x: x[1], reverse=True)[:5]:
                print(f"    {p}: {count}")

if __name__ == '__main__':
    main()
