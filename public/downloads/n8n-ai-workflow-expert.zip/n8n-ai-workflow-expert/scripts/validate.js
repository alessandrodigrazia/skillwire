/**
 * @description Funzioni di validazione di base per un workflow n8n in formato JSON.
 * NOTA: Questo script è un artefatto concettuale. L'ambiente di esecuzione dell'AI 
 * dovrà fornire un modo per eseguire queste funzioni.
 */

/**
 * Trova i nodi che non sono collegati a nessun altro nodo (orfani).
 * @param {object} workflow - L'oggetto JSON del workflow parsato.
 * @returns {Array<string>} Un array di nomi di nodi orfani.
 */
function findOrphanedNodes(workflow) {
    if (!workflow.nodes || !workflow.connections) {
        return [];
    }

    const allNodeNames = new Set(workflow.nodes.map(n => n.name));
    const connectedNodes = new Set();

    for (const sourceName in workflow.connections) {
        connectedNodes.add(sourceName);
        const outputs = workflow.connections[sourceName];
        for (const outputType in outputs) {
            for (const connection of outputs[outputType]) {
                for (const target of connection) {
                    connectedNodes.add(target.node);
                }
            }
        }
    }

    const orphaned = [...allNodeNames].filter(name => !connectedNodes.has(name));
    return orphaned;
}

/**
 * Controlla i nodi che hanno credenziali mancanti o con placeholder.
 * @param {object} workflow - L'oggetto JSON del workflow parsato.
 * @returns {Array<{nodeName: string, credentialName: string, credentialId: string}>} Un array di credenziali mancanti.
 */
function checkMissingCredentials(workflow) {
    if (!workflow.nodes) {
        return [];
    }

    const missingCreds = [];

    for (const node of workflow.nodes) {
        if (node.credentials) {
            for (const credType in node.credentials) {
                const cred = node.credentials[credType];
                if (!cred.id || cred.id.includes('_PLACEHOLDER') || cred.id.includes('_CREDENTIAL_ID')) {
                    missingCreds.push({
                        nodeName: node.name,
                        credentialName: cred.name || credType,
                        credentialId: cred.id || 'Non presente'
                    });
                }
            }
        }
    }
    return missingCreds;
}

/**
 * Esegue una validazione completa del workflow.
 * @param {string} jsonString - La stringa JSON del workflow.
 * @returns {{isValid: boolean, issues: {orphans: Array<string>, missingCredentials: Array<object>}}} Il risultato della validazione.
 */
function validateWorkflow(jsonString) {
    let workflow;
    try {
        workflow = JSON.parse(jsonString);
    } catch (e) {
        return { isValid: false, issues: { error: `JSON non valido: ${e.message}` } };
    }

    const orphans = findOrphanedNodes(workflow);
    const missingCredentials = checkMissingCredentials(workflow);

    const issueCount = orphans.length + missingCredentials.length;

    return {
        isValid: issueCount === 0,
        issueCount: issueCount,
        issues: {
            orphans,
            missingCredentials
        }
    };
}

// Esempio di come potrebbe essere usato
/*
const workflowJson = `{
    "nodes": [
        { "name": "Start", "type": "n8n-nodes-base.manualTrigger" },
        { "name": "Send Email", "type": "n8n-nodes-base.gmail", "credentials": { "gmailOAuth2": { "id": "GMAIL_CREDENTIAL_ID" } } },
        { "name": "Orphaned Node", "type": "n8n-nodes-base.set" }
    ],
    "connections": {
        "Start": { "main": [[{ "node": "Send Email", "type": "main" }]] }
    }
}`.replace(/\n/g, '');

const validationResult = validateWorkflow(workflowJson);
console.log(JSON.stringify(validationResult, null, 2));
// Output atteso:
// {
//   "isValid": false,
//   "issueCount": 2,
//   "issues": {
//     "orphans": [ "Orphaned Node" ],
//     "missingCredentials": [
//       { "nodeName": "Send Email", "credentialName": "gmailOAuth2", "credentialId": "GMAIL_CREDENTIAL_ID" }
//     ]
//   }
// }
*/

module.exports = {
    validateWorkflow,
    findOrphanedNodes,
    checkMissingCredentials
};
