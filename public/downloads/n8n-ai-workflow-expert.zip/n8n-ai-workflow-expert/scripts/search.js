/**
 * @description Funzioni di ricerca per la knowledge base della skill N8N.
 * NOTA: Questo script è un artefatto concettuale. L'ambiente di esecuzione dell'AI 
 * dovrà fornire un modo per leggere il filesystem e eseguire queste funzioni.
 */

/**
 * Cerca una parola chiave o una frase in tutti i file Markdown nella directory di riferimento.
 * 
 * @param {object} fs - Un'implementazione del modulo filesystem (es. Node.js 'fs').
 * @param {object} path - Un'implementazione del modulo path (es. Node.js 'path').
 * @param {string} baseDir - La directory principale della skill.
 * @param {string} searchTerm - La parola o frase da cercare (case-insensitive).
 * @returns {Promise<Array<{file: string, line: number, text: string}>>} Un array di risultati.
 */
async function searchKnowledgeBase(fs, path, baseDir, searchTerm) {
    const referencesDir = path.join(baseDir, 'references');
    const results = [];
    const lowerCaseSearchTerm = searchTerm.toLowerCase();

    async function findInDir(directory) {
        const entries = await fs.promises.readdir(directory, { withFileTypes: true });
        for (const entry of entries) {
            const fullPath = path.join(directory, entry.name);
            if (entry.isDirectory()) {
                await findInDir(fullPath);
            } else if (entry.isFile() && entry.name.endsWith('.md')) {
                const fileContent = await fs.promises.readFile(fullPath, 'utf8');
                const lines = fileContent.split('\n');
                for (let i = 0; i < lines.length; i++) {
                    const line = lines[i];
                    if (line.toLowerCase().includes(lowerCaseSearchTerm)) {
                        results.push({
                            file: fullPath.replace(baseDir, ''), // Percorso relativo
                            line: i + 1,
                            text: line.trim()
                        });
                    }
                }
            }
        }
    }

    await findInDir(referencesDir);
    return results;
}

/**
 * Elenca tutti i template JSON disponibili.
 * 
 * @param {object} fs - Un'implementazione del modulo filesystem.
 * @param {object} path - Un'implementazione del modulo path.
 * @param {string} baseDir - La directory principale della skill.
 * @returns {Promise<Array<{category: string, name: string, path: string}>>} Un array di template.
 */
async function listTemplates(fs, path, baseDir) {
    const templatesDir = path.join(baseDir, 'assets', 'templates');
    const results = [];

    async function findInDir(directory, category) {
        const entries = await fs.promises.readdir(directory, { withFileTypes: true });
        for (const entry of entries) {
            const fullPath = path.join(directory, entry.name);
            if (entry.isDirectory()) {
                await findInDir(fullPath, entry.name);
            } else if (entry.isFile() && entry.name.endsWith('.json')) {
                results.push({
                    category: category,
                    name: entry.name.replace('.json', ''),
                    path: fullPath.replace(baseDir, '')
                });
            }
        }
    }

    await findInDir(templatesDir, null);
    return results;
}

// Esempio di come potrebbe essere usato in un ambiente Node.js
/*
const fs = require('fs');
const path = require('path');
const baseDir = __dirname; // Assumendo che lo script sia in /scripts

(async () => {
    console.log('--- Ricerca per "Rate Limit" ---');
    const searchResults = await searchKnowledgeBase(fs, path, path.join(baseDir, '..'), 'Rate Limit');
    console.log(searchResults);

    console.log('\n--- Elenco dei Template Disponibili ---');
    const templates = await listTemplates(fs, path, path.join(baseDir, '..'));
    console.log(templates);
})();
*/

module.exports = {
    searchKnowledgeBase,
    listTemplates
};
