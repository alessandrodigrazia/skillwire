#!/usr/bin/env python3
"""
N8N Workflow Analyzer
Estrae metadata, pattern e statistics da una collezione di workflow JSON
"""

import json
import os
from pathlib import Path
from collections import defaultdict, Counter
import re

class WorkflowAnalyzer:
    def __init__(self, workflows_dir, output_dir):
        self.workflows_dir = Path(workflows_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.workflows = []
        self.node_types = Counter()
        self.ai_models = Counter()
        self.use_cases = defaultdict(list)
        self.patterns = defaultdict(list)

    def analyze_all(self):
        """Analizza tutti i workflow nella directory"""
        print(f"Scanning {self.workflows_dir}...")

        json_files = list(self.workflows_dir.rglob("*.json"))
        print(f"Found {len(json_files)} JSON files")

        for i, json_file in enumerate(json_files, 1):
            if i % 100 == 0:
                print(f"  Processed {i}/{len(json_files)} workflows...")

            try:
                workflow = self.analyze_workflow(json_file)
                if workflow:
                    self.workflows.append(workflow)
            except Exception as e:
                print(f"  ⚠️  Error in {json_file.name}: {e}")

        print(f"\nSuccessfully analyzed {len(self.workflows)} workflows")

    def analyze_workflow(self, json_file):
        """Analizza un singolo workflow"""
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # Skip if no nodes
        if 'nodes' not in data or not data['nodes']:
            return None

        nodes = data['nodes']

        # Extract metadata
        workflow = {
            'id': json_file.stem,
            'name': data.get('name', json_file.stem),
            'file_path': str(json_file.relative_to(self.workflows_dir.parent)),
            'nodes_count': len(nodes),
            'nodes_types': [],
            'ai_nodes': [],
            'ai_models': [],
            'trigger_types': [],
            'category': self._detect_category(json_file),
            'has_ai': False,
            'complexity': self._calculate_complexity(nodes),
            'key_patterns': []
        }

        # Analyze nodes
        for node in nodes:
            node_type = node.get('type', '')
            workflow['nodes_types'].append(node_type)
            self.node_types[node_type] += 1

            # Detect AI nodes
            if 'langchain' in node_type or 'openai' in node_type.lower():
                workflow['has_ai'] = True
                workflow['ai_nodes'].append(node_type)

                # Extract AI model
                if 'parameters' in node:
                    params = node['parameters']
                    if 'modelName' in params:
                        model = params['modelName']
                        workflow['ai_models'].append(model)
                        self.ai_models[model] += 1
                    elif 'model' in params:
                        model = params.get('model', {})
                        if isinstance(model, dict):
                            model = model.get('value', 'unknown')
                        workflow['ai_models'].append(str(model))
                        self.ai_models[str(model)] += 1

            # Detect triggers
            if 'trigger' in node_type.lower() or node.get('name', '').lower().startswith('trigger'):
                trigger_type = self._extract_trigger_type(node_type)
                workflow['trigger_types'].append(trigger_type)

        # Detect patterns
        workflow['key_patterns'] = self._detect_patterns(workflow)

        return workflow

    def _detect_category(self, file_path):
        """Rileva categoria dal path"""
        parts = file_path.parts
        if len(parts) > 1:
            return parts[-2].lower()
        return 'uncategorized'

    def _calculate_complexity(self, nodes):
        """Calcola complessità workflow"""
        if len(nodes) < 3:
            return 'simple'
        elif len(nodes) < 8:
            return 'medium'
        else:
            return 'complex'

    def _extract_trigger_type(self, node_type):
        """Estrae tipo trigger dal node type"""
        trigger_types = {
            'schedule': 'schedule',
            'webhook': 'webhook',
            'gmail': 'email',
            'email': 'email',
            'form': 'form',
            'chat': 'chat',
            'manual': 'manual'
        }

        node_lower = node_type.lower()
        for key, value in trigger_types.items():
            if key in node_lower:
                return value
        return 'other'

    def _detect_patterns(self, workflow):
        """Rileva pattern comuni"""
        patterns = []
        nodes = workflow['nodes_types']

        # Pattern detection logic
        if 'gmail' in str(nodes).lower() and 'airtable' in str(nodes).lower():
            patterns.append('email-to-database')

        if workflow['has_ai'] and any('linkedin' in str(n).lower() for n in nodes):
            patterns.append('ai-content-generation')

        if 'extractFromFile' in str(nodes):
            patterns.append('document-processing')

        if workflow['has_ai'] and 'outputParserStructured' in str(nodes):
            patterns.append('structured-extraction')

        if 'agent' in str(nodes).lower():
            patterns.append('ai-agent')

        if 'schedule' in workflow.get('trigger_types', []):
            patterns.append('scheduled-automation')

        return patterns

    def generate_reports(self):
        """Genera report e index files"""
        print("\nGenerating reports...")

        # 1. Workflow Metadata Index
        self._generate_workflow_index()

        # 2. Node Statistics
        self._generate_node_statistics()

        # 3. AI Model Usage
        self._generate_ai_statistics()

        # 4. Pattern Clustering
        self._generate_pattern_clusters()

        # 5. Use Case Examples
        self._generate_use_case_examples()

        print("All reports generated successfully!")

    def _generate_workflow_index(self):
        """Genera index searchable di tutti i workflow"""
        output = {
            'total_workflows': len(self.workflows),
            'categories': {},
            'workflows': self.workflows
        }

        # Group by category
        for wf in self.workflows:
            cat = wf['category']
            if cat not in output['categories']:
                output['categories'][cat] = 0
            output['categories'][cat] += 1

        output_file = self.output_dir / 'workflow-metadata.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2, ensure_ascii=False)

        print(f"  ✓ Workflow index: {output_file}")

    def _generate_node_statistics(self):
        """Statistiche uso nodi"""
        stats = {
            'total_node_types': len(self.node_types),
            'most_used_nodes': self.node_types.most_common(50),
            'node_usage': dict(self.node_types)
        }

        output_file = self.output_dir / 'node-statistics.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)

        print(f"  ✓ Node statistics: {output_file}")

    def _generate_ai_statistics(self):
        """Statistiche AI models"""
        ai_workflows = [wf for wf in self.workflows if wf['has_ai']]

        # Group by use case
        ai_use_cases = defaultdict(lambda: {'count': 0, 'models': Counter(), 'examples': []})

        for wf in ai_workflows:
            for pattern in wf['key_patterns']:
                if 'ai' in pattern or 'content' in pattern or 'extraction' in pattern:
                    ai_use_cases[pattern]['count'] += 1
                    for model in wf['ai_models']:
                        ai_use_cases[pattern]['models'][model] += 1
                    if len(ai_use_cases[pattern]['examples']) < 5:
                        ai_use_cases[pattern]['examples'].append(wf['id'])

        stats = {
            'total_ai_workflows': len(ai_workflows),
            'ai_model_usage': dict(self.ai_models),
            'ai_use_cases': {
                k: {
                    'count': v['count'],
                    'models': dict(v['models']),
                    'examples': v['examples']
                }
                for k, v in ai_use_cases.items()
            }
        }

        output_file = self.output_dir / 'ai-model-usage.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)

        print(f"  ✓ AI statistics: {output_file}")

    def _generate_pattern_clusters(self):
        """Cluster workflow per pattern"""
        pattern_clusters = defaultdict(lambda: {'count': 0, 'workflows': []})

        for wf in self.workflows:
            for pattern in wf['key_patterns']:
                pattern_clusters[pattern]['count'] += 1
                if len(pattern_clusters[pattern]['workflows']) < 10:
                    pattern_clusters[pattern]['workflows'].append({
                        'id': wf['id'],
                        'name': wf['name'],
                        'file_path': wf['file_path']
                    })

        output = {
            'total_patterns': len(pattern_clusters),
            'patterns': {
                k: v for k, v in
                sorted(pattern_clusters.items(), key=lambda x: x[1]['count'], reverse=True)
            }
        }

        output_file = self.output_dir / 'pattern-clusters.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2, ensure_ascii=False)

        print(f"  ✓ Pattern clusters: {output_file}")

    def _generate_use_case_examples(self):
        """Genera esempi per use case comuni"""
        use_cases = {
            'email-processing': [],
            'content-automation': [],
            'document-analysis': [],
            'data-integration': [],
            'ai-agents': []
        }

        for wf in self.workflows:
            # Email processing
            if any('gmail' in n.lower() or 'outlook' in n.lower() for n in wf['nodes_types']):
                if len(use_cases['email-processing']) < 10:
                    use_cases['email-processing'].append(wf['id'])

            # Content automation
            if wf['has_ai'] and any('linkedin' in n.lower() or 'twitter' in n.lower() for n in wf['nodes_types']):
                if len(use_cases['content-automation']) < 10:
                    use_cases['content-automation'].append(wf['id'])

            # Document analysis
            if 'extractFromFile' in str(wf['nodes_types']):
                if len(use_cases['document-analysis']) < 10:
                    use_cases['document-analysis'].append(wf['id'])

            # AI Agents
            if 'agent' in str(wf['ai_nodes']).lower():
                if len(use_cases['ai-agents']) < 10:
                    use_cases['ai-agents'].append(wf['id'])

        output_file = self.output_dir / 'use-case-examples.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(use_cases, f, indent=2, ensure_ascii=False)

        print(f"  ✓ Use case examples: {output_file}")

def main():
    import sys
    import io

    # Fix encoding for Windows
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

    if len(sys.argv) < 2:
        print("Usage: python analyze-workflows.py <workflows_directory> [output_directory]")
        print("\nExample:")
        print("  python analyze-workflows.py C:/Users/aless/Documents/N8N/workflows ./n8n-ai-workflow-expert/references/index")
        sys.exit(1)

    workflows_dir = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else './output'

    print("N8N Workflow Analyzer")
    print("=" * 50)

    analyzer = WorkflowAnalyzer(workflows_dir, output_dir)
    analyzer.analyze_all()
    analyzer.generate_reports()

    print("\n" + "=" * 50)
    print("Analysis complete!")
    print(f"\nReports saved to: {output_dir}")
    print("\nGenerated files:")
    print("  - workflow-metadata.json (searchable index)")
    print("  - node-statistics.json (node usage stats)")
    print("  - ai-model-usage.json (AI model statistics)")
    print("  - pattern-clusters.json (workflow patterns)")
    print("  - use-case-examples.json (example workflows)")

if __name__ == '__main__':
    main()
