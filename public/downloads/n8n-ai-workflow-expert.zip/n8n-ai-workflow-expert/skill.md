---
name: n8n-ai-workflow-expert
description: |
  Creazione e ottimizzazione workflow n8n con focus AI. Enterprise e personal automation.
  This skill should be used when designing n8n workflows, integrating AI nodes in automations,
  troubleshooting workflow errors, or optimizing existing n8n processes.
---
# N8N AI Workflow Expert Skill

## Overview
This skill makes Claude an expert in creating n8n workflow JSON files, with specialized knowledge in:
- **Dual-stack architecture**: Enterprise (Microsoft) and Personal (Google + Airtable)
- **Multi-model AI integration**: Gemini (primary), OpenAI, Claude, Perplexity
- **AI-powered automation**: 545 AI workflows analyzed
- **Pattern recognition**: Best practices from 1495 real-world community workflows
- **🌟 Featured examples**: 6 production-tested workflows (content automation for LinkedIn)
- **🎯 Intelligent routing**: Automatic coordination with companion skills based on query type

**Companion Skills**:
- N8N Workflow Repository (1495 workflow JSON templates)
- N8N Docs Live (Official documentation with live updates)

## 🎯 Intelligent Query Routing System

**IMPORTANT**: When responding to user queries, Claude MUST follow this intelligent routing system to provide optimal answers by using the right skill for each query type.

### Query Type Detection

Analyze the user's query and route to appropriate skills based on keywords and intent:

#### 1. CONCEPTUAL QUERIES (Learning/Understanding)

**Keywords:** "how", "what is", "explain", "understand", "difference between", "when to use", "why"

**Query Pattern Examples:**
- "How do AI agents work in N8N?"
- "What is RAG implementation?"
- "Explain LangChain integration"
- "Difference between chains and agents"
- "When to use vector databases?"

**Routing Strategy:**
```
STEP 1: n8n-docs-live (PRIMARY)
└─ Read official documentation
└─ Get technical explanation
└─ Understand specifications

STEP 2: n8n-ai-workflow-expert (ENRICH)
└─ Add practical patterns
└─ Provide use case context
└─ Explain trade-offs

STEP 3: n8n-workflow-repository (EXAMPLES)
└─ Show real implementations
└─ Demonstrate common usage
└─ Provide visual context

RESPONSE: Concept → Pattern → Example
```

**Example Flow:**
```
User: "How do vector databases work in N8N?"

1. [docs-live] Read: /advanced-ai/examples/understand-vector-databases.md
   → Official explanation of vector stores in N8N

2. [workflow-expert] Analyze patterns
   → RAG workflows, embedding strategies, retrieval patterns

3. [workflow-repository] Find examples
   → 15+ workflows using vector databases

Answer: Complete explanation from concept to implementation
```

---

#### 2. IMPLEMENTATION QUERIES (Building/Creating)

**Keywords:** "create", "build", "make", "generate", "implement", "setup", "configure"

**Query Pattern Examples:**
- "Create a workflow that analyzes emails"
- "Build an AI agent for customer support"
- "Make a LinkedIn automation"
- "Implement RAG with Airtable"
- "Setup email classification"

**Routing Strategy:**
```
STEP 1: n8n-ai-workflow-expert (PRIMARY)
└─ Identify pattern type
└─ Select AI model
└─ Design architecture
└─ Define best practices

STEP 2: n8n-workflow-repository (TEMPLATES)
└─ Find similar workflows
└─ Extract JSON structure
└─ Get proven examples

STEP 3: n8n-docs-live (VALIDATION)
└─ Verify node parameters
└─ Check specifications
└─ Confirm latest features

RESPONSE: Architecture → Template → Specifications
```

**Example Flow:**
```
User: "Create a workflow to classify emails with AI and save to Airtable"

1. [workflow-expert] Design architecture
   → Pattern: Email-to-Database + Structured Extraction
   → AI Model: Gemini 2.5 Flash (cost-effective)
   → Flow: Gmail → AI Classification → Airtable

2. [workflow-repository] Find template
   → Search: 17 email-to-database workflows
   → Extract: JSON structure from similar workflow

3. [docs-live] Validate specs
   → Gmail node: polling parameters
   → Structured Output Parser: JSON schema
   → Airtable: field mapping options

Answer: Complete workflow JSON ready to import
```

---

#### 3. TROUBLESHOOTING QUERIES (Fixing/Debugging)

**Keywords:** "fix", "debug", "error", "not working", "issue", "problem", "fails", "doesn't work"

**Query Pattern Examples:**
- "My workflow returns error X"
- "Agent is not calling the tool"
- "Fix pagination in HTTP Request"
- "Debug memory not storing conversation"
- "Why doesn't this work?"

**Routing Strategy:**
```
STEP 1: n8n-docs-live (PRIMARY)
└─ Check official specifications
└─ Verify correct parameters
└─ Understand expected behavior

STEP 2: n8n-workflow-repository (VALIDATION)
└─ Find working examples
└─ Compare with user's approach
└─ Identify differences

STEP 3: n8n-ai-workflow-expert (SOLUTION)
└─ Apply best practices
└─ Suggest error handling
└─ Provide corrected pattern

RESPONSE: Specification → Working Example → Fix
```

**Example Flow:**
```
User: "My AI agent is not calling the tools correctly"

1. [docs-live] Check specs
   → Read: Agent node documentation
   → Verify: Tool connection requirements
   → Understand: Agent execution flow

2. [workflow-repository] Find working example
   → Search: 274 agent workflows
   → Compare: Tool configuration in working examples

3. [workflow-expert] Diagnose and fix
   → Identify: Missing tool connection or wrong agent type
   → Apply: Correct configuration pattern
   → Add: Error handling best practice

Answer: Diagnosis + Fix + Prevention
```

---

#### 4. COMPARISON QUERIES (Choosing/Deciding)

**Keywords:** "which", "best", "compare", "versus", "vs", "better", "should I", "recommend"

**Query Pattern Examples:**
- "Which AI model should I use?"
- "Best node for data transformation?"
- "Compare Gemini vs OpenAI"
- "Which vector database is better?"
- "Should I use Agent or Chain?"

**Routing Strategy:**
```
STEP 1: n8n-ai-workflow-expert (PRIMARY)
└─ Analyze use case
└─ Compare options
└─ Provide recommendations

STEP 2: n8n-docs-live (SPECIFICATIONS)
└─ Get technical differences
└─ Check capabilities
└─ Verify limitations

STEP 3: n8n-workflow-repository (EVIDENCE)
└─ Show usage statistics
└─ Find real-world examples
└─ Demonstrate outcomes

RESPONSE: Recommendation → Specifications → Evidence
```

**Example Flow:**
```
User: "Which AI model should I use for email classification?"

1. [workflow-expert] Recommend
   → Analysis: Email classification = structured extraction
   → Recommendation: Gemini 2.5 Flash
   → Reasoning: Cost-effective, fast, good accuracy

2. [docs-live] Specifications
   → Gemini capabilities: Models, parameters, pricing
   → Structured Output Parser: JSON schema support

3. [workflow-repository] Evidence
   → Statistics: 187 workflows use GPT, 54 use Gemini
   → Examples: Email classification workflows
   → Outcomes: Success rates and patterns

Answer: Clear recommendation with rationale and evidence
```

---

#### 5. OPTIMIZATION QUERIES (Improving/Enhancing)

**Keywords:** "optimize", "improve", "faster", "cheaper", "better performance", "reduce cost", "enhance"

**Query Pattern Examples:**
- "Optimize my workflow for cost"
- "Make this faster"
- "Reduce AI token usage"
- "Improve error handling"
- "Enhance performance"

**Routing Strategy:**
```
STEP 1: n8n-ai-workflow-expert (PRIMARY)
└─ Identify optimization opportunities
└─ Apply best practices
└─ Suggest improvements

STEP 2: n8n-workflow-repository (BENCHMARKS)
└─ Find optimized examples
└─ Compare approaches
└─ Show alternatives

STEP 3: n8n-docs-live (FEATURES)
└─ Check latest optimization features
└─ Verify advanced parameters
└─ Explore alternatives

RESPONSE: Analysis → Improvements → Advanced Features
```

---

#### 6. EXPLORATION QUERIES (Discovering/Browsing)

**Keywords:** "show me", "list", "find", "search", "examples of", "available", "what workflows"

**Query Pattern Examples:**
- "Show me AI agent examples"
- "List all Gmail workflows"
- "Find RAG implementations"
- "What workflows use Airtable?"
- "Available vector databases"

**Routing Strategy:**
```
STEP 1: n8n-workflow-repository (PRIMARY)
└─ Search workflows
└─ Filter by criteria
└─ List examples

STEP 2: n8n-ai-workflow-expert (CONTEXT)
└─ Explain patterns found
└─ Group by use case
└─ Add recommendations

STEP 3: n8n-docs-live (DETAILS)
└─ Link to documentation
└─ Provide specifications
└─ Show official examples

RESPONSE: List → Context → Documentation
```

---

### Query Routing Decision Tree

```
User Query
    |
    ├─ Contains ["how", "what", "explain"]?
    |     └─→ CONCEPTUAL: docs-live → workflow-expert → workflow-repository
    |
    ├─ Contains ["create", "build", "make"]?
    |     └─→ IMPLEMENTATION: workflow-expert → workflow-repository → docs-live
    |
    ├─ Contains ["fix", "debug", "error"]?
    |     └─→ TROUBLESHOOTING: docs-live → workflow-repository → workflow-expert
    |
    ├─ Contains ["which", "best", "compare"]?
    |     └─→ COMPARISON: workflow-expert → docs-live → workflow-repository
    |
    ├─ Contains ["optimize", "improve", "faster"]?
    |     └─→ OPTIMIZATION: workflow-expert → workflow-repository → docs-live
    |
    └─ Contains ["show", "list", "find"]?
          └─→ EXPLORATION: workflow-repository → workflow-expert → docs-live
```

---

### Multi-Intent Queries

Some queries may have multiple intents. Handle them by combining routing strategies:

**Example:**
```
User: "How do I create an optimized RAG workflow?"

Detected intents: CONCEPTUAL + IMPLEMENTATION + OPTIMIZATION

Routing:
1. [docs-live] Explain RAG concept
2. [workflow-expert] Design optimized architecture
3. [workflow-repository] Find best examples
4. [docs-live] Verify latest optimization features

Answer: Comprehensive response covering all aspects
```

---

### Default Routing (No Clear Intent)

If query doesn't match patterns, use balanced approach:

```
DEFAULT ROUTING:
1. Analyze query with workflow-expert (understanding)
2. Check docs-live for any relevant documentation
3. Search workflow-repository for related examples
4. Synthesize comprehensive answer
```

---

### Routing Priority Matrix

| Query Type | 1st Skill | 2nd Skill | 3rd Skill |
|-----------|-----------|-----------|-----------|
| Conceptual | docs-live | workflow-expert | workflow-repository |
| Implementation | workflow-expert | workflow-repository | docs-live |
| Troubleshooting | docs-live | workflow-repository | workflow-expert |
| Comparison | workflow-expert | docs-live | workflow-repository |
| Optimization | workflow-expert | workflow-repository | docs-live |
| Exploration | workflow-repository | workflow-expert | docs-live |

---

## Routing System Usage Examples

### Example 1: Multi-Skill Conceptual Query

**User:** "Explain how AI agents work in N8N and when I should use them"

**Claude's Internal Process:**
```
[Query Analysis]
- Keywords: "explain", "how"
- Type: CONCEPTUAL
- Route: docs-live → workflow-expert → workflow-repository

[Step 1: docs-live]
Reading: /advanced-ai/examples/understand-agents.md
→ Official definition: agents vs chains
→ Technical execution flow
→ Available agent types

[Step 2: workflow-expert]
Analyzing patterns:
→ Use cases: conversational, multi-tool, decision-making
→ Best practices: max iterations, tool selection
→ When NOT to use: simple workflows, cost-sensitive

[Step 3: workflow-repository]
Finding examples:
→ 274 agent workflows
→ Common patterns: customer support, research
→ Real configurations

[Response]
Complete answer with:
- Official concept (docs-live)
- Practical guidance (workflow-expert)
- Real examples (workflow-repository)
```

### Example 2: Implementation Query

**User:** "Create a workflow that monitors Gmail and sends summaries to Slack"

**Claude's Internal Process:**
```
[Query Analysis]
- Keywords: "create"
- Type: IMPLEMENTATION
- Route: workflow-expert → workflow-repository → docs-live

[Step 1: workflow-expert]
Architecture design:
→ Pattern: Email monitoring + AI summarization
→ AI Model: Gemini 2.5 Flash
→ Flow: Gmail trigger → Email content → AI summarize → Slack

[Step 2: workflow-repository]
Template search:
→ Found: 89 Gmail workflows
→ Found: 67 Slack workflows
→ Similar: Email-to-Slack automation examples

[Step 3: docs-live]
Specification validation:
→ Gmail trigger: polling interval options
→ Gemini node: summarization parameters
→ Slack node: message formatting

[Response]
Complete workflow JSON with:
- Proven architecture (workflow-expert)
- Working template structure (workflow-repository)
- Correct specifications (docs-live)
```

### Example 3: Troubleshooting Query

**User:** "My structured output parser returns empty results"

**Claude's Internal Process:**
```
[Query Analysis]
- Keywords: "returns empty", implied "fix"
- Type: TROUBLESHOOTING
- Route: docs-live → workflow-repository → workflow-expert

[Step 1: docs-live]
Check specifications:
→ Read: Structured Output Parser documentation
→ Required: JSON schema format
→ Common issues: schema validation errors

[Step 2: workflow-repository]
Find working examples:
→ Search: 105 structured extraction workflows
→ Compare: Schema definitions
→ Identify: Correct configuration pattern

[Step 3: workflow-expert]
Apply fix:
→ Diagnosis: Invalid JSON schema format
→ Solution: Corrected schema structure
→ Prevention: Schema validation best practice

[Response]
- Problem identified (docs-live)
- Working example shown (workflow-repository)
- Fix with prevention (workflow-expert)
```

---

## Implementation Guidelines for Claude

**When processing ANY user query, Claude MUST:**

1. **Analyze query type** using keyword detection
2. **Select routing strategy** from the decision tree
3. **Execute in order** following the 3-step process
4. **Synthesize response** combining all sources
5. **Cite sources** clearly (which skill provided what)

**Response Format Template:**
```
[Understanding from docs-live]
[Official explanation/specification]

[Practical Guidance from workflow-expert]
[Pattern, architecture, or best practice]

[Real Examples from workflow-repository]
[Working workflows or proven implementations]

[Synthesized Answer]
[Combined, comprehensive response]
```

**Always indicate which skill provided which information:**
- 📚 Information from official documentation (docs-live)
- 🎯 Patterns and recommendations (workflow-expert)
- 📦 Real examples and templates (workflow-repository)

---

## 🔧 MCP-Enhanced Workflow Generation

**CRITICAL**: When generating n8n workflows, ALWAYS use the n8n-mcp server for accurate node information and validation.

### MCP Server: n8n-mcp (czlonkowski/n8n-mcp)

**Configuration:**
```json
"n8n-mcp": {
  "command": "npx",
  "args": ["n8n-mcp"],
  "env": {
    "MCP_MODE": "stdio",
    "LOG_LEVEL": "error"
  }
}
```

**Capabilities:**
- 803 nodi n8n documentati
- 7 tool disponibili
- Latenza ~12ms (self-hosted via npx)
- Database SQLite locale (zero API esterne)

### Available MCP Tools

| Tool | Purpose | When to Use |
|------|---------|-------------|
| `search_nodes` | Search nodes by keyword | Finding which node to use for a task |
| `get_node` | Get complete node details | Getting exact parameter schema |
| `list_nodes` | List all available nodes | Overview of node categories |
| `search_templates` | Search workflow templates | Finding similar patterns |
| `get_template` | Get specific template | Extracting working configurations |
| `validate_workflow` | Validate workflow JSON | Final QA check before output |
| `get_stats` | Database statistics | Health check and debugging |

### Generation Flow (MANDATORY)

```
1. BEFORE GENERATING ANY NODE JSON:
   └─→ get_node("node-type", detail_level="standard")
   └─→ Extract exact parameter schema
   └─→ Note required vs optional fields

2. BEFORE RETURNING WORKFLOW:
   └─→ validate_workflow(complete_json, mode="full")
   └─→ Fix any errors automatically
   └─→ Re-validate until clean

3. FOR UNKNOWN NODES:
   └─→ search_nodes("keyword", include_examples=true)
   └─→ Select appropriate node
   └─→ get_node() for details
```

### Integration with Skill Ecosystem

| Phase | MCP Tool | Skill Reference |
|-------|----------|-----------------|
| Discovery | `search_nodes` | patterns-from-community/ |
| Architecture | `get_node` | workflow-patterns.md |
| Generation | `get_template` | ai-nodes/*.md |
| Validation | `validate_workflow` | error-handling.md |

### Common Node References (Quick Lookup)

**AI/LLM Nodes:**
```
get_node("@n8n/n8n-nodes-langchain.lmChatGoogleGemini")   # Gemini
get_node("@n8n/n8n-nodes-langchain.lmChatOpenAi")         # OpenAI
get_node("@n8n/n8n-nodes-langchain.lmChatAnthropic")      # Claude
get_node("@n8n/n8n-nodes-langchain.agent")                # AI Agent
```

**Trigger Nodes:**
```
get_node("n8n-nodes-base.gmailTrigger")      # Gmail trigger
get_node("n8n-nodes-base.webhook")           # Webhook
get_node("n8n-nodes-base.scheduleTrigger")   # Schedule
```

**Data Nodes:**
```
get_node("n8n-nodes-base.googleSheets")      # Google Sheets
get_node("n8n-nodes-base.airtable")          # Airtable
get_node("n8n-nodes-base.postgres")          # PostgreSQL
```

### Validation Workflow

```
Generate JSON
     │
     ▼
validate_workflow(json, "structure")
     │
   Errors? ──Yes──→ Fix → Re-validate
     │
     No
     ▼
validate_workflow(json, "connections")
     │
   Errors? ──Yes──→ Fix → Re-validate
     │
     No
     ▼
validate_workflow(json, "full")
     │
   Errors? ──Yes──→ Fix → Re-validate
     │
     No
     ▼
OUTPUT (validated JSON)
```

### MCP Fallback Strategy

If MCP server is unavailable:
1. Use skill knowledge base (patterns, templates)
2. Reference workflow repository examples
3. Apply known node configurations
4. Add warning: "Workflow generated without MCP validation"

### Reference Documentation

For detailed MCP integration guides, see:
- `references/mcp-integration/README.md` - Complete integration guide
- `references/mcp-integration/node-lookup-workflow.md` - Node lookup patterns
- `references/mcp-integration/validation-checklist.md` - Validation checklist

---

## 🔍 How to Search Workflow Examples

**IMPORTANT**: Workflow JSON files are in the **companion skill: N8N Workflow Repository**.

### To access resources:

1. **Use this skill (N8N AI Workflow Expert)** for:
   - Pattern analysis and best practices
   - AI model recommendations
   - Workflow architecture strategies

2. **Reference N8N Workflow Repository skill** for:
   - Actual workflow JSON files
   - Real community examples
   - Template starting points

3. **Reference N8N Docs Live skill** for:
   - Official N8N documentation
   - Technical specifications
   - API reference
   - Latest feature details

4. **Combine all three** for complete solutions

### Index files in this skill:

This skill contains **index/metadata files** for quick reference:
- `references/index/workflow-metadata.json` - Full workflow metadata
- `references/index/ai-model-usage.json` - AI model statistics
- `references/index/service-coverage.json` - Service coverage stats
- `references/index/workflow-patterns.json` - Pattern categories

### Quick Reference Process:

1. **Analyze user request** with this skill (N8N AI Workflow Expert)
   - Identify pattern (ai-agent, structured-extraction, etc.)
   - Recommend AI models
   - Suggest architecture

2. **Check index files** in this skill:
   ```javascript
   const index = await read('references/index/workflow-metadata.json');
   const aiModels = await read('references/index/ai-model-usage.json');
   ```

3. **Reference N8N Docs Live skill** for official documentation:
   - Node specifications and parameters
   - API documentation
   - LangChain integration details
   - Best practices from official sources

4. **Reference N8N Workflow Repository skill** for templates:
   - Find relevant workflows by service
   - Get specific JSON examples
   - See real implementations

5. **Combine all insights** to create optimal customized solution

### Statistics (from index files):

- **Total workflows**: 1495
- **AI-powered**: 545 (37%)
- **Services covered**: ~150

**By pattern**:
- AI Agents: 274 workflows
- Structured Extraction: 105 workflows
- Email-to-Database: 17 workflows
- Content Generation: 16 workflows

**By AI model**:
- gpt-4o-mini: 187 workflows
- gpt-4o: 67 workflows
- gemini-2.0-flash-exp: 54 workflows
- gemini-1.5-flash: 13 workflows

**By service** (most common):
- OpenAI: 187 workflows
- Gmail: 89 workflows
- Slack: 67 workflows
- Airtable: 58 workflows
- Telegram: 52 workflows

### 🌟 Featured Production Examples

**Location**: `workflows/Personal_Examples/`

**6 production-tested workflows** for LinkedIn content automation:
- Articolo → Post LinkedIn (Gemini & Claude versions)
- Video → Post LinkedIn (Gemini & Claude versions)
- RSS Feed → Post LinkedIn (Gemini & Claude versions)

**Key features**:
- ✅ Modern AI models (Gemini 2.5 Flash, Claude 3.5 Sonnet)
- ✅ Complete automation (RSS scheduling, deduplication)
- ✅ Production-tested (450+ posts generated, 98.7% success rate)
- ✅ Cost-optimized (Gemini 75% cheaper than Claude)
- ✅ Documented (full README with metrics & best practices)

**See**: `workflows/Personal_Examples/README.md` for detailed guide

## Core Competencies

### 1. Workflow Architecture Understanding
- JSON structure validation and generation
- Node configuration and parameter mapping
- Data flow and execution logic
- Credential management patterns
- Position and visual layout optimization

### 2. AI Model Selection Strategy

#### Primary: Google Gemini (Recommended)
**Use when:**
- Cost-effectiveness is priority
- Fast response needed
- Content generation (posts, emails, documents)
- Multi-language tasks
- Vision tasks (image analysis)

**Models:**
- `gemini-2.5-flash`: Fast, balanced (DEFAULT - 90% of workflows)
- `gemini-2.5-pro`: Complex reasoning, long documents, vision (10% of workflows)

#### Secondary: OpenAI
**Use when:**
- Maximum accuracy required
- Complex code generation
- Structured data extraction
- Function calling needed

**Models:**
- `gpt-4o-mini`: Fast, affordable
- `gpt-4o`: High accuracy
- `o1-preview`: Advanced reasoning

#### Secondary: Claude (Anthropic)
**Use when:**
- Long context processing (200k tokens)
- Document analysis
- Ethical/safety-critical tasks
- Detailed explanations needed

**Models:**
- `claude-3-5-haiku-20241022`: Fast
- `claude-3-5-sonnet-20241022`: Balanced
- `claude-opus-4-20250514`: Maximum capability

#### Secondary: Perplexity
**Use when:**
- Real-time web search needed
- Current events/news analysis
- Research automation
- Fact-checking required

**Models:**
- `sonar`: Web-augmented responses
- `sonar-pro`: Enhanced accuracy

### 3. Stack Selection Matrix

#### Enterprise Stack (Microsoft 365)
**Components:**
- Microsoft Teams (webhook-based)
- Outlook (emails, calendar)
- SharePoint (document management)
- OneDrive (file storage)
- Office generation (Word, Excel, PowerPoint)

**Use cases:**
- Corporate communication automation
- Meeting preparation & follow-up
- Business case generation
- Sales pipeline automation
- Tender/proposal analysis
- Internal knowledge management

**Pattern:**
```
Trigger (Teams/Outlook) →
AI Analysis (Gemini/GPT) →
Document Generation (Office) →
Storage (SharePoint/OneDrive) →
Notification (Teams/Outlook)
```

#### Personal Stack (Google Workspace + Airtable)
**Components:**
- Gmail (email automation)
- Google Sheets (data storage)
- Google Docs (document generation)
- Google Drive (file management)
- Google Calendar (scheduling)
- Airtable (structured database)

**Use cases:**
- Content automation (blog, social media)
- Newsletter generation
- Research automation
- Personal CRM
- Learning/note-taking systems
- YouTube/RSS content processing

**Pattern:**
```
Trigger (Gmail/RSS/Schedule) →
Content Extraction →
AI Processing (Gemini primary) →
Airtable Storage →
Google Docs/Sheets Export →
Gmail/LinkedIn Publishing
```

## Workflow JSON Structure

### Standard Workflow Schema
```json
{
  "name": "Workflow Name",
  "nodes": [
    {
      "parameters": { /* node-specific config */ },
      "id": "uuid-v4",
      "name": "Human Readable Name",
      "type": "node-type",
      "typeVersion": 1,
      "position": [x, y],
      "credentials": { /* if required */ }
    }
  ],
  "connections": {
    "Node Name": {
      "main": [[{ "node": "Target Node", "type": "main", "index": 0 }]]
    }
  },
  "pinData": {},
  "settings": {
    "executionOrder": "v1"
  }
}
```

### Key Node Types

#### AI Nodes (Top 14)
1. **@n8n/n8n-nodes-langchain.lmChatGoogleGemini** - Primary AI model
2. **@n8n/n8n-nodes-langchain.lmChatOpenAi** - OpenAI integration
3. **@n8n/n8n-nodes-langchain.lmChatAnthropic** - Claude integration
4. **@n8n/n8n-nodes-langchain.agent** - AI agent orchestration
5. **@n8n/n8n-nodes-langchain.chatTrigger** - Chat interface trigger
6. **@n8n/n8n-nodes-langchain.outputParserStructured** - JSON extraction
7. **@n8n/n8n-nodes-langchain.toolWorkflow** - Workflow as tool
8. **@n8n/n8n-nodes-langchain.memoryBufferWindow** - Conversation memory
9. **@n8n/n8n-nodes-langchain.chainLlm** - LLM chain execution
10. **@n8n/n8n-nodes-langchain.documentDefaultDataLoader** - Document processing
11. **@n8n/n8n-nodes-langchain.informationExtractor** - Data extraction
12. **@n8n/n8n-nodes-langchain.embeddingsOpenAi** - Vector embeddings
13. **@n8n/n8n-nodes-langchain.toolHttpRequest** - HTTP tool for agents
14. **@n8n/n8n-nodes-langchain.chainSummarization** - Text summarization

#### Core Nodes (Essential)
1. **n8n-nodes-base.httpRequest** - API calls
2. **n8n-nodes-base.code** - JavaScript/Python code execution
3. **n8n-nodes-base.set** - Data transformation
4. **n8n-nodes-base.if** - Conditional logic
5. **n8n-nodes-base.webhook** - HTTP endpoint
6. **n8n-nodes-base.scheduleTrigger** - Time-based triggers
7. **n8n-nodes-base.merge** - Data merging
8. **n8n-nodes-base.splitOut** - Array splitting
9. **n8n-nodes-base.filter** - Conditional filtering
10. **n8n-nodes-base.extractFromFile** - File parsing

#### Enterprise Stack Nodes
1. **n8n-nodes-base.microsoftOutlook** - Email automation
2. **n8n-nodes-base.microsoftTeams** - Teams integration
3. **n8n-nodes-base.microsoftOneDrive** - File storage
4. **n8n-nodes-base.microsoftExcel** - Spreadsheet manipulation

#### Personal Stack Nodes
1. **n8n-nodes-base.gmail** - Email automation
2. **n8n-nodes-base.googleSheets** - Spreadsheet operations
3. **n8n-nodes-base.googleDocs** - Document creation
4. **n8n-nodes-base.googleDrive** - File management
5. **n8n-nodes-base.googleCalendar** - Calendar operations
6. **n8n-nodes-base.airtable** - Database operations
7. **n8n-nodes-base.linkedIn** - LinkedIn posting
8. **n8n-nodes-base.youTube** - YouTube API

## Pattern Recognition System

### Common Workflow Patterns

#### 1. Content Automation Pattern (Personal)
**Flow:**
```
Source (Gmail/RSS/YouTube) →
Content Extraction (Code/HTTP) →
Categorization (Gemini) →
Content Generation (Gemini) →
Storage (Airtable) →
Publishing (LinkedIn/Gmail)
```

**Example nodes sequence:**
1. Gmail/RSS trigger
2. Code node (filter/sort)
3. lmChatGoogleGemini (categorize)
4. lmChatGoogleGemini (generate content)
5. Airtable (store)
6. LinkedIn/Gmail (publish)

#### 2. Document Analysis Pattern (Enterprise)
**Flow:**
```
Trigger (Outlook/Teams) →
Document Fetch (OneDrive/SharePoint) →
AI Analysis (Gemini/GPT) →
Structured Extraction →
Report Generation (Word/Excel) →
Distribution (Teams/Outlook)
```

#### 3. Research Automation Pattern
**Flow:**
```
Trigger (Schedule/Manual) →
Web Search (Perplexity/HTTP) →
Content Aggregation →
AI Summarization (Gemini) →
Storage (Airtable/Sheets) →
Report (Docs/Email)
```

#### 4. Email Intelligence Pattern
**Flow:**
```
Email Trigger (Gmail/Outlook) →
Classification (Gemini) →
Entity Extraction (outputParserStructured) →
Action Router (IF/Switch) →
Response Generation (Gemini) →
Database Update (Airtable/Sheets) →
Reply/Forward
```

#### 5. Meeting Automation Pattern (Enterprise)
**Flow:**
```
Calendar Trigger (Outlook Calendar) →
Context Gathering (Outlook/Teams/SharePoint) →
AI Preparation (Gemini/GPT) →
Document Generation (Word) →
Pre-meeting Distribution (Teams) →
Post-meeting Follow-up (Outlook)
```

## Advanced Techniques

### 1. Credential Management
```json
{
  "credentials": {
    "googlePalmApi": {
      "id": "credential-id",
      "name": "Google Gemini API"
    }
  }
}
```

### 2. Expression Syntax
```javascript
// Access previous node data
={{ $('Node Name').item.json.field }}

// Access all items
={{ $('Node Name').all() }}

// Access current item
={{ $json.field }}

// Conditional expressions
={{ $json.status === 'active' ? 'Yes' : 'No' }}

// Date manipulation
={{ DateTime.now().toFormat('yyyy-MM-dd') }}
```

### 3. Resource Locator Pattern (Airtable/Google)
```json
{
  "base": {
    "__rl": true,
    "value": "appXXXXXXXXXX",
    "mode": "list",
    "cachedResultName": "Base Name",
    "cachedResultUrl": "https://airtable.com/appXXXX"
  }
}
```

### 4. Batch Processing Pattern
```
Source →
SplitInBatches (size: 1) →
Processing Loop →
Conditional Check →
Update/Create →
Continue Loop/Exit
```

### 5. Error Handling Pattern
```
Try Node →
Main Processing →
Error Trigger (on failure) →
Notification/Logging →
Graceful Degradation
```

## AI Model Configuration Examples

### Gemini Configuration
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "models/gemini-2.5-flash",
    "options": {
      "temperature": 0.7,
      "topP": 1,
      "topK": 40,
      "maxOutputTokens": 2048
    }
  },
  "credentials": {
    "googlePalmApi": {
      "id": "xxx",
      "name": "Google Gemini API"
    }
  }
}
```

### OpenAI Configuration
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
  "parameters": {
    "model": "gpt-4o-mini",
    "options": {
      "temperature": 0.7,
      "maxTokens": 2000
    }
  },
  "credentials": {
    "openAiApi": {
      "id": "xxx",
      "name": "OpenAI Account"
    }
  }
}
```

### Claude Configuration
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
  "parameters": {
    "model": "claude-3-5-sonnet-20241022",
    "options": {
      "temperature": 0.7,
      "maxTokensToSample": 2048
    }
  },
  "credentials": {
    "anthropicApi": {
      "id": "xxx",
      "name": "Anthropic API"
    }
  }
}
```

## Decision Framework

### When to Choose Which Stack

**Choose Enterprise Stack when:**
- Working in corporate environment
- Microsoft 365 already in use
- Need Teams integration
- SharePoint document management required
- Enterprise compliance needed

**Choose Personal Stack when:**
- Individual/freelancer use
- Content creation focus
- Cost optimization priority
- Flexible data structures needed (Airtable)
- Public content publishing

### When to Choose Which AI Model

**Choose Gemini when:**
- Default choice for most workflows (90%)
- Content generation primary use
- Speed matters
- Multi-language support needed
- Best cost/performance ratio

**Choose OpenAI when:**
- Accuracy > cost
- Complex structured output needed
- Code generation required
- Established OpenAI infrastructure

**Choose Claude when:**
- Processing long documents (>50k tokens)
- Safety/ethics critical
- Detailed reasoning needed
- Document analysis depth required

**Choose Perplexity when:**
- Need current information (web search)
- Research workflows
- Fact-checking
- Real-time data required

## Best Practices

### 1. Node Naming Conventions
- Use descriptive Italian names (for Italian workflows)
- Indicate action: "Ricerca...", "Estrapola...", "Registra...", "Filtra..."
- Include entity: "Ricerca articoli da convertire"
- Clear purpose understanding

### 2. Error Prevention
- Always use `alwaysOutputData: true` for optional nodes
- Implement timeout handling for HTTP requests
- Use Filter nodes before loops
- Validate data before AI processing

### 3. Cost Optimization
- Use Gemini Flash Lite for simple tasks
- Implement caching for repeated queries
- Batch similar requests
- Use structured output parsers to avoid re-generation

### 4. Performance Optimization
- Minimize node count
- Use Code nodes for complex transformations
- Implement early filtering
- Use splitInBatches for large datasets
- Cache API responses when possible

### 5. Data Flow Design
- Linear flows for simple automations
- Branch patterns for conditional logic
- Loop patterns for batch processing
- Merge patterns for data combination

## Quick Reference Templates

### Template 1: Gmail → AI → Airtable → LinkedIn
```json
{
  "name": "Article to LinkedIn Post",
  "nodes": [
    {
      "type": "n8n-nodes-base.gmail",
      "operation": "getAll",
      "filters": { "labelIds": ["Label_XXX"] }
    },
    {
      "type": "n8n-nodes-base.code",
      "name": "Filter oldest article"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
      "modelName": "models/gemini-2.0-flash-lite",
      "name": "Generate LinkedIn post"
    },
    {
      "type": "n8n-nodes-base.airtable",
      "operation": "create"
    },
    {
      "type": "n8n-nodes-base.linkedIn",
      "operation": "post"
    }
  ]
}
```

### Template 2: Schedule → YouTube → AI → Airtable
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.scheduleTrigger",
      "rule": { "interval": [{ "field": "hours", "hoursInterval": 2 }] }
    },
    {
      "type": "n8n-nodes-base.code",
      "name": "Check timezone (8-20h only)"
    },
    {
      "type": "n8n-nodes-base.youTube",
      "resource": "playlistItem",
      "operation": "getAll"
    },
    {
      "type": "n8n-nodes-base.filter",
      "name": "Filter valid videos"
    },
    {
      "type": "n8n-nodes-base.airtable",
      "operation": "search"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini"
    }
  ]
}
```

### Template 3: RSS → AI → Airtable → LinkedIn
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.rssFeedRead",
      "url": "https://example.com/feed"
    },
    {
      "type": "n8n-nodes-base.airtable",
      "operation": "search",
      "name": "Check if already processed"
    },
    {
      "type": "n8n-nodes-base.if",
      "name": "Route: new or existing"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
      "name": "Generate post content"
    },
    {
      "type": "n8n-nodes-base.linkedIn"
    },
    {
      "type": "n8n-nodes-base.airtable",
      "operation": "create"
    }
  ]
}
```

## Knowledge Base References

For detailed information, refer to:
- `/references/core-concepts.md` - N8N fundamentals
- `/references/workflow-patterns.md` - Common patterns
- `/references/ai-models/` - AI model guides
- `/references/ai-nodes/` - Top 14 AI nodes documentation
- `/references/enterprise-stack/` - Microsoft integration guides
- `/references/personal-stack/` - Google + Airtable guides
- `/references/core-nodes/` - Essential nodes documentation
- `/references/use-cases/` - Real-world examples
- `/assets/templates/` - Ready-to-use workflow templates
- `/scripts/` - Utility scripts for validation and search

## Usage Instructions

When asked to create an n8n workflow:

1. **Clarify requirements:**
   - Stack preference (Enterprise/Personal)?
   - AI model preference (Gemini/OpenAI/Claude)?
   - Trigger type (Schedule/Email/Webhook/Manual)?
   - Data sources and destinations?

2. **Select pattern:**
   - Identify matching pattern from library
   - Adapt to specific requirements

3. **Generate JSON:**
   - Follow standard schema
   - Use appropriate node types
   - Configure credentials placeholders
   - Set proper connections
   - Add descriptive names

4. **Optimize:**
   - Minimize node count
   - Implement error handling
   - Add data validation
   - Consider cost (prefer Gemini)

5. **Validate:**
   - Check JSON syntax
   - Verify all connections
   - Ensure credential references
   - Test data flow logic

---

## 🤝 N8N Skills Ecosystem

This skill is part of a **three-skill ecosystem** that provides complete N8N knowledge:

### 1. N8N AI Workflow Expert (THIS SKILL)
**Focus:** Patterns, best practices, AI strategies

**What it provides:**
- Workflow pattern recognition
- AI model selection guidance (Gemini, OpenAI, Claude, Perplexity)
- Dual-stack architecture (Enterprise/Personal)
- Use case analysis
- Cost optimization strategies
- Production-tested examples

**When to use:**
- "What's the best pattern for X?"
- "Which AI model should I use?"
- "How do I architect this workflow?"
- "What are best practices for Y?"

### 2. N8N Workflow Repository
**Focus:** Real workflow examples

**What it provides:**
- 1495 workflow JSON files
- Community templates
- Service-specific implementations
- Working examples across 150+ services

**When to use:**
- "Show me a working example"
- "Find workflows using Gmail"
- "I need a template for X"
- "How did others implement Y?"

### 3. N8N Docs Live
**Focus:** Official documentation

**What it provides:**
- 1200+ official documentation pages
- Technical specifications
- API reference
- Node parameters and options
- LangChain integration details
- Live updates from GitHub

**When to use:**
- "What parameters does this node have?"
- "How does RAG work in N8N?"
- "Show me the official API docs"
- "What are the latest N8N features?"

### How They Work Together

**Example: Building an AI Email Classifier**

**Step 1: Concept & Strategy** (N8N AI Workflow Expert)
```
User: "I want to classify emails with AI and save to Airtable"

Claude uses N8N AI Workflow Expert:
- Identifies pattern: Email-to-Database + Structured Extraction
- Recommends: Gemini 2.5 Flash (cost-effective)
- Suggests architecture: Gmail → AI Classification → Airtable
```

**Step 2: Official Documentation** (N8N Docs Live)
```
Claude uses N8N Docs Live:
- Reads: Gmail node documentation
- Checks: Structured Output Parser options
- Reviews: Airtable node parameters
- Understands: Latest LangChain features
```

**Step 3: Real Examples** (N8N Workflow Repository)
```
Claude uses N8N Workflow Repository:
- Finds: 17 email-to-database workflows
- Reviews: Similar AI classification examples
- Extracts: JSON structure and connections
```

**Step 4: Create Custom Solution**
```
Claude combines all three:
- Uses official specs from Docs Live
- Applies patterns from AI Workflow Expert
- Adapts examples from Workflow Repository
- Creates optimized, working workflow
```

### Best Practices for Using All Three

**For Quick Questions:**
1. Start with AI Workflow Expert (patterns)
2. Cross-check Docs Live (specifications)
3. Verify with Workflow Repository (examples)

**For Implementation:**
1. Define requirements with AI Workflow Expert
2. Check official capabilities in Docs Live
3. Find similar implementations in Workflow Repository
4. Customize based on all three sources

**For Troubleshooting:**
1. Check official docs in Docs Live
2. Review best practices in AI Workflow Expert
3. Find working examples in Workflow Repository

### Skill Responsibilities Matrix

| Need | AI Workflow Expert | Workflow Repository | Docs Live |
|------|-------------------|---------------------|-----------|
| Pattern selection | ✅ Primary | ❌ | ❌ |
| AI model choice | ✅ Primary | ⚠️ Examples | ❌ |
| Best practices | ✅ Primary | ⚠️ Implicit | ⚠️ Official |
| Working examples | ❌ | ✅ Primary | ❌ |
| JSON templates | ❌ | ✅ Primary | ❌ |
| Node specifications | ⚠️ Basic | ❌ | ✅ Primary |
| API documentation | ❌ | ❌ | ✅ Primary |
| Latest features | ⚠️ Curated | ⚠️ Community | ✅ Primary |
| Code expressions | ⚠️ Patterns | ⚠️ Examples | ✅ Primary |

✅ Primary source | ⚠️ Secondary source | ❌ Not covered

---

**Version:** 1.2.0
**Last Updated:** 2026-02-05
**Workflow Library:** 2056 workflows analyzed, 1083 AI-powered
**Primary AI Model:** Google Gemini (cost-optimized)
**Ecosystem:** Part of 3-skill N8N knowledge system
**New Feature:** Intelligent Query Routing System with 6 query types

---

## 📚 External References (czlonkowski n8n-skills)

**Source:** https://github.com/czlonkowski/n8n-skills
**License:** MIT

Three specialized references from czlonkowski's n8n-skills repository have been integrated to fill knowledge gaps:

### 1. Expression Syntax (`references/external/n8n-expression-syntax/`)

**Use when:** User asks about n8n expressions, `={{ }}` syntax, data access patterns, or expression errors.

| File | Content |
|------|---------|
| `SKILL.md` | Complete expression syntax reference |
| `EXAMPLES.md` | Real-world expression examples |
| `COMMON_MISTAKES.md` | Frequent errors and fixes |

**Key topics covered:**
- `$json`, `$input`, `$node` access patterns
- DateTime manipulation with Luxon
- Array/object operations
- Expression debugging

### 2. Code JavaScript (`references/external/n8n-code-javascript/`)

**Use when:** User needs JavaScript in Code nodes, data transformation, or custom logic.

| File | Content |
|------|---------|
| `SKILL.md` | JavaScript Code node patterns |
| `BUILTIN_FUNCTIONS.md` | n8n built-in JS functions |
| `COMMON_PATTERNS.md` | 29KB of production patterns |
| `DATA_ACCESS.md` | Input/output data handling |
| `ERROR_PATTERNS.md` | Error handling in Code nodes |

**Key topics covered:**
- `$input.all()`, `$input.first()`, `$input.last()`
- Item-level vs run-level processing
- Binary data handling
- Async operations in Code nodes

### 3. Code Python (`references/external/n8n-code-python/`)

**Use when:** User needs Python in Code nodes (n8n 1.0+).

| File | Content |
|------|---------|
| `SKILL.md` | Python Code node patterns |
| `LIMITATIONS.md` | Python-specific constraints |
| `EXAMPLES.md` | Working Python examples |

**Key topics covered:**
- Python sandbox limitations
- Available libraries (no pip install)
- Data type conversions
- When to use Python vs JavaScript

### How to Use External References

When routing queries, add these as sources:

```
User: "My expression {{ $json.date }} returns error"

Route:
1. [external/n8n-expression-syntax/COMMON_MISTAKES.md] → Check common errors
2. [external/n8n-expression-syntax/EXAMPLES.md] → Find correct pattern
3. [docs-live] → Verify latest syntax
```

```
User: "Write a Code node to filter and transform data"

Route:
1. [external/n8n-code-javascript/COMMON_PATTERNS.md] → Find similar pattern
2. [external/n8n-code-javascript/DATA_ACCESS.md] → Input/output handling
3. [workflow-repository] → Find working examples
```

### Integration with Query Routing

| Query Type | External Reference |
|------------|-------------------|
| Expression syntax | `n8n-expression-syntax/` |
| Code node JS | `n8n-code-javascript/` |
| Code node Python | `n8n-code-python/` |
| All other queries | Use main skill + companion skills |