# N8N AI Workflow Expert - Claude Skill

## Overview

This skill transforms Claude into an n8n expert, specialized in creating JSON workflows with a focus on:
- **AI-powered automation** (Gemini 2.5 primary)
- **Dual-stack**: Enterprise (Microsoft 365) and Personal (Google Workspace + Airtable)
- **Pattern-based design**: 1495 real workflows analyzed, 545 AI-powered
- **Featured examples**: 6 production-tested workflows (LinkedIn automation)

**Companion Skill**: N8N Workflow Repository (1495 workflow JSON templates)

**Note**: Workflow JSON files are now in a separate companion skill to respect Claude's 200-file limit per skill.

---

## Quick Start

### 1. Skill Installation

Copy the `n8n-ai-workflow-expert/` folder to the Claude Code skills directory:

```bash
# Claude Code skills path (example)
~/.claude-code/skills/n8n-ai-workflow-expert/
```

### 2. Verify Installation

The skill will be automatically loaded. Claude will have access to:
- SKILL.md (main guide)
- references/ (technical documentation)
- assets/templates/ (ready-to-use templates)

### 3. First Use

Ask Claude:
```
"Create an n8n workflow that reads emails from Gmail,
categorizes them with Gemini, and saves them to Airtable"
```

Claude will automatically use the knowledge base to generate the complete JSON.

---

## Skill Structure

```
n8n-ai-workflow-expert/
│
├── SKILL.md                          # Main guide
├── README.md                         # This file
├── EXAMPLES.md                       # Practical examples
│
├── references/
│   ├── core-concepts.md             # N8N fundamentals
│   ├── workflow-patterns.md         # Common patterns
│   │
│   ├── index/                       # Index files (metadata only)
│   │   ├── ai-model-usage.json      # AI model statistics
│   │   ├── service-coverage.json    # Service coverage stats
│   │   └── workflow-patterns.json   # Pattern categories
│   │
│   ├── ai-models/                   # AI model guides
│   │   ├── model-selection-matrix.md
│   │   ├── gemini-guide.md          # Gemini 2.5 (PRIMARY)
│   │   ├── openai-guide.md
│   │   ├── claude-guide.md
│   │   └── perplexity-guide.md
│   │
│   ├── patterns-from-community/     # Patterns from real workflows
│   │   ├── README.md
│   │   ├── ai-agent-patterns.md     # 274 workflows
│   │   └── structured-extraction-patterns.md  # 105 workflows
│   │
│   ├── snippets/                    # Reusable snippets
│   │   ├── README.md
│   │   ├── ai-models/               # Gemini, OpenAI configs
│   │   └── langchain/               # Chains, Agents
│   │
│   ├── ai-nodes/                    # LangChain nodes guide
│   ├── enterprise-stack/            # Microsoft 365
│   ├── personal-stack/              # Google + Airtable
│   └── core-nodes/                  # Essential nodes
│
├── assets/
│   └── templates/                   # Ready-to-use templates
│
└── scripts/                         # Utility scripts
    ├── analyze-workflows.py         # Analyze workflows, generate index
    └── search-workflows.py          # Search workflows from CLI
```

---

## Featured Examples (Production-Tested)

**Note**: Featured examples are now in the companion skill **N8N Workflow Repository**

**Location**: `workflows/Personal_Examples/` (in N8N Workflow Repository skill)

**6 ready-to-use workflows** for LinkedIn content automation:
- **Article → LinkedIn Post** (Gemini & Claude)
- **Video → LinkedIn Post** (Gemini & Claude)
- **RSS Feed → LinkedIn Post** (Gemini & Claude)

**Features**:
- Production-tested (450+ posts generated)
- Success rate: 98.7%
- Cost-optimized (Gemini 75% cheaper)
- Complete automation (scheduling, deduplication, logging)
- Complete documentation with real metrics

**See**: `workflows/Personal_Examples/README.md` for detailed guide.

---

## Usage Examples

### Example 1: Simple Workflow Generation

**Request:**
```
Create a workflow that every day at 9:00
reads articles from an RSS feed and saves them to Airtable
```

**Claude will generate:**
- Complete workflow JSON
- Correct node configuration
- Connections between nodes
- Best practices applied

---

### Example 2: Content Automation

**Request:**
```
I want to automate LinkedIn post creation from articles.
Stack: Gmail + Gemini + Airtable + LinkedIn
```

**Claude will provide:**
- Pattern matching (Article to Social Post)
- Complete workflow JSON
- Optimal Gemini configuration (2.5 Flash)
- Deduplication system
- Logging in Airtable

---

### Example 3: AI Model Selection

**Request:**
```
Which AI model should I use to extract structured data
from 1000 PDF invoices?
```

**Claude will recommend:**
- Gemini 2.5 Flash (90% accuracy, fast)
- If accuracy < 95% → GPT-4o-mini
- Pattern: Batch processing + error handling

---

## Skill Capabilities

### 1. Workflow Generation
Claude can generate complete workflow JSON for:
- Content automation (social media, newsletter)
- Email management (classification, auto-reply)
- Document processing (analysis, extraction)
- Data pipelines (ETL, enrichment)
- Integration workflows (API, multi-system)
- Monitoring & alerts

### 2. AI Model Selection
Claude can recommend the optimal model:
- **Gemini 2.5 Flash** (default, 90% of cases)
- **Gemini 2.5 Pro** (complex reasoning, vision)
- **GPT-4o** (maximum structured output accuracy)
- **Claude** (long documents >50k tokens)
- **Perplexity** (web search, current events)

### 3. Stack Recommendation
Claude identifies the right stack:
- **Personal Stack**: Google Workspace + Airtable
  - Gmail, Google Sheets/Docs/Drive, Calendar
  - Airtable (flexible database)
  - LinkedIn, YouTube, RSS

- **Enterprise Stack**: Microsoft 365
  - Outlook, Teams, OneDrive, SharePoint
  - Office (Word, Excel, PowerPoint)

### 4. Pattern Recognition
Claude recognizes and applies patterns:
- Content automation (Article → Post)
- Batch processing (1000 items)
- Deduplication strategy
- Error handling
- Human-in-the-loop
- Progressive enrichment

### 5. Best Practices
Claude automatically applies:
- Naming conventions
- Error handling
- Cost optimization (Gemini primary)
- Performance optimization
- Security best practices

---

## Supported Use Cases

### Personal/Content Creator
1. **Social Media Automation**
   - Email → AI → LinkedIn/Twitter
   - YouTube → AI → Multi-platform post
   - RSS → Curated newsletter

2. **Research Automation**
   - Web scraping → AI summary → Database
   - Perplexity research → Gemini content

3. **Personal CRM**
   - Email → Contact extraction → Airtable
   - Meeting notes → Action items → Tasks

### Enterprise/Business
1. **Meeting Automation**
   - Calendar trigger → Context gathering → AI prep → Distribution

2. **Document Intelligence**
   - Contract upload → AI analysis → Risk flagging → Review

3. **Customer Support**
   - Email classification → Auto-response → SLA tracking

4. **Sales Automation**
   - Lead enrichment → AI scoring → CRM update → Notification

---

## How to Get the Most Out of It

### Best Practices for Requests

#### Vague Request (Avoid)
```
"Create a workflow for emails"
```

#### Specific Request (Recommended)
```
"Create a workflow that:
- Trigger: New Gmail emails with label 'Articles'
- Extracts the content
- Uses Gemini to categorize (Analysis/Tutorial/News)
- Generates a LinkedIn post (200 words)
- Saves to Airtable with status 'Draft'
- Sends me a Slack notification"
```

**Result:** Claude will generate a complete and optimized workflow.

---

### Useful Information to Provide

1. **Trigger Type**
   - Schedule (when? every hour? daily?)
   - Email (Gmail/Outlook? filters?)
   - Webhook
   - Manual

2. **Data Sources**
   - Where does the data come from?
   - Format (JSON, email, PDF, etc.)

3. **Processing Requirements**
   - What should the AI do?
   - Categorization? Generation? Extraction?

4. **Output/Destination**
   - Where do the results go?
   - Airtable? Google Sheets? Email?

5. **Stack Preference** (optional)
   - Personal (Google) or Enterprise (Microsoft)?

---

## Reference Guides

### AI Models
- **Gemini 2.5 Flash**: DEFAULT for 90% of workflows
  - Content generation, categorization, fast processing
  - Excellent quality/speed ratio

- **Gemini 2.5 Pro**: Complex tasks
  - Long documents (>50k tokens)
  - Image/video analysis
  - Maximum quality reasoning

- **GPT-4o-mini**: Accuracy focus
  - Structured data extraction
  - Complex JSON parsing

See: `references/ai-models/model-selection-matrix.md`

### Workflow Patterns
Most common patterns:
1. Content Automation (Email/RSS → AI → Social)
2. Document Analysis (Upload → AI → Database)
3. Batch Processing (Split → Process → Merge)
4. Email Intelligence (Classify → Route → Respond)

See: `references/workflow-patterns.md`

### Core Concepts
- Expression syntax: `={{ $json.field }}`
- Node structure and connections
- Credential management
- Error handling

See: `references/core-concepts.md`

---

## Troubleshooting

### Claude can't find the skill
- Verify installation path
- Restart Claude Code
- Check that SKILL.md exists

### Generated workflow doesn't work
- Ask Claude to validate the JSON
- Check credential IDs (placeholder)
- Test node by node in n8n

### Wrong AI model
- Specify in your request: "Use Gemini 2.5 Flash"
- Claude default is always Gemini (optimal)

---

## Updates and Maintenance

### How to Update the Skill

1. New workflow templates:
   - Add JSON to `assets/templates/`

2. New patterns:
   - Document in `references/workflow-patterns.md`

3. New nodes:
   - Add guides to `references/ai-nodes/` or `references/core-nodes/`

### Contributing

This skill is based on:
- Analysis of 2056 community workflows
- 1083 AI-powered workflows
- n8n best practices

For improvements, document:
- New patterns found
- Edge cases
- Optimizations

---

## Cost Optimization

### Default Strategy (Built-in)
Claude always uses **Gemini 2.5 Flash** as default:
- Fast (100 tokens/sec)
- Excellent quality
- Great cost/performance ratio

### When to Upgrade to Gemini 2.5 Pro
Claude will automatically suggest when:
- Long documents (>50k tokens)
- Vision tasks (images/video)
- Complex reasoning chains

### Hybrid Approach
For large volumes, Claude can suggest:
```
1000 items → Gemini 2.5 Flash (categorize/score)
Filter top 100 (uncertain) → Gemini 2.5 Pro (analyze)
Result: Speed + accuracy where needed
```

---

## Metrics & Performance

### What to Track
Claude can help you implement:
- Workflow execution count
- Success/failure rate
- Processing time
- AI model costs
- Quality scores

### Dashboard Suggestions
Claude can generate workflows for:
- Daily/weekly reports (Airtable → Google Sheets → Email)
- Real-time monitoring (Slack notifications)
- Cost tracking (by model/workflow)

---

## Next Steps

### 1. Test with a Simple Workflow
```
"Create a workflow that sends an email every Monday morning with a reminder"
```

### 2. Try Content Automation
```
"Setup: Gmail → Gemini → Airtable → LinkedIn for articles"
```

### 3. Explore Advanced Patterns
```
"Show me patterns for processing 1000 emails in batch with AI"
```

### 4. Optimize Existing Workflows
```
"I have this workflow [paste JSON]. How can I optimize it?"
```

---

## Support

### Resources
- **N8N Docs**: https://docs.n8n.io
- **N8N Community**: https://community.n8n.io
- **Skill Location**: `n8n-ai-workflow-expert/SKILL.md`

### Common Commands

**Request a workflow:**
```
"Create workflow for [goal] using [stack]"
```

**Validate JSON:**
```
"Validate this n8n workflow: [JSON]"
```

**Optimize:**
```
"How can I improve this workflow? [JSON]"
```

**Debug:**
```
"This workflow doesn't work: [error]. Help me debug."
```

**Model Selection:**
```
"Which AI model should I use for [task]?"
```

---

## Version

- **Version**: 1.0.0
- **Last Updated**: 2025-01-19
- **AI Models**: Gemini 2.5 (primary), OpenAI, Claude, Perplexity
- **Workflows Analyzed**: 2056 (1083 AI-powered)
- **Primary Stack**: Personal (Google + Airtable) & Enterprise (Microsoft 365)

---

## Key Features Summary

- **Instant workflow generation** - Complete JSON in seconds
- **AI model optimization** - Gemini 2.5 primary (cost-effective)
- **Dual-stack support** - Personal & Enterprise
- **Pattern library** - 2056+ workflow examples
- **Best practices built-in** - Security, performance, error handling
- **Cost-conscious** - Always suggests optimal model
- **Production-ready** - Tested on real use cases

---

**Ready to automate? Ask Claude to create your first n8n workflow!**
