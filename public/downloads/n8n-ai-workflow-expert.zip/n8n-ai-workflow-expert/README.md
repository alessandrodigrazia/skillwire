# N8N AI Workflow Expert - Claude Skill

## 📋 Overview

Questa skill trasforma Claude in un esperto di n8n, specializzato nella creazione di workflow JSON con focus su:
- **Automazione AI-powered** (Gemini 2.5 primario)
- **Dual-stack**: Enterprise (Microsoft 365) e Personal (Google Workspace + Airtable)
- **Pattern-based design**: 1495 workflow reali analizzati, 545 AI-powered
- **🌟 Featured examples**: 6 workflow production-tested (LinkedIn automation)

**Companion Skill**: N8N Workflow Repository (1495 workflow JSON templates)

**Note**: Workflow JSON files are now in a separate companion skill to respect Claude's 200-file limit per skill.

---

## 🚀 Quick Start

### 1. Installazione della Skill

Copia la cartella `n8n-ai-workflow-expert/` nella directory delle skills di Claude Code:

```bash
# Percorso skills Claude Code (esempio)
~/.claude-code/skills/n8n-ai-workflow-expert/
```

### 2. Verifica Installazione

La skill sarà automaticamente caricata. Claude avrà accesso a:
- SKILL.md (guida principale)
- references/ (documentazione tecnica)
- assets/templates/ (template pronti)

### 3. Primo Utilizzo

Chiedi a Claude:
```
"Crea un workflow n8n che legge email da Gmail,
le categorizza con Gemini e le salva in Airtable"
```

Claude utilizzerà automaticamente la knowledge base per generare il JSON completo.

---

## 📚 Struttura della Skill

```
n8n-ai-workflow-expert/
│
├── SKILL.md                          # ⭐ Guida principale
├── README.md                         # Questo file
├── EXAMPLES.md                       # 📚 Esempi pratici
│
├── references/
│   ├── core-concepts.md             # Fondamentali di n8n
│   ├── workflow-patterns.md         # Pattern comuni
│   │
│   ├── index/                       # 📊 Index files (metadata only)
│   │   ├── ai-model-usage.json      # AI model statistics
│   │   ├── service-coverage.json    # Service coverage stats
│   │   └── workflow-patterns.json   # Pattern categories
│   │
│   ├── ai-models/                   # Guide AI models
│   │   ├── model-selection-matrix.md
│   │   ├── gemini-guide.md          # ⭐ Gemini 2.5 (PRIMARY)
│   │   ├── openai-guide.md
│   │   ├── claude-guide.md
│   │   └── perplexity-guide.md
│   │
│   ├── patterns-from-community/     # Pattern da workflow reali
│   │   ├── README.md
│   │   ├── ai-agent-patterns.md     # 274 workflows
│   │   └── structured-extraction-patterns.md  # 105 workflows
│   │
│   ├── snippets/                    # Snippet riutilizzabili
│   │   ├── README.md
│   │   ├── ai-models/               # Gemini, OpenAI configs
│   │   └── langchain/               # Chains, Agents
│   │
│   ├── ai-nodes/                    # LangChain nodes guide
│   ├── enterprise-stack/            # Microsoft 365
│   ├── personal-stack/              # Google + Airtable
│   └── core-nodes/                  # Essential nodes
│
├── assets/
│   └── templates/                   # Template pronti
│
└── scripts/                         # 🆕 Utility scripts
    ├── analyze-workflows.py         # Analizza workflow, genera index
    └── search-workflows.py          # Cerca workflow da CLI
```

---

## 🌟 Featured Examples (Production-Tested)

**Note**: Featured examples are now in the companion skill **N8N Workflow Repository**

**Location**: `workflows/Personal_Examples/` (in N8N Workflow Repository skill)

**6 workflow pronti all'uso** per LinkedIn content automation:
- **Articolo → Post LinkedIn** (Gemini & Claude)
- **Video → Post LinkedIn** (Gemini & Claude)
- **RSS Feed → Post LinkedIn** (Gemini & Claude)

**Caratteristiche**:
- ✅ Production-tested (450+ posts generati)
- ✅ Success rate: 98.7%
- ✅ Cost-optimized (Gemini 75% più economico)
- ✅ Complete automation (scheduling, deduplication, logging)
- ✅ Documentazione completa con metriche reali

**Vedi**: `workflows/Personal_Examples/README.md` per guida dettagliata.

---

## 💡 Esempi di Utilizzo

### Esempio 1: Generazione Workflow Semplice

**Richiesta:**
```
Crea un workflow che ogni giorno alle 9:00
legge gli articoli da un feed RSS e li salva in Airtable
```

**Claude genererà:**
- JSON completo del workflow
- Configurazione nodi corretta
- Connessioni tra nodi
- Best practices applicate

---

### Esempio 2: Content Automation

**Richiesta:**
```
Voglio automatizzare la creazione di post LinkedIn da articoli.
Stack: Gmail + Gemini + Airtable + LinkedIn
```

**Claude fornirà:**
- Pattern matching (Article to Social Post)
- Workflow JSON completo
- Configurazione Gemini ottimale (2.5 Flash)
- Sistema di deduplicazione
- Logging in Airtable

---

### Esempio 3: Selezione AI Model

**Richiesta:**
```
Quale modello AI devo usare per estrarre dati strutturati
da 1000 fatture PDF?
```

**Claude consiglierà:**
- Gemini 2.5 Flash (90% accuratezza, veloce)
- Se accuratezza < 95% → GPT-4o-mini
- Pattern: Batch processing + error handling

---

## 🎯 Capabilities della Skill

### 1. Workflow Generation
Claude può generare workflow JSON completi per:
- ✅ Content automation (social media, newsletter)
- ✅ Email management (classificazione, auto-reply)
- ✅ Document processing (analisi, estrazione)
- ✅ Data pipelines (ETL, enrichment)
- ✅ Integration workflows (API, multi-system)
- ✅ Monitoring & alerts

### 2. AI Model Selection
Claude sa consigliare il modello ottimale:
- **Gemini 2.5 Flash** (default, 90% dei casi)
- **Gemini 2.5 Pro** (complex reasoning, vision)
- **GPT-4o** (massima accuratezza structured output)
- **Claude** (long documents >50k tokens)
- **Perplexity** (web search, current events)

### 3. Stack Recommendation
Claude identifica lo stack giusto:
- **Personal Stack**: Google Workspace + Airtable
  - Gmail, Google Sheets/Docs/Drive, Calendar
  - Airtable (database flessibile)
  - LinkedIn, YouTube, RSS

- **Enterprise Stack**: Microsoft 365
  - Outlook, Teams, OneDrive, SharePoint
  - Office (Word, Excel, PowerPoint)

### 4. Pattern Recognition
Claude riconosce e applica pattern:
- Content automation (Article → Post)
- Batch processing (1000 items)
- Deduplication strategy
- Error handling
- Human-in-the-loop
- Progressive enrichment

### 5. Best Practices
Claude applica automaticamente:
- Naming conventions italiane
- Error handling
- Cost optimization (Gemini primary)
- Performance optimization
- Security best practices

---

## 🔧 Use Cases Supportati

### Personal/Content Creator
1. **Social Media Automation**
   - Email → AI → LinkedIn/Twitter
   - YouTube → AI → Multi-platform post
   - RSS → Curated newsletter

2. **Research Automation**
   - Web scraping → AI summary → Database
   - Perplexity research → Gemini content

3. **Personal CRM**
   - Email → Contact extraction → Airtable
   - Meeting notes → Action items → Tasks

### Enterprise/Business
1. **Meeting Automation**
   - Calendar trigger → Context gathering → AI prep → Distribution

2. **Document Intelligence**
   - Contract upload → AI analysis → Risk flagging → Review

3. **Customer Support**
   - Email classification → Auto-response → SLA tracking

4. **Sales Automation**
   - Lead enrichment → AI scoring → CRM update → Notification

---

## 🎓 Come Ottenere il Massimo

### Best Practices per Richieste

#### ❌ Richiesta Vaga
```
"Crea un workflow per le email"
```

#### ✅ Richiesta Specifica
```
"Crea un workflow che:
- Trigger: Nuove email Gmail con label 'Articoli'
- Estrae il contenuto
- Usa Gemini per categorizzare (Analisi/Tutorial/News)
- Genera un post LinkedIn (200 parole)
- Salva in Airtable con status 'Draft'
- Mi invia notifica Slack"
```

**Risultato:** Claude genererà workflow completo e ottimizzato.

---

### Informazioni Utili da Fornire

1. **Trigger Type**
   - Schedule (quando? ogni ora? giornaliero?)
   - Email (Gmail/Outlook? filtri?)
   - Webhook
   - Manual

2. **Data Sources**
   - Da dove arrivano i dati?
   - Formato (JSON, email, PDF, etc.)

3. **Processing Requirements**
   - Cosa deve fare l'AI?
   - Categorizzazione? Generazione? Estrazione?

4. **Output/Destination**
   - Dove vanno i risultati?
   - Airtable? Google Sheets? Email?

5. **Stack Preference** (opzionale)
   - Personal (Google) o Enterprise (Microsoft)?

---

## 📖 Guide di Riferimento

### AI Models
- **Gemini 2.5 Flash**: DEFAULT per 90% workflow
  - Content generation, categorization, fast processing
  - Ottimo rapporto qualità/velocità

- **Gemini 2.5 Pro**: Complex tasks
  - Long documents (>50k tokens)
  - Image/video analysis
  - Maximum quality reasoning

- **GPT-4o-mini**: Accuracy focus
  - Structured data extraction
  - Complex JSON parsing

Consultare: `references/ai-models/model-selection-matrix.md`

### Workflow Patterns
Pattern più comuni:
1. Content Automation (Email/RSS → AI → Social)
2. Document Analysis (Upload → AI → Database)
3. Batch Processing (Split → Process → Merge)
4. Email Intelligence (Classify → Route → Respond)

Consultare: `references/workflow-patterns.md`

### Core Concepts
- Expression syntax: `={{ $json.field }}`
- Node structure e connections
- Credential management
- Error handling

Consultare: `references/core-concepts.md`

---

## 🚨 Troubleshooting

### Claude non trova la skill
- Verifica path installazione
- Riavvia Claude Code
- Controlla che SKILL.md esista

### Workflow generato non funziona
- Chiedi a Claude di validare il JSON
- Verifica credential IDs (placeholder)
- Testa node per node in n8n

### Modello AI sbagliato
- Specifica nella richiesta: "Usa Gemini 2.5 Flash"
- Claude default è sempre Gemini (ottimale)

---

## 🔄 Aggiornamenti e Manutenzione

### Come Aggiornare la Skill

1. Nuovi template workflow:
   - Aggiungi JSON in `assets/templates/`

2. Nuovi pattern:
   - Documenta in `references/workflow-patterns.md`

3. Nuovi nodi:
   - Aggiungi guide in `references/ai-nodes/` o `references/core-nodes/`

### Contribuire

Questa skill è basata su:
- Analisi di 2056 workflow community
- 1083 workflow AI-powered
- Best practices n8n

Per miglioramenti, documenta:
- Nuovi pattern trovati
- Edge cases
- Ottimizzazioni

---

## 💰 Cost Optimization

### Default Strategy (Built-in)
Claude usa sempre **Gemini 2.5 Flash** come default:
- Fast (100 tokens/sec)
- Eccellente qualità
- Ottimo costo/performance

### Quando Upgrade a Gemini 2.5 Pro
Claude suggerirà automaticamente quando:
- Long documents (>50k tokens)
- Vision tasks (images/video)
- Complex reasoning chains

### Hybrid Approach
Per grandi volumi, Claude può suggerire:
```
1000 items → Gemini 2.5 Flash (categorize/score)
Filter top 100 (uncertain) → Gemini 2.5 Pro (analyze)
Result: Speed + accuracy where needed
```

---

## 📊 Metrics & Performance

### Cosa Trackare
Claude può aiutarti a implementare:
- Workflow execution count
- Success/failure rate
- Processing time
- AI model costs
- Quality scores

### Dashboard Suggestions
Claude può generare workflow per:
- Daily/weekly reports (Airtable → Google Sheets → Email)
- Real-time monitoring (Slack notifications)
- Cost tracking (by model/workflow)

---

## 🎯 Next Steps

### 1. Testa con Workflow Semplice
```
"Crea un workflow che invia email ogni lunedì mattina con reminder"
```

### 2. Prova Content Automation
```
"Setup: Gmail → Gemini → Airtable → LinkedIn per articoli"
```

### 3. Esplora Pattern Avanzati
```
"Mostrami pattern per processing 1000 email in batch con AI"
```

### 4. Ottimizza Workflow Esistenti
```
"Ho questo workflow [incolla JSON]. Come posso ottimizzarlo?"
```

---

## 🤝 Support

### Risorse
- **N8N Docs**: https://docs.n8n.io
- **N8N Community**: https://community.n8n.io
- **Skill Location**: `n8n-ai-workflow-expert/SKILL.md`

### Common Commands

**Chiedere un workflow:**
```
"Crea workflow per [obiettivo] usando [stack]"
```

**Validare JSON:**
```
"Valida questo workflow n8n: [JSON]"
```

**Ottimizzare:**
```
"Come posso migliorare questo workflow? [JSON]"
```

**Debug:**
```
"Questo workflow non funziona: [error]. Aiutami a debuggare."
```

**Selezione Model:**
```
"Quale AI model devo usare per [task]?"
```

---

## 📝 Version

- **Version**: 1.0.0
- **Last Updated**: 2025-01-19
- **AI Models**: Gemini 2.5 (primary), OpenAI, Claude, Perplexity
- **Workflows Analyzed**: 2056 (1083 AI-powered)
- **Primary Stack**: Personal (Google + Airtable) & Enterprise (Microsoft 365)

---

## ✨ Key Features Summary

✅ **Instant workflow generation** - JSON completo in secondi
✅ **AI model optimization** - Gemini 2.5 primary (cost-effective)
✅ **Dual-stack support** - Personal & Enterprise
✅ **Pattern library** - 2056+ workflow examples
✅ **Best practices built-in** - Security, performance, error handling
✅ **Italian-first** - Naming conventions e documentation
✅ **Cost-conscious** - Always suggests optimal model
✅ **Production-ready** - Testato su use case reali

---

**Ready to automate? Ask Claude to create your first n8n workflow! 🚀**
