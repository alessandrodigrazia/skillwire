# Practical Workflow Search Examples

This guide shows **concrete examples** of how Claude can search and use the 2049 available workflows.

---

## Featured Production Examples

**First of all**: If you're looking for examples of **LinkedIn content automation**, go directly to:
→ `workflows/Personal_Examples/README.md`

**6 production-tested workflows**:
- Article → LinkedIn Post (Gemini & Claude versions)
- Video → LinkedIn Post (Gemini & Claude versions)
- RSS Feed → LinkedIn Post (Gemini & Claude versions)

**Real metrics**: 450+ posts, 98.7% success rate, $3.38 costs in 6 months.

---

## Example 1: "I want to create a Telegram bot with AI"

### User Request
```
User: How do I create a Telegram bot that responds with AI?
```

### Claude's Process

**Step 1: Load Index**
```javascript
const index = await read('references/index/workflow-metadata.json');
console.log(`Total workflows: ${index.total_workflows}`); // 2049
```

**Step 2: Search for Relevant Pattern**
```javascript
const telegramAI = index.workflows.filter(w =>
  // Search for Telegram nodes
  w.nodes_types.some(n => n.toLowerCase().includes('telegram')) &&
  // With AI
  w.has_ai === true
);

console.log(`Found ${telegramAI.length} Telegram + AI workflows`);
// Output: Found 12 Telegram + AI workflows
```

**Step 3: Select Top 3 Examples**
```javascript
// Vary by complexity
const simple = telegramAI.find(w => w.complexity === 'simple');
const medium = telegramAI.find(w => w.complexity === 'medium');
const complex = telegramAI.find(w => w.complexity === 'complex');

const examples = [simple, medium, complex].filter(Boolean);
```

**Step 4: Read Full Workflows**
```javascript
for (const ex of examples) {
  const workflow = await read(ex.file_path);

  // Extract relevant nodes
  const telegramNode = workflow.nodes.find(n =>
    n.type.includes('telegram')
  );
  const aiNode = workflow.nodes.find(n =>
    n.type.includes('langchain')
  );

  console.log(`Example: ${ex.name}`);
  console.log(`- File: ${ex.file_path}`);
  console.log(`- AI Model: ${ex.ai_models.join(', ')}`);
  console.log(`- Nodes: ${ex.nodes_count}`);
}
```

**Step 5: Present to User**
```markdown
I found 12 examples of Telegram bots with AI. Here are the 3 most representative:

### 1. Simple Bot (5 nodes)
**File**: workflows/Telegram/0800_Aggregate_Telegram_Automate_Triggered.json
**Pattern**: Telegram Trigger → AI response → Send reply

**AI Model used**: gemini-2.0-flash-exp
**Recommendation**: Upgrade to `models/gemini-2.5-flash` for better performance

**Configuration**:
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.telegramTrigger",
      "parameters": {
        "updates": ["message"]
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
      "parameters": {
        "modelName": "models/gemini-2.5-flash"
      }
    }
  ]
}
```

Which example would you like to explore in detail?
```

---

## Example 2: "Examples of data extraction from email"

### User Request
```
User: I need to extract structured data from emails
```

### Claude's Process

**Step 1: Search Pattern**
```javascript
const emailExtraction = index.workflows.filter(w =>
  w.key_patterns?.includes('structured-extraction') &&
  (w.trigger_types?.includes('email') ||
   w.key_patterns?.includes('email-to-database'))
);

console.log(`Found ${emailExtraction.length} examples`);
// Output: 17 examples
```

**Step 2: Group by AI Model**
```javascript
const byModel = {};
emailExtraction.forEach(w => {
  w.ai_models.forEach(model => {
    if (!byModel[model]) byModel[model] = [];
    byModel[model].push(w);
  });
});

console.log('Model distribution:');
console.log(`- Gemini: ${(byModel['gemini-2.0-flash'] || []).length}`);
console.log(`- GPT-4o-mini: ${(byModel['gpt-4o-mini'] || []).length}`);
console.log(`- GPT-4o: ${(byModel['gpt-4o'] || []).length}`);
```

**Step 3: Show Different Approaches**
```javascript
// Approach 1: Gemini (most economical)
const geminiExample = emailExtraction.find(w =>
  w.ai_models.some(m => m.includes('gemini'))
);

// Approach 2: OpenAI (most accurate)
const openaiExample = emailExtraction.find(w =>
  w.ai_models.includes('gpt-4o-mini')
);

// Approach 3: Simplest
const simpleExample = emailExtraction.find(w =>
  w.complexity === 'simple'
);
```

**Step 4: Present with Comparison**
```markdown
I found 17 email data extraction workflows. Here are 3 different approaches:

### Approach 1: Gemini 2.5 Flash (Recommended - Economical)
**Cost**: ~$0.01 per 100 emails
**Accuracy**: 94%
**File**: workflows/Aggregate/0472_Aggregate_Gmail_Create_Triggered.json

**Pattern**:
Gmail Trigger → Gemini 2.5 Flash → Structured Parser → Airtable

### Approach 2: GPT-4o-mini (More Accurate)
**Cost**: ~$0.02 per 100 emails
**Accuracy**: 96%
**File**: workflows/Gmail/1324_Aggregate_Gmail_Send_Triggered.json

**Pattern**:
Gmail Trigger → GPT-4o-mini → Validation → Airtable → Confirmation Email

### Approach 3: Simple (Entry-Level)
**Cost**: ~$0.01 per 100 emails
**File**: workflows/Email/simple-extraction.json

**Which do you prefer?** I can show you the complete configuration.
```

---

## Example 3: "AI Agent with multiple tools"

### User Request
```
User: I want an AI agent that can search the web, query a database, and do calculations
```

### Claude's Process

**Step 1: Search Complex Agents**
```javascript
const complexAgents = index.workflows.filter(w =>
  w.key_patterns?.includes('ai-agent') &&
  w.nodes_count > 7  // Implies multiple tools
);

console.log(`Found ${complexAgents.length} complex agents`);
```

**Step 2: Identify Tool Combinations**
```javascript
complexAgents.forEach(w => {
  // Count tool types
  const tools = w.nodes_types.filter(n =>
    n.includes('tool')
  );

  console.log(`${w.id}: ${tools.length} tools`);
  console.log(`Tools: ${tools.join(', ')}`);
});
```

**Step 3: Find Best Match**
```javascript
const multiTool = complexAgents.find(w => {
  const nodes = w.nodes_types.join(',');
  return nodes.includes('toolHttpRequest') &&  // Web search
         nodes.includes('toolWorkflow') &&     // Database query
         nodes.includes('toolCode');           // Calculations
});
```

**Step 4: Extract Configuration**
```javascript
const workflow = await read(multiTool.file_path);

const agentNode = workflow.nodes.find(n => n.type.includes('agent'));
const tools = workflow.nodes.filter(n => n.type.includes('tool'));

console.log('Agent System Message:', agentNode.parameters.options.systemMessage);
console.log('Configured tools:');
tools.forEach(t => {
  console.log(`- ${t.name}: ${t.parameters.description}`);
});
```

**Step 5: Present Complete Example**
```markdown
I found an example that does exactly what you're asking for.

**File**: workflows/Aggregate/1404_Aggregate_Telegram_Automation_Triggered.json

**Architecture**:
```
Telegram Trigger →
AI Agent (Gemini 2.5 Flash) →
  ├─ Tool 1: HTTP Request (Web Search)
  ├─ Tool 2: Workflow Call (Database Query)
  └─ Tool 3: Code (Calculations)
→ Response to User
```

**Agent Configuration**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.agent",
  "parameters": {
    "options": {
      "systemMessage": "You are a helpful assistant with access to:\n- Web search for current information\n- Database queries for historical data\n- Calculator for complex computations"
    }
  }
}
```

**Tool 1: Web Search**
```json
{
  "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
  "parameters": {
    "name": "web_search",
    "description": "Search the web for current information",
    "method": "GET",
    "url": "=https://api.search.com/query?q={{ $json.query }}"
  }
}
```

**Tool 2: Database Query**
```json
{
  "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
  "parameters": {
    "name": "database_query",
    "description": "Query internal database for records",
    "workflowId": "123"
  }
}
```

**Tool 3: Calculator**
```json
{
  "type": "@n8n/n8n-nodes-langchain.toolCode",
  "parameters": {
    "name": "calculator",
    "description": "Perform mathematical calculations",
    "jsCode": "return { result: eval($input.first().json.expression) };"
  }
}
```

**Would you like me to adapt this example to your specific use case?**
```

---

## Example 4: "Daily scheduling workflow"

### User Request
```
User: How do I make a workflow that runs every day at 9 AM?
```

### Claude's Process

**Step 1: Search Scheduled Workflows**
```javascript
const scheduled = index.workflows.filter(w =>
  w.trigger_types?.includes('schedule')
);

console.log(`Found ${scheduled.length} scheduled workflows`);
```

**Step 2: Filter by Simplicity**
```javascript
const simpleScheduled = scheduled.filter(w =>
  w.complexity === 'simple'
).slice(0, 5);
```

**Step 3: Read Example**
```javascript
const example = simpleScheduled[0];
const workflow = await read(example.file_path);

const scheduleNode = workflow.nodes.find(n =>
  n.type === 'n8n-nodes-base.scheduleTrigger'
);

console.log('Schedule config:', scheduleNode.parameters);
```

**Step 4: Present Configuration**
```markdown
Here's how to configure a schedule trigger for 9 AM daily:

**Configuration**:
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.scheduleTrigger",
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "cronExpression",
              "expression": "0 9 * * *"
            }
          ]
        },
        "triggerTimes": {
          "item": [
            {
              "mode": "everyDay",
              "hour": 9,
              "minute": 0
            }
          ]
        }
      },
      "name": "Daily 9 AM Trigger"
    }
  ]
}
```

**Alternatives**:
- Cron expression: `0 9 * * *` (9 AM every day)
- Interval mode: Every day at 9:00
- Timezone: Automatically server UTC

**Community examples**:
- Found ${scheduled.length} scheduled workflows
- Common patterns: daily reports, data sync, cleanup tasks
```

---

## Example 5: "Modernize old workflow"

### User Request
```
User: I have a workflow that uses gemini-1.5-flash, how do I update it?
```

### Claude's Process

**Step 1: Find Workflows with Old Models**
```javascript
const oldGemini = index.workflows.filter(w =>
  w.ai_models.some(m =>
    m.includes('gemini-1.5') ||
    m.includes('gemini-2.0') ||
    m.includes('gemini-flash-lite')
  )
);

console.log(`Found ${oldGemini.length} workflows to modernize`);
```

**Step 2: Show Upgrade Path**
```markdown
I found ${oldGemini.length} workflows that use old Gemini versions.

**Old models → New models**:

| Old | New | Benefits |
|-----|-----|----------|
| `gemini-1.5-flash` | `models/gemini-2.5-flash` | +30% speed, -20% cost |
| `gemini-1.5-pro` | `models/gemini-2.5-pro` | 2M context (vs 1M) |
| `gemini-2.0-flash-exp` | `models/gemini-2.5-flash` | Stable version |
| `gemini-2.0-flash-lite` | `models/gemini-2.5-flash` | Deprecated |

**Required change**:

Before:
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "gemini-1.5-flash"
  }
}
```

After:
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "models/gemini-2.5-flash",
    "options": {
      "temperature": 0.7,
      "maxOutputTokens": 2048
    }
  }
}
```

**Estimated savings**: 20-30% on API costs
```

---

## Database Statistics

**Available workflows**: 2049
**Categories**: 187
**AI-powered**: 796 (39%)
**Unique nodes**: 502

**Top Patterns**:
1. ai-agent: 376 workflows
2. structured-extraction: 154 workflows
3. email-to-database: 13 workflows
4. ai-content-generation: 11 workflows

**Top AI Models**:
1. gpt-4o-mini: 249 workflows
2. gpt-4o: 95 workflows
3. gemini-2.0-flash-exp: 65 workflows
4. gemini-2.0-flash: 29 workflows

---

## Tips for Effective Search

### Best Practices

1. **Always start with the index**
   - Don't read files randomly
   - Filter first, read later

2. **Limit file reads**
   - Max 3-5 workflows per query
   - Show variety (simple, medium, complex)

3. **Show file path**
   - User can explore on their own
   - Useful for future reference

4. **Suggest modernizations**
   - Identify old models
   - Propose upgrades when appropriate

5. **Explain patterns**
   - Don't just show JSON
   - Explain why it works

### Things to Avoid

1. Don't read all files
2. Don't assume one example = best practice
3. Don't ignore context (complexity, use case)
4. Don't show only code without explanation

---

## Utilities for the User

### Search Test
```bash
cd n8n-ai-workflow-expert
python scripts/search-workflows.py --pattern ai-agent --limit 5
```

### Extract Configuration
```bash
python scripts/search-workflows.py --node-type telegram --has-ai --export results.json
```

---

**For Claude**: Use these examples as templates when the user asks for workflows. Adapt the search process to the specific request, but always follow the pattern: **Index → Filter → Read → Present**.
