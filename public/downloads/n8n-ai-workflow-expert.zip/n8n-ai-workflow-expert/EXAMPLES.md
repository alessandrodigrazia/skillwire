# 📚 Esempi Pratici di Ricerca Workflow

Questa guida mostra **esempi concreti** di come Claude può cercare e utilizzare i 2049 workflow disponibili.

---

## 🌟 Featured Production Examples

**Prima di tutto**: Se cerchi esempi di **LinkedIn content automation**, vai direttamente a:
→ `workflows/Personal_Examples/README.md`

**6 workflow production-tested**:
- Articolo → Post LinkedIn (Gemini & Claude)
- Video → Post LinkedIn (Gemini & Claude)
- RSS Feed → Post LinkedIn (Gemini & Claude)

**Metriche reali**: 450+ posts, 98.7% success rate, $3.38 costi in 6 mesi.

---

## Esempio 1: "Voglio creare un bot Telegram con AI"

### Richiesta User
```
User: Come creo un bot Telegram che risponde con AI?
```

### Processo di Claude

**Step 1: Carica Index**
```javascript
const index = await read('references/index/workflow-metadata.json');
console.log(`Total workflows: ${index.total_workflows}`); // 2049
```

**Step 2: Cerca Pattern Rilevante**
```javascript
const telegramAI = index.workflows.filter(w =>
  // Cerca nodi Telegram
  w.nodes_types.some(n => n.toLowerCase().includes('telegram')) &&
  // Con AI
  w.has_ai === true
);

console.log(`Trovati ${telegramAI.length} workflow Telegram + AI`);
// Output: Trovati 12 workflow Telegram + AI
```

**Step 3: Seleziona Top 3 Esempi**
```javascript
// Varia per complessità
const simple = telegramAI.find(w => w.complexity === 'simple');
const medium = telegramAI.find(w => w.complexity === 'medium');
const complex = telegramAI.find(w => w.complexity === 'complex');

const examples = [simple, medium, complex].filter(Boolean);
```

**Step 4: Leggi Workflow Completi**
```javascript
for (const ex of examples) {
  const workflow = await read(ex.file_path);

  // Estrai nodi rilevanti
  const telegramNode = workflow.nodes.find(n =>
    n.type.includes('telegram')
  );
  const aiNode = workflow.nodes.find(n =>
    n.type.includes('langchain')
  );

  console.log(`Esempio: ${ex.name}`);
  console.log(`- File: ${ex.file_path}`);
  console.log(`- AI Model: ${ex.ai_models.join(', ')}`);
  console.log(`- Nodes: ${ex.nodes_count}`);
}
```

**Step 5: Presenta a User**
```markdown
Ho trovato 12 esempi di bot Telegram con AI. Ecco i 3 più rappresentativi:

### 1️⃣ Bot Semplice (5 nodi)
**File**: workflows/Telegram/0800_Aggregate_Telegram_Automate_Triggered.json
**Pattern**: Trigger Telegram → AI response → Invia risposta

**AI Model usato**: gemini-2.0-flash-exp
⚠️ **Raccomandazione**: Aggiorna a `models/gemini-2.5-flash` per performance migliori

**Configurazione**:
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.telegramTrigger",
      "parameters": {
        "updates": ["message"]
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
      "parameters": {
        "modelName": "models/gemini-2.5-flash"
      }
    }
  ]
}
```

Quale esempio vuoi esplorare in dettaglio?
```

---

## Esempio 2: "Esempi di estrazione dati da email"

### Richiesta User
```
User: Ho bisogno di estrarre dati strutturati dalle email
```

### Processo di Claude

**Step 1: Cerca Pattern**
```javascript
const emailExtraction = index.workflows.filter(w =>
  w.key_patterns?.includes('structured-extraction') &&
  (w.trigger_types?.includes('email') ||
   w.key_patterns?.includes('email-to-database'))
);

console.log(`Trovati ${emailExtraction.length} esempi`);
// Output: 17 esempi
```

**Step 2: Raggruppa per AI Model**
```javascript
const byModel = {};
emailExtraction.forEach(w => {
  w.ai_models.forEach(model => {
    if (!byModel[model]) byModel[model] = [];
    byModel[model].push(w);
  });
});

console.log('Distribuzione modelli:');
console.log(`- Gemini: ${(byModel['gemini-2.0-flash'] || []).length}`);
console.log(`- GPT-4o-mini: ${(byModel['gpt-4o-mini'] || []).length}`);
console.log(`- GPT-4o: ${(byModel['gpt-4o'] || []).length}`);
```

**Step 3: Mostra Diversi Approcci**
```javascript
// Approccio 1: Gemini (più economico)
const geminiExample = emailExtraction.find(w =>
  w.ai_models.some(m => m.includes('gemini'))
);

// Approccio 2: OpenAI (più accurato)
const openaiExample = emailExtraction.find(w =>
  w.ai_models.includes('gpt-4o-mini')
);

// Approccio 3: Più semplice
const simpleExample = emailExtraction.find(w =>
  w.complexity === 'simple'
);
```

**Step 4: Presenta con Confronto**
```markdown
Ho trovato 17 workflow di estrazione dati da email. Ecco 3 approcci diversi:

### Approccio 1: Gemini 2.5 Flash (Raccomandato - Economico)
**Costo**: ~$0.01 per 100 email
**Accuracy**: 94%
**File**: workflows/Aggregate/0472_Aggregate_Gmail_Create_Triggered.json

**Pattern**:
Gmail Trigger → Gemini 2.5 Flash → Structured Parser → Airtable

### Approccio 2: GPT-4o-mini (Più Accurato)
**Costo**: ~$0.02 per 100 email
**Accuracy**: 96%
**File**: workflows/Gmail/1324_Aggregate_Gmail_Send_Triggered.json

**Pattern**:
Gmail Trigger → GPT-4o-mini → Validation → Airtable → Confirmation Email

### Approccio 3: Semplice (Entry-Level)
**Costo**: ~$0.01 per 100 email
**File**: workflows/Email/simple-extraction.json

**Quale preferisci?** Posso mostrarti la configurazione completa.
```

---

## Esempio 3: "AI Agent con multiple tools"

### Richiesta User
```
User: Voglio un AI agent che possa cercare su web, queryare database, e fare calcoli
```

### Processo di Claude

**Step 1: Cerca Agenti Complessi**
```javascript
const complexAgents = index.workflows.filter(w =>
  w.key_patterns?.includes('ai-agent') &&
  w.nodes_count > 7  // Implica multiple tools
);

console.log(`Trovati ${complexAgents.length} agent complessi`);
```

**Step 2: Identifica Tool Combinations**
```javascript
complexAgents.forEach(w => {
  // Conta tool types
  const tools = w.nodes_types.filter(n =>
    n.includes('tool')
  );

  console.log(`${w.id}: ${tools.length} tools`);
  console.log(`Tools: ${tools.join(', ')}`);
});
```

**Step 3: Trova Best Match**
```javascript
const multiTool = complexAgents.find(w => {
  const nodes = w.nodes_types.join(',');
  return nodes.includes('toolHttpRequest') &&  // Web search
         nodes.includes('toolWorkflow') &&     // Database query
         nodes.includes('toolCode');           // Calculations
});
```

**Step 4: Estrai Configurazione**
```javascript
const workflow = await read(multiTool.file_path);

const agentNode = workflow.nodes.find(n => n.type.includes('agent'));
const tools = workflow.nodes.filter(n => n.type.includes('tool'));

console.log('Agent System Message:', agentNode.parameters.options.systemMessage);
console.log('Tools configurati:');
tools.forEach(t => {
  console.log(`- ${t.name}: ${t.parameters.description}`);
});
```

**Step 5: Presenta Esempio Completo**
```markdown
Perfetto! Ho trovato un esempio che fa esattamente quello che chiedi.

**File**: workflows/Aggregate/1404_Aggregate_Telegram_Automation_Triggered.json

**Architettura**:
```
Telegram Trigger →
AI Agent (Gemini 2.5 Flash) →
  ├─ Tool 1: HTTP Request (Web Search)
  ├─ Tool 2: Workflow Call (Database Query)
  └─ Tool 3: Code (Calculations)
→ Response to User
```

**Configurazione Agent**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.agent",
  "parameters": {
    "options": {
      "systemMessage": "You are a helpful assistant with access to:\n- Web search for current information\n- Database queries for historical data\n- Calculator for complex computations"
    }
  }
}
```

**Tool 1: Web Search**
```json
{
  "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
  "parameters": {
    "name": "web_search",
    "description": "Search the web for current information",
    "method": "GET",
    "url": "=https://api.search.com/query?q={{ $json.query }}"
  }
}
```

**Tool 2: Database Query**
```json
{
  "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
  "parameters": {
    "name": "database_query",
    "description": "Query internal database for records",
    "workflowId": "123"
  }
}
```

**Tool 3: Calculator**
```json
{
  "type": "@n8n/n8n-nodes-langchain.toolCode",
  "parameters": {
    "name": "calculator",
    "description": "Perform mathematical calculations",
    "jsCode": "return { result: eval($input.first().json.expression) };"
  }
}
```

**Vuoi che adatti questo esempio al tuo use case specifico?**
```

---

## Esempio 4: "Workflow scheduling giornaliero"

### Richiesta User
```
User: Come faccio un workflow che gira ogni giorno alle 9 AM?
```

### Processo di Claude

**Step 1: Cerca Scheduled Workflows**
```javascript
const scheduled = index.workflows.filter(w =>
  w.trigger_types?.includes('schedule')
);

console.log(`Trovati ${scheduled.length} workflow schedulati`);
```

**Step 2: Filtra per Semplicità**
```javascript
const simpleScheduled = scheduled.filter(w =>
  w.complexity === 'simple'
).slice(0, 5);
```

**Step 3: Leggi Esempio**
```javascript
const example = simpleScheduled[0];
const workflow = await read(example.file_path);

const scheduleNode = workflow.nodes.find(n =>
  n.type === 'n8n-nodes-base.scheduleTrigger'
);

console.log('Schedule config:', scheduleNode.parameters);
```

**Step 4: Presenta Configurazione**
```markdown
Ecco come configurare uno schedule trigger per le 9 AM giornaliere:

**Configurazione**:
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.scheduleTrigger",
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "cronExpression",
              "expression": "0 9 * * *"
            }
          ]
        },
        "triggerTimes": {
          "item": [
            {
              "mode": "everyDay",
              "hour": 9,
              "minute": 0
            }
          ]
        }
      },
      "name": "Daily 9 AM Trigger"
    }
  ]
}
```

**Alternative**:
- Cron expression: `0 9 * * *` (9 AM ogni giorno)
- Interval mode: Every day at 9:00
- Timezone: Automaticamente UTC del server

**Esempi dalla community**:
- Trovati ${scheduled.length} workflow schedulati
- Pattern comuni: daily reports, data sync, cleanup tasks
```

---

## Esempio 5: "Modernizza vecchio workflow"

### Richiesta User
```
User: Ho un workflow che usa gemini-1.5-flash, come lo aggiorno?
```

### Processo di Claude

**Step 1: Trova Workflow con Vecchi Modelli**
```javascript
const oldGemini = index.workflows.filter(w =>
  w.ai_models.some(m =>
    m.includes('gemini-1.5') ||
    m.includes('gemini-2.0') ||
    m.includes('gemini-flash-lite')
  )
);

console.log(`Trovati ${oldGemini.length} workflow da modernizzare`);
```

**Step 2: Mostra Upgrade Path**
```markdown
Ho trovato ${oldGemini.length} workflow che usano versioni vecchie di Gemini.

**Vecchi modelli → Nuovi modelli**:

| Vecchio | Nuovo | Benefici |
|---------|-------|----------|
| `gemini-1.5-flash` | `models/gemini-2.5-flash` | +30% velocità, -20% costo |
| `gemini-1.5-pro` | `models/gemini-2.5-pro` | 2M context (vs 1M) |
| `gemini-2.0-flash-exp` | `models/gemini-2.5-flash` | Versione stabile |
| `gemini-2.0-flash-lite` | `models/gemini-2.5-flash` | Deprecato |

**Modifica necessaria**:

Prima:
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "gemini-1.5-flash"
  }
}
```

Dopo:
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "models/gemini-2.5-flash",
    "options": {
      "temperature": 0.7,
      "maxOutputTokens": 2048
    }
  }
}
```

**Risparmio stimato**: 20-30% sui costi API
```

---

## 📊 Statistiche Database

**Workflow disponibili**: 2049
**Categorie**: 187
**AI-powered**: 796 (39%)
**Unique nodes**: 502

**Top Patterns**:
1. ai-agent: 376 workflow
2. structured-extraction: 154 workflow
3. email-to-database: 13 workflow
4. ai-content-generation: 11 workflow

**Top AI Models**:
1. gpt-4o-mini: 249 workflow
2. gpt-4o: 95 workflow
3. gemini-2.0-flash-exp: 65 workflow
4. gemini-2.0-flash: 29 workflow

---

## 🎯 Tips per Ricerca Efficace

### ✅ Best Practices

1. **Inizia sempre con index**
   - Non leggere file a caso
   - Filtra prima, leggi dopo

2. **Limita file reads**
   - Max 3-5 workflow per query
   - Mostra variety (simple, medium, complex)

3. **Mostra file path**
   - User può esplorare da solo
   - Utile per riferimento futuro

4. **Suggerisci modernizzazioni**
   - Identifica modelli vecchi
   - Proponi upgrade quando appropriato

5. **Spiega pattern**
   - Non solo mostra JSON
   - Spiega perché funziona

### ❌ Da Evitare

1. Non leggere tutti i file
2. Non assumere che un esempio = best practice
3. Non ignorare context (complexity, use case)
4. Non mostrare solo codice senza spiegazione

---

## 🔧 Utility per User

### Test di Ricerca
```bash
cd n8n-ai-workflow-expert
python scripts/search-workflows.py --pattern ai-agent --limit 5
```

### Estrai Configurazione
```bash
python scripts/search-workflows.py --node-type telegram --has-ai --export results.json
```

---

**Per Claude**: Usa questi esempi come template quando user chiede workflow. Adatta il processo di ricerca alla richiesta specifica, ma segui sempre il pattern: **Index → Filter → Read → Present**.
