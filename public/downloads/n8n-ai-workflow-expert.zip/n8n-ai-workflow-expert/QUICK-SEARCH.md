# 🔍 Quick Search Guide for Claude

**Per Claude**: Questa guida ti spiega come cercare esempi nei **2054 workflow JSON disponibili**.

---

## ⚡ TL;DR - Come Cercare Velocemente

### 1️⃣ **Carica l'Index** (fallo sempre per primo)
```javascript
const index = await read('references/index/workflow-metadata.json');
// Contiene metadata di tutti 2054 workflows
```

### 2️⃣ **Filtra per Criterio**
```javascript
// Esempio: Trova AI agents con Gemini
const matches = index.workflows.filter(w =>
  w.key_patterns?.includes('ai-agent') &&
  w.ai_models?.some(m => m.includes('gemini'))
);
```

### 3️⃣ **Leggi Solo i File Rilevanti** (max 3-5)
```javascript
// Leggi il primo match
const workflow = await read(`workflows/${matches[0].file_path}`);
```

---

## 📊 Index Fields Reference

Ogni workflow nell'index ha:

```javascript
{
  "id": "0472_Aggregate_Gmail_Create_Triggered",
  "name": "Gmail to Airtable Extraction",
  "file_path": "Aggregate/0472_Aggregate_Gmail_Create_Triggered.json",
  "nodes_count": 8,
  "nodes_types": [
    "n8n-nodes-base.gmailTrigger",
    "@n8n/n8n-nodes-langchain.chainLlm",
    "n8n-nodes-base.airtable"
  ],
  "ai_nodes": [
    "@n8n/n8n-nodes-langchain.chainLlm",
    "@n8n/n8n-nodes-langchain.lmChatOpenAi"
  ],
  "ai_models": ["gpt-4o-mini"],
  "trigger_types": ["email"],
  "category": "aggregate",
  "has_ai": true,
  "complexity": "medium",
  "key_patterns": ["email-to-database", "structured-extraction"]
}
```

---

## 🎯 Common Search Patterns

### Pattern 1: Cerca per Use Case
```javascript
// User: "Mostrami esempio di estrazione dati da email"
const results = index.workflows.filter(w =>
  w.key_patterns?.includes('email-to-database') ||
  (w.trigger_types?.includes('email') && w.key_patterns?.includes('structured-extraction'))
);

// Prendi i top 3
const top3 = results.slice(0, 3);

// Leggi i workflow completi
for (const wf of top3) {
  const fullWorkflow = await read(`workflows/${wf.file_path}`);
  // Analizza e presenta
}
```

### Pattern 2: Cerca per AI Model
```javascript
// User: "Esempi con Gemini 2.5"
const geminWorkflows = index.workflows.filter(w =>
  w.ai_models?.some(m =>
    m.includes('gemini-2.5') ||
    m.includes('gemini-2.0')  // Include anche versioni da aggiornare
  )
);

console.log(`Trovati ${geminiWorkflows.length} workflow Gemini`);
```

### Pattern 3: Cerca per Nodi Specifici
```javascript
// User: "Workflow con Gmail + Airtable"
const results = index.workflows.filter(w => {
  const nodes = w.nodes_types.join(',').toLowerCase();
  return nodes.includes('gmail') && nodes.includes('airtable');
});
```

### Pattern 4: Cerca per Complessità
```javascript
// User: "Esempio semplice di AI agent"
const simpleAgents = index.workflows.filter(w =>
  w.key_patterns?.includes('ai-agent') &&
  w.complexity === 'simple'
);
```

### Pattern 5: Cerca per Categoria
```javascript
// User: "Workflow nella categoria Gmail"
const gmailWorkflows = index.workflows.filter(w =>
  w.category === 'gmail'
);
```

---

## 🚀 Workflow di Ricerca Consigliato

### Step 1: Comprendi Richiesta User
```
User: "Come creare un bot Telegram con AI?"

→ Keywords: telegram, ai, bot, agent
→ Pattern probabile: ai-agent
→ Node type: telegram
```

### Step 2: Query Index
```javascript
const matches = index.workflows.filter(w =>
  // Pattern match
  w.key_patterns?.includes('ai-agent') &&
  // Node match
  w.nodes_types.some(n => n.toLowerCase().includes('telegram'))
);

console.log(`Trovati ${matches.length} match`);
```

### Step 3: Seleziona Best Examples
```javascript
// Ordina per rilevanza
const sorted = matches.sort((a, b) => {
  // Preferisci complessità media (più educativo)
  const complexityScore = {simple: 0, medium: 1, complex: 0};
  return (complexityScore[b.complexity] || 0) - (complexityScore[a.complexity] || 0);
});

// Prendi top 3
const examples = sorted.slice(0, 3);
```

### Step 4: Leggi e Analizza
```javascript
for (const ex of examples) {
  console.log(`\nExample ${ex.id}:`);
  console.log(`- File: workflows/${ex.file_path}`);
  console.log(`- Nodes: ${ex.nodes_count}`);
  console.log(`- AI Models: ${ex.ai_models.join(', ')}`);

  // Leggi workflow completo
  const workflow = await read(`workflows/${ex.file_path}`);

  // Estrai configurazione rilevante
  const agentNode = workflow.nodes.find(n => n.type.includes('agent'));
  const telegramNode = workflow.nodes.find(n => n.type.includes('telegram'));

  // Presenta configurazione
}
```

### Step 5: Presenta a User
```markdown
Ho trovato 3 esempi di bot Telegram con AI:

**1. Esempio Semplice** (5 nodes)
File: `workflows/Telegram/1234_Telegram_Bot.json`
- Trigger: Telegram
- AI: gemini-2.0-flash-exp → **Raccomando aggiornare a gemini-2.5-flash**
- Pattern: Risposta semplice senza tools

**Configurazione chiave**:
[mostra snippet rilevante]

**2. Esempio con Tools** (10 nodes)
[...]
```

---

## 📋 Filtri Disponibili

### By Pattern (key_patterns)
- `"ai-agent"` - 381 workflows
- `"structured-extraction"` - 154 workflows
- `"email-to-database"` - 17 workflows
- `"ai-content-generation"` - 15 workflows
- `"scheduled-automation"` - vari

### By Complexity
- `"simple"` - < 3 nodes
- `"medium"` - 3-8 nodes
- `"complex"` - > 8 nodes

### By AI Presence
- `has_ai: true` - 801 workflows
- `has_ai: false` - 1253 workflows

### By Trigger Type
- `"email"` - 334 workflows (Gmail, Outlook)
- `"webhook"` - 145 workflows
- `"schedule"` - vari
- `"manual"` - vari
- `"chat"` - vari

### By AI Model
Top models disponibili:
- `"gpt-4o-mini"` - 249 workflows
- `"gpt-4o"` - 95 workflows
- `"gemini-2.0-flash-exp"` - 65 workflows
- `"gemini-2.0-flash"` - 29 workflows
- `"models/gemini-1.5-flash"` - 17 workflows

---

## ⚠️ Best Practices

### ✅ DO

1. **Sempre carica index prima** - Non cercare nei file direttamente
2. **Limita file reads** - Max 3-5 workflow per query
3. **Mostra file path** - User può esplorare se vuole
4. **Suggerisci modernizzazioni** - Se vedi vecchi modelli
5. **Varia esempi** - Mostra approcci diversi

### ❌ DON'T

1. **Non leggere tutti i file** - Usa index per filtrare
2. **Non ignorare complessità** - Mostra esempi progressivi
3. **Non solo un esempio** - Mostra 2-3 approcci
4. **Non assumere modello** - Verifica nell'index prima

---

## 🎯 Template Risposta

Quando user chiede esempio:

```markdown
Ho cercato nell'index di 2054 workflows e ho trovato **{N} esempi** rilevanti.

Ecco i {top 3} più rappresentativi:

### 1. {Nome Workflow} ({complexity})
**File**: `workflows/{file_path}`
**Nodi**: {nodes_count} | **Pattern**: {key_patterns}
**AI Model**: {ai_model} {se vecchio → suggerisci upgrade}

**Cosa fa**:
{descrizione basata su nodes}

**Configurazione chiave**:
```json
{snippet rilevante dal workflow}
```

**Quando usarlo**: {use case specifico}

---

### 2. {Secondo esempio - diverso approccio}
[...]

---

**Quale approccio preferisci?** Posso mostrarti la configurazione completa di uno specifico.
```

---

## 🔧 Utility Scripts

### Script 1: Search from CLI
```bash
cd n8n-ai-workflow-expert
python scripts/search-workflows.py --pattern ai-agent --model gemini --limit 5
```

### Script 2: Extract Node Config
```bash
python scripts/extract-node-config.py --workflow-id "0472_Aggregate_Gmail" --node-type "lmChatOpenAi"
```

---

## 📊 Quick Stats Reference

**Dataset Overview**:
- Total workflows: 2054
- AI-powered: 801 (39%)
- Unique node types: 502
- Categories: 187

**Top Patterns**:
1. ai-agent: 381 (19%)
2. structured-extraction: 154 (8%)
3. email-to-database: 17 (<1%)

**Top Nodes**:
1. Set: 2553 usages
2. HTTP Request: 2125
3. IF: 1102
4. Code: 1030
5. OpenAI Chat: 633

---

## 💡 Examples by Common Requests

### "Show me email automation"
```javascript
index.workflows.filter(w => w.trigger_types?.includes('email'))
// Returns: 334 workflows
```

### "AI content generation"
```javascript
index.workflows.filter(w => w.key_patterns?.includes('ai-content-generation'))
// Returns: 15 workflows
```

### "Simple Gmail to Airtable"
```javascript
index.workflows.filter(w =>
  w.category === 'gmail' &&
  w.nodes_types.some(n => n.includes('airtable')) &&
  w.complexity === 'simple'
)
```

### "Complex AI agents"
```javascript
index.workflows.filter(w =>
  w.key_patterns?.includes('ai-agent') &&
  w.complexity === 'complex' &&
  w.nodes_count > 10
)
```

---

## 🎓 Learning from Examples

### Beginner Query
User: "Primo workflow AI, cosa faccio?"

**Your Response**:
1. Cerca `complexity: "simple" && has_ai: true`
2. Trova 3-5 esempi entry-level
3. Mostra il più semplice (3-5 nodes)
4. Spiega ogni node
5. Suggerisci gemini-2.5-flash

### Intermediate Query
User: "Come strutturare estrazione dati?"

**Your Response**:
1. Cerca `key_patterns: "structured-extraction"`
2. Trova 154 esempi
3. Mostra 3 approcci diversi
4. Evidenzia best practices comuni
5. Template pronto all'uso

### Advanced Query
User: "Multi-tool agent con memoria e RAG"

**Your Response**:
1. Cerca `ai-agent + nodes_count > 10`
2. Filtra per presenza memory nodes
3. Cerca vector store integration
4. Mostra esempio completo
5. Spiega architettura

---

## ✅ Checklist per Ogni Ricerca

Prima di rispondere a user:

- [ ] Ho caricato `workflow-metadata.json`?
- [ ] Ho filtrato correttamente?
- [ ] Ho limitato a 3-5 esempi?
- [ ] Ho letto solo i file necessari?
- [ ] Ho mostrato i file path?
- [ ] Ho suggerito modernizzazioni se needed?
- [ ] Ho spiegato perché questi esempi?
- [ ] Ho offerto alternative?

---

**Remember**: L'index è la tua **mappa del tesoro**. I 2054 JSON sono il **tesoro**. Usa la mappa per trovare il tesoro giusto, non scavare ovunque! 🗺️💎
