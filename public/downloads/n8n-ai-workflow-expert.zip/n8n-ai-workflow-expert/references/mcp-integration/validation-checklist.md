# Validation Checklist

Checklist pre-output per workflow n8n generati. Usare `validate_workflow` MCP per verifica automatica.

## Pre-Validation Checklist (Manuale)

### 1. Struttura Base

- [ ] `name`: presente e descrittivo
- [ ] `nodes`: array non vuoto
- [ ] `connections`: oggetto presente
- [ ] `settings`: oggetto presente (può essere vuoto)
- [ ] `meta`: presente con `instanceId` (anche placeholder)

### 2. Ogni Nodo

- [ ] `id`: UUID univoco
- [ ] `name`: nome descrittivo univoco
- [ ] `type`: nome nodo valido (verificato con `get_node`)
- [ ] `typeVersion`: versione corretta per il nodo
- [ ] `position`: array `[x, y]` con coordinate valide
- [ ] `parameters`: oggetto con parametri richiesti

### 3. Connections

- [ ] Ogni connessione referenzia nodi esistenti
- [ ] Format: `"NomeNodo": { "main": [[{ "node": "AltroNodo", "type": "main", "index": 0 }]] }`
- [ ] Nessuna connessione orfana
- [ ] Trigger node non ha connessioni in ingresso

### 4. Parametri Nodi AI

- [ ] Credenziali referenziate (non hardcoded)
- [ ] `model` specificato per LLM nodes
- [ ] `systemMessage` presente se richiesto
- [ ] `options` configurate appropriatamente

### 5. Trigger Node

- [ ] Esattamente 1 trigger node (per workflow standard)
- [ ] Trigger è il primo nodo nella catena
- [ ] Nessuna connessione in ingresso al trigger

## Chiamata MCP validate_workflow

```javascript
// Validazione completa
validate_workflow({
  workflow: workflowJson,
  mode: "full"  // "full" | "structure" | "connections"
})
```

### Modalità Validazione

| Mode | Cosa Valida |
|------|-------------|
| `structure` | Solo struttura JSON base |
| `connections` | Connessioni tra nodi |
| `full` | Tutto (struttura + connections + parameters) |

## Errori Comuni e Fix

### ERR001: Node type not found

```
Errore: Node type "n8n-nodes-base.gmailTriggers" not found
Fix: Verificare nome esatto con search_nodes("gmail")
     Corretto: "n8n-nodes-base.gmailTrigger" (singolare)
```

### ERR002: Missing required parameter

```
Errore: Missing required parameter "resource" in node "Gmail"
Fix: get_node("n8n-nodes-base.gmail") → vedere required params
```

### ERR003: Connection to non-existent node

```
Errore: Connection references node "Email Parser" which doesn't exist
Fix: Verificare che tutti i nomi nelle connections matchino i nomi dei nodi
```

### ERR004: Duplicate node ID

```
Errore: Duplicate node ID "abc123"
Fix: Generare UUID univoci per ogni nodo
```

### ERR005: Invalid typeVersion

```
Errore: Invalid typeVersion 1 for node type that requires 2
Fix: get_node() → verificare versioneDefaults
```

## Template Workflow Minimo Valido

```json
{
  "name": "Workflow Name",
  "nodes": [
    {
      "id": "uuid-trigger",
      "name": "Manual Trigger",
      "type": "n8n-nodes-base.manualTrigger",
      "typeVersion": 1,
      "position": [240, 300],
      "parameters": {}
    },
    {
      "id": "uuid-action",
      "name": "Set",
      "type": "n8n-nodes-base.set",
      "typeVersion": 3.4,
      "position": [460, 300],
      "parameters": {
        "mode": "manual",
        "duplicateItem": false,
        "assignments": {
          "assignments": [
            {
              "name": "output",
              "value": "Hello World",
              "type": "string"
            }
          ]
        }
      }
    }
  ],
  "connections": {
    "Manual Trigger": {
      "main": [
        [
          {
            "node": "Set",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  },
  "settings": {
    "executionOrder": "v1"
  },
  "meta": {
    "instanceId": "placeholder"
  }
}
```

## Workflow Validazione Completo

```
1. Genera workflow JSON
         │
         ▼
2. validate_workflow(json, "structure")
         │
    ┌────┴────┐
    │ Errori? │
    └────┬────┘
     Sì  │  No
    ┌────┘    └────┐
    ▼              ▼
 Fix errori   validate_workflow(json, "connections")
    │              │
    └──────────────┘
                   │
              ┌────┴────┐
              │ Errori? │
              └────┬────┘
               Sì  │  No
              ┌────┘    └────┐
              ▼              ▼
           Fix errori   validate_workflow(json, "full")
              │              │
              └──────────────┘
                             │
                        ┌────┴────┐
                        │ Errori? │
                        └────┬────┘
                         Sì  │  No
                        ┌────┘    └────┐
                        ▼              ▼
                     Fix errori    OUTPUT
                        │
                        └──────────────→ Re-validate
```

## Note Finali

- **Sempre validare** prima di restituire un workflow all'utente
- **Fix automatico**: Se possibile, correggere errori senza chiedere all'utente
- **Fallback**: Se MCP non disponibile, usare checklist manuale
- **Logging**: Tenere traccia degli errori comuni per migliorare generazione
