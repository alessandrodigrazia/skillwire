# MCP Integration Guide

Guida per l'integrazione del server `czlonkowski/n8n-mcp` nel workflow di generazione n8n.

## Tool Disponibili (n8n-mcp v2.30.2)

| Tool | Descrizione | Quando Usarlo |
|------|-------------|---------------|
| `search_nodes` | Cerca nodi per keyword | Finding quale nodo usare per un task |
| `get_node` | Dettagli completi di un nodo | Ottenere schema parametri esatto |
| `list_nodes` | Lista tutti i nodi disponibili | Overview categorie disponibili |
| `search_templates` | Cerca workflow template | Trovare pattern simili |
| `get_template` | Dettagli template specifico | Estrarre configurazioni funzionanti |
| `validate_workflow` | Valida JSON workflow | QA finale pre-output |
| `get_stats` | Statistiche database | Debug e health check |

## Tool Priority Matrix

| Fase Workflow | Tool MCP Primario | Skill Reference Secondario |
|---------------|-------------------|---------------------------|
| Discovery | `search_nodes` | patterns-from-community/ |
| Architecture | `get_node` | workflow-patterns.md |
| Generation | `get_template` | ai-nodes/*.md |
| Validation | `validate_workflow` | error-handling.md |

## Workflow Operativo Standard

```
RICHIESTA UTENTE
       │
       ▼
┌──────────────────────────────────────┐
│ STEP 1: ANALISI (Skill Knowledge)    │
│ - Identificare pattern richiesto     │
│ - Selezionare AI model appropriato   │
│ - Determinare stack (personal/ent)   │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 2: NODE DISCOVERY (MCP)         │
│ - search_nodes("keyword")            │
│ - Identificare nodi candidati        │
│ - Verificare disponibilità           │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 3: TEMPLATE SEARCH (MCP + Repo) │
│ - search_templates("use case")       │
│ - Cercare in Zie619 repository       │
│ - Estrarre configurazioni simili     │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 4: NODE DETAILS (MCP)           │
│ - get_node("node-type") per ogni     │
│ - Estrarre schema parametri esatto   │
│ - Notare required vs optional        │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 5: GENERAZIONE JSON             │
│ - Applicare pattern da Skill         │
│ - Usare parametri esatti da MCP      │
│ - Configurare connections            │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 6: VALIDAZIONE (MCP)            │
│ - validate_workflow(json)            │
│ - Fix automatico errori              │
│ - Re-validate fino a clean           │
└──────────────────┬───────────────────┘
                   │
                   ▼
              OUTPUT JSON
```

## Best Practices

### 1. Sempre verificare nodi prima di generare

```
ERRATO:  Generare JSON con nodi "immaginati"
CORRETTO: get_node("n8n-nodes-base.gmail") → usare schema reale
```

### 2. Validare sempre prima di restituire

```
ERRATO:  Restituire JSON non validato
CORRETTO: validate_workflow() → fix → re-validate → output
```

### 3. Preferire template esistenti

```
ERRATO:  Generare tutto da zero
CORRETTO: search_templates() → adattare template funzionante
```

## Mapping Skill ↔ MCP

| Concetto Skill | Tool MCP Corrispondente |
|----------------|------------------------|
| Pattern Library | `search_templates` |
| Node Reference | `get_node` |
| Error Handling | `validate_workflow` |
| AI Model Selection | Skill-only (no MCP) |
| Connection Logic | Skill-only (no MCP) |

## Note Tecniche

- **Latenza MCP**: ~12ms per chiamata (self-hosted via npx)
- **Database**: 803 nodi n8n documentati
- **Fallback**: Se MCP non disponibile → usa solo Skill knowledge
- **Cache**: Database SQLite locale, nessuna chiamata API esterna
