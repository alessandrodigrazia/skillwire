# Node Lookup Workflow

Pattern di lookup per i nodi n8n più comuni usando il tool MCP `get_node`.

## Trigger Nodes

### Email Triggers

```
get_node("n8n-nodes-base.gmailTrigger")    # Gmail new email
get_node("n8n-nodes-base.imapEmail")        # Generic IMAP
get_node("n8n-nodes-base.microsoftOutlookTrigger")  # Outlook
```

### Webhook & Schedule

```
get_node("n8n-nodes-base.webhook")          # HTTP webhook
get_node("n8n-nodes-base.scheduleTrigger")  # Cron schedule
get_node("n8n-nodes-base.manualTrigger")    # Manual execution
```

### Chat Triggers

```
get_node("@n8n/n8n-nodes-langchain.chatTrigger")  # Chat interface
get_node("n8n-nodes-base.telegramTrigger")        # Telegram bot
get_node("n8n-nodes-base.slackTrigger")           # Slack events
```

## AI/LLM Nodes

### Chat Models

```
get_node("@n8n/n8n-nodes-langchain.lmChatGoogleGemini")   # Gemini
get_node("@n8n/n8n-nodes-langchain.lmChatOpenAi")         # OpenAI/GPT
get_node("@n8n/n8n-nodes-langchain.lmChatAnthropic")      # Claude
get_node("@n8n/n8n-nodes-langchain.lmChatOllama")         # Ollama local
get_node("@n8n/n8n-nodes-langchain.lmChatGroq")           # Groq
```

### AI Agents & Chains

```
get_node("@n8n/n8n-nodes-langchain.agent")                # AI Agent
get_node("@n8n/n8n-nodes-langchain.chainLlm")             # Basic LLM Chain
get_node("@n8n/n8n-nodes-langchain.chainSummarization")   # Summarization
get_node("@n8n/n8n-nodes-langchain.chainRetrievalQa")     # RAG Q&A
```

### AI Tools

```
get_node("@n8n/n8n-nodes-langchain.toolCalculator")       # Calculator
get_node("@n8n/n8n-nodes-langchain.toolCode")             # Code execution
get_node("@n8n/n8n-nodes-langchain.toolWikipedia")        # Wikipedia
get_node("@n8n/n8n-nodes-langchain.toolWorkflow")         # Sub-workflow
get_node("@n8n/n8n-nodes-langchain.toolHttpRequest")      # HTTP requests
```

### Embeddings & Vector

```
get_node("@n8n/n8n-nodes-langchain.embeddingsOpenAi")     # OpenAI embeddings
get_node("@n8n/n8n-nodes-langchain.embeddingsGoogleGemini") # Gemini embeddings
get_node("@n8n/n8n-nodes-langchain.vectorStorePinecone")  # Pinecone
get_node("@n8n/n8n-nodes-langchain.vectorStoreQdrant")    # Qdrant
```

### Memory

```
get_node("@n8n/n8n-nodes-langchain.memoryBufferWindow")   # Window buffer
get_node("@n8n/n8n-nodes-langchain.memoryPostgresChat")   # Postgres memory
get_node("@n8n/n8n-nodes-langchain.memoryRedisChat")      # Redis memory
```

## Data Nodes

### Databases

```
get_node("n8n-nodes-base.postgres")         # PostgreSQL
get_node("n8n-nodes-base.mysql")            # MySQL
get_node("n8n-nodes-base.mongoDb")          # MongoDB
get_node("n8n-nodes-base.redis")            # Redis
get_node("n8n-nodes-base.airtable")         # Airtable
get_node("n8n-nodes-base.notion")           # Notion
```

### Google Workspace

```
get_node("n8n-nodes-base.googleSheets")     # Google Sheets
get_node("n8n-nodes-base.googleDrive")      # Google Drive
get_node("n8n-nodes-base.gmail")            # Gmail actions
get_node("n8n-nodes-base.googleCalendar")   # Calendar
get_node("n8n-nodes-base.googleDocs")       # Google Docs
```

### Microsoft 365

```
get_node("n8n-nodes-base.microsoftExcel")   # Excel
get_node("n8n-nodes-base.microsoftOneDrive") # OneDrive
get_node("n8n-nodes-base.microsoftOutlook") # Outlook actions
get_node("n8n-nodes-base.microsoftTeams")   # Teams
```

## Utility Nodes

### Data Transformation

```
get_node("n8n-nodes-base.set")              # Set field values
get_node("n8n-nodes-base.code")             # JavaScript/Python code
get_node("n8n-nodes-base.itemLists")        # Split/aggregate items
get_node("n8n-nodes-base.splitInBatches")   # Batch processing
get_node("n8n-nodes-base.merge")            # Merge branches
get_node("n8n-nodes-base.filter")           # Filter items
get_node("n8n-nodes-base.sort")             # Sort items
```

### Flow Control

```
get_node("n8n-nodes-base.if")               # Conditional branch
get_node("n8n-nodes-base.switch")           # Multi-way branch
get_node("n8n-nodes-base.wait")             # Delay execution
get_node("n8n-nodes-base.noOp")             # No operation (passthrough)
get_node("n8n-nodes-base.executeWorkflow")  # Call sub-workflow
```

### HTTP & API

```
get_node("n8n-nodes-base.httpRequest")      # HTTP requests
get_node("n8n-nodes-base.respondToWebhook") # Webhook response
get_node("n8n-nodes-base.graphql")          # GraphQL
```

## Pattern: Discovery → Details

Quando non conosci il nome esatto del nodo:

```
1. search_nodes("gmail")           # Trova nodi correlati
2. get_node("n8n-nodes-base.gmail") # Ottieni dettagli

Esempio output search_nodes:
- n8n-nodes-base.gmail (Gmail)
- n8n-nodes-base.gmailTrigger (Gmail Trigger)
```

## Pattern: Verificare Disponibilità

Prima di usare un nodo, verificare che esista:

```
1. get_node("nomeNodo")
2. Se errore → search_nodes("keyword") per alternative
3. Usare nodo verificato nel workflow
```

## Nomi Nodi Comuni (Quick Reference)

| Servizio | Nome Nodo Corretto |
|----------|-------------------|
| Gmail | `n8n-nodes-base.gmail` |
| Sheets | `n8n-nodes-base.googleSheets` |
| Slack | `n8n-nodes-base.slack` |
| OpenAI | `@n8n/n8n-nodes-langchain.lmChatOpenAi` |
| Gemini | `@n8n/n8n-nodes-langchain.lmChatGoogleGemini` |
| HTTP | `n8n-nodes-base.httpRequest` |
| Code | `n8n-nodes-base.code` |
| IF | `n8n-nodes-base.if` |
| Set | `n8n-nodes-base.set` |
| Webhook | `n8n-nodes-base.webhook` |
