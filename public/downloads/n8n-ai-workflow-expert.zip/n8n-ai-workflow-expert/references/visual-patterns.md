# Libreria di Pattern Visuali per Workflow n8n

## 1. Introduzione

Questo documento fornisce una serie di "blueprint" o diagrammi di flusso per i pattern di automazione più comuni in n8n. Questi schemi aiutano a comprendere a colpo d'occhio la sequenza delle operazioni e il flusso dei dati, offrendo una visione architetturale di alto livello che complementa le guide specifiche dei singoli nodi.

---

## Pattern 1: ETL Semplice (Extract, Transform, Load)

**Scopo:** Estrarre dati da una fonte, trasformarli in un formato utile e caricarli in una destinazione.

**Diagramma:**
```
[Fonte Dati: API / Trigger] ---> [Trasforma: Nodo Set o Code] ---> [Destinazione: Database / Sheets]
```

*   **Extract:** Un nodo `HTTP Request` o un trigger (es. `Gmail Trigger`) recupera i dati iniziali.
*   **Transform:** Un nodo `Set` o `Code` pulisce i dati, rinomina i campi, cambia i formati o esegue calcoli.
*   **Load:** Un nodo come `Google Sheets`, `Airtable` o `PostgreSQL` inserisce i dati trasformati nella destinazione finale.

**Caso d'uso:** Scaricare gli ordini giornalieri da Shopify, calcolare il margine per ogni ordine e salvarli in un foglio Google Sheets.

---

## Pattern 2: Arricchimento Dati (Data Enrichment)

**Scopo:** Prendere un dato di base (come un'email) e arricchirlo con informazioni aggiuntive da altre fonti.

**Diagramma:**
```
[Trigger: Nuovo Lead] ---> [HTTP Request: API Arricchimento] ---> [Merge: Combina Dati] ---> [CRM: Aggiorna Contatto]
```

*   **Trigger:** Un `Webhook` riceve un nuovo lead con solo nome ed email.
*   **HTTP Request:** Chiama un'API esterna (es. Clearbit) usando l'email per ottenere il nome dell'azienda, il settore e il numero di dipendenti.
*   **Merge:** Unisce i dati originali del lead con i dati di arricchimento.
*   **CRM:** Aggiorna il record del contatto nel CRM con le nuove informazioni.

---

## Pattern 3: Aggregazione Dati (Data Aggregation)

**Scopo:** Raccogliere dati da più fonti diverse, standardizzarli e aggregarli per creare un report consolidato.

**Diagramma:**
```
                   /--> [Fonte A: CRM] ------> [Format A] --\ 
[Schedule Trigger] --|--> [Fonte B: Analytics] -> [Format B] --> [Merge] -> [Aggregate] -> [Crea Report]
                   \--> [Fonte C: Database] --> [Format C] --/
```

*   **Trigger:** Un `Schedule Trigger` avvia il processo (es. ogni notte).
*   **Flussi Paralleli:** Tre rami paralleli recuperano dati da sistemi diversi.
*   **Format:** Ogni ramo ha un nodo `Set` o `Code` per standardizzare i dati in un formato comune.
*   **Merge:** Riunisce tutti i dati standardizzati in un unico flusso.
*   **Aggregate:** Un nodo `Code` o `Aggregate` esegue calcoli sui dati combinati (es. somme, medie).
*   **Crea Report:** Il risultato finale viene usato per generare un report (es. via email).

---

## Pattern 4: Approvazione Manuale (Human in the Loop)

**Scopo:** Mettere in pausa un'automazione in attesa di una decisione da parte di un essere umano.

**Diagramma:**
```
[Trigger] -> [Prepara Dati] -> [Invia Richiesta Approvazione] -> [Wait] -> [If: Approvato?] --(true)--> [Esegui Azione]
                                                                       |
                                                                       +--(false)--> [Notifica Rifiuto]
```

*   **Invia Richiesta:** Un nodo `Outlook` o `Teams` invia un messaggio a un manager con due link speciali (generati con il nodo `Webhook`).
*   **Wait:** Il nodo `Wait` mette in pausa il workflow.
*   **Ripresa:** Quando il manager clicca su uno dei link ("Approva" o "Rifiuta"), invia una richiesta a un secondo workflow (o allo stesso, se configurato per questo) che fa ripartire il nodo `Wait`.
*   **If:** Controlla quale link è stato cliccato e instrada il workflow sul ramo corretto.

**Caso d'uso:** Un'AI genera un post per i social, ma questo viene pubblicato solo dopo l'approvazione del responsabile marketing.

---

## Pattern 5: Elaborazione in Batch (Batch Processing Loop)

**Scopo:** Processare un grande numero di item in lotti controllati per evitare rate limit e problemi di memoria.

**Diagramma:**
```
                                     +----------------------------------+
                                     |                                  |
[Fonte Dati: 1000 items] -> [Split in Batches] --(Batch)--> [Processa Batch] -> [Wait] --+
                                     |
                                   (Done)
                                     |
                                     V
                              [Fine / Invia Riepilogo]
```

*   **Split in Batches:** Riceve N item e ne fa passare solo un piccolo lotto (es. 50).
*   **Processa Batch:** Una serie di nodi (es. `HttpRequest`) elabora gli item del lotto.
*   **Wait:** Una pausa per rispettare i limiti delle API.
*   **Loop:** L'ultimo nodo del blocco di elaborazione si ricollega all'input dello `Split in Batches`, che a quel punto invierà il lotto successivo.
*   **Done:** Quando tutti i lotti sono stati processati, il flusso prosegue dall'output "Done" per le azioni finali.

**Caso d'uso:** Aggiornare 5000 contatti in un CRM che permette solo 100 chiamate API al minuto.
