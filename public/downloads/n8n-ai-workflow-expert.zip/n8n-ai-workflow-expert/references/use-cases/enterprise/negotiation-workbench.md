# Enterprise Use Case: Negotiation Preparation Workbench

## 1. Workflow Objective

**Purpose:** Provide a salesperson with a strategic and interactive "workbench" to prepare for a complex negotiation. The workflow guides the user through a series of sequential analyses, based on a structured methodology, to define all key elements of the deal: from critical factors to the BATNA (Best Alternative to a Negotiated Agreement), to producing a final, operational "Battle Plan".

This workflow replicates a sequential negotiation analysis logic, transforming a complex analysis process into a guided experience.

## 2. Technology Stack Used

*   **Trigger:** `Form Trigger` (to collect the initial negotiation context).
*   **AI:** `Google Gemini Pro` (essential for the complexity of the analyses required at each step).
*   **Core Logic:** `Set` (to accumulate the results of each phase and prepare the input for the next one).
*   **Storage:** `SharePoint` (to save the final Battle Plan).
*   **Notification:** `Teams`.

## 3. Flow Logic (Sequential Analysis Chain)

This workflow is a guided "wizard", where each step builds upon the previous one.

### **Step 1: Initial Inputs**
*   **Node:** `Form Trigger`.
*   **Logic:** A form collects the basic context: customer name, links to documents about the offer and client context (stored on SharePoint).

### **Step 2: Key Factors Analysis**
*   **`Set` Node:** Prepares the first prompt, using the logic from `negotiationPrompt.js` for `step: 1`, passing the context documents.
*   **`Google Gemini Pro` Node:** Analyzes the documents and generates a JSON output containing the key negotiation factors, their description, and the estimated importance for both parties.

### **Step 3: ZOPA (Zone of Possible Agreement) Definition**
*   **`Set` Node:** Takes the JSON output from Step 2 and uses it as context for the next prompt (`step: 2`), asking to define the ZOPA for quantifiable factors.
*   **`Google Gemini Pro` Node:** Generates a JSON with objectives and limits for us and for the customer.

### **Step 4: Trade Variables Identification**
*   **`Set` Node:** Prepares the prompt for `step: 3`, passing the accumulated context.
*   **`Google Gemini Pro` Node:** Generates a JSON with a list of possible "Gives" (low-cost concessions for us) and "Takes" (high-value requests for us).

### **Step 5: BATNA (Best Alternative) Analysis**
*   **`Set` Node:** Prepares the prompt for `step: 4`.
*   **`Google Gemini Pro` Node:** Generates a JSON that defines the BATNA for both parties.

### **Step 6: Final "Battle Plan" Generation**
*   **`Set` Node:** This is the crucial consolidation step. It collects **all JSON outputs** from previous steps (Key Factors, ZOPA, Variables, BATNA) and inserts them into a single, comprehensive prompt for `step: 6`.
*   **`Google Gemini Pro` Node:** Executes the final analysis and generates the complete "Battle Plan", with primary objective, opening sequence, key levers, planned concessions, and objection handling.

### **Step 7: Saving and Notification**
*   **`Microsoft Word` Node:** Converts the Battle Plan (which can be formatted in Markdown by the AI) into a `.docx` document.
*   **`SharePoint (Upload)` Node:** Saves the Word document in a dedicated folder.
*   **`Teams` Node:** Notifies the salesperson that their Battle Plan is ready, with a direct link to the document.

## 4. Key Points and Best Practices

*   **Workflow as "Wizard":** This workflow is not a single automation, but a true decision support tool that guides the user step by step, replicating a strategic consulting process.
*   **Cumulative Context Management:** The key to this workflow is its ability to maintain and enrich context. Each AI call builds on the results of the previous one. Using `Set` nodes to progressively aggregate data into a single `json` object is the correct pattern for managing this state.
*   **Need for a Powerful AI Model:** A multi-step strategic analysis like this requires a top-tier language model. `Gemini 1.5 Pro` or `GPT-4o` are necessary to ensure consistency and quality of reasoning across all steps.
*   **Actionable Output:** The final result is not simple text, but a strategic and operational document (the "Battle Plan") that the salesperson can study and bring to the meeting, drastically increasing their preparation and confidence.
*   **Interactivity vs. Automation:** While this workflow is presented as a fully automated chain, a variant could include manual approval steps (`Wait > Wait for Webhook`) after each step, allowing the user to validate or modify the output of each analysis before proceeding to the next one, transforming it into a true interactive tool.
