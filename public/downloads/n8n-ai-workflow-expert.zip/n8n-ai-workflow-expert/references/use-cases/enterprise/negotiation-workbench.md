# Caso d'Uso Enterprise: Workbench di Preparazione alla Negoziazione

## 1. Obiettivo del Workflow

**Scopo:** Fornire a un venditore un "workbench" (banco di lavoro) strategico e interattivo per preparare una negoziazione complessa. Il workflow guida l'utente attraverso una serie di analisi sequenziali, basate su una metodologia strutturata, per definire tutti gli elementi chiave della trattativa: dai fattori critici alla MAAN (Migliore Alternativa ad un Accordo Negoziato), fino a produrre un "Piano di Battaglia" finale e operativo.

Questo workflow replica una logica sequenziale di analisi negoziale, trasformando un processo di analisi complesso in un'esperienza guidata.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `Form Trigger` (per raccogliere il contesto iniziale della negoziazione).
*   **AI:** `Google Gemini Pro` (essenziale per la complessità delle analisi richieste in ogni step).
*   **Core Logic:** `Set` (per accumulare i risultati di ogni fase e preparare l'input per la successiva).
*   **Archiviazione:** `SharePoint` (per salvare il Piano di Battaglia finale).
*   **Notifica:** `Teams`.

## 3. Logica del Flusso (Catena di Analisi Sequenziale)

Questo workflow è un "wizard" guidato, dove ogni passaggio si basa sul precedente.

### **Step 1: Input Iniziali**
*   **Nodo:** `Form Trigger`.
*   **Logica:** Un form raccoglie il contesto di base: nome del cliente, link a documenti sull'offerta e sul contesto del cliente (archiviati su SharePoint).

### **Step 2: Analisi dei Fattori Chiave**
*   **Nodo `Set`:** Prepara il primo prompt, usando la logica di `negotiationPrompt.js` per lo `step: 1`, passando i documenti di contesto.
*   **Nodo `Google Gemini Pro`:** Analizza i documenti e genera un output JSON contenente i fattori chiave della negoziazione, la loro descrizione e l'importanza stimata per entrambe le parti.

### **Step 3: Definizione della ZOPA (Zone of Possible Agreement)**
*   **Nodo `Set`:** Prende l'output JSON dello Step 2 e lo usa come contesto per il prompt successivo (`step: 2`), chiedendo di definire la ZOPA per i fattori quantificabili.
*   **Nodo `Google Gemini Pro`:** Genera un JSON con gli obiettivi e i limiti per noi e per il cliente.

### **Step 4: Identificazione delle Variabili di Scambio**
*   **Nodo `Set`:** Prepara il prompt per lo `step: 3`, passando il contesto accumulato.
*   **Nodo `Google Gemini Pro`:** Genera un JSON con una lista di possibili "Give" (concessioni a basso costo per noi) e "Take" (richieste di alto valore per noi).

### **Step 5: Analisi della MAAN (Best Alternative)**
*   **Nodo `Set`:** Prepara il prompt per lo `step: 4`.
*   **Nodo `Google Gemini Pro`:** Genera un JSON che definisce la MAAN per entrambe le parti.

### **Step 6: Generazione del "Piano di Battaglia" Finale**
*   **Nodo `Set`:** Questo è il passaggio cruciale di consolidamento. Raccoglie **tutti gli output JSON** degli step precedenti (Fattori Chiave, ZOPA, Variabili, MAAN) e li inserisce in un unico, grande prompt per lo `step: 6`.
*   **Nodo `Google Gemini Pro`:** Esegue l'analisi finale e genera il "Piano di Battaglia" completo, con obiettivo primario, sequenza di apertura, leve chiave, concessioni pianificate e gestione delle obiezioni.

### **Step 7: Salvataggio e Notifica**
*   **Nodo `Microsoft Word`:** Converte il Piano di Battaglia (che può essere formattato in Markdown dall'AI) in un documento `.docx`.
*   **Nodo `SharePoint (Upload)`:** Salva il documento Word in una cartella dedicata.
*   **Nodo `Teams`:** Notifica al venditore che il suo Piano di Battaglia è pronto, con un link diretto al documento.

## 4. Punti Chiave e Best Practice

*   **Workflow come "Wizard":** Questo workflow non è una singola automazione, ma un vero e proprio strumento di supporto decisionale che guida l'utente passo dopo passo, replicando un processo di consulenza strategica.
*   **Gestione del Contesto Cumulativo:** La chiave di questo workflow è la sua capacità di mantenere e arricchire il contesto. Ogni chiamata all'AI si basa sui risultati della precedente. L'uso di nodi `Set` per aggregare progressivamente i dati in un unico oggetto `json` è il pattern corretto per gestire questo stato.
*   **Necessità di un Modello AI Potente:** Un'analisi strategica multi-step come questa richiede un modello di linguaggio di altissimo livello. `Gemini 1.5 Pro` o `GPT-4o` sono necessari per garantire la coerenza e la qualità del ragionamento attraverso tutti i passaggi.
*   **Output Azionabile:** Il risultato finale non è un semplice testo, ma un documento strategico e operativo (il "Piano di Battaglia") che il venditore può studiare e portare con sé nell'incontro, aumentando drasticamente la sua preparazione e fiducia.
*   **Interattività vs. Automazione:** Mentre questo workflow è presentato come una catena completamente automatizzata, una variante potrebbe includere dei passaggi di approvazione manuale (`Wait > Wait for Webhook`) dopo ogni step, permettendo all'utente di validare o modificare l'output di ogni analisi prima di procedere alla successiva, trasformandolo in un vero e proprio strumento interattivo.
