# Caso d'Uso Enterprise: Analisi Documenti di Gara con RAG

## 1. Obiettivo del Workflow

**Scopo:** Creare un sistema semi-automatico per analizzare complessi documenti di gara (capitolati, offerte tecniche). Il sistema indicizza il contenuto di questi documenti in una "knowledge base" e permette agli utenti (team di prevendita, commerciali) di porre domande in linguaggio naturale per estrarre rapidamente informazioni chiave, come requisiti, scadenze, penali e criteri di valutazione.

Questo approccio, noto come **RAG (Retrieval-Augmented Generation)**, è di gran lunga superiore al semplice invio di un documento a un'AI, perché garantisce risposte basate **esclusivamente** sui fatti contenuti nel documento, minimizzando il rischio di errori o "allucinazioni" dell'AI.

Il processo è diviso in due workflow distinti: **Indicizzazione** e **Interrogazione (Q&A)**.

## 2. Workflow 1: Indicizzazione del Documento

**Obiettivo:** Leggere un nuovo documento di gara, suddividerlo e salvarlo in un database vettoriale per renderlo "interrogabile".

**Stack Utilizzato:**
*   **Trigger:** `SharePoint Trigger`
*   **File Handling:** `SharePoint (Download)`, `SharePoint (Move)`
*   **Processing:** `Document Loader`, `Embeddings` (es. OpenAI), `Vector Store` (es. Qdrant, Pinecone, o In-Memory)

**Logica del Flusso:**
1.  **Trigger:** Un `SharePoint Trigger` si avvia quando un nuovo file PDF viene caricato nella cartella `/Gare/Da Indicizzare/`.
2.  **Download & Chunking:** Un nodo `SharePoint (Download)` scarica il file. Subito dopo, un `Document Loader` lo legge e lo divide in centinaia di piccoli "chunk" (frammenti) di testo sovrapposti.
3.  **Creazione Embeddings:** Un nodo `Embeddings` (es. `embeddingsOpenAi`) trasforma ogni singolo chunk di testo in un vettore numerico, che ne rappresenta il significato semantico.
4.  **Salvataggio nel Vector Store:** Un nodo `Vector Store` (es. `Qdrant`) riceve i chunk e i loro vettori. Salva ogni vettore associandolo al testo del chunk e a metadati importanti, come l'ID della gara (`tender_id`).
5.  **Archiviazione:** Un nodo `SharePoint (Move)` sposta il documento originale in `/Gare/Indicizzati/` per evitare una nuova elaborazione.

## 3. Workflow 2: Interrogazione (Q&A) del Documento

**Obiettivo:** Permettere a un utente di fare una domanda su una gara specifica e ricevere una risposta basata sui documenti indicizzati.

**Stack Utilizzato:**
*   **Interfaccia:** `Chat Trigger` (per test) o un canale di `Microsoft Teams`.
*   **Core Logic:** `Embeddings`, `Vector Store`, `Google Gemini`.

**Logica del Flusso:**
1.  **Trigger:** Un `Chat Trigger` riceve la domanda dell'utente, che deve includere l'ID della gara. Esempio: `"Quali sono le penali previste per la gara #G123?"`
2.  **Ricerca Semantica:**
    *   Il workflow estrae la domanda (`"Quali sono le penali?"`) e l'ID della gara (`G123`).
    *   La domanda viene trasformata in un vettore di embedding.
    *   Un nodo `Vector Store (Search)` cerca nel database i chunk di testo i cui vettori sono più "simili" al vettore della domanda, **filtrando i risultati solo per quelli con `tender_id = G123`**.
    *   Questo passaggio recupera i 3-5 paragrafi più pertinenti dal documento di gara originale.
3.  **Generazione della Risposta (RAG):**
    *   **Nodo `Google Gemini`:** Riceve sia la domanda originale dell'utente sia i chunk di testo pertinenti recuperati dal vector store.
    *   **Prompt (Cruciale):** Il prompt istruisce l'AI in modo molto specifico: `"Basandoti ESCLUSIVAMENTE sul contesto fornito qui di seguito, rispondi alla domanda dell'utente. Se la risposta non è presente nel contesto, rispondi 'Non ho trovato l'informazione nel documento'. Domanda: [Domanda Utente]. Contesto: [Chunk 1, Chunk 2, Chunk 3]."`
4.  **Consegna della Risposta:** Il nodo `Respond to Webhook` invia la risposta generata dall'AI all'interfaccia di chat dell'utente.

## 4. Punti Chiave e Best Practice

*   **Separazione dei Processi:** Dividere l'indicizzazione (un processo pesante, eseguito una volta per documento) dall'interrogazione (un processo leggero e frequente) è una best practice fondamentale per l'efficienza e la scalabilità.
*   **Il Potere del RAG:** Questo pattern è il modo corretto per interrogare documenti. Invece di sovraccaricare un'AI con un documento di 100 pagine, si focalizza la sua attenzione solo sui pochi paragrafi rilevanti, ottenendo risposte molto più accurate e veloci.
*   **"Grounding" dell'AI:** Il prompt usato nel workflow di Q&A è detto "grounding prompt". Forza l'AI a basarsi solo sui fatti forniti (il contesto), impedendole di inventare risposte o di usare la sua conoscenza generale. Questo è essenziale per l'accuratezza in ambito legale e tecnico.
*   **Importanza dei Metadati:** Salvare metadati (come `tender_id`, `document_name`, `chapter`) insieme ai vettori è cruciale. Permette di filtrare la ricerca e di fare domande su un documento specifico all'interno di una knowledge base che potrebbe contenerne centinaia.
*   **Scelta del Vector Store:** Per iniziare, il nodo `In-Memory Vector Store` di n8n è ottimo per i test. Per un'applicazione di produzione con molti documenti, è necessario utilizzare un database vettoriale dedicato come **Qdrant**, **Pinecone** o **Supabase**, che offrono persistenza e performance di ricerca elevate.
