# Caso d'Uso Enterprise: Preparazione Automatizzata Incontri Commerciali

## 1. Obiettivo del Workflow

**Scopo:** Generare e consegnare automaticamente un briefing di una pagina, conciso e strategico, a un venditore circa un'ora prima di un incontro commerciale programmato. Il briefing deve aggregare le informazioni più recenti e rilevanti sul cliente, sulle opportunità aperte e sulle interazioni recenti, fornendo al venditore i punti di discussione chiave.

**Casi d'uso reali:**
*   Preparazione per una demo con un nuovo potenziale cliente.
*   Follow-up strategico con un cliente esistente per discutere un rinnovo o un upsell.
*   Incontro con un partner per discutere di iniziative congiunte.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `Microsoft Outlook Calendar` (si attiva prima di un evento).
*   **Data Sources:** CRM (es. Salesforce, HubSpot via `HttpRequest`), `Microsoft Outlook` (per le email recenti), `SharePoint` (per documenti associati al cliente).
*   **Core Logic:** `Set`, `Code`.
*   **AI:** `Google Gemini` (per analizzare e sintetizzare le informazioni in un briefing).
*   **Delivery:** `Microsoft Teams` (per inviare il briefing come messaggio diretto).

## 3. Logica del Flusso (Step-by-Step)

### **Step 1: Trigger - L'Incontro si Avvicina**
*   **Nodo:** `Microsoft Outlook Calendar Trigger`.
*   **Logica:** Il workflow si avvia 60 minuti prima dell'inizio di un evento nel calendario. È fondamentale configurare il trigger per attivarsi solo per eventi specifici, ad esempio quelli che hanno la categoria `"Incontro Cliente"` o che includono partecipanti esterni all'organizzazione.

### **Step 2: Estrazione e Preparazione dei Dati**
*   **Nodo `Set`:** Estrae l'indirizzo email del partecipante esterno dall'evento del calendario. Questo sarà l'identificativo per le ricerche successive.

### **Step 3: Raccolta Contesto dal CRM**
*   **Nodo `HttpRequest` (o nodo CRM dedicato):** Esegue una chiamata all'API del CRM per recuperare le informazioni associate all'email del contatto. 
*   **Dati da recuperare:** Nome dell'azienda, ruolo del contatto, valore totale delle opportunità aperte, fase dell'opportunità più importante.

### **Step 4: Analisi delle Interazioni Recenti**
*   **Nodo `Microsoft Outlook (GetAll)`:** Cerca le ultime 3-5 email scambiate con l'indirizzo email del contatto. Un nodo `Set` o `Code` può essere usato per estrarre solo gli oggetti e le date, creando un riassunto delle comunicazioni recenti.

### **Step 5: Consolidamento delle Informazioni**
*   **Nodo `Code`:** Raccoglie tutti i dati recuperati (dati CRM, lista email recenti) e li formatta in un unico blocco di testo strutturato, pronto per essere analizzato dall'AI. L'uso di tag come `<CRM_DATA>` e `<EMAIL_HISTORY>` è una best practice.

### **Step 6: Generazione del Briefing con AI**
*   **Nodo `Google Gemini`:** Riceve il blocco di testo consolidato. Il `systemMessage` istruisce l'AI ad agire come un assistente di vendita strategico.
*   **Prompt:** `"Analizza i seguenti dati su un cliente e genera un briefing di una pagina per un incontro commerciale. Struttura il briefing nelle seguenti sezioni: 1. Panoramica Cliente e Opportunità, 2. Attività Recenti, 3. Punti di Discussione Chiave e Prossimi Passi Suggeriti."`

### **Step 7: Consegna del Briefing**
*   **Nodo `Microsoft Teams`:** Invia un messaggio diretto al proprietario dell'evento del calendario (il venditore). Il messaggio contiene il briefing generato dall'AI, formattato con Markdown per una facile lettura.

## 4. Punti Chiave e Best Practice

*   **Trigger Mirato:** La precisione del trigger è tutto. Usa le categorie di Outlook o una parola chiave specifica nell'oggetto dell'invito (es. `"[Cliente]"`) per assicurarti che il workflow si attivi solo per gli incontri corretti, evitando di girare a vuoto per appuntamenti interni.
*   **Il Contesto è Re:** La qualità del briefing è direttamente proporzionale alla quantità e qualità dei dati che riesci a fornire all'AI. Più fonti riesci a collegare (CRM, email, SharePoint, notizie recenti sull'azienda del cliente), più strategico e utile sarà il briefing.
*   **Prompt Strutturato:** Chiedi all'AI di generare l'output con sezioni chiare e definite (`## Panoramica`, `## Punti di Discussione`). Questo rende il briefing facile da scorrere e assimilare in pochi minuti prima della call.
*   **Consegna Puntuale:** Avviare il workflow un'ora prima dell'incontro è un buon equilibrio. Dà al venditore tempo sufficiente per leggere il briefing, ma assicura che le informazioni (come le email recenti) siano le più aggiornate possibile.
*   **Modularità con `toolWorkflow`:** I passaggi di raccolta dati (Step 3 e 4) sono candidati perfetti per essere trasformati in sub-workflow riutilizzabili. Potresti avere un "tool" chiamato `get_customer_snapshot` che, dato un indirizzo email, restituisce tutte le informazioni rilevanti, e che può essere riutilizzato in molti altri workflow di vendita.
