# Enterprise Use Case: Automated Sales Meeting Preparation

## 1. Workflow Objective

**Purpose:** Automatically generate and deliver a concise, strategic one-page briefing to a salesperson approximately one hour before a scheduled sales meeting. The briefing must aggregate the most recent and relevant information about the customer, open opportunities, and recent interactions, providing the salesperson with key discussion points.

**Real use cases:**
*   Preparation for a demo with a new potential customer.
*   Strategic follow-up with an existing customer to discuss a renewal or upsell.
*   Meeting with a partner to discuss joint initiatives.

## 2. Technology Stack Used

*   **Trigger:** `Microsoft Outlook Calendar` (activates before an event).
*   **Data Sources:** CRM (e.g., Salesforce, HubSpot via `HttpRequest`), `Microsoft Outlook` (for recent emails), `SharePoint` (for customer-associated documents).
*   **Core Logic:** `Set`, `Code`.
*   **AI:** `Google Gemini` (to analyze and synthesize information into a briefing).
*   **Delivery:** `Microsoft Teams` (to send the briefing as a direct message).

## 3. Flow Logic (Step-by-Step)

### **Step 1: Trigger - The Meeting Approaches**
*   **Node:** `Microsoft Outlook Calendar Trigger`.
*   **Logic:** The workflow starts 60 minutes before an event begins on the calendar. It is fundamental to configure the trigger to activate only for specific events, for example those with the category `"Customer Meeting"` or that include external participants from outside the organization.

### **Step 2: Data Extraction and Preparation**
*   **`Set` Node:** Extracts the external participant's email address from the calendar event. This will be the identifier for subsequent searches.

### **Step 3: Context Collection from CRM**
*   **`HttpRequest` Node (or dedicated CRM node):** Makes an API call to the CRM to retrieve information associated with the contact's email.
*   **Data to retrieve:** Company name, contact role, total value of open opportunities, stage of the most important opportunity.

### **Step 4: Recent Interactions Analysis**
*   **`Microsoft Outlook (GetAll)` Node:** Searches for the last 3-5 emails exchanged with the contact's email address. A `Set` or `Code` node can be used to extract only subjects and dates, creating a summary of recent communications.

### **Step 5: Information Consolidation**
*   **`Code` Node:** Collects all retrieved data (CRM data, recent email list) and formats it into a single structured text block, ready to be analyzed by the AI. Using tags like `<CRM_DATA>` and `<EMAIL_HISTORY>` is a best practice.

### **Step 6: Briefing Generation with AI**
*   **`Google Gemini` Node:** Receives the consolidated text block. The `systemMessage` instructs the AI to act as a strategic sales assistant.
*   **Prompt:** `"Analyze the following customer data and generate a one-page briefing for a sales meeting. Structure the briefing in the following sections: 1. Customer and Opportunity Overview, 2. Recent Activity, 3. Key Discussion Points and Suggested Next Steps."`

### **Step 7: Briefing Delivery**
*   **`Microsoft Teams` Node:** Sends a direct message to the calendar event owner (the salesperson). The message contains the AI-generated briefing, formatted with Markdown for easy reading.

## 4. Key Points and Best Practices

*   **Targeted Trigger:** Trigger precision is everything. Use Outlook categories or a specific keyword in the meeting subject (e.g., `"[Customer]"`) to ensure the workflow activates only for the correct meetings, avoiding idle runs for internal appointments.
*   **Context is King:** The briefing quality is directly proportional to the quantity and quality of data you can provide to the AI. The more sources you can connect (CRM, email, SharePoint, recent news about the client's company), the more strategic and useful the briefing will be.
*   **Structured Prompt:** Ask the AI to generate output with clear, defined sections (`## Overview`, `## Discussion Points`). This makes the briefing easy to scan and absorb in a few minutes before the call.
*   **Timely Delivery:** Starting the workflow one hour before the meeting is a good balance. It gives the salesperson enough time to read the briefing, while ensuring the information (such as recent emails) is as up-to-date as possible.
*   **Modularity with `toolWorkflow`:** The data collection steps (Steps 3 and 4) are perfect candidates for being transformed into reusable sub-workflows. You could have a "tool" called `get_customer_snapshot` that, given an email address, returns all relevant information, and that can be reused in many other sales workflows.
