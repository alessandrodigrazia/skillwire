# Caso d'Uso Enterprise: Workflow di Preparazione Strategica Account

## 1. Obiettivo del Workflow

**Scopo:** Automatizzare l'intero processo di intelligence e preparazione strategica per un nuovo account B2B. Partendo dal solo nome di un'azienda target, il workflow esegue una ricerca approfondita, ne analizza il posizionamento strategico (C-SWOT), identifica le aree di valore per la nostra offerta e, infine, produce gli artefatti per il primo contatto: un **One-Pager strategico** e la **bozza dell'email di contatto**.

Questo workflow replica la prima metà del processo di account planning, incapsulando la logica dei prompt `preResearch`, `cswot`, `valueAreas` e `onePagerAndEmail` in una catena automatizzata.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `Form Trigger` o `Webhook` (per inserire il nome dell'azienda target).
*   **Ricerca Esterna:** `HttpRequest` (per chiamare un'API di ricerca come Perplexity o un'altra AI per la fase di intelligence).
*   **AI Core:** `Google Gemini Pro` (per le fasi di analisi e generazione che richiedono ragionamento complesso).
*   **Core Logic:** `Set`, `Code` (per gestire il flusso di dati tra i passaggi).
*   **Archiviazione e Output:** `Microsoft Outlook` (per salvare l'email come bozza), `SharePoint` (per salvare il One-Pager).

## 3. Logica del Flusso (Catena di Prompt Sequenziali)

Questo workflow è un esempio di **"AI Chaining"**, dove l'output di un'agente AI diventa l'input per il successivo, arricchendo il contesto a ogni passo.

### **Step 1: Input Iniziale**
*   **Nodo:** `Form Trigger`.
*   **Logica:** Un semplice form chiede al venditore di inserire il `Nome dell'Azienda Prospect` da analizzare.

### **Step 2: Pre-Ricerca (Intelligence Gathering)**
*   **Nodo `Set`:** Prepara il prompt per l'agente "Pre-Ricerca", usando il template da `preResearchPrompt.js`.
*   **Nodo `Google Gemini`:** Genera il "meta-prompt", ovvero il briefing di ricerca avanzato.
*   **Nodo `HttpRequest`:** Invia il meta-prompt a un'API esterna di AI conversazionale (es. Perplexity, o un altro endpoint Gemini/OpenAI) per eseguire la ricerca e ottenere un report strategico dettagliato sul prospect.

### **Step 3: Analisi C-SWOT**
*   **Nodo `Set`:** Prende il report strategico dallo Step 2 e lo inserisce nel template del prompt `cswotPrompt.js`.
*   **Nodo `Google Gemini Pro`:** Esegue l'analisi C-SWOT e produce un output JSON strutturato con punti di forza, debolezza, opportunità e minacce del cliente.

### **Step 4: Identificazione Aree di Valore**
*   **Nodo `Set`:** Prende l'output JSON della C-SWOT e lo usa come input per il template del prompt `valueAreasPrompt.js`.
*   **Nodo `Google Gemini Pro`:** Identifica e genera le 4 Aree di Valore più promettenti, collegando i problemi del cliente alle soluzioni della nostra azienda, e produce un altro output JSON strutturato.

### **Step 5: Generazione One-Pager ed Email**
*   **Nodo `Set`:** Prende i dati JSON della C-SWOT e delle Aree di Valore e li inserisce nel template `onePagerAndEmailPrompt.js` (configurato per il One-Pager).
*   **Nodo `Google Gemini Pro`:** Genera il contenuto del One-Pager strategico in formato JSON.
*   **Un secondo `Set` e `Gemini Pro`:** Eseguono un processo simile, ma questa volta usando il contenuto del One-Pager appena generato per creare la bozza dell'email di contatto, sempre in formato JSON (`subject` e `bodyHtml`).

### **Step 6: Salvataggio degli Artefatti (Human-in-the-Loop)**
*   **Nodo `Microsoft Outlook`:** Usa l'operazione `Create Draft`. Salva l'email generata nella cartella "Bozze" del venditore. **Questo è un passaggio cruciale:** l'email non viene inviata automaticamente, ma attende una revisione e un invio manuale.
*   **Nodo `SharePoint (List Item: Create)`:** Salva il contenuto del One-Pager in una Lista SharePoint per future consultazioni.

## 4. Punti Chiave e Best Practice

*   **AI Chaining:** Questo workflow dimostra la potenza di una catena di chiamate AI. Ogni agente specializzato lavora sull'output del precedente, creando un livello di analisi e pertinenza impossibile da ottenere con un singolo prompt.
*   **Separazione dei Compiti:** Ogni agente AI ha una responsabilità singola e chiara (ricerca, analisi SWOT, generazione, ecc.). Questo rende il workflow più affidabile e facile da debuggare.
*   **Dati Strutturati come Filo Conduttore:** L'uso di JSON come formato di interscambio tra i vari step AI è fondamentale per la robustezza del processo. Ogni agente sa esattamente quale input aspettarsi.
*   **Human in the Loop (Fondamentale):** Il workflow non sostituisce il venditore, ma lo potenzia. L'output finale (l'email) viene salvato come bozza, garantendo che un essere umano abbia sempre il controllo finale, possa personalizzare ulteriormente il messaggio e decida il momento giusto per l'invio.
*   **Costo/Beneficio:** Questo è un workflow complesso che esegue multiple chiamate a modelli AI potenti. Il suo valore non sta nel risparmio di token, ma nel risparmio di **ore** di lavoro di analisi strategica per il team di vendita, producendo un output di qualità molto elevata.
