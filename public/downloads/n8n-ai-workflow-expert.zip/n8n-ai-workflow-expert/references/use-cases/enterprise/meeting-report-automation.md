# Caso d'Uso Enterprise: Report Automatico di Incontri Commerciali

## 1. Obiettivo del Workflow

**Scopo:** Automatizzare il processo di documentazione post-meeting. Il workflow prende una registrazione audio di un incontro commerciale, la trascrive, e genera un report strutturato che include un riassunto, le decisioni prese e gli action item assegnati. L'obiettivo è eliminare il lavoro manuale di riascolto e sintesi, rendendo i risultati dell'incontro immediatamente azionabili.

**Casi d'uso reali:**
*   Generare i verbali di incontri con clienti importanti.
*   Estrarre i compiti assegnati durante una riunione di progetto.
*   Archiviare in modo strutturato le decisioni prese durante le sessioni di revisione strategica.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `Microsoft OneDrive Trigger` o `SharePoint Trigger` (un nuovo file audio viene caricato).
*   **File Handling:** `OneDrive`/`SharePoint` (per scaricare e spostare il file).
*   **Trascrizione:** `HttpRequest` (per chiamare un'API di trascrizione come OpenAI Whisper).
*   **AI:** `Google Gemini Pro` (per analizzare la lunga trascrizione e generare il report).
*   **Delivery & Logging:** `Microsoft Outlook`, `Microsoft Teams`, `SharePoint Lists`.

## 3. Logica del Flusso (Step-by-Step)

### **Step 1: Trigger - Registrazione Caricata**
*   **Nodo:** `OneDrive Trigger`.
*   **Logica:** Il workflow si avvia quando un file audio (es. `.m4a`, `.mp4`) viene caricato in una cartella specifica, ad esempio `/Registrazioni Meeting/Da Processare/`.

### **Step 2: Download del File Audio**
*   **Nodo:** `OneDrive (Download)`.
*   **Logica:** Il nodo scarica il file audio appena caricato, rendendolo disponibile come dato binario per il passaggio successivo.

### **Step 3: Trascrizione dell'Audio**
*   **Nodo:** `HttpRequest`.
*   **Logica:** Questo nodo invia il file audio a un'API di trascrizione esterna. L'API di **OpenAI Whisper** è lo standard di mercato per questa operazione.
    *   **Method:** `POST`
    *   **URL:** `https://api.openai.com/v1/audio/transcriptions`
    *   **Body:** `multipart/form-data`, con il file audio e il nome del modello (`whisper-1`).
    *   **Authentication:** Header Auth con la API key di OpenAI.

### **Step 4: Analisi della Trascrizione con AI**
*   **Nodo:** `Google Gemini Pro`.
*   **Logica:** Il nodo riceve il testo completo della trascrizione (che può essere molto lungo, motivo per cui si usa un modello Pro). Il prompt è progettato per generare un output strutturato.
*   **Prompt:** `"Sei un business analyst. Analizza la seguente trascrizione di un incontro e genera un report in Markdown con queste sezioni esatte: ## Riassunto Esecutivo, ## Decisioni Chiave (come lista puntata), ## Action Items (come tabella con colonne: Azione, Responsabile, Scadenza), ## Sentiment Cliente (Positivo, Neutrale, o Preoccupato, con una breve motivazione)."`

### **Step 5: Distribuzione del Report**
*   **Nodo `Microsoft Outlook`:** Invia un'email a tutti i partecipanti dell'incontro (le cui email possono essere recuperate dal calendario o dal CRM) con il report generato dall'AI nel corpo dell'email.
*   **Nodo `SharePoint (List Item: Create)`:** Salva le informazioni chiave (come gli Action Items) in una Lista SharePoint centralizzata per il tracciamento dei compiti.

### **Step 6: Archiviazione del File**
*   **Nodo `OneDrive (Move)`:** Sposta il file audio originale dalla cartella `/Da Processare/` alla cartella `/Archiviati/`. Questo passaggio è fondamentale per evitare che il workflow processi di nuovo la stessa registrazione.

## 4. Punti Chiave e Best Practice

*   **Trascrizione come Servizio Esterno:** n8n non ha un nodo nativo per la trascrizione. L'uso del nodo `HttpRequest` per chiamare un servizio specializzato come Whisper è il pattern corretto e dimostra la grande flessibilità di n8n.
*   **Gestione di File di Grandi Dimensioni:** I file audio possono essere pesanti. Assicurati che la tua istanza n8n abbia memoria e spazio su disco sufficienti per gestirli temporaneamente durante l'esecuzione del workflow.
*   **Usa un Modello AI per Contesti Lunghi:** Le trascrizioni possono essere molto lunghe. È essenziale usare un modello con un'ampia finestra di contesto, come `Gemini 1.5 Pro` o `Claude 3 Sonnet`, per poter analizzare l'intero testo in una sola volta e non perdere informazioni.
*   **Prompt per l'Estrazione Strutturata:** Il valore di questo workflow risiede nella sua capacità di produrre un output strutturato e azionabile. Il prompt deve chiedere esplicitamente all'AI di usare la formattazione Markdown (liste, tabelle) per rendere il report immediatamente utilizzabile.
*   **Archiviazione Post-Elaborazione:** Spostare sempre il file processato in una cartella di archivio è una best practice cruciale per la robustezza del workflow. Impedisce elaborazioni multiple e mantiene ordinata la cartella di input.
