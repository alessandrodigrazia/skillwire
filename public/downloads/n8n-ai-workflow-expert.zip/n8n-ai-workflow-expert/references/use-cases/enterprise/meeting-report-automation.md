# Enterprise Use Case: Automated Sales Meeting Report

## 1. Workflow Objective

**Purpose:** Automate the post-meeting documentation process. The workflow takes an audio recording of a sales meeting, transcribes it, and generates a structured report that includes a summary, decisions made, and assigned action items. The goal is to eliminate the manual work of re-listening and synthesizing, making meeting outcomes immediately actionable.

**Real use cases:**
*   Generating minutes for meetings with important clients.
*   Extracting assigned tasks during a project meeting.
*   Archiving decisions made during strategic review sessions in a structured manner.

## 2. Technology Stack Used

*   **Trigger:** `Microsoft OneDrive Trigger` or `SharePoint Trigger` (a new audio file is uploaded).
*   **File Handling:** `OneDrive`/`SharePoint` (to download and move the file).
*   **Transcription:** `HttpRequest` (to call a transcription API like OpenAI Whisper).
*   **AI:** `Google Gemini Pro` (to analyze the long transcription and generate the report).
*   **Delivery & Logging:** `Microsoft Outlook`, `Microsoft Teams`, `SharePoint Lists`.

## 3. Flow Logic (Step-by-Step)

### **Step 1: Trigger - Recording Uploaded**
*   **Node:** `OneDrive Trigger`.
*   **Logic:** The workflow starts when an audio file (e.g., `.m4a`, `.mp4`) is uploaded to a specific folder, for example `/Meeting Recordings/To Process/`.

### **Step 2: Audio File Download**
*   **Node:** `OneDrive (Download)`.
*   **Logic:** The node downloads the newly uploaded audio file, making it available as binary data for the next step.

### **Step 3: Audio Transcription**
*   **Node:** `HttpRequest`.
*   **Logic:** This node sends the audio file to an external transcription API. The **OpenAI Whisper** API is the market standard for this operation.
    *   **Method:** `POST`
    *   **URL:** `https://api.openai.com/v1/audio/transcriptions`
    *   **Body:** `multipart/form-data`, with the audio file and model name (`whisper-1`).
    *   **Authentication:** Header Auth with the OpenAI API key.

### **Step 4: Transcription Analysis with AI**
*   **Node:** `Google Gemini Pro`.
*   **Logic:** The node receives the full transcription text (which can be very long, hence the use of a Pro model). The prompt is designed to generate structured output.
*   **Prompt:** `"You are a business analyst. Analyze the following meeting transcription and generate a report in Markdown with these exact sections: ## Executive Summary, ## Key Decisions (as a bulleted list), ## Action Items (as a table with columns: Action, Responsible, Deadline), ## Client Sentiment (Positive, Neutral, or Concerned, with a brief justification)."`

### **Step 5: Report Distribution**
*   **`Microsoft Outlook` Node:** Sends an email to all meeting participants (whose emails can be retrieved from the calendar or CRM) with the AI-generated report in the email body.
*   **`SharePoint (List Item: Create)` Node:** Saves key information (such as Action Items) to a centralized SharePoint List for task tracking.

### **Step 6: File Archiving**
*   **`OneDrive (Move)` Node:** Moves the original audio file from the `/To Process/` folder to the `/Archived/` folder. This step is fundamental to prevent the workflow from processing the same recording again.

## 4. Key Points and Best Practices

*   **Transcription as an External Service:** n8n does not have a native transcription node. Using the `HttpRequest` node to call a specialized service like Whisper is the correct pattern and demonstrates the great flexibility of n8n.
*   **Large File Handling:** Audio files can be heavy. Ensure that your n8n instance has sufficient memory and disk space to handle them temporarily during workflow execution.
*   **Use an AI Model for Long Contexts:** Transcriptions can be very long. It is essential to use a model with a large context window, such as `Gemini 1.5 Pro` or `Claude 3 Sonnet`, to be able to analyze the entire text at once without losing information.
*   **Prompt for Structured Extraction:** The value of this workflow lies in its ability to produce structured and actionable output. The prompt must explicitly ask the AI to use Markdown formatting (lists, tables) to make the report immediately usable.
*   **Post-Processing Archiving:** Always moving the processed file to an archive folder is a crucial best practice for workflow robustness. It prevents multiple processing and keeps the input folder organized.
