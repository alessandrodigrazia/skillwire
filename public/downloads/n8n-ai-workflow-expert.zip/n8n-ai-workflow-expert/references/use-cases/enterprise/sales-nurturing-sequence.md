# Caso d'Uso Enterprise: Sequenza di Nurturing per Vendite B2B

## 1. Obiettivo del Workflow

**Scopo:** Automatizzare l'invio di una sequenza di 3 email di nurturing personalizzate a un potenziale cliente (lead) quando questo entra in una fase specifica del processo di vendita. L'obiettivo è mantenere il contatto, fornire valore e spingere il lead verso un'azione (es. prenotare una call) senza un intervento manuale continuo da parte del venditore.

**Casi d'uso reali:**
*   Un lead ha scaricato un whitepaper e deve essere "scaldato".
*   Un contatto raccolto a una fiera deve essere inserito in un flusso di follow-up.
*   Un'opportunità in stallo nel CRM deve essere riattivata.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** CRM (es. HubSpot, Salesforce) o Webhook (quando un lead viene qualificato).
*   **Core Logic:** `Set`, `Wait`, `If`.
*   **AI:** `Google Gemini` (per la generazione personalizzata dei testi delle email).
*   **Comunicazione:** `Microsoft Outlook` (per l'invio delle email).
*   **Logging:** `Airtable` o aggiornamento del CRM (per tracciare il completamento della sequenza).

## 3. Logica del Flusso (Step-by-Step)

Questo workflow è progettato per essere una sequenza temporizzata che si auto-sostiene.

### **Step 1: Il Trigger - Inizio della Sequenza**
*   **Nodo:** `Webhook` o `HubSpot Trigger`.
*   **Logica:** Il workflow si avvia quando un sistema esterno (es. il CRM) notifica che un lead è entrato nella fase "Nurturing". L'input iniziale deve contenere almeno: `nome`, `cognome`, `email`, `azienda` e `contesto` (es. "ha scaricato il whitepaper su AI nel manifatturiero").

### **Step 2: Email #1 - Il Contatto Iniziale**
*   **Nodo `Set`:** Prepara il prompt per l'AI, includendo i dati del lead e l'obiettivo della prima email (es. "Presentati, fai riferimento al whitepaper scaricato e propon un'idea di valore iniziale").
*   **Nodo `Google Gemini`:** Genera il testo della prima email, personalizzandola.
*   **Nodo `Microsoft Outlook`:** Invia l'email generata all'indirizzo del lead.

### **Step 3: Pausa Strategica #1**
*   **Nodo `Wait`:** Il workflow viene messo in pausa per un periodo definito. È un passaggio cruciale per non "spammarlo".
*   **Configurazione:** `3 Giorni`.

### **Step 4: Email #2 - Il Follow-up di Valore**
*   **Nodo `Set`:** Prepara un nuovo prompt. Questa volta, l'obiettivo è fornire valore aggiunto. Esempio: `"Fai seguito alla precedente email. Menziona un caso studio rilevante per il settore '{{$json.azienda.settore}}' e allega il link al nostro ultimo articolo sul blog."`
*   **Nodo `Google Gemini`:** Genera la seconda email.
*   **Nodo `Microsoft Outlook`:** Invia la seconda email.

### **Step 5: Pausa Strategica #2**
*   **Nodo `Wait`:** Il workflow viene messo nuovamente in pausa, questa volta per un periodo più lungo.
*   **Configurazione:** `5 Giorni`.

### **Step 6: Email #3 - La Chiamata all'Azione Finale**
*   **Nodo `Set`:** Prepara l'ultimo prompt. L'obiettivo è ottenere una risposta o chiudere il ciclo.
    Esempio: `"Scrivi un'email breve e diretta. Chiedi se l'argomento è ancora di interesse e propon due slot per una call di 15 minuti la prossima settimana per discuterne."`
*   **Nodo `Google Gemini`:** Genera l'ultima email.
*   **Nodo `Microsoft Outlook`:** Invia l'ultima email.

### **Step 7: Logging e Conclusione**
*   **Nodo `Airtable (Update)`:** Aggiorna il record del lead nel database di tracciamento, impostando il campo `Stato Nurturing` su `"Completato"`.

## 4. Punti Chiave e Best Practice

*   **Personalizzazione Dinamica:** Il vero valore di questo workflow sta nella capacità dell'AI di personalizzare ogni email. I prompt devono essere progettati per sfruttare tutti i dati disponibili sul lead (`nome`, `azienda`, `settore`, `interessi passati`) per rendere la comunicazione il più possibile 1-a-1.
*   **Temporizzazione (`Wait`):** La durata delle pause è fondamentale. Sperimenta con tempistiche diverse (es. 2, 4, 7 giorni) per trovare il ritmo che funziona meglio per il tuo target.
*   **Logica di Uscita (Avanzato):** Questo workflow base prosegue fino alla fine. Una versione avanzata dovrebbe includere una **logica di uscita**. Questo si ottiene con un secondo workflow che si attiva quando il lead risponde a una delle email. Questo secondo workflow dovrebbe aggiornare lo stato del lead in Airtable/CRM a `"Ha Risposto"`, e il workflow di nurturing, prima di inviare ogni email, dovrebbe controllare questo stato con un nodo `If` per fermarsi immediatamente se il lead ha già risposto.
*   **Contenuto Sempre Aggiornato:** Per rendere le email di valore ancora più efficaci, il prompt per l'AI può essere arricchito dinamicamente. Ad esempio, prima di chiamare Gemini, un nodo `RSS Feed Read` può recuperare il link dell'ultimo post del blog aziendale, da includere nell'email.
*   **Test A/B sui Prompt:** Puoi facilmente testare l'efficacia di diversi stili di comunicazione. Duplica il workflow e modifica solo i prompt nel nodo `Set` per vedere quale sequenza genera più risposte.
