# Caso d'Uso Enterprise: Generatore di Presentazioni di Vendita

## 1. Obiettivo del Workflow

**Scopo:** Assistere un venditore nella creazione di una presentazione di vendita personalizzata e strategica. Il processo è diviso in due fasi: prima, l'AI genera uno "storyboard" (una scaletta delle slide), definendo la narrazione strategica. Poi, per ogni slide dello storyboard, l'AI genera il contenuto dettagliato, inclusi titolo, punti elenco e note per il relatore.

L'obiettivo è ridurre drasticamente il tempo di preparazione, garantendo al contempo che la presentazione sia logicamente strutturata, persuasiva e personalizzata sul cliente.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `Form Trigger` (per raccogliere gli obiettivi e il contesto della presentazione).
*   **AI:** `Google Gemini Pro` (per la creazione sia dello storyboard che del contenuto delle singole slide).
*   **Core Logic:** `Split in Batches` (per iterare sullo storyboard e generare una slide alla volta).
*   **Archiviazione:** `SharePoint` (per salvare l'output finale in un formato facilmente utilizzabile).

## 3. Logica del Flusso (Processo a Due Fasi)

Questo workflow è un eccellente esempio di come l'AI possa essere usata prima per la progettazione e poi per l'esecuzione.

### **Fase 1: Creazione dello Storyboard**

1.  **Trigger (`Form Trigger`):** Un form raccoglie i dati di input di alto livello: `Obiettivo della Presentazione`, `Audience Target`, `Numero di Slide Desiderato` e il contesto sul cliente (che può essere incollato o recuperato da un precedente workflow, come l'Account Planning).
2.  **Generazione Storyboard (`Google Gemini Pro`):** Una prima chiamata all'AI, usando la logica del tuo `presentationPrompt.js` per il `subtask: "generateStoryboard"`, genera la struttura narrativa della presentazione. L'output è un array JSON in cui ogni oggetto rappresenta una slide e contiene `id`, `title` e `purpose` (lo scopo di quella slide).

### **Fase 2: Generazione del Contenuto delle Slide (in un Loop)**

3.  **Loop (`Split in Batches`):** Il nodo viene configurato con `Batch Size: 1` per processare una slide dello storyboard alla volta.
4.  **Generazione Contenuto Slide (`Google Gemini Pro`):** All'interno del loop, per ogni slide, viene eseguita una seconda chiamata all'AI. Questa chiamata usa la logica del `subtask: "generateSlide"` e riceve come contesto:
    *   I dettagli della slide corrente (`title` e `purpose`).
    *   L'intero storyboard (per dare all'AI consapevolezza di dove si trova nella narrazione).
    *   Il contesto generale sul cliente.
    L'AI genera un oggetto JSON con il contenuto dettagliato della slide: `title`, `subtitle`, `contentBlocks` (in HTML) e `speakerNotes`.
5.  **Aggregazione Contenuti (`Aggregate`):** Dopo che il loop ha processato tutte le slide, un nodo `Aggregate` raccoglie i contenuti generati per ogni slide in un unico array.

### **Fase 3: Salvataggio e Notifica**

6.  **Formattazione Output (`Code`):** Un nodo `Code` prende l'array di slide e lo formatta in un unico documento Markdown, facile da leggere e da copiare.
7.  **Salvataggio (`SharePoint`):** Il file Markdown viene salvato su una Libreria Documentale di SharePoint.
8.  **Notifica (`Teams`):** Un messaggio notifica al venditore che la bozza della sua presentazione è pronta, con un link al documento.

## 4. Punti Chiave e Best Practice

*   **Approccio a Due Fasi (Struttura > Contenuto):** Separare la creazione dello storyboard dalla generazione del contenuto è un pattern vincente. Permette all'utente (o a un'altra AI) di validare la struttura narrativa prima di investire tempo e token nella scrittura dei dettagli. In una versione interattiva, si potrebbe inserire un'approvazione manuale dopo lo Step 2.
*   **Loop per la Generazione Modulare:** Usare `Split in Batches` con `Batch Size: 1` è il modo corretto per generare contenuti complessi in modo modulare. Permette di gestire ogni slide come un task separato, riducendo la probabilità di errori e migliorando la qualità del contenuto di ogni singola slide.
*   **Output per PowerPoint:** n8n non ha un nodo nativo per creare file `.pptx`. La best practice è generare il contenuto in un formato pulito e strutturato come il **Markdown**. Questo testo può poi essere facilmente copiato e incollato in un template PowerPoint aziendale, separando il compito creativo della generazione del contenuto da quello del design grafico.
*   **Passare il Contesto Completo nel Loop:** Nello Step 4, è fondamentale passare all'AI non solo i dettagli della slide corrente, ma l'intero storyboard. Questo dà al modello il contesto narrativo completo, permettendogli di creare transizioni più fluide e contenuti più coerenti con il flusso generale della presentazione.
