# Enterprise Use Case: Sales Presentation Generator

## 1. Workflow Objective

**Purpose:** Assist a salesperson in creating a personalized and strategic sales presentation. The process is divided into two phases: first, the AI generates a "storyboard" (a slide outline), defining the strategic narrative. Then, for each storyboard slide, the AI generates detailed content, including title, bullet points, and speaker notes.

The goal is to drastically reduce preparation time while ensuring the presentation is logically structured, persuasive, and personalized for the customer.

## 2. Technology Stack Used

*   **Trigger:** `Form Trigger` (to collect the presentation objectives and context).
*   **AI:** `Google Gemini Pro` (for creating both the storyboard and individual slide content).
*   **Core Logic:** `Split in Batches` (to iterate over the storyboard and generate one slide at a time).
*   **Storage:** `SharePoint` (to save the final output in an easily usable format).

## 3. Flow Logic (Two-Phase Process)

This workflow is an excellent example of how AI can be used first for design and then for execution.

### **Phase 1: Storyboard Creation**

1.  **Trigger (`Form Trigger`):** A form collects high-level input data: `Presentation Objective`, `Target Audience`, `Desired Number of Slides`, and customer context (which can be pasted or retrieved from a previous workflow, such as Account Planning).
2.  **Storyboard Generation (`Google Gemini Pro`):** A first AI call, using the logic from your `presentationPrompt.js` for the `subtask: "generateStoryboard"`, generates the presentation's narrative structure. The output is a JSON array where each object represents a slide and contains `id`, `title`, and `purpose` (the purpose of that slide).

### **Phase 2: Slide Content Generation (in a Loop)**

3.  **Loop (`Split in Batches`):** The node is configured with `Batch Size: 1` to process one storyboard slide at a time.
4.  **Slide Content Generation (`Google Gemini Pro`):** Within the loop, for each slide, a second AI call is executed. This call uses the logic of the `subtask: "generateSlide"` and receives as context:
    *   The current slide details (`title` and `purpose`).
    *   The entire storyboard (to give the AI awareness of where it is in the narrative).
    *   The general customer context.
    The AI generates a JSON object with the detailed slide content: `title`, `subtitle`, `contentBlocks` (in HTML), and `speakerNotes`.
5.  **Content Aggregation (`Aggregate`):** After the loop has processed all slides, an `Aggregate` node collects the generated content for each slide into a single array.

### **Phase 3: Saving and Notification**

6.  **Output Formatting (`Code`):** A `Code` node takes the slide array and formats it into a single Markdown document, easy to read and copy.
7.  **Saving (`SharePoint`):** The Markdown file is saved to a SharePoint Document Library.
8.  **Notification (`Teams`):** A message notifies the salesperson that their presentation draft is ready, with a link to the document.

## 4. Key Points and Best Practices

*   **Two-Phase Approach (Structure > Content):** Separating storyboard creation from content generation is a winning pattern. It allows the user (or another AI) to validate the narrative structure before investing time and tokens in writing the details. In an interactive version, a manual approval could be inserted after Step 2.
*   **Loop for Modular Generation:** Using `Split in Batches` with `Batch Size: 1` is the correct way to generate complex content in a modular fashion. It allows managing each slide as a separate task, reducing error probability and improving the content quality of each individual slide.
*   **Output for PowerPoint:** n8n does not have a native node for creating `.pptx` files. The best practice is to generate content in a clean, structured format like **Markdown**. This text can then be easily copied and pasted into a corporate PowerPoint template, separating the creative task of content generation from that of graphic design.
*   **Pass the Full Context in the Loop:** In Step 4, it is fundamental to pass the AI not only the current slide details but the entire storyboard. This gives the model the full narrative context, enabling it to create smoother transitions and content more consistent with the overall presentation flow.
