# Caso d'Uso Enterprise: Generazione Bozza di Business Case

## 1. Obiettivo del Workflow

**Scopo:** Accelerare drasticamente la creazione di documenti di business case. Il workflow fornisce un semplice form web in cui un utente (es. un product manager o un venditore) può inserire i dati chiave di un progetto. Questi dati vengono poi utilizzati da un'AI per generare una bozza completa e ben strutturata del business case in formato Microsoft Word, pronta per la revisione.

**Casi d'uso reali:**
*   Creare la documentazione iniziale per una nuova iniziativa di prodotto.
*   Formalizzare una proposta di investimento per un nuovo progetto interno.
*   Standardizzare il modo in cui i business case vengono presentati al management.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `Form Trigger` (per raccogliere i dati di input in modo strutturato).
*   **AI:** `Google Gemini Pro` (necessario un modello potente per la complessità del compito).
*   **Document Generation:** `Microsoft Word` (per creare il file `.docx` dal testo generato).
*   **Archiviazione:** `SharePoint` o `OneDrive` (per salvare il documento finale).
*   **Notifica:** `Microsoft Teams` o `Outlook`.

## 3. Logica del Flusso (Step-by-Step)

### **Step 1: Trigger - Raccolta Dati tramite Form**
*   **Nodo:** `Form Trigger`.
*   **Logica:** Questo nodo genera un URL univoco che punta a un form web. L'utente compila i campi del form, che sono stati predefiniti per raccogliere le informazioni essenziali del progetto.
*   **Campi del Form:** `Nome Progetto`, `Obiettivo Principale (1 frase)`, `KPI di Successo (es. Aumento MRR del 10%)`, `Costi Stimati (€)`, `Team/Persone Coinvolte`.

### **Step 2: Preparazione del Prompt Dettagliato**
*   **Nodo `Set`:** Prende i dati inviati tramite il form e li assembla in un prompt dettagliato per il modello AI, basandosi sulla logica del tuo `businessCasePrompt.js`.
*   **Prompt:** Il prompt istruisce l'AI ad agire come un senior business analyst e a generare un business case completo in formato Markdown, richiedendo sezioni specifiche come:
    *   `## 1. Executive Summary`
    *   `## 2. Problema e Opportunità`
    *   `## 3. Soluzione Proposta`
    *   `## 4. Analisi Finanziaria (basata sui costi stimati)`
    *   `## 5. Analisi dei Rischi`
    *   `## 6. Piano di Implementazione di Massima`
    *   `## 7. Metriche di Successo e KPI`

### **Step 3: Generazione della Bozza con AI**
*   **Nodo:** `Google Gemini Pro`.
*   **Logica:** Il nodo riceve il prompt dettagliato e genera il testo completo del business case in formato Markdown. Si usa un modello "Pro" data la necessità di produrre un testo lungo, coerente e ben strutturato.

### **Step 4: Creazione del Documento Word**
*   **Nodo:** `Microsoft Word`.
*   **Logica:** Questo nodo prende il testo in formato Markdown generato dall'AI e lo converte in un documento `.docx` formattato, con titoli, liste puntate e grassetti resi correttamente.

### **Step 5: Salvataggio del Documento**
*   **Nodo:** `SharePoint (Upload)`.
*   **Logica:** Il file `.docx` (disponibile come dato binario dall'output del nodo Word) viene caricato in una specifica Libreria Documentale su SharePoint, ad esempio `/Business Cases/Bozze/`.

### **Step 6: Notifica all'Utente**
*   **Nodo `Microsoft Teams`:** Invia un messaggio diretto all'utente che ha avviato il processo, informandolo che la bozza del suo business case è pronta e includendo un link diretto al documento su SharePoint.

## 4. Punti Chiave e Best Practice

*   **Il Form come Interfaccia Utente:** Il `Form Trigger` è un modo eccellente e a basso costo per fornire un'interfaccia utente strutturata per i workflow generativi. Guida l'utente a fornire esattamente le informazioni necessarie.
*   **L'Arte del Prompt Strutturato:** Il successo di questo workflow dipende al 90% dalla qualità del prompt. Fornire all'AI una struttura chiara da seguire (le sezioni del business case) è il modo migliore per ottenere un output di alta qualità e consistente.
*   **Da Markdown a Word:** Il nodo `Microsoft Word` è estremamente potente perché trasforma un semplice testo Markdown in un documento `.docx` professionale, pronto per essere condiviso e modificato in un ambiente aziendale.
*   **Un Acceleratore, non un Sostituto:** È importante posizionare questo workflow come un "generatore di prime bozze". L'output è una bozza di alta qualità che può far risparmiare ore di lavoro, ma è pensata per essere il punto di partenza per la revisione e il perfezionamento da parte di un essere umano.
*   **Modularità del Prompt:** Per workflow ancora più avanzati, diverse sezioni del prompt potrebbero essere caricate dinamicamente. Ad esempio, a seconda del "Tipo di Progetto" selezionato nel form (es. "IT" o "Marketing"), si potrebbe usare un template di prompt diverso per generare sezioni di analisi finanziaria o di mercato più specifiche.
