# Caso d'Uso Personal: Feed RSS a Post LinkedIn (con Ricerca)

## 1. Obiettivo del Workflow

**Scopo:** Creare un motore di content curation semi-automatico che monitora più fonti di notizie tramite feed RSS, usa un'AI per selezionare gli articoli più strategici e originali, li arricchisce con una ricerca web approfondita e infine genera un post LinkedIn che non è un semplice riassunto, ma un'analisi originale e ricca di contesto.

Questo caso d'uso, basato sul tuo workflow `03. RSS Feed → Post LinkedIn (powered by Gemini).json`, rappresenta un sistema editoriale avanzato.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `RSS Feed Read Trigger` (istanze multiple per diverse fonti).
*   **Database/Logging:** `Airtable` (per deduplicazione e storico dei post).
*   **AI (Analisi e Scrittura):** `Google Gemini` (in ruoli multipli).
*   **AI (Ricerca):** `Perplexity` (chiamato tramite `HttpRequest` per l'arricchimento dei contenuti).
*   **Output:** `LinkedIn`.

## 3. Logica del Flusso (Pattern Editoriale con Arricchimento)

Il workflow simula un vero e proprio processo editoriale.

### **Step 1: Aggregazione e Deduplicazione**
*   **Nodi `RSS Feed Read Trigger`:** Più trigger, uno per ogni fonte di notizie (es. TechCrunch, VentureBeat), monitorano i feed a orari diversi per distribuire il carico.
*   **Nodo `Airtable (Search)`:** Appena un nuovo articolo viene rilevato, il workflow controlla immediatamente se l'URL è già presente nel database per scartare i duplicati.

### **Step 2: Selezione Editoriale (AI Curation)**
*   **Nodo `Airtable (Search)`:** Recupera lo storico degli ultimi 10 post pubblicati per fornire contesto sulla nostra linea editoriale.
*   **Nodo `Google Gemini` (Agente "Capo Redattore"):** Questo è il primo, cruciale passaggio AI. L'agente riceve il nuovo articolo e lo storico dei post. Il suo compito è decidere se l'articolo è sufficientemente **interessante, strategico e originale** rispetto a quanto già pubblicato. Se l'articolo viene approvato, l'agente estrae anche gli argomenti chiave o le domande che meritano un approfondimento.

### **Step 3: Arricchimento con Ricerca Esterna**
*   **Nodo `HttpRequest` (chiamata a Perplexity):** Le domande o gli argomenti identificati dal "Capo Redattore" vengono inviati all'API di Perplexity. Perplexity esegue una ricerca sul web per raccogliere informazioni aggiuntive, dati recenti, statistiche o punti di vista alternativi non presenti nell'articolo originale.

### **Step 4: Generazione del Post Arricchito**
*   **Nodo `Google Gemini` (Agente "Copywriter Strategico"):** Questo secondo agente AI riceve un contesto molto ricco:
    1.  Il testo dell'articolo originale.
    2.  I risultati della ricerca di Perplexity.
    3.  Lo storico dei post recenti (per mantenere uno stile coerente).
    Il suo compito è scrivere un post per LinkedIn che non si limiti a riassumere l'articolo, ma che lo metta in prospettiva, lo arricchisca con i dati della ricerca e offra un'analisi originale.

### **Step 5: Quality Assurance e Pubblicazione**
*   **Nodo `Google Gemini` (Agente QA):** Un ultimo controllo di qualità sul testo finale.
*   **Nodo `LinkedIn (Post)`:** Pubblica il post finale.
*   **Nodo `Airtable (Create)`:** Registra il post nel database per future analisi di contesto.

## 4. Punti Chiave e Best Practice

*   **Workflow di Curatela, non solo di Ripubblicazione:** La vera potenza di questo workflow non è automatizzare la scrittura, ma automatizzare il **processo editoriale**. L'AI viene usata prima per **selezionare** e poi per **arricchire** il contenuto, un pattern molto più sofisticato.
*   **Arricchimento tramite Ricerca (RAG arricchito):** L'uso di un'AI di ricerca come Perplexity per aggiungere informazioni esterne è una forma avanzata di RAG. Il contenuto finale è superiore all'articolo originale perché è più completo e contestualizzato.
*   **Separazione dei Compiti AI:** L'uso di agenti AI distinti per la selezione ("Capo Redattore") e per la scrittura ("Copywriter") rispecchia un processo umano e porta a risultati di qualità superiore. Ogni agente ha un obiettivo chiaro e un contesto specifico.
*   **Gestione di Fonti Multiple:** Il workflow dimostra come aggregare e gestire input da più fonti (diversi feed RSS) in un unico processo di analisi standardizzato.
*   **Efficienza:** Sebbene più complesso, questo workflow è molto efficiente. Scarta automaticamente gli articoli non interessanti o ripetitivi, concentrando le risorse (e i costi dei token AI) solo sui contenuti a più alto potenziale.
