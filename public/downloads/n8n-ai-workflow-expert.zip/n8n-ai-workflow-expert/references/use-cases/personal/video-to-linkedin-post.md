# Personal Use Case: YouTube Video to LinkedIn Post

## 1. Workflow Objective

**Purpose:** Create an automatic system that monitors a YouTube playlist and, for each new video added, extracts the transcription, analyzes it with an AI, and generates a high-quality LinkedIn post, complete with logging and work queue cleanup.

This use case, based on your workflow `02. Video → Post LinkedIn (powered by Gemini).json`, is an excellent example of how to repurpose video content on text-based platforms.

## 2. Technology Stack Used

*   **Trigger:** `Schedule Trigger` (for periodic execution).
*   **Input:** `YouTube` (to read videos from a playlist).
*   **Database/Logging:** `Airtable` (for deduplication and tracking).
*   **AI:** `Google Gemini` (used for transcription, categorization, writing, and QA).
*   **Output:** `LinkedIn` (for publishing).
*   **Core Logic:** `Split in Batches`, `If`, `Code`, `Switch`.

## 3. Flow Logic (Pattern "Playlist as Inbox")

The workflow uses a YouTube playlist as a "mailbox" or work queue.

### **Step 1: Trigger and Time Check**
*   **`Schedule Trigger` Node:** Starts the workflow at regular intervals (e.g., every 2 hours).
*   **`Code` Node:** A simple check verifies that the current time is within an "operational window" (e.g., 08:00-20:00) before proceeding, to avoid publishing at undesirable hours.

### **Step 2: Video Retrieval and Deduplication**
*   **`YouTube (GetAll)` Node:** Reads all videos in a specific playlist (e.g., "Videos to Process").
*   **`Split in Batches` Node (`Batch Size: 1`):** Isolates each video to process it individually in a loop.
*   **`Airtable (Search)` Node:** Within the loop, searches the database to check if the current video's `VideoID` has already been processed. This is the **deduplication** step.
*   **`If` Node:** If the video already exists in the database, the flow for that video stops. Otherwise, it continues.

### **Step 3: Transcription and AI Analysis**
*   **`HttpRequest` (or `Google Gemini`) Node:** Performs video transcription. Your workflow uses an advanced Gemini 1.5 Pro feature that can accept a YouTube URL directly for transcription.
*   **`Google Gemini` (Categorizer Agent) Node:** Analyzes the transcription to determine the video category (e.g., `ANNOUNCEMENT`, `ANALYSIS`, `TUTORIAL`).

### **Step 4: Post Generation and Publishing**
*   This step follows the same logic as the article workflow:
    1.  **Historical Context:** `Airtable` retrieves previous posts from the same category.
    2.  **Draft Generation:** A `Switch` routes to a specialized `Gemini` agent that writes the post draft based on the transcription.
    3.  **Quality Assurance:** A `Gemini` "Editor-in-Chief" agent reviews and approves the final text.
    4.  **Publishing:** The `LinkedIn` node publishes the post.

### **Step 5: Logging and Queue Cleanup**
*   **`Airtable (Update)` Node:** Updates the video record in Airtable, marking it as `"Done"` and saving the post text and LinkedIn URL.
*   **`YouTube (Delete)` Node:** Removes the video from the "Videos to Process" playlist. This is the final step that completes the cycle, ensuring the work queue contains only new videos.

## 4. Key Points and Best Practices

*   **Playlist as Work Queue:** This is an extremely powerful and flexible design pattern. It allows a user to "assign tasks" to the workflow simply by adding a video to a playlist from any device.
*   **Transcription is the Heart:** The success of this workflow depends on the ability to obtain a good quality transcription from the video. Using multimodal models like Gemini 1.5 Pro that can directly process videos significantly simplifies this step.
*   **Robust Loop:** The combination of `Split in Batches` to process one video at a time and `Airtable` for deduplication makes the process very robust. Even if removing the video from the playlist fails, it will not be processed again.
*   **Time Control:** The `Code` node that checks the time is a simple but professional touch, giving greater control over when the automation interacts with the audience.
*   **Separation Between Curation and Processing:** The workflow does not concern itself with finding videos, but only with processing those the user has already selected. This separation of duties (manual curation vs. automated processing) is an excellent practice.
