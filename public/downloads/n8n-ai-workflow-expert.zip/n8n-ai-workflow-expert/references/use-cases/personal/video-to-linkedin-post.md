# Caso d'Uso Personal: Video YouTube a Post LinkedIn

## 1. Obiettivo del Workflow

**Scopo:** Creare un sistema automatico che monitora una playlist di YouTube e, per ogni nuovo video aggiunto, ne estrae la trascrizione, la analizza con un'AI e genera un post LinkedIn di alta qualità, completo di log e pulizia della coda di lavoro.

Questo caso d'uso, basato sul tuo workflow `02. Video → Post LinkedIn (powered by Gemini).json`, è un esempio eccellente di come riproporre contenuti video su piattaforme testuali.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `Schedule Trigger` (per l'esecuzione periodica).
*   **Input:** `YouTube` (per leggere i video da una playlist).
*   **Database/Logging:** `Airtable` (per la deduplicazione e il tracciamento).
*   **AI:** `Google Gemini` (usato per la trascrizione, categorizzazione, scrittura e QA).
*   **Output:** `LinkedIn` (per la pubblicazione).
*   **Core Logic:** `Split in Batches`, `If`, `Code`, `Switch`.

## 3. Logica del Flusso (Pattern "Playlist as Inbox")

Il workflow utilizza una playlist di YouTube come una "casella di posta" o una coda di lavoro.

### **Step 1: Trigger e Controllo Orario**
*   **Nodo `Schedule Trigger`:** Avvia il workflow a intervalli regolari (es. ogni 2 ore).
*   **Nodo `Code`:** Un semplice controllo verifica che l'orario corrente sia all'interno di una "finestra operativa" (es. 08:00-20:00) prima di procedere, per evitare di pubblicare in orari indesiderati.

### **Step 2: Recupero e Deduplicazione dei Video**
*   **Nodo `YouTube (GetAll)`:** Legge tutti i video presenti in una playlist specifica (es. "Video da Processare").
*   **Nodo `Split in Batches` (`Batch Size: 1`):** Isola ogni video per processarlo singolarmente in un loop.
*   **Nodo `Airtable (Search)`:** All'interno del loop, cerca nel database se il `VideoID` del video corrente è già stato processato. Questo è il passaggio di **deduplicazione**.
*   **Nodo `If`:** Se il video esiste già nel database, il flusso per quel video si interrompe. Altrimenti, prosegue.

### **Step 3: Trascrizione e Analisi AI**
*   **Nodo `HttpRequest` (o `Google Gemini`):** Esegue la trascrizione del video. Il tuo workflow usa una funzionalità avanzata di Gemini 1.5 Pro che può accettare un URL di YouTube direttamente per la trascrizione.
*   **Nodo `Google Gemini` (Agente Categorizzatore):** Analizza la trascrizione per determinare la categoria del video (es. `ANNUNCIO`, `ANALISI`, `TUTORIAL`).

### **Step 4: Generazione e Pubblicazione del Post**
*   Questo passaggio ricalca la logica del workflow per gli articoli:
    1.  **Contesto Storico:** `Airtable` recupera i post precedenti della stessa categoria.
    2.  **Generazione Bozza:** Uno `Switch` indirizza a un agente `Gemini` specializzato che scrive la bozza del post basandosi sulla trascrizione.
    3.  **Quality Assurance:** Un agente `Gemini` "Capo Redattore" revisiona e approva il testo finale.
    4.  **Pubblicazione:** Il nodo `LinkedIn` pubblica il post.

### **Step 5: Logging e Pulizia della Coda**
*   **Nodo `Airtable (Update)`:** Aggiorna il record del video in Airtable, segnandolo come `"Done"` e salvando il testo del post e l'URL di LinkedIn.
*   **Nodo `YouTube (Delete)`:** Rimuove il video dalla playlist "Video da Processare". Questo è il passaggio finale che completa il ciclo, assicurando che la coda di lavoro contenga solo video nuovi.

## 4. Punti Chiave e Best Practice

*   **Playlist come Coda di Lavoro:** Questo è un pattern di design estremamente potente e flessibile. Permette a un utente di "assegnare compiti" al workflow semplicemente aggiungendo un video a una playlist da qualsiasi dispositivo.
*   **La Trascrizione è il Cuore:** Il successo di questo workflow dipende dalla capacità di ottenere una trascrizione di buona qualità dal video. L'uso di modelli multimodali come Gemini 1.5 Pro che possono processare direttamente i video semplifica notevolmente questo passaggio.
*   **Loop Robusto:** La combinazione di `Split in Batches` per processare un video alla volta e di `Airtable` per la deduplicazione rende il processo molto robusto. Anche se la rimozione del video dalla playlist dovesse fallire, non verrà processato di nuovo.
*   **Controllo Temporale:** Il nodo `Code` che verifica l'orario è un tocco semplice ma professionale, che dà un maggiore controllo su quando l'automazione interagisce con il pubblico.
*   **Separazione tra Creazione e Processamento:** Il workflow non si occupa di trovare i video, ma solo di processare quelli che l'utente ha già selezionato. Questa separazione dei compiti (curation manuale vs. processamento automatico) è un'ottima pratica.
