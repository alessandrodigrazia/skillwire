# Caso d'Uso Personal: Articolo da Email a Post LinkedIn

## 1. Obiettivo del Workflow

**Scopo:** Automatizzare completamente il processo di content creation che trasforma un articolo, ricevuto via email, in un post LinkedIn di alta qualità, pronto per la pubblicazione. Il workflow è progettato per essere robusto, intelligente e per mantenere un alto standard qualitativo attraverso un sistema di agenti AI.

Questo caso d'uso è basato sul tuo workflow `01. Articolo → Post LinkedIn (powered by Gemini).json`.

## 2. Stack Tecnologico Utilizzato

*   **Trigger:** `Schedule Trigger` (per eseguire il controllo periodicamente).
*   **Input:** `Gmail` (per leggere le email con una specifica etichetta).
*   **Database/Logging:** `Airtable` (per tracciare i post pubblicati e fornire contesto storico).
*   **AI:** `Google Gemini` (utilizzato in ruoli multipli: categorizzazione, scrittura e quality assurance).
*   **Output:** `LinkedIn` (per la pubblicazione del post).

## 3. Logica del Flusso (Sistema ad Agenti Multi-Step)

Il workflow implementa una sofisticata catena di montaggio editoriale basata su AI.

### **Step 1: Identificazione del Contenuto**
*   **Nodo `Schedule Trigger`:** Avvia il workflow a intervalli regolari (es. ogni 2 ore).
*   **Nodo `Gmail (GetAll)`:** Cerca tutte le email con l'etichetta `"DaConvertire"`.
*   **Nodo `Code`:** Se vengono trovate più email, seleziona solo la più vecchia per garantire un'elaborazione in ordine cronologico (FIFO - First-In, First-Out).

### **Step 2: Analisi e Categorizzazione**
*   **Nodo `Google Gemini` (Agente Categorizzatore):** Legge il testo dell'articolo e lo classifica in una categoria predefinita (es. `ANNUNCIO`, `ANALISI`, `TUTORIAL`, `GENERALE`).

### **Step 3: Raccolta Contesto**
*   **Nodo `Airtable (Search)`:** Cerca nella tabella dei post già pubblicati gli ultimi 5 articoli della stessa categoria identificata nello step precedente.
*   **Nodo `Code`:** Consolida questi post storici in un unico blocco di testo (`<STORICO_POST_RECENTI>`) da passare all'agente scrittore per evitare ripetizioni.

### **Step 4: Generazione della Bozza**
*   **Nodo `Switch`:** Indirizza il flusso a un "agente copywriter" specializzato in base alla categoria. Ogni ramo dello switch porta a un nodo `Google Gemini` con un prompt diverso, ottimizzato per scrivere post di tipo annuncio, analisi, ecc.
*   **Nodo `Google Gemini` (Agente Copywriter):** Riceve il testo dell'articolo e lo storico dei post. Il suo compito è generare la prima bozza del post LinkedIn.

### **Step 5: Quality Assurance (QA)**
*   **Nodo `Google Gemini` (Agente QA - "Capo Redattore"):** Riceve la bozza generata e la confronta con il testo originale e una checklist di qualità (definita nel prompt). Decide se il post è `APPROVATO` o se necessita di una `REVISIONE`, e in tal caso lo corregge direttamente. L'output è un JSON con la decisione e il testo finale (`final_post_text`).

### **Step 6: Pubblicazione e Logging**
*   **Nodo `LinkedIn (Post)`:** Pubblica il `final_post_text` approvato sulla pagina aziendale.
*   **Nodo `Airtable (Create)`:** Registra il nuovo post nel database, salvando il testo, la categoria e l'URN del post di LinkedIn.

### **Step 7: Pulizia**
*   **Nodi `Gmail (Remove/Add Labels)`:** Rimuove l'etichetta `"DaConvertire"` dall'email originale e aggiunge l'etichetta `"Convertito"`, assicurando che non venga mai più elaborata.

## 4. Punti Chiave e Best Practice

*   **Sistema ad Agenti Specializzati:** L'uso di più nodi Gemini con ruoli diversi (Categorizzatore, Copywriter, QA) è un pattern avanzato che garantisce una qualità dell'output molto più elevata rispetto a un singolo prompt monolitico.
*   **Generazione Contestuale:** Il recupero dello storico da Airtable (Step 3) è una tecnica fondamentale. Fornisce al modello AI un contesto sulle pubblicazioni recenti, spingendolo a creare contenuti più originali e a variare gli angoli di analisi.
*   **Gestione dello Stato tramite Etichette:** L'uso delle etichette di Gmail per gestire il ciclo di vita di un'email (`DaConvertire` -> `Convertito`) è una best practice semplice e robusta per il controllo del flusso in workflow asincroni.
*   **Separazione tra Trigger e Logica:** Il workflow non si attiva su ogni email, ma è schedulato. Questo gli permette di processare le email una alla volta in modo controllato, evitando di sovraccaricare il sistema o di incorrere in race condition.
