# Nodo: OpenAI Chat Model (`@n8n/n8n-nodes-langchain.lmChatOpenAi`)

## 1. Descrizione

Questo nodo permette l'integrazione con i modelli di linguaggio della famiglia GPT (Generative Pre-trained Transformer) di OpenAI. Dall'analisi del dataset, questo è risultato il nodo AI più utilizzato, presente in 633 workflow.

All'interno di questa skill, OpenAI è considerato il **modello secondario**, da utilizzare quando i requisiti di un task superano le capacità di Gemini o quando è richiesta la massima accuratezza possibile, specialmente nell'estrazione di dati strutturati complessi.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Model** | Seleziona il modello GPT da utilizzare. | `gpt-4o-mini` (veloce), `gpt-4o` (massima accuratezza) |
| **Messages** | L'array di messaggi che costituisce la conversazione. | `{{ $json.prompt }}` |
| **Options** | Contiene i parametri per controllare il comportamento del modello. | |
| `temperature` | Controlla la creatività (0.0 per risposte fattuali, 1.0+ per massima creatività). | `0.5` |
| `maxTokens` | Il numero massimo di token da generare. | `2048` |
| `response_format` | Forza l'output in un formato specifico, come JSON. | `json_object` |

## 3. Esempio di Configurazione JSON

Questo esempio è tratto dal workflow `0472_Aggregate_Gmail_Create_Triggered.json`, dove viene usato per etichettare email.

```json
{
  "parameters": {
    "model": "gpt-4o-mini",
    "options": {
      "temperature": 0.3,
      "maxTokens": 1024
    }
  },
  "id": "uuid-goes-here",
  "name": "OpenAI Chat",
  "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "openAiApi": {
      "id": "credential-id",
      "name": "OpenAI Account"
    }
  }
}
```

## 4. Caso d'Uso Pratico (Pattern: Data Extraction)

OpenAI eccelle nell'estrazione di dati strutturati. Un caso d'uso comune è l'analisi di un testo non strutturato (come il corpo di un'email o una fattura) per estrarre informazioni in formato JSON.

**Flusso Semplificato:**
1.  **Gmail (Trigger):** Un'email con una fattura in allegato avvia il workflow.
2.  **Extract from File:** Il testo della fattura PDF viene estratto.
3.  **OpenAI Chat (Questo Nodo):** Riceve il testo e un prompt che chiede di estrarre i dati (numero fattura, data, importo, IVA) in formato JSON.
4.  **Set:** I dati JSON estratti vengono mappati su campi specifici.
5.  **Airtable/Google Sheets:** I dati strutturati vengono salvati in un database o foglio di calcolo.

**Input del nodo OpenAI:**
*   `messages.content`: Contiene il testo della fattura e un prompt che include lo schema JSON desiderato.
*   `options.response_format`: Impostato su `json_object` per garantire che l'output sia un JSON valido.
*   `options.temperature`: Impostato su un valore basso (es. `0.1`) per ridurre le allucinazioni e aumentare la precisione.

**Output del nodo OpenAI:**
*   Un oggetto JSON contenente i dati estratti, pronto per essere elaborato dal nodo successivo.

## 5. Best Practices & Consigli

*   **Quando Sceglierlo:** Usa OpenAI al posto di Gemini quando la **massima accuratezza** è più importante del costo. È la scelta migliore per l'estrazione di dati strutturati complessi, la generazione di codice o quando i modelli Gemini non forniscono la qualità desiderata.
*   **Usa `gpt-4o-mini` per Bilanciare:** È un ottimo punto di partenza che offre una qualità molto alta a un costo e una velocità ragionevoli, competendo direttamente con Gemini Flash.
*   **Attiva `JSON Mode`:** Se devi estrarre JSON, imposta il parametro `Response Format` su `JSON Object`. Questo riduce drasticamente gli errori di parsing.
*   **Prompting per JSON:** Nel tuo prompt, fornisci sempre un esempio chiaro del JSON che ti aspetti. Esempio: `"Rispondi solo con un oggetto JSON che segua questo schema: { \"nome\": \"string\", \"importo\": number }"`.
*   **Monitora i Costi:** I modelli OpenAI, specialmente `gpt-4o`, possono essere significativamente più costosi di Gemini. Usali in modo mirato solo dove il loro valore è massimo.
