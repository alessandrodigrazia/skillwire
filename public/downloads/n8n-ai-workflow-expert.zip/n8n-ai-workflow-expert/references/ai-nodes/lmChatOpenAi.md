# Node: OpenAI Chat Model (`@n8n/n8n-nodes-langchain.lmChatOpenAi`)

## 1. Description

This node enables integration with OpenAI's GPT (Generative Pre-trained Transformer) family of language models. From the dataset analysis, this turned out to be the most used AI node, present in 633 workflows.

Within this skill, OpenAI is considered the **secondary model**, to be used when a task's requirements exceed Gemini's capabilities or when maximum possible accuracy is required, especially for extracting complex structured data.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Model** | Selects the GPT model to use. | `gpt-4o-mini` (fast), `gpt-4o` (maximum accuracy) |
| **Messages** | The array of messages that constitute the conversation. | `{{ $json.prompt }}` |
| **Options** | Contains the parameters to control the model's behavior. | |
| `temperature` | Controls creativity (0.0 for factual responses, 1.0+ for maximum creativity). | `0.5` |
| `maxTokens` | The maximum number of tokens to generate. | `2048` |
| `response_format` | Forces the output into a specific format, such as JSON. | `json_object` |

## 3. JSON Configuration Example

This example is taken from the workflow `0472_Aggregate_Gmail_Create_Triggered.json`, where it is used for email labeling.

```json
{
  "parameters": {
    "model": "gpt-4o-mini",
    "options": {
      "temperature": 0.3,
      "maxTokens": 1024
    }
  },
  "id": "uuid-goes-here",
  "name": "OpenAI Chat",
  "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "openAiApi": {
      "id": "credential-id",
      "name": "OpenAI Account"
    }
  }
}
```

## 4. Practical Use Case (Pattern: Data Extraction)

OpenAI excels at structured data extraction. A common use case is analyzing unstructured text (such as an email body or an invoice) to extract information in JSON format.

**Simplified Flow:**
1.  **Gmail (Trigger):** An email with an invoice attachment triggers the workflow.
2.  **Extract from File:** The text of the invoice PDF is extracted.
3.  **OpenAI Chat (This Node):** Receives the text and a prompt asking to extract the data (invoice number, date, amount, VAT) in JSON format.
4.  **Set:** The extracted JSON data is mapped to specific fields.
5.  **Airtable/Google Sheets:** The structured data is saved to a database or spreadsheet.

**OpenAI node input:**
*   `messages.content`: Contains the invoice text and a prompt that includes the desired JSON schema.
*   `options.response_format`: Set to `json_object` to ensure the output is valid JSON.
*   `options.temperature`: Set to a low value (e.g., `0.1`) to reduce hallucinations and increase accuracy.

**OpenAI node output:**
*   A JSON object containing the extracted data, ready to be processed by the next node.

## 5. Best Practices & Tips

*   **When to Choose It:** Use OpenAI instead of Gemini when **maximum accuracy** is more important than cost. It is the best choice for complex structured data extraction, code generation, or when Gemini models do not provide the desired quality.
*   **Use `gpt-4o-mini` for Balance:** It is an excellent starting point that offers very high quality at a reasonable cost and speed, competing directly with Gemini Flash.
*   **Enable `JSON Mode`:** If you need to extract JSON, set the `Response Format` parameter to `JSON Object`. This drastically reduces parsing errors.
*   **Prompting for JSON:** In your prompt, always provide a clear example of the JSON you expect. Example: `"Reply only with a JSON object that follows this schema: { \"name\": \"string\", \"amount\": number }"`.
*   **Monitor Costs:** OpenAI models, especially `gpt-4o`, can be significantly more expensive than Gemini. Use them in a targeted manner only where their value is greatest.
