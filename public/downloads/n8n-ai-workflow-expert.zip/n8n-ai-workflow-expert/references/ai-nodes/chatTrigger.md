# Node: Chat Trigger (`@n8n/n8n-nodes-langchain.chatTrigger`)

## 1. Description

The **Chat Trigger** node is a specialized trigger that creates a web-based chat interface directly within the n8n environment. Its primary purpose is to provide a quick and easy way to **test and debug conversational workflows**, particularly those using an `AI Agent`.

Instead of having to configure a bot on Telegram, Slack, or another messaging service, you can interact with your workflow through a simple web page. In the analyzed dataset, it is present in 181 workflows, almost always paired with an `AI Agent` node.

## 2. Key Parameters

The node has a very simple configuration, but it exposes crucial output data.

| Parameter/Output | Description | Example Value |
| :--- | :--- | :--- |
| **Webhook URL** | The public URL to access the chat interface. n8n provides a test URL (temporary) and a production one (permanent). | `https://n8n.example.com/webhook/chat-uuid` |
| **Output: `message`** | The text of the message sent by the user in the chat. | `"What is 5 times 8?"` |
| **Output: `responseUrl`** | **(Crucial)** The URL to which the response must be sent in order for it to appear in the chat interface. | `https://n8n.example.com/webhook/chat-uuid/respond` |
| **Output: `userId`** | A unique ID for the chat session user, useful for managing separate memories. | `"user-abc-123"` |

## 3. JSON Configuration Example

```json
{
  "parameters": {},
  "id": "uuid-goes-here",
  "name": "When chat message received",
  "type": "@n8n/n8n-nodes-langchain.chatTrigger",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "webhookId": "webhook-uuid"
}
```

## 4. Practical Use Case (Pattern: Agent Development and Debugging)

This node is the ideal starting point for testing an AI agent.

**Simplified Flow:**
1.  **Chat Trigger (This Node):** The user opens the webhook URL and types a message (e.g., "Who is the CEO of OpenAI?").
2.  **AI Agent:** Receives the message from the `chatTrigger` output.
3.  **Reasoning and Tool Use:** The agent decides to use the `Wikipedia` tool to search for "CEO of OpenAI".
4.  **Response Formulation:** The agent receives the information and formulates a complete response.
5.  **Respond to Webhook:** This special node receives the agent's final response and sends it to the `responseUrl` provided by the `chatTrigger`. The response immediately appears in the user's chat interface.

This creates an immediate feedback loop, perfect for development.

## 5. Best Practices & Tips

*   **Development Tool, Not for Production:** Consider this node as a tool for debugging and for creating simple internal interfaces. For a chatbot aimed at external customers, it is always better to use a dedicated trigger such as `Telegram Trigger`, `Slack Trigger`, or `Webhook` to integrate it into your site.
*   **Always Use `Respond to Webhook`:** To send a response to the chat, you **must** use the `Respond to Webhook` node. Pass it the response you want to display and make sure the "Response URL" option is set with the expression `{{ $json.responseUrl }}` coming from the `chatTrigger` node.
*   **Session Management:** Every time you open the chat trigger URL in a new browser tab, a new session is created with a new `userId`. This is great for testing how the agent handles conversations with different users, especially if you are using memory.
*   **Embeddable via `iframe`:** The chat interface is a simple web page. You can embed it in other internal applications (such as an admin panel) using an `<iframe>` tag to quickly create AI-based data query tools for your team.
