# Nodo: Window Buffer Memory (`@n8n/n8n-nodes-langchain.memoryBufferWindow`)

## 1. Descrizione

Il nodo **Window Buffer Memory** fornisce una "memoria a breve termine" per un `AI Agent`. Il suo scopo è registrare gli ultimi `K` scambi di una conversazione (messaggio dell'utente e risposta dell'AI) e passarli all'agente come contesto per le interazioni successive.

Senza questo nodo, un agente è "senza stato" (stateless): ogni domanda è un'interazione nuova e non ha alcun ricordo di ciò che è stato detto prima. Con questo nodo, l'agente diventa "con stato" (stateful) e può sostenere una conversazione naturale, rispondere a domande di follow-up e ricordare il contesto. È un componente indispensabile per qualsiasi chatbot o assistente conversazionale.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Memory Key** | Il nome del campo che conterrà la cronologia della chat nel prompt inviato all'agente. Il valore predefinito è `chat_history` e raramente necessita di essere cambiato. | `chat_history` |
| **Session ID** | **(Cruciale)** Un ID univoco che identifica una specifica conversazione. Permette all'agente di mantenere memorie separate per utenti diversi. | `{{ $json.userId }}` o `{{ $json.message.chat.id }}` |
| **K** | Il numero di interazioni passate (un'interazione = 1 domanda + 1 risposta) da conservare in memoria. | `10` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra una configurazione di memoria tipica per un chatbot.

```json
{
  "parameters": {
    "memoryKey": "chat_history",
    "sessionId": "{{ $json.userId }}",
    "k": 10
  },
  "id": "uuid-goes-here",
  "name": "Simple Memory",
  "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Agente Conversazionale)

**Obiettivo:** Creare un agente che ricordi il contesto della conversazione.

**Flusso Semplificato:**
1.  **Chat Trigger:** L'utente avvia una conversazione e invia un messaggio. Il nodo espone un `userId` univoco per quella sessione.
2.  **Window Buffer Memory (Questo Nodo):** Viene configurato con `Session ID: {{ $json.userId }}`. Recupera la cronologia della chat per quell'utente specifico (se esiste).
3.  **AI Agent:** È collegato al nodo di memoria. Il suo prompt riceve automaticamente la `chat_history`.

**Esempio di Conversazione:**

*   **Utente:** `"Chi ha scritto la Divina Commedia?"`
    *   *Memoria:* (vuota)
    *   *Agente:* Risponde `"Dante Alighieri."`
    *   *Memoria:* Salva lo scambio: `[Human: "Chi ha scritto...", AI: "Dante Alighieri."]`

*   **Utente:** `"E in che anno è nato?"`
    *   *Memoria:* Recupera lo scambio precedente e lo passa all'agente.
    *   *Agente:* Grazie alla cronologia, capisce che "lui" si riferisce a Dante e risponde: `"Dante Alighieri è nato nel 1265."`
    *   *Memoria:* Aggiunge il nuovo scambio alla cronologia.

Senza il nodo di memoria, alla seconda domanda l'agente non avrebbe saputo a chi si riferisse "lui".

## 5. Best Practices & Consigli

*   **Obbligatorio per le Conversazioni:** Se il tuo agente deve gestire più di un singolo scambio domanda-risposta, l'uso di un nodo di memoria è **essenziale**.
*   **Imposta un `Session ID` Dinamico:** Questo è il parametro più importante. Deve essere collegato a un valore che identifica univocamente la conversazione (es. l'ID utente dal `Chat Trigger`, l'ID della chat da `Telegram Trigger`, ecc.). **Non usare mai un valore statico in produzione**, altrimenti tutti gli utenti condivideranno la stessa, caotica, memoria.
*   **Bilancia il Valore di `K`:** `K` rappresenta il numero di scambi da ricordare. Un valore troppo basso (es. 2-3) farà sì che l'agente "dimentichi" in fretta. Un valore troppo alto (es. 20+) consumerà molti token nel context window del modello AI, aumentando i costi e potenzialmente superando i limiti. Inizia con un valore ragionevole come `10`.
*   **Memoria di Sessione vs. Persistente:** Questo nodo fornisce una memoria di sessione, che si resetta alla chiusura del workflow (o dopo un periodo di inattività). Per una memoria a lungo termine che sopravvive tra diverse esecuzioni, esistono alternative più complesse come `Redis-Backed Chat Memory` (`@n8n/n8n-nodes-langchain.memoryRedis`), che richiedono però un'infrastruttura esterna (un database Redis).
