# Nodo: Google Gemini Chat Model (`@n8n/n8n-nodes-langchain.googleGemini`)

## 1. Descrizione

Questo è il nodo principale per interagire con i modelli di linguaggio (LLM) di Google Gemini. È il cuore della maggior parte dei workflow AI-powered, utilizzato per compiti come la generazione di testo, la classificazione, la traduzione e l'analisi del contenuto.

La filosofia di questa skill prevede l'uso di Gemini come **modello di default** per il suo eccellente rapporto costo/performance, come evidenziato nel file `model-selection-matrix.md`.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Model ID** | Seleziona il modello Gemini da utilizzare. | `models/gemini-2.5-flash` (default), `models/gemini-2.5-pro` (per compiti complessi) |
| **Messages** | L'array di messaggi che costituisce la conversazione. Solitamente contiene il `systemMessage` (opzionale) e il prompt dell'utente. | `{{ $json.prompt }}` |
| **Options** | Contiene i parametri per controllare il comportamento del modello. | |
| `temperature` | Controlla la "creatività" della risposta (0.0 per risposte deterministiche, 1.0 per massima creatività). | `0.7` (default bilanciato) |
| `maxOutputTokens` | Il numero massimo di token che il modello può generare nella risposta. Utile per controllare costi e lunghezza. | `2048` |
| `topP`, `topK` | Parametri avanzati per il campionamento del token. Generalmente non è necessario modificarli. | `1`, `40` |

## 3. Esempio di Configurazione JSON

Questo è un esempio di come appare il nodo Gemini all'interno del file JSON di un workflow.

```json
{
  "parameters": {
    "modelId": {
      "__rl": true,
      "value": "models/gemini-2.5-flash",
      "mode": "list"
    },
    "messages": {
      "values": [
        {
          "content": "=<STORICO_POST_RECENTI>\n{{ $json.historicalContext }}\n</STORICO_POST_RECENTI>\n\n<SOURCE_MATERIAL>\n{{ $json.articleText }}\n</SOURCE_MATERIAL>"
        }
      ]
    },
    "options": {
      "systemMessage": "# MENTALITÀ E RUOLO: IL DECODIFICATORE STRATEGICO...",
      "maxOutputTokens": 8000
    }
  },
  "id": "39bd3173-55ae-471c-b3b9-c1f5edfd57d5",
  "name": "Copywriter ANNUNCI",
  "type": "@n8n/n8n-nodes-langchain.googleGemini",
  "typeVersion": 1,
  "position": [
    0,
    -256
  ],
  "credentials": {
    "googlePalmApi": {
      "id": "CyLqP7wsNRAV5EDp",
      "name": "Google Gemini(PaLM) Api account"
    }
  }
}
```

## 4. Caso d'Uso Pratico (Pattern: Content Automation)

Questo nodo è centrale nel pattern "Article to Social Post", come visto nel workflow `01. Articolo → Post LinkedIn (powered by Gemini).json`.

**Flusso Semplificato:**
1.  **Set (Prepara Dati):** Un nodo `Set` raccoglie il testo dell'articolo e lo storico dei post precedenti.
2.  **Google Gemini (Questo Nodo):** Riceve i dati e un `systemMessage` che gli assegna il ruolo di "Copywriter". Il suo compito è generare il testo del post LinkedIn.
3.  **Code (Estrai Risposta):** Un nodo `Code` esegue il parsing della risposta del modello per estrarre solo il testo del post.
4.  **LinkedIn (Pubblica):** Il testo pulito viene inviato al nodo LinkedIn per la pubblicazione.

**Input del nodo Gemini:**
*   `messages.content`: Contiene il testo dell'articolo e lo storico dei post, passati dinamicamente da un nodo precedente tramite espressioni `{{ ... }}`.
*   `options.systemMessage`: Contiene un prompt molto dettagliato che definisce il ruolo, il tono, lo stile e il formato di output desiderato.

**Output del nodo Gemini:**
*   Un oggetto JSON contenente la risposta del modello, solitamente in `content.parts[0].text`.

## 5. Best Practices & Consigli

*   **Inizia Sempre con `gemini-2.5-flash`:** Come indicato nella matrice di selezione, questo modello offre il miglior equilibrio per il 90% dei casi d'uso. Usa `gemini-2.5-pro` solo se la complessità del compito lo richiede esplicitamente (es. analisi di immagini, ragionamenti molto complessi).
*   **Sfrutta il `systemMessage`:** Non scrivere tutto il prompt nel campo `content`. Usa il `systemMessage` (nelle `options`) per definire il ruolo e le regole generali. Questo migliora la coerenza delle risposte.
*   **Struttura l'Input:** Invece di passare un unico blocco di testo, usa tag come `<ARTICLE>` e `<STORICO>` per separare logicamente le diverse parti dell'input. Questo aiuta il modello a capire meglio il contesto.
*   **Controlla i Costi con `maxOutputTokens`:** Imposta sempre un limite ragionevole per evitare risposte troppo lunghe e costi inaspettati.
*   **Abbassa la `temperature` per l'Estrazione Dati:** Se usi Gemini per estrarre dati strutturati (es. JSON), imposta `temperature: 0.2` per ottenere risposte più prevedibili e consistenti.
*   **Gestisci l'Output con un Nodo `Code`:** Non passare mai l'output grezzo di Gemini direttamente a un altro servizio. Usa sempre un nodo `Code` intermedio per pulire la risposta, estrarre esattamente ciò che ti serve e gestire eventuali errori o formati inattesi.
