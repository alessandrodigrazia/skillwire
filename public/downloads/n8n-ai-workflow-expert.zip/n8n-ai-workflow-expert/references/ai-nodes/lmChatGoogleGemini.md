# Node: Google Gemini Chat Model (`@n8n/n8n-nodes-langchain.googleGemini`)

## 1. Description

This is the main node for interacting with Google Gemini language models (LLMs). It is the heart of most AI-powered workflows, used for tasks such as text generation, classification, translation, and content analysis.

This skill's philosophy calls for using Gemini as the **default model** due to its excellent cost/performance ratio, as highlighted in the `model-selection-matrix.md` file.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Model ID** | Selects the Gemini model to use. | `models/gemini-2.5-flash` (default), `models/gemini-2.5-pro` (for complex tasks) |
| **Messages** | The array of messages that constitute the conversation. Usually contains the `systemMessage` (optional) and the user prompt. | `{{ $json.prompt }}` |
| **Options** | Contains the parameters to control the model's behavior. | |
| `temperature` | Controls the "creativity" of the response (0.0 for deterministic responses, 1.0 for maximum creativity). | `0.7` (balanced default) |
| `maxOutputTokens` | The maximum number of tokens the model can generate in the response. Useful for controlling costs and length. | `2048` |
| `topP`, `topK` | Advanced parameters for token sampling. Generally, these do not need to be modified. | `1`, `40` |

## 3. JSON Configuration Example

This is an example of how the Gemini node appears inside a workflow's JSON file.

```json
{
  "parameters": {
    "modelId": {
      "__rl": true,
      "value": "models/gemini-2.5-flash",
      "mode": "list"
    },
    "messages": {
      "values": [
        {
          "content": "=<STORICO_POST_RECENTI>\n{{ $json.historicalContext }}\n</STORICO_POST_RECENTI>\n\n<SOURCE_MATERIAL>\n{{ $json.articleText }}\n</SOURCE_MATERIAL>"
        }
      ]
    },
    "options": {
      "systemMessage": "# MENTALITÀ E RUOLO: IL DECODIFICATORE STRATEGICO...",
      "maxOutputTokens": 8000
    }
  },
  "id": "39bd3173-55ae-471c-b3b9-c1f5edfd57d5",
  "name": "Copywriter ANNUNCI",
  "type": "@n8n/n8n-nodes-langchain.googleGemini",
  "typeVersion": 1,
  "position": [
    0,
    -256
  ],
  "credentials": {
    "googlePalmApi": {
      "id": "CyLqP7wsNRAV5EDp",
      "name": "Google Gemini(PaLM) Api account"
    }
  }
}
```

## 4. Practical Use Case (Pattern: Content Automation)

This node is central to the "Article to Social Post" pattern, as seen in the workflow `01. Articolo → Post LinkedIn (powered by Gemini).json`.

**Simplified Flow:**
1.  **Set (Prepare Data):** A `Set` node collects the article text and the history of previous posts.
2.  **Google Gemini (This Node):** Receives the data and a `systemMessage` that assigns it the role of "Copywriter". Its task is to generate the LinkedIn post text.
3.  **Code (Extract Response):** A `Code` node parses the model's response to extract only the post text.
4.  **LinkedIn (Publish):** The clean text is sent to the LinkedIn node for publishing.

**Gemini node input:**
*   `messages.content`: Contains the article text and the post history, passed dynamically from a previous node via `{{ ... }}` expressions.
*   `options.systemMessage`: Contains a very detailed prompt that defines the desired role, tone, style, and output format.

**Gemini node output:**
*   A JSON object containing the model's response, usually in `content.parts[0].text`.

## 5. Best Practices & Tips

*   **Always Start with `gemini-2.5-flash`:** As indicated in the selection matrix, this model offers the best balance for 90% of use cases. Use `gemini-2.5-pro` only if the task complexity explicitly requires it (e.g., image analysis, very complex reasoning).
*   **Leverage the `systemMessage`:** Do not write the entire prompt in the `content` field. Use the `systemMessage` (in `options`) to define the role and general rules. This improves response consistency.
*   **Structure the Input:** Instead of passing a single block of text, use tags like `<ARTICLE>` and `<HISTORY>` to logically separate different parts of the input. This helps the model better understand the context.
*   **Control Costs with `maxOutputTokens`:** Always set a reasonable limit to avoid overly long responses and unexpected costs.
*   **Lower the `temperature` for Data Extraction:** If you are using Gemini to extract structured data (e.g., JSON), set `temperature: 0.2` for more predictable and consistent responses.
*   **Handle the Output with a `Code` Node:** Never pass Gemini's raw output directly to another service. Always use an intermediate `Code` node to clean the response, extract exactly what you need, and handle any errors or unexpected formats.
