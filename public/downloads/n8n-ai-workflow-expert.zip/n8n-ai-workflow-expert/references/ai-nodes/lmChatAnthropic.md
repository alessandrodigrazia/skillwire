# Nodo: Anthropic Claude Chat Model (`@n8n/n8n-nodes-langchain.lmChatAnthropic`)

## 1. Descrizione

Questo nodo consente di integrare i modelli di linguaggio di Anthropic, noti come Claude. Sebbene meno frequente nel dataset analizzato (35 istanze), Claude si ritaglia un ruolo fondamentale per un caso d'uso specifico e di alto valore: l'**elaborazione di documenti a contesto lungo**.

All'interno di questa skill, Claude è la scelta d'elezione quando la lunghezza del testo in input supera i limiti degli altri modelli (tipicamente oltre 100k token), arrivando a gestire fino a 200k token (circa 150.000 parole).

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Model** | Seleziona il modello Claude da utilizzare. | `claude-3-5-sonnet-20241022` (bilanciato), `claude-3-opus-20240229` (massima potenza) |
| **Messages** | L'array di messaggi che costituisce la conversazione. | `{{ $json.prompt }}` |
| **Options** | Contiene i parametri per controllare il comportamento del modello. | |
| `temperature` | Controlla la creatività della risposta. | `0.3` (per analisi fattuali) |
| `maxTokensToSample` | Il numero massimo di token da generare nella risposta. **È obbligatorio per questo nodo.** | `4096` |

## 3. Esempio di Configurazione JSON

```json
{
  "parameters": {
    "model": "claude-3-5-sonnet-20241022",
    "options": {
      "temperature": 0.2,
      "maxTokensToSample": 4096
    }
  },
  "id": "uuid-goes-here",
  "name": "Claude Document Analysis",
  "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "anthropicApi": {
      "id": "credential-id",
      "name": "Anthropic API Account"
    }
  }
}
```

## 4. Caso d'Uso Pratico (Pattern: Document Intelligence)

Il caso d'uso perfetto per Claude è l'analisi di documenti molto lunghi, come un capitolato di gara, un contratto legale o un report di ricerca accademica.

**Flusso Semplificato:**
1.  **OneDrive / SharePoint (Trigger):** Un nuovo file (es. `documento_di_gara.pdf`) viene caricato in una cartella specifica.
2.  **Extract from File:** Il testo completo del PDF viene estratto. Supponiamo che sia di 80.000 parole (circa 110k token).
3.  **Anthropic Claude (Questo Nodo):** Riceve l'intero testo e un prompt che chiede di:
    *   Riassumere i requisiti tecnici chiave.
    *   Identificare le clausole di rischio.
    *   Estrarre le scadenze principali.
    *   Fornire un punteggio di fattibilità da 1 a 10.
4.  **Airtable / SharePoint List:** I dati strutturati estratti da Claude vengono salvati per creare un report di analisi.
5.  **Teams / Outlook:** Una notifica viene inviata al team responsabile con il riassunto e il link al report.

**Input del nodo Claude:**
*   `messages.content`: Contiene l'intero testo del documento (che altri modelli non potrebbero accettare) e il prompt con le istruzioni di analisi.

**Output del nodo Claude:**
*   Una risposta testuale contenente l'analisi richiesta, che può essere poi elaborata da un nodo `outputParserStructured` o da un nodo `Code`.

## 5. Best Practices & Consigli

*   **Quando Sceglierlo:** La risposta è semplice: **quando il contesto è troppo lungo per Gemini o OpenAI**. Se devi analizzare un documento che supera i 100k token, Claude è la scelta obbligata e migliore.
*   **Modello `Sonnet` vs `Opus`:** Inizia con `claude-3-5-sonnet-20241022`. È più veloce, molto più economico e incredibilmente capace. Passa a `claude-3-opus-20240229` solo se la complessità del ragionamento richiesto è estrema e il costo non è il fattore limitante principale.
*   **Parametro `maxTokensToSample`:** A differenza di altri nodi, questo è **obbligatorio**. Assicurati di impostare un valore sufficientemente alto per contenere la risposta che ti aspetti (es. `4096` o `8192`).
*   **Ideale per la Sicurezza:** I modelli Claude sono noti per i loro "guardrail" etici. Se stai costruendo un'applicazione rivolta al pubblico e la sicurezza delle risposte è una priorità assoluta, Claude è una scelta eccellente.
*   **Costo:** Sebbene `Sonnet` sia competitivo, `Opus` è un modello premium con un costo paragonabile a GPT-4. Usalo con parsimonia e solo quando strettamente necessario.
