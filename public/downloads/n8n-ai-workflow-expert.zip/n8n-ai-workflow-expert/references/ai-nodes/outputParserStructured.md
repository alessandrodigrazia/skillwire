# Nodo: Structured Output Parser (`@n8n/n8n-nodes-langchain.outputParserStructured`)

## 1. Descrizione

Questo nodo è un "validatore" e "formattatore". Il suo compito è prendere l'output testuale grezzo di un modello di linguaggio (LLM) e trasformarlo in un **oggetto JSON pulito e strutturato**, secondo uno schema che definisci tu. È un componente essenziale per costruire workflow AI robusti.

Senza di esso, dovresti affidarti a parsing manuali (con il nodo `Code` e `JSON.parse`), che sono fragili e possono fallire se l'LLM aggiunge testo extra come "Ecco il JSON che hai chiesto:". Questo parser, invece, è progettato per ignorare il testo superfluo ed estrarre solo il JSON valido.

## 2. Parametri Chiave

| Parametro |
| :--- | 
| **Zod Schema** | **(Obbligatorio)** Il cuore del nodo. Un array di oggetti che definisce la struttura del JSON desiderato, usando la sintassi Zod. Per ogni campo, specifichi nome, tipo e descrizione. |

**Connessioni:**
*   **LLM:** Va collegato al nodo del modello di linguaggio (es. `lmChatGoogleGemini`) di cui si vuole parsare l'output.
*   **Input:** Va collegato al nodo che fornisce il prompt al modello (es. `chainLlm` o un nodo `Set`).

## 3. Esempio di Configurazione JSON

Questo esempio, ispirato a `0472_Aggregate_Gmail_Create_Triggered.json`, mostra come definire uno schema per estrarre dati da un'email.

```json
{
  "parameters": {
    "zodSchema": {
      "schema": [
        {
          "name": "category",
          "type": "string",
          "description": "Una di: URGENT, INVOICE, SPAM, GENERIC"
        },
        {
          "name": "priority",
          "type": "number",
          "description": "Un numero da 1 a 5 che indica l'urgenza"
        },
        {
          "name": "sender_email",
          "type": "string",
          "description": "L'indirizzo email del mittente"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "JSON Parser",
  "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Estrazione Dati Affidabile)

**Obiettivo:** Estrarre in modo affidabile i dettagli di un contatto da un testo non strutturato.

**Flusso Semplificato:**
1.  **Set (Input):** Un nodo `Set` contiene il testo: "Contatto: Mario Rossi, email: mario.r@example.com, ID cliente: 98765".
2.  **lmChatOpenAi (LLM):** Riceve il testo con il prompt: "Estrai i dati da questo testo e formattali secondo lo schema fornito."
3.  **Structured Output Parser (Questo Nodo):** È collegato all'LLM e ha uno Zod Schema che definisce i campi `nome` (string), `email` (string) e `id_cliente` (number).
4.  **Esecuzione:**
    *   L'LLM potrebbe rispondere con: "Certo, ecco il JSON: {\"nome\": \"Mario Rossi\", \"email\": \"mario.r@example.com\", \"id_cliente\": 98765}".
    *   Il parser ignora "Certo, ecco il JSON:", legge la stringa JSON, la valida rispetto allo schema e restituisce un oggetto JSON pulito: `{ nome: "Mario Rossi", email: "mario.r@example.com", id_cliente: 98765 }`.
5.  **Airtable:** Il nodo Airtable riceve l'oggetto JSON pulito e può mappare i campi `nome`, `email` e `id_cliente` direttamente alle colonne della tabella, senza errori.

## 5. Best Practices & Consigli

*   **Sempre Dopo un LLM per JSON:** Se ti aspetti un output JSON da un modello AI, usa **sempre** questo nodo. È il metodo più robusto e affidabile, superiore al parsing manuale tramite il nodo `Code`.
*   **Descrizioni Chiare nello Schema:** La `description` di ogni campo nello Zod Schema non è solo un commento per te. Viene passata al modello AI per aiutarlo a capire il significato di ogni campo, migliorando notevolmente l'accuratezza dell'estrazione.
*   **Sii Specifico con i Tipi:** Definisci sempre il tipo di dato corretto (`string`, `number`, `boolean`). Se ti aspetti un numero e l'AI restituisce una stringa, il parser può tentare una conversione o segnalare un errore, rendendo il workflow più prevedibile.
*   **Informa l'LLM nel Prompt:** Anche se il parser è potente, aiuta il modello AI dicendogli esplicitamente nel prompt di seguire lo schema. Esempio: `"...Rispondi esclusivamente con un oggetto JSON che aderisca allo schema fornito."`
*   **Usa Modelli con Istruzioni Forti:** Questo nodo funziona meglio con modelli AI che seguono bene le istruzioni, come `gpt-4o` o `gemini-2.5-pro`. Per modelli più piccoli, potrebbe essere necessario un prompt più rigido.
