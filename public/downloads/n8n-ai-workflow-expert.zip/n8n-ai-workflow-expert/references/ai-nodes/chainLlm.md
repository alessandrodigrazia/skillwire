# Nodo: LLM Chain (`@n8n/n8n-nodes-langchain.chainLlm`)

## 1. Descrizione

Il nodo **LLM Chain** è uno dei blocchi costruttivi più basilari e comuni in un workflow AI. Rappresenta una singola, diretta interazione con un modello di linguaggio (LLM). Il suo scopo è "incatenare" (chain) un prompt a un modello per ottenere una risposta.

A differenza di un `AI Agent` che può pianificare e usare strumenti, una `LLM Chain` esegue un singolo compito ben definito. È la scelta ideale per operazioni semplici e non interattive come la classificazione di un testo, una traduzione, una sintesi o la generazione di un contenuto basata su un template.

L'analisi del dataset lo identifica come un nodo molto comune, presente in 257 workflow.

## 2. Parametri Chiave e Connessioni

| Parametro/Connessione | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **LLM** | **(Obbligatoria)** La connessione al modello di linguaggio che eseguirà la richiesta. | `lmChatGoogleGemini`, `lmChatOpenAi` |
| **Prompt** | Il template del prompt da inviare al modello. Può contenere dei placeholder (variabili) tra doppie parentesi graffe. | `"Traduci il seguente testo in italiano: {{testo_inglese}}"` |
| **Prompt Values** | Un oggetto JSON in cui si specificano i valori da sostituire nei placeholder del prompt. | `{"testo_inglese": "{{ $json.text_from_previous_node }}"}` |

## 3. Esempio di Configurazione JSON

Questo esempio, ispirato a `0472_Aggregate_Gmail_Create_Triggered.json`, mostra una catena che classifica un'email.

```json
{
  "parameters": {
    "llm": {
      "__rl": true,
      "value": "OpenAI Chat",
      "mode": "list"
    },
    "prompt": "Classifica il corpo di questa email in una delle seguenti categorie: FATTURA, SPAM, RICHIESTA_INFO.\n\nEmail: {{email_body}}",
    "promptValues": {
      "values": [
        {
          "name": "email_body",
          "value": "={{ $json.body }}"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "Assign labels for message",
  "type": "@n8n/n8n-nodes-langchain.chainLlm",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Classificazione Semplice)

**Obiettivo:** Classificare automaticamente le email in arrivo.

**Flusso Semplificato:**
1.  **Gmail Trigger:** Un nuovo messaggio arriva nella casella di posta.
2.  **LLM Chain (Questo Nodo):**
    *   È collegato a un nodo `lmChatGoogleGemini`.
    *   Il suo parametro **Prompt** è: `"Sei un assistente per l'organizzazione di email. Classifica questa email come URGENTE, NORMALE o SPAM. Rispondi solo con una di queste tre parole. Testo email: {{corpo_email}}" `.
    *   Il suo parametro **Prompt Values** è impostato per passare il corpo dell'email dal trigger al placeholder `corpo_email`.
3.  **Esecuzione:** Il nodo invia il prompt compilato a Gemini e riceve in output una singola parola (es. `"URGENTE"`).
4.  **Switch:** Un nodo `Switch` riceve la classificazione e instrada il workflow su rami diversi: invia una notifica Slack se `URGENTE`, archivia l'email se `SPAM`, ecc.

## 5. Best Practices & Consigli

*   **Usa per Compiti Diretti:** Scegli `LLM Chain` per compiti "uno-a-uno" dove non è richiesto ragionamento complesso o l'uso di strumenti. Se l'AI deve fare più passaggi o interagire con altri sistemi, un `AI Agent` è la scelta migliore.
*   **Sfrutta i Placeholder:** Definisci un prompt generico nel parametro `Prompt` e passa i dati dinamicamente tramite `Prompt Values`. Questo rende i tuoi workflow più puliti e facili da leggere, separando il template dalla logica dei dati.
*   **Separazione tra Logica e Modello:** L'uso di questo nodo promuove una buona architettura. La logica del prompt è contenuta qui, mentre la configurazione del modello (quale modello usare, temperatura, ecc.) è gestita nel nodo LLM collegato (es. `lmChatGoogleGemini`).
*   **Per Output Strutturati:** Sebbene sia possibile chiedere un JSON a una `LLM Chain`, è più robusto usare la combinazione `LLM Model` + `Structured Output Parser`, che valida l'output. Usa la `LLM Chain` principalmente quando ti aspetti una risposta testuale semplice.
