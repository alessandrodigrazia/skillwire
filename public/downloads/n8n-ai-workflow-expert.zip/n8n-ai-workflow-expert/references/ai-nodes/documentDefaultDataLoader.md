# Nodo: Default Document Loader (`@n8n/n8n-nodes-langchain.documentDefaultDataLoader`)

## 1. Descrizione

Il nodo **Default Document Loader** è il punto di ingresso per qualsiasi workflow di tipo **RAG (Retrieval-Augmented Generation)**. Il suo compito è caricare un documento da una fonte (un file, un URL, dati binari) e, cosa più importante, suddividerlo in "chunk" (frammenti) di testo più piccoli e gestibili.

Questa suddivisione è fondamentale perché i modelli AI hanno un limite al numero di parole che possono processare in una sola volta (context window). Suddividere un documento lungo in tanti piccoli pezzi permette di indicizzarli in un database vettoriale e di recuperare solo i frammenti più pertinenti per rispondere a una domanda specifica.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Source** | La fonte del documento. Può essere un file locale, un URL o, più comunemente, i dati binari provenienti da un nodo precedente. | `{{ $binary.data }}` |
| **Splitter** | La strategia usata per dividere il testo. La scelta migliore per la maggior parte dei casi è `Recursive Character Text Splitter`. | `Recursive Character Text Splitter` |
| **Chunk Size** | La dimensione massima di ogni frammento di testo, misurata in caratteri. | `1000` |
| **Chunk Overlap** | Il numero di caratteri che si sovrappongono tra due frammenti consecutivi. Aiuta a non perdere il contesto a cavallo dei tagli. | `200` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra come configurare il nodo per caricare un file PDF ricevuto da un nodo precedente.

```json
{
  "parameters": {
    "source": "={{ $binary.data }}",
    "splitter": "recursiveCharacterTextSplitter",
    "options": {
      "chunkSize": 1000,
      "chunkOverlap": 200
    }
  },
  "id": "uuid-goes-here",
  "name": "Load and Split Document",
  "type": "@n8n/n8n-nodes-langchain.documentDefaultDataLoader",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Preparazione di una Knowledge Base RAG)

**Obiettivo:** Creare una knowledge base interrogabile partendo da un documento PDF.

**Flusso Semplificato:**
1.  **Webhook / Manual Trigger:** L'utente fornisce l'URL di un documento PDF.
2.  **HTTP Request:** Scarica il file PDF dall'URL. L'output di questo nodo sarà un dato binario.
3.  **Default Document Loader (Questo Nodo):**
    *   Riceve i dati binari del PDF nel campo `Source`.
    *   Usa il `Recursive Character Text Splitter` per dividere il testo del PDF in frammenti di 1000 caratteri, con una sovrapposizione di 200 caratteri tra un frammento e l'altro.
4.  **Embeddings Node (es. `embeddingsOpenAi`):** Converte ogni singolo frammento di testo in un vettore numerico (embedding).
5.  **Vector Store Node (es. `vectorStoreQdrant`):** Salva tutti i vettori in un database vettoriale, rendendoli disponibili per future ricerche semantiche.

L'output di questo workflow è una knowledge base pronta. Un secondo workflow potrà poi usarla per permettere a un agente di rispondere a domande specifiche sul contenuto del documento originale.

## 5. Best Practices & Consigli

*   **Primo Passo Obbligatorio per il RAG:** Qualsiasi workflow che debba "parlare" con i tuoi documenti inizia con questo nodo.
*   **L'Importanza del Chunking:** La scelta di `Chunk Size` e `Chunk Overlap` è l'aspetto più critico della configurazione.
    *   **Chunk Size:** Un valore tra `700` e `1500` caratteri è un buon punto di partenza. Deve essere abbastanza grande da contenere un concetto completo, ma non così grande da superare i limiti del modello di embedding.
    *   **Chunk Overlap:** Imposta una sovrapposizione di circa il 15-20% della dimensione del chunk (es. `150`-`200` per una `chunkSize` di 1000). Questo assicura che le frasi o le idee che si trovano a cavallo di due chunk non vengano perse.
*   **Usa lo Splitter Ricorsivo:** Per testi generici (articoli, PDF, etc.), il `Recursive Character Text Splitter` è quasi sempre la scelta migliore. Tenta di dividere il testo in modo intelligente (prima per paragrafi, poi per frasi, poi per parole) prima di ricorrere a un taglio netto, preservando al meglio la semantica del testo.
*   **Un Documento alla Volta:** Questo nodo è ottimizzato per processare un singolo documento alla volta. Se devi indicizzare più documenti, inseriscilo in un ciclo usando il nodo `Split in Batches`.
