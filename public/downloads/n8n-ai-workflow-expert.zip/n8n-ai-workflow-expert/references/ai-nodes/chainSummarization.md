# Node: Summarization Chain (`@n8n/n8n-nodes-langchain.chainSummarization`)

## 1. Description

The **Summarization Chain** node is a specialized tool for a very common task: **summarizing long documents**. While a simple `LLM Chain` can fail if the text exceeds the model's token limit, this node implements advanced strategies to handle texts of any length.

It works by breaking the task into smaller steps, processing portions of the document separately and then combining them into a final summary. It is the robust and scalable solution for summarizing articles, reports, transcripts, or any other extended document.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **LLM** | **(Required)** The connection to the language model that will perform the summarization. | `lmChatGoogleGemini` |
| **Chain Type** | **(Crucial)** The strategy to use for summarizing the document. The two most important are: | `Map Reduce` |
| | `Map Reduce`: First summarizes small "chunks" of the document in parallel (Map phase), then combines these partial summaries into a single final summary (Reduce phase). It is fast and efficient. | |
| | `Refine`: Creates a summary of the first chunk, then iteratively "refines" it by showing the model the current summary and the next chunk, asking it to improve the summary with the new information. It is slower but can produce very detailed summaries. | |
| **Input** | The documents to summarize. The expected input is an array of "Document" objects, typically the output of a `documentDefaultDataLoader`. | `{{ $items }}` |

## 3. JSON Configuration Example

This example shows a typical configuration for summarizing a document using the `Map Reduce` strategy.

```json
{
  "parameters": {
    "llm": {
      "__rl": true,
      "value": "Google Gemini Chat Model",
      "mode": "list"
    },
    "chainType": "map_reduce"
  },
  "id": "uuid-goes-here",
  "name": "Summarize Document",
  "type": "@n8n/n8n-nodes-langchain.chainSummarization",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Summarizing Long Articles)

**Objective:** Generate an executive summary of a long market analysis report.

**Simplified Flow:**
1.  **HTTP Request:** Downloads a 20-page report from a URL.
2.  **Document Loader:** The `documentDefaultDataLoader` node takes the PDF and splits it into, say, 30 text chunks.
3.  **Summarization Chain (This Node):**
    *   Is connected to an `lmChatGoogleGemini` node (ideal for speed and cost).
    *   The **Chain Type** is set to `Map Reduce`.
    *   Receives as **Input** the array of 30 chunks from the Document Loader.
4.  **Execution (Map Reduce):**
    *   **Map Phase:** The node sends all 30 chunks to Gemini, executing 30 calls in parallel. For each chunk, it asks: `"Summarize this text in one sentence."` It gets 30 brief summaries.
    *   **Reduce Phase:** The node takes the 30 partial summaries, merges them into a single text, and makes a final call to Gemini: `"Create a coherent summary based on these key points."`
5.  **Output:** The node's final output is a single, well-structured summary of the entire 20-page document.

## 5. Best Practices & Tips

*   **The Right Choice for Long Documents:** Always use this node instead of an `LLM Chain` when the input text is long or of variable length. It is specifically designed to avoid "context window exceeded" errors.
*   **`Map Reduce` is the Standard:** For 90% of cases, the `Map Reduce` strategy is the best. It is efficient, scalable, and leverages parallelism, making it very fast.
*   **Use `Refine` for Detailed Summaries:** Choose `Refine` only if you need a summary that builds sequentially, capturing the evolution of topics in the document. Keep in mind that it is significantly slower and can be more expensive, since each successive call contains an increasingly larger context.
*   **Input from `Document Loader`:** This node is designed to work in synergy with the output of a `documentDefaultDataLoader`. Make sure the input is an array of documents (chunks), not a single text string.
*   **Watch the Costs:** Even though it is efficient, a summarization chain can involve numerous API calls (especially `Map Reduce`). Use fast and economical models like `gemini-2.5-flash` to keep costs under control.
