# Nodo: Summarization Chain (`@n8n/n8n-nodes-langchain.chainSummarization`)

## 1. Descrizione

Il nodo **Summarization Chain** è uno strumento specializzato per un compito molto comune: **riassumere documenti lunghi**. Mentre una semplice `LLM Chain` può fallire se il testo supera il limite di token del modello, questo nodo implementa strategie avanzate per gestire testi di qualsiasi lunghezza.

Funziona suddividendo il compito in passaggi più piccoli, elaborando porzioni del documento separatamente per poi combinarle in un riassunto finale. È la soluzione robusta e scalabile per la sintesi di articoli, report, trascrizioni o qualsiasi altro documento esteso.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **LLM** | **(Obbligatoria)** La connessione al modello di linguaggio che eseguirà la sintesi. | `lmChatGoogleGemini` |
| **Chain Type** | **(Cruciale)** La strategia da utilizzare per riassumere il documento. Le due più importanti sono: | `Map Reduce` |
| | `Map Reduce`: Prima riassume piccoli "chunk" del documento in parallelo (fase Map), poi combina questi riassunti parziali in un unico riassunto finale (fase Reduce). È veloce ed efficiente. | |
| | `Refine`: Crea un riassunto del primo chunk, poi lo "raffina" iterativamente mostrando al modello il riassunto corrente e il chunk successivo, chiedendogli di migliorare il riassunto con le nuove informazioni. È più lento ma può produrre riassunti molto dettagliati. | |
| **Input** | I documenti da riassumere. L'input atteso è un array di oggetti "Document", tipicamente l'output di un `documentDefaultDataLoader`. | `{{ $items }}` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra una configurazione tipica per riassumere un documento usando la strategia `Map Reduce`.

```json
{
  "parameters": {
    "llm": {
      "__rl": true,
      "value": "Google Gemini Chat Model",
      "mode": "list"
    },
    "chainType": "map_reduce"
  },
  "id": "uuid-goes-here",
  "name": "Summarize Document",
  "type": "@n8n/n8n-nodes-langchain.chainSummarization",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Riassunto di Articoli Lunghi)

**Obiettivo:** Generare un riassunto esecutivo di un lungo report di analisi di mercato.

**Flusso Semplificato:**
1.  **HTTP Request:** Scarica un report di 20 pagine da un URL.
2.  **Document Loader:** Il nodo `documentDefaultDataLoader` prende il PDF e lo divide in, diciamo, 30 chunk di testo.
3.  **Summarization Chain (Questo Nodo):**
    *   È collegato a un nodo `lmChatGoogleGemini` (ideale per velocità e costo).
    *   Il **Chain Type** è impostato su `Map Reduce`.
    *   Riceve in **Input** l'array di 30 chunk dal Document Loader.
4.  **Esecuzione (Map Reduce):**
    *   **Fase Map:** Il nodo invia tutti i 30 chunk a Gemini, eseguendo 30 chiamate in parallelo. Per ogni chunk, chiede: `"Riassumi questo testo in una frase."`. Ottiene 30 brevi riassunti.
    *   **Fase Reduce:** Il nodo prende i 30 riassunti parziali, li unisce in un unico testo e fa una chiamata finale a Gemini: `"Crea un riassunto coerente basandoti su questi punti chiave." `
5.  **Output:** L'output finale del nodo è un singolo riassunto ben strutturato dell'intero documento di 20 pagine.

## 5. Best Practices & Consigli

*   **La Scelta Giusta per Documenti Lunghi:** Usa sempre questo nodo al posto di una `LLM Chain` quando il testo di input è lungo o di lunghezza variabile. È progettato appositamente per evitare errori di "context window exceeded".
*   **`Map Reduce` è lo Standard:** Per il 90% dei casi, la strategia `Map Reduce` è la migliore. È efficiente, scalabile e sfrutta il parallelismo, rendendola molto veloce.
*   **Usa `Refine` per Riassunti Dettagliati:** Scegli `Refine` solo se hai bisogno di un riassunto che si costruisce in modo sequenziale, catturando l'evoluzione degli argomenti nel documento. Tieni presente che è significativamente più lento e può essere più costoso, dato che ogni chiamata successiva contiene un contesto sempre più grande.
*   **Input da `Document Loader`:** Questo nodo è progettato per lavorare in sinergia con l'output di un `documentDefaultDataLoader`. Assicurati che l'input sia un array di documenti (chunk), non una singola stringa di testo.
*   **Attenzione ai Costi:** Anche se efficiente, una catena di riassunto può comportare numerose chiamate API (specialmente `Map Reduce`). Usa modelli veloci ed economici come `gemini-2.5-flash` per mantenere i costi sotto controllo.
