# Nodo: Workflow as Tool (`@n8n/n8n-nodes-langchain.toolWorkflow`)

## 1. Descrizione

Il nodo **Workflow as Tool** è un concetto potente che permette di trasformare un intero workflow n8n in uno "strumento" riutilizzabile che un `AI Agent` può invocare.

In pratica, puoi incapsulare una logica complessa (come cercare dati in un database, inviare un'email formattata o generare un report) in un workflow separato (un "sub-workflow") e poi esporlo all'agente come una singola azione. Questo permette di creare agenti estremamente potenti e modulari, separando la logica di ragionamento (l'agente) dalla logica di esecuzione (i tool).

L'analisi del dataset mostra che questo nodo è usato in 180 workflow, segnalando la sua importanza negli scenari agentici avanzati.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Workflow ID** | **(Obbligatorio)** L'ID del workflow che vuoi eseguire come strumento. | `zUaxnVJ5EMNv0xEr` |
| **Tool Name** | **(Obbligatorio)** Il nome con cui l'agente si riferirà a questo strumento. Deve essere un nome breve e programmatico. | `cerca_dettagli_ordine` |
| **Tool Description** | **(Cruciale)** La descrizione che l'agente leggerà per capire cosa fa lo strumento e quando usarlo. Deve essere molto chiara. | `"Usalo per recuperare i dettagli e lo stato di un ordine specifico, fornendo il suo ID."` |
| **Input Parameters** | Uno schema Zod che definisce i parametri che lo strumento accetta in input. | `[{"name": "order_id", "type": "string", "description": "L'ID univoco dell'ordine da cercare"}]` |

## 3. Esempio di Configurazione JSON

Questo esempio definisce un tool che esegue un altro workflow per cercare ordini.

```json
{
  "parameters": {
    "workflowId": "some-workflow-id",
    "name": "cercaOrdineCliente",
    "description": "Usa questo strumento per ottenere i dettagli di un ordine di un cliente usando l'ID dell'ordine.",
    "schema": {
      "schema": [
        {
          "name": "order_id",
          "type": "string",
          "description": "L'ID dell'ordine da cercare, es. ORD-12345"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "Tool: Cerca Ordine",
  "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Agente con Accesso Controllato ai Dati)

**Obiettivo:** Creare un agente di supporto clienti che possa controllare lo stato di un ordine senza avere accesso diretto al database.

**Workflow 1: L'Agente Principale**
1.  **Telegram Trigger:** L'utente scrive: `"Vorrei sapere lo stato del mio ordine #ABC-123"`.
2.  **Tool: Cerca Ordine (Questo Nodo):** Configurato per eseguire il "Sub-Workflow" e descritto come "Utile per trovare i dettagli di un ordine tramite il suo ID".
3.  **AI Agent:** Riceve il messaggio, riconosce la richiesta e l'ID dell'ordine (`ABC-123`). Decide di usare lo strumento `Cerca Ordine` passandogli `order_id: "ABC-123"`.
4.  L'agente attende la risposta dal tool, la riceve (`"Stato: Spedito"`) e formula una risposta per l'utente.
5.  **Telegram (Send):** Invia la risposta: `"Il tuo ordine ABC-123 risulta spedito." `

**Workflow 2: Il Sub-Workflow (es. ID: `sub-workflow-id`)**
1.  **Execute Workflow Trigger:** Si attiva quando viene chiamato dall'agente. Riceve `order_id` come input.
2.  **Airtable (Search Records):** Cerca nella tabella "Ordini" un record dove il campo `ID` corrisponde all'`order_id` ricevuto.
3.  **Set:** Formatta il risultato in una stringa semplice (es. `"Stato: Spedito, Data: 2025-10-18"`).
4.  **Respond to Webhook:** Restituisce la stringa formattata all'agente che l'ha chiamato.

## 5. Best Practices & Consigli

*   **Pensa in Termini di "Funzioni":** Considera ogni sub-workflow come una funzione riutilizzabile. Questo ti permette di costruire una libreria di "competenze" per i tuoi agenti (es. `inviaEmail`, `cercaContatto`, `creaReportPDF`).
*   **La Descrizione è Tutto:** L'agente è bravo quanto le descrizioni dei suoi strumenti. Sii esplicito su **cosa fa** lo strumento e **quali input richiede**. Una buona descrizione è la chiave per un agente affidabile.
*   **Schema di Input Rigoroso:** Usa sempre lo schema Zod per definire gli input. Funziona come la "firma di una funzione" in programmazione e dice all'agente esattamente quali argomenti passare.
*   **Output Semplice dal Sub-Workflow:** Il sub-workflow dovrebbe restituire un output semplice e conciso (una stringa di testo o un piccolo JSON). L'agente lo userà come contesto per la sua risposta finale, non ha bisogno di dati grezzi complessi.
*   **Sicurezza e Astrazione:** Questo nodo è un pattern di sicurezza eccellente. Permette a un agente di interagire con sistemi interni (database, CRM) in modo controllato, senza mai esporre le credenziali o la logica di accesso diretto al modello AI principale.
