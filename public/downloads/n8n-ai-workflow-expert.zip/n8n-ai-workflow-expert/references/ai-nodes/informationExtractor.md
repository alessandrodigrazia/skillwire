# Nodo: Information Extractor (`@n8n/n8n-nodes-langchain.informationExtractor`)

## 1. Descrizione

Il nodo **Information Extractor** è uno strumento specializzato progettato per un compito specifico: estrarre dati strutturati (in formato JSON) da un blocco di testo non strutturato. Funziona come una combinazione integrata di un modello di linguaggio e un parser di output.

È la scelta ideale quando l'obiettivo primario del tuo workflow è l'estrazione di informazioni precise, come dati da un'email, dettagli da una fattura o specifiche da una richiesta utente. Invece di costruire manualmente una catena con un LLM e un parser, questo nodo offre una soluzione "all-in-one" più semplice e diretta per questo specifico caso d'uso.

## 2. Parametri Chiave e Connessioni

| Parametro/Connessione | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **LLM** | **(Obbligatoria)** La connessione al modello di linguaggio che eseguirà l'estrazione. | `lmChatOpenAi` (consigliato per l'accuratezza) |
| **Zod Schema** | **(Obbligatorio)** Lo schema che definisce la struttura e i tipi di dati del JSON che si desidera estrarre. | `[{"name": "nome_prodotto", "type": "string"}]` |
| **Input** | Il testo non strutturato da cui estrarre le informazioni. | `{{ $json.email_body }}` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra come configurare il nodo per estrarre i dettagli di un lead da un testo.

```json
{
  "parameters": {
    "llm": {
      "__rl": true,
      "value": "OpenAI Chat Model",
      "mode": "list"
    },
    "zodSchema": {
      "schema": [
        {
          "name": "nome_contatto",
          "type": "string",
          "description": "Il nome e cognome del potenziale cliente"
        },
        {
          "name": "azienda",
          "type": "string",
          "description": "Il nome dell'azienda del contatto"
        },
        {
          "name": "email",
          "type": "string",
          "description": "L'indirizzo email del contatto"
        }
      ]
    },
    "text": "Nuovo lead ricevuto: Paolo Verdi per conto di Tech Solutions srl. Contattarlo a paolo.verdi@techsolutions.it."
  },
  "id": "uuid-goes-here",
  "name": "Extract Lead Details",
  "type": "@n8n/n8n-nodes-langchain.informationExtractor",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Lead Routing da Email)

**Obiettivo:** Estrarre automaticamente i dati di un nuovo lead da un'email e creare un record nel CRM.

**Flusso Semplificato:**
1.  **Gmail Trigger:** Si attiva quando arriva una nuova email con oggetto "Nuovo Lead".
2.  **Information Extractor (Questo Nodo):**
    *   È collegato a un nodo `lmChatOpenAi` per massima precisione.
    *   Il suo **Zod Schema** definisce i campi `nome`, `azienda`, `email` e `richiesta`.
    *   Il campo **Input** riceve il corpo dell'email dal trigger.
3.  **Esecuzione:** Il nodo invia il testo e lo schema al modello AI, che estrae le informazioni. L'output del nodo è un singolo oggetto JSON pulito: `{ "nome": "Paolo Verdi", "azienda": "Tech Solutions srl", ... }`.
4.  **HubSpot / Salesforce:** Il nodo del CRM riceve i dati strutturati e li usa per creare un nuovo Contatto e un nuovo Deal, senza bisogno di parsing manuale.

## 5. Best Practices & Consigli

*   **Quando Usarlo:** Scegli questo nodo quando il tuo unico scopo è **estrarre dati**. Se devi anche generare testo creativo, sostenere una conversazione o eseguire logiche complesse, un `AI Agent` o una `LLM Chain` sono più adatti.
*   **Usa un LLM Accurato:** L'estrazione di precisione è un compito difficile. Per risultati affidabili, collega questo nodo a un modello di alta qualità come `gpt-4o` o `gpt-4o-mini`. I modelli più piccoli potrebbero avere difficoltà a seguire lo schema in modo consistente.
*   **Descrizioni Dettagliate nello Schema:** La qualità dell'estrazione dipende quasi interamente dalla qualità del tuo Zod Schema. Usa il campo `description` per ogni campo per spiegare al modello esattamente cosa ti aspetti. Esempio: per un campo `data_fattura`, una buona descrizione è `"La data della fattura, da formattare come YYYY-MM-DD"`.
*   **Gestione dei Campi Mancanti:** Se un'informazione non è presente nel testo, il campo corrispondente nell'output JSON sarà probabilmente `null` o assente. Prevedi questa eventualità nel tuo workflow usando un nodo `IF` per controllare se un campo essenziale è stato estratto prima di procedere.
*   **Alternativa "All-in-One":** Considera questo nodo come un'alternativa più semplice e integrata alla catena `LLM Chain` -> `Structured Output Parser` quando il tuo unico bisogno è l'estrazione.
