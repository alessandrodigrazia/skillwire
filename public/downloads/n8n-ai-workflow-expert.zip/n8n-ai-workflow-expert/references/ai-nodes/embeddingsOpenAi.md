# Nodo: OpenAI Embeddings (`@n8n/n8n-nodes-langchain.embeddingsOpenAi`)

## 1. Descrizione

Il nodo **OpenAI Embeddings** è un componente fondamentale nei workflow di tipo **RAG (Retrieval-Augmented Generation)**. La sua funzione è quella di trasformare frammenti di testo (chunk) in **embeddings**, ovvero rappresentazioni vettoriali numeriche.

In parole semplici, un embedding è un array di numeri (es. `[0.01, -0.045, ..., 0.09]`) che cattura il significato semantico del testo. Questo processo è ciò che permette di effettuare una "ricerca semantica": invece di cercare per parole chiave, si può cercare per concetti e significati. Due pezzi di testo con significato simile avranno vettori di embedding simili nello spazio multidimensionale.

Questo nodo utilizza i modelli di embedding di OpenAI per eseguire questa trasformazione.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Model** | Il modello di embedding di OpenAI da utilizzare. La scelta standard e consigliata è `text-embedding-3-small`. | `text-embedding-3-small` |
| **Input** | Il testo o, più comunemente, l'array di testi (chunk) da convertire in vettori. | `{{ $items }}` dal nodo `Document Loader` |

## 3. Esempio di Configurazione JSON

```json
{
  "parameters": {
    "model": "text-embedding-3-small"
  },
  "id": "uuid-goes-here",
  "name": "OpenAI Embeddings",
  "type": "@n8n/n8n-nodes-langchain.embeddingsOpenAi",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "openAiApi": {
      "id": "credential-id",
      "name": "OpenAI Account"
    }
  }
}
```

## 4. Caso d'Uso Pratico (Pattern: Indicizzazione Documenti per RAG)

Questo nodo è un passaggio intermedio cruciale nel processo di creazione di una knowledge base.

**Flusso Semplificato:**
1.  **Document Loader:** Un nodo `documentDefaultDataLoader` carica un PDF e lo divide in 100 frammenti di testo (chunk).
2.  **OpenAI Embeddings (Questo Nodo):**
    *   Riceve in input l'array di 100 chunk di testo.
    *   Per ogni chunk, contatta l'API di OpenAI e genera un vettore di embedding.
    *   Il suo output è un array di 100 oggetti, dove ogni oggetto contiene sia il testo originale del chunk sia il suo vettore numerico (`embedding`).
3.  **Vector Store (es. `vectorStoreQdrant`):** Riceve l'array di oggetti dal nodo Embeddings e li salva in un database vettoriale. Questo database è ora indicizzato e pronto per la ricerca semantica.

## 5. Best Practices & Consigli

*   **Il Motore della Ricerca Semantica:** Senza questo passaggio, la ricerca basata sul significato è impossibile. Questo nodo è ciò che traduce il linguaggio umano in un formato che un computer può confrontare matematicamente.
*   **Modello Consigliato:** Per quasi tutti i casi d'uso, il modello `text-embedding-3-small` di OpenAI è la scelta ottimale. Offre un eccellente compromesso tra costo, velocità e qualità della ricerca.
*   **Posizionamento nel Workflow:** Questo nodo si trova quasi sempre in questa posizione:
    1.  Dopo un `Document Loader` (o un altro nodo che produce chunk di testo).
    2.  Prima di un nodo `Vector Store` (che ha bisogno dei vettori per l'indicizzazione).
*   **Costi di Indicizzazione:** La creazione di embeddings ha un costo, che dipende dal numero di token nel testo da indicizzare. Tuttavia, questa è tipicamente un'operazione che si esegue una sola volta per ogni documento. Una volta che i vettori sono salvati nel database vettoriale, non è necessario ricalcolarli.
*   **Alternative:** Esistono nodi di embedding anche per altri provider (come Google), ma i modelli di OpenAI sono considerati uno standard di alta qualità nel settore.
