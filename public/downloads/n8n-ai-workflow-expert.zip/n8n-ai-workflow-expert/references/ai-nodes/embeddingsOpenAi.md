# Node: OpenAI Embeddings (`@n8n/n8n-nodes-langchain.embeddingsOpenAi`)

## 1. Description

The **OpenAI Embeddings** node is a fundamental component in **RAG (Retrieval-Augmented Generation)** workflows. Its function is to transform text fragments (chunks) into **embeddings**, which are numerical vector representations.

In simple terms, an embedding is an array of numbers (e.g., `[0.01, -0.045, ..., 0.09]`) that captures the semantic meaning of the text. This process is what enables "semantic search": instead of searching by keywords, you can search by concepts and meanings. Two pieces of text with similar meanings will have similar embedding vectors in multidimensional space.

This node uses OpenAI's embedding models to perform this transformation.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Model** | The OpenAI embedding model to use. The standard and recommended choice is `text-embedding-3-small`. | `text-embedding-3-small` |
| **Input** | The text or, more commonly, the array of texts (chunks) to convert into vectors. | `{{ $items }}` from the `Document Loader` node |

## 3. JSON Configuration Example

```json
{
  "parameters": {
    "model": "text-embedding-3-small"
  },
  "id": "uuid-goes-here",
  "name": "OpenAI Embeddings",
  "type": "@n8n/n8n-nodes-langchain.embeddingsOpenAi",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "openAiApi": {
      "id": "credential-id",
      "name": "OpenAI Account"
    }
  }
}
```

## 4. Practical Use Case (Pattern: Document Indexing for RAG)

This node is a crucial intermediate step in the process of creating a knowledge base.

**Simplified Flow:**
1.  **Document Loader:** A `documentDefaultDataLoader` node loads a PDF and splits it into 100 text fragments (chunks).
2.  **OpenAI Embeddings (This Node):**
    *   Receives as input the array of 100 text chunks.
    *   For each chunk, it contacts the OpenAI API and generates an embedding vector.
    *   Its output is an array of 100 objects, where each object contains both the original chunk text and its numerical vector (`embedding`).
3.  **Vector Store (e.g., `vectorStoreQdrant`):** Receives the array of objects from the Embeddings node and saves them in a vector database. This database is now indexed and ready for semantic search.

## 5. Best Practices & Tips

*   **The Engine of Semantic Search:** Without this step, meaning-based search is impossible. This node is what translates human language into a format that a computer can compare mathematically.
*   **Recommended Model:** For almost all use cases, OpenAI's `text-embedding-3-small` model is the optimal choice. It offers an excellent trade-off between cost, speed, and search quality.
*   **Positioning in the Workflow:** This node is almost always found in this position:
    1.  After a `Document Loader` (or another node that produces text chunks).
    2.  Before a `Vector Store` node (which needs the vectors for indexing).
*   **Indexing Costs:** Creating embeddings has a cost, which depends on the number of tokens in the text to be indexed. However, this is typically a one-time operation for each document. Once the vectors are saved in the vector database, they do not need to be recalculated.
*   **Alternatives:** Embedding nodes exist for other providers (such as Google) as well, but OpenAI's models are considered a high-quality industry standard.
