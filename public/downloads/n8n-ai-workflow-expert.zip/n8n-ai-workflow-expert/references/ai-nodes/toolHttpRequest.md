# Nodo: HTTP Request as Tool (`@n8n/n8n-nodes-langchain.toolHttpRequest`)

## 1. Descrizione

Il nodo **HTTP Request as Tool** è uno degli strumenti più potenti a disposizione di un `AI Agent`. Permette all'agente di interagire con virtualmente **qualsiasi API esterna** disponibile su Internet, eseguendo richieste HTTP (come GET, POST, ecc.).

Questo trasforma l'agente da un sistema chiuso a un'entità in grado di accedere a informazioni in tempo reale (meteo, notizie, dati finanziari) o di eseguire azioni su sistemi di terze parti (creare un task in un project manager, inviare un messaggio, ecc.). L'analisi del dataset, con 142 istanze, ne conferma l'uso in scenari agentici avanzati che richiedono un'interazione con il mondo esterno.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Tool Name** | **(Obbligatorio)** Il nome che l'agente userà per identificare e chiamare questo strumento. | `get_current_weather` |
| **Tool Description** | **(Cruciale)** La descrizione che l'agente legge per capire cosa fa lo strumento, quando usarlo e quali parametri richiede. | `"Usalo per ottenere il meteo attuale di una città. Richiede il parametro 'city'."` |
| **Headers** | Permette di configurare gli header della richiesta HTTP, essenziale per l'autenticazione tramite API key. | `Authorization: Bearer {{ $env.WEATHER_API_KEY }}` |

## 3. Esempio di Configurazione JSON

Questo esempio definisce un tool che permette a un agente di interrogare un'API del meteo.

```json
{
  "parameters": {
    "name": "getWeather",
    "description": "Usa questo strumento per ottenere le condizioni meteo attuali di una specifica città. L'input deve essere il nome della città.",
    "headers": {
      "parameters": [
        {
          "name": "Authorization",
          "value": "Bearer {{ $env.WEATHER_API_KEY }}"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "Tool: Get Weather",
  "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Agente con Accesso a Dati in Tempo Reale)

**Obiettivo:** Creare un agente in grado di rispondere a domande sul meteo attuale.

**Flusso Semplificato:**
1.  **Chat Trigger:** L'utente chiede: `"Che tempo fa a Roma?"`.
2.  **HTTP Request as Tool (Questo Nodo):** È configurato come un tool chiamato `get_weather` che esegue una richiesta GET all'URL `https://api.weather.com/current?city={{$parameters.city}}`.
3.  **AI Agent:**
    *   Riceve la domanda dell'utente.
    *   Analizza la domanda e capisce che l'intento è conoscere il meteo e l'entità è "Roma".
    *   Legge la descrizione del tool `get_weather` e capisce che è lo strumento giusto da usare.
    *   Invoca il tool passando il parametro `city: "Roma"`.
4.  **Esecuzione:** Il nodo esegue la chiamata API, che restituisce un JSON con i dati del meteo (es. `{"temperature": 25, "conditions": "Soleggiato"}`).
5.  **Formulazione Risposta:** L'agente riceve il JSON dall'API, estrae le informazioni rilevanti e formula una risposta in linguaggio naturale: `"A Roma ci sono 25 gradi e il tempo è soleggiato."`.

## 5. Best Practices & Consigli

*   **La Descrizione è la Guida dell'Agente:** La qualità della `Tool Description` è tutto. L'agente si basa al 100% su di essa per decidere se e come usare lo strumento. Sii esplicito su cosa fa, quali parametri accetta e cosa restituisce.
*   **Sicurezza Prima di Tutto:** Non inserire mai chiavi API o altri segreti direttamente nella configurazione. Usa sempre le **variabili d'ambiente** di n8n (es. `{{ $env.MY_API_KEY }}`) per gestire i segreti e referenziarle negli header.
*   **Limita i Permessi:** Quando esponi un'API a un agente, non dargli mai accesso a endpoint distruttivi (come `DELETE /all_data`). Se possibile, crea degli endpoint API specifici per l'agente con permessi di sola lettura o strettamente limitati alle azioni necessarie.
*   **Informa l'Agente sull'Output:** Nella descrizione, può essere utile specificare che tipo di output lo strumento restituisce (es. `"...restituisce un oggetto JSON con i dettagli del prodotto."`). Questo aiuta l'agente a sapere come interpretare il risultato.
*   **Un Tool per Ogni Endpoint:** È una buona pratica creare un nodo `toolHttpRequest` separato per ogni endpoint API che vuoi esporre, ognuno con un nome e una descrizione specifici. Evita di creare un unico tool generico che cerca di fare troppe cose.
