# Node: HTTP Request as Tool (`@n8n/n8n-nodes-langchain.toolHttpRequest`)

## 1. Description

The **HTTP Request as Tool** node is one of the most powerful tools available to an `AI Agent`. It allows the agent to interact with virtually **any external API** available on the Internet by executing HTTP requests (such as GET, POST, etc.).

This transforms the agent from a closed system into an entity capable of accessing real-time information (weather, news, financial data) or performing actions on third-party systems (creating a task in a project manager, sending a message, etc.). The dataset analysis, with 142 instances, confirms its use in advanced agentic scenarios requiring interaction with the outside world.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Tool Name** | **(Required)** The name the agent will use to identify and call this tool. | `get_current_weather` |
| **Tool Description** | **(Crucial)** The description the agent reads to understand what the tool does, when to use it, and what parameters it requires. | `"Use it to get the current weather for a city. Requires the parameter 'city'."` |
| **Headers** | Allows configuring the HTTP request headers, essential for authentication via API key. | `Authorization: Bearer {{ $env.WEATHER_API_KEY }}` |

## 3. JSON Configuration Example

This example defines a tool that allows an agent to query a weather API.

```json
{
  "parameters": {
    "name": "getWeather",
    "description": "Use this tool to get the current weather conditions of a specific city. The input must be the city name.",
    "headers": {
      "parameters": [
        {
          "name": "Authorization",
          "value": "Bearer {{ $env.WEATHER_API_KEY }}"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "Tool: Get Weather",
  "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Agent with Real-Time Data Access)

**Objective:** Create an agent capable of answering questions about current weather.

**Simplified Flow:**
1.  **Chat Trigger:** The user asks: `"What's the weather like in Rome?"`.
2.  **HTTP Request as Tool (This Node):** Is configured as a tool called `get_weather` that executes a GET request to the URL `https://api.weather.com/current?city={{$parameters.city}}`.
3.  **AI Agent:**
    *   Receives the user's question.
    *   Analyzes the question and understands that the intent is to know the weather and the entity is "Rome".
    *   Reads the `get_weather` tool description and understands it is the right tool to use.
    *   Invokes the tool, passing the parameter `city: "Rome"`.
4.  **Execution:** The node executes the API call, which returns a JSON with the weather data (e.g., `{"temperature": 25, "conditions": "Sunny"}`).
5.  **Response Formulation:** The agent receives the JSON from the API, extracts the relevant information, and formulates a natural language response: `"In Rome it's 25 degrees and the weather is sunny."`.

## 5. Best Practices & Tips

*   **The Description is the Agent's Guide:** The quality of the `Tool Description` is everything. The agent relies 100% on it to decide whether and how to use the tool. Be explicit about what it does, what parameters it accepts, and what it returns.
*   **Security First:** Never place API keys or other secrets directly in the configuration. Always use n8n's **environment variables** (e.g., `{{ $env.MY_API_KEY }}`) to manage secrets and reference them in headers.
*   **Limit Permissions:** When exposing an API to an agent, never give it access to destructive endpoints (like `DELETE /all_data`). If possible, create specific API endpoints for the agent with read-only permissions or strictly limited to the necessary actions.
*   **Inform the Agent About the Output:** In the description, it can be useful to specify what type of output the tool returns (e.g., `"...returns a JSON object with the product details."`). This helps the agent know how to interpret the result.
*   **One Tool per Endpoint:** It is good practice to create a separate `toolHttpRequest` node for each API endpoint you want to expose, each with a specific name and description. Avoid creating a single generic tool that tries to do too many things.
