# Nodo: Merge (`n8n-nodes-base.merge`)

## 1. Descrizione

Il nodo **Merge** è un nodo di controllo del flusso fondamentale, utilizzato per **combinare o riunire più flussi di dati** provenienti da rami diversi del workflow in un unico stream di output.

È il complemento naturale di nodi che creano ramificazioni, come `If` e `Switch`. Quando un workflow si divide per seguire logiche diverse, il nodo `Merge` permette di far convergere nuovamente questi percorsi per eseguire una serie di azioni comuni. Può anche essere usato in modalità più avanzate per arricchire i dati, in modo simile a una `JOIN` in SQL.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Mode** | La strategia utilizzata per combinare gli item. | `Append` (default), `Combine` |
| | `Append`: Attende che tutti gli input abbiano terminato e poi accoda i risultati. Se un ramo non produce output, non viene accodato nulla. | |
| | `Combine`: Unisce i dati di item provenienti da input diversi in un unico item, basandosi su una chiave di corrispondenza. | |
| **Number of Inputs** | Il numero di rami di input che il nodo deve attendere prima di procedere. | `2` |
| **Key** (solo in modalità `Combine`) | Il nome del campo da usare per far corrispondere gli item tra i diversi flussi di input. | `customerId` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra un nodo `Merge` in modalità `Append` che attende l'output da due rami diversi.

```json
{
  "parameters": {
    "mode": "append",
    "options": {}
  },
  "id": "uuid-goes-here",
  "name": "Merge Branches",
  "type": "n8n-nodes-base.merge",
  "typeVersion": 3.2,
  "position": [
    123,
    456
  ]
}
```

## 4. Casi d'Uso Pratici

### a) Riunire i Rami di un Nodo `If` (Modalità `Append`)

**Obiettivo:** Eseguire un'azione comune dopo una decisione condizionale.

**Flusso:**
1.  **If:** Controlla se un ordine è `URGENTE`.
2.  **Ramo `true`:** Un nodo `Slack` invia una notifica immediata al canale delle emergenze.
3.  **Ramo `false`:** Un nodo `Gmail` invia un'email di notifica standard.
4.  **Merge (Questo Nodo):** È collegato a entrambi i nodi (`Slack` e `Gmail`). Indipendentemente dal percorso seguito, riceve l'item originale dell'ordine.
5.  **Airtable (Update):** Un nodo Airtable, posto dopo il `Merge`, aggiorna lo stato dell'ordine a `"Notificato"`, eseguendo un'azione comune a entrambi i casi.

### b) Arricchire Dati (Modalità `Combine`)

**Obiettivo:** Combinare i dati di un ordine con i dettagli del cliente da un'altra fonte.

**Flusso:**
1.  **Ramo A - Airtable:** Recupera una lista di ordini, ognuno con `orderId` e `customerId`.
2.  **Ramo B - Google Sheets:** Recupera una lista di clienti, ognuna con `customerId` e `customerName`.
3.  **Merge (Questo Nodo):**
    *   Impostato in modalità `Combine`.
    *   Il `Key` per entrambi gli input è impostato su `customerId`.
4.  **Output:** Il nodo produce un nuovo stream di item, dove ogni item contiene i dati combinati: `orderId`, `customerId` e `customerName`.

## 5. Best Practices & Consigli

*   **Chiudere i Rami:** L'uso più comune e importante del `Merge` è per "chiudere" i percorsi aperti da un `If` o da uno `Switch`. Questo rende i workflow ordinati e previene che terminino inaspettatamente.
*   **`Append` per il Flusso, `Combine` per i Dati:** Ricorda la differenza fondamentale:
    *   Usa `Append` quando vuoi semplicemente che il workflow **continui** dopo una ramificazione.
    *   Usa `Combine` quando vuoi **arricchire** i dati di uno stream con quelli di un altro, come faresti con una `JOIN` in un database.
*   **Imposta Correttamente il `Number of Inputs`:** Assicurati che il numero di input configurato corrisponda esattamente al numero di rami che stai collegando. Se imposti `2` ma colleghi un solo ramo, il workflow si bloccherà, attendendo un input che non arriverà mai.
*   **Alternativa Semplice - `NoOp`:** Se hai solo bisogno di un punto di incontro visivo per i connettori, senza alcuna logica di unione (ad esempio, per far convergere più rami di errore a un'unica notifica), il nodo `NoOp` (No Operation) può essere un'alternativa più semplice. Tuttavia, `Merge` è più esplicito e potente per la gestione dei flussi di dati.
