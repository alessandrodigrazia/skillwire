# Nodo: Code (`n8n-nodes-base.code`)

## 1. Descrizione

Il nodo **Code** è la "via di fuga" definitiva di n8n. Permette di scrivere ed eseguire codice **JavaScript** personalizzato, offrendo una flessibilità illimitata per manipolare dati, implementare logiche complesse o interagire con librerie esterne.

Quando i nodi standard (`Set`, `If`, `Filter`, ecc.) non sono sufficienti per realizzare una trasformazione o una logica specifica, il nodo `Code` è la soluzione. È uno dei nodi più potenti del sistema, come dimostra la sua alta frequenza di utilizzo (quinto nodo più usato con 1005 istanze nel dataset analizzato).

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Mode** | La modalità di esecuzione del codice. | `Run Once for Each Item` |
| | `Run Once for Each Item`: Esegue il codice una volta per ogni item ricevuto in input. L'item corrente è accessibile tramite le variabili `$item` o `$json`. | |
| | `Run Once for All Items`: Esegue il codice una sola volta. Tutti gli item in input sono disponibili come un array nella variabile `$items`. | |
| **JavaScript Code** | L'area di testo dove viene scritto il codice JavaScript. | `const name = $json.firstName.toUpperCase();
return [{ json: { fullName: name } }];` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra un semplice nodo `Code` che formatta un nome in maiuscolo.

```json
{
  "parameters": {
    "jsCode": "// Eseguito per ogni item\nconst firstName = $json.firstName;\nconst lastName = $json.lastName;\n\nconst fullName = `${firstName} ${lastName}`.toUpperCase();\n\n// Ritorna un nuovo oggetto JSON\nreturn [{ json: { fullName: fullName } }];"
  },
  "id": "uuid-goes-here",
  "name": "Format Name",
  "type": "n8n-nodes-base.code",
  "typeVersion": 2,
  "position": [
    123,
    456
  ]
}
```

## 4. Casi d'Uso Pratici

### a) Trasformazione Dati Complessa

**Obiettivo:** Ristrutturare un array di oggetti proveniente da un'API in un formato diverso.

**Flusso:**
1.  **HTTP Request:** Ottiene un array di prodotti, dove ogni prodotto ha una struttura complessa (es. `{"product_data": {"name": "...", "price_details": {"value": 99.9}}}`).
2.  **Code (Questo Nodo):** In modalità `Run Once for All Items`, il codice esegue un ciclo (`for...of`) sull'array `$items`. Per ogni item, estrae solo i campi necessari (`name`, `price`), li rinomina e crea un nuovo array di oggetti puliti. Infine, restituisce il nuovo array.
3.  **Google Sheets:** Il nodo riceve l'array pulito e lo inserisce facilmente in un foglio di calcolo.

### b) Parsing di Testo con Regular Expressions

**Obiettivo:** Estrarre un numero d'ordine con un formato specifico da un blocco di testo.

**Flusso:**
1.  **Gmail:** Riceve il corpo di un'email.
2.  **Code (Questo Nodo):** In modalità `Run Once for Each Item`, il codice usa una Regular Expression (RegEx) per trovare una corrispondenza per il pattern `PO-[0-9]{8}` all'interno del testo dell'email (`$json.body`).
3.  Il codice restituisce un nuovo campo `orderNumber` con il valore estratto.

## 5. Best Practices & Consigli

*   **L'Ultima Risorsa (ma potente):** Usa il nodo `Code` quando hai esaurito le possibilità dei nodi più semplici. Per assegnazioni dirette, usa `Set`. Per condizioni, usa `If`. Per logica complessa, trasformazioni di array o calcoli, il nodo `Code` è perfetto.
*   **Scegli la Modalità Corretta:** La scelta della modalità di esecuzione è fondamentale.
    *   Usa `Run Once for Each Item` per trasformare ogni item indipendentemente dagli altri.
    *   Usa `Run Once for All Items` quando devi aggregare, confrontare, ordinare o filtrare l'intero set di dati in una sola operazione.
*   **La Struttura di Ritorno è Obbligatoria:** Il tuo codice **deve** restituire un array di oggetti, e ogni oggetto deve avere una proprietà `json`. Esempio: `return [{ json: { mio_nuovo_campo: 'valore' } }];`. Se restituisci un array vuoto (`[]`), l'esecuzione per quel ramo del workflow si fermerà, un modo utile per filtrare dati.
*   **Accesso ai Dati:** Ricorda come accedere ai dati:
    *   In modalità "Each Item": `$item` (l'intero item) o `$json` (scorciatoia per `$item.json`).
    *   In modalità "All Items": `$items` (l'array completo di item).
    *   Per accedere ai dati di un nodo precedente specifico (da qualsiasi modalità): `$('Nome del Nodo').all()` o `$('Nome del Nodo').first()`.
*   **Librerie Integrate:** Il nodo `Code` non è un ambiente Node.js completo, ma ha accesso ad alcune utili librerie globali, tra cui `moment.js` per la manipolazione avanzata delle date (anche se `DateTime` di Luxon, disponibile di default nelle espressioni, è spesso sufficiente).
