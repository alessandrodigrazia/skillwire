# Nodo: Set (`n8n-nodes-base.set`)

## 1. Descrizione

Il nodo **Set** è probabilmente il nodo di utilità più importante e più usato in n8n. La sua funzione principale è quella di **creare, modificare o rinominare i campi** (proprietà) all'interno degli item di dati che fluiscono nel workflow.

È il "coltellino svizzero" per la preparazione e la trasformazione dei dati. Lo si usa costantemente per preparare l'input per il nodo successivo, per impostare valori statici o per estrarre e riorganizzare dati provenienti da altre fonti. L'analisi del dataset lo posiziona come il secondo nodo più frequente in assoluto, presente in ben 2530 workflow.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Mode** | La modalità di funzionamento. `Append` (default) aggiunge i nuovi campi ai dati esistenti. `Overwrite` cancella tutti i dati precedenti e li sostituisce solo con i campi definiti nel nodo. | `Append` |
| **Assignments** | La lista delle operazioni da eseguire. Ogni operazione definisce un campo e il valore da assegnargli. | |
| `Name` | Il nome del campo da creare o sovrascrivere. | `nome_cliente` |
| `Value` | Il valore da assegnare al campo. Può essere un valore statico (es. un testo fisso) o un'espressione dinamica (es. `{{ $json.id }}`). | `"Valore Fisso"` o `{{ $json.some_field }}` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra un nodo `Set` che crea tre nuovi campi: uno con un valore statico, uno con un valore dinamico da un nodo precedente, e uno che combina entrambi.

```json
{
  "parameters": {
    "assignments": {
      "assignments": [
        {
          "id": "abc-123",
          "name": "status_processo",
          "type": "string",
          "value": "Iniziato"
        },
        {
          "id": "def-456",
          "name": "id_cliente",
          "type": "string",
          "value": "={{ $(\'Leggi da Airtable\').item.json.customerId }}"
        },
        {
          "id": "ghi-789",
          "name": "messaggio_log",
          "type": "string",
          "value": "Processando l\'ordine {{ $json.orderNumber }} per il cliente {{ $json.customerName }}"
        }
      ]
    },
    "options": {}
  },
  "id": "uuid-goes-here",
  "name": "Prepara Dati per AI",
  "type": "n8n-nodes-base.set",
  "typeVersion": 3.4,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico

**Obiettivo:** Preparare un prompt per un modello AI, combinando testo statico e dati dinamici.

**Flusso Semplificato:**
1.  **Airtable Trigger:** Si attiva quando un nuovo record viene aggiunto a una tabella "Articoli da Riassumere", contenente i campi `titolo` e `testo_articolo`.
2.  **Set (Questo Nodo):** Prepara i dati per il nodo Gemini. Crea un nuovo campo chiamato `prompt_per_ai`.
    *   Il campo `prompt_per_ai` viene impostato con un'espressione che combina istruzioni fisse con i dati del trigger: `"Sei un esperto di social media. Crea un post per LinkedIn che riassuma questo articolo.\n\nTitolo: {{ $json.titolo }}\nTesto: {{ $json.testo_articolo }}"`
3.  **Google Gemini:** Riceve il `prompt_per_ai` come input e genera il post per LinkedIn.

Grazie al nodo `Set`, abbiamo separato la logica di costruzione del prompt dalla logica di chiamata all'AI, rendendo il workflow più pulito e leggibile.

## 5. Best Practices & Consigli

*   **Il Nodo "Colla":** Pensa al nodo `Set` come alla colla che tiene insieme il tuo workflow. Lo usi quasi sempre tra un'app e l'altra per adattare i dati dal formato di output di un nodo al formato di input richiesto dal successivo.
*   **Usa `Append` (quasi sempre):** Nel 99% dei casi, la modalità di default `Append` è quella corretta. Aggiunge i nuovi dati senza cancellare quelli esistenti. Usa `Overwrite` con estrema cautela, solo se vuoi esplicitamente scartare tutti i dati precedenti.
*   **Nomi di Campo Chiari:** Quando crei un nuovo campo, dagli un nome descrittivo (es. `email_cliente_formattata` invece di `email2`). Questo renderà il debug molto più semplice.
*   **`Set` vs. `Code`:** Per assegnazioni di valori semplici, concatenazioni di stringhe o piccole trasformazioni, il nodo `Set` è più veloce, più efficiente e molto più facile da leggere rispetto al nodo `Code`. Usa il nodo `Code` solo quando hai bisogno di logica complessa, come cicli, chiamate a librerie esterne o trasformazioni di dati che richiedono più passaggi.
*   **Mantieni i Nodi `Set` Piccoli:** Invece di un unico, enorme nodo `Set` con 20 assegnazioni, considera di usarne due o tre più piccoli con nomi descrittivi (es. "Prepara Dati Cliente", "Prepara Dati Ordine"). Questo migliora la leggibilità del workflow.
