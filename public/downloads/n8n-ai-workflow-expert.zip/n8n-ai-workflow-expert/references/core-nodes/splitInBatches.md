# Nodo: Split in Batches (`n8n-nodes-base.splitInBatches`)

## 1. Descrizione

Il nodo **Split in Batches** è un nodo di utilità essenziale per processare in modo affidabile grandi quantità di dati. La sua funzione è quella di prendere un grande numero di item in input e suddividerli in "batch" (lotti) più piccoli e gestibili.

Questo nodo crea un **loop**, processando un batch alla volta. È fondamentale per interagire con API che hanno dei rate limit (limiti al numero di richieste), per evitare di esaurire la memoria del sistema o per gestire workflow che devono eseguire operazioni su migliaia di record in modo controllato e sequenziale.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Batch Size** | **(Cruciale)** Il numero di item da includere in ogni batch. Se l'input ha 1000 item e il Batch Size è 100, il nodo creerà 10 loop, ognuno con 100 item. | `100` |
| **Options > Respect previous `runIndex`** | Un'opzione avanzata per la gestione di loop annidati (un loop dentro un altro). Generalmente non è necessario attivarla. | `false` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra un nodo configurato per creare batch di 50 item ciascuno.

```json
{
  "parameters": {
    "batchSize": 50,
    "options": {}
  },
  "id": "uuid-goes-here",
  "name": "Split 1000 items into batches of 50",
  "type": "n8n-nodes-base.splitInBatches",
  "typeVersion": 3,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Elaborazione Massiva Controllata)

**Obiettivo:** Arricchire 1000 contatti presi da un foglio Google Sheets con dati provenienti da un'API esterna che permette solo 100 chiamate al minuto.

**Flusso:**
1.  **Google Sheets (getAll):** Legge 1000 righe dal foglio, producendo 1000 item.
2.  **Split in Batches (Questo Nodo):**
    *   Riceve i 1000 item.
    *   È configurato con `Batch Size: 50`.
    *   Al primo giro, invia i primi 50 item al suo output "Batch".
3.  **HTTP Request:** Esegue 50 chiamate all'API esterna per arricchire i dati dei 50 item del batch.
4.  **Wait:** Dopo aver processato il batch, il workflow attende per 60 secondi per rispettare il rate limit dell'API.
5.  **Loop:** L'output del nodo `Wait` viene ricollegato all'input del nodo `Split in Batches`. Il nodo `Split in Batches` è abbastanza intelligente da capire che il primo loop è finito e invia il batch successivo (item 51-100) al suo output, continuando così fino a esaurire tutti i 1000 item.

## 5. Best Practices & Consigli

*   **Indispensabile per i Grandi Volumi:** Usa sempre questo nodo quando lavori con centinaia o migliaia di item. È l'unico modo per garantire che il tuo workflow non fallisca per limiti di memoria o timeout e per interagire educatamente con le API esterne.
*   **La Magia del Loop:** Per creare il ciclo, devi **ricollegare** l'ultimo nodo della tua logica di elaborazione del batch all'input del nodo `Split in Batches`. Sarà lui a gestire l'iterazione e a inviare il batch successivo.
*   **Usa `Wait` per i Rate Limit:** Se il tuo loop contiene chiamate a API esterne, inserisci **sempre** un nodo `Wait` alla fine del ciclo per evitare di essere bloccato per aver effettuato troppe richieste in poco tempo.
*   **Batch Size = 1 per Elaborazione Seriale:** Un caso d'uso estremamente comune è impostare `Batch Size: 1`. Questo crea un loop che processa gli item uno alla volta, in modo sequenziale. È utile quando le operazioni devono essere eseguite in un ordine preciso o quando vuoi debuggare il processo su un singolo item.
*   **`splitInBatches` vs. `Split Out`:** Non confonderli. `Split Out` è un nodo più vecchio e semplice che prende *un singolo item* contenente un array e lo scompone in più item. `Split in Batches` è più potente: prende *un flusso di più item* e li raggruppa in lotti, gestendo un vero e proprio ciclo di elaborazione. Per i loop, `Split in Batches` è quasi sempre la scelta corretta.
