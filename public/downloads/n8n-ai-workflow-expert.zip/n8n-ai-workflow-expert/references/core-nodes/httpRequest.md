# Nodo: HTTP Request (`n8n-nodes-base.httpRequest`)

## 1. Descrizione

Il nodo **HTTP Request** è uno degli strumenti più potenti e flessibili di n8n. Permette di comunicare con **qualsiasi API o servizio web su Internet** eseguendo richieste HTTP personalizzate (GET, POST, PUT, DELETE, ecc.).

È il nodo da utilizzare ogni volta che si desidera interagire con un servizio che non dispone di un nodo n8n dedicato. Che si tratti di recuperare dati da un'API pubblica, inviare informazioni a un sistema interno o attivare un processo su un'altra piattaforma, questo nodo è lo strumento giusto. La sua enorme popolarità (terzo nodo più usato nel dataset con 2123 istanze) ne dimostra la centralità.

**Differenza con `toolHttpRequest`**: Mentre `toolHttpRequest` è uno strumento che un `AI Agent` può decidere di usare, questo nodo viene usato per eseguire chiamate API predefinite e fisse all'interno della logica di un workflow.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Method** | Il metodo HTTP della richiesta. | `GET` (per leggere dati), `POST` (per creare dati) |
| **URL** | L'URL dell'endpoint API da contattare. Può contenere espressioni dinamiche. | `https://api.example.com/orders/{{ $json.orderId }}` |
| **Authentication** | Il metodo per autenticarsi all'API. `Header Auth` è molto comune per le API key. | `Header Auth` |
| **Headers** | Permette di inviare header HTTP, come `Authorization` per le API key. | `Authorization: Bearer {{ $env.MY_API_KEY }}` |
| **Body Parameters** | Usato con `POST`, `PUT`, `PATCH` per inviare dati nel corpo della richiesta, solitamente in formato JSON. | `{"name": "{{ $json.customerName }}"}` |
| **Query Parameters** | Usato con `GET` per aggiungere parametri all'URL (es. per filtri o paginazione). | `status=active&limit=100` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra una richiesta `POST` per inviare dati JSON a un'API, utilizzando un header per l'autenticazione.

```json
{
  "parameters": {
    "method": "POST",
    "url": "https://api.internalcrm.com/v1/contacts",
    "authentication": "headerAuth",
    "sendBody": true,
    "bodyParameters": {
      "parameters": [
        {
          "name": "name",
          "value": "={{ $json.name }}"
        },
        {
          "name": "email",
          "value": "={{ $json.email }}"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "Create Contact in CRM",
  "type": "n8n-nodes-base.httpRequest",
  "typeVersion": 4.2,
  "position": [
    123,
    456
  ],
  "credentials": {
    "httpHeaderAuth": {
      "id": "credential-id",
      "name": "Internal CRM API Key"
    }
  }
}
```

## 4. Casi d'Uso Pratici

### a) Recuperare Dati da un'API Esterna

**Obiettivo:** Ottenere le ultime notizie di tecnologia da un'API di news.

**Flusso:**
1.  **Schedule Trigger:** Esegue il workflow ogni ora.
2.  **HTTP Request (Questo Nodo):** Esegue una richiesta `GET` all'URL `https://newsapi.org/v2/top-headlines?category=technology`. L'autenticazione avviene tramite un header `X-Api-Key`.
3.  **Split In Batches:** Processa gli articoli restituiti uno alla volta per le fasi successive.

### b) Inviare Dati a un Sistema Esterno

**Obiettivo:** Creare un nuovo utente su una piattaforma esterna quando si iscrive tramite un form.

**Flusso:**
1.  **Webhook:** Riceve i dati da un form di iscrizione (nome, email).
2.  **HTTP Request (Questo Nodo):** Esegue una richiesta `POST` all'endpoint `https://api.externalplatform.com/users`. I dati dell'utente (nome, email) vengono inviati nel `Body` della richiesta.
3.  **Respond to Webhook:** Restituisce un messaggio di successo al form.

## 5. Best Practices & Consigli

*   **Il Coltello Svizzero per le API:** Se un servizio ha un'API ma non un nodo n8n dedicato, questo è lo strumento che devi usare.
*   **Autenticazione Sicura:** **Non inserire mai** chiavi API, token o password direttamente nell'URL, nel corpo o negli header. Usa sempre il sistema di **Credentials** integrato in n8n e, se necessario, le variabili d'ambiente (`{{ $env.SECRET_KEY }}`).
*   **Gestione del JSON:** Quando invii dati (`POST`/`PUT`), imposta il `Body Content Type` su `JSON` e costruisci il corpo usando i `Body Parameters`. n8n gestirà automaticamente la corretta formattazione.
*   **Debug degli Errori:** Se una richiesta fallisce, il primo posto dove guardare è l'output del nodo `HttpRequest`. Fornirà dettagli cruciali come lo **status code** (es. 400, 401, 404) e il **corpo della risposta** del server, che di solito contiene un messaggio di errore esplicito.
*   **Gestione della Paginazione:** Molte API restituiscono dati in "pagine". Invece di creare logiche complesse con loop, usa la funzionalità di **Pagination** integrata nel nodo. n8n può essere configurato per seguire automaticamente i link `next_page` o per incrementare un numero di pagina fino a quando non ci sono più risultati.
