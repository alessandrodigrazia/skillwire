# Node: HTTP Request (`n8n-nodes-base.httpRequest`)

## 1. Description

The **HTTP Request** node is one of the most powerful and flexible tools in n8n. It allows you to communicate with **any API or web service on the Internet** by executing custom HTTP requests (GET, POST, PUT, DELETE, etc.).

This is the node to use whenever you want to interact with a service that does not have a dedicated n8n node. Whether you need to retrieve data from a public API, send information to an internal system, or trigger a process on another platform, this node is the right tool. Its enormous popularity (third most used node in the dataset with 2123 instances) demonstrates its centrality.

**Difference with `toolHttpRequest`**: While `toolHttpRequest` is a tool that an `AI Agent` can decide to use, this node is used to execute predefined and fixed API calls within a workflow's logic.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Method** | The HTTP method of the request. | `GET` (to read data), `POST` (to create data) |
| **URL** | The URL of the API endpoint to contact. Can contain dynamic expressions. | `https://api.example.com/orders/{{ $json.orderId }}` |
| **Authentication** | The method to authenticate with the API. `Header Auth` is very common for API keys. | `Header Auth` |
| **Headers** | Allows sending HTTP headers, such as `Authorization` for API keys. | `Authorization: Bearer {{ $env.MY_API_KEY }}` |
| **Body Parameters** | Used with `POST`, `PUT`, `PATCH` to send data in the request body, usually in JSON format. | `{"name": "{{ $json.customerName }}"}` |
| **Query Parameters** | Used with `GET` to add parameters to the URL (e.g., for filters or pagination). | `status=active&limit=100` |

## 3. JSON Configuration Example

This example shows a `POST` request to send JSON data to an API, using a header for authentication.

```json
{
  "parameters": {
    "method": "POST",
    "url": "https://api.internalcrm.com/v1/contacts",
    "authentication": "headerAuth",
    "sendBody": true,
    "bodyParameters": {
      "parameters": [
        {
          "name": "name",
          "value": "={{ $json.name }}"
        },
        {
          "name": "email",
          "value": "={{ $json.email }}"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "Create Contact in CRM",
  "type": "n8n-nodes-base.httpRequest",
  "typeVersion": 4.2,
  "position": [
    123,
    456
  ],
  "credentials": {
    "httpHeaderAuth": {
      "id": "credential-id",
      "name": "Internal CRM API Key"
    }
  }
}
```

## 4. Practical Use Cases

### a) Retrieving Data from an External API

**Objective:** Get the latest technology news from a news API.

**Flow:**
1.  **Schedule Trigger:** Runs the workflow every hour.
2.  **HTTP Request (This Node):** Executes a `GET` request to the URL `https://newsapi.org/v2/top-headlines?category=technology`. Authentication is done through an `X-Api-Key` header.
3.  **Split In Batches:** Processes the returned articles one at a time for subsequent stages.

### b) Sending Data to an External System

**Objective:** Create a new user on an external platform when they sign up through a form.

**Flow:**
1.  **Webhook:** Receives data from a sign-up form (name, email).
2.  **HTTP Request (This Node):** Executes a `POST` request to the endpoint `https://api.externalplatform.com/users`. The user data (name, email) is sent in the request `Body`.
3.  **Respond to Webhook:** Returns a success message to the form.

## 5. Best Practices & Tips

*   **The Swiss Army Knife for APIs:** If a service has an API but no dedicated n8n node, this is the tool you should use.
*   **Secure Authentication:** **Never place** API keys, tokens, or passwords directly in the URL, body, or headers. Always use the built-in **Credentials** system in n8n and, if necessary, environment variables (`{{ $env.SECRET_KEY }}`).
*   **JSON Handling:** When sending data (`POST`/`PUT`), set the `Body Content Type` to `JSON` and build the body using `Body Parameters`. n8n will automatically handle the correct formatting.
*   **Error Debugging:** If a request fails, the first place to look is the `HttpRequest` node output. It will provide crucial details such as the **status code** (e.g., 400, 401, 404) and the server's **response body**, which usually contains an explicit error message.
*   **Pagination Handling:** Many APIs return data in "pages". Instead of creating complex logic with loops, use the built-in **Pagination** feature in the node. n8n can be configured to automatically follow `next_page` links or to increment a page number until there are no more results.
