# Nodo: If (`n8n-nodes-base.if`)

## 1. Descrizione

Il nodo **If** è uno dei nodi di controllo del flusso più importanti in n8n. Agisce come una dichiarazione `if/else` in programmazione, permettendo al workflow di prendere decisioni e di seguire percorsi diversi in base a condizioni specifiche.

Si valutano uno o più valori provenienti dai nodi precedenti e, a seconda che le condizioni siano vere (`true`) o false (`false`), i dati vengono instradati a uno dei due rami di output. È lo strumento primario per implementare la logica condizionale. La sua alta frequenza nel dataset (1096 istanze) ne sottolinea il ruolo cruciale.

## 2. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Conditions** | L'insieme di regole da valutare. Ogni condizione è composta da tre parti. | |
| `First Value` | Il valore da controllare, tipicamente un'espressione dinamica che legge un dato da un nodo precedente. | `{{ $json.status }}` |
| `Operation` | L'operatore di confronto da applicare. | `Equal`, `Not Equal`, `Contains`, `Larger Than`, `Is Empty` |
| `Second Value` | Il valore con cui confrontare il primo valore. | `"completed"` |
| **Combinator** | Specifica come combinare più condizioni: `All` (logica AND, tutte devono essere vere) o `Any` (logica OR, almeno una deve essere vera). | `All` |

## 3. Esempio di Configurazione JSON

Questo esempio mostra un nodo `If` che controlla se un campo `status` è uguale a `"processed"`.

```json
{
  "parameters": {
    "conditions": {
      "options": {},
      "conditions": [
        {
          "id": "uuid-goes-here",
          "leftValue": "={{ $json.status }}",
          "operator": {
            "type": "string",
            "operation": "equals"
          },
          "rightValue": "processed"
        }
      ],
      "combinator": "and"
    }
  },
  "id": "uuid-goes-here",
  "name": "Check if Processed",
  "type": "n8n-nodes-base.if",
  "typeVersion": 2.2,
  "position": [
    123,
    456
  ]
}
```

## 4. Casi d'Uso Pratici

### a) Routing Basato su Categoria

**Obiettivo:** Indirizzare un'email al dipartimento corretto in base alla sua categoria, determinata da un'AI.

**Flusso:**
1.  **LLM Chain:** Un nodo AI analizza un'email e restituisce un campo `category` (es. `"Vendite"` o `"Supporto"`).
2.  **If (Questo Nodo):** Controlla se il campo `category` è uguale a `"Vendite"`.
3.  **Output:**
    *   **Ramo `true`:** I dati fluiscono ai nodi che creano un nuovo lead nel CRM (es. HubSpot).
    *   **Ramo `false`:** I dati fluiscono ai nodi che creano un nuovo ticket nel sistema di supporto (es. Zendesk).

### b) Controllo Dati Vuoti

**Obiettivo:** Evitare errori controllando se un nodo precedente ha restituito dei risultati.

**Flusso:**
1.  **Airtable (Search):** Cerca un record nel database. Se non lo trova, il suo output sarà vuoto.
2.  **If (Questo Nodo):** Usa l'operazione `Is Not Empty` per controllare l'output del nodo Airtable.
3.  **Output:**
    *   **Ramo `true` (Dati presenti):** I dati fluiscono a un nodo che aggiorna il record esistente.
    *   **Ramo `false` (Dati assenti):** I dati fluiscono a un nodo che crea un nuovo record.

## 5. Best Practices & Consigli

*   **Il Decision-Maker Standard:** Per qualsiasi logica `if/else` binaria, questo è il nodo da usare.
*   **`If` vs. `Switch`:** Usa il nodo `If` per decisioni binarie (vero/falso). Se devi gestire più di due possibili percorsi basati sul valore di un singolo campo (es. `status` può essere `"new"`, `"pending"`, `"done"`, `"error"`), il nodo `Switch` è più pulito e leggibile.
*   **Prevenire Errori con `Is Empty`:** Uno degli usi più importanti del nodo `If` è la difesa dagli errori. Usalo sempre dopo nodi che potrebbero non restituire risultati (come una ricerca in un database o un filtro) per controllare se l'output è vuoto (`Is Empty`) prima di tentare di elaborarlo.
*   **Attenzione ai Tipi di Dati:** n8n cerca di essere flessibile, ma è buona norma essere consapevoli dei tipi di dati che si confrontano (stringa, numero, booleano). La maggior parte delle operazioni di base funziona come previsto, ma per confronti più rigidi, potrebbe essere necessario convertire i tipi di dati in un nodo `Set` precedente.
*   **Rinomina gli Output:** Per migliorare la leggibilità del workflow, puoi rinominare i due rami di output del nodo `If` (es. `true` -> `"Record Trovato"`, `false` -> `"Crea Nuovo Record"`).
