# Guida per Principianti: Il Tuo Primo Workflow in n8n

## 1. Obiettivo del Tutorial

Questa guida ti accompagnerà passo dopo passo nella creazione del tuo primo workflow funzionante in n8n. L'obiettivo è dimostrare i concetti fondamentali della piattaforma costruendo un'automazione semplice ma pratica: un **report meteo giornaliero** inviato via email.

Alla fine di questo tutorial, avrai imparato a:
*   Creare un workflow e aggiungere nodi.
*   Configurare un trigger per avviare un'automazione a un orario prestabilito.
*   Recuperare dati da un'API esterna.
*   Estrarre e formattare le informazioni che ti servono.
*   Inviare un'email automatica.
*   Attivare un workflow per renderlo operativo.

## 2. Il Progetto: Report Meteo Giornaliero

**Cosa costruiremo:** Un workflow che si attiva ogni mattina alle 7:00, contatta un servizio meteo per ottenere le previsioni di una città a tua scelta, formatta le informazioni in un messaggio chiaro e te lo invia via email.

**Stack Utilizzato:**
*   `Schedule Trigger`
*   `HTTP Request`
*   `Set`
*   `Send Email` (o `Gmail` / `Outlook`)

---

## 3. Creazione del Workflow (Step-by-Step)

### **Step 1: Il Trigger - Avvio Automatico**

Ogni workflow ha bisogno di un punto di partenza. Il nostro si avvierà a un orario fisso.

1.  Nel canvas vuoto, clicca su **"Add first step..."**.
2.  Cerca e seleziona il nodo **`Schedule Trigger`**.
3.  Nel pannello di configurazione a destra, imposta:
    *   **Mode:** `Every Day`
    *   **Time:** `07:00`
    *   **Timezone:** Seleziona il tuo fuso orario (es. `Europe/Rome`).
4.  Rinomina il nodo in `"Ogni Giorno alle 7:00"` per chiarezza.

### **Step 2: Recupero dei Dati - Chiamata all'API Meteo**

Ora dobbiamo recuperare le previsioni meteo.

1.  Clicca sul `+` che appare a destra del nodo Schedule.
2.  Cerca e seleziona il nodo **`HTTP Request`**.
3.  Configuralo come segue:
    *   **Method:** `GET`
    *   **URL:** Incolla un URL da un servizio meteo. Un esempio facile e gratuito è OpenWeatherMap. L'URL sarà simile a questo (sostituisci `TUA_API_KEY` e `TUA_CITTA`):
        `https://api.openweathermap.org/data/2.5/weather?q=TUA_CITTA&appid=TUA_API_KEY&units=metric&lang=it`
4.  Rinomina il nodo in `"Get Dati Meteo"`.
5.  Clicca su **"Execute Node"** per testare la chiamata. Dovresti vedere una risposta JSON con molti dati sul meteo.

### **Step 3: Estrazione dei Dati - Il Nodo `Set`**

L'API ci ha dato troppe informazioni. Estraiamo solo quelle che ci servono.

1.  Aggiungi un nodo **`Set`** dopo l'HTTP Request.
2.  Rinominalo in `"Estrai Info Utili"`.
3.  In `Assignments`, crea i seguenti campi (value):
    *   **`citta`**: `{{ $json.name }}`
    *   **`temperatura`**: `{{ Math.round($json.main.temp) }}`
    *   **`descrizione`**: `{{ $json.weather[0].description }}`
    *   **`umidita`**: `{{ $json.main.humidity }}`
4.  Testa il nodo. L'output ora sarà un oggetto JSON pulito con solo questi 4 campi.

### **Step 4: Formattazione dell'Email**

Prepariamo il testo da inviare.

1.  Aggiungi un altro nodo **`Set`**.
2.  Rinominalo in `"Prepara Contenuto Email"`.
3.  Crea due campi:
    *   **`soggetto`**: `Report Meteo per {{ $json.citta }} - {{ DateTime.now().toFormat('dd/MM/yyyy') }}`
    *   **`corpo_html`**: Clicca sull'icona a forma di ingranaggio e apri l'editor di espressioni. Incolla il seguente codice HTML:
        ```html
        <h2>Previsioni per {{ $json.citta }}</h2>
        <p><strong>Temperatura:</strong> {{ $json.temperatura }}°C</p>
        <p><strong>Previsione:</strong> {{ $json.descrizione.charAt(0).toUpperCase() + $json.descrizione.slice(1) }}</p>
        <p><strong>Umidità:</strong> {{ $json.umidita }}%</p>
        ```

### **Step 5: Invio dell'Email**

L'ultimo passo attivo.

1.  Aggiungi un nodo **`Send Email`** (o `Gmail`, `Outlook`, a seconda del tuo provider).
2.  Configuralo:
    *   **To:** Il tuo indirizzo email.
    *   **Subject:** Usa un'espressione per leggere il campo creato prima: `{{ $json.soggetto }}`
    *   **HTML:** Usa un'espressione per leggere il corpo dell'email: `{{ $json.corpo_html }}`
3.  Assicurati di aver configurato le credenziali per l'invio delle email.

### **Step 6: Attivazione del Workflow**

Il workflow è pronto, ma è ancora inattivo. Dobbiamo attivarlo.

1.  Clicca sul pulsante **"Save"** in alto per salvare il tuo lavoro.
2.  In alto a destra, sposta l'interruttore da **"Inactive"** a **"Active"**.

**Fatto!** Da ora in poi, ogni mattina alle 7:00, il workflow si eseguirà automaticamente e riceverai il tuo report meteo personalizzato.

## 4. Concetti Imparati

Completando questo tutorial, hai imparato i concetti fondamentali di n8n:
*   **Trigger e Azioni:** Hai capito la differenza tra un nodo che avvia il workflow e i nodi che compiono azioni.
*   **Flusso di Dati:** Hai visto come i dati (in formato JSON) fluiscono da un nodo all'altro.
*   **Espressioni:** Hai usato le espressioni `{{ ... }}` per accedere dinamicamente ai dati dei nodi precedenti e manipolarli.
*   **Ciclo di Sviluppo:** Hai imparato a costruire, testare e attivare un workflow.
