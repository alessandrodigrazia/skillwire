# Beginner Guide: Your First Workflow in n8n

## 1. Tutorial Objective

This guide will walk you step by step through creating your first working workflow in n8n. The goal is to demonstrate the fundamental concepts of the platform by building a simple yet practical automation: a **daily weather report** sent via email.

By the end of this tutorial, you will have learned to:
*   Create a workflow and add nodes.
*   Configure a trigger to start an automation at a preset time.
*   Retrieve data from an external API.
*   Extract and format the information you need.
*   Send an automatic email.
*   Activate a workflow to make it operational.

## 2. The Project: Daily Weather Report

**What we will build:** A workflow that activates every morning at 7:00, contacts a weather service to get the forecast for a city of your choice, formats the information into a clear message, and sends it to you via email.

**Stack Used:**
*   `Schedule Trigger`
*   `HTTP Request`
*   `Set`
*   `Send Email` (or `Gmail` / `Outlook`)

---

## 3. Creating the Workflow (Step-by-Step)

### **Step 1: The Trigger - Automatic Start**

Every workflow needs a starting point. Ours will start at a fixed time.

1.  On the empty canvas, click **"Add first step..."**.
2.  Search for and select the **`Schedule Trigger`** node.
3.  In the configuration panel on the right, set:
    *   **Mode:** `Every Day`
    *   **Time:** `07:00`
    *   **Timezone:** Select your timezone (e.g., `Europe/Rome`).
4.  Rename the node to `"Every Day at 7:00"` for clarity.

### **Step 2: Data Retrieval - Calling the Weather API**

Now we need to retrieve the weather forecast.

1.  Click on the `+` that appears to the right of the Schedule node.
2.  Search for and select the **`HTTP Request`** node.
3.  Configure it as follows:
    *   **Method:** `GET`
    *   **URL:** Paste a URL from a weather service. An easy and free example is OpenWeatherMap. The URL will be similar to this (replace `YOUR_API_KEY` and `YOUR_CITY`):
        `https://api.openweathermap.org/data/2.5/weather?q=YOUR_CITY&appid=YOUR_API_KEY&units=metric&lang=en`
4.  Rename the node to `"Get Weather Data"`.
5.  Click **"Execute Node"** to test the call. You should see a JSON response with lots of weather data.

### **Step 3: Data Extraction - The `Set` Node**

The API gave us too much information. Let's extract only what we need.

1.  Add a **`Set`** node after the HTTP Request.
2.  Rename it to `"Extract Useful Info"`.
3.  In `Assignments`, create the following fields (value):
    *   **`city`**: `{{ $json.name }}`
    *   **`temperature`**: `{{ Math.round($json.main.temp) }}`
    *   **`description`**: `{{ $json.weather[0].description }}`
    *   **`humidity`**: `{{ $json.main.humidity }}`
4.  Test the node. The output will now be a clean JSON object with only these 4 fields.

### **Step 4: Email Formatting**

Let's prepare the text to send.

1.  Add another **`Set`** node.
2.  Rename it to `"Prepare Email Content"`.
3.  Create two fields:
    *   **`subject`**: `Weather Report for {{ $json.city }} - {{ DateTime.now().toFormat('dd/MM/yyyy') }}`
    *   **`body_html`**: Click the gear icon and open the expression editor. Paste the following HTML code:
        ```html
        <h2>Forecast for {{ $json.city }}</h2>
        <p><strong>Temperature:</strong> {{ $json.temperature }}°C</p>
        <p><strong>Forecast:</strong> {{ $json.description.charAt(0).toUpperCase() + $json.description.slice(1) }}</p>
        <p><strong>Humidity:</strong> {{ $json.humidity }}%</p>
        ```

### **Step 5: Sending the Email**

The last active step.

1.  Add a **`Send Email`** node (or `Gmail`, `Outlook`, depending on your provider).
2.  Configure it:
    *   **To:** Your email address.
    *   **Subject:** Use an expression to read the field created earlier: `{{ $json.subject }}`
    *   **HTML:** Use an expression to read the email body: `{{ $json.body_html }}`
3.  Make sure you have configured the credentials for sending emails.

### **Step 6: Activating the Workflow**

The workflow is ready, but it is still inactive. We need to activate it.

1.  Click the **"Save"** button at the top to save your work.
2.  In the top right, toggle the switch from **"Inactive"** to **"Active"**.

**Done!** From now on, every morning at 7:00, the workflow will run automatically and you will receive your personalized weather report.

## 4. Concepts Learned

By completing this tutorial, you have learned the fundamental concepts of n8n:
*   **Triggers and Actions:** You understood the difference between a node that starts the workflow and nodes that perform actions.
*   **Data Flow:** You saw how data (in JSON format) flows from one node to another.
*   **Expressions:** You used `{{ ... }}` expressions to dynamically access and manipulate data from previous nodes.
*   **Development Cycle:** You learned to build, test, and activate a workflow.
