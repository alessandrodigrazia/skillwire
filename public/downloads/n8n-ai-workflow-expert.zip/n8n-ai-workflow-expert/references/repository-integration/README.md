# Zie619 Repository Integration

Guide for integrating the Zie619/n8n-workflows repository with 2,061 real workflow templates.

## Repository Overview

**Local path**: `~/GitHub/n8n-workflows`

**Statistics**:
- 2,061 workflow JSON files
- 240 service folders
- FastAPI + SQLite FTS backend implemented
- Last sync: December 2025

## Repository Structure

```
n8n-workflows/
├── workflows/
│   ├── Airtable/           # 58 workflows
│   ├── Gmail/              # 89 workflows
│   ├── Google_Sheets/      # 45 workflows
│   ├── OpenAI/             # 187 workflows
│   ├── Slack/              # 67 workflows
│   ├── Telegram/           # 52 workflows
│   ├── ...                 # 234 other folders
│   └── Personal_Examples/  # 6 production workflows
├── api_server.py           # FastAPI backend
├── database.db             # SQLite with FTS
└── requirements.txt
```

## API Endpoints (Local Backend)

### Start Server

```bash
cd ~/GitHub/n8n-workflows
pip install -r requirements.txt
python api_server.py --host 127.0.0.1 --port 8080
```

### Search Workflows

```http
GET http://localhost:8080/api/workflows?q=gmail+airtable&per_page=10
```

**Response:**
```json
{
  "results": [
    {
      "filename": "0472_Gmail_Airtable_Create.json",
      "name": "Gmail to Airtable Automation",
      "description": "...",
      "services": ["Gmail", "Airtable"],
      "ai_powered": true,
      "node_count": 8
    }
  ],
  "total": 17,
  "page": 1
}
```

### Get Workflow Details

```http
GET http://localhost:8080/api/workflows/0472_Gmail_Airtable_Create.json
```

**Response:**
```json
{
  "metadata": { ... },
  "workflow_json": { ... }  # Complete n8n JSON
}
```

### Statistics

```http
GET http://localhost:8080/api/stats
```

## Integration Workflow

```
1. USER REQUEST: "Create email classification workflow"
       │
       ▼
2. SEARCH REPOSITORY
   GET /api/workflows?q=email+classification
       │
       ▼
3. ANALYZE RESULTS
   - Review matching workflows
   - Identify best template
   - Extract patterns
       │
       ▼
4. FETCH TEMPLATE
   GET /api/workflows/{best_match}.json
       │
       ▼
5. ADAPT & CUSTOMIZE
   - Modify for user requirements
   - Update AI model (Gemini default)
   - Configure credentials
       │
       ▼
6. VALIDATE (MCP)
   validate_workflow(adapted_json)
       │
       ▼
7. OUTPUT
```

## Search Strategies

### By Service

```http
# Gmail workflows
GET /api/workflows?q=gmail

# OpenAI + Airtable
GET /api/workflows?q=openai+airtable

# Multiple services
GET /api/workflows?q=slack+notion+ai
```

### By Pattern

```http
# Email automation
GET /api/workflows?q=email+trigger

# AI agent workflows
GET /api/workflows?q=agent+langchain

# Scheduled automation
GET /api/workflows?q=schedule+cron
```

### By Use Case

```http
# Content generation
GET /api/workflows?q=content+generation+linkedin

# Document processing
GET /api/workflows?q=document+analysis+pdf

# Customer support
GET /api/workflows?q=customer+support+chatbot
```

## Common Workflow Categories

| Category | Keywords | Count |
|----------|----------|-------|
| Email Automation | gmail, outlook, email | 150+ |
| AI/LLM | openai, gemini, claude, agent | 545+ |
| Data Sync | airtable, sheets, notion | 200+ |
| Social Media | linkedin, twitter, telegram | 120+ |
| Document Processing | pdf, docs, ocr | 80+ |
| API Integration | webhook, http, rest | 300+ |
| Scheduling | schedule, cron, trigger | 180+ |

## Template Adaptation Guidelines

### 1. Update AI Model

```json
// FROM (template)
"modelName": "gpt-4o-mini"

// TO (recommended)
"modelName": "models/gemini-2.5-flash"
```

### 2. Update Credentials

```json
// Remove hardcoded IDs
"credentials": {
  "googlePalmApi": {
    "id": "YOUR_CREDENTIAL_ID",
    "name": "Google Gemini API"
  }
}
```

### 3. Localize Names

```json
// FROM (English)
"name": "Process Email"

// TO (Italian)
"name": "Elabora Email"
```

### 4. Update Positions

Recalculate positions for visual clarity:
```json
"position": [240, 300]  // Increment x by 220 per node
```

## Comparison: Repository vs Skill Knowledge

| Source | Strength | Use For |
|--------|----------|---------|
| **Zie619 Repository** | Real JSON, tested configurations | Starting templates |
| **Skill Knowledge** | Patterns, best practices | Architecture decisions |
| **n8n-mcp** | Accurate node specs | Parameter validation |

## Best Practices

1. **Always search repository first** when user asks for specific service integration
2. **Combine multiple templates** for complex workflows
3. **Prefer newer workflows** (higher numbers = more recent)
4. **Validate after adaptation** using n8n-mcp
5. **Check AI model** and update to Gemini if cost matters

## Fallback: Direct File Access

If API not running, access files directly:

```python
import glob
import json

path = os.path.expanduser("~/GitHub/n8n-workflows/workflows")
files = glob.glob(f"{path}/**/*.json", recursive=True)

for f in files:
    with open(f, 'r', encoding='utf-8') as file:
        workflow = json.load(file)
        if "gmail" in workflow.get("name", "").lower():
            print(f"Found: {f}")
```

## Notes

- Repository comes from n8n community (Zie619)
- Workflows may use obsolete node versions
- Always validate with MCP before output
- Personal_Examples/ contains production-tested workflows
