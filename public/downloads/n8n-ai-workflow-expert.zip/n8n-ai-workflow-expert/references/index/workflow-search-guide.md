# Workflow Search Guide for Claude

Questa guida spiega come Claude può cercare e accedere agli **esempi reali di workflow** dalla collezione di 2054 JSON files.

## 🎯 Problema & Soluzione

### Problema
- 2054 workflow JSON files (~500MB totali)
- Impossibile caricare tutti in memoria
- Claude ha limiti token per file read

### Soluzione: Index-Based Search
- **workflow-metadata.json** (2.3MB) contiene index searchable di TUTTI i workflow
- Claude cerca nell'index, poi legge solo i file rilevanti
- Accesso intelligente vs brute-force

---

## 📊 Index Structure

### workflow-metadata.json Format

```json
{
  "total_workflows": 2054,
  "categories": {
    "gmail": 334,
    "airtable": 171,
    "aggregate": 368,
    ...
  },
  "workflows": [
    {
      "id": "0472_Aggregate_Gmail_Create_Triggered",
      "name": "Gmail to Airtable Extraction",
      "file_path": "workflows/Aggregate/0472_Aggregate_Gmail_Create_Triggered.json",
      "nodes_count": 8,
      "nodes_types": [
        "n8n-nodes-base.gmailTrigger",
        "@n8n/n8n-nodes-langchain.chainLlm",
        "@n8n/n8n-nodes-langchain.lmChatOpenAi",
        "@n8n/n8n-nodes-langchain.outputParserStructured",
        "n8n-nodes-base.airtable"
      ],
      "ai_nodes": [
        "@n8n/n8n-nodes-langchain.chainLlm",
        "@n8n/n8n-nodes-langchain.lmChatOpenAi"
      ],
      "ai_models": ["gpt-4o-mini"],
      "trigger_types": ["email"],
      "category": "aggregate",
      "has_ai": true,
      "complexity": "medium",
      "key_patterns": [
        "email-to-database",
        "structured-extraction"
      ]
    },
    ...
  ]
}
```

---

## 🔍 Search Strategies for Claude

### Strategy 1: Search by Pattern

**User asks**: "Show me an example of AI agent with multiple tools"

**Claude's approach**:
1. Load `workflow-metadata.json`
2. Filter where `"key_patterns"` includes `"ai-agent"`
3. Filter where `nodes_count` > 5 (implies multiple tools)
4. Sort by `complexity`
5. Pick top 2-3 examples
6. Read those specific JSON files

**Example code** (pseudo):
```javascript
// In Claude's reasoning
const metadata = JSON.parse(await read('workflow-metadata.json'));
const agentWorkflows = metadata.workflows.filter(w =>
  w.key_patterns.includes('ai-agent') &&
  w.nodes_count > 5
);

// Pick best example
const example = agentWorkflows[0];

// Now read actual workflow
const workflow = JSON.parse(await read(example.file_path));
// Analyze and present to user
```

---

### Strategy 2: Search by AI Model

**User asks**: "Show me workflow using Gemini 2.0 Flash"

**Claude's approach**:
1. Load index
2. Filter where `"ai_models"` includes `"gemini-2.0-flash"` or `"models/gemini-2.0-flash"`
3. Group by `key_patterns` to show variety
4. Present 3-5 diverse examples

---

### Strategy 3: Search by Node Combination

**User asks**: "Example of Gmail → AI extraction → Airtable"

**Claude's approach**:
1. Load index
2. Filter where `nodes_types` includes:
   - `"n8n-nodes-base.gmail*"` (Gmail nodes)
   - `"@n8n/n8n-nodes-langchain.*"` (AI nodes)
   - `"n8n-nodes-base.airtable"` (Airtable)
3. Sort by `complexity` (simple first for learning)
4. Read and present example

---

### Strategy 4: Search by Use Case

**User asks**: "How to automate email processing?"

**Claude's approach**:
1. Load index
2. Filter where:
   - `trigger_types` includes `"email"` OR
   - `nodes_types` includes Gmail nodes
3. Check `key_patterns` for relevant patterns
4. Present 3-5 examples with different approaches

---

## 📁 Workflow File Location

### Symbolic Link Setup

```bash
# Create symbolic link (Windows)
cd C:\Users\aless\Documents\N8N\workflows\n8n-ai-workflow-expert
mklink /D workflows C:\Users\aless\Documents\N8N\workflows

# Result: n8n-ai-workflow-expert/workflows → actual workflow folder
```

**Benefit**:
- No duplication (500MB saved)
- Always up-to-date
- Claude can read via relative path: `workflows/Gmail/xxx.json`

---

## 🎯 Claude's Workflow Access Pattern

### Step-by-Step Process

**1. User Request**
```
User: "Show me example of structured data extraction from email"
```

**2. Claude Searches Index**
```javascript
// Claude loads workflow-metadata.json (2.3MB - acceptable)
const metadata = await read('references/index/workflow-metadata.json');

// Search
const matches = metadata.workflows.filter(w =>
  w.key_patterns.includes('structured-extraction') &&
  w.key_patterns.includes('email-to-database')
);

// Found: 17 matches
```

**3. Claude Selects Best Examples**
```javascript
// Pick diverse examples
const examples = [
  matches.find(w => w.ai_models.includes('gpt-4o-mini')),
  matches.find(w => w.ai_models.includes('gemini-2.0-flash')),
  matches.find(w => w.complexity === 'simple')
];
```

**4. Claude Reads Specific Files**
```javascript
// Only read 2-3 files (not all 2054!)
for (const ex of examples.slice(0, 3)) {
  const workflow = await read(ex.file_path);
  // Analyze node configuration
  // Extract relevant patterns
}
```

**5. Claude Presents to User**
```
"I found 17 email extraction workflows. Here are 3 examples:

1. Simple Gmail → Gemini → Airtable (8 nodes)
   File: workflows/Aggregate/0472_Aggregate_Gmail_Create_Triggered.json
   Uses: gemini-2.0-flash-exp (can modernize to 2.5-flash)
   Pattern: Email trigger → LLM extraction → Database storage

2. Advanced with validation (12 nodes)
   File: workflows/Gmail/1324_Aggregate_Gmail_Send_Triggered.json
   Uses: gpt-4o-mini
   Pattern: Includes error handling and confirmation email

[Shows relevant configuration snippets]
```

---

## 📊 Search Filters Available

### By Pattern (key_patterns)
- `"ai-agent"` (381 workflows)
- `"structured-extraction"` (154 workflows)
- `"email-to-database"` (17 workflows)
- `"ai-content-generation"` (15 workflows)
- `"scheduled-automation"` (varies)

### By Complexity
- `"simple"` (< 3 nodes)
- `"medium"` (3-8 nodes)
- `"complex"` (> 8 nodes)

### By AI Model
- `"gpt-4o-mini"` (249 workflows)
- `"gpt-4o"` (95 workflows)
- `"gemini-2.0-flash-exp"` (65 workflows)
- `"gemini-2.0-flash"` (29 workflows)
- + 100+ other models

### By Trigger Type
- `"email"` (Gmail, Outlook)
- `"schedule"` (cron/interval)
- `"webhook"` (HTTP trigger)
- `"manual"` (manual execution)
- `"chat"` (chat interface)

### By Node Type
- Any of 502 unique node types
- Example: `"n8n-nodes-base.gmail"` (334 workflows)
- Example: `"@n8n/n8n-nodes-langchain.agent"` (463 workflows)

---

## 🚀 Performance Optimization

### Token Usage Strategy

**Inefficient Approach** (❌):
```
Load all 2054 JSON files → 50M+ tokens → Impossible
```

**Efficient Approach** (✅):
```
1. Load workflow-metadata.json → 2.3MB → ~500k tokens (acceptable)
2. Search/filter in memory → negligible
3. Read 2-3 specific files → ~50k tokens each
Total: ~650k tokens (within limits)
```

**Savings**: 98%+ token reduction

---

## 🎯 Example Search Queries

### Query 1: "Find LinkedIn automation workflows"
```javascript
const results = metadata.workflows.filter(w =>
  w.nodes_types.some(n => n.toLowerCase().includes('linkedin'))
);
// Returns: workflows using LinkedIn node
```

### Query 2: "Find AI agents using Gemini"
```javascript
const results = metadata.workflows.filter(w =>
  w.key_patterns.includes('ai-agent') &&
  w.ai_models.some(m => m.toLowerCase().includes('gemini'))
);
```

### Query 3: "Find simple email automation"
```javascript
const results = metadata.workflows.filter(w =>
  w.trigger_types.includes('email') &&
  w.complexity === 'simple' &&
  w.has_ai === false  // non-AI automation
);
```

### Query 4: "Find workflows with specific node combo"
```javascript
const results = metadata.workflows.filter(w => {
  const types = w.nodes_types.join(',').toLowerCase();
  return types.includes('gmail') &&
         types.includes('airtable') &&
         types.includes('langchain');
});
```

---

## 📖 Usage for Different Scenarios

### Scenario 1: Learning from Examples
**User**: "I want to build email automation"

**Claude**:
1. Search workflows with `trigger_types: ["email"]`
2. Sort by `complexity: "simple"` first
3. Present 3 beginner-friendly examples
4. Show progression to medium/complex

### Scenario 2: Modernization
**User**: "Upgrade my workflow to use Gemini 2.5"

**Claude**:
1. Search workflows using old Gemini versions
2. Show how to replace model config
3. Reference modern examples using gemini-2.5-flash

### Scenario 3: Pattern Discovery
**User**: "What's the best way to implement structured extraction?"

**Claude**:
1. Filter `key_patterns: ["structured-extraction"]`
2. Group by `ai_models` to compare approaches
3. Show most common pattern (154 examples)
4. Highlight best practices from popular configs

### Scenario 4: Node Configuration
**User**: "How to configure AI agent with tools?"

**Claude**:
1. Filter `ai_nodes` including "agent"
2. Read top 3 examples
3. Extract tool configurations
4. Show variations (2 tools vs 5 tools)

---

## 🔧 Utility Scripts for Search

### Script 1: search-workflows.py

**Usage**:
```bash
python scripts/search-workflows.py --pattern "ai-agent" --model "gemini" --limit 5
```

**Output**:
```json
[
  {
    "id": "0800_Aggregate_Telegram_Automate_Triggered",
    "name": "Telegram AI Bot",
    "file_path": "workflows/Aggregate/0800_Aggregate_Telegram_Automate_Triggered.json",
    "ai_models": ["gemini-2.0-flash-exp"],
    "nodes_count": 12,
    "complexity": "complex"
  },
  ...
]
```

### Script 2: extract-node-config.py

**Usage**:
```bash
python scripts/extract-node-config.py --workflow-id "0472_Aggregate_Gmail_Create_Triggered" --node-type "lmChatOpenAi"
```

**Output**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
  "parameters": {
    "model": "gpt-4o-mini",
    "options": {
      "temperature": 0.3
    }
  }
}
```

---

## 💡 Best Practices for Claude

### 1. Always Start with Index
```javascript
// ✅ Good
const index = await read('references/index/workflow-metadata.json');
const filtered = index.workflows.filter(...);
const workflow = await read(filtered[0].file_path);

// ❌ Bad
for (let i = 0; i < 2054; i++) {
  const wf = await read(`workflows/.../${i}.json`); // Too many reads!
}
```

### 2. Limit File Reads
- Max 3-5 workflow files per query
- Use index to pre-filter
- Only read when showing concrete examples

### 3. Show File Paths
Always tell user where example is from:
```
"This example is from: workflows/Aggregate/0472_Aggregate_Gmail_Create_Triggered.json"
```
→ User can open in N8N if needed

### 4. Offer Variety
When showing examples, vary by:
- AI model used
- Complexity level
- Specific pattern implementation

### 5. Explain Modernization
When showing old examples:
```
"This workflow uses gemini-2.0-flash-exp (older version).
Recommend modernizing to models/gemini-2.5-flash for better performance."
```

---

## 📊 Index Statistics (Quick Reference)

**Total workflows**: 2054
**AI-powered**: 801 (39%)
**Unique node types**: 502

**Top patterns**:
- ai-agent: 381 (47.5% of AI workflows)
- structured-extraction: 154 (19.2%)
- email-to-database: 17
- ai-content-generation: 15

**Top AI models**:
- gpt-4o-mini: 249 (31%)
- gpt-4o: 95 (12%)
- gemini-2.0-flash-exp: 65 (8%)

**Top triggers**:
- email: 334
- webhook: 145
- schedule: varies

---

## 🎯 Claude's Decision Tree

```
User asks for workflow example
    ↓
Does it match a known pattern?
    ├─ Yes → Filter by pattern in index
    └─ No → Filter by node types / trigger
         ↓
Found matches?
    ├─ Yes → How many?
    │    ├─ 1-5: Read all, show all
    │    ├─ 6-20: Read top 3, mention others available
    │    └─ 20+: Read top 3, group others by variation
    └─ No → Suggest similar patterns or manual construction
         ↓
For each selected workflow:
    1. Read JSON file
    2. Extract relevant configuration
    3. Identify modernization opportunities
    4. Present with context
```

---

## 🚀 Expected Performance

### Search Time
- Index load: < 1 second
- Filter: < 100ms (in-memory)
- Read 3 workflows: < 2 seconds
- **Total**: < 5 seconds

### Token Efficiency
- Old approach: 50M+ tokens (impossible)
- New approach: ~650k tokens (feasible)
- **Savings**: 98%+

### Accuracy
- Pattern matching: High (based on analyzed metadata)
- Relevance: High (pre-filtered by use case)
- Variety: High (can show multiple approaches)

---

## 📝 Summary: How This Adds Value

### For Claude:
1. **Instant access** to 2054 real-world examples
2. **Intelligent search** vs brute-force
3. **Token-efficient** (only load what's needed)
4. **Context-aware** (metadata includes patterns, complexity, models)

### For Users:
1. **Concrete examples** for any pattern
2. **Learning from community** best practices
3. **Copy-paste ready** configurations
4. **Modernization guidance** (old → new models)

### For Skill Quality:
1. **Evidence-based** recommendations (not theoretical)
2. **Diverse examples** (not just 1-2 templates)
3. **Up-to-date** (can re-analyze as workflows added)
4. **Comprehensive** coverage (502 node types)

---

**Key Takeaway**: Index-based search transforms 2054 static files into a **searchable, intelligent knowledge base** that Claude can query efficiently to provide relevant, tested examples for any N8N workflow use case.
