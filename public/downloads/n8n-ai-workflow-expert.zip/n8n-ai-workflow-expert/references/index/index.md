# Master Index della Skill: N8N AI Workflow Expert

Questo documento funge da indice principale per tutte le risorse di conoscenza contenute in questa skill. Usalo come punto di partenza per trovare documentazione su nodi, pattern e casi d'uso.

---

## 1. Concetti Fondamentali

*   **[Core Concepts](./core-concepts.md):** Le basi di n8n (nodi, connessioni, dati, espressioni).
*   **[Workflow Patterns](./workflow-patterns.md):** Modelli architetturali comuni (Content Automation, RAG, Batch Processing, etc.).

---

## 2. Documentazione dei Nodi

### Nodi AI (`/references/ai-nodes/`)

*   **Modelli di Linguaggio:**
    *   [Google Gemini](./ai-nodes/lmChatGoogleGemini.md) (Scelta Primaria)
    *   [OpenAI](./ai-nodes/lmChatOpenAi.md) (Scelta Secondaria per accuratezza)
    *   [Anthropic Claude](./ai-nodes/lmChatAnthropic.md) (Per contesti lunghi)
*   **Agenti e Strumenti (Tools):**
    *   [AI Agent](./ai-nodes/agent.md) (Orchestratore intelligente)
    *   [Workflow as Tool](./ai-nodes/toolWorkflow.md) (Invocare un workflow come strumento)
    *   [HTTP Request as Tool](./ai-nodes/toolHttpRequest.md) (Dare all'agente accesso alle API)
*   **Gestione della Conversazione:**
    *   [Chat Trigger](./ai-nodes/chatTrigger.md) (Interfaccia di test)
    *   [Window Buffer Memory](./ai-nodes/memoryBufferWindow.md) (Memoria a breve termine)
*   **Catene (Chains) e Parser:**
    *   [LLM Chain](./ai-nodes/chainLlm.md) (Singola interazione AI)
    *   [Summarization Chain](./ai-nodes/chainSummarization.md) (Per riassumere documenti lunghi)
    *   [Structured Output Parser](./ai-nodes/outputParserStructured.md) (Estrarre JSON dall'output AI)
*   **RAG (Retrieval-Augmented Generation):**
    *   [Default Document Loader](./ai-nodes/documentDefaultDataLoader.md) (Caricare e dividere documenti)
    *   [OpenAI Embeddings](./ai-nodes/embeddingsOpenAi.md) (Creare vettori semantici)
    *   [Information Extractor](./ai-nodes/informationExtractor.md) (Estrarre dati strutturati da testo)

### Nodi Core (`/references/core-nodes/`)

*   [Set](./core-nodes/set.md) (Manipolare dati)
*   [HTTP Request](./core-nodes/httpRequest.md) (Chiamate API manuali)
*   [If](./core-nodes/if.md) (Logica condizionale)
*   [Code](./core-nodes/code.md) (Logica JavaScript personalizzata)
*   [Merge](./core-nodes/merge.md) (Riunire flussi)
*   [Split in Batches](./core-nodes/splitInBatches.md) (Creare loop e gestire grandi volumi)

### Nodi dello Stack Personale (`/references/personal-stack/`)

*   [Gmail](./personal-stack/gmail.md)
*   [Airtable](./personal-stack/airtable.md)
*   [YouTube](./personal-stack/youtube.md)
*   [LinkedIn](./personal-stack/linkedin.md)
*   [RSS Feed Read](./personal-stack/rssFeedRead.md)

### Nodi dello Stack Enterprise (`/references/enterprise-stack/`)

*   [Microsoft Outlook](./enterprise-stack/outlook.md)
*   [Microsoft Teams](./enterprise-stack/teams.md)
*   [Microsoft SharePoint](./enterprise-stack/sharepoint.md)
*   [Microsoft OneDrive](./enterprise-stack/onedrive.md)
*   [Microsoft Excel](./enterprise-stack/excel.md)

---

## 3. Casi d'Uso e Template

### Enterprise (`/references/use-cases/enterprise/`)

*   **Account Planning Strategico:**
    *   Guida: [account-planning-workflow.md](./use-cases/enterprise/account-planning-workflow.md)
    *   Template: `account-planning.json`
*   **Preparazione Incontri:**
    *   Guida: [meeting-preparation.md](./use-cases/enterprise/meeting-preparation.md)
    *   Template: `meeting-preparation.json`
*   **Report Post-Incontro:**
    *   Guida: [meeting-report-automation.md](./use-cases/enterprise/meeting-report-automation.md)
    *   Template: `meeting-report-automation.json`
*   **Analisi Documenti di Gara (RAG):**
    *   Guida: [tender-document-analysis.md](./use-cases/enterprise/tender-document-analysis.md)
    *   Template (Indexing): `tender-indexing.json`
    *   Template (Q&A): `tender-qa.json`
*   **Workbench di Negoziazione:**
    *   Guida: [negotiation-workbench.md](./use-cases/enterprise/negotiation-workbench.md)
    *   Template: `negotiation-workbench.json`
*   **Generazione Business Case:**
    *   Guida: [business-case-generation.md](./use-cases/enterprise/business-case-generation.md)
    *   Template: `business-case-generation.json`
*   **Generazione Presentazioni:**
    *   Guida: [presentation-generation.md](./use-cases/enterprise/presentation-generation.md)
    *   Template: `presentation-generation.json`

### Personal (`/references/use-cases/personal/`)

*   **Articolo a Post LinkedIn:**
    *   Guida: [article-to-linkedin-post.md](./use-cases/personal/article-to-linkedin-post.md)
    *   Template: `01. Articolo → Post LinkedIn (powered by Gemini).json`
*   **Video a Post LinkedIn:**
    *   Guida: [video-to-linkedin-post.md](./use-cases/personal/video-to-linkedin-post.md)
    *   Template: `02. Video → Post LinkedIn (powered by Gemini).json`
*   **RSS a Post LinkedIn:**
    *   Guida: [rss-to-linkedin-post.md](./use-cases/personal/rss-to-linkedin-post.md)
    *   Template: `03. RSS Feed → Post LinkedIn (powered by Gemini).json`

---

## 4. Guide Introduttive e Avanzate

### Guide per Principianti (`/references/beginner/`)

*   **[Il Tuo Primo Workflow](./beginner/first-workflow-tutorial.md):** Una guida passo-passo per creare un report meteo giornaliero.

### Guide Avanzate (`/references/advanced/`)

*   **[Gestione degli Errori](./advanced/error-handling.md):** Come costruire workflow robusti che gestiscono i fallimenti.
*   **[Modalità di Esecuzione](./advanced/execution-modes.md):** Differenze tra modalità `regular` e `queue` per la produzione.
*   **[Sub-workflow e Modularità](./advanced/subworkflows.md):** Come creare workflow riutilizzabili.

---

## 5. Pattern Architetturali

*   **[Pattern Visuali](./visual-patterns.md):** Diagrammi di flusso per i pattern di automazione più comuni (ETL, RAG, Approval, etc.).

---

## 6. Script di Utilità (`/scripts/`)

*   **[search.js](./scripts/search.js):** Fornisce funzioni per cercare all'interno della knowledge base.
*   **[validate.js](./scripts/validate.js):** Fornisce funzioni per una validazione di base dei workflow JSON.
