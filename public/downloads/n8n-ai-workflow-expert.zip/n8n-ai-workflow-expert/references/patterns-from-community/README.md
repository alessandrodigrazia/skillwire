# Pattern Library da Community Workflows

Questa sezione contiene pattern estratti dall'analisi di **2054 workflow reali** della community N8N.

## 📊 Dati Sorgente

- **Totale workflows analizzati**: 2054
- **AI-powered workflows**: 801 (39%)
- **Unique node types**: 502
- **Pattern identificati**: 5 categori principali

---

## 🎯 Pattern per Use Case

### 1. AI Agent Pattern (381 workflows)

**Descrizione**: Workflow che implementano AI agents con tool-calling e multi-step reasoning.

**Modelli più usati**:
- gpt-4o-mini: 185 workflows
- gpt-4o: 71 workflows
- gemini-2.0-flash-exp: 41 workflows

**Node Configuration tipica**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.agent",
  "parameters": {
    "model": "gpt-4o-mini"
  }
}
```

**File di riferimento**: Vedi `ai-agent-patterns.md` per esempi dettagliati

---

### 2. Structured Extraction Pattern (154 workflows)

**Descrizione**: Estrazione dati strutturati da testo, email, documenti.

**Modelli più usati**:
- gpt-4o-mini: 68 workflows
- gpt-4o: 33 workflows
- gemini models: 18+ workflows

**Node Configuration tipica**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.chainLlm",
  "parameters": {}
},
{
  "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
  "parameters": {
    "jsonSchema": "{ \"type\": \"object\", \"properties\": {...} }"
  }
}
```

**File di riferimento**: Vedi `structured-extraction-patterns.md`

---

### 3. Email-to-Database Pattern (17 workflows)

**Descrizione**: Parsing automatico email e storage in database.

**Modelli più usati**:
- gpt-4o: 6 workflows
- gpt-4o-mini: 6 workflows
- llama-3.3-70b-versatile: 3 workflows

**Node Configuration tipica**:
```json
{
  "type": "n8n-nodes-base.gmail"
},
{
  "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
  "parameters": {
    "model": "gpt-4o-mini"
  }
},
{
  "type": "n8n-nodes-base.airtable"
}
```

**File di riferimento**: Vedi `email-to-database-patterns.md`

---

### 4. Content Generation Pattern (15 workflows)

**Descrizione**: Generazione automatica contenuti per social, blog, newsletter.

**Modelli più usati**:
- gpt-4o-mini: 6 workflows
- gpt-4o: 4 workflows
- gemini-2.5-flash: 1 workflow

**Node Configuration tipica**:
```json
{
  "type": "n8n-nodes-base.rssFeedRead"
},
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "models/gemini-2.5-flash"
  }
},
{
  "type": "n8n-nodes-base.linkedin"
}
```

**File di riferimento**: Vedi `content-generation-patterns.md`

---

## 📈 Node Usage Statistics

**Top 20 nodi più usati** (da node-statistics.json):

1. **n8n-nodes-base.set**: 2,553 occorrenze
2. **n8n-nodes-base.httpRequest**: 2,125 occorrenze
3. **n8n-nodes-base.if**: 1,102 occorrenze
4. **n8n-nodes-base.code**: 1,030 occorrenze
5. **@n8n/n8n-nodes-langchain.lmChatOpenAi**: 633 occorrenze
6. **n8n-nodes-base.merge**: 611 occorrenze
7. **@n8n/n8n-nodes-langchain.agent**: 463 occorrenze
8. **n8n-nodes-base.splitInBatches**: 397 occorrenze
9. **n8n-nodes-base.aggregate**: 368 occorrenze
10. **n8n-nodes-base.gmail**: 334 occorrenze

**AI Nodes Breakdown**:
- OpenAI Chat: 633 workflows
- AI Agent: 463 workflows
- Google Gemini Chat: 197 workflows
- LLM Chain: 190 workflows
- Structured Output Parser: 174 workflows

---

## 🔍 Come Usare Questa Library

### 1. Search per Use Case
Consulta i file specifici per pattern:
- `ai-agent-patterns.md` - Per implementare AI agents
- `structured-extraction-patterns.md` - Per parsing dati strutturati
- `email-to-database-patterns.md` - Per automazione email
- `content-generation-patterns.md` - Per generazione contenuti

### 2. Search per Node Type
Usa `references/index/node-statistics.json` per trovare:
- Configurazioni comuni per nodi specifici
- Combinazioni di nodi frequenti
- Best practices dalla community

### 3. Search per AI Model
Usa `references/index/ai-model-usage.json` per trovare:
- Workflow che usano modelli specifici
- Use cases ottimali per ogni modello
- Esempi reali di implementazione

---

## 📦 Index Files Disponibili

Tutti gli index sono in `references/index/`:

1. **workflow-metadata.json** (2.3MB)
   - Index completo di tutti 2054 workflows
   - Metadata: nodes, AI models, complexity, patterns

2. **node-statistics.json** (24KB)
   - Statistiche uso 502 node types
   - Most common configurations

3. **ai-model-usage.json** (9.6KB)
   - Distribuzione 801 AI workflows
   - Use case breakdown per model

4. **pattern-clusters.json** (14KB)
   - Cluster workflows per pattern similarity
   - Esempi rappresentativi per cluster

5. **use-case-examples.json** (2.1KB)
   - Esempi categorizzati per use case
   - Email processing, content automation, document analysis, AI agents

---

## 🎓 Learning Path Consigliato

### Beginner
1. Inizia con `email-to-database-patterns.md`
2. Studia esempi semplici (complexity: simple)
3. Usa gemini-2.5-flash per testing

### Intermediate
1. Esplora `structured-extraction-patterns.md`
2. Studia workflow complexity: medium
3. Sperimenta con chainLlm + outputParserStructured

### Advanced
1. Deep dive in `ai-agent-patterns.md`
2. Analizza workflow complexity: complex
3. Implementa multi-tool agents con memoria

---

## 🔧 Utility Scripts

### Search Workflow by Pattern
```bash
python scripts/search-workflows.py --pattern "ai-agent"
```

### Extract Node Config
```bash
python scripts/extract-node-config.py --node-type "lmChatGoogleGemini"
```

### Generate Template from Example
```bash
python scripts/generate-template.py --workflow-id "0762_Aggregate_Stickynote_Create_Triggered"
```

---

## 📊 Statistics Summary

**Community Insights**:
- 39% dei workflow usa AI (trend crescente)
- gpt-4o-mini è il modello più popolare (31% degli AI workflows)
- AI Agent è il pattern più comune (47% degli AI workflows)
- Set + HTTP Request + IF sono la "triade" più usata

**Migrazione Opportunity**:
- Molti workflow usano ancora gemini-1.5/2.0
- Opportunità di modernizzazione a gemini-2.5
- Potenziale risparmio costi: 50-75%

---

## 🚀 Next Steps

1. **Per Claude**: Usa questi pattern come reference quando crei nuovi workflow
2. **Per Users**: Consulta esempi reali prima di implementare da zero
3. **Per Optimization**: Compara il tuo workflow con best practices community

**Goal**: Accelerare sviluppo workflow sfruttando collective intelligence di 2000+ esempi reali.
