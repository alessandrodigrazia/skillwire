# AI Agent Patterns (381 workflows analyzed)

Patterns extracted from 381 real community workflows that implement AI agents.

## 📊 Overview

- **Workflows analyzed**: 381
- **% of total AI workflows**: 47.5%
- **Average complexity**: Medium-Complex
- **Average node count**: 8-15 nodes

## 🎯 AI Models Used

### Distribution (from ai-model-usage.json):
1. **gpt-4o-mini**: 185 workflows (48.6%)
2. **gpt-4o**: 71 workflows (18.6%)
3. **gemini-2.0-flash-exp**: 41 workflows (10.8%)
4. **gemini-2.0-flash**: 19 workflows (5.0%)
5. **text-embedding-3-small**: 18 workflows (4.7%)
6. **gemini-1.5-flash**: 9 workflows

**Insight**: gpt-4o-mini dominates (almost 50%), but there is growing Gemini adoption.

**Skill recommendation**:
- Default: **gemini-2.5-flash** (more affordable, similar performance)
- Complex agents: **gemini-2.5-pro** or gpt-4o

---

## 🏗️ Common Structures

### Pattern 1: Basic Agent (Single Tool)

**When to use**: Simple task with 1-2 tools

**Node Structure**:
```
Trigger → Agent (with 1 tool) → Response
```

**Typical configuration**:
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.chatTrigger",
      "name": "Chat Trigger"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "name": "AI Agent",
      "parameters": {
        "model": {
          "modelName": "models/gemini-2.5-flash"
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
      "name": "Search Tool",
      "parameters": {
        "workflowId": "={{ $workflow.id }}"
      }
    }
  ]
}
```

**Community example**:
- Workflow ID: `0800_Aggregate_Telegram_Automate_Triggered`
- Use case: Telegram bot with search capability
- Model: gpt-4o-mini → **Modernize with gemini-2.5-flash**

---

### Pattern 2: Multi-Tool Agent

**When to use**: Agent needs to access multiple data sources or APIs

**Node Structure**:
```
Trigger → Agent → Tool 1 (HTTP Request)
                 → Tool 2 (Database Query)
                 → Tool 3 (Custom Workflow)
                 → Memory Buffer
```

**Typical configuration**:
```json
{
  "nodes": [
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "parameters": {
        "model": "gemini-2.5-flash",
        "options": {
          "systemMessage": "You are an assistant that can search for information, query databases, and call external APIs."
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
      "name": "API Search Tool"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
      "name": "Database Query Tool"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolCode",
      "name": "Custom Logic Tool"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
      "parameters": {
        "contextWindowLength": 5
      }
    }
  ]
}
```

**Community examples**:
- `0681_Aggregate_HTTP_Create_Webhook`
- `1404_Aggregate_Telegram_Automation_Triggered`

---

### Pattern 3: Agent with Memory and Context

**When to use**: Multi-turn conversations requiring context awareness

**Node Structure**:
```
Chat Trigger → Agent → Memory Buffer Window → Vector Store (optional)
                    → Tools...
```

**Memory Configuration**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
  "parameters": {
    "contextWindowLength": 10,
    "sessionKey": "={{ $json.userId }}"
  }
}
```

**Vector Store Integration** (18 workflows use embeddings):
```json
{
  "type": "@n8n/n8n-nodes-langchain.vectorStoreInMemory",
  "parameters": {}
},
{
  "type": "@n8n/n8n-nodes-langchain.embeddingsOpenAi",
  "parameters": {
    "model": "text-embedding-3-small"
  }
}
```

**Modernization**: Use Google's `text-embedding-004` (more affordable)

---

### Pattern 4: RAG Agent (Retrieval-Augmented Generation)

**When to use**: Agent needs to answer based on custom knowledge base

**Node Structure**:
```
Document Upload → Text Splitter → Embeddings → Vector Store
                                                     ↓
User Query → Agent → Retriever Tool → Response
```

**Typical configuration**:
```json
{
  "nodes": [
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "name": "RAG Agent"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolVectorStore",
      "name": "Knowledge Base Retriever",
      "parameters": {
        "topK": 5
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.vectorStoreInMemory"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.embeddingsGoogleGemini",
      "parameters": {
        "modelName": "models/text-embedding-004"
      }
    }
  ]
}
```

**Community examples** (22 workflows with embeddings):
- text-embedding-3-small: 18 workflows
- text-embedding-3-large: 6 workflows
- **Recommendation**: Migrate to `models/text-embedding-004` (Google - more affordable)

---

## 🎨 System Message Best Practices (from the community)

### Pattern: Role Definition
```javascript
const systemMessage = `
You are an expert assistant for [specific domain].

Capabilities:
- Tool 1: [description]
- Tool 2: [description]
- Tool 3: [description]

Guidelines:
1. Always use the most appropriate tool
2. If you are unsure, ask for clarification
3. Provide concise and accurate answers
`;
```

### Pattern: Constraint Setting
```javascript
const systemMessage = `
IMPORTANT:
- DO NOT invent unavailable information
- ALWAYS use tools to verify data
- If a tool fails, inform the user
- Keep responses under 200 words
`;
```

---

## 🔧 Tool Configuration Patterns

### Tool 1: HTTP Request Tool

**Usage**: 463 workflows use the agent node, many with HTTP tool

```json
{
  "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
  "parameters": {
    "name": "search_api",
    "description": "Search for information on the web using an external API",
    "method": "GET",
    "url": "={{ $json.query }}",
    "authentication": "genericCredentialType"
  }
}
```

### Tool 2: Workflow Tool

**Usage**: Reuse existing workflows as tools

```json
{
  "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
  "parameters": {
    "name": "database_search",
    "description": "Search records in the corporate database",
    "workflowId": "123",
    "specifyInputSchema": true,
    "jsonSchemaExample": {
      "searchTerm": "string",
      "limit": "number"
    }
  }
}
```

### Tool 3: Code Tool

**Usage**: Custom logic not implementable otherwise

```json
{
  "type": "@n8n/n8n-nodes-langchain.toolCode",
  "parameters": {
    "name": "calculate_metrics",
    "description": "Calculate complex metrics from input data",
    "jsCode": "const result = items[0].json.data.reduce((acc, val) => acc + val, 0); return { result };"
  }
}
```

---

## 📊 Performance Insights

### Model Performance (based on usage patterns):

**gpt-4o-mini** (185 workflows):
- ✅ Pro: Excellent cost/performance balance for agents
- ✅ Pro: Excellent tool-calling accuracy
- ❌ Con: More expensive than Gemini 2.5 Flash

**gemini-2.0-flash-exp** (41 workflows):
- ✅ Pro: Fast, affordable
- ⚠️ Warning: Experimental version (deprecated)
- 🔄 **Action**: Migrate to gemini-2.5-flash

**Recommendation Matrix**:

| Use Case | Model | Reasoning |
|----------|-------|-----------|
| Basic agent (1-2 tools) | gemini-2.5-flash | Cost-effective, fast |
| Multi-tool agent (3-5 tools) | gemini-2.5-flash | Sufficient capability |
| Complex reasoning agent | gemini-2.5-pro | Better reasoning |
| High-stakes agent | gpt-4o | Max reliability |

---

## 🚨 Community Anti-Patterns

### ❌ Anti-Pattern 1: Agent without System Message
**Problem**: 30% of workflows do not define a clear system message
**Fix**: Always define role and capabilities

### ❌ Anti-Pattern 2: Too Many Tools
**Problem**: Some workflows have 7-10 tools → confusion
**Fix**: Max 3-5 tools, group similar tools in sub-workflows

### ❌ Anti-Pattern 3: No Error Handling
**Problem**: Agent crashes if a tool fails
**Fix**: Implement try/catch in custom tools

### ❌ Anti-Pattern 4: Deprecated Models
**Problem**: Usage of gpt-3.5-turbo, gemini-1.5-flash-001
**Fix**: Migrate to gemini-2.5-flash/pro

---

## 🎯 Recommended Templates

### Template 1: Customer Support Agent
```json
{
  "name": "Customer Support Agent (Gemini 2.5 Flash)",
  "nodes": [
    {
      "type": "n8n-nodes-base.chatTrigger"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "parameters": {
        "model": "gemini-2.5-flash",
        "options": {
          "systemMessage": "You are a customer support assistant. Use tools to search for orders, tracking, and FAQs."
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
      "name": "Search Orders",
      "parameters": {
        "description": "Search customer orders by ID or email"
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
      "name": "Track Shipment",
      "parameters": {
        "description": "Get shipment tracking status"
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
      "parameters": {
        "contextWindowLength": 5
      }
    }
  ]
}
```

### Template 2: Data Analysis Agent
```json
{
  "name": "Data Analysis Agent (Gemini 2.5 Pro)",
  "nodes": [
    {
      "type": "n8n-nodes-base.webhook"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "parameters": {
        "model": "gemini-2.5-pro",
        "options": {
          "systemMessage": "Analyze data and generate insights. Use the SQL tool to query the database."
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolCode",
      "name": "SQL Query Tool",
      "parameters": {
        "description": "Execute SQL queries on the database"
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolCode",
      "name": "Chart Generator",
      "parameters": {
        "description": "Generate charts from data"
      }
    }
  ]
}
```

---

## 📈 Trend Analysis

### AI Agents Growth:
- 2023: ~150 workflows
- 2024: ~230 workflows
- Trend: +50% year-over-year

### Model Shift:
- 2023: 90% OpenAI
- 2024: 75% OpenAI, 25% Gemini/others
- Trend: Diversification towards Gemini

### Tool Complexity:
- Average tools/agent: 2.3
- Range: 1-8 tools
- Sweet spot: 2-4 tools

---

## 🔍 Search by Example

### Find Similar Agents:
1. Open `references/index/workflow-metadata.json`
2. Search for workflows with `"key_patterns": ["ai-agent"]`
3. Filter by desired `ai_models`
4. Analyze `nodes_types` for pattern match

### Example Query (pseudo-code):
```javascript
const agents = workflows.filter(w =>
  w.key_patterns.includes('ai-agent') &&
  w.ai_models.includes('gpt-4o-mini') &&
  w.complexity === 'medium'
);
```

---

## 📚 Additional Resources

- **node-statistics.json**: Common configurations for the `agent` node
- **ai-model-usage.json**: Detailed breakdown of 381 workflows
- **pattern-clusters.json**: Agent similarity clusters

---

## 🎓 Learning Path

### Beginner
1. Study Template 1 (Customer Support)
2. Implement with 1-2 simple tools
3. Use gemini-2.5-flash

### Intermediate
1. Add memory (memoryBufferWindow)
2. Integrate 3-4 different tools
3. Implement error handling

### Advanced
1. RAG agent with vector store
2. Multi-step reasoning
3. Complex custom tools
4. A/B test gemini-2.5-pro vs gpt-4o

---

## ✅ Best Practices Checklist

- [ ] Clear and specific system message
- [ ] 2-4 tools (not too many)
- [ ] Memory if multi-turn conversation
- [ ] Error handling for tool failures
- [ ] Appropriate model (gemini-2.5-flash default)
- [ ] Detailed tool descriptions
- [ ] Test with edge-case queries
- [ ] Cost and performance monitoring

---

**Key insight**: AI agents are the most popular pattern (47.5% of AI workflows). The community prefers gpt-4o-mini, but there is enormous savings opportunity by migrating to gemini-2.5-flash (50% cost, similar performance).
