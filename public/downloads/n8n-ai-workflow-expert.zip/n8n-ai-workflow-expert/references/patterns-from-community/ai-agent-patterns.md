# AI Agent Patterns (381 workflows analizzati)

Pattern estratti da 381 workflow reali della community che implementano AI agents.

## 📊 Overview

- **Workflows analizzati**: 381
- **% sul totale AI workflows**: 47.5%
- **Complessità media**: Medium-Complex
- **Node count medio**: 8-15 nodes

## 🎯 Modelli AI Usati

### Distribuzione (da ai-model-usage.json):
1. **gpt-4o-mini**: 185 workflows (48.6%)
2. **gpt-4o**: 71 workflows (18.6%)
3. **gemini-2.0-flash-exp**: 41 workflows (10.8%)
4. **gemini-2.0-flash**: 19 workflows (5.0%)
5. **text-embedding-3-small**: 18 workflows (4.7%)
6. **gemini-1.5-flash**: 9 workflows

**Insight**: gpt-4o-mini domina (quasi 50%), ma c'è crescente adozione Gemini.

**Raccomandazione skill**:
- Default: **gemini-2.5-flash** (più economico, performance simile)
- Complex agents: **gemini-2.5-pro** o gpt-4o

---

## 🏗️ Strutture Comuni

### Pattern 1: Basic Agent (Single Tool)

**Quando usare**: Task semplice con 1-2 tools

**Node Structure**:
```
Trigger → Agent (with 1 tool) → Response
```

**Configurazione tipica**:
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.chatTrigger",
      "name": "Chat Trigger"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "name": "AI Agent",
      "parameters": {
        "model": {
          "modelName": "models/gemini-2.5-flash"
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
      "name": "Search Tool",
      "parameters": {
        "workflowId": "={{ $workflow.id }}"
      }
    }
  ]
}
```

**Esempio dalla community**:
- Workflow ID: `0800_Aggregate_Telegram_Automate_Triggered`
- Use case: Telegram bot con search capability
- Model: gpt-4o-mini → **Modernizza con gemini-2.5-flash**

---

### Pattern 2: Multi-Tool Agent

**Quando usare**: Agent deve accedere a multiple fonti dati o API

**Node Structure**:
```
Trigger → Agent → Tool 1 (HTTP Request)
                 → Tool 2 (Database Query)
                 → Tool 3 (Custom Workflow)
                 → Memory Buffer
```

**Configurazione tipica**:
```json
{
  "nodes": [
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "parameters": {
        "model": "gemini-2.5-flash",
        "options": {
          "systemMessage": "Sei un assistente che può cercare info, queryare database, e chiamare API esterne."
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
      "name": "API Search Tool"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
      "name": "Database Query Tool"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolCode",
      "name": "Custom Logic Tool"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
      "parameters": {
        "contextWindowLength": 5
      }
    }
  ]
}
```

**Esempi dalla community**:
- `0681_Aggregate_HTTP_Create_Webhook`
- `1404_Aggregate_Telegram_Automation_Triggered`

---

### Pattern 3: Agent con Memory e Context

**Quando usare**: Conversazioni multi-turn che richiedono context awareness

**Node Structure**:
```
Chat Trigger → Agent → Memory Buffer Window → Vector Store (optional)
                    → Tools...
```

**Configurazione Memory**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
  "parameters": {
    "contextWindowLength": 10,
    "sessionKey": "={{ $json.userId }}"
  }
}
```

**Vector Store Integration** (18 workflows usano embeddings):
```json
{
  "type": "@n8n/n8n-nodes-langchain.vectorStoreInMemory",
  "parameters": {}
},
{
  "type": "@n8n/n8n-nodes-langchain.embeddingsOpenAi",
  "parameters": {
    "model": "text-embedding-3-small"
  }
}
```

**Modernizzazione**: Usa `text-embedding-004` di Google (più economico)

---

### Pattern 4: RAG Agent (Retrieval-Augmented Generation)

**Quando usare**: Agent deve rispondere basandosi su knowledge base custom

**Node Structure**:
```
Document Upload → Text Splitter → Embeddings → Vector Store
                                                     ↓
User Query → Agent → Retriever Tool → Response
```

**Configurazione tipica**:
```json
{
  "nodes": [
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "name": "RAG Agent"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolVectorStore",
      "name": "Knowledge Base Retriever",
      "parameters": {
        "topK": 5
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.vectorStoreInMemory"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.embeddingsGoogleGemini",
      "parameters": {
        "modelName": "models/text-embedding-004"
      }
    }
  ]
}
```

**Esempi dalla community** (22 workflows con embeddings):
- text-embedding-3-small: 18 workflows
- text-embedding-3-large: 6 workflows
- **Recommendation**: Migra a `models/text-embedding-004` (Google - più economico)

---

## 🎨 System Message Best Practices (dalla community)

### Pattern: Role Definition
```javascript
const systemMessage = `
Sei un esperto assistente per [dominio specifico].

Capacità:
- Tool 1: [descrizione]
- Tool 2: [descrizione]
- Tool 3: [descrizione]

Linee guida:
1. Usa sempre lo strumento più appropriato
2. Se non sei sicuro, chiedi chiarimenti
3. Fornisci risposte concise e accurate
`;
```

### Pattern: Constraint Setting
```javascript
const systemMessage = `
IMPORTANTE:
- NON inventare informazioni non disponibili
- Usa SEMPRE i tool per verificare dati
- Se un tool fallisce, informa l'utente
- Mantieni le risposte sotto 200 parole
`;
```

---

## 🔧 Tool Configuration Patterns

### Tool 1: HTTP Request Tool

**Uso**: 463 workflows usano agent node, molti con HTTP tool

```json
{
  "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
  "parameters": {
    "name": "search_api",
    "description": "Cerca informazioni su web usando API esterna",
    "method": "GET",
    "url": "={{ $json.query }}",
    "authentication": "genericCredentialType"
  }
}
```

### Tool 2: Workflow Tool

**Uso**: Riusa workflow esistenti come tools

```json
{
  "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
  "parameters": {
    "name": "database_search",
    "description": "Cerca record nel database aziendale",
    "workflowId": "123",
    "specifyInputSchema": true,
    "jsonSchemaExample": {
      "searchTerm": "string",
      "limit": "number"
    }
  }
}
```

### Tool 3: Code Tool

**Uso**: Custom logic non implementabile altrimenti

```json
{
  "type": "@n8n/n8n-nodes-langchain.toolCode",
  "parameters": {
    "name": "calculate_metrics",
    "description": "Calcola metriche complesse da dati input",
    "jsCode": "const result = items[0].json.data.reduce((acc, val) => acc + val, 0); return { result };"
  }
}
```

---

## 📊 Performance Insights

### Model Performance (basato su usage patterns):

**gpt-4o-mini** (185 workflows):
- ✅ Pro: Ottimo balance costo/performance per agenti
- ✅ Pro: Eccellente tool-calling accuracy
- ❌ Contro: Più costoso di Gemini 2.5 Flash

**gemini-2.0-flash-exp** (41 workflows):
- ✅ Pro: Veloce, economico
- ⚠️ Warning: Versione experimental (deprecata)
- 🔄 **Action**: Migra a gemini-2.5-flash

**Recommendation Matrix**:

| Use Case | Model | Reasoning |
|----------|-------|-----------|
| Basic agent (1-2 tools) | gemini-2.5-flash | Cost-effective, fast |
| Multi-tool agent (3-5 tools) | gemini-2.5-flash | Sufficient capability |
| Complex reasoning agent | gemini-2.5-pro | Better reasoning |
| High-stakes agent | gpt-4o | Max reliability |

---

## 🚨 Anti-Patterns dalla Community

### ❌ Anti-Pattern 1: Agent senza System Message
**Problema**: 30% dei workflow non definisce system message chiaro
**Fix**: Sempre definire role e capabilities

### ❌ Anti-Pattern 2: Troppi Tools
**Problema**: Alcuni workflow hanno 7-10 tools → confusion
**Fix**: Max 3-5 tools, gruppo tool simili in sub-workflows

### ❌ Anti-Pattern 3: No Error Handling
**Problema**: Agent crashes se tool fallisce
**Fix**: Implementa try/catch in custom tools

### ❌ Anti-Pattern 4: Models Deprecati
**Problema**: Uso di gpt-3.5-turbo, gemini-1.5-flash-001
**Fix**: Migra a gemini-2.5-flash/pro

---

## 🎯 Templates Raccomandati

### Template 1: Customer Support Agent
```json
{
  "name": "Customer Support Agent (Gemini 2.5 Flash)",
  "nodes": [
    {
      "type": "n8n-nodes-base.chatTrigger"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "parameters": {
        "model": "gemini-2.5-flash",
        "options": {
          "systemMessage": "Sei un assistente customer support. Usa i tool per cercare ordini, tracking, FAQ."
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
      "name": "Search Orders",
      "parameters": {
        "description": "Cerca ordini cliente per ID o email"
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolHttpRequest",
      "name": "Track Shipment",
      "parameters": {
        "description": "Ottieni status tracking spedizione"
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
      "parameters": {
        "contextWindowLength": 5
      }
    }
  ]
}
```

### Template 2: Data Analysis Agent
```json
{
  "name": "Data Analysis Agent (Gemini 2.5 Pro)",
  "nodes": [
    {
      "type": "n8n-nodes-base.webhook"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.agent",
      "parameters": {
        "model": "gemini-2.5-pro",
        "options": {
          "systemMessage": "Analizza dati e genera insights. Usa SQL tool per query database."
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolCode",
      "name": "SQL Query Tool",
      "parameters": {
        "description": "Esegui query SQL su database"
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.toolCode",
      "name": "Chart Generator",
      "parameters": {
        "description": "Genera chart da dati"
      }
    }
  ]
}
```

---

## 📈 Trend Analysis

### Crescita AI Agents:
- 2023: ~150 workflows
- 2024: ~230 workflows
- Trend: +50% year-over-year

### Model Shift:
- 2023: 90% OpenAI
- 2024: 75% OpenAI, 25% Gemini/others
- Trend: Diversificazione verso Gemini

### Tool Complexity:
- Media tools/agent: 2.3
- Range: 1-8 tools
- Sweet spot: 2-4 tools

---

## 🔍 Search by Example

### Find Similar Agents:
1. Apri `references/index/workflow-metadata.json`
2. Cerca workflows con `"key_patterns": ["ai-agent"]`
3. Filtra per `ai_models` desiderato
4. Analizza `nodes_types` per pattern match

### Example Query (pseudo-code):
```javascript
const agents = workflows.filter(w =>
  w.key_patterns.includes('ai-agent') &&
  w.ai_models.includes('gpt-4o-mini') &&
  w.complexity === 'medium'
);
```

---

## 📚 Risorse Aggiuntive

- **node-statistics.json**: Configurazioni comuni per nodo `agent`
- **ai-model-usage.json**: Breakdown dettagliato 381 workflows
- **pattern-clusters.json**: Cluster similarity agents

---

## 🎓 Learning Path

### Beginner
1. Studia Template 1 (Customer Support)
2. Implementa con 1-2 tools semplici
3. Usa gemini-2.5-flash

### Intermediate
1. Aggiungi memory (memoryBufferWindow)
2. Integra 3-4 tools diversi
3. Implementa error handling

### Advanced
1. RAG agent con vector store
2. Multi-step reasoning
3. Custom tools complessi
4. A/B test gemini-2.5-pro vs gpt-4o

---

## ✅ Checklist Best Practices

- [ ] System message chiaro e specifico
- [ ] 2-4 tools (non troppi)
- [ ] Memory se conversazione multi-turn
- [ ] Error handling per tool failures
- [ ] Model appropriato (gemini-2.5-flash default)
- [ ] Tool descriptions dettagliate
- [ ] Test con query edge-case
- [ ] Monitoring costi e performance

---

**Insight chiave**: Gli AI agents sono il pattern più popolare (47.5% degli AI workflows). La community preferisce gpt-4o-mini, ma c'è enorme opportunità di risparmio migrando a gemini-2.5-flash (50% costo, performance simile).
