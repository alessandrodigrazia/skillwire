# Nodo: Microsoft Teams (`n8n-nodes-base.microsoftTeams`)

## 1. Descrizione

Il nodo **Microsoft Teams** è il connettore che permette a n8n di integrarsi con la piattaforma di collaborazione di Microsoft. La sua funzione principale è quella di **inviare messaggi e notifiche** a canali o chat specifiche.

È lo strumento ideale per tenere aggiornati i team su eventi importanti che accadono nei tuoi workflow, come la chiusura di un'opportunità di vendita, un errore di sistema, un nuovo lead ad alta priorità o la disponibilità di un nuovo report. Funge da centro di notifica per le tue automazioni aziendali.

## 2. Operazioni Principali

*   **Message - Post:** L'operazione più comune. Invia un messaggio di testo a un canale o a una chat utente.
*   **Channel - Get All:** Recupera un elenco di tutti i canali disponibili all'interno di un Team, utile per selezionare dinamicamente dove inviare un messaggio.
*   **Channel - Get:** Recupera i dettagli di un singolo canale.

## 3. Parametri Chiave (per l'operazione `Message: Post`)

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Team** | Il Team di Microsoft Teams in cui si trova il canale di destinazione. | `Sales Department` |
| **Channel** | Il canale specifico all'interno del Team in cui verrà pubblicato il messaggio. | `General` o `Q4-Deals` |
| **Content** | Il testo del messaggio da inviare. Supporta la formattazione Markdown. | `"**Nuovo Lead!**\nContatto: {{ $json.leadName }}"` |
| **Mentions** | Permette di menzionare (`@`) utenti specifici, un canale o un tag per attirare l'attenzione. | `@channel` |

## 4. Esempio di Configurazione JSON

Questo esempio mostra come inviare un messaggio di notifica a un canale specifico.

```json
{
  "parameters": {
    "team": "team-id-here",
    "channel": "channel-id-here",
    "content": "**Opportunità Vinta!** 🥳\n\nComplimenti a **{{ $json.salesRep }}** per aver chiuso il deal *{{ $json.dealName }}* per un valore di €{{ $json.amount }}"
  },
  "id": "uuid-goes-here",
  "name": "Notify Sales Team",
  "type": "n8n-nodes-base.microsoftTeams",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftTeamsOAuth2Api": {
      "id": "credential-id",
      "name": "My Corporate Teams Account"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Notifica di Vendita)

**Obiettivo:** Celebrare la vittoria di un'importante opportunità di vendita con il team commerciale.

**Flusso:**
1.  **CRM Trigger (es. Salesforce):** Il workflow si avvia quando un'opportunità viene aggiornata allo stato `"Chiuso Vinto"` e il suo valore supera i 20.000€.
2.  **Set:** Un nodo `Set` prepara un messaggio formattato, includendo il nome del venditore, il nome dell'opportunità e il suo valore economico.
3.  **Microsoft Teams (Post) (Questo Nodo):**
    *   Seleziona il Team `"Reparto Vendite"` e il canale `"Vittorie"`.
    *   Pubblica il messaggio preparato, magari menzionando l'intero canale (`@channel`) per assicurarsi che tutti ricevano la notifica.

Questo crea un ciclo di feedback positivo e aumenta la visibilità sui successi del team in tempo reale.

## 6. Best Practices & Consigli

*   **Centro Notifiche Aziendale:** Usa Teams come destinazione primaria per tutte le notifiche interne che richiedono visibilità e collaborazione (es. nuovi lead qualificati, errori critici in un sistema, report settimanali pronti per la revisione).
*   **Formattazione con Markdown:** Per rendere i messaggi più chiari e leggibili, sfrutta la sintassi Markdown supportata da Teams: `**testo in grassetto**`, `*testo in corsivo*`, `[Testo del Link](URL)` e liste puntate.
*   **Usa le Menzioni per Notifiche Mirate:** Se un alert è rilevante solo per una persona o un sottogruppo, usa la funzione di menzione (`@nome.cognome`) per inviare una notifica diretta solo a loro, riducendo il rumore per il resto del team.
*   **Messaggi Complessi con Adaptive Cards:** Per messaggi interattivi che includono pulsanti, campi di input o layout complessi, Teams utilizza le "Adaptive Cards". Sebbene il nodo base abbia un supporto limitato, la tecnica avanzata consiste nel costruire il JSON della Adaptive Card (usando il loro [designer online](https://adaptivecards.io/designer/)) e inviarlo tramite un nodo `HTTP Request` all'API di Microsoft Graph. Questo sblocca un potenziale di interattività enorme.
*   **Avviare Workflow da Teams:** Mentre questo nodo serve per *inviare messaggi a* Teams, puoi anche *avviare un workflow da* Teams. La tecnica standard è configurare un "Incoming Webhook" in un canale di Teams. Questo webhook ti fornisce un URL a cui puoi inviare messaggi. Configurando un workflow n8n con un trigger `Webhook`, puoi catturare questi messaggi e avviare automazioni basate su comandi o eventi che accadono in Teams.
