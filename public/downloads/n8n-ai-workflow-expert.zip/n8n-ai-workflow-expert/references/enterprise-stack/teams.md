# Node: Microsoft Teams (`n8n-nodes-base.microsoftTeams`)

## 1. Description

The **Microsoft Teams** node is the connector that allows n8n to integrate with Microsoft's collaboration platform. Its main function is to **send messages and notifications** to specific channels or chats.

It is the ideal tool for keeping teams updated on important events happening in your workflows, such as the closing of a sales opportunity, a system error, a new high-priority lead, or the availability of a new report. It serves as a notification center for your business automations.

## 2. Main Operations

*   **Message - Post:** The most common operation. Sends a text message to a channel or a user chat.
*   **Channel - Get All:** Retrieves a list of all available channels within a Team, useful for dynamically selecting where to send a message.
*   **Channel - Get:** Retrieves the details of a single channel.

## 3. Key Parameters (for the `Message: Post` operation)

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Team** | The Microsoft Teams Team where the destination channel is located. | `Sales Department` |
| **Channel** | The specific channel within the Team where the message will be posted. | `General` or `Q4-Deals` |
| **Content** | The text of the message to send. Supports Markdown formatting. | `"**New Lead!**\nContact: {{ $json.leadName }}"` |
| **Mentions** | Allows mentioning (`@`) specific users, a channel, or a tag to attract attention. | `@channel` |

## 4. JSON Configuration Example

This example shows how to send a notification message to a specific channel.

```json
{
  "parameters": {
    "team": "team-id-here",
    "channel": "channel-id-here",
    "content": "**Deal Won!** 🥳\n\nCongratulations to **{{ $json.salesRep }}** for closing the deal *{{ $json.dealName }}* worth €{{ $json.amount }}"
  },
  "id": "uuid-goes-here",
  "name": "Notify Sales Team",
  "type": "n8n-nodes-base.microsoftTeams",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftTeamsOAuth2Api": {
      "id": "credential-id",
      "name": "My Corporate Teams Account"
    }
  }
}
```

## 5. Practical Use Case (Pattern: Sales Notification)

**Objective:** Celebrate the winning of an important sales opportunity with the sales team.

**Flow:**
1.  **CRM Trigger (e.g., Salesforce):** The workflow starts when an opportunity is updated to the `"Closed Won"` status and its value exceeds €20,000.
2.  **Set:** A `Set` node prepares a formatted message, including the salesperson's name, the opportunity name, and its monetary value.
3.  **Microsoft Teams (Post) (This Node):**
    *   Selects the Team `"Sales Department"` and the channel `"Wins"`.
    *   Posts the prepared message, possibly mentioning the entire channel (`@channel`) to ensure everyone receives the notification.

This creates a positive feedback loop and increases visibility into the team's successes in real time.

## 6. Best Practices & Tips

*   **Corporate Notification Center:** Use Teams as the primary destination for all internal notifications that require visibility and collaboration (e.g., new qualified leads, critical system errors, weekly reports ready for review).
*   **Formatting with Markdown:** To make messages clearer and more readable, leverage the Markdown syntax supported by Teams: `**bold text**`, `*italic text*`, `[Link Text](URL)`, and bulleted lists.
*   **Use Mentions for Targeted Notifications:** If an alert is relevant only to one person or a subgroup, use the mention feature (`@first.last`) to send a direct notification only to them, reducing noise for the rest of the team.
*   **Complex Messages with Adaptive Cards:** For interactive messages that include buttons, input fields, or complex layouts, Teams uses "Adaptive Cards". Although the base node has limited support, the advanced technique involves building the Adaptive Card JSON (using their [online designer](https://adaptivecards.io/designer/)) and sending it via an `HTTP Request` node to the Microsoft Graph API. This unlocks enormous interactivity potential.
*   **Starting Workflows from Teams:** While this node is for *sending messages to* Teams, you can also *start a workflow from* Teams. The standard technique is to configure an "Incoming Webhook" in a Teams channel. This webhook provides you with a URL to which you can send messages. By configuring an n8n workflow with a `Webhook` trigger, you can capture these messages and start automations based on commands or events happening in Teams.
