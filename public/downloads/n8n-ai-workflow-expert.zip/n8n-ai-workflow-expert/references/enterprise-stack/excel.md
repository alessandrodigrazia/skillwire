# Nodo: Microsoft Excel (`n8n-nodes-base.microsoftExcel`)

## 1. Descrizione

Il nodo **Microsoft Excel** permette a n8n di leggere, scrivere e modificare file Excel (`.xlsx`) archiviati su **OneDrive** o **SharePoint**. Questo nodo è fondamentale per automatizzare i processi aziendali che si basano su fogli di calcolo, come il reporting, l'analisi dei dati o il logging di attività.

Consente di integrare la potenza delle automazioni n8n con lo strumento di analisi dati più diffuso al mondo, permettendo di popolare report per il management, registrare i risultati di un workflow o leggere dati di input da file gestiti dagli utenti.

## 2. Operazioni Principali

*   **Append to File:** Aggiunge nuove righe di dati in fondo a un foglio di lavoro esistente. È l'operazione più comune per il logging.
*   **Read from File:** Legge i dati da un foglio di lavoro. Può leggere l'intera tabella o solo un intervallo specifico.
*   **Create File:** Crea un nuovo file Excel da zero, popolandolo con i dati provenienti da n8n.
*   **Update Row(s):** Modifica una o più righe esistenti che corrispondono a un criterio di ricerca.
*   **Delete Row(s):** Cancella una o più righe.

## 3. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Storage** | Specifica dove è archiviato il file Excel. | `SharePoint` o `OneDrive` |
| **Site/Drive** | Il sito SharePoint o il Drive specifico in cui si trova il file. | `Sales Department` |
| **File** | Il file Excel su cui operare. | `Report_Vendite_Q4.xlsx` |
| **Worksheet** | Il nome o l'ID del foglio di lavoro all'interno del file. | `Leads-Incoming` |
| **Columns** | Per le operazioni di scrittura (`Append`, `Update`), definisce la mappatura tra i dati di n8n e le colonne del file Excel. | `{"Nome Lead": "{{ $json.name }}"}` |
| **Options > Has Header** | **(Importante)** Indica se la prima riga del foglio di calcolo è un'intestazione. Se attivo, n8n userà i nomi delle colonne invece delle lettere (A, B, C). | `true` |

## 4. Esempio di Configurazione JSON (Aggiungere Righe)

```json
{
  "parameters": {
    "storage": "sharePoint",
    "siteId": "my-company.sharepoint.com,site-id-here",
    "fileId": "file-id-here",
    "worksheetId": "worksheet-id-here",
    "operation": "append",
    "columns": {
      "mappingMode": "defineBelow",
      "value": {
        "Data Lead": "={{ DateTime.now().toISODate() }}",
        "Nome Contatto": "={{ $json.contactName }}",
        "Azienda": "={{ $json.companyName }}",
        "Valore Deal": "={{ $json.dealValue }}"
      }
    }
  },
  "id": "uuid-goes-here",
  "name": "Log Lead in Excel Report",
  "type": "n8n-nodes-base.microsoftExcel",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftExcelOAuth2Api": {
      "id": "credential-id",
      "name": "My Corporate Excel Account"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Logging Dati di Vendita)

**Obiettivo:** Ogni nuovo lead qualificato dal marketing deve essere registrato in un file Excel centrale sul sito SharePoint del team vendite.

**Flusso:**
1.  **Webhook:** Un workflow si avvia quando il marketing qualifica un nuovo lead nel loro sistema, inviando i dati a n8n.
2.  **Set:** Un nodo `Set` formatta i dati ricevuti, assicurandosi che i nomi dei campi siano puliti.
3.  **Microsoft Excel (Append) (Questo Nodo):**
    *   Si collega al file `Report_Leads_FY2025.xlsx` su SharePoint.
    *   Seleziona il foglio di lavoro `"Q4-Leads"`.
    *   Aggiunge una nuova riga, mappando i dati del lead (nome, azienda, email, fonte) alle colonne corrispondenti nel foglio di calcolo.
4.  **Teams:** Invia una notifica al canale del team vendite per avvisarli del nuovo lead, menzionando che è stato registrato nel report Excel.

## 6. Best Practices & Consigli

*   **Excel vs. Liste SharePoint:** Usa **Excel** quando gli utenti finali hanno bisogno della familiarità e delle capacità di analisi di un foglio di calcolo (grafici, tabelle pivot, formule complesse). Usa le **Liste SharePoint** per dati più strutturati, simili a un database, dove la consistenza e la validazione dei dati sono più importanti.
*   **Posizione del File:** Ricorda che il file Excel deve esistere su OneDrive o SharePoint prima che n8n possa interagirci (a meno che non si usi l'operazione `Create File`).
*   **Abilita Sempre `Has Header`:** È una best practice fondamentale. Attivando questa opzione, puoi fare riferimento alle colonne per nome (`Nome Cliente`) invece che per lettera (`C`), il che rende il tuo workflow infinitamente più leggibile e robusto a modifiche future del file (come l'aggiunta di una nuova colonna).
*   **Performance con File di Grandi Dimensioni:** Leggere o scrivere su file Excel con decine di migliaia di righe può essere un'operazione lenta. Se le performance diventano un problema, valuta se una Lista SharePoint o un database dedicato (come PostgreSQL o SQL Server) possano essere una soluzione migliore e più scalabile.
*   **Alternativa per Creare File:** Se hai solo bisogno di creare un file `.xlsx` o `.csv` da zero con i dati del tuo workflow (senza un template preesistente su OneDrive/SharePoint), il nodo generico `Spreadsheet File` è un'ottima alternativa. Il file generato sarà disponibile come dato binario e potrà poi essere caricato su OneDrive/SharePoint con il rispettivo nodo.
