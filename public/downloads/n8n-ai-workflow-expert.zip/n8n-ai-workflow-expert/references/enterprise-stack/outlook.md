# Nodo: Microsoft Outlook (`n8n-nodes-base.microsoftOutlook`)

## 1. Descrizione

Il nodo **Microsoft Outlook** è il connettore per il servizio di posta elettronica dell'ecosistema Microsoft 365. È il nodo centrale per qualsiasi automazione di processi di business che si basi sulla comunicazione via email in un ambiente aziendale.

Similmente al nodo Gmail, può funzionare sia come **trigger** (per avviare workflow in risposta a email in arrivo) sia come **azione** per inviare, leggere e organizzare messaggi. È uno strumento fondamentale per automatizzare i processi di vendita, il customer service e le comunicazioni interne.

## 2. Operazioni Principali

*   **Send:** Invia un'email. I parametri principali includono `To`, `Subject`, e `Body`. Supporta l'invio di email in formato HTML.
*   **Get:** Recupera un'email specifica tramite il suo ID.
*   **GetAll:** Recupera una lista di email da una cartella specifica, con la possibilità di applicare filtri avanzati.
*   **Move:** Sposta un'email da una cartella a un'altra. Questa è l'azione chiave per gestire lo stato di un'email processata (es. da `Inbox` a `Processed`).
*   **Create Folder:** Crea una nuova cartella nella casella di posta.

## 3. Il Nodo come Trigger (`microsoftOutlookTrigger`)

Se usato come primo nodo, si attiva non appena un'email arriva in una cartella specificata (di default, la `Inbox`). Questo permette di creare automazioni reattive, come la classificazione immediata dei lead in arrivo o la creazione di ticket di supporto.

## 4. Esempio di Configurazione JSON (Azione di Invio)

```json
{
  "parameters": {
    "operation": "send",
    "to": "{{ $json.contactEmail }}",
    "subject": "Follow-up riguardo la nostra conversazione su {{ $json.dealName }}",
    "body": "<p>Ciao {{ $json.contactFirstName }},</p><p>ti scrivo per dare seguito alla nostra recente chiacchierata. Saresti disponibile per una breve call la prossima settimana?</p>"
  },
  "id": "uuid-goes-here",
  "name": "Send Follow-up Email",
  "type": "n8n-nodes-base.microsoftOutlook",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftOutlookOAuth2Api": {
      "id": "credential-id",
      "name": "My Corporate Outlook Account"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Sales Nurturing Automatico)

**Obiettivo:** Inviare un'email di follow-up personalizzata quando un'opportunità di vendita in un CRM (es. HubSpot, Salesforce) passa a una certa fase.

**Flusso:**
1.  **CRM Trigger:** Il workflow si avvia quando un'opportunità viene spostata nella fase `"Follow-up"`.
2.  **Set:** Un nodo `Set` prepara i dati necessari: l'email del contatto, il suo nome e il contesto dell'opportunità.
3.  **LLM Node (Gemini):** Un modello AI genera un testo per l'email di follow-up, personalizzandolo con i dati del contatto e dell'opportunità.
4.  **Outlook (Send) (Questo Nodo):** Invia l'email generata dall'AI al potenziale cliente.
5.  **CRM (Update):** Un nodo finale aggiorna l'opportunità nel CRM, registrando che l'email di follow-up è stata inviata.

## 6. Best Practices & Consigli

*   **Usa le Cartelle per Gestire lo Stato:** A differenza di Gmail che usa le etichette, in Outlook il modo migliore per tracciare lo stato di un'email è spostarla. Un pattern comune è: triggerare le email nella `Inbox`, processarle e poi usare l'operazione `Move` per spostarle in una cartella `_Processed` o `_Archived`. Questo evita che il workflow le elabori di nuovo.
*   **Filtri Avanzati:** Sfrutta i filtri nell'operazione `GetAll` per recuperare solo le email che ti interessano. Puoi filtrare per mittente (`from`), per oggetto (`subject`), per categoria (`categories`) o per cartella.
*   **Sicurezza con OAuth2:** La connessione a un account Outlook aziendale è sicura e utilizza lo standard OAuth2. n8n non memorizzerà mai la tua password, ma riceverà un'autorizzazione ad agire per tuo conto, che può essere revocata in qualsiasi momento dall'amministratore di Microsoft 365.
*   **Invio da Caselle Condivise (Shared Mailbox):** Una funzionalità potentissima in ambito aziendale è la possibilità di inviare email da una casella di posta condivisa (es. `vendite@azienda.it`). Questo si può configurare nelle opzioni del nodo, a patto di avere i permessi necessari sul proprio account Microsoft 365.
*   **Formato HTML:** Per le comunicazioni aziendali, usa sempre il campo `Body` in modalità `HTML` per poter includere la firma aziendale, link e una formattazione professionale.
