# Nodo: Microsoft SharePoint (`n8n-nodes-base.microsoftSharePoint`)

## 1. Descrizione

Il nodo **Microsoft SharePoint** è il connettore per la piattaforma collaborativa di Microsoft. SharePoint è utilizzato dalle aziende come sistema centrale per la **gestione documentale**, l'archiviazione e la collaborazione su file e dati strutturati (tramite le Liste).

In n8n, questo nodo è fondamentale per automatizzare qualsiasi processo aziendale che ruoti attorno ai documenti: approvazione di report, analisi di contratti, archiviazione di fatture, e l'analisi di documenti di gara.

## 2. Operazioni Principali

Il nodo SharePoint può interagire con due tipi di risorse principali: File e List Item.

*   **File - Upload:** Carica un file (es. un report PDF generato da n8n) in una specifica Libreria Documentale di SharePoint.
*   **File - Download:** Scarica un file da SharePoint per elaborarlo in n8n (es. per darlo in pasto a un'AI).
*   **File - Get All:** Elenca tutti i file e le cartelle presenti in una specifica cartella di una Libreria Documentale.
*   **List Item - Create:** Crea un nuovo elemento in una Lista di SharePoint (che funziona come una tabella di un database).
*   **List Item - Get All:** Recupera elementi da una Lista, con la possibilità di filtrarli.
*   **List Item - Update:** Aggiorna un elemento esistente in una Lista.

## 3. Il Nodo come Trigger (`microsoftSharePointTrigger`)

Se usato come primo nodo, può avviare un workflow quando:
*   Un nuovo file viene caricato o modificato in una cartella specifica.
*   Un nuovo elemento viene creato o modificato in una Lista specifica.

Questo è estremamente potente per creare automazioni documentali reattive.

## 4. Esempio di Configurazione JSON (Caricamento File)

```json
{
  "parameters": {
    "resource": "file",
    "operation": "upload",
    "siteId": "my-company.sharepoint.com,site-id-here",
    "folderId": "folder-id-here",
    "binaryData": true,
    "binaryPropertyName": "data"
  },
  "id": "uuid-goes-here",
  "name": "Upload Report to SharePoint",
  "type": "n8n-nodes-base.microsoftSharePoint",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftSharePointOAuth2Api": {
      "id": "credential-id",
      "name": "My Corporate SharePoint Account"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Analisi Documenti di Gara)

**Obiettivo:** Automatizzare l'analisi preliminare di un nuovo documento di gara caricato dal team commerciale.

**Flusso:**
1.  **SharePoint Trigger:** Il workflow si avvia non appena un nuovo file viene aggiunto alla cartella `"Documenti di Gara/Da Analizzare"` sul sito SharePoint del reparto vendite.
2.  **SharePoint (Download):** Il workflow scarica immediatamente il file appena caricato.
3.  **Document Loader:** Il file (es. un PDF di 50 pagine) viene caricato e suddiviso in "chunk" di testo.
4.  **LLM Node (es. Claude / Gemini Pro):** Un modello AI con un ampio context window analizza il testo completo per estrarre i requisiti chiave, le scadenze, i criteri di valutazione e i potenziali rischi.
5.  **SharePoint (List Item: Create):** I risultati dell'analisi vengono usati per creare un nuovo elemento in una Lista SharePoint chiamata `"Analisi Gare"`, con colonne per `Nome Gara`, `Scadenza`, `Rischi Identificati` e `Sintesi Requisiti`.
6.  **Teams:** Un messaggio viene inviato al canale del team di prevendita con un riassunto dell'analisi e un link diretto all'elemento appena creato nella lista SharePoint.

## 6. Best Practices & Consigli

*   **SharePoint vs. OneDrive:** Usa **SharePoint** per i documenti di team, di reparto o aziendali, dove la struttura e i permessi sono importanti. Usa `OneDrive` per i file personali di un utente o per condivisioni informali. SharePoint è la scelta giusta per i processi di business strutturati.
*   **Trigger su Cartelle Specifiche:** Quando usi il trigger, configuralo sempre per monitorare una cartella molto specifica (es. `/Documenti Condivisi/Proposte/Incoming`). Evita di monitorare la radice di un sito per non generare esecuzioni indesiderate.
*   **Usa le Liste SharePoint come Database:** Le Liste sono un'ottima alternativa ad Airtable o Google Sheets all'interno dell'ecosistema Microsoft. Sono strutturate, supportano metadati, permessi e possono essere usate per salvare i risultati dei tuoi workflow o per gestire lo stato di un processo.
*   **Gestione dei File Binari:** Ricorda che l'operazione `Download` rende il file disponibile in n8n come dato binario (`binary data`). Questo dato può essere poi passato ad altri nodi, come un `Document Loader` per l'analisi del testo o un nodo `Outlook` per inviarlo come allegato email.
*   **Gestione dei Permessi:** SharePoint ha un sistema di permessi molto granulare. Assicurati che l'account Microsoft 365 connesso a n8n abbia i permessi di lettura/scrittura necessari per il Sito, la Libreria Documentale o la Lista con cui intendi interagire.
