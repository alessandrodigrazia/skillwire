# Nodo: Microsoft OneDrive (`n8n-nodes-base.microsoftOneDrive`)

## 1. Descrizione

Il nodo **Microsoft OneDrive** connette n8n allo spazio di archiviazione file personale di un utente all'interno dell'ecosistema Microsoft 365. È lo strumento per automatizzare operazioni su file e cartelle che risiedono nel OneDrive di un utente.

È ideale per scenari come il salvataggio di report personali, l'archiviazione di allegati email o l'avvio di workflow basati su file caricati da un utente nel proprio spazio cloud. Funziona come la controparte personale di SharePoint, che è invece orientato ai team e all'azienda.

## 2. Operazioni Principali

*   **File - Upload:** L'operazione più comune. Carica un file (ricevuto da un altro nodo come dato binario) in una specifica cartella di OneDrive.
*   **File - Download:** Scarica un file da OneDrive per renderlo disponibile come dato binario per i nodi successivi del workflow (es. per un'analisi AI).
*   **File - Get All:** Elenca tutti i file e le sottocartelle presenti in una cartella specifica.
*   **File - Delete:** Cancella un file.
*   **Folder - Create:** Crea una nuova cartella.

## 3. Il Nodo come Trigger (`microsoftOneDriveTrigger`)

Se usato come primo nodo del workflow, si attiva non appena un nuovo file viene caricato o modificato in una cartella specifica del OneDrive dell'utente, permettendo di avviare automazioni basate su eventi del filesystem.

## 4. Esempio di Configurazione JSON (Caricamento File)

```json
{
  "parameters": {
    "operation": "upload",
    "drive": "me",
    "folderId": "folder-id-here",
    "binaryData": true,
    "binaryPropertyName": "data",
    "fileName": "report-vendite-{{ DateTime.now().toISODate() }}.pdf"
  },
  "id": "uuid-goes-here",
  "name": "Upload Report to OneDrive",
  "type": "n8n-nodes-base.microsoftOneDrive",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftOneDriveOAuth2Api": {
      "id": "credential-id",
      "name": "My OneDrive Account"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Salvataggio Report Personale)

**Obiettivo:** Un venditore desidera ricevere un report settimanale delle sue opportunità aperte, salvato automaticamente nel suo OneDrive personale.

**Flusso:**
1.  **Schedule Trigger:** Il workflow si avvia ogni venerdì alle 17:00.
2.  **CRM Node (es. Salesforce):** Recupera tutte le opportunità "aperte" assegnate a quel venditore.
3.  **Spreadsheet File Node:** Converte la lista di opportunità in un file CSV o Excel.
4.  **OneDrive (Upload) (Questo Nodo):**
    *   Prende il file del report generato (come dato binario).
    *   Lo carica nella cartella `"Report Settimanali"` del OneDrive del venditore.
    *   Assegna un nome dinamico al file, come `"Report-Opportunita-2025-10-24.csv"`.
5.  **Outlook (Send):** Invia un'email al venditore per notificargli che il suo report è pronto e disponibile nel suo OneDrive.

## 6. Best Practices & Consigli

*   **OneDrive per il Personale, SharePoint per il Team:** Questa è la distinzione chiave. Usa **OneDrive** per i file di lavoro di un singolo utente (i "Miei Documenti" nel cloud). Usa **SharePoint** per i documenti che appartengono a un team, a un progetto o all'intera azienda e che richiedono una struttura e permessi di collaborazione.
*   **Trigger su Cartelle Dedicate:** Come per SharePoint, quando usi il trigger, fallo puntare a una cartella specifica e dedicata (es. `/App/n8n/Input`). Questo previene esecuzioni accidentali del workflow e mantiene l'automazione ordinata.
*   **Gestione dei Dati Binari:** L'operazione `Upload` si aspetta di ricevere dati binari. Questi dati possono provenire da un'operazione di `Download` (da OneDrive stesso o da un altro servizio come Gmail), da un nodo `HTTP Request` che scarica un file, o da un nodo che genera un file (come `Spreadsheet File` o un generatore di PDF).
*   **Condivisione di File:** Sebbene il nodo si concentri sulle operazioni sui file, puoi estenderne le capacità. Dopo aver caricato un file, puoi usare un nodo `HTTP Request` per chiamare l'API Microsoft Graph e creare un link di condivisione per quel file, da inviare poi via email o Teams.
*   **Autenticazione OAuth2:** La connessione a OneDrive è sicura e basata su OAuth2, senza che n8n debba mai memorizzare la tua password.
