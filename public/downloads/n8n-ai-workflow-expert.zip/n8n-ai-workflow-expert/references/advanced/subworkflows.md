# Guida Avanzata: Sub-workflow e Modularità

## 1. Descrizione

Un **Sub-workflow** è un workflow n8n autonomo che può essere eseguito da un altro workflow (detto "padre" o "parent"). Questo concetto è analogo a quello di una **funzione** o una **subroutine** nella programmazione tradizionale. Permette di incapsulare una logica specifica e riutilizzabile in un unico posto, migliorando drasticamente l'organizzazione, la manutenibilità e la leggibilità dei tuoi progetti di automazione.

Invece di avere un unico, monolitico workflow di 100 nodi, puoi suddividerlo in un workflow principale che orchestra le operazioni chiamando diversi sub-workflow specializzati.

## 2. I Componenti Chiave

Per implementare questo pattern servono due nodi specifici:

1.  **`Execute Workflow Trigger`:** Questo nodo deve essere il **trigger** del tuo sub-workflow. Definisce che il workflow è progettato per essere chiamato da un altro e ne specifica i parametri di input.

2.  **`Execute Workflow`:** Questo nodo viene usato nel workflow **padre** per chiamare il sub-workflow. Da qui si seleziona quale sub-workflow eseguire e si passano i dati di input necessari.

## 3. Flusso dei Dati: Chiamata e Ritorno

Il processo è simile a una chiamata di funzione:

1.  **Chiamata:** Il workflow padre raggiunge un nodo `Execute Workflow`. L'esecuzione del padre si **ferma** e attende.
2.  **Passaggio Dati:** I dati configurati nel nodo `Execute Workflow` vengono inviati come input al nodo `Execute Workflow Trigger` del sub-workflow.
3.  **Esecuzione:** Il sub-workflow viene eseguito dall'inizio alla fine, compiendo la sua logica.
4.  **Ritorno:** Alla fine della sua esecuzione, il sub-workflow deve restituire un risultato. Questo viene tipicamente fatto con un nodo `Respond to Webhook` che invia i dati a un URL speciale fornito dal trigger.
5.  **Ripresa:** Il workflow padre riceve i dati di ritorno dal sub-workflow nell'output del nodo `Execute Workflow` e riprende la sua esecuzione.

## 4. Esempio di Configurazione JSON

**A) Nodo `Execute Workflow` (nel workflow Padre):**
```json
{
  "parameters": {
    "workflowId": "SUB_WORKFLOW_ID",
    "source": "data",
    "data": "={{ { \"email\": $json.customerEmail } }}"
  },
  "name": "Call: Enrich Email",
  "type": "n8n-nodes-base.executeWorkflow",
  "typeVersion": 1,
  "position": [123, 456]
}
```

**B) Nodo `Execute Workflow Trigger` (nel Sub-workflow):**
```json
{
  "parameters": {},
  "name": "Start (on call)",
  "type": "n8n-nodes-base.executeWorkflowTrigger",
  "typeVersion": 1,
  "position": [-200, 0]
}
```

## 5. Caso d'Uso Pratico (Pattern: Astrazione della Logica)

**Obiettivo:** Creare una "funzione" riutilizzabile per arricchire un'email con dati da un servizio esterno, da usare in più workflow.

**Sub-workflow: `"Arricchisci-Email"`**
1.  **Trigger (`Execute Workflow Trigger`):** Si aspetta di ricevere un input con un campo `email`.
2.  **HTTP Request:** Chiama un'API (es. Clearbit) passando l'email ricevuta per ottenere il nome dell'azienda, il settore, ecc.
3.  **Set:** Formatta i dati ricevuti in un oggetto JSON pulito.
4.  **Respond to Webhook:** Restituisce l'oggetto JSON con i dati arricchiti al workflow chiamante.

**Workflow Padre (es. `"Nuovo Lead da Form"`)**
1.  **Webhook:** Riceve i dati di un nuovo lead, inclusa la sua email.
2.  **Execute Workflow (Questo Nodo):** Chiama il sub-workflow `"Arricchisci-Email"`, passandogli l'email del lead.
3.  **Airtable:** Il nodo riceve in output i dati arricchiti dal sub-workflow e li usa per creare un record completo nel CRM.

In questo modo, se in futuro cambierà il servizio di arricchimento, basterà modificare il solo sub-workflow, e tutti i workflow che lo usano beneficeranno automaticamente dell'aggiornamento.

## 6. Best Practices & Consigli

*   **DRY (Don't Repeat Yourself):** Se ti trovi a fare copia-incolla della stessa sequenza di 3 o più nodi in diversi workflow, è il segnale che quella logica dovrebbe essere estratta in un sub-workflow.
*   **Migliora la Manutenibilità:** Centralizzare una logica (es. l'invio di una notifica formattata su Teams) in un sub-workflow rende la manutenzione incredibilmente più semplice. Se devi cambiare il formato della notifica, modifichi un solo workflow invece di dieci.
*   **Astrazione e Leggibilità:** I sub-workflow nascondono la complessità. Un workflow padre può diventare una semplice sequenza di chiamate a sub-workflow (es. `Leggi Dati` -> `Arricchisci Dati` -> `Genera Report` -> `Invia Notifica`), rendendolo molto più facile da leggere e capire a colpo d'occhio.
*   **Testing Isolato:** È molto più facile testare un sub-workflow che compie una sola azione specifica, piuttosto che un enorme workflow monolitico. Puoi testare ogni "funzione" in modo isolato prima di orchestrarle insieme.
*   **Usa Nomi Chiari:** Dai ai tuoi sub-workflow nomi che descrivano chiaramente cosa fanno (es. `utility-SendWelcomeEmail`, `process-AnalyzeInvoicePdf`), in modo da poterli trovare e riutilizzare facilmente.
