# Guida Avanzata: Gestione degli Errori (Error Handling)

## 1. Perché la Gestione degli Errori è Fondamentale

Un workflow in produzione non può permettersi di fallire silenziosamente. Una gestione degli errori robusta è ciò che distingue un'automazione amatoriale da una di livello enterprise. Permette al sistema di reagire a problemi inaspettati (es. un'API non disponibile, dati in un formato errato), notificare gli errori, e, in alcuni casi, tentare un recupero automatico. Questa guida, basata sulle best practice, illustra come implementare queste strategie in n8n.

## 2. Meccanismi Integrati di n8n

n8n offre potenti strumenti nativi per la gestione degli errori.

### a) Error Workflow

È la strategia più potente e consigliata. Puoi designare un workflow separato (un "Error Workflow") che viene eseguito **automaticamente** ogni volta che il tuo workflow principale fallisce.

*   **Come funziona:** Nelle impostazioni del workflow principale, alla voce "Error Workflow", selezioni il workflow che hai creato per la gestione degli errori.
*   **Cosa riceve:** L'Error Workflow riceve un input speciale contenente tutte le informazioni sull'errore: il nome del workflow fallito, il nodo che ha causato l'errore, il messaggio di errore e i dati che erano in elaborazione in quel momento.
*   **Cosa fare nell'Error Workflow:** Tipicamente, un Error Workflow esegue queste azioni:
    1.  **Formatta un Messaggio:** Un nodo `Set` crea un messaggio di notifica chiaro.
    2.  **Notifica il Team:** Un nodo `Teams` o `Outlook` invia l'alert a un canale o a un amministratore, includendo tutti i dettagli dell'errore per un rapido debug.
    3.  **Logga l'Errore:** Un nodo `Airtable` o `Google Sheets` registra l'errore in un database per analisi future.

### b) Continue on Fail (Continua in caso di Fallimento)

Questa è un'opzione disponibile nelle **impostazioni di quasi ogni nodo**.

*   **Come funziona:** Se attivata, dice a n8n di non bloccare l'intero workflow se *quel specifico nodo* fallisce. L'esecuzione continuerà, ma il nodo fallito non produrrà alcun output.
*   **Quando usarlo:** È perfetto per operazioni non critiche. Esempio: in un workflow che arricchisce i dati di un cliente, una chiamata a un'API secondaria per trovare il logo dell'azienda può fallire. Attivando "Continue on Fail", il workflow continuerà a funzionare con i dati principali, anche se il logo non è stato trovato.

### c) Retry on Fail (Riprova in caso di Fallimento)

Anche questa è un'opzione nelle impostazioni del nodo.

*   **Come funziona:** Se un nodo fallisce, n8n tenterà automaticamente di eseguirlo di nuovo per un numero di volte specificato, attendendo un intervallo di tempo tra un tentativo e l'altro.
*   **Quando usarlo:** È la soluzione ideale per errori temporanei e imprevedibili, come un problema di rete momentaneo o un'API che risponde con un errore 503 (Service Unavailable). Impostare 2-3 tentativi con un intervallo di qualche secondo può risolvere automaticamente la maggior parte di questi problemi transitori.

## 3. Strategie di Implementazione Pratica

### a) Simulare un Blocco `try/catch` con il Nodo `Code`

Per operazioni rischiose all'interno di un singolo nodo, come il parsing di un JSON potenzialmente malformato, puoi usare un blocco `try/catch` nel nodo `Code`.

```javascript
// Esempio di gestione errore nel nodo Code
try {
  // Operazione rischiosa
  const data = JSON.parse($json.body.potentiallyInvalidJson);
  return [{ json: { success: true, parsedData: data } }];
} catch (error) {
  // Se il parsing fallisce, non bloccare il workflow.
  // Invece, produci un output che segnala l'errore.
  return [{ json: { success: false, error: error.message } }];
}
```

### b) Routing Condizionale con il Nodo `If`

Dopo un nodo che potrebbe fallire (come un `HttpRequest` o il nodo `Code` dell'esempio precedente), puoi usare un nodo `If` per controllare un flag di successo.

*   **Condizione del Nodo `If`:** `{{ $json.success }}` è `true`.
*   **Ramo `true`:** Il workflow prosegue con l'elaborazione normale.
*   **Ramo `false`:** Il workflow segue un percorso di gestione dell'errore (es. invia una notifica specifica e si ferma).

## 4. Best Practice

*   **Usa Sempre un Error Workflow:** Per qualsiasi workflow in produzione, imposta sempre un Error Workflow. È la tua rete di sicurezza principale.
*   **Anticipa i Punti di Fallimento:** Quando costruisci un workflow, chiediti: "Cosa succede se questo nodo fallisce?". I candidati più comuni sono le chiamate a API esterne (`HttpRequest`), l'elaborazione di dati (`Code`) e l'autenticazione.
*   **`Retry on Fail` per l'Instabilità della Rete:** Abilita sempre questa opzione per le chiamate a servizi esterni. Risolverà da sola una quantità sorprendente di errori.
*   **`Continue on Fail` per Dati Non Essenziali:** Usalo per i passaggi di "arricchimento" che, se falliscono, non compromettono il risultato finale del workflow.
*   **Messaggi di Errore Utili:** Quando invii una notifica di errore, non limitarti a dire "Workflow fallito". Includi sempre il nome del workflow, il nome del nodo, il messaggio di errore e, se possibile, i dati di input che hanno causato il problema. Questo renderà il debug 10 volte più veloce.
