# Guida Avanzata: Modalità di Esecuzione dei Workflow

## 1. Introduzione

n8n offre diverse "modalità di esecuzione" per i workflow. La scelta della modalità corretta è una decisione architetturale cruciale che impatta direttamente la **stabilità, la performance e la scalabilità** della tua istanza n8n. Questa guida illustra le differenze e fornisce raccomandazioni per ambienti di sviluppo e di produzione.

## 2. Le Modalità di Esecuzione Principali

### a) Modalità `regular` (Default)

È la modalità predefinita con cui n8n viene eseguito.

*   **Come Funziona:** Ogni esecuzione di un workflow viene gestita direttamente dal processo principale di n8n. Questo significa che l'interfaccia utente, l'API e l'esecuzione dei workflow condividono tutti le stesse risorse di CPU e memoria.

*   **Vantaggi:**
    *   **Semplicità:** Non richiede alcuna configurazione aggiuntiva.

*   **Svantaggi:**
    *   **Mancanza di Isolamento:** Un singolo workflow che consuma troppe risorse (es. un loop infinito, elaborazione di un file enorme) può rallentare o bloccare l'intera istanza di n8n, rendendo anche l'interfaccia utente irresponsive.
    *   **Scalabilità Limitata:** Non è adatta per gestire un alto volume di esecuzioni concorrenti.

*   **Quando Usarla:** È la modalità perfetta per lo **sviluppo**, il **testing** e per istanze personali con un numero limitato di workflow non critici.

### b) Modalità `queue` (Consigliata per la Produzione)

È la modalità progettata per ambienti di produzione seri.

*   **Come Funziona:** Quando un workflow deve essere eseguito, non viene eseguito immediatamente dal processo principale. Viene invece aggiunto a una **coda di messaggi** (gestita da un sistema esterno come Redis). Uno o più processi "worker" separati ascoltano questa coda, prelevano le esecuzioni e le processano in modo isolato.

*   **Vantaggi:**
    *   **Stabilità e Affidabilità:** Il processo principale rimane sempre reattivo e protetto. Un workflow che va in crash in un worker non influenzerà minimamente gli altri workflow o l'interfaccia principale.
    *   **Isolamento delle Risorse:** Ogni esecuzione avviene in un processo separato, garantendo un migliore isolamento di memoria e CPU.
    *   **Scalabilità:** È il fondamento per la scalabilità orizzontale. Puoi avviare più macchine con processi worker che attingono tutti dalla stessa coda, permettendoti di processare migliaia di esecuzioni in parallelo.

*   **Svantaggi:**
    *   **Complessità di Configurazione:** Richiede un'infrastruttura aggiuntiva (un server Redis) e la configurazione di variabili d'ambiente specifiche.

*   **Quando Usarla:** È **fortemente raccomandata per qualsiasi ambiente di produzione**, anche con un traffico moderato. È un requisito non negoziabile per applicazioni critiche o ad alto volume.

## 3. Come si Configura

La modalità di esecuzione non è un'impostazione che si trova all'interno di un workflow, ma una configurazione a livello di intera istanza n8n, gestita tramite **variabili d'ambiente**.

Per attivare la modalità `queue`, è necessario impostare le seguenti variabili d'ambiente prima di avviare n8n (tipicamente in un file `docker-compose.yml`):

```yaml
# Esempio di configurazione per docker-compose
services:
  n8n:
    environment:
      - EXECUTIONS_MODE=queue
      - QUEUE_BULL_REDIS_HOST=redis # Nome del servizio Redis
      - QUEUE_BULL_REDIS_PORT=6379
      - QUEUE_BULL_REDIS_PASSWORD=your-redis-password

  redis:
    image: redis:alpine
    command: ["redis-server", "--save", "60", "1", "--loglevel", "warning", "--requirepass", "your-redis-password"]
```

## 4. Raccomandazioni Finali

*   **Sviluppo e Test:** Inizia e lavora in modalità `regular` per la sua immediatezza.
*   **Produzione:** Prima di mettere in produzione qualsiasi workflow di importanza anche solo media, pianifica la migrazione della tua istanza n8n alla modalità `queue`. Questo ti salverà da innumerevoli problemi di stabilità e performance in futuro.
*   **Webhook:** Anche i workflow attivati da webhook beneficiano enormemente della modalità `queue`. Il processo principale riceve la chiamata webhook, la aggiunge istantaneamente alla coda e risponde subito al chiamante, mentre un worker la processerà in background. Questo evita timeout e garantisce che nessuna chiamata vada persa.
