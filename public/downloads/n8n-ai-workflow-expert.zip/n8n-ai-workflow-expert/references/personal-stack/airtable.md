# Nodo: Airtable (`n8n-nodes-base.airtable`)

## 1. Descrizione

Il nodo **Airtable** permette a n8n di connettersi e interagire con le basi di Airtable. Airtable è un servizio ibrido tra un foglio di calcolo e un database, estremamente flessibile e facile da usare. Per questo motivo, è la soluzione ideale da usare come "backend" o "database di stato" per i workflow di n8n, specialmente nello Stack Personale.

Può essere utilizzato per memorizzare i dati elaborati da un workflow, registrare l'esecuzione di un'automazione, tracciare lo stato di un processo (es. "Todo", "In Progress", "Done") e, soprattutto, per verificare se un'informazione è già stata processata.

## 2. Operazioni Principali

*   **Search:** L'operazione più importante. Cerca uno o più record che corrispondono a una formula specifica. È fondamentale per la deduplicazione e per recuperare dati.
*   **Create:** Aggiunge uno o più nuovi record a una tabella.
*   **Update:** Modifica uno o più record esistenti, identificandoli tramite il loro ID.
*   **Upsert:** Un'operazione combinata: se un record con una certa chiave esiste, lo aggiorna; altrimenti, lo crea.
*   **Get:** Recupera un singolo record conoscendone l'ID univoco.
*   **Delete:** Cancella uno o più record.

## 3. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Base** | La Base Airtable (il "database") a cui connettersi. | `Articoli Convertiti` |
| **Table** | La Tabella specifica all'interno della Base. | `Post Pubblicati` |
| **Operation** | L'azione da compiere (`Search`, `Create`, ecc.). | `Search` |
| **Filter By Formula** | **(Cruciale per `Search`)** La formula, in sintassi Airtable, usata per trovare i record. | `LOWER({VideoID}) = LOWER("{{ $json.VideoID }}")` |
| **Columns** | Per le operazioni `Create` e `Update`, definisce la mappatura tra i dati di n8n e le colonne di Airtable. | `{"Status": "Done", "Post Text": "{{ $json.post_text }}"}` |

## 4. Esempio di Configurazione JSON (Operazione di Ricerca)

Questo esempio, basato sui tuoi workflow, mostra come cercare un record per evitare di processare due volte lo stesso video.

```json
{
  "parameters": {
    "operation": "search",
    "base": {
      "__rl": true,
      "value": "appXXXXXXXXXXXXXXX",
      "mode": "id"
    },
    "table": {
      "__rl": true,
      "value": "tblXXXXXXXXXXXXXXX",
      "mode": "id"
    },
    "filterByFormula": "LOWER({VideoID}) = LOWER(\"{{ $json.VideoID }}\")",
    "limit": 1
  },
  "id": "uuid-goes-here",
  "name": "Ricerca video su Airtable",
  "type": "n8n-nodes-base.airtable",
  "typeVersion": 2.1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "airtableTokenApi": {
      "id": "credential-id",
      "name": "Airtable Personal Access Token"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Deduplicazione e Logging)

**Obiettivo:** Leggere un feed RSS e pubblicare un post su LinkedIn solo per gli articoli non ancora processati.

**Flusso:**
1.  **RSS Feed Read:** Il workflow si attiva e legge gli ultimi articoli da un feed.
2.  **Airtable (Search) (Questo Nodo):** Per ogni articolo, il workflow cerca nella tabella "Articoli Processati" se esiste già un record con lo stesso URL. La formula è: `LOWER({URL}) = LOWER("{{ $json.link }}")`.
3.  **If:** Un nodo `If` controlla se la ricerca ha prodotto risultati.
4.  **Ramo `true` (Record Trovato):** Il workflow si ferma per quell'articolo. L'articolo è già stato processato.
5.  **Ramo `false` (Nessun Record):**
    *   Un nodo AI genera il testo del post.
    *   Un nodo `LinkedIn` pubblica il post.
    *   **Airtable (Create):** Un secondo nodo Airtable **crea** un nuovo record nella tabella "Articoli Processati", salvando l'URL dell'articolo, il testo del post e la data. Questo garantisce che l'articolo non venga riprocessato la volta successiva.

## 6. Best Practices & Consigli

*   **Il Tuo Database di Riferimento:** Airtable è perfetto come "cervello" o memoria a lungo termine per i tuoi workflow. Usalo per tracciare cosa è stato fatto e per guidare le decisioni future.
*   **Padroneggia la `Filter By Formula`:** Questa è la funzionalità più potente del nodo. Ti permette di creare logiche di ricerca complesse. Ricorda che la sintassi è quella delle [formule di Airtable](https://support.airtable.com/docs/formula-field-reference), non JavaScript. Per rendere i confronti insensibili a maiuscole/minuscole, usa sempre `LOWER()` su entrambi i lati dell'uguaglianza.
*   **"Search Before Create":** Il pattern "Cerca prima di Creare" è la pratica numero uno per evitare duplicati e creare automazioni robuste. Applicalo sempre.
*   **Corrispondenza Nomi Campi:** I nomi dei campi che usi nel parametro `Columns` devono corrispondere **esattamente** (incluse maiuscole/minuscole e spazi) ai nomi delle colonne nella tua tabella Airtable.
*   **Sfrutta la UI di n8n:** Quando configuri il nodo, n8n ti permette di selezionare Base e Tabella da un menu a tendina, pre-compilando i loro ID. Questo riduce il rischio di errori.
