# Nodo: LinkedIn (`n8n-nodes-base.linkedIn`)

## 1. Descrizione

Il nodo **LinkedIn** consente a n8n di interagire con l'API di LinkedIn, permettendo di automatizzare la pubblicazione di contenuti sulla piattaforma. È il nodo finale per eccellenza nei workflow di content automation.

La sua funzione principale è quella di prendere un testo, tipicamente generato da un modello AI, e pubblicarlo come aggiornamento di stato su un profilo personale o, più comunemente per scopi di business, su una pagina aziendale (Organization).

## 2. Operazioni Principali

*   **Post:** L'operazione più importante e utilizzata. Pubblica un contenuto sulla piattaforma. Può essere un semplice post di testo, un articolo, o un post con un link o un'immagine.
*   **Get:** Recupera informazioni sul profilo dell'utente autenticato o su un'organizzazione che gestisce.

## 3. Parametri Chiave (per l'operazione `Post`)

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Post As** | Specifica se pubblicare come `Person` (profilo personale) o `Organization` (pagina aziendale). | `Organization` |
| **Organization** | Se si pubblica come `Organization`, questo campo permette di selezionare la pagina aziendale specifica. | `The GenAI Break (109375981)` |
| **Text** | **(Cruciale)** Il contenuto testuale del post. Qui viene inserito l'output del nodo AI che ha generato il testo. | `{{ $json.final_post_text }}` |
| **Additional Fields > Link** | Permette di aggiungere un URL al post, che LinkedIn mostrerà con un'anteprima. | `{{ $json.article_url }}` |

## 4. Esempio di Configurazione JSON

Questo esempio, tratto dai tuoi workflow, mostra come pubblicare un post di testo su una pagina aziendale.

```json
{
  "parameters": {
    "postAs": "organization",
    "organization": "={{ $('Configurazione').first().json.organizationId }}",
    "text": "={{ $json.final_post_text }}"
  },
  "id": "uuid-goes-here",
  "name": "LinkedIn: pubblica post",
  "type": "n8n-nodes-base.linkedIn",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "linkedInOAuth2Api": {
      "id": "credential-id",
      "name": "My LinkedIn Account"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Pubblicazione di Contenuti AI)

**Obiettivo:** Pubblicare automaticamente su una pagina LinkedIn aziendale un post generato da un'AI a partire da un articolo.

**Flusso:**
1.  **Trigger (Gmail/RSS):** Un nuovo articolo viene identificato.
2.  **AI Node (Gemini):** Un modello AI, guidato da un prompt dettagliato, genera un post LinkedIn di alta qualità basato sull'articolo.
3.  **QA Node (Opzionale):** Un secondo modello AI o un passaggio manuale approva la qualità del testo generato.
4.  **LinkedIn (Post) (Questo Nodo):**
    *   Riceve il testo finale e approvato.
    *   Il parametro `Text` viene popolato con il testo dall'AI.
    *   Il parametro `Post As` è impostato su `Organization`.
    *   Il post viene pubblicato sulla pagina aziendale.
5.  **Airtable (Update):** L'output del nodo LinkedIn contiene l'URN (Uniform Resource Name) del post appena creato. Questo ID viene salvato in Airtable per tenere traccia di ciò che è stato pubblicato.

## 6. Best Practices & Consigli

*   **Nodo Finale del Flusso:** Il nodo LinkedIn è tipicamente l'ultimo passo attivo in un workflow di automazione dei contenuti.
*   **La Qualità è Regina:** LinkedIn è una piattaforma professionale. Assicurati sempre che il contenuto generato dall'AI sia di alta qualità. I tuoi workflow di esempio implementano un eccellente pattern di Quality Assurance (QA) con un secondo agente AI ("Capo Redattore") che valida la bozza prima della pubblicazione. Questa è una best practice da mantenere.
*   **Salva l'URN del Post:** L'output del nodo dopo una pubblicazione di successo contiene l'URN del post (es. `urn:li:share:712345...`). Salva sempre questo ID nel tuo database di log (Airtable). Ti permetterà di fare riferimento al post in futuro, ad esempio per leggerne i commenti o per creare un link diretto (`https://www.linkedin.com/feed/update/URN_QUI`).
*   **Autenticazione Sicura:** La connessione a LinkedIn utilizza il protocollo sicuro OAuth2. Dovrai autorizzare n8n ad agire per conto del tuo profilo una sola volta.
*   **Testa con il Profilo Personale:** Durante lo sviluppo, potresti trovare più semplice e sicuro pubblicare sul tuo profilo personale (`Post As: Person`) per testare il workflow. Una volta che sei soddisfatto del risultato, puoi passare alla pubblicazione sulla pagina aziendale.
