# Nodo: Gmail (`n8n-nodes-base.gmail`)

## 1. Descrizione

Il nodo **Gmail** è l'interfaccia per interagire con il servizio di posta elettronica di Google. È un nodo estremamente versatile che può agire sia come **trigger** (per avviare un workflow quando arriva un'email) sia come **azione** (per leggere, inviare, spostare o etichettare messaggi).

È un componente centrale dello "Stack Personale" e la base per innumerevoli workflow di automazione, dalla gestione delle email in arrivo alla creazione di notifiche. L'analisi del dataset lo conferma come uno dei nodi di integrazione più popolari.

## 2. Operazioni Principali

Il nodo Gmail può eseguire diverse azioni, le più importanti sono:

*   **Send:** Invia un'email. I parametri chiave sono `To`, `Subject` e `Body` (per testo semplice) o `HTML` (per email formattate).
*   **Get:** Recupera il contenuto completo di una singola email, specificandone l'ID.
*   **GetAll:** Recupera una lista di email. È fondamentale usare il parametro `Filters` per limitare la ricerca (es. per etichetta, mittente, oggetto) ed evitare di scaricare l'intera casella di posta.
*   **Add Labels / Remove Labels:** Aggiunge o rimuove una o più etichette da un messaggio. Questa è un'operazione cruciale per tracciare lo stato di elaborazione di un'email.
*   **Move:** Sposta un'email in una cartella diversa (es. Cestino, Spam, Archivio).

## 3. Il Nodo come Trigger (`gmailTrigger`)

Se usato come primo nodo di un workflow, si comporta da trigger. Si attiva non appena un'email che corrisponde ai criteri specificati (es. ha una certa etichetta, proviene da un certo mittente) arriva nella casella di posta. Questo permette di avviare automazioni in tempo reale.

## 4. Esempio di Configurazione JSON (Azione di Invio)

```json
{
  "parameters": {
    "operation": "send",
    "to": "{{ $json.customerEmail }}",
    "subject": "Il tuo ordine #{{ $json.orderId }} è stato spedito!",
    "html": "<p>Ciao {{ $json.customerName }},</p><p>Siamo felici di comunicarti che il tuo ordine è in viaggio!</p>"
  },
  "id": "uuid-goes-here",
  "name": "Send Shipping Confirmation",
  "type": "n8n-nodes-base.gmail",
  "typeVersion": 2.1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "gmailOAuth2": {
      "id": "credential-id",
      "name": "My Gmail Account"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Email → AI → Airtable)

Questo pattern, visto nel workflow `01. Articolo → Post LinkedIn`, è un esempio perfetto di come usare il nodo Gmail sia come trigger che come azione.

**Flusso:**
1.  **Gmail Trigger:** Il workflow si attiva quando un'email riceve l'etichetta `"DaConvertire"`.
2.  **Gmail (Get):** L'ID dell'email triggerata viene usato per recuperare il corpo completo del messaggio.
3.  **LLM Node (Gemini):** Il testo dell'email viene analizzato e trasformato in un post per LinkedIn.
4.  **Airtable (Create):** Il post generato viene salvato in un database Airtable.
5.  **Gmail (Remove/Add Labels):** Per completare il ciclo, il workflow usa due nodi Gmail:
    *   Uno per **rimuovere** l'etichetta `"DaConvertire"`.
    *   Uno per **aggiungere** l'etichetta `"Convertito"`.

Questo passaggio finale è fondamentale per evitare che il workflow processi la stessa email all'infinito.

## 6. Best Practices & Consigli

*   **Usa le Etichette per Controllare il Flusso:** Le etichette (labels) sono il metodo più robusto per gestire lo stato di un'email in un'automazione. Un workflow dovrebbe sempre "marcare" un'email dopo averla elaborata (es. aggiungendo `status-processed`) per evitare di riprocessarla.
*   **Filtra Sempre in `GetAll`:** Non usare mai l'operazione `GetAll` senza filtri. Recuperare migliaia di email è inefficiente e può bloccare il workflow. Usa sempre il campo `Filters` per specificare un'etichetta, un mittente o un intervallo di date.
*   **Usa HTML per Email Formattate:** Quando invii email, preferisci sempre il campo `HTML` al `Body`. Questo ti permette di usare tag HTML (`<p>`, `<b>`, `<a>`, ecc.) per creare messaggi più leggibili e professionali, includendo link e formattazione.
*   **Autenticazione Sicura con OAuth2:** La connessione a Gmail usa il protocollo OAuth2, che è lo standard di sicurezza del settore. n8n ti guiderà nel processo di autorizzazione, che va fatto una sola volta. Non dovrai mai inserire la tua password di Google direttamente in n8n.
*   **Attenzione ai Limiti di Invio:** Gmail impone dei limiti sul numero di email che puoi inviare in un giorno (circa 500 per un account standard). Se devi inviare grandi volumi di email, considera l'uso di servizi transazionali dedicati (come SendGrid o Postmark) al posto del tuo account Gmail personale.
