# Nodo: RSS Feed Read (`n8n-nodes-base.rssFeedRead`)

## 1. Descrizione

Il nodo **RSS Feed Read** è uno strumento semplice ed efficace per monitorare i contenuti di siti web, blog e testate giornalistiche. Può essere utilizzato in due modi:

1.  **Come Trigger (`RSS Feed Read Trigger`):** Avvia un workflow automaticamente ogni volta che un nuovo elemento (come un nuovo articolo) viene pubblicato in un feed RSS.
2.  **Come Azione:** Legge tutti gli elementi correnti di un feed RSS su richiesta, all'interno di un workflow già avviato.

Questo nodo è il punto di partenza ideale per qualsiasi automazione di content curation, monitoraggio delle notizie o aggregazione di contenuti da più fonti.

## 2. Modalità di Utilizzo e Parametri

### a) Modalità Trigger

Questa è la modalità più comune. Il workflow viene eseguito per **ogni nuovo articolo** trovato nel feed dall'ultimo controllo.

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Feed URL** | L'URL del feed RSS da monitorare. | `https://www.theverge.com/rss/index.xml` |
| **Poll Times** | La frequenza con cui n8n deve controllare il feed. Puoi definire ore o minuti. | Ogni ora (`1h`) |

### b) Modalità Azione

In questa modalità, il nodo legge **tutti gli articoli** presenti nel feed in quel momento.

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **URL** | L'URL del feed RSS da leggere. | `{{ $json.feedUrl }}` |

## 3. Esempio di Configurazione JSON (Modalità Trigger)

```json
{
  "parameters": {
    "pollTimes": {
      "item": [
        {
          "mode": "everyX",
          "value": 1,
          "unit": "hours"
        }
      ]
    },
    "feedUrl": "https://feeds.arstechnica.com/arstechnica/index/"
  },
  "id": "uuid-goes-here",
  "name": "RSS Feed Trigger",
  "type": "n8n-nodes-base.rssFeedReadTrigger",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Caso d'Uso Pratico (Pattern: Content Curation)

**Obiettivo:** Monitorare un blog di settore e pubblicare un commento su LinkedIn per ogni nuovo articolo interessante.

**Flusso:**
1.  **RSS Feed Read Trigger (Questo Nodo):** Controlla ogni ora il feed RSS di un blog. Quando trova un nuovo articolo, il workflow parte e l'output del nodo contiene titolo, link e descrizione dell'articolo.
2.  **Airtable (Search):** Cerca in un database se l'URL (`link`) dell'articolo è già stato processato. Questo passaggio di **deduplicazione** è fondamentale.
3.  **If:** Se la ricerca non produce risultati, l'articolo è nuovo e il workflow prosegue.
4.  **HTTP Request:** Spesso i feed RSS contengono solo un riassunto. Questo nodo scarica il contenuto completo dell'articolo dalla pagina web originale (usando il `link` fornito dal trigger).
5.  **LLM Node (Gemini):** Riassumere l'articolo completo e genera un commento o un'analisi strategica.
6.  **LinkedIn (Post):** Pubblica il contenuto generato.
7.  **Airtable (Create):** Salva l'URL dell'articolo nel database per assicurarsi che non venga riprocessato in futuro.

## 5. Best Practices & Consigli

*   **Trigger vs. Azione:** Usa la modalità **Trigger** per un monitoraggio automatico e continuo in background. Usa la modalità **Azione** se vuoi controllare tu quando leggere il feed (es. una volta al giorno tramite uno `Schedule` trigger che poi legge 5 feed diversi in parallelo).
*   **La Deduplicazione è Obbligatoria:** Non fidarti ciecamente del fatto che il trigger si attivi una sola volta per ogni item. I feed RSS possono avere dei comportamenti anomali. Implementa **sempre** un tuo meccanismo di deduplicazione (come il pattern "Search before Create" su Airtable) usando l'URL o il GUID dell'articolo come chiave univoca.
*   **Recupera il Contenuto Completo:** Ricorda che la maggior parte dei feed RSS fornisce solo un riassunto nel campo `description` o `content:encoded`. Per un'analisi di qualità con un LLM, avrai quasi sempre bisogno di un passaggio aggiuntivo con un nodo `HTTP Request` per scaricare il testo completo dalla pagina dell'articolo.
*   **Gestire Più Feed:** Se devi monitorare molti feed, creare un workflow per ogni feed può essere dispersivo. Un pattern più efficiente è usare un singolo `Schedule` trigger (es. ogni ora) che attiva un workflow che legge una lista di URL di feed da un database (es. Airtable) e li processa in un loop `Split in Batches`.
