# Node: RSS Feed Read (`n8n-nodes-base.rssFeedRead`)

## 1. Description

The **RSS Feed Read** node is a simple and effective tool for monitoring website, blog, and news outlet content. It can be used in two ways:

1.  **As a Trigger (`RSS Feed Read Trigger`):** Automatically starts a workflow every time a new item (such as a new article) is published in an RSS feed.
2.  **As an Action:** Reads all current items from an RSS feed on demand, within an already running workflow.

This node is the ideal starting point for any content curation automation, news monitoring, or content aggregation from multiple sources.

## 2. Usage Modes and Parameters

### a) Trigger Mode

This is the most common mode. The workflow runs for **each new article** found in the feed since the last check.

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Feed URL** | The URL of the RSS feed to monitor. | `https://www.theverge.com/rss/index.xml` |
| **Poll Times** | How frequently n8n should check the feed. You can define hours or minutes. | Every hour (`1h`) |

### b) Action Mode

In this mode, the node reads **all articles** currently in the feed.

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **URL** | The URL of the RSS feed to read. | `{{ $json.feedUrl }}` |

## 3. JSON Configuration Example (Trigger Mode)

```json
{
  "parameters": {
    "pollTimes": {
      "item": [
        {
          "mode": "everyX",
          "value": 1,
          "unit": "hours"
        }
      ]
    },
    "feedUrl": "https://feeds.arstechnica.com/arstechnica/index/"
  },
  "id": "uuid-goes-here",
  "name": "RSS Feed Trigger",
  "type": "n8n-nodes-base.rssFeedReadTrigger",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Content Curation)

**Objective:** Monitor an industry blog and publish a comment on LinkedIn for each new interesting article.

**Flow:**
1.  **RSS Feed Read Trigger (This Node):** Checks the RSS feed of a blog every hour. When it finds a new article, the workflow starts and the node's output contains the article's title, link, and description.
2.  **Airtable (Search):** Searches a database to check if the article's URL (`link`) has already been processed. This **deduplication** step is fundamental.
3.  **If:** If the search returns no results, the article is new and the workflow continues.
4.  **HTTP Request:** RSS feeds often contain only a summary. This node downloads the full content of the article from the original web page (using the `link` provided by the trigger).
5.  **LLM Node (Gemini):** Summarizes the full article and generates a comment or strategic analysis.
6.  **LinkedIn (Post):** Publishes the generated content.
7.  **Airtable (Create):** Saves the article URL to the database to ensure it will not be reprocessed in the future.

## 5. Best Practices & Tips

*   **Trigger vs. Action:** Use **Trigger** mode for automatic and continuous background monitoring. Use **Action** mode if you want to control when to read the feed (e.g., once a day via a `Schedule` trigger that then reads 5 different feeds in parallel).
*   **Deduplication is Mandatory:** Do not blindly trust that the trigger will fire only once per item. RSS feeds can exhibit anomalous behavior. **Always** implement your own deduplication mechanism (like the "Search before Create" pattern on Airtable) using the article URL or GUID as a unique key.
*   **Retrieve the Full Content:** Remember that most RSS feeds provide only a summary in the `description` or `content:encoded` field. For quality analysis with an LLM, you will almost always need an additional step with an `HTTP Request` node to download the full text from the article's page.
*   **Managing Multiple Feeds:** If you need to monitor many feeds, creating a workflow for each feed can be scattered. A more efficient pattern is to use a single `Schedule` trigger (e.g., every hour) that activates a workflow which reads a list of feed URLs from a database (e.g., Airtable) and processes them in a `Split in Batches` loop.
