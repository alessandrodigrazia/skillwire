# Nodo: YouTube (`n8n-nodes-base.youTube`)

## 1. Descrizione

Il nodo **YouTube** permette a n8n di interagire con l'API di YouTube. Consente di automatizzare azioni come la ricerca di video, il recupero di dettagli su video o canali e, soprattutto, la gestione di playlist.

È un nodo chiave per i workflow di content creation e curation, permettendo di usare YouTube come fonte di contenuti da analizzare, riassumere o riproporre su altre piattaforme.

## 2. Operazioni Principali

*   **Search:** Cerca video, canali o playlist in base a una query di testo.
*   **Video - Get:** Recupera tutte le informazioni dettagliate di un video specifico fornendone l'ID.
*   **Playlist Item - GetAll:** Recupera tutti i video (items) contenuti in una specifica playlist. Questa è un'operazione molto comune per processare una lista di video curata.
*   **Playlist Item - Insert:** Aggiunge un video a una playlist.
*   **Playlist Item - Delete:** Rimuove un video da una playlist. Questa azione è fondamentale per "marcare" un video come processato.

## 3. Parametri Chiave

| Parametro | Descrizione | Esempio di Valore |
| :--- | :--- | :--- |
| **Resource** | La risorsa di YouTube con cui si vuole interagire. | `Playlist Item` |
| **Operation** | L'azione specifica da eseguire sulla risorsa. | `GetAll` |
| **Playlist ID** | L'ID univoco della playlist di YouTube su cui operare. Si trova nell'URL della playlist. | `PL1WSxrKCmNH9HwFIM9nVRpHOdPDg8y0H6` |
| **Video ID** | L'ID univoco di un video, necessario per operazioni come `Get` o `Insert`. | `dQw4w9WgXcQ` |

## 4. Esempio di Configurazione JSON (Lettura da Playlist)

Questo esempio, basato sul tuo workflow `02. Video → Post LinkedIn`, mostra come leggere tutti i video da una playlist.

```json
{
  "parameters": {
    "resource": "playlistItem",
    "operation": "getAll",
    "playlistId": "={{ $('Configurazione').first().json.playlistId }}",
    "returnAll": true
  },
  "id": "uuid-goes-here",
  "name": "Ricerca video da convertire in playlist YouTube",
  "type": "n8n-nodes-base.youTube",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "youTubeOAuth2Api": {
      "id": "credential-id",
      "name": "My YouTube Account"
    }
  }
}
```

## 5. Caso d'Uso Pratico (Pattern: Coda di Lavoro con Playlist)

**Obiettivo:** Creare un sistema in cui si aggiungono video a una playlist "Da Processare" e un workflow n8n li trasforma automaticamente in post per LinkedIn.

**Flusso:**
1.  **Azione Manuale:** Un utente (tu) trova un video interessante su YouTube e lo aggiunge alla playlist "Da Processare".
2.  **Schedule Trigger:** Ogni ora, un workflow n8n si avvia.
3.  **YouTube (GetAll) (Questo Nodo):** Il workflow legge tutti i video presenti nella playlist "Da Processare".
4.  **Airtable (Search):** Per ogni video, controlla in un database se è già stato processato in passato (deduplicazione).
5.  **If (Nuovo Video):** Se il video è nuovo, il flusso continua:
    *   Un nodo AI genera un post basato sul titolo e la descrizione del video.
    *   Un nodo `LinkedIn` pubblica il post.
    *   **YouTube (Delete) (Questo Nodo):** Il video viene **rimosso** dalla playlist "Da Processare". Questo passaggio è cruciale per evitare che venga riprocessato al ciclo successivo.

## 6. Best Practices & Consigli

*   **Usa le Playlist come Code di Lavoro:** Il pattern "inbox playlist" è estremamente efficace. Ti permette di curare contenuti in modo asincrono (dal tuo telefono, dal browser) e lasciare che n8n li processi in modo automatico. Una playlist per l'input (`Da Processare`) e magari una per l'output (`Processati`) è un'ottima struttura.
*   **Rimuovi Dopo l'Elaborazione:** Ricorda sempre di usare l'operazione `Playlist Item: Delete` dopo aver processato con successo un video. È il modo più pulito per gestire lo stato e prevenire doppioni.
*   **Attenzione alle Quote API:** L'API di YouTube ha un sistema di quote giornaliere. Le operazioni di lettura (`GetAll`) sono relativamente economiche, ma un workflow che gira molto frequentemente (es. ogni minuto) su una playlist molto grande potrebbe consumare la quota. Un controllo ogni ora o due è solitamente un buon compromesso.
*   **Autenticazione OAuth2:** Come per gli altri servizi Google, la connessione a YouTube richiede un'autenticazione sicura tramite OAuth2, che n8n gestisce in modo guidato.
*   **Recupera Dati Specifici:** L'output del nodo YouTube può essere molto ricco di informazioni. Usa un nodo `Set` per estrarre solo i campi che ti servono (`videoId`, `title`, `description`) per mantenere il flusso di dati pulito e leggibile.
