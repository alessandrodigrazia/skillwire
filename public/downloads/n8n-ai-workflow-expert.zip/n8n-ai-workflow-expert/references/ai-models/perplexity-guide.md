# Perplexity Guide (SPECIALIZED - Web Search Focus)

## Quando Usare Perplexity
Usa Perplexity quando hai bisogno di **informazioni web real-time**:
- Eventi attuali e news
- Informazioni su prodotti recenti
- Market research aggiornato
- Fact-checking con fonti
- Dati dopo il training cutoff dei modelli

**Caratteristica Unica:** Web search integrato + AI synthesis
**Limitazione:** Non disponibile come nodo LangChain nativo in n8n

---

## Modelli Disponibili

### sonar (Standard)
**Specifiche:**
- Costo: ~$1/1M tokens (stimato)
- Velocità: ~60 tokens/sec
- Features: Web search + AI synthesis
- Sources: Include citazioni

**Usa per:**
- Research generale
- Current events
- Quick fact-checking

---

### sonar-pro (Enhanced)
**Specifiche:**
- Costo: ~$3/1M tokens (stimato)
- Velocità: ~50 tokens/sec
- Features: Enhanced accuracy + more sources
- Depth: Analisi più approfondita

**Usa per:**
- Research professionale
- High-stakes fact-checking
- Comprehensive analysis

---

## Integrazione N8N (via HTTP Request)

Perplexity non ha nodo LangChain dedicato, usa **HTTP Request**:

### Setup Base
```json
{
  "type": "n8n-nodes-base.httpRequest",
  "parameters": {
    "method": "POST",
    "url": "https://api.perplexity.ai/chat/completions",
    "authentication": "genericCredentialType",
    "genericAuthType": "httpHeaderAuth",
    "sendBody": true,
    "contentType": "application/json",
    "bodyParameters": {
      "parameters": [
        {
          "name": "model",
          "value": "sonar"
        },
        {
          "name": "messages",
          "value": "=[{\"role\": \"user\", \"content\": \"{{ $json.query }}\"}]"
        }
      ]
    }
  },
  "credentials": {
    "httpHeaderAuth": {
      "id": "YOUR_CREDENTIAL_ID",
      "name": "Perplexity API Key"
    }
  }
}
```

### Credential Setup
1. Crea credential **HTTP Header Auth**
2. **Header Name:** `Authorization`
3. **Header Value:** `Bearer YOUR_PERPLEXITY_API_KEY`

---

## Casi d'Uso Ottimali

### 1. Current Events Summary
```javascript
const query = "Quali sono gli ultimi sviluppi nell'AI questa settimana?";
```

**Response:** Informazioni aggiornate con link alle fonti

**Alternativa senza Perplexity:**
- Modelli standard → info obsolete (training cutoff)

---

### 2. Product Research
```javascript
const query = `
Trova le informazioni più recenti su {{ $json.productName }}.
Include: features, pricing, reviews, data di rilascio.
`;
```

**Beneficio:** Dati sempre aggiornati da web

---

### 3. Market Research
```javascript
const query = `
Ricerca i trend attuali nel settore {{ $json.industry }}.
Focus su: dimensione mercato, player chiave, news recenti.
`;
```

**Valore:** Intelligence competitiva real-time

---

### 4. Fact-Checking con Fonti
```javascript
const query = `
Verifica questa affermazione: "{{ $json.claim }}"
Fornisci fonti affidabili.
`;
```

**Output:** Verifica + link a fonti originali

---

### 5. Competitor Analysis
```javascript
const query = `
Analizza {{ $json.competitorName }}:
- Prodotti recenti lanciati
- Funding e acquisizioni
- Cambiamenti leadership
- News ultime 30 giorni
`;
```

---

## Response Format

### Struttura Response Perplexity
```json
{
  "id": "response-id",
  "model": "sonar",
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "Risposta con citazioni numerate [1], [2], etc."
    },
    "finish_reason": "stop"
  }],
  "citations": [
    "https://source1.com/article",
    "https://source2.com/page",
    "https://source3.com/news"
  ]
}
```

### Estrarre Risposta in N8N
```javascript
// Nel Code node dopo HTTP Request
const response = $json.choices[0].message.content;
const citations = $json.citations || [];

return [{
  json: {
    answer: response,
    sources: citations
  }
}];
```

---

## Pattern di Integrazione

### Pattern 1: Research → Content Generation
```
Perplexity (ricerca argomento) →
Store risultati in Airtable →
Gemini 2.5 Flash (genera contenuto da ricerca) →
Publish
```

**Benefici:**
- Info current (Perplexity)
- Generazione cost-effective (Gemini)
- **Risparmio:** 89% vs usare Perplexity per entrambi

**Esempio workflow:**
```json
{
  "nodes": [
    {
      "name": "1. Research con Perplexity",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "https://api.perplexity.ai/chat/completions",
        "method": "POST",
        "body": {
          "model": "sonar",
          "messages": [{
            "role": "user",
            "content": "Ricerca {{ $json.topic }}"
          }]
        }
      }
    },
    {
      "name": "2. Store Research in Airtable",
      "type": "n8n-nodes-base.airtable",
      "parameters": {
        "operation": "create"
      }
    },
    {
      "name": "3. Generate Content con Gemini",
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
      "parameters": {
        "modelName": "models/gemini-2.5-flash"
      }
    }
  ]
}
```

---

### Pattern 2: Daily News Digest
```
Schedule Trigger (daily 8 AM) →
Perplexity (news su topics specifici) →
Gemini (summarize + formato email) →
Gmail (send digest)
```

**Use case:** Rassegna stampa personalizzata automatica

---

### Pattern 3: Competitive Intelligence
```
Schedule (weekly) →
Split (lista competitors) →
For each competitor:
  → Perplexity (latest news/updates) →
  → Gemini (analyze + scoring) →
Merge results →
Report in Google Sheets →
Slack notification
```

---

### Pattern 4: Research Cache Strategy
```
User query →
Check Airtable cache (< 24h old?) →
  IF found → Return cached
  IF not found →
    → Perplexity (fresh research) →
    → Cache in Airtable (with timestamp) →
    → Return result
```

**Beneficio:** Riduce chiamate Perplexity duplicate
**Risparmio:** 60-80% sui costi per query ripetute

---

## Ottimizzazione Costi

### Strategia 1: Research Batch
Invece di query individuali, batch:

```javascript
const query = `
Ricerca questi 5 argomenti:
1. {{ $json.topic1 }}
2. {{ $json.topic2 }}
3. {{ $json.topic3 }}
4. {{ $json.topic4 }}
5. {{ $json.topic5 }}

Per ognuno fornisci: summary + 2-3 fonti chiave.
`;
```

**Risparmio:** 1 API call vs 5 (80% risparmio)

---

### Strategia 2: Perplexity → Gemini Pipeline
```
Input: Tema generale →
Perplexity: Research iniziale (1 query) →
Gemini: Genera 10 pezzi di contenuto da ricerca →
Output: 10 articoli basati su 1 ricerca

Cost breakdown:
- Perplexity: $3 (1 query)
- Gemini: $0.50 (10 generazioni)
Total: $3.50

vs.

- Perplexity per ogni pezzo: $30 (10 queries)
Savings: 88%
```

---

### Strategia 3: Caching Intelligente
```javascript
// Logica caching
const cacheKey = hash(query);
const cached = await airtable.search({ key: cacheKey });

if (cached && isRecent(cached.timestamp, hours=24)) {
  return cached.result;
} else {
  const result = await perplexity.search(query);
  await airtable.create({ key: cacheKey, result, timestamp: now() });
  return result;
}
```

**Risparmio:** 70-90% per query ripetute

---

## Quando Usare vs NON Usare

### ✅ USA Perplexity quando:
- Hai bisogno di info **post-training cutoff** (> Jan 2025)
- News e current events
- Product info recenti (lanci ultimi mesi)
- Market intelligence real-time
- Verification con fonti necessaria

### ❌ NON usare Perplexity quando:
- Info generale già nei training data
- Content generation (usa Gemini - più economico)
- Structured data extraction (usa GPT-4o/Gemini)
- Alto volume senza caching (troppo costoso)
- Info non time-sensitive

---

## Confronto Costi

### Scenario: 1000 Research Queries

| Strategy | Cost | Notes |
|----------|------|-------|
| **Perplexity only** | ~$3000 | 1000 queries × $3 |
| **Perplexity + Cache (50% hit)** | ~$1500 | 500 unique queries |
| **Perplexity + Gemini content** | ~$350 | 100 research + 1000 content gen |
| **Standard LLM (no search)** | $37.50 | Gemini 2.5 Flash (but outdated info) |

**Conclusione:** Usa Perplexity strategicamente, non per tutto

---

## Template Workflow Perplexity

### Research to Content Pipeline
```json
{
  "name": "Perplexity Research → Gemini Content",
  "nodes": [
    {
      "name": "Schedule: Daily Research",
      "type": "n8n-nodes-base.scheduleTrigger",
      "parameters": {
        "rule": {
          "interval": [{"field": "days", "daysInterval": 1}]
        }
      }
    },
    {
      "name": "Topics to Research",
      "type": "n8n-nodes-base.set",
      "parameters": {
        "assignments": {
          "assignments": [
            {"name": "topic", "value": "Latest AI developments"}
          ]
        }
      }
    },
    {
      "name": "Perplexity Research",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "https://api.perplexity.ai/chat/completions",
        "method": "POST",
        "sendBody": true,
        "bodyParameters": {
          "parameters": [
            {
              "name": "model",
              "value": "sonar"
            },
            {
              "name": "messages",
              "value": "=[{\"role\": \"user\", \"content\": \"{{ $json.topic }}\"}]"
            }
          ]
        }
      }
    },
    {
      "name": "Extract Research Data",
      "type": "n8n-nodes-base.code",
      "parameters": {
        "jsCode": "const response = $json.choices[0].message.content;\nconst sources = $json.citations || [];\n\nreturn [{ json: { research: response, sources } }];"
      }
    },
    {
      "name": "Generate Content with Gemini",
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
      "parameters": {
        "modelName": "models/gemini-2.5-flash"
      }
    },
    {
      "name": "Store in Airtable",
      "type": "n8n-nodes-base.airtable",
      "parameters": {
        "operation": "create"
      }
    }
  ]
}
```

---

## Best Practices

### 1. Query Specificity
❌ **Vago:**
```
"Tell me about AI"
```

✅ **Specifico:**
```
"What are the major AI product launches in December 2024? Focus on: company, product name, key features, and launch date."
```

### 2. Source Validation
Sempre estrarre e verificare le citazioni:

```javascript
// Code node dopo Perplexity
const citations = $json.citations || [];

// Filter only trusted domains
const trustedSources = citations.filter(url =>
  url.includes('techcrunch.com') ||
  url.includes('reuters.com') ||
  url.includes('bloomberg.com')
);

return [{ json: {
  answer: $json.choices[0].message.content,
  trustedSources
}}];
```

### 3. Rate Limiting
Implementa delays per API calls:

```javascript
// Dopo ogni Perplexity call
await new Promise(resolve => setTimeout(resolve, 2000)); // 2s delay
```

---

## Limitazioni

### 1. Nessun Nodo LangChain Nativo
- Devi usare HTTP Request manualmente
- No integration con AI Agents diretta
- Setup più complesso vs Gemini/OpenAI

### 2. Costi Variabili
- Pricing non sempre trasparente
- Cost per query può variare
- Difficile budgeting preciso

### 3. Rate Limits
- Limiti su queries/min
- Possibili throttling
- Necessario retry logic

---

## Alternative a Perplexity

### Opzione 1: Gemini + Google Search API
```
Google Custom Search API (ricerca) →
Gemini 2.5 Flash (sintesi risultati)
```

**Pro:** Più controllo, potenzialmente più economico
**Contro:** Setup più complesso

### Opzione 2: Web Scraping + Gemini
```
HTTP Request (fetch pagine web) →
Extract from File (parse HTML) →
Gemini (analizza contenuto)
```

**Pro:** Massimo controllo
**Contro:** Fragile (cambiamenti siti), legal issues

### Opzione 3: RSS Feeds + Gemini
```
RSS Feed Read (fonti news) →
Gemini (analizza e sintetizza)
```

**Pro:** Gratuito, affidabile
**Contro:** Solo fonti con RSS, non query-based

---

## Conclusione: Quando Vale Perplexity

### Usa Perplexity se:
✅ Budget OK per research professionale
✅ Info real-time critical
✅ Fonti verificate necessarie
✅ Time-sensitive intelligence
✅ Alternative insufficienti

### Evita Perplexity se:
❌ Budget limitato
❌ Info non time-sensitive
❌ Alto volume queries
❌ Alternative (RSS, scraping) sufficienti

---

## Strategia Raccomandata

**Hybrid Approach:**
```
1. Daily/Weekly Research: Perplexity
   - Market updates
   - Competitor news
   - Industry trends

2. Content Generation: Gemini
   - Articles
   - Social posts
   - Summaries

3. Cache Everything: Airtable
   - Avoid duplicate queries
   - Build knowledge base
```

**ROI Optimization:**
- 1 Perplexity query → 10+ content pieces (Gemini)
- Cache results → Reuse for 24-48h
- Batch queries quando possibile

**Expected Savings:** 70-90% vs using Perplexity for everything

---

## Summary Table

| Aspect | Perplexity | Gemini 2.5 Flash | When to Use |
|--------|-----------|------------------|-------------|
| **Real-time Info** | ✅ Excellent | ❌ Training cutoff | Current events → Perplexity |
| **Cost** | $$$ High | $ Low | General tasks → Gemini |
| **Sources** | ✅ Provided | ❌ No citations | Need verification → Perplexity |
| **Content Gen** | Okay | ✅ Excellent | Bulk content → Gemini |
| **Speed** | Medium | ✅ Fast | High volume → Gemini |

**Best Practice:** Perplexity for research, Gemini for production
