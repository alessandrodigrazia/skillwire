# Google Gemini Guide (PRIMARY RECOMMENDATION)

## Overview
Google Gemini is the **primary recommended AI model** for n8n workflows due to its optimal balance of cost, speed, and quality.

**Cost Advantage:** 33-200x cheaper than premium models
**Speed Advantage:** Fastest inference (up to 100 tokens/sec)
**Quality:** Excellent for 90%+ of use cases

---

## Available Models

### gemini-2.5-flash ⭐ **DEFAULT CHOICE**
**When to use:** 90% of workflows

**Specs:**
- Speed: ~100 tokens/sec (very fast)
- Context: 1M tokens
- Best for: Content generation, categorization, fast processing

**Perfect for:**
- Social media posts
- Email responses
- Content categorization
- Simple Q&A
- Tag generation
- Summaries
- General content generation

**Example:**
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "models/gemini-2.5-flash",
    "options": {
      "temperature": 0.7,
      "topP": 1,
      "topK": 40
    }
  }
}
```

---

### gemini-2.5-pro **PREMIUM CHOICE**
**When to use:** 10% of workflows (when highest quality needed)

**Specs:**
- Speed: ~60 tokens/sec
- Context: 2M tokens
- Best for: Complex reasoning, long documents, vision tasks, maximum quality

**Use cases:**
- Long document analysis (>50k tokens)
- Complex reasoning chains
- Image/video analysis
- Multi-modal tasks
- High-stakes content generation
- Maximum accuracy required

**Example:**
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "models/gemini-2.5-pro",
    "options": {
      "temperature": 0.7,
      "topP": 0.95,
      "maxOutputTokens": 8192
    }
  }
}
```

---

## N8N Node Configuration

### Full Node Structure
```json
{
  "parameters": {
    "modelName": "models/gemini-2.5-flash",
    "options": {
      "temperature": 0.7,
      "topP": 1,
      "topK": 40,
      "maxOutputTokens": 2048,
      "safetySettings": []
    }
  },
  "id": "uuid-here",
  "name": "Google Gemini Chat Model",
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "typeVersion": 1,
  "position": [x, y],
  "credentials": {
    "googlePalmApi": {
      "id": "credential-id",
      "name": "Google Gemini API"
    }
  }
}
```

### Parameter Guide

#### temperature (0.0 - 2.0)
Controls randomness/creativity:
- **0.0-0.3:** Deterministic, factual tasks
  - Data extraction
  - Classification
  - Factual Q&A
- **0.5-0.7:** Balanced (DEFAULT)
  - General content generation
  - Summaries
  - Emails
- **0.8-1.2:** Creative
  - Marketing copy
  - Blog posts
  - Social media
- **1.3-2.0:** Very creative (experimental)
  - Brainstorming
  - Fiction

#### topP (0.0 - 1.0)
Nucleus sampling:
- **0.9-1.0:** More diverse output
- **0.8-0.9:** Balanced
- **0.6-0.7:** More focused

**Recommendation:** Keep at 1.0 unless specifically tuning

#### topK (1 - 100)
Number of top tokens to consider:
- **1-10:** Very focused
- **20-40:** Balanced (DEFAULT)
- **50-100:** More random

#### maxOutputTokens
- **Default:** 2048
- **Short responses:** 512-1024
- **Long content:** 4096-8192
- **Maximum:** 8192 (Flash Lite/Flash), 8192 (Pro)

---

## Common Use Cases & Prompts

### Use Case 1: LinkedIn Post Generation
```javascript
// Prompt in chainLlm node
const prompt = `
Sei un esperto di LinkedIn in lingua italiana.
Trasforma questo articolo in un post LinkedIn coinvolgente e professionale.

Articolo: {{ $json.articleText }}

Requisiti:
- Lunghezza: 150-250 parole
- Tono: Professionale ma accessibile
- Emoji: Max 2-3, solo se pertinenti
- Call-to-action finale
- Hashtag: 3-5 rilevanti

Formato finale: Solo testo del post, senza note o commenti.
`;
```

**Node config:**
```json
{
  "modelName": "models/gemini-2.5-flash",
  "options": {
    "temperature": 0.8,
    "maxOutputTokens": 1024
  }
}
```

---

### Use Case 2: Email Categorization
```javascript
// With outputParserStructured
const schema = {
  "category": "One of: URGENT, NORMAL, SPAM, NEWSLETTER",
  "priority": "Number 1-5",
  "requiresReply": "Boolean"
};
```

**Node config:**
```json
{
  "modelName": "models/gemini-2.5-flash",
  "options": {
    "temperature": 0.2,
    "maxOutputTokens": 256
  }
}
```

**Prompt:**
```
Categorizza questa email.

Da: {{ $json.from }}
Oggetto: {{ $json.subject }}
Testo: {{ $json.body }}

Rispondi in JSON secondo questo schema.
```

---

### Use Case 3: Content Summarization
```javascript
const prompt = `
Riassumi questo articolo in modo conciso.

Articolo: {{ $json.content }}

Lunghezza: 2-3 frasi (max 100 parole)
Stile: Chiaro e diretto
`;
```

**Node config:**
```json
{
  "modelName": "models/gemini-2.5-flash",
  "options": {
    "temperature": 0.5,
    "maxOutputTokens": 512
  }
}
```

---

### Use Case 4: Sentiment Analysis
```javascript
const prompt = `
Analizza il sentimento di questo testo.

Testo: {{ $json.feedback }}

Rispondi in JSON:
{
  "sentiment": "positive|neutral|negative",
  "score": 0.0-1.0,
  "reason": "breve spiegazione"
}
`;
```

**Node config:**
```json
{
  "modelName": "models/gemini-2.5-flash",
  "options": {
    "temperature": 0.3
  }
}
```

---

### Use Case 5: Multi-Language Translation
```javascript
const prompt = `
Traduci questo testo in {{ $json.targetLanguage }}.

Testo originale ({{ $json.sourceLanguage }}):
{{ $json.text }}

Requisiti:
- Mantieni tono e stile
- Adatta espressioni idiomatiche
- Solo traduzione, nessun commento
`;
```

**Node config:**
```json
{
  "modelName": "models/gemini-2.5-flash",
  "options": {
    "temperature": 0.5
  }
}
```

---

## Vision Capabilities (Pro only)

### Image Analysis
Gemini 2.5 Pro can analyze images:

```javascript
// In n8n, pass image as binary data
const prompt = `
Analizza questa immagine e descrivi:
1. Oggetti principali
2. Colori dominanti
3. Emozione/atmosfera
4. Possibili utilizzi

Rispondi in formato JSON.
`;
```

**Node config:**
```json
{
  "modelName": "models/gemini-2.5-pro",
  "options": {
    "temperature": 0.6
  }
}
```

**Binary data:** Include image in previous node output

---

## Best Practices

### 1. Prompt Engineering

**❌ Bad:**
```
"Create a post"
```

**✅ Good:**
```
"Sei un copywriter esperto.
Trasforma questo articolo in un post LinkedIn.
Lunghezza: 200 parole.
Tono: Professionale.
Target: Manager IT italiani.
Include: CTA e 3-5 hashtag.
```

**Key principles:**
- Be specific
- Define role/persona
- Specify length/format
- Define tone/style
- Include examples if needed

---

### 2. Temperature Tuning

**Classification/Extraction:**
```json
{ "temperature": 0.1-0.3 }
```

**General Content:**
```json
{ "temperature": 0.5-0.7 }
```

**Creative Content:**
```json
{ "temperature": 0.8-1.2 }
```

---

### 3. Output Length Control

Use maxOutputTokens to prevent:
- Unnecessary verbosity
- Cost overruns
- Long processing times

**Rule of thumb:**
- 1 token ≈ 0.75 words (English)
- 1 token ≈ 0.6 words (Italian)

---

### 4. Error Handling

Always include error handling:

```javascript
// In Code node after Gemini
try {
  const response = $input.item.json.text;
  if (!response) {
    throw new Error("Empty response from Gemini");
  }
  return [{ json: { response } }];
} catch (error) {
  return [{
    json: {
      error: error.message,
      fallback: "Default response"
    }
  }];
}
```

---

### 5. Structured Output

Use `outputParserStructured` for JSON:

```
chainLlm Node (Gemini) →
outputParserStructured →
outputParserAutofixing (optional)
```

**Benefits:**
- Guaranteed JSON format
- Auto-fixing for minor errors
- Type safety

---

## Cost Optimization Strategies

### Strategy 1: Start with Flash
```
Gemini 2.5 Flash → Test quality → Upgrade to Pro only if needed
```

**Best Practice:** Flash handles 90% of use cases excellently

---

### Strategy 2: Hybrid Filtering
```
1000 items → Gemini 2.5 Flash (categorize, fast)
Filter to top 100 (uncertain cases)
→ Gemini 2.5 Pro (detailed analysis)

Result: Speed + accuracy where needed
```

---

### Strategy 3: Caching (when available)
For repeated queries:
- Cache common responses
- Use Redis/Airtable for results
- Check cache before API call

---

### Strategy 4: Batch Processing
Process multiple items in single request when possible:

```javascript
// Instead of 100 API calls
const prompt = `Categorize these 100 emails:
${emails.map((e, i) => `${i}. ${e.subject}`).join('\n')}
`;

// 1 API call, 100x cheaper
```

---

## Common Pitfalls

### ❌ Pitfall 1: Using Pro for simple tasks
**Problem:** Slower + unnecessary for most tasks

**Solution:** Always start with Gemini 2.5 Flash

---

### ❌ Pitfall 2: Not specifying format
**Problem:** Inconsistent outputs

**Solution:** Always specify exact format needed

---

### ❌ Pitfall 3: Too high temperature for extraction
**Problem:** Unreliable structured data

**Solution:** Use temperature < 0.3 for extraction

---

### ❌ Pitfall 4: Not using output parser
**Problem:** Manual JSON parsing, errors

**Solution:** Use outputParserStructured node

---

## Integration Patterns

### Pattern 1: Gemini + Airtable
```
Trigger →
Gemini (categorize/generate) →
Airtable (store) →
Conditional actions
```

### Pattern 2: Gemini Chain
```
Gemini 1 (summarize) →
Gemini 2 (translate) →
Gemini 3 (optimize for platform)
```

### Pattern 3: Gemini + Human Review
```
Gemini (generate draft) →
Store in Airtable (status: pending) →
Email for review →
Webhook (approve/reject) →
Publish or refine
```

---

## Performance Tips

### Tip 1: Parallel Processing
Process independent items in parallel:

```
Input (10 items) →
Split →
10 parallel Gemini calls →
Merge results
```

**Speedup:** 10x faster than sequential

---

### Tip 2: Early Exit
Stop processing if criteria met:

```
Gemini (quick check) →
IF (confidence > 0.9) → Done
ELSE → Gemini Pro (detailed check)
```

---

### Tip 3: Progressive Enhancement
Start fast, enhance later:

```
Gemini Flash Lite (immediate) → Store →
Background: Gemini Pro (enhancement) → Update
```

**UX:** Users see results immediately

---

## Monitoring & Metrics

### Track These Metrics
1. **Cost per workflow execution**
2. **Average response time**
3. **Quality score (human review)**
4. **Error rate**

### Optimization Loop
```
1. Measure baseline (2.5 Flash)
2. If quality insufficient → Try 2.5 Pro
3. Track speed vs. quality tradeoff
```

---

## Multi-Language Support

Gemini excels at:
- Italian
- English
- Spanish
- French
- German
- Portuguese
- And 100+ more

**Tip:** Specify language in prompt:
```
"Rispondi in italiano"
"Respond in English"
```

---

## Summary: Gemini Selection Logic

```javascript
function selectGeminiModel(useCase) {
  // Pro for complex/long/vision tasks
  if (useCase.tokensIn > 50000 ||
      useCase.hasImages ||
      useCase.complexity === 'high' ||
      useCase.maxQualityNeeded) {
    return 'gemini-2.5-pro';
  }

  // Default: Flash for everything else
  return 'gemini-2.5-flash';
}
```

---

**Key Takeaway:** Start with `gemini-2.5-flash` for 90% of workflows. It's fast, cost-effective, and excellent quality. Upgrade to `gemini-2.5-pro` only for complex reasoning, long documents, or vision tasks.

**Best Practice:** Flash first, Pro when needed.
