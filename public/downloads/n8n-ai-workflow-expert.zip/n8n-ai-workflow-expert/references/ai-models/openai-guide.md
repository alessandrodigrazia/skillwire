# OpenAI Guide (SECONDARY - Accuracy Focus)

## Quando Usare OpenAI
Usa OpenAI quando **l'accuratezza è più importante del costo**:
- Estrazione dati strutturati complessi
- Generazione codice di alta qualità
- Function calling avanzato
- Hai già infrastruttura OpenAI esistente

**Costo:** 2-33x più costoso di Gemini 2.5 Flash
**Accuratezza:** Leggermente superiore per output strutturati

---

## Modelli Disponibili

### gpt-4o-mini (CONSIGLIATO per OpenAI)
**Specifiche:**
- Costo: $0.15/1M input, $0.60/1M output
- Velocità: ~70 tokens/sec
- Context: 128k tokens

**Usa per:**
- Estrazione dati strutturati
- Task OpenAI veloci
- Generazione JSON affidabile
- Integrazione API

**Configurazione N8N:**
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
  "parameters": {
    "model": "gpt-4o-mini",
    "options": {
      "temperature": 0.7,
      "maxTokens": 2000
    }
  },
  "credentials": {
    "openAiApi": {
      "id": "YOUR_OPENAI_CREDENTIAL_ID",
      "name": "OpenAI Account"
    }
  }
}
```

---

### gpt-4o (Alta Accuratezza)
**Specifiche:**
- Costo: $2.50/1M input, $10.00/1M output
- Velocità: ~50 tokens/sec
- Context: 128k tokens
- Capacità vision

**Usa per:**
- Massima accuratezza richiesta
- Generazione codice complesso
- Output strutturato critico
- Analisi immagini

**Esempio:**
```json
{
  "parameters": {
    "model": "gpt-4o",
    "options": {
      "temperature": 0.5,
      "maxTokens": 4000
    }
  }
}
```

---

### o1-preview (Ragionamento Avanzato)
**Specifiche:**
- Costo: $15/1M input, $60/1M output
- Velocità: ~20 tokens/sec
- Context: 128k tokens

**Usa per:**
- Ragionamento matematico
- Problem-solving complesso
- Logica multi-step
- Task scientifici

**Warning:** 100-200x più costoso di Gemini 2.5 Flash

**Esempio:**
```json
{
  "parameters": {
    "model": "o1-preview",
    "options": {
      "temperature": 1.0,
      "maxTokens": 4000
    }
  }
}
```

---

## Casi d'Uso Ottimali

### 1. Parsing Fatture/Documenti
```javascript
const prompt = `
Estrai i dati da questa fattura in formato JSON.

Testo fattura: {{ $json.invoiceText }}

Schema richiesto:
{
  "numero_fattura": "string",
  "data": "YYYY-MM-DD",
  "totale": "number",
  "fornitore": "string",
  "voci": [{"descrizione": "...", "importo": 0}]
}
`;
```

**Modello:** gpt-4o-mini
**Temperature:** 0.1-0.2
**Perché OpenAI:** Eccellente per estrazione strutturata precisa

---

### 2. Generazione Codice
```javascript
const prompt = `
Genera una funzione Python che {{ $json.requirements }}.

Requisiti:
- Include docstring
- Aggiungi type hints
- Gestione errori
- Unit tests
`;
```

**Modello:** gpt-4o
**Temperature:** 0.5
**Perché OpenAI:** Qualità codice superiore

---

### 3. Estrazione JSON Complessa
```javascript
const prompt = `
Estrai tutte le aziende, persone, date e importi da questo testo.

Testo: {{ $json.text }}

Formato:
{
  "aziende": [{"nome": "", "contesto": ""}],
  "persone": [{"nome": "", "ruolo": ""}],
  "date": [{"data": "", "evento": ""}],
  "importi": [{"valore": 0, "valuta": "", "contesto": ""}]
}
`;
```

**Modello:** gpt-4o-mini
**Temperature:** 0.2
**Response Format:** `{"type": "json_object"}`

---

## Function Calling (Punto di Forza OpenAI)

OpenAI eccelle nel function calling con gli AI Agents:

### Setup Agent con Tools
```json
{
  "type": "@n8n/n8n-nodes-langchain.agent",
  "parameters": {
    "promptType": "define",
    "text": "={{ $json.query }}"
  }
}
```

**Tools collegabili:**
- `toolHttpRequest` (chiamate API)
- `toolWorkflow` (sub-workflows)
- `toolCalculator` (calcoli)
- Custom tools

**Vantaggi OpenAI:**
- Function calling più affidabile
- Migliore interpretazione dei parametri
- Error handling superiore

---

## Configurazione Avanzata

### JSON Mode (Garantisce Output JSON)
```json
{
  "options": {
    "response_format": {"type": "json_object"},
    "temperature": 0.3
  }
}
```

**Importante:** Nel prompt devi specificare che vuoi JSON

---

### Few-Shot Examples (Migliora Accuratezza)
```javascript
const prompt = `
Estrai dati nel seguente formato.

Esempio 1:
Input: "Fattura #123 da Acme Corp per €500"
Output: {"numero": "123", "fornitore": "Acme Corp", "importo": 500}

Esempio 2:
Input: "Invoice #456 from Beta Ltd for €1200"
Output: {"numero": "456", "fornitore": "Beta Ltd", "importo": 1200}

Ora estrai da:
{{ $json.text }}
`;
```

**Risultato:** +15-25% accuratezza

---

## Comparazione Costi con Gemini

### Scenario: 100k Estrazioni Strutturate

| Modello | Input Cost | Output Cost | Totale |
|---------|-----------|-------------|--------|
| **Gemini 2.5 Flash** | $7.50 | $30.00 | **$37.50** |
| **GPT-4o-mini** | $15.00 | $60.00 | **$75.00** |
| **GPT-4o** | $250.00 | $1000.00 | **$1250.00** |

**Savings Gemini:** 50% vs GPT-4o-mini, 97% vs GPT-4o

---

## Quando NON Usare OpenAI

❌ **Evita OpenAI per:**
- Categorizzazione semplice (usa Gemini 2.5 Flash - 50% più economico)
- Generazione contenuti alto volume (troppo costoso)
- Task multi-lingua (Gemini migliore)
- Analisi immagini (Gemini 2.5 Pro superiore e più economico)

✅ **Usa OpenAI solo quando:**
- Gemini 2.5 Flash accuratezza < 90%
- Gemini 2.5 Pro accuratezza < 95%
- Function calling critico
- Infrastruttura OpenAI esistente

---

## Best Practices OpenAI

### 1. Temperature per Task Type

**Estrazione Dati:**
```json
{"temperature": 0.1}
```

**Contenuti Generali:**
```json
{"temperature": 0.7}
```

**Creativi:**
```json
{"temperature": 0.9}
```

### 2. Max Tokens Optimization
```json
{
  "maxTokens": 256   // Categorizzazione
  "maxTokens": 1024  // Estrazione standard
  "maxTokens": 4096  // Generazione lunga
}
```

**Risparmio:** Limitare tokens riduce costi output

### 3. Retry Logic
```javascript
// Nel Code node dopo OpenAI
let retries = 0;
while (retries < 3) {
  try {
    const result = callOpenAI();
    if (isValidJSON(result)) break;
  } catch (e) {
    retries++;
  }
}
```

---

## Pattern di Integrazione

### Pattern 1: Gemini → OpenAI Fallback
```
Input →
Gemini 2.5 Flash (fast, cheap) →
IF (confidence < 0.9) →
  GPT-4o-mini (accurate) →
  Result
ELSE →
  Result (Gemini)
```

**Beneficio:** 80% risolti da Gemini (cheap), 20% da OpenAI (accurate)
**Risparmio:** ~60% sui costi totali

---

### Pattern 2: Batch + OpenAI
```
1000 items →
Batch in groups of 10 →
GPT-4o-mini (process batch) →
Merge results
```

**Beneficio:** Riduce API calls da 1000 a 100
**Risparmio:** Overhead ridotto

---

### Pattern 3: OpenAI per Validation
```
Gemini (generate) →
OpenAI (validate/refine) →
Final output
```

**Use case:** Content generation + quality control

---

## Vision Capabilities (GPT-4o)

### Analisi Immagini
```javascript
const prompt = `
Analizza questa immagine e descrivi:
1. Oggetti principali
2. Testo visibile (OCR)
3. Colori dominanti
4. Possibile uso/contesto

Rispondi in JSON.
`;
```

**Configurazione:**
```json
{
  "model": "gpt-4o",
  "options": {
    "temperature": 0.6,
    "maxTokens": 1024
  }
}
```

**Note:** Include immagine come binary data dal nodo precedente

**Alternativa:** Gemini 2.5 Pro spesso migliore per vision (più economico)

---

## Embeddings (Per RAG)

### OpenAI Embeddings Node
```json
{
  "type": "@n8n/n8n-nodes-langchain.embeddingsOpenAi",
  "parameters": {
    "model": "text-embedding-3-small"
  },
  "credentials": {
    "openAiApi": {
      "id": "xxx",
      "name": "OpenAI"
    }
  }
}
```

**Costi:**
- text-embedding-3-small: $0.02/1M tokens
- text-embedding-3-large: $0.13/1M tokens

**Use case:** Vector search, RAG systems, similarity search

---

## Monitoring & Optimization

### Metriche da Tracciare
1. **Cost per task type**
2. **Accuracy rate** (vs Gemini)
3. **Average latency**
4. **Error/retry rate**

### Optimization Loop
```
1. Start: Gemini 2.5 Flash (baseline)
2. Measure: Accuratezza < 90%?
3. Test: GPT-4o-mini (sample 100 items)
4. Compare: Accuracy vs Cost
5. Decide: Switch se gain > 10% e budget OK
```

---

## Errori Comuni

### ❌ Errore 1: Usare GPT-4o per tutto
**Problema:** Costi 33x superiori a Gemini

**Soluzione:**
```
Gemini 2.5 Flash (default) →
Se insufficiente → GPT-4o-mini →
Se ancora insufficiente → GPT-4o
```

---

### ❌ Errore 2: Non specificare JSON nel prompt
**Problema:** Output non strutturato anche con `json_object` mode

**Soluzione:**
```javascript
const prompt = `
Rispondi SOLO in formato JSON valido.
Schema: {"campo1": "valore", "campo2": 123}
...
`;
```

---

### ❌ Errore 3: Temperature troppo alta per estrazione
**Problema:** Output inconsistenti

**Soluzione:** Temperature 0.1-0.3 per task deterministici

---

## Strategia Raccomandata

### Decision Tree
```javascript
function selectModel(task) {
  // Default: sempre Gemini
  if (task.type === "simple") {
    return "gemini-2.5-flash";
  }

  // Upgrade per accuratezza
  if (task.structuredOutput && task.criticalAccuracy) {
    return "gpt-4o-mini";
  }

  // Premium solo se necessario
  if (task.maxAccuracy && task.budgetOK) {
    return "gpt-4o";
  }

  // Default safe
  return "gemini-2.5-flash";
}
```

---

## Template Workflow OpenAI

### Estrazione Strutturata
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.httpRequest",
      "name": "Fetch Documents"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
      "name": "OpenAI GPT-4o-mini",
      "parameters": {
        "model": "gpt-4o-mini",
        "options": {
          "temperature": 0.2,
          "response_format": {"type": "json_object"}
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.chainLlm",
      "name": "Extract Structured Data"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "name": "Parse JSON"
    },
    {
      "type": "n8n-nodes-base.code",
      "name": "Validate & Clean"
    }
  ]
}
```

---

## Riassunto Decisionale

### Usa OpenAI (GPT-4o-mini) quando:
✅ Estrazione dati strutturati critici
✅ Gemini accuratezza < 90%
✅ Function calling necessario
✅ Budget permette 2x cost vs Gemini

### Usa OpenAI (GPT-4o) quando:
✅ Gemini + GPT-4o-mini insufficienti
✅ Generazione codice mission-critical
✅ Budget permette 33x cost vs Gemini

### NON usare OpenAI quando:
❌ Task semplici (categorizzazione, tag)
❌ Alto volume / budget limitato
❌ Multi-lingua (Gemini migliore)
❌ Gemini già soddisfa requisiti

---

## Conclusione

**Strategia Ottimale:**
1. **Default:** Gemini 2.5 Flash (90% dei casi)
2. **Upgrade:** Gemini 2.5 Pro (complessità alta)
3. **Specializzato:** GPT-4o-mini (solo se Gemini < 90% accuratezza)
4. **Premium:** GPT-4o (rarissimo, solo mission-critical)

**Risparmio atteso:** 50-80% sui costi AI seguendo questa gerarchia

---

**Next Steps:**
- Testa Gemini 2.5 Flash prima
- Misura accuratezza
- Passa a OpenAI solo se necessario
- Monitora cost/accuracy tradeoff
