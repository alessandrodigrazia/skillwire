# Claude Guide (SECONDARY - Long Context Focus)

## Quando Usare Claude
Usa Claude (Anthropic) quando:
- Processing documenti lunghi (>50k tokens)
- Serve ragionamento dettagliato
- Applicazioni safety-critical
- Conversational AI con profondità

**Punto di forza:** Long context (200k tokens)
**Costo:** 11-200x più costoso di Gemini 2.5 Flash
**Nota:** Gemini 2.5 Pro ha 2M tokens context (10x più di Claude)

---

## Modelli Disponibili

### claude-3-5-haiku (Veloce)
**Specifiche:**
- Costo: $0.80/1M input, $4.00/1M output
- Velocità: ~60 tokens/sec
- Context: 200k tokens

**Usa per:** Task Claude veloci con long context

**Configurazione N8N:**
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
  "parameters": {
    "model": "claude-3-5-haiku-20241022",
    "options": {
      "temperature": 0.7,
      "maxTokensToSample": 2048
    }
  },
  "credentials": {
    "anthropicApi": {
      "id": "YOUR_ANTHROPIC_CREDENTIAL_ID",
      "name": "Anthropic API"
    }
  }
}
```

---

### claude-3-5-sonnet (CONSIGLIATO per Claude)
**Specifiche:**
- Costo: $3.00/1M input, $15.00/1M output
- Velocità: ~40 tokens/sec
- Context: 200k tokens

**Usa per:**
- Analisi documenti lunghi
- Review contratti
- Spiegazioni dettagliate
- Conversazioni multi-turn

**Esempio:**
```json
{
  "parameters": {
    "model": "claude-3-5-sonnet-20241022",
    "options": {
      "temperature": 0.7,
      "maxTokensToSample": 4096
    }
  }
}
```

---

### claude-opus-4 (Massima Qualità)
**Specifiche:**
- Costo: $15/1M input, $75/1M output
- Velocità: ~30 tokens/sec
- Context: 200k tokens

**Usa per:** Solo necessità di massima qualità (raro)

**Warning:** 200x più costoso di Gemini 2.5 Flash

---

## Casi d'Uso Ottimali

### 1. Analisi Documenti Lunghi
```javascript
const prompt = `
Analizza questo contratto di 50 pagine e identifica:
1. Obblighi chiave
2. Rischi potenziali
3. Clausole inusuali
4. Raccomandazioni

Contratto: {{ $json.documentText }}
`;
```

**Modello:** claude-3-5-sonnet
**Perché Claude:** Può processare 50+ pagine in singola richiesta
**Alternativa:** Gemini 2.5 Pro (2M context, più economico)

---

### 2. Code Review Dettagliato
```javascript
const prompt = `
Rivedi questo codebase (2000 righe) e fornisci:
1. Vulnerabilità di sicurezza
2. Problemi di performance
3. Violazioni best practices
4. Suggerimenti refactoring

Codice: {{ $json.code }}
`;
```

**Modello:** claude-3-5-sonnet
**Perché Claude:** Review approfondito e dettagliato

---

### 3. Conversazione Multi-Turn con Memoria
```
User Query →
Claude Sonnet (con memoryBufferWindow) →
Response →
Store in memory →
Next query usa full context
```

**Setup con Memory:**
```json
{
  "nodes": [
    {
      "type": "@n8n/n8n-nodes-langchain.chatTrigger"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
      "name": "Claude with Memory"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
      "parameters": {
        "contextWindowLength": 10
      }
    }
  ]
}
```

---

## Confronto: Claude vs Gemini per Long Context

| Feature | Claude Sonnet | Gemini 2.5 Pro | Winner |
|---------|---------------|----------------|--------|
| Context Window | 200k tokens | 2M tokens | 🏆 Gemini (10x più) |
| Costo Input | $3/1M | ~$1.25/1M | 🏆 Gemini (58% meno) |
| Costo Output | $15/1M | ~$5/1M | 🏆 Gemini (67% meno) |
| Velocità | 40 t/s | 60 t/s | 🏆 Gemini (+50%) |
| Reasoning Style | Molto dettagliato | Bilanciato | Preferenza personale |

**Conclusione:** Per long-context tasks, **Gemini 2.5 Pro è generalmente migliore** (più context, più economico, più veloce)

**Usa Claude quando:**
- Preferisci lo stile di ragionamento di Claude
- Hai infrastruttura Anthropic esistente
- Safety/ethics particolarmente critico (Constitutional AI)

---

## Best Practices Claude

### 1. System Prompts
Claude risponde bene a system prompts chiari:

```javascript
const systemPrompt = "Sei un esperto analista legale con 20 anni di esperienza in contratti commerciali.";
const userPrompt = "Analizza questo contratto...";
```

### 2. Prompts Strutturati XML-Style
Claude performa meglio con struttura XML:

```xml
<document>
{{ $json.text }}
</document>

<instructions>
1. Riassumi il documento
2. Estrai punti chiave
3. Identifica rischi
</instructions>

<output_format>
JSON con struttura:
{
  "summary": "...",
  "key_points": [...],
  "risks": [...]
}
</output_format>
```

### 3. Chain of Thought
Incoraggia ragionamento dettagliato:

```
"Pensa step-by-step, spiegando il tuo ragionamento per ogni punto."
```

---

## Configurazione Avanzata

### Temperature per Task Type

**Analisi Documenti:**
```json
{"temperature": 0.5}
```

**Contenuto Creativo:**
```json
{"temperature": 0.8}
```

**Reasoning Complesso:**
```json
{"temperature": 0.7}
```

### Max Tokens
```json
{
  "maxTokensToSample": 1024,  // Risposte brevi
  "maxTokensToSample": 4096,  // Analisi standard
  "maxTokensToSample": 8192   // Output dettagliato
}
```

---

## Pattern di Integrazione

### Pattern 1: Claude per Deep Analysis
```
Trigger (nuovo documento) →
Extract text →
Claude Sonnet (analisi profonda) →
Structured output →
Database storage →
Alert se rischi trovati
```

### Pattern 2: Gemini → Claude Review
```
Gemini 2.5 Flash (draft veloce) →
Claude Sonnet (review e refine) →
Final output
```

**Use case:** Content creation + quality assurance

### Pattern 3: Long Document Pipeline
```
Upload documento (200 pagine) →
Split in chunks (20k tokens each) →
Parallel Claude processing →
Merge e summarize →
Final report
```

---

## Costi Comparativi

### Scenario: Analisi 100 Contratti (50k tokens ciascuno)

| Modello | Input (5M tokens) | Output (1M tokens) | Totale |
|---------|-------------------|-------------------|--------|
| **Gemini 2.5 Pro** | $6.25 | $5.00 | **$11.25** |
| **Claude Sonnet** | $15.00 | $15.00 | **$30.00** |
| **Claude Opus** | $75.00 | $75.00 | **$150.00** |

**Savings Gemini:** 63% vs Claude Sonnet, 92% vs Claude Opus

---

## Quando NON Usare Claude

❌ **Evita Claude per:**
- Contenuti brevi (< 10k tokens) → Usa Gemini 2.5 Flash
- Alto volume processing → Troppo costoso
- Categorizzazione semplice → Overkill
- Vision tasks → Gemini 2.5 Pro migliore
- Budget limitato → Gemini più cost-effective

✅ **Usa Claude solo quando:**
- Stile di reasoning di Claude preferito
- Infrastruttura Anthropic esistente
- Safety/ethics massima priorità
- Gemini non disponibile/accettabile

---

## Constitutional AI (Safety)

Claude è costruito con **Constitutional AI** - ottimo per:
- Healthcare applications
- Legal document processing
- Content moderation
- Educational content
- HR/sensitive data

**Esempio Safety-Critical:**
```javascript
const prompt = `
Analizza questo feedback dei pazienti e identifica:
- Reclami medici seri
- Problemi di sicurezza
- Questioni privacy

IMPORTANTE: Segnala QUALSIASI potenziale rischio per la sicurezza.

Feedback: {{ $json.patientFeedback }}
`;
```

**Modello:** claude-3-5-sonnet
**Perché:** Constitutional AI per safety

---

## Multi-Turn Conversation Example

### Setup Chatbot con Memoria
```json
{
  "workflow": {
    "nodes": [
      {
        "type": "@n8n/n8n-nodes-langchain.chatTrigger",
        "name": "Chat Interface"
      },
      {
        "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
        "name": "Claude Sonnet",
        "parameters": {
          "model": "claude-3-5-sonnet-20241022"
        }
      },
      {
        "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
        "name": "Conversation Memory",
        "parameters": {
          "contextWindowLength": 5
        }
      },
      {
        "type": "@n8n/n8n-nodes-langchain.chainConversation",
        "name": "Conversation Chain"
      }
    ]
  }
}
```

**Beneficio:** Claude mantiene contesto conversazione profondo

---

## Limitazioni da Considerare

### 1. Context Window vs Gemini
- Claude: 200k tokens
- Gemini 2.5 Pro: 2M tokens (10x superiore)

**Implicazione:** Gemini può processare documenti molto più lunghi

### 2. Velocità
- Claude Sonnet: ~40 t/s
- Gemini 2.5 Pro: ~60 t/s

**Implicazione:** Gemini 50% più veloce

### 3. Costi
- Claude: 2.4x più costoso di Gemini 2.5 Pro
- Claude Opus: 12x più costoso

---

## Decision Framework

### Usa Claude quando:
```javascript
if (task.requiresConstitutionalAI ||
    team.prefersClaudeStyle ||
    existing.infrastructure === "Anthropic") {
  return "claude-3-5-sonnet";
}

// Altrimenti, default a Gemini
return "gemini-2.5-pro";
```

### Flowchart Decisionale
```
Need long document processing?
├─ Yes → Context needed?
│   ├─ >200k tokens → Gemini 2.5 Pro (2M context)
│   └─ <200k tokens → Claude Sonnet OK
└─ No → Gemini 2.5 Flash (default)
```

---

## Template Workflow Claude

### Document Analysis
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.webhook",
      "name": "Document Upload"
    },
    {
      "type": "n8n-nodes-base.extractFromFile",
      "name": "Extract Text"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
      "name": "Claude Analysis",
      "parameters": {
        "model": "claude-3-5-sonnet-20241022",
        "options": {
          "temperature": 0.6
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.chainLlm",
      "name": "Analyze Document"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "name": "Structure Output"
    },
    {
      "type": "n8n-nodes-base.airtable",
      "name": "Save Analysis"
    }
  ]
}
```

---

## Monitoring & Optimization

### Metriche
- **Quality score** (vs Gemini)
- **Processing time** (per document)
- **Cost per analysis**
- **Error rate**

### A/B Testing
```
Test 100 documenti:
- 50 con Claude Sonnet
- 50 con Gemini 2.5 Pro

Compare:
- Qualità output
- Tempo processing
- Costo totale
```

**Risultato atteso:** Gemini vince su costo/velocità, Claude su stile

---

## Errori Comuni

### ❌ Errore 1: Usare Claude per task semplici
**Problema:** 8x più costoso di Gemini per stessi risultati

**Soluzione:** Claude solo per long/complex documents

### ❌ Errore 2: Non sfruttare long context
**Problema:** Paghi per 200k context ma usi solo 10k

**Soluzione:** Se < 50k tokens, considera Gemini

### ❌ Errore 3: Prompts non strutturati
**Problema:** Claude performa meglio con struttura

**Soluzione:** Usa tags XML per chiarezza

---

## Integrazione con N8N Tools

### Claude + Tool Workflow
```json
{
  "type": "@n8n/n8n-nodes-langchain.agent",
  "parameters": {
    "model": "claude-3-5-sonnet"
  }
}
```

**Tools:**
- `toolWorkflow` (chiama altri workflow)
- `toolHttpRequest` (API calls)
- Custom tools

**Nota:** OpenAI generalmente migliore per function calling

---

## Conclusione: Claude vs Gemini

### Scegli Claude se:
✅ Stile reasoning dettagliato preferito
✅ Constitutional AI necessario (safety)
✅ Team già usa Anthropic
✅ Budget non è vincolo primario

### Scegli Gemini 2.5 Pro se:
✅ Need context >200k tokens (fino a 2M)
✅ Budget-conscious (63% risparmio)
✅ Velocità importante (+50%)
✅ Long documents + vision

---

## Raccomandazione Finale

**Per la maggior parte dei use case long-context:**
```
Default: Gemini 2.5 Pro
- Più economico (63%)
- Più veloce (50%)
- Context 10x superiore (2M vs 200k)

Alternative: Claude Sonnet
- Solo se preferenza stile
- O infrastruttura esistente
- O Constitutional AI critical
```

**Strategia ottimale:**
1. Prova Gemini 2.5 Pro first
2. Se qualità insufficiente → Test Claude
3. Compare cost/quality tradeoff
4. Scegli in base a risultati

**Risparmio atteso:** 60-90% usando Gemini come default
