# N8N Workflow Patterns

## Introduction
This document catalogs proven workflow patterns extracted from 2056+ community workflows, with special focus on the 1083 AI-powered workflows.

## Pattern Categories

### 1. Content Automation Patterns
### 2. Data Processing Patterns
### 3. Communication Automation Patterns
### 4. Document Management Patterns
### 5. AI-Powered Analysis Patterns
### 6. Integration Patterns
### 7. Monitoring & Alert Patterns

---

## 1. Content Automation Patterns

### Pattern 1.1: Article to Social Post
**Use Case:** Convert articles/newsletters to social media posts

**Flow:**
```
Email/RSS Trigger →
Content Extraction →
AI Categorization →
AI Content Generation →
Database Storage (Airtable) →
Social Publishing (LinkedIn)
```

**Nodes:**
1. **Gmail** (getAll with label filter) OR **RSS Feed Read**
2. **Code** (extract oldest/filter)
3. **lmChatGoogleGemini** (categorize content)
4. **lmChatGoogleGemini** (generate post)
5. **Airtable** (create record)
6. **LinkedIn** (create post)

**Key Features:**
- Deduplication via Airtable search
- Timezone-aware scheduling
- Status tracking (Todo/In Progress/Done)
- Post history logging

**Example from library:**
- `01. Articolo → Post LinkedIn (powered by Gemini).json`

---

### Pattern 1.2: Video to Social Post
**Use Case:** Monitor YouTube playlist and create social posts for new videos

**Flow:**
```
Schedule Trigger (2h) →
Timezone Check (8-20h) →
YouTube Playlist Fetch →
Data Normalization →
Airtable Dedup Check →
AI Post Generation →
LinkedIn Publishing →
Playlist Cleanup
```

**Nodes:**
1. **Schedule Trigger** (interval-based)
2. **Code** (timezone validation)
3. **Set** (configuration variables)
4. **YouTube** (getAll playlistItems)
5. **Code** (normalize video data)
6. **Filter** (validate VideoID/PlaylistItemID)
7. **Split in Batches** (process one at a time)
8. **Airtable** (search for existing)
9. **IF** (new vs existing)
10. **lmChatGoogleGemini** (generate content)
11. **LinkedIn** (publish)
12. **YouTube** (delete from playlist)
13. **Airtable** (create/update record)

**Key Features:**
- Batch processing (1 video at a time)
- Working hours filtering
- Automatic playlist cleanup
- Complete audit trail

**Example from library:**
- `02. Video → Post LinkedIn (powered by Gemini).json`

---

### Pattern 1.3: RSS Feed Aggregation
**Use Case:** Curate content from RSS feeds with AI-powered selection

**Flow:**
```
Schedule Trigger →
RSS Feed Read (multiple sources) →
Content Filtering →
AI Relevance Scoring →
Top Content Selection →
AI Summary Generation →
Newsletter/Post Creation →
Distribution
```

**Nodes:**
1. **Schedule Trigger** (daily/weekly)
2. **RSS Feed Read** (multiple in parallel)
3. **Merge** (combine feeds)
4. **Code** (deduplicate)
5. **lmChatGoogleGemini** (score relevance)
6. **Filter** (threshold-based selection)
7. **lmChatGoogleGemini** (generate summary)
8. **Airtable/Google Sheets** (log)
9. **Gmail/Mailchimp** (send newsletter)

**Example from library:**
- `03. RSS Feed → Post LinkedIn (powered by Gemini).json`

---

## 2. Data Processing Patterns

### Pattern 2.1: Batch Processing with Loop
**Use Case:** Process large datasets item by item

**Flow:**
```
Trigger →
Data Source →
Split in Batches →
Process Item →
Conditional Check →
Update/Create →
Loop Continue/Exit
```

**Implementation:**
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.splitInBatches",
      "parameters": {
        "batchSize": 1,
        "options": {}
      }
    }
  ]
}
```

**Best Practices:**
- Use batchSize: 1 for sequential processing
- Implement error handling per item
- Add progress tracking
- Include timeout management

---

### Pattern 2.2: Data Enrichment Pipeline
**Use Case:** Enhance data with multiple sources

**Flow:**
```
Input Data →
Primary Enrichment (API 1) →
Secondary Enrichment (API 2) →
AI Enhancement →
Data Validation →
Storage/Export
```

**Nodes:**
1. **Trigger** (Webhook/Schedule/Manual)
2. **HTTP Request** (API enrichment 1)
3. **Merge** (combine original + enriched)
4. **HTTP Request** (API enrichment 2)
5. **lmChatGoogleGemini** (AI enhancement)
6. **Code** (data validation)
7. **Airtable/Sheets** (storage)

---

### Pattern 2.3: Deduplication Strategy
**Use Case:** Prevent duplicate processing

**Implementation:**
```
Input Items →
Database Search (by unique key) →
IF (exists) →
  TRUE: Skip or Update
  FALSE: Create New
```

**Example Code:**
```json
{
  "type": "n8n-nodes-base.airtable",
  "parameters": {
    "operation": "search",
    "filterByFormula": "LOWER({VideoID}) = LOWER(\"{{ $json.VideoID }}\")",
    "limit": 1
  }
}
```

---

## 3. Communication Automation Patterns

### Pattern 3.1: Smart Email Classification
**Use Case:** Auto-classify and route emails

**Flow:**
```
Email Trigger →
AI Classification →
Entity Extraction →
Route by Category →
  - Urgent: Immediate notification
  - Normal: Queue for review
  - Spam: Archive
Database Logging
```

**Nodes:**
1. **Gmail/Outlook** (trigger on new email)
2. **lmChatGoogleGemini** (classify: urgent/normal/spam)
3. **outputParserStructured** (extract: category, priority, entities)
4. **Switch** (route by category)
5. **Slack/Teams** (urgent notification)
6. **Airtable** (log all emails)
7. **Gmail/Outlook** (apply labels/move)

---

### Pattern 3.2: Auto-Response with Context
**Use Case:** Generate context-aware email responses

**Flow:**
```
Email Trigger →
Context Gathering (previous emails, CRM) →
AI Response Generation →
Human Review (optional) →
Send Reply →
Log Interaction
```

**Nodes:**
1. **Gmail/Outlook** (new email)
2. **Code** (extract sender, thread ID)
3. **Airtable/CRM** (fetch contact history)
4. **Gmail/Outlook** (get thread messages)
5. **lmChatGoogleGemini** (generate response)
6. **IF** (auto-send vs review)
7. **Gmail/Outlook** (send reply)
8. **Airtable** (log interaction)

---

### Pattern 3.3: Multi-Channel Notification
**Use Case:** Send notifications across multiple platforms

**Flow:**
```
Event Trigger →
Message Formatting →
Parallel Distribution:
  - Email
  - Slack
  - Teams
  - SMS
Status Tracking
```

**Implementation:**
Use parallel branches from single trigger:
```
Trigger → Set (format message) →
  ├→ Gmail
  ├→ Slack
  ├→ Teams
  └→ Twilio (SMS)
```

---

## 4. Document Management Patterns

### Pattern 4.1: Document Analysis Pipeline
**Use Case:** Extract insights from documents

**Flow:**
```
Document Upload (Drive/OneDrive) →
File Type Detection →
Content Extraction →
AI Analysis →
Structured Data Extraction →
Database Storage →
Summary Distribution
```

**Nodes:**
1. **Google Drive/OneDrive** (new file trigger)
2. **Code** (detect file type)
3. **Extract from File** (PDF/Word/Excel)
4. **lmChatGoogleGemini** (analyze content)
5. **outputParserStructured** (extract structured data)
6. **Airtable/Sheets** (store results)
7. **Gmail/Slack** (send summary)

---

### Pattern 4.2: Automated Report Generation
**Use Case:** Generate periodic reports from data

**Flow:**
```
Schedule Trigger →
Data Collection (multiple sources) →
Data Aggregation →
AI Insights Generation →
Document Creation (Docs/Word) →
Distribution →
Archival
```

**Nodes:**
1. **Schedule Trigger** (weekly/monthly)
2. **Airtable/Sheets/Database** (fetch data)
3. **Code** (aggregate and calculate)
4. **lmChatGoogleGemini** (generate insights)
5. **Google Docs/Word** (create document)
6. **Gmail/Outlook** (send report)
7. **Google Drive/OneDrive** (archive)

---

### Pattern 4.3: Contract/Document Review
**Use Case:** AI-assisted document review

**Flow:**
```
Document Upload →
AI Analysis (risks, terms, obligations) →
Structured Extraction →
Comparison (with template/standards) →
Alert Generation (anomalies) →
Review Dashboard Update
```

**Nodes:**
1. **Webhook/Drive** (document upload)
2. **Extract from File**
3. **chainLlm** (analyze document)
4. **outputParserStructured** (extract key terms)
5. **Code** (compare with standards)
6. **IF** (flag anomalies)
7. **Slack/Email** (alert reviewers)
8. **Airtable** (update dashboard)

---

## 5. AI-Powered Analysis Patterns

### Pattern 5.1: Sentiment Analysis Pipeline
**Use Case:** Monitor brand sentiment from feedback/reviews

**Flow:**
```
Trigger (Reviews/Social/Emails) →
Text Preprocessing →
AI Sentiment Analysis →
Entity Recognition →
Categorization →
Alert on Negative →
Dashboard Update
```

**Nodes:**
1. **Trigger** (API/Webhook/Email)
2. **Code** (clean text)
3. **lmChatGoogleGemini** (sentiment analysis)
4. **outputParserStructured** (extract: sentiment, score, entities)
5. **Filter** (negative sentiment)
6. **Slack/Email** (alert team)
7. **Airtable/Sheets** (dashboard)

---

### Pattern 5.2: Content Categorization at Scale
**Use Case:** Auto-categorize large volumes of content

**Flow:**
```
Content Stream →
Batch Processing →
AI Categorization →
Confidence Scoring →
High Confidence: Auto-categorize
Low Confidence: Human Review
Tagging & Storage
```

**Nodes:**
1. **RSS/API/Webhook** (content source)
2. **Split in Batches** (process in chunks)
3. **lmChatGoogleGemini** (categorize)
4. **outputParserStructured** (category + confidence)
5. **IF** (confidence threshold)
6. **Airtable** (auto-categorize or flag for review)
7. **Loop Back** (next batch)

---

### Pattern 5.3: Multi-Language Translation Pipeline
**Use Case:** Translate content across languages

**Flow:**
```
Source Content →
Language Detection →
Translation (AI) →
Quality Check →
Multi-Platform Publishing
```

**Nodes:**
1. **Trigger** (new content)
2. **lmChatGoogleGemini** (detect language)
3. **lmChatGoogleGemini** (translate to target languages)
4. **Code** (format for each platform)
5. **Parallel Publishing:**
   - LinkedIn (EN)
   - LinkedIn (IT)
   - Twitter (EN)
   - etc.

---

## 6. Integration Patterns

### Pattern 6.1: Bi-Directional Sync
**Use Case:** Keep two systems in sync

**Flow:**
```
System A Trigger →
Transform Data →
Update System B →
Webhook Back →
Update System A (avoid loop)
```

**Key Considerations:**
- Prevent infinite loops (use status flags)
- Handle conflicts (last-write-wins or manual review)
- Implement retry logic
- Log all sync operations

---

### Pattern 6.2: Event-Driven Architecture
**Use Case:** Decouple systems via events

**Flow:**
```
Event Source →
Webhook Receiver →
Event Router (Switch) →
  - Event Type 1: Handler A
  - Event Type 2: Handler B
  - Event Type 3: Handler C
Response/Acknowledgment
```

**Implementation:**
```json
{
  "type": "n8n-nodes-base.switch",
  "parameters": {
    "rules": {
      "rules": [
        {
          "conditions": {
            "conditions": [
              {
                "leftValue": "={{ $json.event_type }}",
                "operator": "equals",
                "rightValue": "order.created"
              }
            ]
          },
          "renameOutput": "Order Created"
        }
      ]
    }
  }
}
```

---

### Pattern 6.3: API Gateway Pattern
**Use Case:** Single endpoint for multiple backends

**Flow:**
```
Webhook Trigger →
Authentication Check →
Rate Limiting →
Request Router →
  - Service A
  - Service B
  - Service C
Response Aggregation →
Return to Client
```

**Nodes:**
1. **Webhook** (public endpoint)
2. **Code** (validate API key/JWT)
3. **Code** (rate limit check)
4. **Switch** (route by path/method)
5. **HTTP Request** (call service)
6. **Merge** (if multiple services)
7. **Respond to Webhook**

---

## 7. Monitoring & Alert Patterns

### Pattern 7.1: Health Check Monitor
**Use Case:** Monitor service availability

**Flow:**
```
Schedule Trigger (5min) →
Parallel Health Checks:
  - API 1
  - API 2
  - Database
  - Service N
Status Evaluation →
IF (failure detected) →
  Alert Team →
  Create Incident
Log Results
```

**Nodes:**
1. **Schedule Trigger** (`*/5 * * * *`)
2. **Set** (list of endpoints)
3. **Split Out** (create items)
4. **HTTP Request** (health check)
5. **Merge** (collect results)
6. **Code** (evaluate status)
7. **IF** (any failures)
8. **Slack/PagerDuty** (alert)
9. **Database** (log results)

---

### Pattern 7.2: Anomaly Detection
**Use Case:** Detect unusual patterns in data

**Flow:**
```
Schedule Trigger →
Fetch Recent Data →
Calculate Metrics →
AI Anomaly Detection →
IF (anomaly detected) →
  Alert + Context
Historical Logging
```

**Nodes:**
1. **Schedule Trigger** (hourly)
2. **Database** (fetch last N hours)
3. **Code** (calculate: avg, stddev, percentiles)
4. **lmChatGoogleGemini** (analyze for anomalies)
5. **outputParserStructured** (extract: is_anomaly, confidence, reason)
6. **IF** (is_anomaly === true)
7. **Slack** (alert with chart)
8. **Database** (log for trend analysis)

---

### Pattern 7.3: SLA Monitoring
**Use Case:** Track and alert on SLA violations

**Flow:**
```
Event Trigger (ticket created) →
Calculate SLA Deadline →
Store in Database →
Periodic Check (every hour):
  - Check Approaching SLAs →
  - Alert at 80% →
  - Escalate at 100%
Resolution: Update Status
```

**Implementation:**
Two workflows:
1. **SLA Tracker** (on ticket create)
2. **SLA Monitor** (scheduled checks)

---

## Advanced Patterns

### Pattern 8.1: Human-in-the-Loop AI
**Use Case:** AI processing with human approval

**Flow:**
```
Trigger →
AI Processing →
Store Result (pending) →
Send for Review (Email/Slack) →
Webhook for Approval →
IF (approved):
  Execute Action
ELSE:
  Reject + Feedback
Update Training Data
```

**Nodes:**
1. **Trigger**
2. **lmChatGoogleGemini** (generate output)
3. **Airtable** (store as "pending")
4. **Gmail** (send for review with approve/reject links)
5. **Webhook** (capture response)
6. **IF** (approved)
7. **Execute Action**
8. **Airtable** (update status + feedback)

---

### Pattern 8.2: Progressive Enrichment
**Use Case:** Enrich data progressively as it flows

**Flow:**
```
Raw Data →
Stage 1: Basic Info (fast) →
Stage 2: Detailed Info (medium) →
Stage 3: AI Insights (slow) →
Each stage updates database →
Final status: complete
```

**Benefits:**
- Users see partial results quickly
- Expensive operations run last
- Can stop at any stage
- Resilient to failures

---

### Pattern 8.3: Circuit Breaker
**Use Case:** Prevent cascading failures

**Flow:**
```
API Call →
Track Success/Failure →
IF (failure rate > threshold):
  Open Circuit (stop calls)
  Return cached/default response
Periodic Retry:
  Test if service recovered →
  Close circuit if successful
```

**Implementation:**
Use Redis to track:
- Failure count
- Circuit status (open/closed/half-open)
- Last failure time

---

## Pattern Selection Guide

### Choose by Use Case

| Use Case | Recommended Pattern | Key Nodes |
|----------|-------------------|-----------|
| Social Media Automation | 1.1, 1.2, 1.3 | Gmail, Gemini, LinkedIn, Airtable |
| Email Management | 3.1, 3.2 | Gmail, Gemini, Airtable, Slack |
| Document Processing | 4.1, 4.2, 4.3 | Extract from File, Gemini, Docs |
| Data Analysis | 5.1, 5.2 | Gemini, outputParserStructured |
| System Integration | 6.1, 6.2, 6.3 | Webhook, HTTP Request, Switch |
| Monitoring | 7.1, 7.2, 7.3 | Schedule, Code, Slack |

### Choose by Trigger Type

| Trigger | Best For | Patterns |
|---------|----------|----------|
| Schedule | Periodic tasks, reports, monitoring | 1.3, 2.1, 4.2, 7.1-7.3 |
| Webhook | Real-time integrations, APIs | 6.1-6.3, 8.1 |
| Email | Email automation, notifications | 1.1, 3.1, 3.2 |
| File | Document processing | 4.1, 4.3 |
| Chat | AI assistants, chatbots | 8.1 |

### Choose by Complexity

| Complexity | Pattern Examples | Node Count |
|------------|-----------------|------------|
| Simple | Email to Slack notification | 3-5 |
| Medium | Article to social post | 8-12 |
| Complex | Video processing pipeline | 15-25 |
| Advanced | Multi-stage enrichment | 25+ |

---

## Common Anti-Patterns (Avoid)

### ❌ Anti-Pattern 1: Infinite Loops
**Problem:** Workflow triggers itself endlessly

**Solution:**
- Add status flags
- Use deduplication
- Implement circuit breakers

### ❌ Anti-Pattern 2: Monolithic Workflows
**Problem:** Single workflow does everything (100+ nodes)

**Solution:**
- Split into sub-workflows
- Use Execute Workflow node
- Modular design

### ❌ Anti-Pattern 3: Missing Error Handling
**Problem:** Workflow fails completely on any error

**Solution:**
- Use Error Trigger nodes
- Implement try/catch patterns
- Add fallback logic

### ❌ Anti-Pattern 4: Hardcoded Credentials
**Problem:** API keys in Code nodes

**Solution:**
- Use Credentials system
- Environment variables
- Secret management

### ❌ Anti-Pattern 5: No Deduplication
**Problem:** Processing same item multiple times

**Solution:**
- Database lookup before processing
- Use unique IDs
- Implement idempotency

---

## Pattern Combination Examples

### Example 1: Content Curation System
**Combines:** 1.3 (RSS) + 5.2 (Categorization) + 4.2 (Report)

```
RSS Feeds (5 sources) →
Merge & Deduplicate →
AI Categorization →
AI Relevance Scoring →
Top 10 Selection →
Weekly Report Generation →
Email Distribution
```

### Example 2: Customer Support Automation
**Combines:** 3.1 (Email Classification) + 3.2 (Auto-Response) + 7.3 (SLA)

```
Support Email →
AI Classification →
Route by Category →
Auto-Response (FAQ) OR Human Queue →
SLA Tracking →
Escalation if Needed →
Resolution Logging
```

### Example 3: Social Media Command Center
**Combines:** 1.1 + 1.2 + 6.2 (Event Router)

```
Multiple Content Sources:
  - Gmail (articles)
  - YouTube (videos)
  - RSS (news)
Event Router (by source type) →
Content-Specific Processing →
AI Content Generation →
Unified Airtable Database →
Multi-Platform Publishing:
  - LinkedIn
  - Twitter
  - Facebook
Analytics Tracking
```

---

**Next Steps:**
Explore specific implementations in:
- `/references/use-cases/` for detailed examples
- `/assets/templates/` for ready-to-use workflows
- `/references/ai-nodes/` for AI node documentation
