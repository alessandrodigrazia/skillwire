# Advanced Guide: Sub-workflows and Modularity

## 1. Description

A **Sub-workflow** is a standalone n8n workflow that can be executed by another workflow (called the "parent"). This concept is analogous to a **function** or a **subroutine** in traditional programming. It allows you to encapsulate specific, reusable logic in a single place, drastically improving the organization, maintainability, and readability of your automation projects.

Instead of having a single, monolithic 100-node workflow, you can split it into a main workflow that orchestrates operations by calling several specialized sub-workflows.

## 2. Key Components

To implement this pattern, two specific nodes are needed:

1.  **`Execute Workflow Trigger`:** This node must be the **trigger** of your sub-workflow. It defines that the workflow is designed to be called by another and specifies its input parameters.

2.  **`Execute Workflow`:** This node is used in the **parent** workflow to call the sub-workflow. From here you select which sub-workflow to execute and pass the necessary input data.

## 3. Data Flow: Call and Return

The process is similar to a function call:

1.  **Call:** The parent workflow reaches an `Execute Workflow` node. The parent's execution **stops** and waits.
2.  **Data Passing:** The data configured in the `Execute Workflow` node is sent as input to the `Execute Workflow Trigger` node of the sub-workflow.
3.  **Execution:** The sub-workflow runs from start to finish, performing its logic.
4.  **Return:** At the end of its execution, the sub-workflow must return a result. This is typically done with a `Respond to Webhook` node that sends data to a special URL provided by the trigger.
5.  **Resume:** The parent workflow receives the return data from the sub-workflow in the output of the `Execute Workflow` node and resumes its execution.

## 4. JSON Configuration Example

**A) `Execute Workflow` Node (in the Parent workflow):**
```json
{
  "parameters": {
    "workflowId": "SUB_WORKFLOW_ID",
    "source": "data",
    "data": "={{ { \"email\": $json.customerEmail } }}"
  },
  "name": "Call: Enrich Email",
  "type": "n8n-nodes-base.executeWorkflow",
  "typeVersion": 1,
  "position": [123, 456]
}
```

**B) `Execute Workflow Trigger` Node (in the Sub-workflow):**
```json
{
  "parameters": {},
  "name": "Start (on call)",
  "type": "n8n-nodes-base.executeWorkflowTrigger",
  "typeVersion": 1,
  "position": [-200, 0]
}
```

## 5. Practical Use Case (Pattern: Logic Abstraction)

**Objective:** Create a reusable "function" to enrich an email with data from an external service, to be used across multiple workflows.

**Sub-workflow: `"Enrich-Email"`**
1.  **Trigger (`Execute Workflow Trigger`):** Expects to receive an input with an `email` field.
2.  **HTTP Request:** Calls an API (e.g., Clearbit) passing the received email to obtain the company name, industry, etc.
3.  **Set:** Formats the received data into a clean JSON object.
4.  **Respond to Webhook:** Returns the JSON object with the enriched data to the calling workflow.

**Parent Workflow (e.g., `"New Lead from Form"`)**
1.  **Webhook:** Receives data from a new lead, including their email.
2.  **Execute Workflow (This Node):** Calls the sub-workflow `"Enrich-Email"`, passing it the lead's email.
3.  **Airtable:** The node receives the enriched data as output from the sub-workflow and uses it to create a complete record in the CRM.

In this way, if the enrichment service changes in the future, you only need to modify the sub-workflow, and all workflows that use it will automatically benefit from the update.

## 6. Best Practices & Tips

*   **DRY (Don't Repeat Yourself):** If you find yourself copy-pasting the same sequence of 3 or more nodes across different workflows, that is the signal that the logic should be extracted into a sub-workflow.
*   **Improve Maintainability:** Centralizing logic (e.g., sending a formatted notification on Teams) in a sub-workflow makes maintenance incredibly simpler. If you need to change the notification format, you modify a single workflow instead of ten.
*   **Abstraction and Readability:** Sub-workflows hide complexity. A parent workflow can become a simple sequence of sub-workflow calls (e.g., `Read Data` -> `Enrich Data` -> `Generate Report` -> `Send Notification`), making it much easier to read and understand at a glance.
*   **Isolated Testing:** It is much easier to test a sub-workflow that performs a single specific action than a huge monolithic workflow. You can test each "function" in isolation before orchestrating them together.
*   **Use Clear Names:** Give your sub-workflows names that clearly describe what they do (e.g., `utility-SendWelcomeEmail`, `process-AnalyzeInvoicePdf`), so you can find and reuse them easily.
