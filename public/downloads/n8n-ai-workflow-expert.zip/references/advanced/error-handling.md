# Advanced Guide: Error Handling

## 1. Why Error Handling is Fundamental

A workflow in production cannot afford to fail silently. Robust error handling is what distinguishes an amateur automation from an enterprise-grade one. It allows the system to react to unexpected problems (e.g., an unavailable API, data in an incorrect format), notify about errors, and, in some cases, attempt automatic recovery. This guide, based on best practices, illustrates how to implement these strategies in n8n.

## 2. Built-in n8n Mechanisms

n8n offers powerful native tools for error handling.

### a) Error Workflow

This is the most powerful and recommended strategy. You can designate a separate workflow (an "Error Workflow") that is executed **automatically** every time your main workflow fails.

*   **How it works:** In the main workflow settings, under "Error Workflow", you select the workflow you created for error handling.
*   **What it receives:** The Error Workflow receives a special input containing all information about the error: the name of the failed workflow, the node that caused the error, the error message, and the data being processed at that time.
*   **What to do in the Error Workflow:** Typically, an Error Workflow performs these actions:
    1.  **Format a Message:** A `Set` node creates a clear notification message.
    2.  **Notify the Team:** A `Teams` or `Outlook` node sends the alert to a channel or an administrator, including all error details for quick debugging.
    3.  **Log the Error:** An `Airtable` or `Google Sheets` node logs the error in a database for future analysis.

### b) Continue on Fail

This is an option available in the **settings of almost every node**.

*   **How it works:** If enabled, it tells n8n not to block the entire workflow if *that specific node* fails. Execution will continue, but the failed node will produce no output.
*   **When to use it:** It is perfect for non-critical operations. Example: in a workflow that enriches customer data, a call to a secondary API to find the company logo can fail. By enabling "Continue on Fail", the workflow will continue to work with the main data, even if the logo was not found.

### c) Retry on Fail

This is also an option in the node settings.

*   **How it works:** If a node fails, n8n will automatically attempt to execute it again for a specified number of times, waiting a time interval between each attempt.
*   **When to use it:** It is the ideal solution for temporary and unpredictable errors, such as a momentary network issue or an API responding with a 503 (Service Unavailable) error. Setting 2-3 attempts with an interval of a few seconds can automatically resolve most of these transient issues.

## 3. Practical Implementation Strategies

### a) Simulating a `try/catch` Block with the `Code` Node

For risky operations within a single node, such as parsing a potentially malformed JSON, you can use a `try/catch` block in the `Code` node.

```javascript
// Error handling example in the Code node
try {
  // Risky operation
  const data = JSON.parse($json.body.potentiallyInvalidJson);
  return [{ json: { success: true, parsedData: data } }];
} catch (error) {
  // If parsing fails, do not block the workflow.
  // Instead, produce an output that signals the error.
  return [{ json: { success: false, error: error.message } }];
}
```

### b) Conditional Routing with the `If` Node

After a node that might fail (like an `HttpRequest` or the `Code` node from the previous example), you can use an `If` node to check a success flag.

*   **`If` Node Condition:** `{{ $json.success }}` is `true`.
*   **`true` Branch:** The workflow continues with normal processing.
*   **`false` Branch:** The workflow follows an error handling path (e.g., sends a specific notification and stops).

## 4. Best Practices

*   **Always Use an Error Workflow:** For any workflow in production, always set up an Error Workflow. It is your main safety net.
*   **Anticipate Failure Points:** When building a workflow, ask yourself: "What happens if this node fails?". The most common candidates are calls to external APIs (`HttpRequest`), data processing (`Code`), and authentication.
*   **`Retry on Fail` for Network Instability:** Always enable this option for calls to external services. It will automatically resolve a surprising amount of errors on its own.
*   **`Continue on Fail` for Non-Essential Data:** Use it for "enrichment" steps that, if they fail, do not compromise the final result of the workflow.
*   **Useful Error Messages:** When sending an error notification, do not just say "Workflow failed". Always include the workflow name, the node name, the error message, and, if possible, the input data that caused the problem. This will make debugging 10 times faster.
