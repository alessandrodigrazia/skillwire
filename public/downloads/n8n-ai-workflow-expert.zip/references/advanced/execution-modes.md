# Advanced Guide: Workflow Execution Modes

## 1. Introduction

n8n offers different "execution modes" for workflows. Choosing the correct mode is a crucial architectural decision that directly impacts the **stability, performance, and scalability** of your n8n instance. This guide illustrates the differences and provides recommendations for development and production environments.

## 2. Main Execution Modes

### a) `regular` Mode (Default)

This is the default mode with which n8n runs.

*   **How it Works:** Every workflow execution is handled directly by the main n8n process. This means that the user interface, the API, and workflow execution all share the same CPU and memory resources.

*   **Advantages:**
    *   **Simplicity:** Requires no additional configuration.

*   **Disadvantages:**
    *   **Lack of Isolation:** A single workflow that consumes too many resources (e.g., an infinite loop, processing a huge file) can slow down or block the entire n8n instance, making even the user interface unresponsive.
    *   **Limited Scalability:** Not suitable for handling a high volume of concurrent executions.

*   **When to Use It:** It is the perfect mode for **development**, **testing**, and for personal instances with a limited number of non-critical workflows.

### b) `queue` Mode (Recommended for Production)

This is the mode designed for serious production environments.

*   **How it Works:** When a workflow needs to be executed, it is not executed immediately by the main process. Instead, it is added to a **message queue** (managed by an external system like Redis). One or more separate "worker" processes listen to this queue, pick up executions, and process them in isolation.

*   **Advantages:**
    *   **Stability and Reliability:** The main process remains always responsive and protected. A workflow that crashes in a worker will not affect other workflows or the main interface in the slightest.
    *   **Resource Isolation:** Each execution happens in a separate process, ensuring better memory and CPU isolation.
    *   **Scalability:** This is the foundation for horizontal scaling. You can start multiple machines with worker processes all drawing from the same queue, allowing you to process thousands of executions in parallel.

*   **Disadvantages:**
    *   **Configuration Complexity:** Requires additional infrastructure (a Redis server) and the configuration of specific environment variables.

*   **When to Use It:** It is **strongly recommended for any production environment**, even with moderate traffic. It is a non-negotiable requirement for critical or high-volume applications.

## 3. How to Configure It

The execution mode is not a setting found within a workflow, but an instance-level configuration for the entire n8n instance, managed through **environment variables**.

To activate `queue` mode, you need to set the following environment variables before starting n8n (typically in a `docker-compose.yml` file):

```yaml
# Configuration example for docker-compose
services:
  n8n:
    environment:
      - EXECUTIONS_MODE=queue
      - QUEUE_BULL_REDIS_HOST=redis # Redis service name
      - QUEUE_BULL_REDIS_PORT=6379
      - QUEUE_BULL_REDIS_PASSWORD=your-redis-password

  redis:
    image: redis:alpine
    command: ["redis-server", "--save", "60", "1", "--loglevel", "warning", "--requirepass", "your-redis-password"]
```

## 4. Final Recommendations

*   **Development and Testing:** Start and work in `regular` mode for its immediacy.
*   **Production:** Before putting any workflow of even moderate importance into production, plan the migration of your n8n instance to `queue` mode. This will save you from countless stability and performance issues in the future.
*   **Webhook:** Workflows triggered by webhooks also benefit enormously from `queue` mode. The main process receives the webhook call, instantly adds it to the queue, and responds immediately to the caller, while a worker processes it in the background. This avoids timeouts and ensures that no call is lost.
