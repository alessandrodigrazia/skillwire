# Node: Default Document Loader (`@n8n/n8n-nodes-langchain.documentDefaultDataLoader`)

## 1. Description

The **Default Document Loader** node is the entry point for any **RAG (Retrieval-Augmented Generation)** workflow. Its job is to load a document from a source (a file, a URL, binary data) and, most importantly, split it into smaller, more manageable text "chunks" (fragments).

This splitting is fundamental because AI models have a limit on the number of words they can process at once (context window). Splitting a long document into many small pieces allows them to be indexed in a vector database and to retrieve only the most relevant fragments to answer a specific question.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Source** | The document source. It can be a local file, a URL, or, more commonly, binary data from a previous node. | `{{ $binary.data }}` |
| **Splitter** | The strategy used to split the text. The best choice for most cases is `Recursive Character Text Splitter`. | `Recursive Character Text Splitter` |
| **Chunk Size** | The maximum size of each text fragment, measured in characters. | `1000` |
| **Chunk Overlap** | The number of characters that overlap between two consecutive fragments. Helps prevent losing context at the cut boundaries. | `200` |

## 3. JSON Configuration Example

This example shows how to configure the node to load a PDF file received from a previous node.

```json
{
  "parameters": {
    "source": "={{ $binary.data }}",
    "splitter": "recursiveCharacterTextSplitter",
    "options": {
      "chunkSize": 1000,
      "chunkOverlap": 200
    }
  },
  "id": "uuid-goes-here",
  "name": "Load and Split Document",
  "type": "@n8n/n8n-nodes-langchain.documentDefaultDataLoader",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Preparing a RAG Knowledge Base)

**Objective:** Create a queryable knowledge base starting from a PDF document.

**Simplified Flow:**
1.  **Webhook / Manual Trigger:** The user provides the URL of a PDF document.
2.  **HTTP Request:** Downloads the PDF file from the URL. This node's output will be binary data.
3.  **Default Document Loader (This Node):**
    *   Receives the PDF binary data in the `Source` field.
    *   Uses the `Recursive Character Text Splitter` to split the PDF text into fragments of 1000 characters, with an overlap of 200 characters between each fragment.
4.  **Embeddings Node (e.g., `embeddingsOpenAi`):** Converts each individual text fragment into a numerical vector (embedding).
5.  **Vector Store Node (e.g., `vectorStoreQdrant`):** Saves all vectors in a vector database, making them available for future semantic searches.

The output of this workflow is a ready knowledge base. A second workflow can then use it to allow an agent to answer specific questions about the original document's content.

## 5. Best Practices & Tips

*   **Mandatory First Step for RAG:** Any workflow that needs to "talk" to your documents starts with this node.
*   **The Importance of Chunking:** The choice of `Chunk Size` and `Chunk Overlap` is the most critical aspect of the configuration.
    *   **Chunk Size:** A value between `700` and `1500` characters is a good starting point. It must be large enough to contain a complete concept, but not so large as to exceed the embedding model's limits.
    *   **Chunk Overlap:** Set an overlap of approximately 15-20% of the chunk size (e.g., `150`-`200` for a `chunkSize` of 1000). This ensures that sentences or ideas that span two chunks are not lost.
*   **Use the Recursive Splitter:** For general text (articles, PDFs, etc.), the `Recursive Character Text Splitter` is almost always the best choice. It attempts to split the text intelligently (first by paragraphs, then by sentences, then by words) before resorting to a hard cut, best preserving the text's semantics.
*   **One Document at a Time:** This node is optimized for processing a single document at a time. If you need to index multiple documents, place it inside a loop using the `Split in Batches` node.
