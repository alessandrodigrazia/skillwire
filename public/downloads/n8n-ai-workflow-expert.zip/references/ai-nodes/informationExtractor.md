# Node: Information Extractor (`@n8n/n8n-nodes-langchain.informationExtractor`)

## 1. Description

The **Information Extractor** node is a specialized tool designed for a specific task: extracting structured data (in JSON format) from a block of unstructured text. It works as an integrated combination of a language model and an output parser.

It is the ideal choice when the primary goal of your workflow is extracting precise information, such as data from an email, details from an invoice, or specifics from a user request. Instead of manually building a chain with an LLM and a parser, this node offers an "all-in-one" solution that is simpler and more direct for this specific use case.

## 2. Key Parameters and Connections

| Parameter/Connection | Description | Example Value |
| :--- | :--- | :--- |
| **LLM** | **(Required)** The connection to the language model that will perform the extraction. | `lmChatOpenAi` (recommended for accuracy) |
| **Zod Schema** | **(Required)** The schema that defines the structure and data types of the JSON you want to extract. | `[{"name": "product_name", "type": "string"}]` |
| **Input** | The unstructured text from which to extract the information. | `{{ $json.email_body }}` |

## 3. JSON Configuration Example

This example shows how to configure the node to extract lead details from a text.

```json
{
  "parameters": {
    "llm": {
      "__rl": true,
      "value": "OpenAI Chat Model",
      "mode": "list"
    },
    "zodSchema": {
      "schema": [
        {
          "name": "nome_contatto",
          "type": "string",
          "description": "Il nome e cognome del potenziale cliente"
        },
        {
          "name": "azienda",
          "type": "string",
          "description": "Il nome dell'azienda del contatto"
        },
        {
          "name": "email",
          "type": "string",
          "description": "L'indirizzo email del contatto"
        }
      ]
    },
    "text": "Nuovo lead ricevuto: Paolo Verdi per conto di Tech Solutions srl. Contattarlo a paolo.verdi@techsolutions.it."
  },
  "id": "uuid-goes-here",
  "name": "Extract Lead Details",
  "type": "@n8n/n8n-nodes-langchain.informationExtractor",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Lead Routing from Email)

**Objective:** Automatically extract a new lead's data from an email and create a record in the CRM.

**Simplified Flow:**
1.  **Gmail Trigger:** Activates when a new email arrives with the subject "New Lead".
2.  **Information Extractor (This Node):**
    *   Is connected to an `lmChatOpenAi` node for maximum precision.
    *   Its **Zod Schema** defines the fields `name`, `company`, `email`, and `request`.
    *   The **Input** field receives the email body from the trigger.
3.  **Execution:** The node sends the text and the schema to the AI model, which extracts the information. The node's output is a single clean JSON object: `{ "nome": "Paolo Verdi", "azienda": "Tech Solutions srl", ... }`.
4.  **HubSpot / Salesforce:** The CRM node receives the structured data and uses it to create a new Contact and a new Deal, without any manual parsing required.

## 5. Best Practices & Tips

*   **When to Use It:** Choose this node when your sole purpose is to **extract data**. If you also need to generate creative text, sustain a conversation, or execute complex logic, an `AI Agent` or an `LLM Chain` is more suitable.
*   **Use an Accurate LLM:** Precision extraction is a difficult task. For reliable results, connect this node to a high-quality model like `gpt-4o` or `gpt-4o-mini`. Smaller models might struggle to follow the schema consistently.
*   **Detailed Descriptions in the Schema:** The quality of the extraction depends almost entirely on the quality of your Zod Schema. Use the `description` field for each field to explain to the model exactly what you expect. Example: for a `invoice_date` field, a good description is `"The date of the invoice, to be formatted as YYYY-MM-DD"`.
*   **Handling Missing Fields:** If a piece of information is not present in the text, the corresponding field in the JSON output will likely be `null` or absent. Plan for this in your workflow by using an `IF` node to check whether an essential field was extracted before proceeding.
*   **"All-in-One" Alternative:** Consider this node as a simpler, integrated alternative to the `LLM Chain` -> `Structured Output Parser` chain when your only need is extraction.
