# Node: Window Buffer Memory (`@n8n/n8n-nodes-langchain.memoryBufferWindow`)

## 1. Description

The **Window Buffer Memory** node provides "short-term memory" for an `AI Agent`. Its purpose is to record the last `K` exchanges of a conversation (user message and AI response) and pass them to the agent as context for subsequent interactions.

Without this node, an agent is "stateless": every question is a new interaction with no memory of what was said before. With this node, the agent becomes "stateful" and can sustain a natural conversation, answer follow-up questions, and remember the context. It is an indispensable component for any chatbot or conversational assistant.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Memory Key** | The name of the field that will contain the chat history in the prompt sent to the agent. The default value is `chat_history` and rarely needs to be changed. | `chat_history` |
| **Session ID** | **(Crucial)** A unique ID that identifies a specific conversation. Allows the agent to maintain separate memories for different users. | `{{ $json.userId }}` or `{{ $json.message.chat.id }}` |
| **K** | The number of past interactions (one interaction = 1 question + 1 response) to keep in memory. | `10` |

## 3. JSON Configuration Example

This example shows a typical memory configuration for a chatbot.

```json
{
  "parameters": {
    "memoryKey": "chat_history",
    "sessionId": "{{ $json.userId }}",
    "k": 10
  },
  "id": "uuid-goes-here",
  "name": "Simple Memory",
  "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Conversational Agent)

**Objective:** Create an agent that remembers the conversation context.

**Simplified Flow:**
1.  **Chat Trigger:** The user starts a conversation and sends a message. The node exposes a unique `userId` for that session.
2.  **Window Buffer Memory (This Node):** Is configured with `Session ID: {{ $json.userId }}`. Retrieves the chat history for that specific user (if it exists).
3.  **AI Agent:** Is connected to the memory node. Its prompt automatically receives the `chat_history`.

**Conversation Example:**

*   **User:** `"Who wrote the Divine Comedy?"`
    *   *Memory:* (empty)
    *   *Agent:* Responds `"Dante Alighieri."`
    *   *Memory:* Saves the exchange: `[Human: "Who wrote...", AI: "Dante Alighieri."]`

*   **User:** `"And what year was he born?"`
    *   *Memory:* Retrieves the previous exchange and passes it to the agent.
    *   *Agent:* Thanks to the history, understands that "he" refers to Dante and responds: `"Dante Alighieri was born in 1265."`
    *   *Memory:* Adds the new exchange to the history.

Without the memory node, on the second question the agent would not have known who "he" referred to.

## 5. Best Practices & Tips

*   **Mandatory for Conversations:** If your agent needs to handle more than a single question-response exchange, using a memory node is **essential**.
*   **Set a Dynamic `Session ID`:** This is the most important parameter. It must be linked to a value that uniquely identifies the conversation (e.g., the user ID from the `Chat Trigger`, the chat ID from the `Telegram Trigger`, etc.). **Never use a static value in production**, otherwise all users will share the same, chaotic memory.
*   **Balance the `K` Value:** `K` represents the number of exchanges to remember. A value that is too low (e.g., 2-3) will cause the agent to "forget" quickly. A value that is too high (e.g., 20+) will consume many tokens in the AI model's context window, increasing costs and potentially exceeding limits. Start with a reasonable value like `10`.
*   **Session Memory vs. Persistent Memory:** This node provides session memory, which resets when the workflow closes (or after a period of inactivity). For long-term memory that survives across different executions, there are more complex alternatives like `Redis-Backed Chat Memory` (`@n8n/n8n-nodes-langchain.memoryRedis`), which require external infrastructure (a Redis database).
