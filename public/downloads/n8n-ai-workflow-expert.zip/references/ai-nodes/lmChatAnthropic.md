# Node: Anthropic Claude Chat Model (`@n8n/n8n-nodes-langchain.lmChatAnthropic`)

## 1. Description

This node allows integration with Anthropic's language models, known as Claude. Although less frequent in the analyzed dataset (35 instances), Claude carves out a fundamental role for a specific and high-value use case: **long-context document processing**.

Within this skill, Claude is the preferred choice when the input text length exceeds the limits of other models (typically beyond 100k tokens), capable of handling up to 200k tokens (approximately 150,000 words).

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Model** | Selects the Claude model to use. | `claude-3-5-sonnet-20241022` (balanced), `claude-3-opus-20240229` (maximum power) |
| **Messages** | The array of messages that constitute the conversation. | `{{ $json.prompt }}` |
| **Options** | Contains the parameters to control the model's behavior. | |
| `temperature` | Controls the creativity of the response. | `0.3` (for factual analysis) |
| `maxTokensToSample` | The maximum number of tokens to generate in the response. **This is mandatory for this node.** | `4096` |

## 3. JSON Configuration Example

```json
{
  "parameters": {
    "model": "claude-3-5-sonnet-20241022",
    "options": {
      "temperature": 0.2,
      "maxTokensToSample": 4096
    }
  },
  "id": "uuid-goes-here",
  "name": "Claude Document Analysis",
  "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "anthropicApi": {
      "id": "credential-id",
      "name": "Anthropic API Account"
    }
  }
}
```

## 4. Practical Use Case (Pattern: Document Intelligence)

The perfect use case for Claude is analyzing very long documents, such as a tender specification, a legal contract, or an academic research report.

**Simplified Flow:**
1.  **OneDrive / SharePoint (Trigger):** A new file (e.g., `tender_document.pdf`) is uploaded to a specific folder.
2.  **Extract from File:** The full text of the PDF is extracted. Let's assume it is 80,000 words (approximately 110k tokens).
3.  **Anthropic Claude (This Node):** Receives the entire text and a prompt asking to:
    *   Summarize the key technical requirements.
    *   Identify risk clauses.
    *   Extract the main deadlines.
    *   Provide a feasibility score from 1 to 10.
4.  **Airtable / SharePoint List:** The structured data extracted by Claude is saved to create an analysis report.
5.  **Teams / Outlook:** A notification is sent to the responsible team with the summary and a link to the report.

**Claude node input:**
*   `messages.content`: Contains the entire document text (which other models could not accept) and the prompt with analysis instructions.

**Claude node output:**
*   A textual response containing the requested analysis, which can then be processed by an `outputParserStructured` node or a `Code` node.

## 5. Best Practices & Tips

*   **When to Choose It:** The answer is simple: **when the context is too long for Gemini or OpenAI**. If you need to analyze a document that exceeds 100k tokens, Claude is the obligatory and best choice.
*   **`Sonnet` vs `Opus` Model:** Start with `claude-3-5-sonnet-20241022`. It is faster, much more economical, and incredibly capable. Switch to `claude-3-opus-20240229` only if the required reasoning complexity is extreme and cost is not the primary limiting factor.
*   **`maxTokensToSample` Parameter:** Unlike other nodes, this is **mandatory**. Make sure to set a value high enough to contain the response you expect (e.g., `4096` or `8192`).
*   **Ideal for Safety:** Claude models are known for their ethical "guardrails". If you are building a public-facing application and response safety is a top priority, Claude is an excellent choice.
*   **Cost:** Although `Sonnet` is competitive, `Opus` is a premium model with a cost comparable to GPT-4. Use it sparingly and only when strictly necessary.
