# Node: LLM Chain (`@n8n/n8n-nodes-langchain.chainLlm`)

## 1. Description

The **LLM Chain** node is one of the most basic and common building blocks in an AI workflow. It represents a single, direct interaction with a language model (LLM). Its purpose is to "chain" a prompt to a model to obtain a response.

Unlike an `AI Agent` that can plan and use tools, an `LLM Chain` performs a single, well-defined task. It is the ideal choice for simple, non-interactive operations such as text classification, translation, summarization, or content generation based on a template.

The dataset analysis identifies it as a very common node, present in 257 workflows.

## 2. Key Parameters and Connections

| Parameter/Connection | Description | Example Value |
| :--- | :--- | :--- |
| **LLM** | **(Required)** The connection to the language model that will execute the request. | `lmChatGoogleGemini`, `lmChatOpenAi` |
| **Prompt** | The prompt template to send to the model. It can contain placeholders (variables) between double curly braces. | `"Translate the following text to Italian: {{english_text}}"` |
| **Prompt Values** | A JSON object where you specify the values to substitute into the prompt placeholders. | `{"english_text": "{{ $json.text_from_previous_node }}"}` |

## 3. JSON Configuration Example

This example, inspired by `0472_Aggregate_Gmail_Create_Triggered.json`, shows a chain that classifies an email.

```json
{
  "parameters": {
    "llm": {
      "__rl": true,
      "value": "OpenAI Chat",
      "mode": "list"
    },
    "prompt": "Classify the body of this email into one of the following categories: INVOICE, SPAM, INFO_REQUEST.\n\nEmail: {{email_body}}",
    "promptValues": {
      "values": [
        {
          "name": "email_body",
          "value": "={{ $json.body }}"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "Assign labels for message",
  "type": "@n8n/n8n-nodes-langchain.chainLlm",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Simple Classification)

**Objective:** Automatically classify incoming emails.

**Simplified Flow:**
1.  **Gmail Trigger:** A new message arrives in the inbox.
2.  **LLM Chain (This Node):**
    *   Is connected to an `lmChatGoogleGemini` node.
    *   Its **Prompt** parameter is: `"You are an email organization assistant. Classify this email as URGENT, NORMAL, or SPAM. Reply with only one of these three words. Email text: {{email_body}}"`.
    *   Its **Prompt Values** parameter is set to pass the email body from the trigger to the `email_body` placeholder.
3.  **Execution:** The node sends the compiled prompt to Gemini and receives a single word as output (e.g., `"URGENT"`).
4.  **Switch:** A `Switch` node receives the classification and routes the workflow to different branches: sends a Slack notification if `URGENT`, archives the email if `SPAM`, etc.

## 5. Best Practices & Tips

*   **Use for Direct Tasks:** Choose `LLM Chain` for "one-to-one" tasks where complex reasoning or tool use is not required. If the AI needs to take multiple steps or interact with other systems, an `AI Agent` is the better choice.
*   **Leverage Placeholders:** Define a generic prompt in the `Prompt` parameter and pass data dynamically through `Prompt Values`. This makes your workflows cleaner and easier to read, separating the template from the data logic.
*   **Separation of Logic and Model:** Using this node promotes good architecture. The prompt logic is contained here, while the model configuration (which model to use, temperature, etc.) is managed in the connected LLM node (e.g., `lmChatGoogleGemini`).
*   **For Structured Outputs:** Although it is possible to request JSON from an `LLM Chain`, it is more robust to use the `LLM Model` + `Structured Output Parser` combination, which validates the output. Use the `LLM Chain` primarily when you expect a simple text response.
