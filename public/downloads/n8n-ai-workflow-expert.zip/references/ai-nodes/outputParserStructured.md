# Node: Structured Output Parser (`@n8n/n8n-nodes-langchain.outputParserStructured`)

## 1. Description

This node is a "validator" and "formatter". Its job is to take the raw text output of a language model (LLM) and transform it into a **clean, structured JSON object**, according to a schema that you define. It is an essential component for building robust AI workflows.

Without it, you would have to rely on manual parsing (with the `Code` node and `JSON.parse`), which is fragile and can fail if the LLM adds extra text like "Here is the JSON you asked for:". This parser, instead, is designed to ignore superfluous text and extract only the valid JSON.

## 2. Key Parameters

| Parameter |
| :--- |
| **Zod Schema** | **(Required)** The heart of the node. An array of objects that defines the structure of the desired JSON, using Zod syntax. For each field, you specify name, type, and description. |

**Connections:**
*   **LLM:** Should be connected to the language model node (e.g., `lmChatGoogleGemini`) whose output you want to parse.
*   **Input:** Should be connected to the node that provides the prompt to the model (e.g., `chainLlm` or a `Set` node).

## 3. JSON Configuration Example

This example, inspired by `0472_Aggregate_Gmail_Create_Triggered.json`, shows how to define a schema for extracting data from an email.

```json
{
  "parameters": {
    "zodSchema": {
      "schema": [
        {
          "name": "category",
          "type": "string",
          "description": "Una di: URGENT, INVOICE, SPAM, GENERIC"
        },
        {
          "name": "priority",
          "type": "number",
          "description": "Un numero da 1 a 5 che indica l'urgenza"
        },
        {
          "name": "sender_email",
          "type": "string",
          "description": "L'indirizzo email del mittente"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "JSON Parser",
  "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Reliable Data Extraction)

**Objective:** Reliably extract contact details from unstructured text.

**Simplified Flow:**
1.  **Set (Input):** A `Set` node contains the text: "Contact: Mario Rossi, email: mario.r@example.com, customer ID: 98765".
2.  **lmChatOpenAi (LLM):** Receives the text with the prompt: "Extract the data from this text and format it according to the provided schema."
3.  **Structured Output Parser (This Node):** Is connected to the LLM and has a Zod Schema that defines the fields `name` (string), `email` (string), and `customer_id` (number).
4.  **Execution:**
    *   The LLM might respond with: "Sure, here is the JSON: {\"nome\": \"Mario Rossi\", \"email\": \"mario.r@example.com\", \"id_cliente\": 98765}".
    *   The parser ignores "Sure, here is the JSON:", reads the JSON string, validates it against the schema, and returns a clean JSON object: `{ nome: "Mario Rossi", email: "mario.r@example.com", id_cliente: 98765 }`.
5.  **Airtable:** The Airtable node receives the clean JSON object and can map the fields `name`, `email`, and `customer_id` directly to the table columns, without errors.

## 5. Best Practices & Tips

*   **Always After an LLM for JSON:** If you expect JSON output from an AI model, **always** use this node. It is the most robust and reliable method, superior to manual parsing via the `Code` node.
*   **Clear Descriptions in the Schema:** The `description` of each field in the Zod Schema is not just a comment for you. It is passed to the AI model to help it understand the meaning of each field, significantly improving extraction accuracy.
*   **Be Specific with Types:** Always define the correct data type (`string`, `number`, `boolean`). If you expect a number and the AI returns a string, the parser can attempt a conversion or flag an error, making the workflow more predictable.
*   **Inform the LLM in the Prompt:** Even though the parser is powerful, help the AI model by explicitly telling it in the prompt to follow the schema. Example: `"...Reply exclusively with a JSON object that adheres to the provided schema."`
*   **Use Models with Strong Instruction Following:** This node works best with AI models that follow instructions well, such as `gpt-4o` or `gemini-2.5-pro`. For smaller models, a more rigid prompt may be necessary.
