# Node: Workflow as Tool (`@n8n/n8n-nodes-langchain.toolWorkflow`)

## 1. Description

The **Workflow as Tool** node is a powerful concept that allows you to transform an entire n8n workflow into a reusable "tool" that an `AI Agent` can invoke.

In practice, you can encapsulate complex logic (such as searching data in a database, sending a formatted email, or generating a report) into a separate workflow (a "sub-workflow") and then expose it to the agent as a single action. This allows you to create extremely powerful and modular agents, separating the reasoning logic (the agent) from the execution logic (the tools).

The dataset analysis shows that this node is used in 180 workflows, signaling its importance in advanced agentic scenarios.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Workflow ID** | **(Required)** The ID of the workflow you want to run as a tool. | `zUaxnVJ5EMNv0xEr` |
| **Tool Name** | **(Required)** The name by which the agent will refer to this tool. It should be a short, programmatic name. | `search_order_details` |
| **Tool Description** | **(Crucial)** The description the agent will read to understand what the tool does and when to use it. It must be very clear. | `"Use it to retrieve the details and status of a specific order by providing its ID."` |
| **Input Parameters** | A Zod schema that defines the parameters the tool accepts as input. | `[{"name": "order_id", "type": "string", "description": "The unique ID of the order to search for"}]` |

## 3. JSON Configuration Example

This example defines a tool that runs another workflow to search for orders.

```json
{
  "parameters": {
    "workflowId": "some-workflow-id",
    "name": "searchCustomerOrder",
    "description": "Use this tool to get the details of a customer order using the order ID.",
    "schema": {
      "schema": [
        {
          "name": "order_id",
          "type": "string",
          "description": "L'ID dell'ordine da cercare, es. ORD-12345"
        }
      ]
    }
  },
  "id": "uuid-goes-here",
  "name": "Tool: Cerca Ordine",
  "type": "@n8n/n8n-nodes-langchain.toolWorkflow",
  "typeVersion": 1,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Agent with Controlled Data Access)

**Objective:** Create a customer support agent that can check the status of an order without having direct access to the database.

**Workflow 1: The Main Agent**
1.  **Telegram Trigger:** The user writes: `"I'd like to know the status of my order #ABC-123"`.
2.  **Tool: Search Order (This Node):** Configured to run the "Sub-Workflow" and described as "Useful for finding order details by its ID".
3.  **AI Agent:** Receives the message, recognizes the request and the order ID (`ABC-123`). Decides to use the `Search Order` tool, passing it `order_id: "ABC-123"`.
4.  The agent waits for the response from the tool, receives it (`"Status: Shipped"`), and formulates a response for the user.
5.  **Telegram (Send):** Sends the response: `"Your order ABC-123 is marked as shipped."`

**Workflow 2: The Sub-Workflow (e.g., ID: `sub-workflow-id`)**
1.  **Execute Workflow Trigger:** Activates when called by the agent. Receives `order_id` as input.
2.  **Airtable (Search Records):** Searches the "Orders" table for a record where the `ID` field matches the received `order_id`.
3.  **Set:** Formats the result into a simple string (e.g., `"Status: Shipped, Date: 2025-10-18"`).
4.  **Respond to Webhook:** Returns the formatted string to the agent that called it.

## 5. Best Practices & Tips

*   **Think in Terms of "Functions":** Consider each sub-workflow as a reusable function. This allows you to build a library of "capabilities" for your agents (e.g., `sendEmail`, `searchContact`, `createPDFReport`).
*   **The Description is Everything:** The agent is only as good as its tool descriptions. Be explicit about **what** the tool does and **what inputs it requires**. A good description is the key to a reliable agent.
*   **Rigorous Input Schema:** Always use the Zod schema to define inputs. It works like a "function signature" in programming and tells the agent exactly which arguments to pass.
*   **Simple Output from Sub-Workflow:** The sub-workflow should return a simple and concise output (a text string or a small JSON). The agent will use it as context for its final response; it does not need complex raw data.
*   **Security and Abstraction:** This node is an excellent security pattern. It allows an agent to interact with internal systems (databases, CRM) in a controlled manner, without ever exposing credentials or direct access logic to the main AI model.
