# Visual Pattern Library for n8n Workflows

## 1. Introduction

This document provides a series of "blueprints" or flow diagrams for the most common automation patterns in n8n. These diagrams help you understand at a glance the sequence of operations and the data flow, offering a high-level architectural view that complements the specific guides for individual nodes.

---

## Pattern 1: Simple ETL (Extract, Transform, Load)

**Purpose:** Extract data from a source, transform it into a useful format, and load it into a destination.

**Diagram:**
```
[Data Source: API / Trigger] ---> [Transform: Set or Code Node] ---> [Destination: Database / Sheets]
```

*   **Extract:** An `HTTP Request` node or a trigger (e.g., `Gmail Trigger`) retrieves the initial data.
*   **Transform:** A `Set` or `Code` node cleans the data, renames fields, changes formats, or performs calculations.
*   **Load:** A node such as `Google Sheets`, `Airtable`, or `PostgreSQL` inserts the transformed data into the final destination.

**Use case:** Download daily orders from Shopify, calculate the margin for each order, and save them in a Google Sheets spreadsheet.

---

## Pattern 2: Data Enrichment

**Purpose:** Take a base data point (such as an email) and enrich it with additional information from other sources.

**Diagram:**
```
[Trigger: New Lead] ---> [HTTP Request: Enrichment API] ---> [Merge: Combine Data] ---> [CRM: Update Contact]
```

*   **Trigger:** A `Webhook` receives a new lead with only a name and email.
*   **HTTP Request:** Calls an external API (e.g., Clearbit) using the email to obtain the company name, industry, and number of employees.
*   **Merge:** Combines the original lead data with the enrichment data.
*   **CRM:** Updates the contact record in the CRM with the new information.

---

## Pattern 3: Data Aggregation

**Purpose:** Collect data from multiple different sources, standardize it, and aggregate it to create a consolidated report.

**Diagram:**
```
                   /--> [Source A: CRM] ------> [Format A] --\
[Schedule Trigger] --|--> [Source B: Analytics] -> [Format B] --> [Merge] -> [Aggregate] -> [Create Report]
                   \--> [Source C: Database] --> [Format C] --/
```

*   **Trigger:** A `Schedule Trigger` starts the process (e.g., every night).
*   **Parallel Flows:** Three parallel branches retrieve data from different systems.
*   **Format:** Each branch has a `Set` or `Code` node to standardize the data into a common format.
*   **Merge:** Reunites all standardized data into a single flow.
*   **Aggregate:** A `Code` or `Aggregate` node performs calculations on the combined data (e.g., sums, averages).
*   **Create Report:** The final result is used to generate a report (e.g., via email).

---

## Pattern 4: Manual Approval (Human in the Loop)

**Purpose:** Pause an automation while waiting for a decision from a human.

**Diagram:**
```
[Trigger] -> [Prepare Data] -> [Send Approval Request] -> [Wait] -> [If: Approved?] --(true)--> [Execute Action]
                                                                       |
                                                                       +--(false)--> [Notify Rejection]
```

*   **Send Request:** An `Outlook` or `Teams` node sends a message to a manager with two special links (generated with the `Webhook` node).
*   **Wait:** The `Wait` node pauses the workflow.
*   **Resume:** When the manager clicks one of the links ("Approve" or "Reject"), it sends a request to a second workflow (or the same one, if configured for this) that restarts the `Wait` node.
*   **If:** Checks which link was clicked and routes the workflow to the correct branch.

**Use case:** An AI generates a social media post, but it is published only after approval from the marketing manager.

---

## Pattern 5: Batch Processing (Batch Processing Loop)

**Purpose:** Process a large number of items in controlled batches to avoid rate limits and memory issues.

**Diagram:**
```
                                     +----------------------------------+
                                     |                                  |
[Data Source: 1000 items] -> [Split in Batches] --(Batch)--> [Process Batch] -> [Wait] --+
                                     |
                                   (Done)
                                     |
                                     V
                              [End / Send Summary]
```

*   **Split in Batches:** Receives N items and passes only a small batch at a time (e.g., 50).
*   **Process Batch:** A series of nodes (e.g., `HttpRequest`) processes the items in the batch.
*   **Wait:** A pause to respect API limits.
*   **Loop:** The last node in the processing block reconnects to the input of `Split in Batches`, which then sends the next batch.
*   **Done:** When all batches have been processed, the flow continues from the "Done" output for the final actions.

**Use case:** Update 5000 contacts in a CRM that only allows 100 API calls per minute.
