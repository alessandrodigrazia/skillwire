# Validation Checklist

Pre-output checklist for generated n8n workflows. Use the `validate_workflow` MCP tool for automatic verification.

## Pre-Validation Checklist (Manual)

### 1. Basic Structure

- [ ] `name`: present and descriptive
- [ ] `nodes`: non-empty array
- [ ] `connections`: object present
- [ ] `settings`: object present (can be empty)
- [ ] `meta`: present with `instanceId` (even placeholder)

### 2. Each Node

- [ ] `id`: unique UUID
- [ ] `name`: unique descriptive name
- [ ] `type`: valid node name (verified with `get_node`)
- [ ] `typeVersion`: correct version for the node
- [ ] `position`: `[x, y]` array with valid coordinates
- [ ] `parameters`: object with required parameters

### 3. Connections

- [ ] Each connection references existing nodes
- [ ] Format: `"NodeName": { "main": [[{ "node": "OtherNode", "type": "main", "index": 0 }]] }`
- [ ] No orphan connections
- [ ] Trigger node has no input connections

### 4. AI Node Parameters

- [ ] Credentials referenced (not hardcoded)
- [ ] `model` specified for LLM nodes
- [ ] `systemMessage` present if required
- [ ] `options` configured appropriately

### 5. Trigger Node

- [ ] Exactly 1 trigger node (for standard workflows)
- [ ] Trigger is the first node in the chain
- [ ] No input connections to the trigger

## Call MCP validate_workflow

```javascript
// Full validation
validate_workflow({
  workflow: workflowJson,
  mode: "full"  // "full" | "structure" | "connections"
})
```

### Validation Modes

| Mode | What it Validates |
|------|-------------|
| `structure` | Only basic JSON structure |
| `connections` | Connections between nodes |
| `full` | Everything (structure + connections + parameters) |

## Common Errors and Fixes

### ERR001: Node type not found

```
Error: Node type "n8n-nodes-base.gmailTriggers" not found
Fix: Verify exact name with search_nodes("gmail")
     Correct: "n8n-nodes-base.gmailTrigger" (singular)
```

### ERR002: Missing required parameter

```
Error: Missing required parameter "resource" in node "Gmail"
Fix: get_node("n8n-nodes-base.gmail") → see required params
```

### ERR003: Connection to non-existent node

```
Error: Connection references node "Email Parser" which doesn't exist
Fix: Verify that all names in connections match node names
```

### ERR004: Duplicate node ID

```
Error: Duplicate node ID "abc123"
Fix: Generate unique UUIDs for each node
```

### ERR005: Invalid typeVersion

```
Error: Invalid typeVersion 1 for node type that requires 2
Fix: get_node() → verify versionDefaults
```

## Minimum Valid Workflow Template

```json
{
  "name": "Workflow Name",
  "nodes": [
    {
      "id": "uuid-trigger",
      "name": "Manual Trigger",
      "type": "n8n-nodes-base.manualTrigger",
      "typeVersion": 1,
      "position": [240, 300],
      "parameters": {}
    },
    {
      "id": "uuid-action",
      "name": "Set",
      "type": "n8n-nodes-base.set",
      "typeVersion": 3.4,
      "position": [460, 300],
      "parameters": {
        "mode": "manual",
        "duplicateItem": false,
        "assignments": {
          "assignments": [
            {
              "name": "output",
              "value": "Hello World",
              "type": "string"
            }
          ]
        }
      }
    }
  ],
  "connections": {
    "Manual Trigger": {
      "main": [
        [
          {
            "node": "Set",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  },
  "settings": {
    "executionOrder": "v1"
  },
  "meta": {
    "instanceId": "placeholder"
  }
}
```

## Complete Validation Workflow

```
1. Generate workflow JSON
         │
         ▼
2. validate_workflow(json, "structure")
         │
    ┌────┴────┐
    │ Errors? │
    └────┬────┘
     Yes │  No
    ┌────┘    └────┐
    ▼              ▼
 Fix errors   validate_workflow(json, "connections")
    │              │
    └──────────────┘
                   │
              ┌────┴────┐
              │ Errors? │
              └────┬────┘
               Yes │  No
              ┌────┘    └────┐
              ▼              ▼
           Fix errors   validate_workflow(json, "full")
              │              │
              └──────────────┘
                             │
                        ┌────┴────┐
                        │ Errors? │
                        └────┬────┘
                         Yes │  No
                        ┌────┘    └────┐
                        ▼              ▼
                     Fix errors    OUTPUT
                        │
                        └──────────────→ Re-validate
```

## Final Notes

- **Always validate** before returning a workflow to the user
- **Automatic Fix**: If possible, correct errors without asking the user
- **Fallback**: If MCP not available, use manual checklist
- **Logging**: Track common errors to improve generation
