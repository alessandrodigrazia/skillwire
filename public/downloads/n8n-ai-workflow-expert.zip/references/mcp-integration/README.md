# MCP Integration Guide

Guide for integrating the `czlonkowski/n8n-mcp` server into the n8n generation workflow.

## Available Tools (n8n-mcp v2.30.2)

| Tool | Description | When to Use |
|------|-------------|-------------|
| `search_nodes` | Search nodes by keyword | Finding which node to use for a task |
| `get_node` | Complete node details | Getting exact parameter schema |
| `list_nodes` | List all available nodes | Overview of available categories |
| `search_templates` | Search workflow templates | Finding similar patterns |
| `get_template` | Specific template details | Extracting working configurations |
| `validate_workflow` | Validate workflow JSON | Final QA check before output |
| `get_stats` | Database statistics | Debug and health check |

## Tool Priority Matrix

| Workflow Phase | Primary MCP Tool | Secondary Skill Reference |
|----------------|-------------------|---------------------------|
| Discovery | `search_nodes` | patterns-from-community/ |
| Architecture | `get_node` | workflow-patterns.md |
| Generation | `get_template` | ai-nodes/*.md |
| Validation | `validate_workflow` | error-handling.md |

## Standard Operating Workflow

```
USER REQUEST
       │
       ▼
┌──────────────────────────────────────┐
│ STEP 1: ANALYSIS (Skill Knowledge)   │
│ - Identify requested pattern         │
│ - Select appropriate AI model        │
│ - Determine stack (personal/ent)     │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 2: NODE DISCOVERY (MCP)         │
│ - search_nodes("keyword")            │
│ - Identify candidate nodes           │
│ - Verify availability                │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 3: TEMPLATE SEARCH (MCP + Repo) │
│ - search_templates("use case")       │
│ - Search in Zie619 repository        │
│ - Extract similar configurations     │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 4: NODE DETAILS (MCP)           │
│ - get_node("node-type") for each     │
│ - Extract exact parameter schema     │
│ - Note required vs optional          │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 5: JSON GENERATION              │
│ - Apply patterns from Skill          │
│ - Use exact parameters from MCP      │
│ - Configure connections              │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│ STEP 6: VALIDATION (MCP)             │
│ - validate_workflow(json)            │
│ - Auto-fix errors                    │
│ - Re-validate until clean            │
└──────────────────┬───────────────────┘
                   │
                   ▼
              JSON OUTPUT
```

## Best Practices

### 1. Always verify nodes before generating

```
WRONG:   Generate JSON with "imagined" nodes
CORRECT: get_node("n8n-nodes-base.gmail") → use real schema
```

### 2. Always validate before returning

```
WRONG:   Return unvalidated JSON
CORRECT: validate_workflow() → fix → re-validate → output
```

### 3. Prefer existing templates

```
WRONG:   Generate everything from scratch
CORRECT: search_templates() → adapt working template
```

## Skill ↔ MCP Mapping

| Skill Concept | Corresponding MCP Tool |
|----------------|------------------------|
| Pattern Library | `search_templates` |
| Node Reference | `get_node` |
| Error Handling | `validate_workflow` |
| AI Model Selection | Skill-only (no MCP) |
| Connection Logic | Skill-only (no MCP) |

## Technical Notes

- **MCP Latency**: ~12ms per call (self-hosted via npx)
- **Database**: 803 documented n8n nodes
- **Fallback**: If MCP unavailable → use Skill knowledge only
- **Cache**: Local SQLite database, no external API calls
