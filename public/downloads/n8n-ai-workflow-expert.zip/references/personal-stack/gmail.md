# Node: Gmail (`n8n-nodes-base.gmail`)

## 1. Description

The **Gmail** node is the interface for interacting with Google's email service. It is an extremely versatile node that can act both as a **trigger** (to start a workflow when an email arrives) and as an **action** (to read, send, move, or label messages).

It is a central component of the "Personal Stack" and the foundation for countless automation workflows, from managing incoming emails to creating notifications. Dataset analysis confirms it as one of the most popular integration nodes.

## 2. Main Operations

The Gmail node can perform several actions, the most important being:

*   **Send:** Sends an email. Key parameters are `To`, `Subject`, and `Body` (for plain text) or `HTML` (for formatted emails).
*   **Get:** Retrieves the full content of a single email by specifying its ID.
*   **GetAll:** Retrieves a list of emails. It is fundamental to use the `Filters` parameter to limit the search (e.g., by label, sender, subject) to avoid downloading the entire mailbox.
*   **Add Labels / Remove Labels:** Adds or removes one or more labels from a message. This is a crucial operation for tracking the processing state of an email.
*   **Move:** Moves an email to a different folder (e.g., Trash, Spam, Archive).

## 3. The Node as Trigger (`gmailTrigger`)

When used as the first node in a workflow, it acts as a trigger. It activates as soon as an email matching the specified criteria (e.g., has a certain label, comes from a certain sender) arrives in the mailbox. This allows starting automations in real time.

## 4. JSON Configuration Example (Send Action)

```json
{
  "parameters": {
    "operation": "send",
    "to": "{{ $json.customerEmail }}",
    "subject": "Your order #{{ $json.orderId }} has been shipped!",
    "html": "<p>Hi {{ $json.customerName }},</p><p>We are happy to inform you that your order is on its way!</p>"
  },
  "id": "uuid-goes-here",
  "name": "Send Shipping Confirmation",
  "type": "n8n-nodes-base.gmail",
  "typeVersion": 2.1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "gmailOAuth2": {
      "id": "credential-id",
      "name": "My Gmail Account"
    }
  }
}
```

## 5. Practical Use Case (Pattern: Email → AI → Airtable)

This pattern, seen in the workflow `01. Article → Post LinkedIn`, is a perfect example of how to use the Gmail node both as a trigger and as an action.

**Flow:**
1.  **Gmail Trigger:** The workflow activates when an email receives the label `"ToConvert"`.
2.  **Gmail (Get):** The triggered email's ID is used to retrieve the full message body.
3.  **LLM Node (Gemini):** The email text is analyzed and transformed into a LinkedIn post.
4.  **Airtable (Create):** The generated post is saved to an Airtable database.
5.  **Gmail (Remove/Add Labels):** To complete the cycle, the workflow uses two Gmail nodes:
    *   One to **remove** the `"ToConvert"` label.
    *   One to **add** the `"Converted"` label.

This final step is fundamental to prevent the workflow from processing the same email indefinitely.

## 6. Best Practices & Tips

*   **Use Labels to Control the Flow:** Labels are the most robust method for managing an email's state in an automation. A workflow should always "mark" an email after processing it (e.g., by adding `status-processed`) to avoid reprocessing it.
*   **Always Filter in `GetAll`:** Never use the `GetAll` operation without filters. Retrieving thousands of emails is inefficient and can block the workflow. Always use the `Filters` field to specify a label, a sender, or a date range.
*   **Use HTML for Formatted Emails:** When sending emails, always prefer the `HTML` field over `Body`. This allows you to use HTML tags (`<p>`, `<b>`, `<a>`, etc.) to create more readable and professional messages, including links and formatting.
*   **Secure Authentication with OAuth2:** The connection to Gmail uses the OAuth2 protocol, which is the industry security standard. n8n will guide you through the authorization process, which only needs to be done once. You will never need to enter your Google password directly into n8n.
*   **Watch Out for Sending Limits:** Gmail imposes limits on the number of emails you can send per day (approximately 500 for a standard account). If you need to send large volumes of emails, consider using dedicated transactional services (like SendGrid or Postmark) instead of your personal Gmail account.
