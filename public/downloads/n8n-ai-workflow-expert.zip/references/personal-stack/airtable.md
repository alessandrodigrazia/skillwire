# Node: Airtable (`n8n-nodes-base.airtable`)

## 1. Description

The **Airtable** node allows n8n to connect and interact with Airtable bases. Airtable is a hybrid service between a spreadsheet and a database, extremely flexible and easy to use. For this reason, it is the ideal solution to use as a "backend" or "state database" for n8n workflows, especially in the Personal Stack.

It can be used to store data processed by a workflow, log the execution of an automation, track the status of a process (e.g., "Todo", "In Progress", "Done") and, most importantly, to verify whether a piece of information has already been processed.

## 2. Main Operations

*   **Search:** The most important operation. Searches for one or more records that match a specific formula. It is fundamental for deduplication and for retrieving data.
*   **Create:** Adds one or more new records to a table.
*   **Update:** Modifies one or more existing records, identifying them by their ID.
*   **Upsert:** A combined operation: if a record with a certain key exists, it updates it; otherwise, it creates it.
*   **Get:** Retrieves a single record by its unique ID.
*   **Delete:** Deletes one or more records.

## 3. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Base** | The Airtable Base (the "database") to connect to. | `Converted Articles` |
| **Table** | The specific Table within the Base. | `Published Posts` |
| **Operation** | The action to perform (`Search`, `Create`, etc.). | `Search` |
| **Filter By Formula** | **(Crucial for `Search`)** The formula, in Airtable syntax, used to find records. | `LOWER({VideoID}) = LOWER("{{ $json.VideoID }}")` |
| **Columns** | For `Create` and `Update` operations, defines the mapping between n8n data and Airtable columns. | `{"Status": "Done", "Post Text": "{{ $json.post_text }}"}` |

## 4. JSON Configuration Example (Search Operation)

This example, based on your workflows, shows how to search for a record to avoid processing the same video twice.

```json
{
  "parameters": {
    "operation": "search",
    "base": {
      "__rl": true,
      "value": "appXXXXXXXXXXXXXXX",
      "mode": "id"
    },
    "table": {
      "__rl": true,
      "value": "tblXXXXXXXXXXXXXXX",
      "mode": "id"
    },
    "filterByFormula": "LOWER({VideoID}) = LOWER(\"{{ $json.VideoID }}\")",
    "limit": 1
  },
  "id": "uuid-goes-here",
  "name": "Search video on Airtable",
  "type": "n8n-nodes-base.airtable",
  "typeVersion": 2.1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "airtableTokenApi": {
      "id": "credential-id",
      "name": "Airtable Personal Access Token"
    }
  }
}
```

## 5. Practical Use Case (Pattern: Deduplication and Logging)

**Objective:** Read an RSS feed and publish a post on LinkedIn only for articles that have not yet been processed.

**Flow:**
1.  **RSS Feed Read:** The workflow activates and reads the latest articles from a feed.
2.  **Airtable (Search) (This Node):** For each article, the workflow searches the "Processed Articles" table for an existing record with the same URL. The formula is: `LOWER({URL}) = LOWER("{{ $json.link }}")`.
3.  **If:** An `If` node checks whether the search returned any results.
4.  **`true` Branch (Record Found):** The workflow stops for that article. The article has already been processed.
5.  **`false` Branch (No Record):**
    *   An AI node generates the post text.
    *   A `LinkedIn` node publishes the post.
    *   **Airtable (Create):** A second Airtable node **creates** a new record in the "Processed Articles" table, saving the article URL, the post text, and the date. This ensures the article will not be reprocessed next time.

## 6. Best Practices & Tips

*   **Your Reference Database:** Airtable is perfect as a "brain" or long-term memory for your workflows. Use it to track what has been done and to guide future decisions.
*   **Master the `Filter By Formula`:** This is the most powerful feature of the node. It allows you to create complex search logic. Remember that the syntax is that of [Airtable formulas](https://support.airtable.com/docs/formula-field-reference), not JavaScript. To make comparisons case-insensitive, always use `LOWER()` on both sides of the equality.
*   **"Search Before Create":** The "Search before Create" pattern is the number one practice for avoiding duplicates and creating robust automations. Always apply it.
*   **Field Name Matching:** The field names you use in the `Columns` parameter must match **exactly** (including uppercase/lowercase and spaces) the column names in your Airtable table.
*   **Leverage the n8n UI:** When configuring the node, n8n allows you to select Base and Table from a dropdown menu, pre-populating their IDs. This reduces the risk of errors.
