# Node: YouTube (`n8n-nodes-base.youTube`)

## 1. Description

The **YouTube** node allows n8n to interact with the YouTube API. It enables automating actions such as searching for videos, retrieving details about videos or channels, and, most importantly, managing playlists.

It is a key node for content creation and curation workflows, allowing you to use YouTube as a source of content to analyze, summarize, or repurpose on other platforms.

## 2. Main Operations

*   **Search:** Searches for videos, channels, or playlists based on a text query.
*   **Video - Get:** Retrieves all detailed information about a specific video by providing its ID.
*   **Playlist Item - GetAll:** Retrieves all videos (items) contained in a specific playlist. This is a very common operation for processing a curated list of videos.
*   **Playlist Item - Insert:** Adds a video to a playlist.
*   **Playlist Item - Delete:** Removes a video from a playlist. This action is fundamental for "marking" a video as processed.

## 3. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Resource** | The YouTube resource to interact with. | `Playlist Item` |
| **Operation** | The specific action to perform on the resource. | `GetAll` |
| **Playlist ID** | The unique ID of the YouTube playlist to operate on. It can be found in the playlist URL. | `PL1WSxrKCmNH9HwFIM9nVRpHOdPDg8y0H6` |
| **Video ID** | The unique ID of a video, required for operations like `Get` or `Insert`. | `dQw4w9WgXcQ` |

## 4. JSON Configuration Example (Reading from Playlist)

This example, based on your workflow `02. Video → Post LinkedIn`, shows how to read all videos from a playlist.

```json
{
  "parameters": {
    "resource": "playlistItem",
    "operation": "getAll",
    "playlistId": "={{ $('Configurazione').first().json.playlistId }}",
    "returnAll": true
  },
  "id": "uuid-goes-here",
  "name": "Search videos to convert in YouTube playlist",
  "type": "n8n-nodes-base.youTube",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "youTubeOAuth2Api": {
      "id": "credential-id",
      "name": "My YouTube Account"
    }
  }
}
```

## 5. Practical Use Case (Pattern: Work Queue with Playlist)

**Objective:** Create a system where videos are added to a "To Process" playlist and an n8n workflow automatically transforms them into LinkedIn posts.

**Flow:**
1.  **Manual Action:** A user (you) finds an interesting video on YouTube and adds it to the "To Process" playlist.
2.  **Schedule Trigger:** Every hour, an n8n workflow starts.
3.  **YouTube (GetAll) (This Node):** The workflow reads all videos in the "To Process" playlist.
4.  **Airtable (Search):** For each video, it checks a database to see if it has already been processed in the past (deduplication).
5.  **If (New Video):** If the video is new, the flow continues:
    *   An AI node generates a post based on the video's title and description.
    *   A `LinkedIn` node publishes the post.
    *   **YouTube (Delete) (This Node):** The video is **removed** from the "To Process" playlist. This step is crucial to prevent reprocessing on the next cycle.

## 6. Best Practices & Tips

*   **Use Playlists as Work Queues:** The "inbox playlist" pattern is extremely effective. It allows you to curate content asynchronously (from your phone, from the browser) and let n8n process them automatically. One playlist for input (`To Process`) and perhaps one for output (`Processed`) is an excellent structure.
*   **Remove After Processing:** Always remember to use the `Playlist Item: Delete` operation after successfully processing a video. It is the cleanest way to manage state and prevent duplicates.
*   **Watch Out for API Quotas:** The YouTube API has a daily quota system. Read operations (`GetAll`) are relatively inexpensive, but a workflow that runs very frequently (e.g., every minute) on a very large playlist could consume the quota. A check every hour or two is usually a good compromise.
*   **OAuth2 Authentication:** Like other Google services, connecting to YouTube requires secure authentication via OAuth2, which n8n manages in a guided manner.
*   **Retrieve Specific Data:** The YouTube node output can be very rich with information. Use a `Set` node to extract only the fields you need (`videoId`, `title`, `description`) to keep the data flow clean and readable.
