# Claude Guide (SECONDARY - Long Context Focus)

## When to Use Claude
Use Claude (Anthropic) when:
- Processing long documents (>50k tokens)
- Detailed reasoning is needed
- Safety-critical applications
- Conversational AI with depth

**Strength:** Long context (200k tokens)
**Cost:** 11-200x more expensive than Gemini 2.5 Flash
**Note:** Gemini 2.5 Pro has 2M tokens context (10x more than Claude)

---

## Available Models

### claude-3-5-haiku (Fast)
**Specs:**
- Cost: $0.80/1M input, $4.00/1M output
- Speed: ~60 tokens/sec
- Context: 200k tokens

**Use for:** Fast Claude tasks with long context

**N8N Configuration:**
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
  "parameters": {
    "model": "claude-3-5-haiku-20241022",
    "options": {
      "temperature": 0.7,
      "maxTokensToSample": 2048
    }
  },
  "credentials": {
    "anthropicApi": {
      "id": "YOUR_ANTHROPIC_CREDENTIAL_ID",
      "name": "Anthropic API"
    }
  }
}
```

---

### claude-3-5-sonnet (RECOMMENDED for Claude)
**Specs:**
- Cost: $3.00/1M input, $15.00/1M output
- Speed: ~40 tokens/sec
- Context: 200k tokens

**Use for:**
- Long document analysis
- Contract review
- Detailed explanations
- Multi-turn conversations

**Example:**
```json
{
  "parameters": {
    "model": "claude-3-5-sonnet-20241022",
    "options": {
      "temperature": 0.7,
      "maxTokensToSample": 4096
    }
  }
}
```

---

### claude-opus-4 (Maximum Quality)
**Specs:**
- Cost: $15/1M input, $75/1M output
- Speed: ~30 tokens/sec
- Context: 200k tokens

**Use for:** Only when maximum quality is needed (rare)

**Warning:** 200x more expensive than Gemini 2.5 Flash

---

## Optimal Use Cases

### 1. Long Document Analysis
```javascript
const prompt = `
Analyze this 50-page contract and identify:
1. Key obligations
2. Potential risks
3. Unusual clauses
4. Recommendations

Contract: {{ $json.documentText }}
`;
```

**Model:** claude-3-5-sonnet
**Why Claude:** Can process 50+ pages in a single request
**Alternative:** Gemini 2.5 Pro (2M context, cheaper)

---

### 2. Detailed Code Review
```javascript
const prompt = `
Review this codebase (2000 lines) and provide:
1. Security vulnerabilities
2. Performance issues
3. Best practice violations
4. Refactoring suggestions

Code: {{ $json.code }}
`;
```

**Model:** claude-3-5-sonnet
**Why Claude:** Deep and detailed review

---

### 3. Multi-Turn Conversation with Memory
```
User Query →
Claude Sonnet (with memoryBufferWindow) →
Response →
Store in memory →
Next query uses full context
```

**Setup with Memory:**
```json
{
  "nodes": [
    {
      "type": "@n8n/n8n-nodes-langchain.chatTrigger"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
      "name": "Claude with Memory"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
      "parameters": {
        "contextWindowLength": 10
      }
    }
  ]
}
```

---

## Comparison: Claude vs Gemini for Long Context

| Feature | Claude Sonnet | Gemini 2.5 Pro | Winner |
|---------|---------------|----------------|--------|
| Context Window | 200k tokens | 2M tokens | 🏆 Gemini (10x more) |
| Input Cost | $3/1M | ~$1.25/1M | 🏆 Gemini (58% less) |
| Output Cost | $15/1M | ~$5/1M | 🏆 Gemini (67% less) |
| Speed | 40 t/s | 60 t/s | 🏆 Gemini (+50%) |
| Reasoning Style | Very detailed | Balanced | Personal preference |

**Conclusion:** For long-context tasks, **Gemini 2.5 Pro is generally better** (more context, cheaper, faster)

**Use Claude when:**
- You prefer Claude's reasoning style
- You have existing Anthropic infrastructure
- Safety/ethics is particularly critical (Constitutional AI)

---

## Claude Best Practices

### 1. System Prompts
Claude responds well to clear system prompts:

```javascript
const systemPrompt = "You are an expert legal analyst with 20 years of experience in commercial contracts.";
const userPrompt = "Analyze this contract...";
```

### 2. XML-Style Structured Prompts
Claude performs better with XML structure:

```xml
<document>
{{ $json.text }}
</document>

<instructions>
1. Summarize the document
2. Extract key points
3. Identify risks
</instructions>

<output_format>
JSON with structure:
{
  "summary": "...",
  "key_points": [...],
  "risks": [...]
}
</output_format>
```

### 3. Chain of Thought
Encourage detailed reasoning:

```
"Think step-by-step, explaining your reasoning for each point."
```

---

## Advanced Configuration

### Temperature by Task Type

**Document Analysis:**
```json
{"temperature": 0.5}
```

**Creative Content:**
```json
{"temperature": 0.8}
```

**Complex Reasoning:**
```json
{"temperature": 0.7}
```

### Max Tokens
```json
{
  "maxTokensToSample": 1024,  // Short responses
  "maxTokensToSample": 4096,  // Standard analysis
  "maxTokensToSample": 8192   // Detailed output
}
```

---

## Integration Patterns

### Pattern 1: Claude for Deep Analysis
```
Trigger (new document) →
Extract text →
Claude Sonnet (deep analysis) →
Structured output →
Database storage →
Alert if risks found
```

### Pattern 2: Gemini → Claude Review
```
Gemini 2.5 Flash (fast draft) →
Claude Sonnet (review and refine) →
Final output
```

**Use case:** Content creation + quality assurance

### Pattern 3: Long Document Pipeline
```
Upload document (200 pages) →
Split in chunks (20k tokens each) →
Parallel Claude processing →
Merge and summarize →
Final report
```

---

## Comparative Costs

### Scenario: Analysis of 100 Contracts (50k tokens each)

| Model | Input (5M tokens) | Output (1M tokens) | Total |
|---------|-------------------|-------------------|--------|
| **Gemini 2.5 Pro** | $6.25 | $5.00 | **$11.25** |
| **Claude Sonnet** | $15.00 | $15.00 | **$30.00** |
| **Claude Opus** | $75.00 | $75.00 | **$150.00** |

**Gemini Savings:** 63% vs Claude Sonnet, 92% vs Claude Opus

---

## When NOT to Use Claude

❌ **Avoid Claude for:**
- Short content (< 10k tokens) → Use Gemini 2.5 Flash
- High volume processing → Too expensive
- Simple categorization → Overkill
- Vision tasks → Gemini 2.5 Pro is better
- Limited budget → Gemini is more cost-effective

✅ **Use Claude only when:**
- Claude's reasoning style is preferred
- Existing Anthropic infrastructure
- Safety/ethics are top priority
- Gemini is not available/acceptable

---

## Constitutional AI (Safety)

Claude is built with **Constitutional AI** - excellent for:
- Healthcare applications
- Legal document processing
- Content moderation
- Educational content
- HR/sensitive data

**Safety-Critical Example:**
```javascript
const prompt = `
Analyze this patient feedback and identify:
- Serious medical complaints
- Safety issues
- Privacy issues

IMPORTANT: Flag ANY potential safety risk.

Feedback: {{ $json.patientFeedback }}
`;
```

**Model:** claude-3-5-sonnet
**Why:** Constitutional AI for safety

---

## Multi-Turn Conversation Example

### Chatbot Setup with Memory
```json
{
  "workflow": {
    "nodes": [
      {
        "type": "@n8n/n8n-nodes-langchain.chatTrigger",
        "name": "Chat Interface"
      },
      {
        "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
        "name": "Claude Sonnet",
        "parameters": {
          "model": "claude-3-5-sonnet-20241022"
        }
      },
      {
        "type": "@n8n/n8n-nodes-langchain.memoryBufferWindow",
        "name": "Conversation Memory",
        "parameters": {
          "contextWindowLength": 5
        }
      },
      {
        "type": "@n8n/n8n-nodes-langchain.chainConversation",
        "name": "Conversation Chain"
      }
    ]
  }
}
```

**Benefit:** Claude maintains deep conversation context

---

## Limitations to Consider

### 1. Context Window vs Gemini
- Claude: 200k tokens
- Gemini 2.5 Pro: 2M tokens (10x higher)

**Implication:** Gemini can process much longer documents

### 2. Speed
- Claude Sonnet: ~40 t/s
- Gemini 2.5 Pro: ~60 t/s

**Implication:** Gemini 50% faster

### 3. Costs
- Claude: 2.4x more expensive than Gemini 2.5 Pro
- Claude Opus: 12x more expensive

---

## Decision Framework

### Use Claude when:
```javascript
if (task.requiresConstitutionalAI ||
    team.prefersClaudeStyle ||
    existing.infrastructure === "Anthropic") {
  return "claude-3-5-sonnet";
}

// Otherwise, default to Gemini
return "gemini-2.5-pro";
```

### Decision Flowchart
```
Need long document processing?
├─ Yes → Context needed?
│   ├─ >200k tokens → Gemini 2.5 Pro (2M context)
│   └─ <200k tokens → Claude Sonnet OK
└─ No → Gemini 2.5 Flash (default)
```

---

## Claude Workflow Template

### Document Analysis
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.webhook",
      "name": "Document Upload"
    },
    {
      "type": "n8n-nodes-base.extractFromFile",
      "name": "Extract Text"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatAnthropic",
      "name": "Claude Analysis",
      "parameters": {
        "model": "claude-3-5-sonnet-20241022",
        "options": {
          "temperature": 0.6
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.chainLlm",
      "name": "Analyze Document"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "name": "Structure Output"
    },
    {
      "type": "n8n-nodes-base.airtable",
      "name": "Save Analysis"
    }
  ]
}
```

---

## Monitoring & Optimization

### Metrics
- **Quality score** (vs Gemini)
- **Processing time** (per document)
- **Cost per analysis**
- **Error rate**

### A/B Testing
```
Test 100 documents:
- 50 with Claude Sonnet
- 50 with Gemini 2.5 Pro

Compare:
- Output quality
- Processing time
- Total cost
```

**Expected Result:** Gemini wins on cost/speed, Claude on style

---

## Common Mistakes

### ❌ Mistake 1: Using Claude for simple tasks
**Problem:** 8x more expensive than Gemini for same results

**Solution:** Claude only for long/complex documents

### ❌ Mistake 2: Not using long context
**Problem:** Paying for 200k context but using only 10k

**Solution:** If < 50k tokens, consider Gemini

### ❌ Mistake 3: Unstructured Prompts
**Problem:** Claude performs better with structure

**Solution:** Use XML tags for clarity

---

## Integration with N8N Tools

### Claude + Tool Workflow
```json
{
  "type": "@n8n/n8n-nodes-langchain.agent",
  "parameters": {
    "model": "claude-3-5-sonnet"
  }
}
```

**Tools:**
- `toolWorkflow` (call other workflows)
- `toolHttpRequest` (API calls)
- Custom tools

**Note:** OpenAI generally better for function calling

---

## Conclusion: Claude vs Gemini

### Choose Claude if:
✅ Detailed reasoning style preferred
✅ Constitutional AI needed (safety)
✅ Team already uses Anthropic
✅ Budget is not a primary constraint

### Choose Gemini 2.5 Pro if:
✅ Need context >200k tokens (up to 2M)
✅ Budget-conscious (63% savings)
✅ Speed important (+50%)
✅ Long documents + vision

---

## Final Recommendation

**For most long-context use cases:**
```
Default: Gemini 2.5 Pro
- Cheaper (63%)
- Faster (50%)
- Context 10x higher (2M vs 200k)

Alternative: Claude Sonnet
- Only if style preference
- Or existing infrastructure
- Or Constitutional AI critical
```

**Optimal Strategy:**
1. Try Gemini 2.5 Pro first
2. If quality insufficient → Test Claude
3. Compare cost/quality tradeoff
4. Choose based on results

**Expected Savings:** 60-90% using Gemini as default
