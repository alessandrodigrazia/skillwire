# Perplexity Guide (SPECIALIZED - Web Search Focus)

## When to Use Perplexity
Use Perplexity when you need **real-time web information**:
- Current events and news
- Information about recent products
- Up-to-date market research
- Fact-checking with sources
- Data beyond model training cutoff

**Unique Feature:** Integrated web search + AI synthesis
**Limitation:** Not available as a native LangChain node in n8n

---

## Available Models

### sonar (Standard)
**Specs:**
- Cost: ~$1/1M tokens (estimated)
- Speed: ~60 tokens/sec
- Features: Web search + AI synthesis
- Sources: Includes citations

**Use for:**
- General research
- Current events
- Quick fact-checking

---

### sonar-pro (Enhanced)
**Specs:**
- Cost: ~$3/1M tokens (estimated)
- Speed: ~50 tokens/sec
- Features: Enhanced accuracy + more sources
- Depth: More in-depth analysis

**Use for:**
- Professional research
- High-stakes fact-checking
- Comprehensive analysis

---

## N8N Integration (via HTTP Request)

Perplexity has no dedicated LangChain node, use **HTTP Request**:

### Base Setup
```json
{
  "type": "n8n-nodes-base.httpRequest",
  "parameters": {
    "method": "POST",
    "url": "https://api.perplexity.ai/chat/completions",
    "authentication": "genericCredentialType",
    "genericAuthType": "httpHeaderAuth",
    "sendBody": true,
    "contentType": "application/json",
    "bodyParameters": {
      "parameters": [
        {
          "name": "model",
          "value": "sonar"
        },
        {
          "name": "messages",
          "value": "=[{\"role\": \"user\", \"content\": \"{{ $json.query }}\"}]"
        }
      ]
    }
  },
  "credentials": {
    "httpHeaderAuth": {
      "id": "YOUR_CREDENTIAL_ID",
      "name": "Perplexity API Key"
    }
  }
}
```

### Credential Setup
1. Create an **HTTP Header Auth** credential
2. **Header Name:** `Authorization`
3. **Header Value:** `Bearer YOUR_PERPLEXITY_API_KEY`

---

## Optimal Use Cases

### 1. Current Events Summary
```javascript
const query = "What are the latest AI developments this week?";
```

**Response:** Up-to-date information with source links

**Alternative without Perplexity:**
- Standard models → outdated info (training cutoff)

---

### 2. Product Research
```javascript
const query = `
Find the most recent information about {{ $json.productName }}.
Include: features, pricing, reviews, release date.
`;
```

**Benefit:** Always up-to-date data from the web

---

### 3. Market Research
```javascript
const query = `
Research current trends in the {{ $json.industry }} sector.
Focus on: market size, key players, recent news.
`;
```

**Value:** Real-time competitive intelligence

---

### 4. Fact-Checking with Sources
```javascript
const query = `
Verify this claim: "{{ $json.claim }}"
Provide reliable sources.
`;
```

**Output:** Verification + links to original sources

---

### 5. Competitor Analysis
```javascript
const query = `
Analyze {{ $json.competitorName }}:
- Recent product launches
- Funding and acquisitions
- Leadership changes
- News from the last 30 days
`;
```

---

## Response Format

### Perplexity Response Structure
```json
{
  "id": "response-id",
  "model": "sonar",
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "Response with numbered citations [1], [2], etc."
    },
    "finish_reason": "stop"
  }],
  "citations": [
    "https://source1.com/article",
    "https://source2.com/page",
    "https://source3.com/news"
  ]
}
```

### Extracting Response in N8N
```javascript
// In Code node after HTTP Request
const response = $json.choices[0].message.content;
const citations = $json.citations || [];

return [{
  json: {
    answer: response,
    sources: citations
  }
}];
```

---

## Integration Patterns

### Pattern 1: Research → Content Generation
```
Perplexity (research topic) →
Store results in Airtable →
Gemini 2.5 Flash (generate content from research) →
Publish
```

**Benefits:**
- Current info (Perplexity)
- Cost-effective generation (Gemini)
- **Savings:** 89% vs using Perplexity for both

**Example workflow:**
```json
{
  "nodes": [
    {
      "name": "1. Research with Perplexity",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "https://api.perplexity.ai/chat/completions",
        "method": "POST",
        "body": {
          "model": "sonar",
          "messages": [{
            "role": "user",
            "content": "Research {{ $json.topic }}"
          }]
        }
      }
    },
    {
      "name": "2. Store Research in Airtable",
      "type": "n8n-nodes-base.airtable",
      "parameters": {
        "operation": "create"
      }
    },
    {
      "name": "3. Generate Content with Gemini",
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
      "parameters": {
        "modelName": "models/gemini-2.5-flash"
      }
    }
  ]
}
```

---

### Pattern 2: Daily News Digest
```
Schedule Trigger (daily 8 AM) →
Perplexity (news on specific topics) →
Gemini (summarize + email format) →
Gmail (send digest)
```

**Use case:** Automated personalized press review

---

### Pattern 3: Competitive Intelligence
```
Schedule (weekly) →
Split (competitor list) →
For each competitor:
  → Perplexity (latest news/updates) →
  → Gemini (analyze + scoring) →
Merge results →
Report in Google Sheets →
Slack notification
```

---

### Pattern 4: Research Cache Strategy
```
User query →
Check Airtable cache (< 24h old?) →
  IF found → Return cached
  IF not found →
    → Perplexity (fresh research) →
    → Cache in Airtable (with timestamp) →
    → Return result
```

**Benefit:** Reduces duplicate Perplexity calls
**Savings:** 60-80% on costs for repeated queries

---

## Cost Optimization

### Strategy 1: Research Batch
Instead of individual queries, batch them:

```javascript
const query = `
Research these 5 topics:
1. {{ $json.topic1 }}
2. {{ $json.topic2 }}
3. {{ $json.topic3 }}
4. {{ $json.topic4 }}
5. {{ $json.topic5 }}

For each, provide: summary + 2-3 key sources.
`;
```

**Savings:** 1 API call vs 5 (80% savings)

---

### Strategy 2: Perplexity → Gemini Pipeline
```
Input: General topic →
Perplexity: Initial research (1 query) →
Gemini: Generate 10 content pieces from research →
Output: 10 articles based on 1 research

Cost breakdown:
- Perplexity: $3 (1 query)
- Gemini: $0.50 (10 generations)
Total: $3.50

vs.

- Perplexity for each piece: $30 (10 queries)
Savings: 88%
```

---

### Strategy 3: Intelligent Caching
```javascript
// Caching logic
const cacheKey = hash(query);
const cached = await airtable.search({ key: cacheKey });

if (cached && isRecent(cached.timestamp, hours=24)) {
  return cached.result;
} else {
  const result = await perplexity.search(query);
  await airtable.create({ key: cacheKey, result, timestamp: now() });
  return result;
}
```

**Savings:** 70-90% for repeated queries

---

## When to Use vs NOT Use

### USE Perplexity when:
- You need **post-training cutoff** info (> Jan 2025)
- News and current events
- Recent product info (launches in the last few months)
- Real-time market intelligence
- Verification with sources is required

### DO NOT use Perplexity when:
- General info already in training data
- Content generation (use Gemini - cheaper)
- Structured data extraction (use GPT-4o/Gemini)
- High volume without caching (too expensive)
- Non time-sensitive info

---

## Cost Comparison

### Scenario: 1000 Research Queries

| Strategy | Cost | Notes |
|----------|------|-------|
| **Perplexity only** | ~$3000 | 1000 queries x $3 |
| **Perplexity + Cache (50% hit)** | ~$1500 | 500 unique queries |
| **Perplexity + Gemini content** | ~$350 | 100 research + 1000 content gen |
| **Standard LLM (no search)** | $37.50 | Gemini 2.5 Flash (but outdated info) |

**Conclusion:** Use Perplexity strategically, not for everything

---

## Perplexity Template Workflow

### Research to Content Pipeline
```json
{
  "name": "Perplexity Research → Gemini Content",
  "nodes": [
    {
      "name": "Schedule: Daily Research",
      "type": "n8n-nodes-base.scheduleTrigger",
      "parameters": {
        "rule": {
          "interval": [{"field": "days", "daysInterval": 1}]
        }
      }
    },
    {
      "name": "Topics to Research",
      "type": "n8n-nodes-base.set",
      "parameters": {
        "assignments": {
          "assignments": [
            {"name": "topic", "value": "Latest AI developments"}
          ]
        }
      }
    },
    {
      "name": "Perplexity Research",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "url": "https://api.perplexity.ai/chat/completions",
        "method": "POST",
        "sendBody": true,
        "bodyParameters": {
          "parameters": [
            {
              "name": "model",
              "value": "sonar"
            },
            {
              "name": "messages",
              "value": "=[{\"role\": \"user\", \"content\": \"{{ $json.topic }}\"}]"
            }
          ]
        }
      }
    },
    {
      "name": "Extract Research Data",
      "type": "n8n-nodes-base.code",
      "parameters": {
        "jsCode": "const response = $json.choices[0].message.content;\nconst sources = $json.citations || [];\n\nreturn [{ json: { research: response, sources } }];"
      }
    },
    {
      "name": "Generate Content with Gemini",
      "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
      "parameters": {
        "modelName": "models/gemini-2.5-flash"
      }
    },
    {
      "name": "Store in Airtable",
      "type": "n8n-nodes-base.airtable",
      "parameters": {
        "operation": "create"
      }
    }
  ]
}
```

---

## Best Practices

### 1. Query Specificity
**Vague:**
```
"Tell me about AI"
```

**Specific:**
```
"What are the major AI product launches in December 2024? Focus on: company, product name, key features, and launch date."
```

### 2. Source Validation
Always extract and verify citations:

```javascript
// Code node after Perplexity
const citations = $json.citations || [];

// Filter only trusted domains
const trustedSources = citations.filter(url =>
  url.includes('techcrunch.com') ||
  url.includes('reuters.com') ||
  url.includes('bloomberg.com')
);

return [{ json: {
  answer: $json.choices[0].message.content,
  trustedSources
}}];
```

### 3. Rate Limiting
Implement delays for API calls:

```javascript
// After each Perplexity call
await new Promise(resolve => setTimeout(resolve, 2000)); // 2s delay
```

---

## Limitations

### 1. No Native LangChain Node
- You must use HTTP Request manually
- No direct integration with AI Agents
- More complex setup vs Gemini/OpenAI

### 2. Variable Costs
- Pricing not always transparent
- Cost per query can vary
- Difficult to budget precisely

### 3. Rate Limits
- Limits on queries/min
- Possible throttling
- Retry logic required

---

## Alternatives to Perplexity

### Option 1: Gemini + Google Search API
```
Google Custom Search API (search) →
Gemini 2.5 Flash (synthesize results)
```

**Pro:** More control, potentially cheaper
**Con:** More complex setup

### Option 2: Web Scraping + Gemini
```
HTTP Request (fetch web pages) →
Extract from File (parse HTML) →
Gemini (analyze content)
```

**Pro:** Maximum control
**Con:** Fragile (site changes), legal issues

### Option 3: RSS Feeds + Gemini
```
RSS Feed Read (news sources) →
Gemini (analyze and synthesize)
```

**Pro:** Free, reliable
**Con:** Only sources with RSS, not query-based

---

## Conclusion: When Perplexity Is Worth It

### Use Perplexity if:
- Budget OK for professional research
- Real-time info critical
- Verified sources needed
- Time-sensitive intelligence
- Alternatives insufficient

### Avoid Perplexity if:
- Limited budget
- Non time-sensitive info
- High volume queries
- Alternatives (RSS, scraping) sufficient

---

## Recommended Strategy

**Hybrid Approach:**
```
1. Daily/Weekly Research: Perplexity
   - Market updates
   - Competitor news
   - Industry trends

2. Content Generation: Gemini
   - Articles
   - Social posts
   - Summaries

3. Cache Everything: Airtable
   - Avoid duplicate queries
   - Build knowledge base
```

**ROI Optimization:**
- 1 Perplexity query → 10+ content pieces (Gemini)
- Cache results → Reuse for 24-48h
- Batch queries when possible

**Expected Savings:** 70-90% vs using Perplexity for everything

---

## Summary Table

| Aspect | Perplexity | Gemini 2.5 Flash | When to Use |
|--------|-----------|------------------|-------------|
| **Real-time Info** | Excellent | Training cutoff | Current events → Perplexity |
| **Cost** | $$$ High | $ Low | General tasks → Gemini |
| **Sources** | Provided | No citations | Need verification → Perplexity |
| **Content Gen** | Okay | Excellent | Bulk content → Gemini |
| **Speed** | Medium | Fast | High volume → Gemini |

**Best Practice:** Perplexity for research, Gemini for production
