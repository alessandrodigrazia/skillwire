# OpenAI Guide (SECONDARY - Accuracy Focus)

## When to Use OpenAI
Use OpenAI when **accuracy is more important than cost**:
- Complex structured data extraction
- High-quality code generation
- Advanced function calling
- Existing OpenAI infrastructure

**Cost:** 2-33x more expensive than Gemini 2.5 Flash
**Accuracy:** Slightly higher for structured outputs

---

## Available Models

### gpt-4o-mini (RECOMMENDED for OpenAI)
**Specs:**
- Cost: $0.15/1M input, $0.60/1M output
- Speed: ~70 tokens/sec
- Context: 128k tokens

**Use for:**
- Structured data extraction
- Fast OpenAI tasks
- Reliable JSON generation
- API integration

**N8N Configuration:**
```json
{
  "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
  "parameters": {
    "model": "gpt-4o-mini",
    "options": {
      "temperature": 0.7,
      "maxTokens": 2000
    }
  },
  "credentials": {
    "openAiApi": {
      "id": "YOUR_OPENAI_CREDENTIAL_ID",
      "name": "OpenAI Account"
    }
  }
}
```

---

### gpt-4o (High Accuracy)
**Specs:**
- Cost: $2.50/1M input, $10.00/1M output
- Speed: ~50 tokens/sec
- Context: 128k tokens
- Vision capabilities

**Use for:**
- Maximum accuracy required
- Complex code generation
- Critical structured output
- Image analysis

**Example:**
```json
{
  "parameters": {
    "model": "gpt-4o",
    "options": {
      "temperature": 0.5,
      "maxTokens": 4000
    }
  }
}
```

---

### o1-preview (Advanced Reasoning)
**Specs:**
- Cost: $15/1M input, $60/1M output
- Speed: ~20 tokens/sec
- Context: 128k tokens

**Use for:**
- Mathematical reasoning
- Complex problem-solving
- Multi-step logic
- Scientific tasks

**Warning:** 100-200x more expensive than Gemini 2.5 Flash

---

## Optimal Use Cases

### 1. Invoice/Document Parsing
```javascript
const prompt = `
Extract data from this invoice in JSON format.

Invoice text: {{ $json.invoiceText }}

Required schema:
{
  "invoice_number": "string",
  "date": "YYYY-MM-DD",
  "total": "number",
  "supplier": "string",
  "items": [{"description": "...", "amount": 0}]
}
`;
```

**Model:** gpt-4o-mini
**Temperature:** 0.1-0.2
**Why OpenAI:** Excellent for precise structured extraction

---

### 2. Code Generation
```javascript
const prompt = `
Generate a Python function that {{ $json.requirements }}.

Requirements:
- Include docstring
- Add type hints
- Error handling
- Unit tests
`;
```

**Model:** gpt-4o
**Temperature:** 0.5
**Why OpenAI:** Superior code quality

---

### 3. Complex JSON Extraction
```javascript
const prompt = `
Extract all companies, people, dates, and amounts from this text.

Text: {{ $json.text }}

Format:
{
  "companies": [{"name": "", "context": ""}],
  "people": [{"name": "", "role": ""}],
  "dates": [{"date": "", "event": ""}],
  "amounts": [{"value": 0, "currency": "", "context": ""}]
}
`;
```

**Model:** gpt-4o-mini
**Temperature:** 0.2
**Response Format:** `{"type": "json_object"}`

---

## Function Calling (OpenAI Strength)

OpenAI excels at function calling with AI Agents:

### Agent Setup with Tools
```json
{
  "type": "@n8n/n8n-nodes-langchain.agent",
  "parameters": {
    "promptType": "define",
    "text": "={{ $json.query }}"
  }
}
```

**Connectable Tools:**
- `toolHttpRequest` (API calls)
- `toolWorkflow` (sub-workflows)
- `toolCalculator` (calculations)
- Custom tools

**OpenAI Advantages:**
- More reliable function calling
- Better parameter interpretation
- Superior error handling

---

## Advanced Configuration

### JSON Mode (Guarantees JSON Output)
```json
{
  "options": {
    "response_format": {"type": "json_object"},
    "temperature": 0.3
  }
}
```

**Important:** You must specify in the prompt that you want JSON.

---

### Few-Shot Examples (Improves Accuracy)
```javascript
const prompt = `
Extract data in the following format.

Example 1:
Input: "Invoice #123 from Acme Corp for €500"
Output: {"number": "123", "supplier": "Acme Corp", "amount": 500}

Example 2:
Input: "Invoice #456 from Beta Ltd for €1200"
Output: {"number": "456", "supplier": "Beta Ltd", "amount": 1200}

Now extract from:
{{ $json.text }}
`;
```

**Result:** +15-25% accuracy

---

## Cost Comparison with Gemini

### Scenario: 100k Structured Extractions

| Model | Input Cost | Output Cost | Total |
|---------|-----------|-------------|--------|
| **Gemini 2.5 Flash** | $7.50 | $30.00 | **$37.50** |
| **GPT-4o-mini** | $15.00 | $60.00 | **$75.00** |
| **GPT-4o** | $250.00 | $1000.00 | **$1250.00** |

**Gemini Savings:** 50% vs GPT-4o-mini, 97% vs GPT-4o

---

## When NOT to Use OpenAI

❌ **Avoid OpenAI for:**
- Simple categorization (use Gemini 2.5 Flash - 50% cheaper)
- High volume content generation (too expensive)
- Multi-language tasks (Gemini better)
- Image analysis (Gemini 2.5 Pro superior and cheaper)

✅ **Use OpenAI only when:**
- Gemini 2.5 Flash accuracy < 90%
- Gemini 2.5 Pro accuracy < 95%
- Function calling is critical
- Existing OpenAI infrastructure

---

## OpenAI Best Practices

### 1. Temperature by Task Type

**Data Extraction:**
```json
{"temperature": 0.1}
```

**General Content:**
```json
{"temperature": 0.7}
```

**Creative:**
```json
{"temperature": 0.9}
```

### 2. Max Tokens Optimization
```json
{
  "maxTokens": 256   // Categorization
  "maxTokens": 1024  // Standard extraction
  "maxTokens": 4096  // Long generation
}
```

**Savings:** Limiting tokens reduces output costs

### 3. Retry Logic
```javascript
// In Code node after OpenAI
let retries = 0;
while (retries < 3) {
  try {
    const result = callOpenAI();
    if (isValidJSON(result)) break;
  } catch (e) {
    retries++;
  }
}
```

---

## Integration Patterns

### Pattern 1: Gemini → OpenAI Fallback
```
Input →
Gemini 2.5 Flash (fast, cheap) →
IF (confidence < 0.9) →
  GPT-4o-mini (accurate) →
  Result
ELSE →
  Result (Gemini)
```

**Benefit:** 80% solved by Gemini (cheap), 20% by OpenAI (accurate)
**Savings:** ~60% on total costs

### Pattern 2: Batch + OpenAI
```
1000 items →
Batch in groups of 10 →
GPT-4o-mini (process batch) →
Merge results
```

**Benefit:** Reduces API calls from 1000 to 100

### Pattern 3: OpenAI for Validation
```
Gemini (generate) →
OpenAI (validate/refine) →
Final output
```

**Use case:** Content generation + quality control

---

## Vision Capabilities (GPT-4o)

### Image Analysis
```javascript
const prompt = `
Analyze this image and describe:
1. Main objects
2. Visible text (OCR)
3. Dominant colors
4. Possible use/context

Reply in JSON.
`;
```

**Configuration:**
```json
{
  "model": "gpt-4o",
  "options": {
    "temperature": 0.6,
    "maxTokens": 1024
  }
}
```

**Note:** Include image as binary data from previous node
**Alternative:** Gemini 2.5 Pro often better for vision (cheaper)

---

## Embeddings (For RAG)

### OpenAI Embeddings Node
```json
{
  "type": "@n8n/n8n-nodes-langchain.embeddingsOpenAi",
  "parameters": {
    "model": "text-embedding-3-small"
  },
  "credentials": {
    "openAiApi": {
      "id": "xxx",
      "name": "OpenAI"
    }
  }
}
```

**Costs:**
- text-embedding-3-small: $0.02/1M tokens
- text-embedding-3-large: $0.13/1M tokens

**Use case:** Vector search, RAG systems, similarity search

---

## Monitoring & Optimization

### Metrics to Track
1. **Cost per task type**
2. **Accuracy rate** (vs Gemini)
3. **Average latency**
4. **Error/retry rate**

### Optimization Loop
```
1. Start: Gemini 2.5 Flash (baseline)
2. Measure: Accuracy < 90%?
3. Test: GPT-4o-mini (sample 100 items)
4. Compare: Accuracy vs Cost
5. Decide: Switch if gain > 10% and budget OK
```

---

## Common Mistakes

### ❌ Mistake 1: Using GPT-4o for everything
**Problem:** Costs 33x higher than Gemini

**Solution:**
```
Gemini 2.5 Flash (default) →
If insufficient → GPT-4o-mini →
If still insufficient → GPT-4o
```

### ❌ Mistake 2: Not specifying JSON in prompt
**Problem:** Unstructured output even with `json_object` mode

**Solution:**
```javascript
const prompt = `
Reply ONLY in valid JSON format.
Schema: {"field1": "value", "field2": 123}
...
`;
```

### ❌ Mistake 3: Temperature too high for extraction
**Problem:** Inconsistent outputs

**Solution:** Temperature 0.1-0.3 for deterministic tasks

---

## Recommended Strategy

### Decision Tree
```javascript
function selectModel(task) {
  // Default: always Gemini
  if (task.type === "simple") {
    return "gemini-2.5-flash";
  }

  // Upgrade for accuracy
  if (task.structuredOutput && task.criticalAccuracy) {
    return "gpt-4o-mini";
  }

  // Premium only if necessary
  if (task.maxAccuracy && task.budgetOK) {
    return "gpt-4o";
  }

  // Safe default
  return "gemini-2.5-flash";
}
```

---

## OpenAI Workflow Template

### Structured Extraction
```json
{
  "nodes": [
    {
      "type": "n8n-nodes-base.httpRequest",
      "name": "Fetch Documents"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
      "name": "OpenAI GPT-4o-mini",
      "parameters": {
        "model": "gpt-4o-mini",
        "options": {
          "temperature": 0.2,
          "response_format": {"type": "json_object"}
        }
      }
    },
    {
      "type": "@n8n/n8n-nodes-langchain.chainLlm",
      "name": "Extract Structured Data"
    },
    {
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "name": "Parse JSON"
    },
    {
      "type": "n8n-nodes-base.code",
      "name": "Validate & Clean"
    }
  ]
}
```

---

## Summary Decision

### Use OpenAI (GPT-4o-mini) when:
✅ Critical structured data extraction
✅ Gemini accuracy < 90%
✅ Function calling needed
✅ Budget allows 2x cost vs Gemini

### Use OpenAI (GPT-4o) when:
✅ Gemini + GPT-4o-mini insufficient
✅ Mission-critical code generation
✅ Budget allows 33x cost vs Gemini

### Do NOT use OpenAI when:
❌ Simple tasks (categorization, tags)
❌ High volume / limited budget
❌ Multi-language (Gemini better)
❌ Gemini already meets requirements

---

## Conclusion

**Optimal Strategy:**
1. **Default:** Gemini 2.5 Flash (90% of cases)
2. **Upgrade:** Gemini 2.5 Pro (high complexity)
3. **Specialized:** GPT-4o-mini (only if Gemini < 90% accuracy)
4. **Premium:** GPT-4o (very rare, only mission-critical)

**Expected Savings:** 50-80% on AI costs following this hierarchy

---

**Next Steps:**
- Test Gemini 2.5 Flash first
- Measure accuracy
- Switch to OpenAI only if necessary
- Monitor cost/accuracy tradeoff
