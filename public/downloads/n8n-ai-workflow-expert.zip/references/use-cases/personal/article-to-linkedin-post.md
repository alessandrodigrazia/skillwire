# Personal Use Case: Email Article to LinkedIn Post

## 1. Workflow Objective

**Purpose:** Fully automate the content creation process that transforms an article, received via email, into a high-quality LinkedIn post ready for publication. The workflow is designed to be robust, intelligent, and to maintain high quality standards through a system of AI agents.

This use case is based on your workflow `01. Article → Post LinkedIn (powered by Gemini).json`.

## 2. Technology Stack Used

*   **Trigger:** `Schedule Trigger` (to run the check periodically).
*   **Input:** `Gmail` (to read emails with a specific label).
*   **Database/Logging:** `Airtable` (to track published posts and provide historical context).
*   **AI:** `Google Gemini` (used in multiple roles: categorization, writing, and quality assurance).
*   **Output:** `LinkedIn` (for post publishing).

## 3. Flow Logic (Multi-Step Agent System)

The workflow implements a sophisticated AI-based editorial assembly line.

### **Step 1: Content Identification**
*   **`Schedule Trigger` Node:** Starts the workflow at regular intervals (e.g., every 2 hours).
*   **`Gmail (GetAll)` Node:** Searches for all emails with the label `"ToConvert"`.
*   **`Code` Node:** If multiple emails are found, selects only the oldest one to ensure processing in chronological order (FIFO - First-In, First-Out).

### **Step 2: Analysis and Categorization**
*   **`Google Gemini` (Categorizer Agent) Node:** Reads the article text and classifies it into a predefined category (e.g., `ANNOUNCEMENT`, `ANALYSIS`, `TUTORIAL`, `GENERAL`).

### **Step 3: Context Collection**
*   **`Airtable (Search)` Node:** Searches the published posts table for the last 5 articles in the same category identified in the previous step.
*   **`Code` Node:** Consolidates these historical posts into a single text block (`<RECENT_POST_HISTORY>`) to pass to the writer agent to avoid repetitions.

### **Step 4: Draft Generation**
*   **`Switch` Node:** Routes the flow to a specialized "copywriter agent" based on the category. Each switch branch leads to a `Google Gemini` node with a different prompt, optimized for writing announcement, analysis, etc. type posts.
*   **`Google Gemini` (Copywriter Agent) Node:** Receives the article text and the post history. Its task is to generate the first draft of the LinkedIn post.

### **Step 5: Quality Assurance (QA)**
*   **`Google Gemini` (QA Agent - "Editor-in-Chief") Node:** Receives the generated draft and compares it against the original text and a quality checklist (defined in the prompt). It decides whether the post is `APPROVED` or needs a `REVISION`, and in the latter case corrects it directly. The output is a JSON with the decision and the final text (`final_post_text`).

### **Step 6: Publishing and Logging**
*   **`LinkedIn (Post)` Node:** Publishes the approved `final_post_text` on the company page.
*   **`Airtable (Create)` Node:** Logs the new post in the database, saving the text, category, and LinkedIn post URN.

### **Step 7: Cleanup**
*   **`Gmail (Remove/Add Labels)` Nodes:** Removes the `"ToConvert"` label from the original email and adds the `"Converted"` label, ensuring it will never be processed again.

## 4. Key Points and Best Practices

*   **Specialized Agent System:** Using multiple Gemini nodes with different roles (Categorizer, Copywriter, QA) is an advanced pattern that ensures much higher output quality compared to a single monolithic prompt.
*   **Contextual Generation:** Retrieving history from Airtable (Step 3) is a fundamental technique. It provides the AI model with context about recent publications, pushing it to create more original content and vary analysis angles.
*   **State Management via Labels:** Using Gmail labels to manage an email's lifecycle (`ToConvert` -> `Converted`) is a simple and robust best practice for flow control in asynchronous workflows.
*   **Separation Between Trigger and Logic:** The workflow does not trigger on every email but is scheduled. This allows it to process emails one at a time in a controlled manner, avoiding system overload or race conditions.
