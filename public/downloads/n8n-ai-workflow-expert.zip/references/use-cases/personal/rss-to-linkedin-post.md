# Personal Use Case: RSS Feed to LinkedIn Post (with Research)

## 1. Workflow Objective

**Purpose:** Create a semi-automatic content curation engine that monitors multiple news sources via RSS feeds, uses an AI to select the most strategic and original articles, enriches them with in-depth web research, and finally generates a LinkedIn post that is not a simple summary but an original, context-rich analysis.

This use case, based on your workflow `03. RSS Feed → Post LinkedIn (powered by Gemini).json`, represents an advanced editorial system.

## 2. Technology Stack Used

*   **Trigger:** `RSS Feed Read Trigger` (multiple instances for different sources).
*   **Database/Logging:** `Airtable` (for deduplication and post history).
*   **AI (Analysis and Writing):** `Google Gemini` (in multiple roles).
*   **AI (Research):** `Perplexity` (called via `HttpRequest` for content enrichment).
*   **Output:** `LinkedIn`.

## 3. Flow Logic (Editorial Pattern with Enrichment)

The workflow simulates a real editorial process.

### **Step 1: Aggregation and Deduplication**
*   **`RSS Feed Read Trigger` Nodes:** Multiple triggers, one for each news source (e.g., TechCrunch, VentureBeat), monitor feeds at different times to distribute the load.
*   **`Airtable (Search)` Node:** As soon as a new article is detected, the workflow immediately checks if the URL is already in the database to discard duplicates.

### **Step 2: Editorial Selection (AI Curation)**
*   **`Airtable (Search)` Node:** Retrieves the history of the last 10 published posts to provide context about our editorial line.
*   **`Google Gemini` ("Editor-in-Chief" Agent) Node:** This is the first, crucial AI step. The agent receives the new article and the post history. Its task is to decide whether the article is sufficiently **interesting, strategic, and original** compared to what has already been published. If the article is approved, the agent also extracts key topics or questions that deserve further exploration.

### **Step 3: Enrichment with External Research**
*   **`HttpRequest` (Perplexity call) Node:** The questions or topics identified by the "Editor-in-Chief" are sent to the Perplexity API. Perplexity performs a web search to gather additional information, recent data, statistics, or alternative viewpoints not present in the original article.

### **Step 4: Enriched Post Generation**
*   **`Google Gemini` ("Strategic Copywriter" Agent) Node:** This second AI agent receives a very rich context:
    1.  The original article text.
    2.  The Perplexity research results.
    3.  The recent post history (to maintain a consistent style).
    Its task is to write a LinkedIn post that does not simply summarize the article but puts it in perspective, enriches it with research data, and offers an original analysis.

### **Step 5: Quality Assurance and Publishing**
*   **`Google Gemini` (QA Agent) Node:** A final quality check on the final text.
*   **`LinkedIn (Post)` Node:** Publishes the final post.
*   **`Airtable (Create)` Node:** Logs the post in the database for future context analysis.

## 4. Key Points and Best Practices

*   **Curation Workflow, Not Just Republishing:** The true power of this workflow is not automating writing but automating the **editorial process**. AI is used first to **select** and then to **enrich** content, a much more sophisticated pattern.
*   **Enrichment Through Research (Enhanced RAG):** Using a research AI like Perplexity to add external information is an advanced form of RAG. The final content is superior to the original article because it is more complete and contextualized.
*   **AI Task Separation:** Using distinct AI agents for selection ("Editor-in-Chief") and writing ("Copywriter") mirrors a human process and leads to superior quality results. Each agent has a clear objective and specific context.
*   **Multiple Source Management:** The workflow demonstrates how to aggregate and manage input from multiple sources (different RSS feeds) in a single standardized analysis process.
*   **Efficiency:** Although more complex, this workflow is very efficient. It automatically discards uninteresting or repetitive articles, concentrating resources (and AI token costs) only on the highest-potential content.
