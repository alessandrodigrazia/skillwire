# Enterprise Use Case: Strategic Account Preparation Workflow

## 1. Workflow Objective

**Purpose:** Automate the entire intelligence and strategic preparation process for a new B2B account. Starting from just the name of a target company, the workflow performs in-depth research, analyzes its strategic positioning (C-SWOT), identifies value areas for our offering, and finally produces the artifacts for initial contact: a **strategic One-Pager** and the **contact email draft**.

This workflow replicates the first half of the account planning process, encapsulating the logic of the `preResearch`, `cswot`, `valueAreas`, and `onePagerAndEmail` prompts in an automated chain.

## 2. Technology Stack Used

*   **Trigger:** `Form Trigger` or `Webhook` (to input the target company name).
*   **External Research:** `HttpRequest` (to call a search API like Perplexity or another AI for the intelligence phase).
*   **AI Core:** `Google Gemini Pro` (for the analysis and generation phases that require complex reasoning).
*   **Core Logic:** `Set`, `Code` (to manage data flow between steps).
*   **Storage and Output:** `Microsoft Outlook` (to save the email as a draft), `SharePoint` (to save the One-Pager).

## 3. Flow Logic (Sequential Prompt Chain)

This workflow is an example of **"AI Chaining"**, where the output of one AI agent becomes the input for the next, enriching the context at each step.

### **Step 1: Initial Input**
*   **Node:** `Form Trigger`.
*   **Logic:** A simple form asks the salesperson to enter the `Prospect Company Name` to analyze.

### **Step 2: Pre-Research (Intelligence Gathering)**
*   **`Set` Node:** Prepares the prompt for the "Pre-Research" agent, using the template from `preResearchPrompt.js`.
*   **`Google Gemini` Node:** Generates the "meta-prompt", i.e., the advanced research briefing.
*   **`HttpRequest` Node:** Sends the meta-prompt to an external conversational AI API (e.g., Perplexity, or another Gemini/OpenAI endpoint) to execute the research and obtain a detailed strategic report on the prospect.

### **Step 3: C-SWOT Analysis**
*   **`Set` Node:** Takes the strategic report from Step 2 and inserts it into the `cswotPrompt.js` prompt template.
*   **`Google Gemini Pro` Node:** Performs the C-SWOT analysis and produces a structured JSON output with the client's strengths, weaknesses, opportunities, and threats.

### **Step 4: Value Areas Identification**
*   **`Set` Node:** Takes the C-SWOT JSON output and uses it as input for the `valueAreasPrompt.js` prompt template.
*   **`Google Gemini Pro` Node:** Identifies and generates the 4 most promising Value Areas, connecting the client's problems to our company's solutions, and produces another structured JSON output.

### **Step 5: One-Pager and Email Generation**
*   **`Set` Node:** Takes the C-SWOT and Value Areas JSON data and inserts them into the `onePagerAndEmailPrompt.js` template (configured for the One-Pager).
*   **`Google Gemini Pro` Node:** Generates the strategic One-Pager content in JSON format.
*   **A second `Set` and `Gemini Pro`:** Execute a similar process, but this time using the content of the just-generated One-Pager to create the contact email draft, also in JSON format (`subject` and `bodyHtml`).

### **Step 6: Artifact Saving (Human-in-the-Loop)**
*   **`Microsoft Outlook` Node:** Uses the `Create Draft` operation. Saves the generated email in the salesperson's "Drafts" folder. **This is a crucial step:** the email is not sent automatically but awaits review and manual sending.
*   **`SharePoint (List Item: Create)` Node:** Saves the One-Pager content to a SharePoint List for future reference.

## 4. Key Points and Best Practices

*   **AI Chaining:** This workflow demonstrates the power of a chain of AI calls. Each specialized agent works on the output of the previous one, creating a level of analysis and relevance impossible to achieve with a single prompt.
*   **Separation of Duties:** Each AI agent has a single, clear responsibility (research, SWOT analysis, generation, etc.). This makes the workflow more reliable and easier to debug.
*   **Structured Data as Common Thread:** Using JSON as the interchange format between various AI steps is fundamental for process robustness. Each agent knows exactly what input to expect.
*   **Human in the Loop (Fundamental):** The workflow does not replace the salesperson, but empowers them. The final output (the email) is saved as a draft, ensuring that a human always has final control, can further personalize the message, and decides the right time to send.
*   **Cost/Benefit:** This is a complex workflow that executes multiple calls to powerful AI models. Its value lies not in token savings, but in saving **hours** of strategic analysis work for the sales team, producing very high-quality output.
