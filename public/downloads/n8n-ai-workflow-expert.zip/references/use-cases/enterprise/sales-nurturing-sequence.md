# Enterprise Use Case: B2B Sales Nurturing Sequence

## 1. Workflow Objective

**Purpose:** Automate the sending of a sequence of 3 personalized nurturing emails to a potential customer (lead) when they enter a specific stage of the sales process. The goal is to maintain contact, provide value, and push the lead toward an action (e.g., booking a call) without continuous manual intervention from the salesperson.

**Real use cases:**
*   A lead has downloaded a whitepaper and needs to be "warmed up".
*   A contact collected at a trade show needs to be placed in a follow-up flow.
*   A stalled opportunity in the CRM needs to be reactivated.

## 2. Technology Stack Used

*   **Trigger:** CRM (e.g., HubSpot, Salesforce) or Webhook (when a lead is qualified).
*   **Core Logic:** `Set`, `Wait`, `If`.
*   **AI:** `Google Gemini` (for personalized generation of email texts).
*   **Communication:** `Microsoft Outlook` (for sending emails).
*   **Logging:** `Airtable` or CRM update (to track sequence completion).

## 3. Flow Logic (Step-by-Step)

This workflow is designed as a self-sustaining timed sequence.

### **Step 1: The Trigger - Sequence Start**
*   **Node:** `Webhook` or `HubSpot Trigger`.
*   **Logic:** The workflow starts when an external system (e.g., the CRM) notifies that a lead has entered the "Nurturing" stage. The initial input must contain at least: `first name`, `last name`, `email`, `company`, and `context` (e.g., "downloaded the whitepaper on AI in manufacturing").

### **Step 2: Email #1 - The Initial Contact**
*   **`Set` Node:** Prepares the prompt for the AI, including the lead data and the objective for the first email (e.g., "Introduce yourself, reference the downloaded whitepaper, and offer an initial value idea").
*   **`Google Gemini` Node:** Generates the text for the first email, personalizing it.
*   **`Microsoft Outlook` Node:** Sends the generated email to the lead's address.

### **Step 3: Strategic Pause #1**
*   **`Wait` Node:** The workflow is paused for a defined period. This is a crucial step to avoid "spamming" the lead.
*   **Configuration:** `3 Days`.

### **Step 4: Email #2 - The Value Follow-up**
*   **`Set` Node:** Prepares a new prompt. This time, the objective is to provide added value. Example: `"Follow up on the previous email. Mention a relevant case study for the '{{$json.company.industry}}' sector and attach a link to our latest blog article."`
*   **`Google Gemini` Node:** Generates the second email.
*   **`Microsoft Outlook` Node:** Sends the second email.

### **Step 5: Strategic Pause #2**
*   **`Wait` Node:** The workflow is paused again, this time for a longer period.
*   **Configuration:** `5 Days`.

### **Step 6: Email #3 - The Final Call to Action**
*   **`Set` Node:** Prepares the last prompt. The objective is to get a response or close the cycle.
    Example: `"Write a brief and direct email. Ask if the topic is still of interest and suggest two slots for a 15-minute call next week to discuss it."`
*   **`Google Gemini` Node:** Generates the final email.
*   **`Microsoft Outlook` Node:** Sends the final email.

### **Step 7: Logging and Conclusion**
*   **`Airtable (Update)` Node:** Updates the lead record in the tracking database, setting the `Nurturing Status` field to `"Completed"`.

## 4. Key Points and Best Practices

*   **Dynamic Personalization:** The true value of this workflow lies in the AI's ability to personalize each email. Prompts must be designed to leverage all available lead data (`name`, `company`, `industry`, `past interests`) to make the communication as 1-to-1 as possible.
*   **Timing (`Wait`):** The duration of pauses is fundamental. Experiment with different timings (e.g., 2, 4, 7 days) to find the rhythm that works best for your target audience.
*   **Exit Logic (Advanced):** This basic workflow runs to completion. An advanced version should include **exit logic**. This is achieved with a second workflow that activates when the lead responds to one of the emails. This second workflow should update the lead's status in Airtable/CRM to `"Has Responded"`, and the nurturing workflow, before sending each email, should check this status with an `If` node to stop immediately if the lead has already responded.
*   **Always Fresh Content:** To make value emails even more effective, the AI prompt can be enriched dynamically. For example, before calling Gemini, an `RSS Feed Read` node can retrieve the link to the latest company blog post, to include in the email.
*   **A/B Testing on Prompts:** You can easily test the effectiveness of different communication styles. Duplicate the workflow and modify only the prompts in the `Set` node to see which sequence generates more responses.
