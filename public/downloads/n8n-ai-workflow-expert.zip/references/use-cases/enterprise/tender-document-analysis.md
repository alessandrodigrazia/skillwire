# Enterprise Use Case: Tender Document Analysis with RAG

## 1. Workflow Objective

**Purpose:** Create a semi-automated system to analyze complex tender documents (specifications, technical proposals). The system indexes the content of these documents into a "knowledge base" and allows users (presales team, sales reps) to ask questions in natural language to quickly extract key information, such as requirements, deadlines, penalties, and evaluation criteria.

This approach, known as **RAG (Retrieval-Augmented Generation)**, is far superior to simply sending a document to an AI, because it ensures answers based **exclusively** on facts contained in the document, minimizing the risk of AI errors or "hallucinations".

The process is divided into two distinct workflows: **Indexing** and **Querying (Q&A)**.

## 2. Workflow 1: Document Indexing

**Objective:** Read a new tender document, split it up, and save it to a vector database to make it "queryable".

**Stack Used:**
*   **Trigger:** `SharePoint Trigger`
*   **File Handling:** `SharePoint (Download)`, `SharePoint (Move)`
*   **Processing:** `Document Loader`, `Embeddings` (e.g., OpenAI), `Vector Store` (e.g., Qdrant, Pinecone, or In-Memory)

**Flow Logic:**
1.  **Trigger:** A `SharePoint Trigger` starts when a new PDF file is uploaded to the `/Tenders/To Index/` folder.
2.  **Download & Chunking:** A `SharePoint (Download)` node downloads the file. Immediately after, a `Document Loader` reads it and splits it into hundreds of small, overlapping text "chunks" (fragments).
3.  **Embeddings Creation:** An `Embeddings` node (e.g., `embeddingsOpenAi`) transforms each individual text chunk into a numerical vector, which represents its semantic meaning.
4.  **Saving to Vector Store:** A `Vector Store` node (e.g., `Qdrant`) receives the chunks and their vectors. It saves each vector associated with the chunk text and important metadata, such as the tender ID (`tender_id`).
5.  **Archiving:** A `SharePoint (Move)` node moves the original document to `/Tenders/Indexed/` to avoid reprocessing.

## 3. Workflow 2: Document Querying (Q&A)

**Objective:** Allow a user to ask a question about a specific tender and receive an answer based on the indexed documents.

**Stack Used:**
*   **Interface:** `Chat Trigger` (for testing) or a `Microsoft Teams` channel.
*   **Core Logic:** `Embeddings`, `Vector Store`, `Google Gemini`.

**Flow Logic:**
1.  **Trigger:** A `Chat Trigger` receives the user's question, which must include the tender ID. Example: `"What are the penalties for tender #G123?"`
2.  **Semantic Search:**
    *   The workflow extracts the question (`"What are the penalties?"`) and the tender ID (`G123`).
    *   The question is transformed into an embedding vector.
    *   A `Vector Store (Search)` node searches the database for text chunks whose vectors are most "similar" to the question vector, **filtering results only for those with `tender_id = G123`**.
    *   This step retrieves the 3-5 most relevant paragraphs from the original tender document.
3.  **Response Generation (RAG):**
    *   **`Google Gemini` Node:** Receives both the user's original question and the relevant text chunks retrieved from the vector store.
    *   **Prompt (Crucial):** The prompt instructs the AI very specifically: `"Based EXCLUSIVELY on the context provided below, answer the user's question. If the answer is not present in the context, respond 'I did not find the information in the document'. Question: [User Question]. Context: [Chunk 1, Chunk 2, Chunk 3]."`
4.  **Response Delivery:** The `Respond to Webhook` node sends the AI-generated response to the user's chat interface.

## 4. Key Points and Best Practices

*   **Process Separation:** Separating indexing (a heavy process, executed once per document) from querying (a lightweight and frequent process) is a fundamental best practice for efficiency and scalability.
*   **The Power of RAG:** This pattern is the correct way to query documents. Instead of overloading an AI with a 100-page document, it focuses its attention only on the few relevant paragraphs, obtaining much more accurate and faster answers.
*   **AI "Grounding":** The prompt used in the Q&A workflow is called a "grounding prompt". It forces the AI to rely only on the provided facts (the context), preventing it from inventing answers or using its general knowledge. This is essential for accuracy in legal and technical domains.
*   **Importance of Metadata:** Saving metadata (such as `tender_id`, `document_name`, `chapter`) alongside vectors is crucial. It allows filtering search results and asking questions about a specific document within a knowledge base that might contain hundreds.
*   **Vector Store Choice:** To get started, n8n's `In-Memory Vector Store` node is great for testing. For a production application with many documents, you need to use a dedicated vector database like **Qdrant**, **Pinecone**, or **Supabase**, which offer persistence and high search performance.
