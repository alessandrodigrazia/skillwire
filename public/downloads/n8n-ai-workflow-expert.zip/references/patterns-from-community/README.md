# Community Workflows Pattern Library

This section contains patterns extracted from the analysis of **2054 real community N8N workflows**.

## 📊 Source Data

- **Total workflows analyzed**: 2054
- **AI-powered workflows**: 801 (39%)
- **Unique node types**: 502
- **Identified patterns**: 5 main categories

---

## 🎯 Patterns by Use Case

### 1. AI Agent Pattern (381 workflows)

**Description**: Workflows implementing AI agents with tool-calling and multi-step reasoning.

**Most used models**:
- gpt-4o-mini: 185 workflows
- gpt-4o: 71 workflows
- gemini-2.0-flash-exp: 41 workflows

**Typical Node Configuration**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.agent",
  "parameters": {
    "model": "gpt-4o-mini"
  }
}
```

**Reference File**: See `ai-agent-patterns.md` for detailed examples

---

### 2. Structured Extraction Pattern (154 workflows)

**Description**: Structured data extraction from text, email, documents.

**Most used models**:
- gpt-4o-mini: 68 workflows
- gpt-4o: 33 workflows
- gemini models: 18+ workflows

**Typical Node Configuration**:
```json
{
  "type": "@n8n/n8n-nodes-langchain.chainLlm",
  "parameters": {}
},
{
  "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
  "parameters": {
    "jsonSchema": "{ \"type\": \"object\", \"properties\": {...} }"
  }
}
```

**Reference File**: See `structured-extraction-patterns.md`

---

### 3. Email-to-Database Pattern (17 workflows)

**Description**: Automatic email parsing and database storage.

**Most used models**:
- gpt-4o: 6 workflows
- gpt-4o-mini: 6 workflows
- llama-3.3-70b-versatile: 3 workflows

**Typical Node Configuration**:
```json
{
  "type": "n8n-nodes-base.gmail"
},
{
  "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
  "parameters": {
    "model": "gpt-4o-mini"
  }
},
{
  "type": "n8n-nodes-base.airtable"
}
```

**Reference File**: See `email-to-database-patterns.md`

---

### 4. Content Generation Pattern (15 workflows)

**Description**: Automatic content generation for social media, blogs, newsletters.

**Most used models**:
- gpt-4o-mini: 6 workflows
- gpt-4o: 4 workflows
- gemini-2.5-flash: 1 workflow

**Typical Node Configuration**:
```json
{
  "type": "n8n-nodes-base.rssFeedRead"
},
{
  "type": "@n8n/n8n-nodes-langchain.lmChatGoogleGemini",
  "parameters": {
    "modelName": "models/gemini-2.5-flash"
  }
},
{
  "type": "n8n-nodes-base.linkedin"
}
```

**Reference File**: See `content-generation-patterns.md`

---

## 📈 Node Usage Statistics

**Top 20 most used nodes** (from node-statistics.json):

1. **n8n-nodes-base.set**: 2,553 occurrences
2. **n8n-nodes-base.httpRequest**: 2,125 occurrences
3. **n8n-nodes-base.if**: 1,102 occurrences
4. **n8n-nodes-base.code**: 1,030 occurrences
5. **@n8n/n8n-nodes-langchain.lmChatOpenAi**: 633 occurrences
6. **n8n-nodes-base.merge**: 611 occurrences
7. **@n8n/n8n-nodes-langchain.agent**: 463 occurrences
8. **n8n-nodes-base.splitInBatches**: 397 occurrences
9. **n8n-nodes-base.aggregate**: 368 occurrences
10. **n8n-nodes-base.gmail**: 334 occurrences

**AI Nodes Breakdown**:
- OpenAI Chat: 633 workflows
- AI Agent: 463 workflows
- Google Gemini Chat: 197 workflows
- LLM Chain: 190 workflows
- Structured Output Parser: 174 workflows

---

## 🔍 How to Use This Library

### 1. Search by Use Case
Consult specific pattern files:
- `ai-agent-patterns.md` - For implementing AI agents
- `structured-extraction-patterns.md` - For structured data parsing
- `email-to-database-patterns.md` - For email automation
- `content-generation-patterns.md` - For content generation

### 2. Search by Node Type
Use `references/index/node-statistics.json` to find:
- Common configurations for specific nodes
- Frequent node combinations
- Community best practices

### 3. Search by AI Model
Use `references/index/ai-model-usage.json` to find:
- Workflows using specific models
- Optimal use cases for each model
- Real implementation examples

---

## 📦 Available Index Files

All indexes are in `references/index/`:

1. **workflow-metadata.json** (2.3MB)
   - Complete index of all 2054 workflows
   - Metadata: nodes, AI models, complexity, patterns

2. **node-statistics.json** (24KB)
   - Usage statistics for 502 node types
   - Most common configurations

3. **ai-model-usage.json** (9.6KB)
   - Distribution of 801 AI workflows
   - Use case breakdown by model

4. **pattern-clusters.json** (14KB)
   - Workflow clusters by pattern similarity
   - Representative examples per cluster

5. **use-case-examples.json** (2.1KB)
   - Categorized examples by use case
   - Email processing, content automation, document analysis, AI agents

---

## 🎓 Recommended Learning Path

### Beginner
1. Start with `email-to-database-patterns.md`
2. Study simple examples (complexity: simple)
3. Use gemini-2.5-flash for testing

### Intermediate
1. Explore `structured-extraction-patterns.md`
2. Study workflow complexity: medium
3. Experiment with chainLlm + outputParserStructured

### Advanced
1. Deep dive in `ai-agent-patterns.md`
2. Analyze workflow complexity: complex
3. Implement multi-tool agents with memory

---

## 🔧 Utility Scripts

### Search Workflow by Pattern
```bash
python scripts/search-workflows.py --pattern "ai-agent"
```

### Extract Node Config
```bash
python scripts/extract-node-config.py --node-type "lmChatGoogleGemini"
```

### Generate Template from Example
```bash
python scripts/generate-template.py --workflow-id "0762_Aggregate_Stickynote_Create_Triggered"
```

---

## 📊 Statistics Summary

**Community Insights**:
- 39% of workflows use AI (growing trend)
- gpt-4o-mini is the most popular model (31% of AI workflows)
- AI Agent is the most common pattern (47% of AI workflows)
- Set + HTTP Request + IF are the most used "triad"

**Migration Opportunity**:
- Many workflows still use gemini-1.5/2.0
- Modernization opportunity to gemini-2.5
- Potential cost savings: 50-75%

---

## 🚀 Next Steps

1. **For Claude**: Use these patterns as reference when creating new workflows
2. **For Users**: Consult real examples before implementing from scratch
3. **For Optimization**: Compare your workflow with community best practices

**Goal**: Accelerate workflow development leveraging the collective intelligence of 2000+ real examples.
