# Node: Microsoft Outlook (`n8n-nodes-base.microsoftOutlook`)

## 1. Description

The **Microsoft Outlook** node is the connector for the email service in the Microsoft 365 ecosystem. It is the central node for any business process automation that relies on email communication in a corporate environment.

Similar to the Gmail node, it can function both as a **trigger** (to start workflows in response to incoming emails) and as an **action** to send, read, and organize messages. It is a fundamental tool for automating sales processes, customer service, and internal communications.

## 2. Main Operations

*   **Send:** Sends an email. The main parameters include `To`, `Subject`, and `Body`. Supports sending emails in HTML format.
*   **Get:** Retrieves a specific email by its ID.
*   **GetAll:** Retrieves a list of emails from a specific folder, with the ability to apply advanced filters.
*   **Move:** Moves an email from one folder to another. This is the key action for managing the state of a processed email (e.g., from `Inbox` to `Processed`).
*   **Create Folder:** Creates a new folder in the mailbox.

## 3. The Node as Trigger (`microsoftOutlookTrigger`)

When used as the first node, it activates as soon as an email arrives in a specified folder (by default, the `Inbox`). This allows creating reactive automations, such as immediate classification of incoming leads or support ticket creation.

## 4. JSON Configuration Example (Send Action)

```json
{
  "parameters": {
    "operation": "send",
    "to": "{{ $json.contactEmail }}",
    "subject": "Follow-up regarding our conversation about {{ $json.dealName }}",
    "body": "<p>Hi {{ $json.contactFirstName }},</p><p>I am writing to follow up on our recent chat. Would you be available for a brief call next week?</p>"
  },
  "id": "uuid-goes-here",
  "name": "Send Follow-up Email",
  "type": "n8n-nodes-base.microsoftOutlook",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftOutlookOAuth2Api": {
      "id": "credential-id",
      "name": "My Corporate Outlook Account"
    }
  }
}
```

## 5. Practical Use Case (Pattern: Automated Sales Nurturing)

**Objective:** Send a personalized follow-up email when a sales opportunity in a CRM (e.g., HubSpot, Salesforce) moves to a certain stage.

**Flow:**
1.  **CRM Trigger:** The workflow starts when an opportunity is moved to the `"Follow-up"` stage.
2.  **Set:** A `Set` node prepares the necessary data: the contact's email, their name, and the opportunity context.
3.  **LLM Node (Gemini):** An AI model generates text for the follow-up email, personalizing it with the contact and opportunity data.
4.  **Outlook (Send) (This Node):** Sends the AI-generated email to the potential customer.
5.  **CRM (Update):** A final node updates the opportunity in the CRM, recording that the follow-up email has been sent.

## 6. Best Practices & Tips

*   **Use Folders to Manage State:** Unlike Gmail which uses labels, in Outlook the best way to track an email's state is to move it. A common pattern is: trigger on emails in the `Inbox`, process them, and then use the `Move` operation to move them to a `_Processed` or `_Archived` folder. This prevents the workflow from processing them again.
*   **Advanced Filters:** Leverage filters in the `GetAll` operation to retrieve only the emails you are interested in. You can filter by sender (`from`), by subject (`subject`), by category (`categories`), or by folder.
*   **Security with OAuth2:** The connection to a corporate Outlook account is secure and uses the OAuth2 standard. n8n will never store your password, but will receive an authorization to act on your behalf, which can be revoked at any time by the Microsoft 365 administrator.
*   **Sending from Shared Mailboxes:** A very powerful feature in corporate environments is the ability to send emails from a shared mailbox (e.g., `sales@company.com`). This can be configured in the node options, provided you have the necessary permissions on your Microsoft 365 account.
*   **HTML Format:** For corporate communications, always use the `Body` field in `HTML` mode to include the corporate signature, links, and professional formatting.
