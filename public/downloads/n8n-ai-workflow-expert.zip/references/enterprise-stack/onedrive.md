# Node: Microsoft OneDrive (`n8n-nodes-base.microsoftOneDrive`)

## 1. Description

The **Microsoft OneDrive** node connects n8n to a user's personal file storage within the Microsoft 365 ecosystem. It is the tool for automating file and folder operations on a user's OneDrive.

It is ideal for scenarios such as saving personal reports, archiving email attachments, or starting workflows based on files uploaded by a user to their personal cloud space. It functions as the personal counterpart of SharePoint, which is instead team- and company-oriented.

## 2. Main Operations

*   **File - Upload:** The most common operation. Uploads a file (received from another node as binary data) to a specific OneDrive folder.
*   **File - Download:** Downloads a file from OneDrive to make it available as binary data for subsequent workflow nodes (e.g., for AI analysis).
*   **File - Get All:** Lists all files and subfolders in a specific folder.
*   **File - Delete:** Deletes a file.
*   **Folder - Create:** Creates a new folder.

## 3. The Node as Trigger (`microsoftOneDriveTrigger`)

When used as the first node in a workflow, it activates as soon as a new file is uploaded or modified in a specific folder of the user's OneDrive, allowing the creation of filesystem event-based automations.

## 4. JSON Configuration Example (File Upload)

```json
{
  "parameters": {
    "operation": "upload",
    "drive": "me",
    "folderId": "folder-id-here",
    "binaryData": true,
    "binaryPropertyName": "data",
    "fileName": "sales-report-{{ DateTime.now().toISODate() }}.pdf"
  },
  "id": "uuid-goes-here",
  "name": "Upload Report to OneDrive",
  "type": "n8n-nodes-base.microsoftOneDrive",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftOneDriveOAuth2Api": {
      "id": "credential-id",
      "name": "My OneDrive Account"
    }
  }
}
```

## 5. Practical Use Case (Pattern: Personal Report Saving)

**Objective:** A salesperson wants to receive a weekly report of their open opportunities, automatically saved to their personal OneDrive.

**Flow:**
1.  **Schedule Trigger:** The workflow starts every Friday at 5:00 PM.
2.  **CRM Node (e.g., Salesforce):** Retrieves all "open" opportunities assigned to that salesperson.
3.  **Spreadsheet File Node:** Converts the list of opportunities into a CSV or Excel file.
4.  **OneDrive (Upload) (This Node):**
    *   Takes the generated report file (as binary data).
    *   Uploads it to the `"Weekly Reports"` folder in the salesperson's OneDrive.
    *   Assigns a dynamic name to the file, such as `"Opportunities-Report-2025-10-24.csv"`.
5.  **Outlook (Send):** Sends an email to the salesperson notifying them that their report is ready and available in their OneDrive.

## 6. Best Practices & Tips

*   **OneDrive for Personal, SharePoint for the Team:** This is the key distinction. Use **OneDrive** for a single user's work files (the "My Documents" in the cloud). Use **SharePoint** for documents that belong to a team, a project, or the entire company and that require collaboration structure and permissions.
*   **Trigger on Dedicated Folders:** As with SharePoint, when using the trigger, point it to a specific and dedicated folder (e.g., `/App/n8n/Input`). This prevents accidental workflow executions and keeps the automation organized.
*   **Binary Data Handling:** The `Upload` operation expects to receive binary data. This data can come from a `Download` operation (from OneDrive itself or from another service like Gmail), from an `HTTP Request` node that downloads a file, or from a node that generates a file (like `Spreadsheet File` or a PDF generator).
*   **File Sharing:** Although the node focuses on file operations, you can extend its capabilities. After uploading a file, you can use an `HTTP Request` node to call the Microsoft Graph API and create a sharing link for that file, to then send via email or Teams.
*   **OAuth2 Authentication:** The connection to OneDrive is secure and based on OAuth2, without n8n ever needing to store your password.
