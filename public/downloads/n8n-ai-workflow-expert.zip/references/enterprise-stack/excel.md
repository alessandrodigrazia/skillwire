# Node: Microsoft Excel (`n8n-nodes-base.microsoftExcel`)

## 1. Description

The **Microsoft Excel** node allows n8n to read, write, and modify Excel files (`.xlsx`) stored on **OneDrive** or **SharePoint**. This node is fundamental for automating business processes that rely on spreadsheets, such as reporting, data analysis, or activity logging.

It enables integrating the power of n8n automations with the most widely used data analysis tool in the world, allowing you to populate reports for management, log workflow results, or read input data from files managed by users.

## 2. Main Operations

*   **Append to File:** Adds new rows of data to the bottom of an existing worksheet. This is the most common operation for logging.
*   **Read from File:** Reads data from a worksheet. It can read the entire table or only a specific range.
*   **Create File:** Creates a new Excel file from scratch, populating it with data from n8n.
*   **Update Row(s):** Modifies one or more existing rows that match a search criterion.
*   **Delete Row(s):** Deletes one or more rows.

## 3. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Storage** | Specifies where the Excel file is stored. | `SharePoint` or `OneDrive` |
| **Site/Drive** | The SharePoint site or specific Drive where the file is located. | `Sales Department` |
| **File** | The Excel file to operate on. | `Sales_Report_Q4.xlsx` |
| **Worksheet** | The name or ID of the worksheet within the file. | `Leads-Incoming` |
| **Columns** | For write operations (`Append`, `Update`), defines the mapping between n8n data and the Excel file columns. | `{"Lead Name": "{{ $json.name }}"}` |
| **Options > Has Header** | **(Important)** Indicates whether the first row of the spreadsheet is a header. If enabled, n8n will use column names instead of letters (A, B, C). | `true` |

## 4. JSON Configuration Example (Appending Rows)

```json
{
  "parameters": {
    "storage": "sharePoint",
    "siteId": "my-company.sharepoint.com,site-id-here",
    "fileId": "file-id-here",
    "worksheetId": "worksheet-id-here",
    "operation": "append",
    "columns": {
      "mappingMode": "defineBelow",
      "value": {
        "Lead Date": "={{ DateTime.now().toISODate() }}",
        "Contact Name": "={{ $json.contactName }}",
        "Company": "={{ $json.companyName }}",
        "Deal Value": "={{ $json.dealValue }}"
      }
    }
  },
  "id": "uuid-goes-here",
  "name": "Log Lead in Excel Report",
  "type": "n8n-nodes-base.microsoftExcel",
  "typeVersion": 1,
  "position": [
    123,
    456
  ],
  "credentials": {
    "microsoftExcelOAuth2Api": {
      "id": "credential-id",
      "name": "My Corporate Excel Account"
    }
  }
}
```

## 5. Practical Use Case (Pattern: Sales Data Logging)

**Objective:** Every new lead qualified by marketing must be logged in a central Excel file on the sales team's SharePoint site.

**Flow:**
1.  **Webhook:** A workflow starts when marketing qualifies a new lead in their system, sending the data to n8n.
2.  **Set:** A `Set` node formats the received data, ensuring that field names are clean.
3.  **Microsoft Excel (Append) (This Node):**
    *   Connects to the file `Report_Leads_FY2025.xlsx` on SharePoint.
    *   Selects the worksheet `"Q4-Leads"`.
    *   Appends a new row, mapping the lead data (name, company, email, source) to the corresponding columns in the spreadsheet.
4.  **Teams:** Sends a notification to the sales team channel to alert them about the new lead, mentioning that it has been logged in the Excel report.

## 6. Best Practices & Tips

*   **Excel vs. SharePoint Lists:** Use **Excel** when end users need the familiarity and analysis capabilities of a spreadsheet (charts, pivot tables, complex formulas). Use **SharePoint Lists** for more structured, database-like data where data consistency and validation are more important.
*   **File Location:** Remember that the Excel file must exist on OneDrive or SharePoint before n8n can interact with it (unless using the `Create File` operation).
*   **Always Enable `Has Header`:** This is a fundamental best practice. By enabling this option, you can reference columns by name (`Customer Name`) instead of by letter (`C`), which makes your workflow infinitely more readable and robust to future file modifications (such as adding a new column).
*   **Performance with Large Files:** Reading from or writing to Excel files with tens of thousands of rows can be a slow operation. If performance becomes an issue, consider whether a SharePoint List or a dedicated database (like PostgreSQL or SQL Server) might be a better and more scalable solution.
*   **Alternative for Creating Files:** If you only need to create an `.xlsx` or `.csv` file from scratch with your workflow data (without a pre-existing template on OneDrive/SharePoint), the generic `Spreadsheet File` node is an excellent alternative. The generated file will be available as binary data and can then be uploaded to OneDrive/SharePoint with the respective node.
