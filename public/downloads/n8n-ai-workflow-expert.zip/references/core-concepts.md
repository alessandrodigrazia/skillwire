# N8N Core Concepts

## What is N8N?

N8N is a fair-code licensed workflow automation tool that allows you to connect different services and automate tasks. It uses a **node-based** approach where each node represents an action or trigger.

## Fundamental Architecture

### 1. Workflows
A workflow is a collection of connected nodes that execute in sequence or based on conditions. Each workflow is stored as a JSON file containing:
- **nodes**: Array of node configurations
- **connections**: Defines how nodes link together
- **settings**: Global workflow settings
- **pinData**: (Optional) Test data pinned to nodes

### 2. Nodes
Nodes are the building blocks of workflows. There are several types:

#### Trigger Nodes
Start the workflow execution:
- **Manual Trigger**: Start manually from UI
- **Schedule Trigger**: Time-based (cron)
- **Webhook**: HTTP endpoint
- **Email Trigger** (Gmail, Outlook): New email received
- **Chat Trigger**: AI chat interface
- **Form Trigger**: Form submission

#### Action Nodes
Perform operations:
- **Data manipulation**: Set, Code, Filter, Merge, Split
- **API calls**: HTTP Request
- **Database**: PostgreSQL, MySQL, MongoDB, Redis
- **Cloud storage**: Google Drive, OneDrive, Dropbox
- **Communication**: Gmail, Outlook, Slack, Teams
- **AI/ML**: LangChain nodes (Gemini, OpenAI, Claude)
- **Productivity**: Airtable, Google Sheets, Notion

#### Logic Nodes
Control flow:
- **IF**: Conditional branching
- **Switch**: Multiple conditions
- **Merge**: Combine data streams
- **Split**: Divide data
- **Loop**: Iterate over items
- **Error Trigger**: Handle failures

### 3. Connections
Connections link nodes together, defining data flow:

```json
{
  "connections": {
    "Source Node Name": {
      "main": [[
        {
          "node": "Target Node Name",
          "type": "main",
          "index": 0
        }
      ]]
    }
  }
}
```

**Connection types:**
- **main**: Standard data flow
- **ai_languageModel**: AI model connection
- **ai_outputParser**: Output parser connection
- **ai_memory**: Memory connection
- **ai_tool**: Tool connection

## Data Structure

### Items
N8N processes data as **items** - JavaScript objects flowing between nodes.

Example item:
```json
{
  "json": {
    "id": 123,
    "name": "Example",
    "email": "user@example.com"
  },
  "binary": {
    "data": { /* binary file data */ }
  }
}
```

### Accessing Data

#### Current Item
```javascript
={{ $json.fieldName }}
```

#### Previous Node Data
```javascript
// Single item
={{ $('Node Name').item.json.field }}

// All items
={{ $('Node Name').all() }}

// First item
={{ $('Node Name').first().json.field }}

// Last item
={{ $('Node Name').last().json.field }}

// Specific item by index
={{ $('Node Name').item(2).json.field }}
```

#### Environment Variables
```javascript
={{ $env.VARIABLE_NAME }}
```

#### Special Variables
```javascript
={{ $now }}           // Current timestamp
={{ $today }}         // Today's date
={{ $execution }}     // Execution info
={{ $workflow }}      // Workflow info
={{ $itemIndex }}     // Current item index
```

## Node Configuration

### Standard Node Structure
```json
{
  "parameters": {
    /* Node-specific configuration */
  },
  "id": "uuid-v4-format",
  "name": "Human Readable Name",
  "type": "node-type-identifier",
  "typeVersion": 1,
  "position": [x, y],
  "credentials": {
    "credentialType": {
      "id": "credential-uuid",
      "name": "Credential Name"
    }
  }
}
```

### Common Parameters

#### Resource Locator (__rl)
Used by Google, Airtable, and other services:
```json
{
  "base": {
    "__rl": true,
    "value": "resource-id",
    "mode": "list",
    "cachedResultName": "Display Name",
    "cachedResultUrl": "https://url.com"
  }
}
```

#### Assignments (Set Node)
```json
{
  "assignments": {
    "assignments": [
      {
        "id": "unique-id",
        "name": "fieldName",
        "value": "={{ expression }}",
        "type": "string"
      }
    ]
  }
}
```

#### Filters
```json
{
  "filters": {
    "labelIds": ["Label_123"],
    "query": "search term"
  }
}
```

## Expression Language

### String Operations
```javascript
// Concatenation
={{ $json.firstName + " " + $json.lastName }}

// Template literals
={{ `Hello ${$json.name}` }}

// Methods
={{ $json.text.toUpperCase() }}
={{ $json.text.toLowerCase() }}
={{ $json.text.trim() }}
={{ $json.text.split(',') }}
```

### Number Operations
```javascript
={{ $json.price * 1.2 }}
={{ Math.round($json.value) }}
={{ Math.floor($json.value) }}
={{ Math.ceil($json.value) }}
```

### Date Operations
```javascript
={{ DateTime.now().toFormat('yyyy-MM-dd') }}
={{ DateTime.fromISO($json.date).plus({ days: 7 }) }}
={{ new Date().toISOString() }}
```

### Array Operations
```javascript
// Map
={{ $json.items.map(item => item.name) }}

// Filter
={{ $json.items.filter(item => item.active) }}

// Find
={{ $json.items.find(item => item.id === 123) }}

// Length
={{ $json.items.length }}

// Join
={{ $json.tags.join(', ') }}
```

### Object Operations
```javascript
// Access property
={{ $json.user.email }}

// Optional chaining
={{ $json.user?.address?.city }}

// Object keys
={{ Object.keys($json) }}

// Object values
={{ Object.values($json) }}
```

### Conditional Logic
```javascript
// Ternary
={{ $json.status === 'active' ? 'Yes' : 'No' }}

// Nullish coalescing
={{ $json.value ?? 'default' }}

// Logical AND
={{ $json.isActive && $json.isPremium }}

// Logical OR
={{ $json.email || $json.username }}
```

## Credentials Management

### Credential Types
- **OAuth2**: Google, Microsoft, LinkedIn
- **API Key**: Many services
- **Header Auth**: Custom APIs
- **Basic Auth**: Username/password

### Using Credentials
Credentials are referenced by ID:
```json
{
  "credentials": {
    "googlePalmApi": {
      "id": "abc-123-def",
      "name": "Google Gemini API"
    }
  }
}
```

**Best Practice:** Use descriptive names for credentials to easily identify them.

## Execution Model

### Execution Flow
1. **Trigger Node** starts execution
2. Data flows through **connected nodes**
3. Each node processes **all input items**
4. Node outputs become inputs for next nodes
5. Execution completes when all branches finish

### Execution Modes
- **Run Once**: Process all items together
- **Run Once for Each Item**: Process items individually
- **Split In Batches**: Process in chunks

### Error Handling
- **Continue on Fail**: Node outputs empty on error
- **Always Output Data**: Ensures downstream nodes execute
- **Error Trigger**: Catch and handle errors

## AI/LangChain Integration

### LangChain Node Types

#### Chat Models
- **lmChatGoogleGemini**: Google's Gemini models
- **lmChatOpenAi**: OpenAI GPT models
- **lmChatAnthropic**: Anthropic Claude models

#### Chains
- **chainLlm**: Simple LLM chain
- **chainSummarization**: Text summarization
- **agent**: AI agent with tools

#### Tools
- **toolHttpRequest**: HTTP API tool
- **toolWorkflow**: Sub-workflow tool
- **toolCalculator**: Math operations

#### Memory
- **memoryBufferWindow**: Sliding window conversation memory
- **memoryRedis**: Redis-backed memory

#### Output Parsers
- **outputParserStructured**: JSON extraction
- **outputParserAutofixing**: Auto-fix JSON errors

#### Document Loaders
- **documentDefaultDataLoader**: Load documents for RAG

## Performance Optimization

### Best Practices
1. **Minimize Node Count**: Use Code nodes for complex logic
2. **Early Filtering**: Filter data as soon as possible
3. **Batch Processing**: Use splitInBatches for large datasets
4. **Caching**: Store API responses when applicable
5. **Parallel Execution**: Split into parallel branches when possible

### Memory Management
- Limit item count in loops
- Clean up large binary data
- Use pagination for large datasets

## Debugging

### Techniques
1. **Pin Data**: Test with fixed data
2. **Execute Node**: Run individual nodes
3. **View Execution**: Inspect data flow
4. **Use NoOp Nodes**: Merge points for testing
5. **Add Logging**: Code nodes with console.log

### Common Issues
- **Missing Data**: Check connections and expressions
- **Credential Errors**: Verify credential configuration
- **Timeout**: Increase timeout or optimize query
- **Rate Limits**: Implement delays or batching

## Security Best Practices

### Credentials
- Never hardcode credentials in workflows
- Use environment variables for sensitive data
- Rotate credentials regularly
- Use least-privilege access

### Data Handling
- Sanitize user inputs
- Validate data before processing
- Encrypt sensitive data
- Be cautious with external webhooks

### API Security
- Implement webhook authentication
- Use HTTPS for all endpoints
- Rate limit external triggers
- Validate webhook signatures

## Workflow Versioning

### Best Practices
- Use descriptive workflow names
- Include version in name (v1, v2)
- Document changes in notes
- Export workflows regularly
- Use git for version control

### Workflow Export/Import
Workflows export as JSON:
```bash
# Export
n8n export:workflow --id=123 --output=workflow.json

# Import
n8n import:workflow --input=workflow.json
```

## Advanced Concepts

### Sub-workflows
Use **Execute Workflow** node to call other workflows:
- Reusable logic
- Modular design
- Better organization

### Webhook Patterns
- **Production URL**: Permanent endpoint
- **Test URL**: Temporary development endpoint
- **Authentication**: Implement header/query auth

### Scheduling
Cron expressions for Schedule Trigger:
```
* * * * *
│ │ │ │ │
│ │ │ │ └─ Day of week (0-7)
│ │ │ └─── Month (1-12)
│ │ └───── Day of month (1-31)
│ └─────── Hour (0-23)
└───────── Minute (0-59)
```

Examples:
- `0 9 * * *` - Daily at 9 AM
- `*/15 * * * *` - Every 15 minutes
- `0 9 * * 1-5` - Weekdays at 9 AM

### Binary Data
Handle files and images:
```json
{
  "binary": {
    "data": {
      "data": "base64-encoded-content",
      "mimeType": "image/png",
      "fileName": "image.png"
    }
  }
}
```

## Integration Patterns

### API Integration
1. **HTTP Request Node**: Direct API calls
2. **Pagination**: Handle large result sets
3. **Rate Limiting**: Respect API limits
4. **Error Handling**: Retry logic

### Database Integration
1. **Query Parameterization**: Prevent SQL injection
2. **Connection Pooling**: Reuse connections
3. **Transactions**: Ensure data consistency

### File Processing
1. **Read File**: Extract data from files
2. **Transform**: Process with Code/AI
3. **Write File**: Save results
4. **Upload**: Send to storage

## Testing Strategies

### Test Data
- Use Pin Data for consistent tests
- Create test workflows
- Separate test/production credentials

### Validation
- Check data types
- Validate required fields
- Test edge cases
- Error scenarios

### Monitoring
- Track execution success/failure
- Monitor execution time
- Set up alerts for failures
- Log important events

---

**Reference Links:**
- Official Docs: https://docs.n8n.io
- Community Forum: https://community.n8n.io
- Node Reference: https://docs.n8n.io/integrations/
