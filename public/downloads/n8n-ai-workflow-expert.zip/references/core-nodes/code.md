# Node: Code (`n8n-nodes-base.code`)

## 1. Description

The **Code** node is n8n's ultimate "escape hatch". It allows you to write and execute custom **JavaScript** code, offering unlimited flexibility to manipulate data, implement complex logic, or interact with external libraries.

When the standard nodes (`Set`, `If`, `Filter`, etc.) are not sufficient to achieve a specific transformation or logic, the `Code` node is the solution. It is one of the most powerful nodes in the system, as demonstrated by its high usage frequency (fifth most used node with 1005 instances in the analyzed dataset).

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Mode** | The code execution mode. | `Run Once for Each Item` |
| | `Run Once for Each Item`: Executes the code once for each input item. The current item is accessible through the `$item` or `$json` variables. | |
| | `Run Once for All Items`: Executes the code only once. All input items are available as an array in the `$items` variable. | |
| **JavaScript Code** | The text area where the JavaScript code is written. | `const name = $json.firstName.toUpperCase();
return [{ json: { fullName: name } }];` |

## 3. JSON Configuration Example

This example shows a simple `Code` node that formats a name in uppercase.

```json
{
  "parameters": {
    "jsCode": "// Executed for each item\nconst firstName = $json.firstName;\nconst lastName = $json.lastName;\n\nconst fullName = `${firstName} ${lastName}`.toUpperCase();\n\n// Return a new JSON object\nreturn [{ json: { fullName: fullName } }];"
  },
  "id": "uuid-goes-here",
  "name": "Format Name",
  "type": "n8n-nodes-base.code",
  "typeVersion": 2,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Cases

### a) Complex Data Transformation

**Objective:** Restructure an array of objects from an API into a different format.

**Flow:**
1.  **HTTP Request:** Gets an array of products, where each product has a complex structure (e.g., `{"product_data": {"name": "...", "price_details": {"value": 99.9}}}`).
2.  **Code (This Node):** In `Run Once for All Items` mode, the code runs a loop (`for...of`) over the `$items` array. For each item, it extracts only the necessary fields (`name`, `price`), renames them, and creates a new array of clean objects. Finally, it returns the new array.
3.  **Google Sheets:** The node receives the clean array and easily inserts it into a spreadsheet.

### b) Text Parsing with Regular Expressions

**Objective:** Extract an order number with a specific format from a block of text.

**Flow:**
1.  **Gmail:** Receives the body of an email.
2.  **Code (This Node):** In `Run Once for Each Item` mode, the code uses a Regular Expression (RegEx) to find a match for the pattern `PO-[0-9]{8}` within the email text (`$json.body`).
3.  The code returns a new field `orderNumber` with the extracted value.

## 5. Best Practices & Tips

*   **The Last Resort (but Powerful):** Use the `Code` node when you have exhausted the capabilities of simpler nodes. For direct assignments, use `Set`. For conditions, use `If`. For complex logic, array transformations, or calculations, the `Code` node is perfect.
*   **Choose the Correct Mode:** Choosing the execution mode is fundamental.
    *   Use `Run Once for Each Item` to transform each item independently from the others.
    *   Use `Run Once for All Items` when you need to aggregate, compare, sort, or filter the entire dataset in a single operation.
*   **The Return Structure is Mandatory:** Your code **must** return an array of objects, and each object must have a `json` property. Example: `return [{ json: { my_new_field: 'value' } }];`. If you return an empty array (`[]`), execution for that workflow branch will stop -- a useful way to filter data.
*   **Data Access:** Remember how to access data:
    *   In "Each Item" mode: `$item` (the entire item) or `$json` (shortcut for `$item.json`).
    *   In "All Items" mode: `$items` (the complete array of items).
    *   To access data from a specific previous node (from any mode): `$('Node Name').all()` or `$('Node Name').first()`.
*   **Built-in Libraries:** The `Code` node is not a complete Node.js environment, but it has access to some useful global libraries, including `moment.js` for advanced date manipulation (although Luxon's `DateTime`, available by default in expressions, is often sufficient).
