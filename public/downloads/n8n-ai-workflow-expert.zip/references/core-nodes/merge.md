# Node: Merge (`n8n-nodes-base.merge`)

## 1. Description

The **Merge** node is a fundamental flow control node, used to **combine or reunite multiple data streams** from different workflow branches into a single output stream.

It is the natural complement to nodes that create branches, such as `If` and `Switch`. When a workflow splits to follow different logic paths, the `Merge` node allows these paths to converge again to execute a series of common actions. It can also be used in more advanced modes to enrich data, similar to a `JOIN` in SQL.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Mode** | The strategy used to combine items. | `Append` (default), `Combine` |
| | `Append`: Waits for all inputs to finish and then appends the results. If a branch produces no output, nothing is appended. | |
| | `Combine`: Merges data from items coming from different inputs into a single item, based on a matching key. | |
| **Number of Inputs** | The number of input branches the node must wait for before proceeding. | `2` |
| **Key** (only in `Combine` mode) | The field name to use for matching items across different input streams. | `customerId` |

## 3. JSON Configuration Example

This example shows a `Merge` node in `Append` mode waiting for output from two different branches.

```json
{
  "parameters": {
    "mode": "append",
    "options": {}
  },
  "id": "uuid-goes-here",
  "name": "Merge Branches",
  "type": "n8n-nodes-base.merge",
  "typeVersion": 3.2,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Cases

### a) Reuniting the Branches of an `If` Node (`Append` Mode)

**Objective:** Execute a common action after a conditional decision.

**Flow:**
1.  **If:** Checks whether an order is `URGENT`.
2.  **`true` branch:** A `Slack` node sends an immediate notification to the emergency channel.
3.  **`false` branch:** A `Gmail` node sends a standard notification email.
4.  **Merge (This Node):** Is connected to both nodes (`Slack` and `Gmail`). Regardless of which path was taken, it receives the original order item.
5.  **Airtable (Update):** An Airtable node placed after the `Merge` updates the order status to `"Notified"`, executing an action common to both cases.

### b) Enriching Data (`Combine` Mode)

**Objective:** Combine order data with customer details from another source.

**Flow:**
1.  **Branch A - Airtable:** Retrieves a list of orders, each with `orderId` and `customerId`.
2.  **Branch B - Google Sheets:** Retrieves a list of customers, each with `customerId` and `customerName`.
3.  **Merge (This Node):**
    *   Set to `Combine` mode.
    *   The `Key` for both inputs is set to `customerId`.
4.  **Output:** The node produces a new stream of items, where each item contains the combined data: `orderId`, `customerId`, and `customerName`.

## 5. Best Practices & Tips

*   **Close the Branches:** The most common and important use of `Merge` is to "close" paths opened by an `If` or `Switch`. This keeps workflows tidy and prevents them from ending unexpectedly.
*   **`Append` for Flow, `Combine` for Data:** Remember the fundamental difference:
    *   Use `Append` when you simply want the workflow to **continue** after a branch.
    *   Use `Combine` when you want to **enrich** the data of one stream with data from another, as you would with a `JOIN` in a database.
*   **Set the `Number of Inputs` Correctly:** Make sure the configured number of inputs matches exactly the number of branches you are connecting. If you set `2` but connect only one branch, the workflow will hang, waiting for an input that will never arrive.
*   **Simple Alternative - `NoOp`:** If you only need a visual meeting point for connectors, without any merge logic (for example, to funnel multiple error branches to a single notification), the `NoOp` (No Operation) node can be a simpler alternative. However, `Merge` is more explicit and powerful for managing data flows.
