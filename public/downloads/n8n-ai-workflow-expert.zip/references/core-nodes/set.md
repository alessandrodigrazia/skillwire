# Node: Set (`n8n-nodes-base.set`)

## 1. Description

The **Set** node is arguably the most important and most used utility node in n8n. Its primary function is to **create, modify, or rename fields** (properties) within the data items flowing through the workflow.

It is the "Swiss army knife" for data preparation and transformation. You use it constantly to prepare input for the next node, to set static values, or to extract and reorganize data from other sources. The dataset analysis positions it as the second most frequent node overall, present in 2530 workflows.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Mode** | The operating mode. `Append` (default) adds new fields to the existing data. `Overwrite` deletes all previous data and replaces it only with the fields defined in the node. | `Append` |
| **Assignments** | The list of operations to perform. Each operation defines a field and the value to assign to it. | |
| `Name` | The name of the field to create or overwrite. | `customer_name` |
| `Value` | The value to assign to the field. It can be a static value (e.g., fixed text) or a dynamic expression (e.g., `{{ $json.id }}`). | `"Fixed Value"` or `{{ $json.some_field }}` |

## 3. JSON Configuration Example

This example shows a `Set` node that creates three new fields: one with a static value, one with a dynamic value from a previous node, and one that combines both.

```json
{
  "parameters": {
    "assignments": {
      "assignments": [
        {
          "id": "abc-123",
          "name": "status_processo",
          "type": "string",
          "value": "Iniziato"
        },
        {
          "id": "def-456",
          "name": "id_cliente",
          "type": "string",
          "value": "={{ $(\'Leggi da Airtable\').item.json.customerId }}"
        },
        {
          "id": "ghi-789",
          "name": "messaggio_log",
          "type": "string",
          "value": "Processando l\'ordine {{ $json.orderNumber }} per il cliente {{ $json.customerName }}"
        }
      ]
    },
    "options": {}
  },
  "id": "uuid-goes-here",
  "name": "Prepara Dati per AI",
  "type": "n8n-nodes-base.set",
  "typeVersion": 3.4,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case

**Objective:** Prepare a prompt for an AI model by combining static text and dynamic data.

**Simplified Flow:**
1.  **Airtable Trigger:** Activates when a new record is added to a table called "Articles to Summarize", containing the fields `title` and `article_text`.
2.  **Set (This Node):** Prepares the data for the Gemini node. Creates a new field called `prompt_for_ai`.
    *   The `prompt_for_ai` field is set with an expression that combines fixed instructions with the trigger data: `"You are a social media expert. Create a LinkedIn post that summarizes this article.\n\nTitle: {{ $json.titolo }}\nText: {{ $json.testo_articolo }}"`
3.  **Google Gemini:** Receives the `prompt_for_ai` as input and generates the LinkedIn post.

Thanks to the `Set` node, we have separated the prompt construction logic from the AI call logic, making the workflow cleaner and more readable.

## 5. Best Practices & Tips

*   **The "Glue" Node:** Think of the `Set` node as the glue that holds your workflow together. You use it almost always between one app and another to adapt data from one node's output format to the input format required by the next one.
*   **Use `Append` (almost always):** In 99% of cases, the default `Append` mode is the correct one. It adds new data without deleting existing data. Use `Overwrite` with extreme caution, only if you explicitly want to discard all previous data.
*   **Clear Field Names:** When creating a new field, give it a descriptive name (e.g., `formatted_customer_email` instead of `email2`). This will make debugging much easier.
*   **`Set` vs. `Code`:** For simple value assignments, string concatenations, or small transformations, the `Set` node is faster, more efficient, and much easier to read than the `Code` node. Use the `Code` node only when you need complex logic, such as loops, calls to external libraries, or data transformations requiring multiple steps.
*   **Keep `Set` Nodes Small:** Instead of a single, huge `Set` node with 20 assignments, consider using two or three smaller ones with descriptive names (e.g., "Prepare Customer Data", "Prepare Order Data"). This improves workflow readability.
