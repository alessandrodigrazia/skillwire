# Node: Split in Batches (`n8n-nodes-base.splitInBatches`)

## 1. Description

The **Split in Batches** node is an essential utility node for reliably processing large amounts of data. Its function is to take a large number of input items and split them into smaller, more manageable "batches" (lots).

This node creates a **loop**, processing one batch at a time. It is essential for interacting with APIs that have rate limits, for avoiding running out of system memory, or for managing workflows that must perform operations on thousands of records in a controlled and sequential manner.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Batch Size** | **(Crucial)** The number of items to include in each batch. If the input has 1000 items and the Batch Size is 100, the node will create 10 loops, each with 100 items. | `100` |
| **Options > Respect previous `runIndex`** | An advanced option for managing nested loops (a loop inside another loop). Generally, it does not need to be enabled. | `false` |

## 3. JSON Configuration Example

This example shows a node configured to create batches of 50 items each.

```json
{
  "parameters": {
    "batchSize": 50,
    "options": {}
  },
  "id": "uuid-goes-here",
  "name": "Split 1000 items into batches of 50",
  "type": "n8n-nodes-base.splitInBatches",
  "typeVersion": 3,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Case (Pattern: Controlled Bulk Processing)

**Objective:** Enrich 1000 contacts taken from a Google Sheets spreadsheet with data from an external API that only allows 100 calls per minute.

**Flow:**
1.  **Google Sheets (getAll):** Reads 1000 rows from the sheet, producing 1000 items.
2.  **Split in Batches (This Node):**
    *   Receives the 1000 items.
    *   Is configured with `Batch Size: 50`.
    *   On the first run, it sends the first 50 items to its "Batch" output.
3.  **HTTP Request:** Makes 50 calls to the external API to enrich the data for the 50 items in the batch.
4.  **Wait:** After processing the batch, the workflow waits for 60 seconds to respect the API rate limit.
5.  **Loop:** The output of the `Wait` node is reconnected to the input of the `Split in Batches` node. The `Split in Batches` node is smart enough to understand that the first loop has finished and sends the next batch (items 51-100) to its output, continuing this way until all 1000 items are exhausted.

## 5. Best Practices & Tips

*   **Indispensable for Large Volumes:** Always use this node when working with hundreds or thousands of items. It is the only way to ensure that your workflow does not fail due to memory limits or timeouts and to interact politely with external APIs.
*   **The Magic of the Loop:** To create the loop, you must **reconnect** the last node of your batch processing logic to the input of the `Split in Batches` node. It will handle the iteration and send the next batch.
*   **Use `Wait` for Rate Limits:** If your loop contains calls to external APIs, **always** insert a `Wait` node at the end of the cycle to avoid being blocked for making too many requests in a short time.
*   **Batch Size = 1 for Serial Processing:** An extremely common use case is setting `Batch Size: 1`. This creates a loop that processes items one at a time, sequentially. It is useful when operations must be performed in a specific order or when you want to debug the process on a single item.
*   **`splitInBatches` vs. `Split Out`:** Do not confuse them. `Split Out` is an older, simpler node that takes *a single item* containing an array and breaks it into multiple items. `Split in Batches` is more powerful: it takes *a stream of multiple items* and groups them into lots, managing a real processing loop. For loops, `Split in Batches` is almost always the correct choice.
