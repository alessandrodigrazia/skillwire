# Node: If (`n8n-nodes-base.if`)

## 1. Description

The **If** node is one of the most important flow control nodes in n8n. It acts like an `if/else` statement in programming, allowing the workflow to make decisions and follow different paths based on specific conditions.

One or more values from previous nodes are evaluated, and depending on whether the conditions are true (`true`) or false (`false`), the data is routed to one of two output branches. It is the primary tool for implementing conditional logic. Its high frequency in the dataset (1096 instances) underscores its crucial role.

## 2. Key Parameters

| Parameter | Description | Example Value |
| :--- | :--- | :--- |
| **Conditions** | The set of rules to evaluate. Each condition is composed of three parts. | |
| `First Value` | The value to check, typically a dynamic expression that reads data from a previous node. | `{{ $json.status }}` |
| `Operation` | The comparison operator to apply. | `Equal`, `Not Equal`, `Contains`, `Larger Than`, `Is Empty` |
| `Second Value` | The value to compare the first value against. | `"completed"` |
| **Combinator** | Specifies how to combine multiple conditions: `All` (AND logic, all must be true) or `Any` (OR logic, at least one must be true). | `All` |

## 3. JSON Configuration Example

This example shows an `If` node that checks whether a `status` field equals `"processed"`.

```json
{
  "parameters": {
    "conditions": {
      "options": {},
      "conditions": [
        {
          "id": "uuid-goes-here",
          "leftValue": "={{ $json.status }}",
          "operator": {
            "type": "string",
            "operation": "equals"
          },
          "rightValue": "processed"
        }
      ],
      "combinator": "and"
    }
  },
  "id": "uuid-goes-here",
  "name": "Check if Processed",
  "type": "n8n-nodes-base.if",
  "typeVersion": 2.2,
  "position": [
    123,
    456
  ]
}
```

## 4. Practical Use Cases

### a) Category-Based Routing

**Objective:** Route an email to the correct department based on its category, determined by an AI.

**Flow:**
1.  **LLM Chain:** An AI node analyzes an email and returns a `category` field (e.g., `"Sales"` or `"Support"`).
2.  **If (This Node):** Checks whether the `category` field equals `"Sales"`.
3.  **Output:**
    *   **`true` branch:** Data flows to nodes that create a new lead in the CRM (e.g., HubSpot).
    *   **`false` branch:** Data flows to nodes that create a new ticket in the support system (e.g., Zendesk).

### b) Empty Data Check

**Objective:** Prevent errors by checking whether a previous node returned any results.

**Flow:**
1.  **Airtable (Search):** Searches for a record in the database. If it doesn't find one, its output will be empty.
2.  **If (This Node):** Uses the `Is Not Empty` operation to check the Airtable node output.
3.  **Output:**
    *   **`true` branch (Data present):** Data flows to a node that updates the existing record.
    *   **`false` branch (No data):** Data flows to a node that creates a new record.

## 5. Best Practices & Tips

*   **The Standard Decision-Maker:** For any binary `if/else` logic, this is the node to use.
*   **`If` vs. `Switch`:** Use the `If` node for binary decisions (true/false). If you need to handle more than two possible paths based on the value of a single field (e.g., `status` can be `"new"`, `"pending"`, `"done"`, `"error"`), the `Switch` node is cleaner and more readable.
*   **Prevent Errors with `Is Empty`:** One of the most important uses of the `If` node is error prevention. Always use it after nodes that might not return results (such as a database search or a filter) to check whether the output is empty (`Is Empty`) before attempting to process it.
*   **Watch Out for Data Types:** n8n tries to be flexible, but it is good practice to be aware of the data types you are comparing (string, number, boolean). Most basic operations work as expected, but for stricter comparisons, you may need to convert data types in a preceding `Set` node.
*   **Rename the Outputs:** To improve workflow readability, you can rename the two output branches of the `If` node (e.g., `true` -> `"Record Found"`, `false` -> `"Create New Record"`).
