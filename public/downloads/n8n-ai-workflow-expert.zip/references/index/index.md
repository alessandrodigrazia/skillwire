# Master Index of the Skill: N8N AI Workflow Expert

This document serves as the main index for all knowledge resources contained in this skill. Use it as a starting point to find documentation on nodes, patterns, and use cases.

---

## 1. Fundamental Concepts

*   **[Core Concepts](./core-concepts.md):** The basics of n8n (nodes, connections, data, expressions).
*   **[Workflow Patterns](./workflow-patterns.md):** Common architectural models (Content Automation, RAG, Batch Processing, etc.).

---

## 2. Node Documentation

### AI Nodes (`/references/ai-nodes/`)

*   **Language Models:**
    *   [Google Gemini](./ai-nodes/lmChatGoogleGemini.md) (Primary Choice)
    *   [OpenAI](./ai-nodes/lmChatOpenAi.md) (Secondary Choice for accuracy)
    *   [Anthropic Claude](./ai-nodes/lmChatAnthropic.md) (For long contexts)
*   **Agents and Tools:**
    *   [AI Agent](./ai-nodes/agent.md) (Intelligent orchestrator)
    *   [Workflow as Tool](./ai-nodes/toolWorkflow.md) (Invoke a workflow as a tool)
    *   [HTTP Request as Tool](./ai-nodes/toolHttpRequest.md) (Give the agent API access)
*   **Conversation Management:**
    *   [Chat Trigger](./ai-nodes/chatTrigger.md) (Test interface)
    *   [Window Buffer Memory](./ai-nodes/memoryBufferWindow.md) (Short-term memory)
*   **Chains and Parsers:**
    *   [LLM Chain](./ai-nodes/chainLlm.md) (Single AI interaction)
    *   [Summarization Chain](./ai-nodes/chainSummarization.md) (For summarizing long documents)
    *   [Structured Output Parser](./ai-nodes/outputParserStructured.md) (Extract JSON from AI output)
*   **RAG (Retrieval-Augmented Generation):**
    *   [Default Document Loader](./ai-nodes/documentDefaultDataLoader.md) (Load and split documents)
    *   [OpenAI Embeddings](./ai-nodes/embeddingsOpenAi.md) (Create semantic vectors)
    *   [Information Extractor](./ai-nodes/informationExtractor.md) (Extract structured data from text)

### Core Nodes (`/references/core-nodes/`)

*   [Set](./core-nodes/set.md) (Manipulate data)
*   [HTTP Request](./core-nodes/httpRequest.md) (Manual API calls)
*   [If](./core-nodes/if.md) (Conditional logic)
*   [Code](./core-nodes/code.md) (Custom JavaScript logic)
*   [Merge](./core-nodes/merge.md) (Rejoin flows)
*   [Split in Batches](./core-nodes/splitInBatches.md) (Create loops and handle large volumes)

### Personal Stack Nodes (`/references/personal-stack/`)

*   [Gmail](./personal-stack/gmail.md)
*   [Airtable](./personal-stack/airtable.md)
*   [YouTube](./personal-stack/youtube.md)
*   [LinkedIn](./personal-stack/linkedin.md)
*   [RSS Feed Read](./personal-stack/rssFeedRead.md)

### Enterprise Stack Nodes (`/references/enterprise-stack/`)

*   [Microsoft Outlook](./enterprise-stack/outlook.md)
*   [Microsoft Teams](./enterprise-stack/teams.md)
*   [Microsoft SharePoint](./enterprise-stack/sharepoint.md)
*   [Microsoft OneDrive](./enterprise-stack/onedrive.md)
*   [Microsoft Excel](./enterprise-stack/excel.md)

---

## 3. Use Cases and Templates

### Enterprise (`/references/use-cases/enterprise/`)

*   **Strategic Account Planning:**
    *   Guide: [account-planning-workflow.md](./use-cases/enterprise/account-planning-workflow.md)
    *   Template: `account-planning.json`
*   **Meeting Preparation:**
    *   Guide: [meeting-preparation.md](./use-cases/enterprise/meeting-preparation.md)
    *   Template: `meeting-preparation.json`
*   **Post-Meeting Report:**
    *   Guide: [meeting-report-automation.md](./use-cases/enterprise/meeting-report-automation.md)
    *   Template: `meeting-report-automation.json`
*   **Tender Document Analysis (RAG):**
    *   Guide: [tender-document-analysis.md](./use-cases/enterprise/tender-document-analysis.md)
    *   Template (Indexing): `tender-indexing.json`
    *   Template (Q&A): `tender-qa.json`
*   **Negotiation Workbench:**
    *   Guide: [negotiation-workbench.md](./use-cases/enterprise/negotiation-workbench.md)
    *   Template: `negotiation-workbench.json`
*   **Business Case Generation:**
    *   Guide: [business-case-generation.md](./use-cases/enterprise/business-case-generation.md)
    *   Template: `business-case-generation.json`
*   **Presentation Generation:**
    *   Guide: [presentation-generation.md](./use-cases/enterprise/presentation-generation.md)
    *   Template: `presentation-generation.json`

### Personal (`/references/use-cases/personal/`)

*   **Article to LinkedIn Post:**
    *   Guide: [article-to-linkedin-post.md](./use-cases/personal/article-to-linkedin-post.md)
    *   Template: `01. Articolo → Post LinkedIn (powered by Gemini).json`
*   **Video to LinkedIn Post:**
    *   Guide: [video-to-linkedin-post.md](./use-cases/personal/video-to-linkedin-post.md)
    *   Template: `02. Video → Post LinkedIn (powered by Gemini).json`
*   **RSS to LinkedIn Post:**
    *   Guide: [rss-to-linkedin-post.md](./use-cases/personal/rss-to-linkedin-post.md)
    *   Template: `03. RSS Feed → Post LinkedIn (powered by Gemini).json`

---

## 4. Introductory and Advanced Guides

### Beginner Guides (`/references/beginner/`)

*   **[Your First Workflow](./beginner/first-workflow-tutorial.md):** A step-by-step guide to creating a daily weather report.

### Advanced Guides (`/references/advanced/`)

*   **[Error Handling](./advanced/error-handling.md):** How to build robust workflows that handle failures.
*   **[Execution Modes](./advanced/execution-modes.md):** Differences between `regular` and `queue` modes for production.
*   **[Sub-workflows and Modularity](./advanced/subworkflows.md):** How to create reusable workflows.

---

## 5. Architectural Patterns

*   **[Visual Patterns](./visual-patterns.md):** Flow diagrams for the most common automation patterns (ETL, RAG, Approval, etc.).

---

## 6. Utility Scripts (`/scripts/`)

*   **[search.js](./scripts/search.js):** Provides functions for searching within the knowledge base.
*   **[validate.js](./scripts/validate.js):** Provides functions for basic validation of workflow JSON.
