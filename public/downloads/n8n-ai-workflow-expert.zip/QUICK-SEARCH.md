# Quick Search Guide for Claude

**For Claude**: This guide explains how to search for examples among the **2054 available workflow JSON files**.

---

## TL;DR - How to Search Quickly

### 1. **Load the Index** (always do this first)
```javascript
const index = await read('references/index/workflow-metadata.json');
// Contains metadata for all 2054 workflows
```

### 2. **Filter by Criteria**
```javascript
// Example: Find AI agents with Gemini
const matches = index.workflows.filter(w =>
  w.key_patterns?.includes('ai-agent') &&
  w.ai_models?.some(m => m.includes('gemini'))
);
```

### 3. **Read Only the Relevant Files** (max 3-5)
```javascript
// Read the first match
const workflow = await read(`workflows/${matches[0].file_path}`);
```

---

## Index Fields Reference

Each workflow in the index has:

```javascript
{
  "id": "0472_Aggregate_Gmail_Create_Triggered",
  "name": "Gmail to Airtable Extraction",
  "file_path": "Aggregate/0472_Aggregate_Gmail_Create_Triggered.json",
  "nodes_count": 8,
  "nodes_types": [
    "n8n-nodes-base.gmailTrigger",
    "@n8n/n8n-nodes-langchain.chainLlm",
    "n8n-nodes-base.airtable"
  ],
  "ai_nodes": [
    "@n8n/n8n-nodes-langchain.chainLlm",
    "@n8n/n8n-nodes-langchain.lmChatOpenAi"
  ],
  "ai_models": ["gpt-4o-mini"],
  "trigger_types": ["email"],
  "category": "aggregate",
  "has_ai": true,
  "complexity": "medium",
  "key_patterns": ["email-to-database", "structured-extraction"]
}
```

---

## Common Search Patterns

### Pattern 1: Search by Use Case
```javascript
// User: "Show me an example of data extraction from email"
const results = index.workflows.filter(w =>
  w.key_patterns?.includes('email-to-database') ||
  (w.trigger_types?.includes('email') && w.key_patterns?.includes('structured-extraction'))
);

// Take the top 3
const top3 = results.slice(0, 3);

// Read the full workflows
for (const wf of top3) {
  const fullWorkflow = await read(`workflows/${wf.file_path}`);
  // Analyze and present
}
```

### Pattern 2: Search by AI Model
```javascript
// User: "Examples with Gemini 2.5"
const geminWorkflows = index.workflows.filter(w =>
  w.ai_models?.some(m =>
    m.includes('gemini-2.5') ||
    m.includes('gemini-2.0')  // Also include versions to upgrade
  )
);

console.log(`Found ${geminiWorkflows.length} Gemini workflows`);
```

### Pattern 3: Search by Specific Nodes
```javascript
// User: "Workflows with Gmail + Airtable"
const results = index.workflows.filter(w => {
  const nodes = w.nodes_types.join(',').toLowerCase();
  return nodes.includes('gmail') && nodes.includes('airtable');
});
```

### Pattern 4: Search by Complexity
```javascript
// User: "Simple AI agent example"
const simpleAgents = index.workflows.filter(w =>
  w.key_patterns?.includes('ai-agent') &&
  w.complexity === 'simple'
);
```

### Pattern 5: Search by Category
```javascript
// User: "Workflows in the Gmail category"
const gmailWorkflows = index.workflows.filter(w =>
  w.category === 'gmail'
);
```

---

## Recommended Search Workflow

### Step 1: Understand User Request
```
User: "How to create a Telegram bot with AI?"

→ Keywords: telegram, ai, bot, agent
→ Likely pattern: ai-agent
→ Node type: telegram
```

### Step 2: Query Index
```javascript
const matches = index.workflows.filter(w =>
  // Pattern match
  w.key_patterns?.includes('ai-agent') &&
  // Node match
  w.nodes_types.some(n => n.toLowerCase().includes('telegram'))
);

console.log(`Found ${matches.length} matches`);
```

### Step 3: Select Best Examples
```javascript
// Sort by relevance
const sorted = matches.sort((a, b) => {
  // Prefer medium complexity (most educational)
  const complexityScore = {simple: 0, medium: 1, complex: 0};
  return (complexityScore[b.complexity] || 0) - (complexityScore[a.complexity] || 0);
});

// Take top 3
const examples = sorted.slice(0, 3);
```

### Step 4: Read and Analyze
```javascript
for (const ex of examples) {
  console.log(`\nExample ${ex.id}:`);
  console.log(`- File: workflows/${ex.file_path}`);
  console.log(`- Nodes: ${ex.nodes_count}`);
  console.log(`- AI Models: ${ex.ai_models.join(', ')}`);

  // Read full workflow
  const workflow = await read(`workflows/${ex.file_path}`);

  // Extract relevant configuration
  const agentNode = workflow.nodes.find(n => n.type.includes('agent'));
  const telegramNode = workflow.nodes.find(n => n.type.includes('telegram'));

  // Present configuration
}
```

### Step 5: Present to User
```markdown
I found 3 examples of Telegram bots with AI:

**1. Simple Example** (5 nodes)
File: `workflows/Telegram/1234_Telegram_Bot.json`
- Trigger: Telegram
- AI: gemini-2.0-flash-exp → **Recommend upgrading to gemini-2.5-flash**
- Pattern: Simple response without tools

**Key configuration**:
[show relevant snippet]

**2. Example with Tools** (10 nodes)
[...]
```

---

## Available Filters

### By Pattern (key_patterns)
- `"ai-agent"` - 381 workflows
- `"structured-extraction"` - 154 workflows
- `"email-to-database"` - 17 workflows
- `"ai-content-generation"` - 15 workflows
- `"scheduled-automation"` - various

### By Complexity
- `"simple"` - < 3 nodes
- `"medium"` - 3-8 nodes
- `"complex"` - > 8 nodes

### By AI Presence
- `has_ai: true` - 801 workflows
- `has_ai: false` - 1253 workflows

### By Trigger Type
- `"email"` - 334 workflows (Gmail, Outlook)
- `"webhook"` - 145 workflows
- `"schedule"` - various
- `"manual"` - various
- `"chat"` - various

### By AI Model
Top available models:
- `"gpt-4o-mini"` - 249 workflows
- `"gpt-4o"` - 95 workflows
- `"gemini-2.0-flash-exp"` - 65 workflows
- `"gemini-2.0-flash"` - 29 workflows
- `"models/gemini-1.5-flash"` - 17 workflows

---

## Best Practices

### DO

1. **Always load index first** - Don't search files directly
2. **Limit file reads** - Max 3-5 workflows per query
3. **Show file path** - User can explore on their own
4. **Suggest modernizations** - If you see old models
5. **Vary examples** - Show different approaches

### DON'T

1. **Don't read all files** - Use index to filter
2. **Don't ignore complexity** - Show progressive examples
3. **Don't show only one example** - Show 2-3 approaches
4. **Don't assume the model** - Verify in the index first

---

## Response Template

When user asks for an example:

```markdown
I searched the index of 2054 workflows and found **{N} relevant examples**.

Here are the {top 3} most representative:

### 1. {Workflow Name} ({complexity})
**File**: `workflows/{file_path}`
**Nodes**: {nodes_count} | **Pattern**: {key_patterns}
**AI Model**: {ai_model} {if old → suggest upgrade}

**What it does**:
{description based on nodes}

**Key configuration**:
```json
{relevant snippet from workflow}
```

**When to use it**: {specific use case}

---

### 2. {Second example - different approach}
[...]

---

**Which approach do you prefer?** I can show you the complete configuration for a specific one.
```

---

## Utility Scripts

### Script 1: Search from CLI
```bash
cd n8n-ai-workflow-expert
python scripts/search-workflows.py --pattern ai-agent --model gemini --limit 5
```

### Script 2: Extract Node Config
```bash
python scripts/extract-node-config.py --workflow-id "0472_Aggregate_Gmail" --node-type "lmChatOpenAi"
```

---

## Quick Stats Reference

**Dataset Overview**:
- Total workflows: 2054
- AI-powered: 801 (39%)
- Unique node types: 502
- Categories: 187

**Top Patterns**:
1. ai-agent: 381 (19%)
2. structured-extraction: 154 (8%)
3. email-to-database: 17 (<1%)

**Top Nodes**:
1. Set: 2553 usages
2. HTTP Request: 2125
3. IF: 1102
4. Code: 1030
5. OpenAI Chat: 633

---

## Examples by Common Requests

### "Show me email automation"
```javascript
index.workflows.filter(w => w.trigger_types?.includes('email'))
// Returns: 334 workflows
```

### "AI content generation"
```javascript
index.workflows.filter(w => w.key_patterns?.includes('ai-content-generation'))
// Returns: 15 workflows
```

### "Simple Gmail to Airtable"
```javascript
index.workflows.filter(w =>
  w.category === 'gmail' &&
  w.nodes_types.some(n => n.includes('airtable')) &&
  w.complexity === 'simple'
)
```

### "Complex AI agents"
```javascript
index.workflows.filter(w =>
  w.key_patterns?.includes('ai-agent') &&
  w.complexity === 'complex' &&
  w.nodes_count > 10
)
```

---

## Learning from Examples

### Beginner Query
User: "First AI workflow, what should I do?"

**Your Response**:
1. Search `complexity: "simple" && has_ai: true`
2. Find 3-5 entry-level examples
3. Show the simplest one (3-5 nodes)
4. Explain each node
5. Suggest gemini-2.5-flash

### Intermediate Query
User: "How to structure data extraction?"

**Your Response**:
1. Search `key_patterns: "structured-extraction"`
2. Find 154 examples
3. Show 3 different approaches
4. Highlight common best practices
5. Ready-to-use template

### Advanced Query
User: "Multi-tool agent with memory and RAG"

**Your Response**:
1. Search `ai-agent + nodes_count > 10`
2. Filter for presence of memory nodes
3. Search for vector store integration
4. Show complete example
5. Explain architecture

---

## Checklist for Every Search

Before responding to user:

- [ ] Did I load `workflow-metadata.json`?
- [ ] Did I filter correctly?
- [ ] Did I limit to 3-5 examples?
- [ ] Did I read only the necessary files?
- [ ] Did I show the file paths?
- [ ] Did I suggest modernizations if needed?
- [ ] Did I explain why these examples?
- [ ] Did I offer alternatives?

---

**Remember**: The index is your **treasure map**. The 2054 JSON files are the **treasure**. Use the map to find the right treasure, don't dig everywhere!
