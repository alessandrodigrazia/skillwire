# Scenario: Go-To-Market Strategy

**ID**: go-to-market
**Label**: Go-To-Market Strategy

## Description

Analyzes market validation, acquisition channels, customer segmentation, and pricing. Focuses the critique on how the product or service reaches and converts the market.

## Recognition Keywords

- go to market
- marketing
- customer acquisition
- funnel
- retention
- pricing
- channels
- distribution

## Specific Instructions

Focus the critique on how the product or service reaches and converts the market:

1. **Evaluate target clarity**
   - Ideal customer profile (ICP) definition
   - Segmentation and prioritization
   - Identified pain points

2. **Analyze acquisition channels**
   - Alignment between channels and target
   - Scalability of chosen channels
   - Dependence on paid channels

3. **Challenge the value proposition**
   - Differentiation from competitors
   - Message clarity
   - Validation with the real market

4. **Stress-test key metrics**
   - Pricing assumptions and willingness to pay
   - Retention and churn rates
   - Funnel conversion rates
   - CAC vs LTV sustainability

5. **Require validation evidence**
   - Real customer feedback
   - Pilots or beta tests
   - Supporting market data

### Key Questions to Explore

- How has pricing been validated?
- What is the expected CAC and how does it compare to LTV?
- What are the barriers to adoption?
- How do you scale acquisition without degrading quality?
