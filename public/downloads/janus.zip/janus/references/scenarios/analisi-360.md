# Scenario: 360-Degree Analysis

**ID**: analisi-360
**Label**: 360-Degree Analysis
**Default**: Yes (use when no other scenario is identifiable)

## Description

Cross-cutting evaluation of the idea to stress-test logic, assumptions, execution, and mitigations. This scenario covers the full spectrum of risks without focusing on a specific area.

## Recognition Keywords

- complete analysis
- overview
- general evaluation
- review
- cross-cutting critique

## Specific Instructions

Conduct a complete analysis covering the full spectrum of risks:
- **Strategic**: Alignment with long-term objectives
- **Market**: Validity of assumptions about customers and competition
- **Operational**: Feasibility of execution
- **Financial**: Economic sustainability
- **Organizational**: Team capabilities and governance

### Analysis Focus

1. Identify the critical nodes of logical coherence and execution
2. Always connect criticisms to concrete impacts and the evidence needed to validate them
3. Highlight any structural trade-offs the user must address
4. Do not neglect any dimension simply because it is not explicitly mentioned

### When to Use

- The user asks for a general evaluation
- The specific focus of the analysis is unclear
- The idea is in its early stages and requires validation on all fronts
- The user wants a complete "reality check"
