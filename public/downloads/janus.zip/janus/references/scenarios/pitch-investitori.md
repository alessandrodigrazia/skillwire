# Scenario: Investor Pitch

**ID**: pitch-investitori
**Label**: Investor Pitch

## Description

Focused on economic feasibility, financial metrics, expected returns, and plan credibility. Evaluates the proposal from the perspective of potential investors.

## Recognition Keywords

- investors
- fundraising
- pitch deck
- seed
- round
- valuation
- ROI
- venture capital
- angel investor

## Specific Instructions

Evaluate the proposal placing the perspective of potential investors at the center:

1. **Stress-test financial sustainability**
   - Return on investment (ROI)
   - Sensitivity to key economic drivers
   - Break-even and path to profitability

2. **Demand concrete metrics**
   - Addressable market (TAM, SAM, SOM)
   - Expected growth rates
   - Gross and operating margins
   - Capital requirements and runway

3. **Highlight inconsistencies between narrative and numbers**
   - Projections not supported by data
   - Overly optimistic assumptions
   - Lack of sensitivity analysis

4. **Require evidence supporting projections**
   - Existing traction
   - Market validation
   - Realistic comparables

### Key Questions to Explore

- What is the path to profitability?
- How is the requested valuation justified?
- What are the main risks for the investor?
- What is the exit strategy?
- How will the raised capital be used?
