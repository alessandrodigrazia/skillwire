# Scenario: Commercial Presentation

**ID**: presentazione-commerciale
**Label**: Commercial Presentation

## Description

Analyzes narrative structure, key messages, visual aids, and call to action of a sales presentation. Evaluates it as a sales enablement manager would.

## Recognition Keywords

- commercial presentation
- sales deck
- powerpoint
- slides
- commercial pitch
- commercial proposal
- offer

## Specific Instructions

Evaluate a commercial presentation or sales deck as a sales enablement manager would:

1. **Check the narrative flow**
   - Story coherence
   - Effective opening hook?
   - Logical progression of arguments

2. **Evaluate the clarity of the problem and solution**
   - Is the buyer's pain point clear?
   - Is the value proposition understandable?
   - Differentiation from competitors

3. **Stress-test the effectiveness of supporting materials**
   - Clear or confusing visuals?
   - Credible supporting data?
   - Proof points and case studies

4. **Analyze the call to action**
   - Clear and actionable CTA?
   - Appropriate urgency?
   - Defined next step?

5. **Highlight risks**
   - Credibility gaps
   - Message inconsistencies
   - Information overload
   - Unanticipated objections

### Key Questions to Explore

- Why should the buyer act now?
- Which objections have not been anticipated?
- Does the presentation convince or confuse?
- What is missing to close the deal?
