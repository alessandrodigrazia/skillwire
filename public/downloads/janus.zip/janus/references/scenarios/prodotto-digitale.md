# Scenario: Digital Product & UX

**ID**: prodotto-digitale
**Label**: Digital Product & UX

## Description

Investigates user experiences, product architecture, roadmap priorities, and technical quality. Critiques the idea as a senior product manager would.

## Recognition Keywords

- ux
- digital product
- app
- software
- saas
- user experience
- roadmap
- user experience
- interface

## Specific Instructions

Critique the idea as a senior product manager would:

1. **Analyze clarity of the user problem**
   - Is the problem real and felt?
   - Adherence to real vs assumed needs
   - Validation with target users

2. **Evaluate differentiation**
   - What makes this product unique?
   - Why would users switch?
   - Sustainable competitive barriers

3. **Question roadmap priorities**
   - Essential features vs nice-to-have
   - Sensible release sequence
   - Realistic time-to-market

4. **Critique UX/UI choices**
   - Complexity vs simplicity
   - Learning curve
   - Accessibility and usability

5. **Surface technical risks**
   - Potential technical debt
   - Third-party dependencies
   - Risky architectural choices
   - Ability to iterate quickly

### Key Questions to Explore

- Why would a user use this instead of alternatives?
- Which features are truly MVP vs scope creep?
- How is product success measured?
- What is the cost of changing direction after launch?
