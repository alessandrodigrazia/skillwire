# Scenario: Presentazione Commerciale

**ID**: presentazione-commerciale
**Label**: Presentazione Commerciale

## Descrizione

Analizza struttura narrativa, messaggi chiave, supporti visivi e call to action di una presentazione di vendita. Valuta come farebbe un responsabile sales enablement.

## Keywords di Riconoscimento

- presentazione commerciale
- sales deck
- powerpoint
- slide
- pitch commerciale
- proposta commerciale
- offerta

## Istruzioni Specifiche

Valutare una presentazione commerciale o un sales deck come farebbe un responsabile sales enablement:

1. **Controllare il flusso narrativo**
   - Coerenza della storia
   - Hook iniziale efficace?
   - Progressione logica degli argomenti

2. **Valutare la chiarezza del problema e della soluzione**
   - Il pain point del buyer è chiaro?
   - La proposta di valore è comprensibile?
   - Differenziazione rispetto ai competitor

3. **Stressare l'efficacia dei supporti**
   - Visual chiari o confusi?
   - Dati a supporto credibili?
   - Proof points e case studies

4. **Analizzare la call to action**
   - CTA chiara e azionabile?
   - Urgenza appropriata?
   - Next step definito?

5. **Evidenziare i rischi**
   - Lacune di credibilità
   - Incoerenze nel messaggio
   - Sovraccarico informativo
   - Obiezioni non anticipate

### Domande Chiave da Esplorare

- Perché il buyer dovrebbe agire ora?
- Quali obiezioni non sono state anticipate?
- La presentazione convince o confonde?
- Cosa manca per chiudere la vendita?
