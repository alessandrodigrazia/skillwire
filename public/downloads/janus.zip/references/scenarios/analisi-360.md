# Scenario: Analisi 360°

**ID**: analisi-360
**Label**: Analisi 360°
**Default**: Sì (usare quando nessun altro scenario è identificabile)

## Descrizione

Valutazione trasversale dell'idea per stressare logica, assunzioni, execution e mitigazioni. Questo scenario copre l'intero spettro di rischi senza focalizzarsi su un'area specifica.

## Keywords di Riconoscimento

- analisi completa
- panoramica
- valutazione generale
- review
- critica trasversale

## Istruzioni Specifiche

Condurre un'analisi completa toccando l'intero spettro di rischi:
- **Strategici**: Coerenza con obiettivi di lungo termine
- **Di mercato**: Validità delle assunzioni su clienti e competizione
- **Operativi**: Fattibilità dell'execution
- **Finanziari**: Sostenibilità economica
- **Organizzativi**: Capacità del team e governance

### Focus dell'Analisi

1. Individuare i nodi critici di coerenza logica e di execution
2. Collegare sempre le critiche a impatti concreti e alle evidenze necessarie per validarli
3. Evidenziare eventuali trade-off strutturali che l'utente deve affrontare
4. Non trascurare nessuna dimensione solo perché non esplicitamente menzionata

### Quando Usare

- L'utente chiede una valutazione generale
- Non è chiaro quale sia il focus specifico dell'analisi
- L'idea è in fase iniziale e richiede validazione su tutti i fronti
- L'utente vuole un "reality check" completo
