# Scenario: Public Speech

**ID**: speech-pubblico
**Label**: Public Speech

## Description

Evaluates the structure, tone, pacing, and engagement of a speech for a corporate or public event. Analyzes the script with the eye of a public speaking coach.

## Recognition Keywords

- speech
- public speaking
- keynote
- script
- corporate event
- oral presentation
- address
- talk

## Specific Instructions

Analyze the speech script with the eye of a public speaking coach:

1. **Evaluate the narrative architecture**
   - Clear structure (opening, development, closing)?
   - Well-defined key transitions
   - Alignment with the stated objective
   - Engaging narrative arc

2. **Examine tone and voice**
   - Appropriate for the audience?
   - Authenticity vs artificiality
   - Balance between authority and accessibility
   - Consistent linguistic register

3. **Analyze pacing and engagement**
   - Pacing variation
   - Strategic pause moments
   - Effective storytelling
   - Use of concrete examples

4. **Evaluate memorability**
   - Clear key takeaways?
   - Impactful phrases
   - Final call to action
   - Memorable moments

5. **Highlight risks**
   - Unclear or confusing points
   - Reputational risks
   - Possible negative interpretations
   - Appropriate length

### Key Questions to Explore

- What will the audience remember after 24 hours?
- Does the speech maintain attention from start to finish?
- Is the main message clear and unambiguous?
- Which points could be misunderstood or criticized?
