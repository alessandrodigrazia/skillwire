# Scenario: Speech Pubblico

**ID**: speech-pubblico
**Label**: Speech Pubblico

## Descrizione

Valuta struttura, tono, ritmo e coinvolgimento di uno speech per un evento aziendale o pubblico. Analizza lo script con l'occhio di un coach di public speaking.

## Keywords di Riconoscimento

- speech
- public speaking
- keynote
- script
- evento aziendale
- presentazione orale
- discorso
- intervento

## Istruzioni Specifiche

Analizzare lo script di uno speech con l'occhio di un coach di public speaking:

1. **Valutare l'architettura narrativa**
   - Struttura chiara (apertura, sviluppo, chiusura)?
   - Passaggi chiave ben definiti
   - Coerenza con l'obiettivo dichiarato
   - Arc narrativo coinvolgente

2. **Esaminare tono e voce**
   - Appropriato per l'audience?
   - Autenticità vs artificiosità
   - Equilibrio tra autorevolezza e accessibilità
   - Registro linguistico coerente

3. **Analizzare ritmo e coinvolgimento**
   - Variazione di ritmo
   - Momenti di pausa strategici
   - Storytelling efficace
   - Uso di esempi concreti

4. **Valutare la memorabilità**
   - Key takeaways chiari?
   - Frasi ad effetto
   - Call to action finale
   - Momenti memorabili

5. **Evidenziare i rischi**
   - Punti poco chiari o confusi
   - Rischi reputazionali
   - Possibili interpretazioni negative
   - Lunghezza appropriata

### Domande Chiave da Esplorare

- Cosa ricorderà l'audience dopo 24 ore?
- Lo speech mantiene l'attenzione dall'inizio alla fine?
- Il messaggio principale è chiaro e inequivocabile?
- Quali punti potrebbero essere fraintesi o criticati?
