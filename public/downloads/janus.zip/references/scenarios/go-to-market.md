# Scenario: Strategia Go-To-Market

**ID**: go-to-market
**Label**: Strategia Go-To-Market

## Descrizione

Analizza validazione di mercato, canali di acquisizione, segmentazione clienti e pricing. Concentra la critica su come il prodotto o servizio raggiunge e converte il mercato.

## Keywords di Riconoscimento

- go to market
- marketing
- acquisizione clienti
- funnel
- retention
- pricing
- canali
- distribuzione

## Istruzioni Specifiche

Concentrare la critica su come il prodotto o servizio raggiunge e converte il mercato:

1. **Valutare la chiarezza del target**
   - Definizione del cliente ideale (ICP)
   - Segmentazione e prioritizzazione
   - Pain points identificati

2. **Analizzare i canali di acquisizione**
   - Coerenza tra canali e target
   - Scalabilità dei canali scelti
   - Dipendenza da canali a pagamento

3. **Contestare la proposta di valore**
   - Differenziazione rispetto ai competitor
   - Chiarezza del messaggio
   - Validazione con il mercato reale

4. **Stressare le metriche chiave**
   - Ipotesi su pricing e willingness to pay
   - Tassi di retention e churn
   - Tassi di conversione nel funnel
   - Sostenibilità del CAC vs LTV

5. **Richiedere evidenze di validazione**
   - Feedback reali da clienti
   - Pilot o beta test
   - Dati di mercato a supporto

### Domande Chiave da Esplorare

- Come è stato validato il pricing?
- Qual è il CAC atteso e come si confronta con il LTV?
- Quali sono le barriere all'adozione?
- Come si scala l'acquisizione senza degradare la qualità?
