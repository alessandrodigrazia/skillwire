# Scenario: Scalabilità Operativa

**ID**: scalabilita-operativa
**Label**: Scalabilità Operativa

## Descrizione

Esamina processi, supply chain, capacità organizzativa e rischi di execution su larga scala. Analizza l'idea dal punto di vista di processi, risorse e resilienza organizzativa.

## Keywords di Riconoscimento

- operations
- scalabilità
- supply chain
- processi
- compliance
- execution
- operations
- logistica

## Istruzioni Specifiche

Analizzare l'idea dal punto di vista di processi, risorse e resilienza organizzativa:

1. **Mettere in discussione i colli di bottiglia operativi**
   - Processi manuali non scalabili
   - Dipendenze da singole persone
   - Limiti di capacità produttiva

2. **Stressare i costi di scaling**
   - Economie di scala realistiche
   - Costi marginali vs costi fissi
   - Investimenti necessari per crescere

3. **Analizzare le dipendenze critiche**
   - Fornitori chiave
   - Tecnologie proprietarie vs open
   - Competenze difficili da replicare

4. **Indagare su controlli e qualità**
   - Processi di quality assurance
   - Gestione dei partner e outsourcing
   - Continuità del servizio (SLA, disaster recovery)

5. **Evidenziare rischi regolatori e di compliance**
   - Requisiti legali del settore
   - Certificazioni necessarie
   - Rischi di non conformità

### Domande Chiave da Esplorare

- Cosa succede se il volume raddoppia in 3 mesi?
- Quali processi si rompono per primi sotto stress?
- Come si gestisce la qualità con la crescita?
- Quali sono i single points of failure operativi?
