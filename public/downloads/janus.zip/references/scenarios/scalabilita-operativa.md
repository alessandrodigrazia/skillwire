# Scenario: Operational Scalability

**ID**: scalabilita-operativa
**Label**: Operational Scalability

## Description

Examines processes, supply chain, organizational capacity, and execution risks at scale. Analyzes the idea from the perspective of processes, resources, and organizational resilience.

## Recognition Keywords

- operations
- scalability
- supply chain
- processes
- compliance
- execution
- operations
- logistics

## Specific Instructions

Analyze the idea from the perspective of processes, resources, and organizational resilience:

1. **Challenge operational bottlenecks**
   - Non-scalable manual processes
   - Dependencies on single individuals
   - Production capacity limits

2. **Stress-test scaling costs**
   - Realistic economies of scale
   - Marginal costs vs fixed costs
   - Investments needed to grow

3. **Analyze critical dependencies**
   - Key suppliers
   - Proprietary vs open technologies
   - Hard-to-replicate competencies

4. **Investigate controls and quality**
   - Quality assurance processes
   - Partner management and outsourcing
   - Service continuity (SLA, disaster recovery)

5. **Highlight regulatory and compliance risks**
   - Industry legal requirements
   - Necessary certifications
   - Non-compliance risks

### Key Questions to Explore

- What happens if volume doubles in 3 months?
- Which processes break first under stress?
- How is quality managed during growth?
- What are the operational single points of failure?
