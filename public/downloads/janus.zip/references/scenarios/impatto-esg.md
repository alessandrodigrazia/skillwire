# Scenario: ESG Impact & Reputation

**ID**: impatto-esg
**Label**: ESG Impact & Reputation

## Description

Puts pressure on environmental sustainability, social responsibility, and image risks. Analyzes the initiative with the eye of an ESG committee and institutional relations.

## Recognition Keywords

- esg
- sustainability
- governance
- social responsibility
- reputation
- environment
- carbon footprint
- diversity

## Specific Instructions

Analyze the initiative with the eye of an ESG committee and institutional relations:

1. **Challenge environmental claims (E)**
   - Direct and indirect emissions
   - Resource consumption
   - Environmental mitigation strategies
   - Greenwashing risk

2. **Evaluate social responsibility (S)**
   - Labor policies
   - Inclusion and diversity
   - Impact on communities
   - Ethical supply chain

3. **Examine governance (G)**
   - Transparency toward stakeholders
   - Decision-making structure
   - Conflict of interest management
   - Accountability

4. **Highlight reputational issues**
   - Potential controversies
   - Public opinion sensitivity
   - Social backlash risks
   - Media exposure

5. **Analyze regulatory requirements**
   - Mandatory ESG compliance
   - Future regulatory trends
   - Reporting requirements
   - Necessary certifications

### Key Questions to Explore

- Are sustainability claims supported by data?
- What are the hidden reputational risks?
- Is the company prepared for public scrutiny?
- What would happen if an ESG issue were to emerge?
