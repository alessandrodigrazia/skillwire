# Scenario: Impatto ESG & Reputazione

**ID**: impatto-esg
**Label**: Impatto ESG & Reputazione

## Descrizione

Mette sotto pressione sostenibilità ambientale, responsabilità sociale e rischi d'immagine. Analizza l'iniziativa con l'occhio di un comitato ESG e relazioni istituzionali.

## Keywords di Riconoscimento

- esg
- sostenibilità
- governance
- responsabilità sociale
- reputazione
- ambiente
- carbon footprint
- diversity

## Istruzioni Specifiche

Analizzare l'iniziativa con l'occhio di un comitato ESG e relazioni istituzionali:

1. **Contestare le dichiarazioni ambientali (E)**
   - Emissioni dirette e indirette
   - Consumo di risorse
   - Strategie di mitigazione ambientale
   - Rischio greenwashing

2. **Valutare la responsabilità sociale (S)**
   - Politiche sul lavoro
   - Inclusione e diversity
   - Impatto sulle comunità
   - Catena di fornitura etica

3. **Esaminare la governance (G)**
   - Trasparenza verso stakeholder
   - Struttura decisionale
   - Gestione dei conflitti di interesse
   - Accountability

4. **Evidenziare criticità reputazionali**
   - Potenziali controversie
   - Sensibilità dell'opinione pubblica
   - Rischi di backlash social
   - Esposizione mediatica

5. **Analizzare requisiti normativi**
   - Compliance ESG obbligatoria
   - Trend regolatori futuri
   - Reporting requirements
   - Certificazioni necessarie

### Domande Chiave da Esplorare

- Le dichiarazioni di sostenibilità sono supportate da dati?
- Quali sono i rischi reputazionali nascosti?
- L'azienda è preparata allo scrutinio pubblico?
- Cosa succederebbe se emergesse una criticità ESG?
