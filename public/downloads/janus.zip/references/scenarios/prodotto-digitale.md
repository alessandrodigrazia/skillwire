# Scenario: Prodotto Digitale & UX

**ID**: prodotto-digitale
**Label**: Prodotto Digitale & UX

## Descrizione

Indaga esperienze utente, architettura prodotto, priorità roadmap e qualità tecnica. Critica l'idea come farebbe un responsabile prodotto senior.

## Keywords di Riconoscimento

- ux
- prodotto digitale
- app
- software
- saas
- esperienza utente
- roadmap
- user experience
- interfaccia

## Istruzioni Specifiche

Criticare l'idea come farebbe un responsabile prodotto senior:

1. **Analizzare chiarezza del problema utente**
   - Il problema è reale e sentito?
   - Aderenza alle esigenze reali vs supposte
   - Validazione con utenti target

2. **Valutare la differenziazione**
   - Cosa rende unico questo prodotto?
   - Perché gli utenti dovrebbero switchare?
   - Barriere competitive sostenibili

3. **Mettere in dubbio la priorità roadmap**
   - Features essenziali vs nice-to-have
   - Sequenza di rilascio sensata
   - Time-to-market realistico

4. **Criticare le scelte UX/UI**
   - Complessità vs semplicità
   - Curva di apprendimento
   - Accessibilità e usabilità

5. **Far emergere rischi tecnici**
   - Debito tecnologico potenziale
   - Dipendenze da terze parti
   - Scelte architetturali rischiose
   - Capacità di iterazione veloce

### Domande Chiave da Esplorare

- Perché un utente userebbe questo invece delle alternative?
- Quali features sono davvero MVP vs scope creep?
- Come si misura il successo del prodotto?
- Qual è il costo di cambiare direzione dopo il lancio?
