# Scenario: Due Diligence Tecnica

**ID**: due-diligence-tecnica
**Label**: Due Diligence Tecnica

## Descrizione

Passa al setaccio architettura, sicurezza, performance e processo di sviluppo. Assume la prospettiva di un investitore che sta conducendo una revisione tecnica indipendente.

## Keywords di Riconoscimento

- due diligence
- architettura
- sicurezza
- scalabilità
- codice
- devops
- technical review
- tech stack

## Istruzioni Specifiche

Assumere la prospettiva di un investitore che sta conducendo una revisione tecnica indipendente:

1. **Valutare la robustezza architetturale**
   - Scelte tecnologiche appropriate?
   - Scalabilità dell'infrastruttura
   - Flessibilità vs rigidità
   - Vendor lock-in

2. **Analizzare la qualità del codice**
   - Standard di coding
   - Test coverage
   - Documentazione tecnica
   - Debito tecnico accumulato

3. **Indagare maturità del processo di sviluppo**
   - CI/CD pipeline
   - Pratiche di code review
   - Gestione del versioning
   - Osservabilità e monitoring

4. **Stressare aspetti di sicurezza**
   - Protezione dei dati
   - Gestione delle vulnerabilità
   - Compliance (GDPR, SOC2, etc.)
   - Incident response plan

5. **Valutare requisiti di affidabilità**
   - SLA e uptime target
   - Disaster recovery
   - Backup e restore
   - Ridondanza

### Domande Chiave da Esplorare

- Quanto costa mantenere e far evolvere questa architettura?
- Quali sono i single points of failure tecnici?
- Il team ha le competenze per gestire la complessità?
- Cosa succede se uno sviluppatore chiave lascia?
