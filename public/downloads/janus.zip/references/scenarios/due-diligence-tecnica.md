# Scenario: Technical Due Diligence

**ID**: due-diligence-tecnica
**Label**: Technical Due Diligence

## Description

Scrutinizes architecture, security, performance, and development process. Assumes the perspective of an investor conducting an independent technical review.

## Recognition Keywords

- due diligence
- architecture
- security
- scalability
- code
- devops
- technical review
- tech stack

## Specific Instructions

Assume the perspective of an investor conducting an independent technical review:

1. **Evaluate architectural robustness**
   - Appropriate technology choices?
   - Infrastructure scalability
   - Flexibility vs rigidity
   - Vendor lock-in

2. **Analyze code quality**
   - Coding standards
   - Test coverage
   - Technical documentation
   - Accumulated technical debt

3. **Investigate development process maturity**
   - CI/CD pipeline
   - Code review practices
   - Version management
   - Observability and monitoring

4. **Stress-test security aspects**
   - Data protection
   - Vulnerability management
   - Compliance (GDPR, SOC2, etc.)
   - Incident response plan

5. **Evaluate reliability requirements**
   - SLA and uptime targets
   - Disaster recovery
   - Backup and restore
   - Redundancy

### Key Questions to Explore

- How much does it cost to maintain and evolve this architecture?
- What are the technical single points of failure?
- Does the team have the competencies to manage the complexity?
- What happens if a key developer leaves?
