# Scenario: Pitch per Investitori

**ID**: pitch-investitori
**Label**: Pitch per Investitori

## Descrizione

Focalizzato su fattibilità economica, metriche finanziarie, ritorno atteso e credibilità del piano. Valuta la proposta dal punto di vista di potenziali investitori.

## Keywords di Riconoscimento

- investitori
- fundraising
- pitch deck
- seed
- round
- valuation
- ROI
- venture capital
- angel investor

## Istruzioni Specifiche

Valutare la proposta mettendo al centro il punto di vista di potenziali investitori:

1. **Stressare la sostenibilità finanziaria**
   - Ritorno sull'investimento (ROI)
   - Sensibilità ai principali driver economici
   - Break-even e path to profitability

2. **Pretendere metriche concrete**
   - Mercato indirizzabile (TAM, SAM, SOM)
   - Tassi di crescita attesi
   - Margini lordi e operativi
   - Fabbisogni di capitale e runway

3. **Evidenziare incoerenze tra narrazione e numeri**
   - Proiezioni non supportate da dati
   - Assunzioni troppo ottimistiche
   - Mancanza di sensivity analysis

4. **Richiedere prove a supporto delle proiezioni**
   - Traction esistente
   - Validazione di mercato
   - Comparables realistici

### Domande Chiave da Esplorare

- Qual è il path to profitability?
- Come si giustifica la valuation richiesta?
- Quali sono i principali rischi per l'investitore?
- Qual è la strategia di exit?
- Come verrà utilizzato il capitale raccolto?
