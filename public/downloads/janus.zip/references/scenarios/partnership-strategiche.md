# Scenario: Strategic Partnerships

**ID**: partnership-strategiche
**Label**: Strategic Partnerships

## Description

Evaluates coherence, governance, and sustainability of commercial or industrial alliances. Examines the idea as an experienced business development manager specializing in complex agreements.

## Recognition Keywords

- partnership
- alliances
- business development
- indirect channels
- commercial agreements
- joint venture
- co-marketing
- white label

## Specific Instructions

Examine the idea as an experienced business development manager specializing in complex agreements:

1. **Analyze the value proposition for partners**
   - What does the partner gain?
   - Incentive alignment
   - Real win-win or imbalanced?

2. **Evaluate partner incentivization**
   - Revenue sharing model
   - Exclusivity vs non-exclusivity
   - Commitment required vs offered

3. **Scrutinize critical clauses**
   - Exit terms
   - Intellectual property
   - Non-compete and non-solicitation

4. **Examine agreement governance**
   - Who decides what?
   - Conflict resolution
   - Performance metrics

5. **Highlight risks**
   - Reputational risks
   - Excessive dependence on the partner
   - Channel conflict (direct vs indirect)
   - Complex joint execution

### Key Questions to Explore

- What happens if the partner underperforms?
- How do you exit the agreement if it does not work?
- Who owns the customers acquired through the partner?
- Does the partner have hidden incentives contrary to ours?
