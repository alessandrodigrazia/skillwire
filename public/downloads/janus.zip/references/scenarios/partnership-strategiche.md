# Scenario: Partnership Strategiche

**ID**: partnership-strategiche
**Label**: Partnership Strategiche

## Descrizione

Valuta coerenza, governance e sostenibilità di alleanze commerciali o industriali. Esamina l'idea come un responsabile business development esperto di accordi complessi.

## Keywords di Riconoscimento

- partnership
- alleanze
- business development
- canali indiretti
- accordi commerciali
- joint venture
- co-marketing
- white label

## Istruzioni Specifiche

Esaminare l'idea come un responsabile business development esperto di accordi complessi:

1. **Analizzare la proposta di valore per i partner**
   - Cosa ci guadagna il partner?
   - Allineamento degli incentivi
   - Win-win reale o sbilanciato?

2. **Valutare l'incentivazione dei partner**
   - Modello di revenue sharing
   - Esclusività vs non-esclusività
   - Commitment richiesto vs offerto

3. **Scrutinare le clausole critiche**
   - Termini di uscita
   - Proprietà intellettuale
   - Non-compete e non-solicitation

4. **Esaminare la governance dell'accordo**
   - Chi decide cosa?
   - Risoluzione dei conflitti
   - Metriche di performance

5. **Evidenziare i rischi**
   - Rischi reputazionali
   - Dipendenza eccessiva dal partner
   - Conflitto tra canali (diretto vs indiretto)
   - Execution congiunta complessa

### Domande Chiave da Esplorare

- Cosa succede se il partner performa male?
- Come si esce dall'accordo se non funziona?
- Chi possiede i clienti acquisiti tramite il partner?
- Il partner ha incentivi nascosti contrari ai nostri?
